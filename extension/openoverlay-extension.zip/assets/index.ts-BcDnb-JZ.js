(function(){const Gm=()=>{};var sh={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const rf=function(n){const e=[];let t=0;for(let r=0;r<n.length;r++){let i=n.charCodeAt(r);i<128?e[t++]=i:i<2048?(e[t++]=i>>6|192,e[t++]=i&63|128):(i&64512)===55296&&r+1<n.length&&(n.charCodeAt(r+1)&64512)===56320?(i=65536+((i&1023)<<10)+(n.charCodeAt(++r)&1023),e[t++]=i>>18|240,e[t++]=i>>12&63|128,e[t++]=i>>6&63|128,e[t++]=i&63|128):(e[t++]=i>>12|224,e[t++]=i>>6&63|128,e[t++]=i&63|128)}return e},Km=function(n){const e=[];let t=0,r=0;for(;t<n.length;){const i=n[t++];if(i<128)e[r++]=String.fromCharCode(i);else if(i>191&&i<224){const o=n[t++];e[r++]=String.fromCharCode((i&31)<<6|o&63)}else if(i>239&&i<365){const o=n[t++],s=n[t++],l=n[t++],u=((i&7)<<18|(o&63)<<12|(s&63)<<6|l&63)-65536;e[r++]=String.fromCharCode(55296+(u>>10)),e[r++]=String.fromCharCode(56320+(u&1023))}else{const o=n[t++],s=n[t++];e[r++]=String.fromCharCode((i&15)<<12|(o&63)<<6|s&63)}}return e.join("")},of={byteToCharMap_:null,charToByteMap_:null,byteToCharMapWebSafe_:null,charToByteMapWebSafe_:null,ENCODED_VALS_BASE:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",get ENCODED_VALS(){return this.ENCODED_VALS_BASE+"+/="},get ENCODED_VALS_WEBSAFE(){return this.ENCODED_VALS_BASE+"-_."},HAS_NATIVE_SUPPORT:typeof atob=="function",encodeByteArray(n,e){if(!Array.isArray(n))throw Error("encodeByteArray takes an array as a parameter");this.init_();const t=e?this.byteToCharMapWebSafe_:this.byteToCharMap_,r=[];for(let i=0;i<n.length;i+=3){const o=n[i],s=i+1<n.length,l=s?n[i+1]:0,u=i+2<n.length,h=u?n[i+2]:0,p=o>>2,m=(o&3)<<4|l>>4;let g=(l&15)<<2|h>>6,b=h&63;u||(b=64,s||(g=64)),r.push(t[p],t[m],t[g],t[b])}return r.join("")},encodeString(n,e){return this.HAS_NATIVE_SUPPORT&&!e?btoa(n):this.encodeByteArray(rf(n),e)},decodeString(n,e){return this.HAS_NATIVE_SUPPORT&&!e?atob(n):Km(this.decodeStringToByteArray(n,e))},decodeStringToByteArray(n,e){this.init_();const t=e?this.charToByteMapWebSafe_:this.charToByteMap_,r=[];for(let i=0;i<n.length;){const o=t[n.charAt(i++)],l=i<n.length?t[n.charAt(i)]:0;++i;const h=i<n.length?t[n.charAt(i)]:64;++i;const m=i<n.length?t[n.charAt(i)]:64;if(++i,o==null||l==null||h==null||m==null)throw new Ym;const g=o<<2|l>>4;if(r.push(g),h!==64){const b=l<<4&240|h>>2;if(r.push(b),m!==64){const P=h<<6&192|m;r.push(P)}}}return r},init_(){if(!this.byteToCharMap_){this.byteToCharMap_={},this.charToByteMap_={},this.byteToCharMapWebSafe_={},this.charToByteMapWebSafe_={};for(let n=0;n<this.ENCODED_VALS.length;n++)this.byteToCharMap_[n]=this.ENCODED_VALS.charAt(n),this.charToByteMap_[this.byteToCharMap_[n]]=n,this.byteToCharMapWebSafe_[n]=this.ENCODED_VALS_WEBSAFE.charAt(n),this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[n]]=n,n>=this.ENCODED_VALS_BASE.length&&(this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(n)]=n,this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(n)]=n)}}};class Ym extends Error{constructor(){super(...arguments),this.name="DecodeBase64StringError"}}const Qm=function(n){const e=rf(n);return of.encodeByteArray(e,!0)},Ns=function(n){return Qm(n).replace(/\./g,"")},sf=function(n){try{return of.decodeString(n,!0)}catch(e){console.error("base64Decode failed: ",e)}return null};/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Jm(){if(typeof self<"u")return self;if(typeof window<"u")return window;if(typeof global<"u")return global;throw new Error("Unable to locate global object.")}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Xm=()=>Jm().__FIREBASE_DEFAULTS__,Zm=()=>{if(typeof process>"u"||typeof sh>"u")return;const n=sh.__FIREBASE_DEFAULTS__;if(n)return JSON.parse(n)},ey=()=>{if(typeof document>"u")return;let n;try{n=document.cookie.match(/__FIREBASE_DEFAULTS__=([^;]+)/)}catch{return}const e=n&&sf(n[1]);return e&&JSON.parse(e)},oa=()=>{try{return Gm()||Xm()||Zm()||ey()}catch(n){console.info(`Unable to get __FIREBASE_DEFAULTS__ due to: ${n}`);return}},af=n=>{var e,t;return(t=(e=oa())==null?void 0:e.emulatorHosts)==null?void 0:t[n]},ty=n=>{const e=af(n);if(!e)return;const t=e.lastIndexOf(":");if(t<=0||t+1===e.length)throw new Error(`Invalid host ${e} with no separate hostname and port!`);const r=parseInt(e.substring(t+1),10);return e[0]==="["?[e.substring(1,t-1),r]:[e.substring(0,t),r]},lf=()=>{var n;return(n=oa())==null?void 0:n.config},cf=n=>{var e;return(e=oa())==null?void 0:e[`_${n}`]};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ny{constructor(){this.reject=()=>{},this.resolve=()=>{},this.promise=new Promise((e,t)=>{this.resolve=e,this.reject=t})}wrapCallback(e){return(t,r)=>{t?this.reject(t):this.resolve(r),typeof e=="function"&&(this.promise.catch(()=>{}),e.length===1?e(t):e(t,r))}}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ry(n,e){if(n.uid)throw new Error('The "uid" field is no longer supported by mockUserToken. Please use "sub" instead for Firebase Auth User ID.');const t={alg:"none",type:"JWT"},r=e||"demo-project",i=n.iat||0,o=n.sub||n.user_id;if(!o)throw new Error("mockUserToken must contain 'sub' or 'user_id' field!");const s={iss:`https://securetoken.google.com/${r}`,aud:r,iat:i,exp:i+3600,auth_time:i,sub:o,user_id:o,firebase:{sign_in_provider:"custom",identities:{}},...n};return[Ns(JSON.stringify(t)),Ns(JSON.stringify(s)),""].join(".")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Qe(){return typeof navigator<"u"&&typeof navigator.userAgent=="string"?navigator.userAgent:""}function iy(){return typeof window<"u"&&!!(window.cordova||window.phonegap||window.PhoneGap)&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i.test(Qe())}function oy(){var e;const n=(e=oa())==null?void 0:e.forceEnvironment;if(n==="node")return!0;if(n==="browser")return!1;try{return Object.prototype.toString.call(global.process)==="[object process]"}catch{return!1}}function sy(){return typeof navigator<"u"&&navigator.userAgent==="Cloudflare-Workers"}function ay(){const n=typeof chrome=="object"?chrome.runtime:typeof browser=="object"?browser.runtime:void 0;return typeof n=="object"&&n.id!==void 0}function ly(){return typeof navigator=="object"&&navigator.product==="ReactNative"}function cy(){const n=Qe();return n.indexOf("MSIE ")>=0||n.indexOf("Trident/")>=0}function uy(){return!oy()&&!!navigator.userAgent&&navigator.userAgent.includes("Safari")&&!navigator.userAgent.includes("Chrome")}function hy(){try{return typeof indexedDB=="object"}catch{return!1}}function dy(){return new Promise((n,e)=>{try{let t=!0;const r="validate-browser-context-for-indexeddb-analytics-module",i=self.indexedDB.open(r);i.onsuccess=()=>{i.result.close(),t||self.indexedDB.deleteDatabase(r),n(!0)},i.onupgradeneeded=()=>{t=!1},i.onerror=()=>{var o;e(((o=i.error)==null?void 0:o.message)||"")}}catch(t){e(t)}})}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const fy="FirebaseError";class yn extends Error{constructor(e,t,r){super(t),this.code=e,this.customData=r,this.name=fy,Object.setPrototypeOf(this,yn.prototype),Error.captureStackTrace&&Error.captureStackTrace(this,Oo.prototype.create)}}class Oo{constructor(e,t,r){this.service=e,this.serviceName=t,this.errors=r}create(e,...t){const r=t[0]||{},i=`${this.service}/${e}`,o=this.errors[e],s=o?py(o,r):"Error",l=`${this.serviceName}: ${s} (${i}).`;return new yn(i,l,r)}}function py(n,e){return n.replace(gy,(t,r)=>{const i=e[r];return i!=null?String(i):`<${r}?>`})}const gy=/\{\$([^}]+)}/g;function my(n){for(const e in n)if(Object.prototype.hasOwnProperty.call(n,e))return!1;return!0}function mr(n,e){if(n===e)return!0;const t=Object.keys(n),r=Object.keys(e);for(const i of t){if(!r.includes(i))return!1;const o=n[i],s=e[i];if(ah(o)&&ah(s)){if(!mr(o,s))return!1}else if(o!==s)return!1}for(const i of r)if(!t.includes(i))return!1;return!0}function ah(n){return n!==null&&typeof n=="object"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function No(n){const e=[];for(const[t,r]of Object.entries(n))Array.isArray(r)?r.forEach(i=>{e.push(encodeURIComponent(t)+"="+encodeURIComponent(i))}):e.push(encodeURIComponent(t)+"="+encodeURIComponent(r));return e.length?"&"+e.join("&"):""}function yy(n,e){const t=new vy(n,e);return t.subscribe.bind(t)}class vy{constructor(e,t){this.observers=[],this.unsubscribes=[],this.observerCount=0,this.task=Promise.resolve(),this.finalized=!1,this.onNoObservers=t,this.task.then(()=>{e(this)}).catch(r=>{this.error(r)})}next(e){this.forEachObserver(t=>{t.next(e)})}error(e){this.forEachObserver(t=>{t.error(e)}),this.close(e)}complete(){this.forEachObserver(e=>{e.complete()}),this.close()}subscribe(e,t,r){let i;if(e===void 0&&t===void 0&&r===void 0)throw new Error("Missing Observer.");_y(e,["next","error","complete"])?i=e:i={next:e,error:t,complete:r},i.next===void 0&&(i.next=Ka),i.error===void 0&&(i.error=Ka),i.complete===void 0&&(i.complete=Ka);const o=this.unsubscribeOne.bind(this,this.observers.length);return this.finalized&&this.task.then(()=>{try{this.finalError?i.error(this.finalError):i.complete()}catch{}}),this.observers.push(i),o}unsubscribeOne(e){this.observers===void 0||this.observers[e]===void 0||(delete this.observers[e],this.observerCount-=1,this.observerCount===0&&this.onNoObservers!==void 0&&this.onNoObservers(this))}forEachObserver(e){if(!this.finalized)for(let t=0;t<this.observers.length;t++)this.sendOne(t,e)}sendOne(e,t){this.task.then(()=>{if(this.observers!==void 0&&this.observers[e]!==void 0)try{t(this.observers[e])}catch(r){typeof console<"u"&&console.error&&console.error(r)}})}close(e){this.finalized||(this.finalized=!0,e!==void 0&&(this.finalError=e),this.task.then(()=>{this.observers=void 0,this.onNoObservers=void 0}))}}function _y(n,e){if(typeof n!="object"||n===null)return!1;for(const t of e)if(t in n&&typeof n[t]=="function")return!0;return!1}function Ka(){}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Be(n){return n&&n._delegate?n._delegate:n}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Do(n){try{return(n.startsWith("http://")||n.startsWith("https://")?new URL(n).hostname:n).endsWith(".cloudworkstations.dev")}catch{return!1}}async function uf(n){return(await fetch(n,{credentials:"include"})).ok}class yr{constructor(e,t,r){this.name=e,this.instanceFactory=t,this.type=r,this.multipleInstances=!1,this.serviceProps={},this.instantiationMode="LAZY",this.onInstanceCreated=null}setInstantiationMode(e){return this.instantiationMode=e,this}setMultipleInstances(e){return this.multipleInstances=e,this}setServiceProps(e){return this.serviceProps=e,this}setInstanceCreatedCallback(e){return this.onInstanceCreated=e,this}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ir="[DEFAULT]";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wy{constructor(e,t){this.name=e,this.container=t,this.component=null,this.instances=new Map,this.instancesDeferred=new Map,this.instancesOptions=new Map,this.onInitCallbacks=new Map}get(e){const t=this.normalizeInstanceIdentifier(e);if(!this.instancesDeferred.has(t)){const r=new ny;if(this.instancesDeferred.set(t,r),this.isInitialized(t)||this.shouldAutoInitialize())try{const i=this.getOrInitializeService({instanceIdentifier:t});i&&r.resolve(i)}catch{}}return this.instancesDeferred.get(t).promise}getImmediate(e){const t=this.normalizeInstanceIdentifier(e==null?void 0:e.identifier),r=(e==null?void 0:e.optional)??!1;if(this.isInitialized(t)||this.shouldAutoInitialize())try{return this.getOrInitializeService({instanceIdentifier:t})}catch(i){if(r)return null;throw i}else{if(r)return null;throw Error(`Service ${this.name} is not available`)}}getComponent(){return this.component}setComponent(e){if(e.name!==this.name)throw Error(`Mismatching Component ${e.name} for Provider ${this.name}.`);if(this.component)throw Error(`Component for ${this.name} has already been provided`);if(this.component=e,!!this.shouldAutoInitialize()){if(Ty(e))try{this.getOrInitializeService({instanceIdentifier:ir})}catch{}for(const[t,r]of this.instancesDeferred.entries()){const i=this.normalizeInstanceIdentifier(t);try{const o=this.getOrInitializeService({instanceIdentifier:i});r.resolve(o)}catch{}}}}clearInstance(e=ir){this.instancesDeferred.delete(e),this.instancesOptions.delete(e),this.instances.delete(e)}async delete(){const e=Array.from(this.instances.values());await Promise.all([...e.filter(t=>"INTERNAL"in t).map(t=>t.INTERNAL.delete()),...e.filter(t=>"_delete"in t).map(t=>t._delete())])}isComponentSet(){return this.component!=null}isInitialized(e=ir){return this.instances.has(e)}getOptions(e=ir){return this.instancesOptions.get(e)||{}}initialize(e={}){const{options:t={}}=e,r=this.normalizeInstanceIdentifier(e.instanceIdentifier);if(this.isInitialized(r))throw Error(`${this.name}(${r}) has already been initialized`);if(!this.isComponentSet())throw Error(`Component ${this.name} has not been registered yet`);const i=this.getOrInitializeService({instanceIdentifier:r,options:t});for(const[o,s]of this.instancesDeferred.entries()){const l=this.normalizeInstanceIdentifier(o);r===l&&s.resolve(i)}return i}onInit(e,t){const r=this.normalizeInstanceIdentifier(t),i=this.onInitCallbacks.get(r)??new Set;i.add(e),this.onInitCallbacks.set(r,i);const o=this.instances.get(r);return o&&e(o,r),()=>{i.delete(e)}}invokeOnInitCallbacks(e,t){const r=this.onInitCallbacks.get(t);if(r)for(const i of r)try{i(e,t)}catch{}}getOrInitializeService({instanceIdentifier:e,options:t={}}){let r=this.instances.get(e);if(!r&&this.component&&(r=this.component.instanceFactory(this.container,{instanceIdentifier:by(e),options:t}),this.instances.set(e,r),this.instancesOptions.set(e,t),this.invokeOnInitCallbacks(r,e),this.component.onInstanceCreated))try{this.component.onInstanceCreated(this.container,e,r)}catch{}return r||null}normalizeInstanceIdentifier(e=ir){return this.component?this.component.multipleInstances?e:ir:e}shouldAutoInitialize(){return!!this.component&&this.component.instantiationMode!=="EXPLICIT"}}function by(n){return n===ir?void 0:n}function Ty(n){return n.instantiationMode==="EAGER"}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ey{constructor(e){this.name=e,this.providers=new Map}addComponent(e){const t=this.getProvider(e.name);if(t.isComponentSet())throw new Error(`Component ${e.name} has already been registered with ${this.name}`);t.setComponent(e)}addOrOverwriteComponent(e){this.getProvider(e.name).isComponentSet()&&this.providers.delete(e.name),this.addComponent(e)}getProvider(e){if(this.providers.has(e))return this.providers.get(e);const t=new wy(e,this);return this.providers.set(e,t),t}getProviders(){return Array.from(this.providers.values())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var ne;(function(n){n[n.DEBUG=0]="DEBUG",n[n.VERBOSE=1]="VERBOSE",n[n.INFO=2]="INFO",n[n.WARN=3]="WARN",n[n.ERROR=4]="ERROR",n[n.SILENT=5]="SILENT"})(ne||(ne={}));const Iy={debug:ne.DEBUG,verbose:ne.VERBOSE,info:ne.INFO,warn:ne.WARN,error:ne.ERROR,silent:ne.SILENT},Ay=ne.INFO,Sy={[ne.DEBUG]:"log",[ne.VERBOSE]:"log",[ne.INFO]:"info",[ne.WARN]:"warn",[ne.ERROR]:"error"},xy=(n,e,...t)=>{if(e<n.logLevel)return;const r=new Date().toISOString(),i=Sy[e];if(i)console[i](`[${r}]  ${n.name}:`,...t);else throw new Error(`Attempted to log a message with an invalid logType (value: ${e})`)};class Jl{constructor(e){this.name=e,this._logLevel=Ay,this._logHandler=xy,this._userLogHandler=null}get logLevel(){return this._logLevel}set logLevel(e){if(!(e in ne))throw new TypeError(`Invalid value "${e}" assigned to \`logLevel\``);this._logLevel=e}setLogLevel(e){this._logLevel=typeof e=="string"?Iy[e]:e}get logHandler(){return this._logHandler}set logHandler(e){if(typeof e!="function")throw new TypeError("Value assigned to `logHandler` must be a function");this._logHandler=e}get userLogHandler(){return this._userLogHandler}set userLogHandler(e){this._userLogHandler=e}debug(...e){this._userLogHandler&&this._userLogHandler(this,ne.DEBUG,...e),this._logHandler(this,ne.DEBUG,...e)}log(...e){this._userLogHandler&&this._userLogHandler(this,ne.VERBOSE,...e),this._logHandler(this,ne.VERBOSE,...e)}info(...e){this._userLogHandler&&this._userLogHandler(this,ne.INFO,...e),this._logHandler(this,ne.INFO,...e)}warn(...e){this._userLogHandler&&this._userLogHandler(this,ne.WARN,...e),this._logHandler(this,ne.WARN,...e)}error(...e){this._userLogHandler&&this._userLogHandler(this,ne.ERROR,...e),this._logHandler(this,ne.ERROR,...e)}}const ky=(n,e)=>e.some(t=>n instanceof t);let lh,ch;function Py(){return lh||(lh=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction])}function Cy(){return ch||(ch=[IDBCursor.prototype.advance,IDBCursor.prototype.continue,IDBCursor.prototype.continuePrimaryKey])}const hf=new WeakMap,gl=new WeakMap,df=new WeakMap,Ya=new WeakMap,Xl=new WeakMap;function Ry(n){const e=new Promise((t,r)=>{const i=()=>{n.removeEventListener("success",o),n.removeEventListener("error",s)},o=()=>{t(Mn(n.result)),i()},s=()=>{r(n.error),i()};n.addEventListener("success",o),n.addEventListener("error",s)});return e.then(t=>{t instanceof IDBCursor&&hf.set(t,n)}).catch(()=>{}),Xl.set(e,n),e}function Oy(n){if(gl.has(n))return;const e=new Promise((t,r)=>{const i=()=>{n.removeEventListener("complete",o),n.removeEventListener("error",s),n.removeEventListener("abort",s)},o=()=>{t(),i()},s=()=>{r(n.error||new DOMException("AbortError","AbortError")),i()};n.addEventListener("complete",o),n.addEventListener("error",s),n.addEventListener("abort",s)});gl.set(n,e)}let ml={get(n,e,t){if(n instanceof IDBTransaction){if(e==="done")return gl.get(n);if(e==="objectStoreNames")return n.objectStoreNames||df.get(n);if(e==="store")return t.objectStoreNames[1]?void 0:t.objectStore(t.objectStoreNames[0])}return Mn(n[e])},set(n,e,t){return n[e]=t,!0},has(n,e){return n instanceof IDBTransaction&&(e==="done"||e==="store")?!0:e in n}};function Ny(n){ml=n(ml)}function Dy(n){return n===IDBDatabase.prototype.transaction&&!("objectStoreNames"in IDBTransaction.prototype)?function(e,...t){const r=n.call(Qa(this),e,...t);return df.set(r,e.sort?e.sort():[e]),Mn(r)}:Cy().includes(n)?function(...e){return n.apply(Qa(this),e),Mn(hf.get(this))}:function(...e){return Mn(n.apply(Qa(this),e))}}function My(n){return typeof n=="function"?Dy(n):(n instanceof IDBTransaction&&Oy(n),ky(n,Py())?new Proxy(n,ml):n)}function Mn(n){if(n instanceof IDBRequest)return Ry(n);if(Ya.has(n))return Ya.get(n);const e=My(n);return e!==n&&(Ya.set(n,e),Xl.set(e,n)),e}const Qa=n=>Xl.get(n);function Ly(n,e,{blocked:t,upgrade:r,blocking:i,terminated:o}={}){const s=indexedDB.open(n,e),l=Mn(s);return r&&s.addEventListener("upgradeneeded",u=>{r(Mn(s.result),u.oldVersion,u.newVersion,Mn(s.transaction),u)}),t&&s.addEventListener("blocked",u=>t(u.oldVersion,u.newVersion,u)),l.then(u=>{o&&u.addEventListener("close",()=>o()),i&&u.addEventListener("versionchange",h=>i(h.oldVersion,h.newVersion,h))}).catch(()=>{}),l}const Vy=["get","getKey","getAll","getAllKeys","count"],Fy=["put","add","delete","clear"],Ja=new Map;function uh(n,e){if(!(n instanceof IDBDatabase&&!(e in n)&&typeof e=="string"))return;if(Ja.get(e))return Ja.get(e);const t=e.replace(/FromIndex$/,""),r=e!==t,i=Fy.includes(t);if(!(t in(r?IDBIndex:IDBObjectStore).prototype)||!(i||Vy.includes(t)))return;const o=async function(s,...l){const u=this.transaction(s,i?"readwrite":"readonly");let h=u.store;return r&&(h=h.index(l.shift())),(await Promise.all([h[t](...l),i&&u.done]))[0]};return Ja.set(e,o),o}Ny(n=>({...n,get:(e,t,r)=>uh(e,t)||n.get(e,t,r),has:(e,t)=>!!uh(e,t)||n.has(e,t)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Uy{constructor(e){this.container=e}getPlatformInfoString(){return this.container.getProviders().map(t=>{if(qy(t)){const r=t.getImmediate();return`${r.library}/${r.version}`}else return null}).filter(t=>t).join(" ")}}function qy(n){const e=n.getComponent();return(e==null?void 0:e.type)==="VERSION"}const yl="@firebase/app",hh="0.14.11";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const hn=new Jl("@firebase/app"),By="@firebase/app-compat",$y="@firebase/analytics-compat",jy="@firebase/analytics",zy="@firebase/app-check-compat",Wy="@firebase/app-check",Hy="@firebase/auth",Gy="@firebase/auth-compat",Ky="@firebase/database",Yy="@firebase/data-connect",Qy="@firebase/database-compat",Jy="@firebase/functions",Xy="@firebase/functions-compat",Zy="@firebase/installations",ev="@firebase/installations-compat",tv="@firebase/messaging",nv="@firebase/messaging-compat",rv="@firebase/performance",iv="@firebase/performance-compat",ov="@firebase/remote-config",sv="@firebase/remote-config-compat",av="@firebase/storage",lv="@firebase/storage-compat",cv="@firebase/firestore",uv="@firebase/ai",hv="@firebase/firestore-compat",dv="firebase",fv="12.12.0";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const vl="[DEFAULT]",pv={[yl]:"fire-core",[By]:"fire-core-compat",[jy]:"fire-analytics",[$y]:"fire-analytics-compat",[Wy]:"fire-app-check",[zy]:"fire-app-check-compat",[Hy]:"fire-auth",[Gy]:"fire-auth-compat",[Ky]:"fire-rtdb",[Yy]:"fire-data-connect",[Qy]:"fire-rtdb-compat",[Jy]:"fire-fn",[Xy]:"fire-fn-compat",[Zy]:"fire-iid",[ev]:"fire-iid-compat",[tv]:"fire-fcm",[nv]:"fire-fcm-compat",[rv]:"fire-perf",[iv]:"fire-perf-compat",[ov]:"fire-rc",[sv]:"fire-rc-compat",[av]:"fire-gcs",[lv]:"fire-gcs-compat",[cv]:"fire-fst",[hv]:"fire-fst-compat",[uv]:"fire-vertex","fire-js":"fire-js",[dv]:"fire-js-all"};/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const fo=new Map,gv=new Map,_l=new Map;function dh(n,e){try{n.container.addComponent(e)}catch(t){hn.debug(`Component ${e.name} failed to register with FirebaseApp ${n.name}`,t)}}function ni(n){const e=n.name;if(_l.has(e))return hn.debug(`There were multiple attempts to register component ${e}.`),!1;_l.set(e,n);for(const t of fo.values())dh(t,n);for(const t of gv.values())dh(t,n);return!0}function Zl(n,e){const t=n.container.getProvider("heartbeat").getImmediate({optional:!0});return t&&t.triggerHeartbeat(),n.container.getProvider(e)}function Lt(n){return n==null?!1:n.settings!==void 0}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const mv={"no-app":"No Firebase App '{$appName}' has been created - call initializeApp() first","bad-app-name":"Illegal App name: '{$appName}'","duplicate-app":"Firebase App named '{$appName}' already exists with different options or config","app-deleted":"Firebase App named '{$appName}' already deleted","server-app-deleted":"Firebase Server App has been deleted","no-options":"Need to provide options, when not being deployed to hosting via source.","invalid-app-argument":"firebase.{$appName}() takes either no argument or a Firebase App instance.","invalid-log-argument":"First argument to `onLog` must be null or a function.","idb-open":"Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.","idb-get":"Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.","idb-set":"Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.","idb-delete":"Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}.","finalization-registry-not-supported":"FirebaseServerApp deleteOnDeref field defined but the JS runtime does not support FinalizationRegistry.","invalid-server-app-environment":"FirebaseServerApp is not for use in browser environments."},Ln=new Oo("app","Firebase",mv);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class yv{constructor(e,t,r){this._isDeleted=!1,this._options={...e},this._config={...t},this._name=t.name,this._automaticDataCollectionEnabled=t.automaticDataCollectionEnabled,this._container=r,this.container.addComponent(new yr("app",()=>this,"PUBLIC"))}get automaticDataCollectionEnabled(){return this.checkDestroyed(),this._automaticDataCollectionEnabled}set automaticDataCollectionEnabled(e){this.checkDestroyed(),this._automaticDataCollectionEnabled=e}get name(){return this.checkDestroyed(),this._name}get options(){return this.checkDestroyed(),this._options}get config(){return this.checkDestroyed(),this._config}get container(){return this._container}get isDeleted(){return this._isDeleted}set isDeleted(e){this._isDeleted=e}checkDestroyed(){if(this.isDeleted)throw Ln.create("app-deleted",{appName:this._name})}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const mi=fv;function ec(n,e={}){let t=n;typeof e!="object"&&(e={name:e});const r={name:vl,automaticDataCollectionEnabled:!0,...e},i=r.name;if(typeof i!="string"||!i)throw Ln.create("bad-app-name",{appName:String(i)});if(t||(t=lf()),!t)throw Ln.create("no-options");const o=fo.get(i);if(o){if(mr(t,o.options)&&mr(r,o.config))return o;throw Ln.create("duplicate-app",{appName:i})}const s=new Ey(i);for(const u of _l.values())s.addComponent(u);const l=new yv(t,r,s);return fo.set(i,l),l}function ff(n=vl){const e=fo.get(n);if(!e&&n===vl&&lf())return ec();if(!e)throw Ln.create("no-app",{appName:n});return e}function Ds(){return Array.from(fo.values())}function Vn(n,e,t){let r=pv[n]??n;t&&(r+=`-${t}`);const i=r.match(/\s|\//),o=e.match(/\s|\//);if(i||o){const s=[`Unable to register library "${r}" with version "${e}":`];i&&s.push(`library name "${r}" contains illegal characters (whitespace or "/")`),i&&o&&s.push("and"),o&&s.push(`version name "${e}" contains illegal characters (whitespace or "/")`),hn.warn(s.join(" "));return}ni(new yr(`${r}-version`,()=>({library:r,version:e}),"VERSION"))}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const vv="firebase-heartbeat-database",_v=1,po="firebase-heartbeat-store";let Xa=null;function pf(){return Xa||(Xa=Ly(vv,_v,{upgrade:(n,e)=>{switch(e){case 0:try{n.createObjectStore(po)}catch(t){console.warn(t)}}}}).catch(n=>{throw Ln.create("idb-open",{originalErrorMessage:n.message})})),Xa}async function wv(n){try{const t=(await pf()).transaction(po),r=await t.objectStore(po).get(gf(n));return await t.done,r}catch(e){if(e instanceof yn)hn.warn(e.message);else{const t=Ln.create("idb-get",{originalErrorMessage:e==null?void 0:e.message});hn.warn(t.message)}}}async function fh(n,e){try{const r=(await pf()).transaction(po,"readwrite");await r.objectStore(po).put(e,gf(n)),await r.done}catch(t){if(t instanceof yn)hn.warn(t.message);else{const r=Ln.create("idb-set",{originalErrorMessage:t==null?void 0:t.message});hn.warn(r.message)}}}function gf(n){return`${n.name}!${n.options.appId}`}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const bv=1024,Tv=30;class Ev{constructor(e){this.container=e,this._heartbeatsCache=null;const t=this.container.getProvider("app").getImmediate();this._storage=new Av(t),this._heartbeatsCachePromise=this._storage.read().then(r=>(this._heartbeatsCache=r,r))}async triggerHeartbeat(){var e,t;try{const i=this.container.getProvider("platform-logger").getImmediate().getPlatformInfoString(),o=ph();if(((e=this._heartbeatsCache)==null?void 0:e.heartbeats)==null&&(this._heartbeatsCache=await this._heartbeatsCachePromise,((t=this._heartbeatsCache)==null?void 0:t.heartbeats)==null)||this._heartbeatsCache.lastSentHeartbeatDate===o||this._heartbeatsCache.heartbeats.some(s=>s.date===o))return;if(this._heartbeatsCache.heartbeats.push({date:o,agent:i}),this._heartbeatsCache.heartbeats.length>Tv){const s=Sv(this._heartbeatsCache.heartbeats);this._heartbeatsCache.heartbeats.splice(s,1)}return this._storage.overwrite(this._heartbeatsCache)}catch(r){hn.warn(r)}}async getHeartbeatsHeader(){var e;try{if(this._heartbeatsCache===null&&await this._heartbeatsCachePromise,((e=this._heartbeatsCache)==null?void 0:e.heartbeats)==null||this._heartbeatsCache.heartbeats.length===0)return"";const t=ph(),{heartbeatsToSend:r,unsentEntries:i}=Iv(this._heartbeatsCache.heartbeats),o=Ns(JSON.stringify({version:2,heartbeats:r}));return this._heartbeatsCache.lastSentHeartbeatDate=t,i.length>0?(this._heartbeatsCache.heartbeats=i,await this._storage.overwrite(this._heartbeatsCache)):(this._heartbeatsCache.heartbeats=[],this._storage.overwrite(this._heartbeatsCache)),o}catch(t){return hn.warn(t),""}}}function ph(){return new Date().toISOString().substring(0,10)}function Iv(n,e=bv){const t=[];let r=n.slice();for(const i of n){const o=t.find(s=>s.agent===i.agent);if(o){if(o.dates.push(i.date),gh(t)>e){o.dates.pop();break}}else if(t.push({agent:i.agent,dates:[i.date]}),gh(t)>e){t.pop();break}r=r.slice(1)}return{heartbeatsToSend:t,unsentEntries:r}}class Av{constructor(e){this.app=e,this._canUseIndexedDBPromise=this.runIndexedDBEnvironmentCheck()}async runIndexedDBEnvironmentCheck(){return hy()?dy().then(()=>!0).catch(()=>!1):!1}async read(){if(await this._canUseIndexedDBPromise){const t=await wv(this.app);return t!=null&&t.heartbeats?t:{heartbeats:[]}}else return{heartbeats:[]}}async overwrite(e){if(await this._canUseIndexedDBPromise){const r=await this.read();return fh(this.app,{lastSentHeartbeatDate:e.lastSentHeartbeatDate??r.lastSentHeartbeatDate,heartbeats:e.heartbeats})}else return}async add(e){if(await this._canUseIndexedDBPromise){const r=await this.read();return fh(this.app,{lastSentHeartbeatDate:e.lastSentHeartbeatDate??r.lastSentHeartbeatDate,heartbeats:[...r.heartbeats,...e.heartbeats]})}else return}}function gh(n){return Ns(JSON.stringify({version:2,heartbeats:n})).length}function Sv(n){if(n.length===0)return-1;let e=0,t=n[0].date;for(let r=1;r<n.length;r++)n[r].date<t&&(t=n[r].date,e=r);return e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function xv(n){ni(new yr("platform-logger",e=>new Uy(e),"PRIVATE")),ni(new yr("heartbeat",e=>new Ev(e),"PRIVATE")),Vn(yl,hh,n),Vn(yl,hh,"esm2020"),Vn("fire-js","")}xv("");var kv="firebase",Pv="12.12.1";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */Vn(kv,Pv,"app");function mf(){return{"dependent-sdk-initialized-before-auth":"Another Firebase SDK was initialized and is trying to use Auth before Auth is initialized. Please be sure to call `initializeAuth` or `getAuth` before starting any other Firebase SDK."}}const Cv=mf,yf=new Oo("auth","Firebase",mf());/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ms=new Jl("@firebase/auth");function Rv(n,...e){Ms.logLevel<=ne.WARN&&Ms.warn(`Auth (${mi}): ${n}`,...e)}function _s(n,...e){Ms.logLevel<=ne.ERROR&&Ms.error(`Auth (${mi}): ${n}`,...e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function dn(n,...e){throw tc(n,...e)}function Bt(n,...e){return tc(n,...e)}function vf(n,e,t){const r={...Cv(),[e]:t};return new Oo("auth","Firebase",r).create(e,{appName:n.name})}function hr(n){return vf(n,"operation-not-supported-in-this-environment","Operations that alter the current user are not supported in conjunction with FirebaseServerApp")}function tc(n,...e){if(typeof n!="string"){const t=e[0],r=[...e.slice(1)];return r[0]&&(r[0].appName=n.name),n._errorFactory.create(t,...r)}return yf.create(n,...e)}function Q(n,e,...t){if(!n)throw tc(e,...t)}function nn(n){const e="INTERNAL ASSERTION FAILED: "+n;throw _s(e),new Error(e)}function fn(n,e){n||nn(e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function wl(){var n;return typeof self<"u"&&((n=self.location)==null?void 0:n.href)||""}function Ov(){return mh()==="http:"||mh()==="https:"}function mh(){var n;return typeof self<"u"&&((n=self.location)==null?void 0:n.protocol)||null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Nv(){return typeof navigator<"u"&&navigator&&"onLine"in navigator&&typeof navigator.onLine=="boolean"&&(Ov()||ay()||"connection"in navigator)?navigator.onLine:!0}function Dv(){if(typeof navigator>"u")return null;const n=navigator;return n.languages&&n.languages[0]||n.language||null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Mo{constructor(e,t){this.shortDelay=e,this.longDelay=t,fn(t>e,"Short delay should be less than long delay!"),this.isMobile=iy()||ly()}get(){return Nv()?this.isMobile?this.longDelay:this.shortDelay:Math.min(5e3,this.shortDelay)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function nc(n,e){fn(n.emulator,"Emulator should always be set here");const{url:t}=n.emulator;return e?`${t}${e.startsWith("/")?e.slice(1):e}`:t}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _f{static initialize(e,t,r){this.fetchImpl=e,t&&(this.headersImpl=t),r&&(this.responseImpl=r)}static fetch(){if(this.fetchImpl)return this.fetchImpl;if(typeof self<"u"&&"fetch"in self)return self.fetch;if(typeof globalThis<"u"&&globalThis.fetch)return globalThis.fetch;if(typeof fetch<"u")return fetch;nn("Could not find fetch implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static headers(){if(this.headersImpl)return this.headersImpl;if(typeof self<"u"&&"Headers"in self)return self.Headers;if(typeof globalThis<"u"&&globalThis.Headers)return globalThis.Headers;if(typeof Headers<"u")return Headers;nn("Could not find Headers implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static response(){if(this.responseImpl)return this.responseImpl;if(typeof self<"u"&&"Response"in self)return self.Response;if(typeof globalThis<"u"&&globalThis.Response)return globalThis.Response;if(typeof Response<"u")return Response;nn("Could not find Response implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Mv={CREDENTIAL_MISMATCH:"custom-token-mismatch",MISSING_CUSTOM_TOKEN:"internal-error",INVALID_IDENTIFIER:"invalid-email",MISSING_CONTINUE_URI:"internal-error",INVALID_PASSWORD:"wrong-password",MISSING_PASSWORD:"missing-password",INVALID_LOGIN_CREDENTIALS:"invalid-credential",EMAIL_EXISTS:"email-already-in-use",PASSWORD_LOGIN_DISABLED:"operation-not-allowed",INVALID_IDP_RESPONSE:"invalid-credential",INVALID_PENDING_TOKEN:"invalid-credential",FEDERATED_USER_ID_ALREADY_LINKED:"credential-already-in-use",MISSING_REQ_TYPE:"internal-error",EMAIL_NOT_FOUND:"user-not-found",RESET_PASSWORD_EXCEED_LIMIT:"too-many-requests",EXPIRED_OOB_CODE:"expired-action-code",INVALID_OOB_CODE:"invalid-action-code",MISSING_OOB_CODE:"internal-error",CREDENTIAL_TOO_OLD_LOGIN_AGAIN:"requires-recent-login",INVALID_ID_TOKEN:"invalid-user-token",TOKEN_EXPIRED:"user-token-expired",USER_NOT_FOUND:"user-token-expired",TOO_MANY_ATTEMPTS_TRY_LATER:"too-many-requests",PASSWORD_DOES_NOT_MEET_REQUIREMENTS:"password-does-not-meet-requirements",INVALID_CODE:"invalid-verification-code",INVALID_SESSION_INFO:"invalid-verification-id",INVALID_TEMPORARY_PROOF:"invalid-credential",MISSING_SESSION_INFO:"missing-verification-id",SESSION_EXPIRED:"code-expired",MISSING_ANDROID_PACKAGE_NAME:"missing-android-pkg-name",UNAUTHORIZED_DOMAIN:"unauthorized-continue-uri",INVALID_OAUTH_CLIENT_ID:"invalid-oauth-client-id",ADMIN_ONLY_OPERATION:"admin-restricted-operation",INVALID_MFA_PENDING_CREDENTIAL:"invalid-multi-factor-session",MFA_ENROLLMENT_NOT_FOUND:"multi-factor-info-not-found",MISSING_MFA_ENROLLMENT_ID:"missing-multi-factor-info",MISSING_MFA_PENDING_CREDENTIAL:"missing-multi-factor-session",SECOND_FACTOR_EXISTS:"second-factor-already-in-use",SECOND_FACTOR_LIMIT_EXCEEDED:"maximum-second-factor-count-exceeded",BLOCKING_FUNCTION_ERROR_RESPONSE:"internal-error",RECAPTCHA_NOT_ENABLED:"recaptcha-not-enabled",MISSING_RECAPTCHA_TOKEN:"missing-recaptcha-token",INVALID_RECAPTCHA_TOKEN:"invalid-recaptcha-token",INVALID_RECAPTCHA_ACTION:"invalid-recaptcha-action",MISSING_CLIENT_TYPE:"missing-client-type",MISSING_RECAPTCHA_VERSION:"missing-recaptcha-version",INVALID_RECAPTCHA_VERSION:"invalid-recaptcha-version",INVALID_REQ_TYPE:"invalid-req-type"};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Lv=["/v1/accounts:signInWithCustomToken","/v1/accounts:signInWithEmailLink","/v1/accounts:signInWithIdp","/v1/accounts:signInWithPassword","/v1/accounts:signInWithPhoneNumber","/v1/token"],Vv=new Mo(3e4,6e4);function rc(n,e){return n.tenantId&&!e.tenantId?{...e,tenantId:n.tenantId}:e}async function yi(n,e,t,r,i={}){return wf(n,i,async()=>{let o={},s={};r&&(e==="GET"?s=r:o={body:JSON.stringify(r)});const l=No({key:n.config.apiKey,...s}).slice(1),u=await n._getAdditionalHeaders();u["Content-Type"]="application/json",n.languageCode&&(u["X-Firebase-Locale"]=n.languageCode);const h={method:e,headers:u,...o};return sy()||(h.referrerPolicy="no-referrer"),n.emulatorConfig&&Do(n.emulatorConfig.host)&&(h.credentials="include"),_f.fetch()(await bf(n,n.config.apiHost,t,l),h)})}async function wf(n,e,t){n._canInitEmulator=!1;const r={...Mv,...e};try{const i=new Uv(n),o=await Promise.race([t(),i.promise]);i.clearNetworkTimeout();const s=await o.json();if("needConfirmation"in s)throw os(n,"account-exists-with-different-credential",s);if(o.ok&&!("errorMessage"in s))return s;{const l=o.ok?s.errorMessage:s.error.message,[u,h]=l.split(" : ");if(u==="FEDERATED_USER_ID_ALREADY_LINKED")throw os(n,"credential-already-in-use",s);if(u==="EMAIL_EXISTS")throw os(n,"email-already-in-use",s);if(u==="USER_DISABLED")throw os(n,"user-disabled",s);const p=r[u]||u.toLowerCase().replace(/[_\s]+/g,"-");if(h)throw vf(n,p,h);dn(n,p)}}catch(i){if(i instanceof yn)throw i;dn(n,"network-request-failed",{message:String(i)})}}async function Fv(n,e,t,r,i={}){const o=await yi(n,e,t,r,i);return"mfaPendingCredential"in o&&dn(n,"multi-factor-auth-required",{_serverResponse:o}),o}async function bf(n,e,t,r){const i=`${e}${t}?${r}`,o=n,s=o.config.emulator?nc(n.config,i):`${n.config.apiScheme}://${i}`;return Lv.includes(t)&&(await o._persistenceManagerAvailable,o._getPersistenceType()==="COOKIE")?o._getPersistence()._getFinalTarget(s).toString():s}class Uv{clearNetworkTimeout(){clearTimeout(this.timer)}constructor(e){this.auth=e,this.timer=null,this.promise=new Promise((t,r)=>{this.timer=setTimeout(()=>r(Bt(this.auth,"network-request-failed")),Vv.get())})}}function os(n,e,t){const r={appName:n.name};t.email&&(r.email=t.email),t.phoneNumber&&(r.phoneNumber=t.phoneNumber);const i=Bt(n,e,r);return i.customData._tokenResponse=t,i}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function qv(n,e){return yi(n,"POST","/v1/accounts:delete",e)}async function Ls(n,e){return yi(n,"POST","/v1/accounts:lookup",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ro(n){if(n)try{const e=new Date(Number(n));if(!isNaN(e.getTime()))return e.toUTCString()}catch{}}async function Bv(n,e=!1){const t=Be(n),r=await t.getIdToken(e),i=ic(r);Q(i&&i.exp&&i.auth_time&&i.iat,t.auth,"internal-error");const o=typeof i.firebase=="object"?i.firebase:void 0,s=o==null?void 0:o.sign_in_provider;return{claims:i,token:r,authTime:ro(Za(i.auth_time)),issuedAtTime:ro(Za(i.iat)),expirationTime:ro(Za(i.exp)),signInProvider:s||null,signInSecondFactor:(o==null?void 0:o.sign_in_second_factor)||null}}function Za(n){return Number(n)*1e3}function ic(n){const[e,t,r]=n.split(".");if(e===void 0||t===void 0||r===void 0)return _s("JWT malformed, contained fewer than 3 sections"),null;try{const i=sf(t);return i?JSON.parse(i):(_s("Failed to decode base64 JWT payload"),null)}catch(i){return _s("Caught error parsing JWT payload as JSON",i==null?void 0:i.toString()),null}}function yh(n){const e=ic(n);return Q(e,"internal-error"),Q(typeof e.exp<"u","internal-error"),Q(typeof e.iat<"u","internal-error"),Number(e.exp)-Number(e.iat)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function go(n,e,t=!1){if(t)return e;try{return await e}catch(r){throw r instanceof yn&&$v(r)&&n.auth.currentUser===n&&await n.auth.signOut(),r}}function $v({code:n}){return n==="auth/user-disabled"||n==="auth/user-token-expired"}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class jv{constructor(e){this.user=e,this.isRunning=!1,this.timerId=null,this.errorBackoff=3e4}_start(){this.isRunning||(this.isRunning=!0,this.schedule())}_stop(){this.isRunning&&(this.isRunning=!1,this.timerId!==null&&clearTimeout(this.timerId))}getInterval(e){if(e){const t=this.errorBackoff;return this.errorBackoff=Math.min(this.errorBackoff*2,96e4),t}else{this.errorBackoff=3e4;const r=(this.user.stsTokenManager.expirationTime??0)-Date.now()-3e5;return Math.max(0,r)}}schedule(e=!1){if(!this.isRunning)return;const t=this.getInterval(e);this.timerId=setTimeout(async()=>{await this.iteration()},t)}async iteration(){try{await this.user.getIdToken(!0)}catch(e){(e==null?void 0:e.code)==="auth/network-request-failed"&&this.schedule(!0);return}this.schedule()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class bl{constructor(e,t){this.createdAt=e,this.lastLoginAt=t,this._initializeTime()}_initializeTime(){this.lastSignInTime=ro(this.lastLoginAt),this.creationTime=ro(this.createdAt)}_copy(e){this.createdAt=e.createdAt,this.lastLoginAt=e.lastLoginAt,this._initializeTime()}toJSON(){return{createdAt:this.createdAt,lastLoginAt:this.lastLoginAt}}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Vs(n){var m;const e=n.auth,t=await n.getIdToken(),r=await go(n,Ls(e,{idToken:t}));Q(r==null?void 0:r.users.length,e,"internal-error");const i=r.users[0];n._notifyReloadListener(i);const o=(m=i.providerUserInfo)!=null&&m.length?Tf(i.providerUserInfo):[],s=Wv(n.providerData,o),l=n.isAnonymous,u=!(n.email&&i.passwordHash)&&!(s!=null&&s.length),h=l?u:!1,p={uid:i.localId,displayName:i.displayName||null,photoURL:i.photoUrl||null,email:i.email||null,emailVerified:i.emailVerified||!1,phoneNumber:i.phoneNumber||null,tenantId:i.tenantId||null,providerData:s,metadata:new bl(i.createdAt,i.lastLoginAt),isAnonymous:h};Object.assign(n,p)}async function zv(n){const e=Be(n);await Vs(e),await e.auth._persistUserIfCurrent(e),e.auth._notifyListenersIfCurrent(e)}function Wv(n,e){return[...n.filter(r=>!e.some(i=>i.providerId===r.providerId)),...e]}function Tf(n){return n.map(({providerId:e,...t})=>({providerId:e,uid:t.rawId||"",displayName:t.displayName||null,email:t.email||null,phoneNumber:t.phoneNumber||null,photoURL:t.photoUrl||null}))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Hv(n,e){const t=await wf(n,{},async()=>{const r=No({grant_type:"refresh_token",refresh_token:e}).slice(1),{tokenApiHost:i,apiKey:o}=n.config,s=await bf(n,i,"/v1/token",`key=${o}`),l=await n._getAdditionalHeaders();l["Content-Type"]="application/x-www-form-urlencoded";const u={method:"POST",headers:l,body:r};return n.emulatorConfig&&Do(n.emulatorConfig.host)&&(u.credentials="include"),_f.fetch()(s,u)});return{accessToken:t.access_token,expiresIn:t.expires_in,refreshToken:t.refresh_token}}async function Gv(n,e){return yi(n,"POST","/v2/accounts:revokeToken",rc(n,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class $r{constructor(){this.refreshToken=null,this.accessToken=null,this.expirationTime=null}get isExpired(){return!this.expirationTime||Date.now()>this.expirationTime-3e4}updateFromServerResponse(e){Q(e.idToken,"internal-error"),Q(typeof e.idToken<"u","internal-error"),Q(typeof e.refreshToken<"u","internal-error");const t="expiresIn"in e&&typeof e.expiresIn<"u"?Number(e.expiresIn):yh(e.idToken);this.updateTokensAndExpiration(e.idToken,e.refreshToken,t)}updateFromIdToken(e){Q(e.length!==0,"internal-error");const t=yh(e);this.updateTokensAndExpiration(e,null,t)}async getToken(e,t=!1){return!t&&this.accessToken&&!this.isExpired?this.accessToken:(Q(this.refreshToken,e,"user-token-expired"),this.refreshToken?(await this.refresh(e,this.refreshToken),this.accessToken):null)}clearRefreshToken(){this.refreshToken=null}async refresh(e,t){const{accessToken:r,refreshToken:i,expiresIn:o}=await Hv(e,t);this.updateTokensAndExpiration(r,i,Number(o))}updateTokensAndExpiration(e,t,r){this.refreshToken=t||null,this.accessToken=e||null,this.expirationTime=Date.now()+r*1e3}static fromJSON(e,t){const{refreshToken:r,accessToken:i,expirationTime:o}=t,s=new $r;return r&&(Q(typeof r=="string","internal-error",{appName:e}),s.refreshToken=r),i&&(Q(typeof i=="string","internal-error",{appName:e}),s.accessToken=i),o&&(Q(typeof o=="number","internal-error",{appName:e}),s.expirationTime=o),s}toJSON(){return{refreshToken:this.refreshToken,accessToken:this.accessToken,expirationTime:this.expirationTime}}_assign(e){this.accessToken=e.accessToken,this.refreshToken=e.refreshToken,this.expirationTime=e.expirationTime}_clone(){return Object.assign(new $r,this.toJSON())}_performRefresh(){return nn("not implemented")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Sn(n,e){Q(typeof n=="string"||typeof n>"u","internal-error",{appName:e})}class Et{constructor({uid:e,auth:t,stsTokenManager:r,...i}){this.providerId="firebase",this.proactiveRefresh=new jv(this),this.reloadUserInfo=null,this.reloadListener=null,this.uid=e,this.auth=t,this.stsTokenManager=r,this.accessToken=r.accessToken,this.displayName=i.displayName||null,this.email=i.email||null,this.emailVerified=i.emailVerified||!1,this.phoneNumber=i.phoneNumber||null,this.photoURL=i.photoURL||null,this.isAnonymous=i.isAnonymous||!1,this.tenantId=i.tenantId||null,this.providerData=i.providerData?[...i.providerData]:[],this.metadata=new bl(i.createdAt||void 0,i.lastLoginAt||void 0)}async getIdToken(e){const t=await go(this,this.stsTokenManager.getToken(this.auth,e));return Q(t,this.auth,"internal-error"),this.accessToken!==t&&(this.accessToken=t,await this.auth._persistUserIfCurrent(this),this.auth._notifyListenersIfCurrent(this)),t}getIdTokenResult(e){return Bv(this,e)}reload(){return zv(this)}_assign(e){this!==e&&(Q(this.uid===e.uid,this.auth,"internal-error"),this.displayName=e.displayName,this.photoURL=e.photoURL,this.email=e.email,this.emailVerified=e.emailVerified,this.phoneNumber=e.phoneNumber,this.isAnonymous=e.isAnonymous,this.tenantId=e.tenantId,this.providerData=e.providerData.map(t=>({...t})),this.metadata._copy(e.metadata),this.stsTokenManager._assign(e.stsTokenManager))}_clone(e){const t=new Et({...this,auth:e,stsTokenManager:this.stsTokenManager._clone()});return t.metadata._copy(this.metadata),t}_onReload(e){Q(!this.reloadListener,this.auth,"internal-error"),this.reloadListener=e,this.reloadUserInfo&&(this._notifyReloadListener(this.reloadUserInfo),this.reloadUserInfo=null)}_notifyReloadListener(e){this.reloadListener?this.reloadListener(e):this.reloadUserInfo=e}_startProactiveRefresh(){this.proactiveRefresh._start()}_stopProactiveRefresh(){this.proactiveRefresh._stop()}async _updateTokensIfNecessary(e,t=!1){let r=!1;e.idToken&&e.idToken!==this.stsTokenManager.accessToken&&(this.stsTokenManager.updateFromServerResponse(e),r=!0),t&&await Vs(this),await this.auth._persistUserIfCurrent(this),r&&this.auth._notifyListenersIfCurrent(this)}async delete(){if(Lt(this.auth.app))return Promise.reject(hr(this.auth));const e=await this.getIdToken();return await go(this,qv(this.auth,{idToken:e})),this.stsTokenManager.clearRefreshToken(),this.auth.signOut()}toJSON(){return{uid:this.uid,email:this.email||void 0,emailVerified:this.emailVerified,displayName:this.displayName||void 0,isAnonymous:this.isAnonymous,photoURL:this.photoURL||void 0,phoneNumber:this.phoneNumber||void 0,tenantId:this.tenantId||void 0,providerData:this.providerData.map(e=>({...e})),stsTokenManager:this.stsTokenManager.toJSON(),_redirectEventId:this._redirectEventId,...this.metadata.toJSON(),apiKey:this.auth.config.apiKey,appName:this.auth.name}}get refreshToken(){return this.stsTokenManager.refreshToken||""}static _fromJSON(e,t){const r=t.displayName??void 0,i=t.email??void 0,o=t.phoneNumber??void 0,s=t.photoURL??void 0,l=t.tenantId??void 0,u=t._redirectEventId??void 0,h=t.createdAt??void 0,p=t.lastLoginAt??void 0,{uid:m,emailVerified:g,isAnonymous:b,providerData:P,stsTokenManager:A}=t;Q(m&&A,e,"internal-error");const C=$r.fromJSON(this.name,A);Q(typeof m=="string",e,"internal-error"),Sn(r,e.name),Sn(i,e.name),Q(typeof g=="boolean",e,"internal-error"),Q(typeof b=="boolean",e,"internal-error"),Sn(o,e.name),Sn(s,e.name),Sn(l,e.name),Sn(u,e.name),Sn(h,e.name),Sn(p,e.name);const $=new Et({uid:m,auth:e,email:i,emailVerified:g,displayName:r,isAnonymous:b,photoURL:s,phoneNumber:o,tenantId:l,stsTokenManager:C,createdAt:h,lastLoginAt:p});return P&&Array.isArray(P)&&($.providerData=P.map(F=>({...F}))),u&&($._redirectEventId=u),$}static async _fromIdTokenResponse(e,t,r=!1){const i=new $r;i.updateFromServerResponse(t);const o=new Et({uid:t.localId,auth:e,stsTokenManager:i,isAnonymous:r});return await Vs(o),o}static async _fromGetAccountInfoResponse(e,t,r){const i=t.users[0];Q(i.localId!==void 0,"internal-error");const o=i.providerUserInfo!==void 0?Tf(i.providerUserInfo):[],s=!(i.email&&i.passwordHash)&&!(o!=null&&o.length),l=new $r;l.updateFromIdToken(r);const u=new Et({uid:i.localId,auth:e,stsTokenManager:l,isAnonymous:s}),h={uid:i.localId,displayName:i.displayName||null,photoURL:i.photoUrl||null,email:i.email||null,emailVerified:i.emailVerified||!1,phoneNumber:i.phoneNumber||null,tenantId:i.tenantId||null,providerData:o,metadata:new bl(i.createdAt,i.lastLoginAt),isAnonymous:!(i.email&&i.passwordHash)&&!(o!=null&&o.length)};return Object.assign(u,h),u}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const vh=new Map;function rn(n){fn(n instanceof Function,"Expected a class definition");let e=vh.get(n);return e?(fn(e instanceof n,"Instance stored in cache mismatched with class"),e):(e=new n,vh.set(n,e),e)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ef{constructor(){this.type="NONE",this.storage={}}async _isAvailable(){return!0}async _set(e,t){this.storage[e]=t}async _get(e){const t=this.storage[e];return t===void 0?null:t}async _remove(e){delete this.storage[e]}_addListener(e,t){}_removeListener(e,t){}}Ef.type="NONE";const _h=Ef;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ws(n,e,t){return`firebase:${n}:${e}:${t}`}class jr{constructor(e,t,r){this.persistence=e,this.auth=t,this.userKey=r;const{config:i,name:o}=this.auth;this.fullUserKey=ws(this.userKey,i.apiKey,o),this.fullPersistenceKey=ws("persistence",i.apiKey,o),this.boundEventHandler=t._onStorageEvent.bind(t),this.persistence._addListener(this.fullUserKey,this.boundEventHandler)}setCurrentUser(e){return this.persistence._set(this.fullUserKey,e.toJSON())}async getCurrentUser(){const e=await this.persistence._get(this.fullUserKey);if(!e)return null;if(typeof e=="string"){const t=await Ls(this.auth,{idToken:e}).catch(()=>{});return t?Et._fromGetAccountInfoResponse(this.auth,t,e):null}return Et._fromJSON(this.auth,e)}removeCurrentUser(){return this.persistence._remove(this.fullUserKey)}savePersistenceForRedirect(){return this.persistence._set(this.fullPersistenceKey,this.persistence.type)}async setPersistence(e){if(this.persistence===e)return;const t=await this.getCurrentUser();if(await this.removeCurrentUser(),this.persistence=e,t)return this.setCurrentUser(t)}delete(){this.persistence._removeListener(this.fullUserKey,this.boundEventHandler)}static async create(e,t,r="authUser"){if(!t.length)return new jr(rn(_h),e,r);const i=(await Promise.all(t.map(async h=>{if(await h._isAvailable())return h}))).filter(h=>h);let o=i[0]||rn(_h);const s=ws(r,e.config.apiKey,e.name);let l=null;for(const h of t)try{const p=await h._get(s);if(p){let m;if(typeof p=="string"){const g=await Ls(e,{idToken:p}).catch(()=>{});if(!g)break;m=await Et._fromGetAccountInfoResponse(e,g,p)}else m=Et._fromJSON(e,p);h!==o&&(l=m),o=h;break}}catch{}const u=i.filter(h=>h._shouldAllowMigration);return!o._shouldAllowMigration||!u.length?new jr(o,e,r):(o=u[0],l&&await o._set(s,l.toJSON()),await Promise.all(t.map(async h=>{if(h!==o)try{await h._remove(s)}catch{}})),new jr(o,e,r))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function wh(n){const e=n.toLowerCase();if(e.includes("opera/")||e.includes("opr/")||e.includes("opios/"))return"Opera";if(xf(e))return"IEMobile";if(e.includes("msie")||e.includes("trident/"))return"IE";if(e.includes("edge/"))return"Edge";if(If(e))return"Firefox";if(e.includes("silk/"))return"Silk";if(Pf(e))return"Blackberry";if(Cf(e))return"Webos";if(Af(e))return"Safari";if((e.includes("chrome/")||Sf(e))&&!e.includes("edge/"))return"Chrome";if(kf(e))return"Android";{const t=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,r=n.match(t);if((r==null?void 0:r.length)===2)return r[1]}return"Other"}function If(n=Qe()){return/firefox\//i.test(n)}function Af(n=Qe()){const e=n.toLowerCase();return e.includes("safari/")&&!e.includes("chrome/")&&!e.includes("crios/")&&!e.includes("android")}function Sf(n=Qe()){return/crios\//i.test(n)}function xf(n=Qe()){return/iemobile/i.test(n)}function kf(n=Qe()){return/android/i.test(n)}function Pf(n=Qe()){return/blackberry/i.test(n)}function Cf(n=Qe()){return/webos/i.test(n)}function oc(n=Qe()){return/iphone|ipad|ipod/i.test(n)||/macintosh/i.test(n)&&/mobile/i.test(n)}function Kv(n=Qe()){var e;return oc(n)&&!!((e=window.navigator)!=null&&e.standalone)}function Yv(){return cy()&&document.documentMode===10}function Rf(n=Qe()){return oc(n)||kf(n)||Cf(n)||Pf(n)||/windows phone/i.test(n)||xf(n)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Of(n,e=[]){let t;switch(n){case"Browser":t=wh(Qe());break;case"Worker":t=`${wh(Qe())}-${n}`;break;default:t=n}const r=e.length?e.join(","):"FirebaseCore-web";return`${t}/JsCore/${mi}/${r}`}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Qv{constructor(e){this.auth=e,this.queue=[]}pushCallback(e,t){const r=o=>new Promise((s,l)=>{try{const u=e(o);s(u)}catch(u){l(u)}});r.onAbort=t,this.queue.push(r);const i=this.queue.length-1;return()=>{this.queue[i]=()=>Promise.resolve()}}async runMiddleware(e){if(this.auth.currentUser===e)return;const t=[];try{for(const r of this.queue)await r(e),r.onAbort&&t.push(r.onAbort)}catch(r){t.reverse();for(const i of t)try{i()}catch{}throw this.auth._errorFactory.create("login-blocked",{originalMessage:r==null?void 0:r.message})}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Jv(n,e={}){return yi(n,"GET","/v2/passwordPolicy",rc(n,e))}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Xv=6;class Zv{constructor(e){var r;const t=e.customStrengthOptions;this.customStrengthOptions={},this.customStrengthOptions.minPasswordLength=t.minPasswordLength??Xv,t.maxPasswordLength&&(this.customStrengthOptions.maxPasswordLength=t.maxPasswordLength),t.containsLowercaseCharacter!==void 0&&(this.customStrengthOptions.containsLowercaseLetter=t.containsLowercaseCharacter),t.containsUppercaseCharacter!==void 0&&(this.customStrengthOptions.containsUppercaseLetter=t.containsUppercaseCharacter),t.containsNumericCharacter!==void 0&&(this.customStrengthOptions.containsNumericCharacter=t.containsNumericCharacter),t.containsNonAlphanumericCharacter!==void 0&&(this.customStrengthOptions.containsNonAlphanumericCharacter=t.containsNonAlphanumericCharacter),this.enforcementState=e.enforcementState,this.enforcementState==="ENFORCEMENT_STATE_UNSPECIFIED"&&(this.enforcementState="OFF"),this.allowedNonAlphanumericCharacters=((r=e.allowedNonAlphanumericCharacters)==null?void 0:r.join(""))??"",this.forceUpgradeOnSignin=e.forceUpgradeOnSignin??!1,this.schemaVersion=e.schemaVersion}validatePassword(e){const t={isValid:!0,passwordPolicy:this};return this.validatePasswordLengthOptions(e,t),this.validatePasswordCharacterOptions(e,t),t.isValid&&(t.isValid=t.meetsMinPasswordLength??!0),t.isValid&&(t.isValid=t.meetsMaxPasswordLength??!0),t.isValid&&(t.isValid=t.containsLowercaseLetter??!0),t.isValid&&(t.isValid=t.containsUppercaseLetter??!0),t.isValid&&(t.isValid=t.containsNumericCharacter??!0),t.isValid&&(t.isValid=t.containsNonAlphanumericCharacter??!0),t}validatePasswordLengthOptions(e,t){const r=this.customStrengthOptions.minPasswordLength,i=this.customStrengthOptions.maxPasswordLength;r&&(t.meetsMinPasswordLength=e.length>=r),i&&(t.meetsMaxPasswordLength=e.length<=i)}validatePasswordCharacterOptions(e,t){this.updatePasswordCharacterOptionsStatuses(t,!1,!1,!1,!1);let r;for(let i=0;i<e.length;i++)r=e.charAt(i),this.updatePasswordCharacterOptionsStatuses(t,r>="a"&&r<="z",r>="A"&&r<="Z",r>="0"&&r<="9",this.allowedNonAlphanumericCharacters.includes(r))}updatePasswordCharacterOptionsStatuses(e,t,r,i,o){this.customStrengthOptions.containsLowercaseLetter&&(e.containsLowercaseLetter||(e.containsLowercaseLetter=t)),this.customStrengthOptions.containsUppercaseLetter&&(e.containsUppercaseLetter||(e.containsUppercaseLetter=r)),this.customStrengthOptions.containsNumericCharacter&&(e.containsNumericCharacter||(e.containsNumericCharacter=i)),this.customStrengthOptions.containsNonAlphanumericCharacter&&(e.containsNonAlphanumericCharacter||(e.containsNonAlphanumericCharacter=o))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class e_{constructor(e,t,r,i){this.app=e,this.heartbeatServiceProvider=t,this.appCheckServiceProvider=r,this.config=i,this.currentUser=null,this.emulatorConfig=null,this.operations=Promise.resolve(),this.authStateSubscription=new bh(this),this.idTokenSubscription=new bh(this),this.beforeStateQueue=new Qv(this),this.redirectUser=null,this.isProactiveRefreshEnabled=!1,this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION=1,this._canInitEmulator=!0,this._isInitialized=!1,this._deleted=!1,this._initializationPromise=null,this._popupRedirectResolver=null,this._errorFactory=yf,this._agentRecaptchaConfig=null,this._tenantRecaptchaConfigs={},this._projectPasswordPolicy=null,this._tenantPasswordPolicies={},this._resolvePersistenceManagerAvailable=void 0,this.lastNotifiedUid=void 0,this.languageCode=null,this.tenantId=null,this.settings={appVerificationDisabledForTesting:!1},this.frameworks=[],this.name=e.name,this.clientVersion=i.sdkClientVersion,this._persistenceManagerAvailable=new Promise(o=>this._resolvePersistenceManagerAvailable=o)}_initializeWithPersistence(e,t){return t&&(this._popupRedirectResolver=rn(t)),this._initializationPromise=this.queue(async()=>{var r,i,o;if(!this._deleted&&(this.persistenceManager=await jr.create(this,e),(r=this._resolvePersistenceManagerAvailable)==null||r.call(this),!this._deleted)){if((i=this._popupRedirectResolver)!=null&&i._shouldInitProactively)try{await this._popupRedirectResolver._initialize(this)}catch{}await this.initializeCurrentUser(t),this.lastNotifiedUid=((o=this.currentUser)==null?void 0:o.uid)||null,!this._deleted&&(this._isInitialized=!0)}}),this._initializationPromise}async _onStorageEvent(){if(this._deleted)return;const e=await this.assertedPersistence.getCurrentUser();if(!(!this.currentUser&&!e)){if(this.currentUser&&e&&this.currentUser.uid===e.uid){this._currentUser._assign(e),await this.currentUser.getIdToken();return}await this._updateCurrentUser(e,!0)}}async initializeCurrentUserFromIdToken(e){try{const t=await Ls(this,{idToken:e}),r=await Et._fromGetAccountInfoResponse(this,t,e);await this.directlySetCurrentUser(r)}catch(t){console.warn("FirebaseServerApp could not login user with provided authIdToken: ",t),await this.directlySetCurrentUser(null)}}async initializeCurrentUser(e){var o;if(Lt(this.app)){const s=this.app.settings.authIdToken;return s?new Promise(l=>{setTimeout(()=>this.initializeCurrentUserFromIdToken(s).then(l,l))}):this.directlySetCurrentUser(null)}const t=await this.assertedPersistence.getCurrentUser();let r=t,i=!1;if(e&&this.config.authDomain){await this.getOrInitRedirectPersistenceManager();const s=(o=this.redirectUser)==null?void 0:o._redirectEventId,l=r==null?void 0:r._redirectEventId,u=await this.tryRedirectSignIn(e);(!s||s===l)&&(u!=null&&u.user)&&(r=u.user,i=!0)}if(!r)return this.directlySetCurrentUser(null);if(!r._redirectEventId){if(i)try{await this.beforeStateQueue.runMiddleware(r)}catch(s){r=t,this._popupRedirectResolver._overrideRedirectResult(this,()=>Promise.reject(s))}return r?this.reloadAndSetCurrentUserOrClear(r):this.directlySetCurrentUser(null)}return Q(this._popupRedirectResolver,this,"argument-error"),await this.getOrInitRedirectPersistenceManager(),this.redirectUser&&this.redirectUser._redirectEventId===r._redirectEventId?this.directlySetCurrentUser(r):this.reloadAndSetCurrentUserOrClear(r)}async tryRedirectSignIn(e){let t=null;try{t=await this._popupRedirectResolver._completeRedirectFn(this,e,!0)}catch{await this._setRedirectUser(null)}return t}async reloadAndSetCurrentUserOrClear(e){try{await Vs(e)}catch(t){if((t==null?void 0:t.code)!=="auth/network-request-failed")return this.directlySetCurrentUser(null)}return this.directlySetCurrentUser(e)}useDeviceLanguage(){this.languageCode=Dv()}async _delete(){this._deleted=!0}async updateCurrentUser(e){if(Lt(this.app))return Promise.reject(hr(this));const t=e?Be(e):null;return t&&Q(t.auth.config.apiKey===this.config.apiKey,this,"invalid-user-token"),this._updateCurrentUser(t&&t._clone(this))}async _updateCurrentUser(e,t=!1){if(!this._deleted)return e&&Q(this.tenantId===e.tenantId,this,"tenant-id-mismatch"),t||await this.beforeStateQueue.runMiddleware(e),this.queue(async()=>{await this.directlySetCurrentUser(e),this.notifyAuthListeners()})}async signOut(){return Lt(this.app)?Promise.reject(hr(this)):(await this.beforeStateQueue.runMiddleware(null),(this.redirectPersistenceManager||this._popupRedirectResolver)&&await this._setRedirectUser(null),this._updateCurrentUser(null,!0))}setPersistence(e){return Lt(this.app)?Promise.reject(hr(this)):this.queue(async()=>{await this.assertedPersistence.setPersistence(rn(e))})}_getRecaptchaConfig(){return this.tenantId==null?this._agentRecaptchaConfig:this._tenantRecaptchaConfigs[this.tenantId]}async validatePassword(e){this._getPasswordPolicyInternal()||await this._updatePasswordPolicy();const t=this._getPasswordPolicyInternal();return t.schemaVersion!==this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION?Promise.reject(this._errorFactory.create("unsupported-password-policy-schema-version",{})):t.validatePassword(e)}_getPasswordPolicyInternal(){return this.tenantId===null?this._projectPasswordPolicy:this._tenantPasswordPolicies[this.tenantId]}async _updatePasswordPolicy(){const e=await Jv(this),t=new Zv(e);this.tenantId===null?this._projectPasswordPolicy=t:this._tenantPasswordPolicies[this.tenantId]=t}_getPersistenceType(){return this.assertedPersistence.persistence.type}_getPersistence(){return this.assertedPersistence.persistence}_updateErrorMap(e){this._errorFactory=new Oo("auth","Firebase",e())}onAuthStateChanged(e,t,r){return this.registerStateListener(this.authStateSubscription,e,t,r)}beforeAuthStateChanged(e,t){return this.beforeStateQueue.pushCallback(e,t)}onIdTokenChanged(e,t,r){return this.registerStateListener(this.idTokenSubscription,e,t,r)}authStateReady(){return new Promise((e,t)=>{if(this.currentUser)e();else{const r=this.onAuthStateChanged(()=>{r(),e()},t)}})}async revokeAccessToken(e){if(this.currentUser){const t=await this.currentUser.getIdToken(),r={providerId:"apple.com",tokenType:"ACCESS_TOKEN",token:e,idToken:t};this.tenantId!=null&&(r.tenantId=this.tenantId),await Gv(this,r)}}toJSON(){var e;return{apiKey:this.config.apiKey,authDomain:this.config.authDomain,appName:this.name,currentUser:(e=this._currentUser)==null?void 0:e.toJSON()}}async _setRedirectUser(e,t){const r=await this.getOrInitRedirectPersistenceManager(t);return e===null?r.removeCurrentUser():r.setCurrentUser(e)}async getOrInitRedirectPersistenceManager(e){if(!this.redirectPersistenceManager){const t=e&&rn(e)||this._popupRedirectResolver;Q(t,this,"argument-error"),this.redirectPersistenceManager=await jr.create(this,[rn(t._redirectPersistence)],"redirectUser"),this.redirectUser=await this.redirectPersistenceManager.getCurrentUser()}return this.redirectPersistenceManager}async _redirectUserForId(e){var t,r;return this._isInitialized&&await this.queue(async()=>{}),((t=this._currentUser)==null?void 0:t._redirectEventId)===e?this._currentUser:((r=this.redirectUser)==null?void 0:r._redirectEventId)===e?this.redirectUser:null}async _persistUserIfCurrent(e){if(e===this.currentUser)return this.queue(async()=>this.directlySetCurrentUser(e))}_notifyListenersIfCurrent(e){e===this.currentUser&&this.notifyAuthListeners()}_key(){return`${this.config.authDomain}:${this.config.apiKey}:${this.name}`}_startProactiveRefresh(){this.isProactiveRefreshEnabled=!0,this.currentUser&&this._currentUser._startProactiveRefresh()}_stopProactiveRefresh(){this.isProactiveRefreshEnabled=!1,this.currentUser&&this._currentUser._stopProactiveRefresh()}get _currentUser(){return this.currentUser}notifyAuthListeners(){var t;if(!this._isInitialized)return;this.idTokenSubscription.next(this.currentUser);const e=((t=this.currentUser)==null?void 0:t.uid)??null;this.lastNotifiedUid!==e&&(this.lastNotifiedUid=e,this.authStateSubscription.next(this.currentUser))}registerStateListener(e,t,r,i){if(this._deleted)return()=>{};const o=typeof t=="function"?t:t.next.bind(t);let s=!1;const l=this._isInitialized?Promise.resolve():this._initializationPromise;if(Q(l,this,"internal-error"),l.then(()=>{s||o(this.currentUser)}),typeof t=="function"){const u=e.addObserver(t,r,i);return()=>{s=!0,u()}}else{const u=e.addObserver(t);return()=>{s=!0,u()}}}async directlySetCurrentUser(e){this.currentUser&&this.currentUser!==e&&this._currentUser._stopProactiveRefresh(),e&&this.isProactiveRefreshEnabled&&e._startProactiveRefresh(),this.currentUser=e,e?await this.assertedPersistence.setCurrentUser(e):await this.assertedPersistence.removeCurrentUser()}queue(e){return this.operations=this.operations.then(e,e),this.operations}get assertedPersistence(){return Q(this.persistenceManager,this,"internal-error"),this.persistenceManager}_logFramework(e){!e||this.frameworks.includes(e)||(this.frameworks.push(e),this.frameworks.sort(),this.clientVersion=Of(this.config.clientPlatform,this._getFrameworks()))}_getFrameworks(){return this.frameworks}async _getAdditionalHeaders(){var i;const e={"X-Client-Version":this.clientVersion};this.app.options.appId&&(e["X-Firebase-gmpid"]=this.app.options.appId);const t=await((i=this.heartbeatServiceProvider.getImmediate({optional:!0}))==null?void 0:i.getHeartbeatsHeader());t&&(e["X-Firebase-Client"]=t);const r=await this._getAppCheckToken();return r&&(e["X-Firebase-AppCheck"]=r),e}async _getAppCheckToken(){var t;if(Lt(this.app)&&this.app.settings.appCheckToken)return this.app.settings.appCheckToken;const e=await((t=this.appCheckServiceProvider.getImmediate({optional:!0}))==null?void 0:t.getToken());return e!=null&&e.error&&Rv(`Error while retrieving App Check token: ${e.error}`),e==null?void 0:e.token}}function sa(n){return Be(n)}class bh{constructor(e){this.auth=e,this.observer=null,this.addObserver=yy(t=>this.observer=t)}get next(){return Q(this.observer,this.auth,"internal-error"),this.observer.next.bind(this.observer)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let sc={async loadJS(){throw new Error("Unable to load external scripts")},recaptchaV2Script:"",recaptchaEnterpriseScript:"",gapiScript:""};function t_(n){sc=n}function n_(n){return sc.loadJS(n)}function r_(){return sc.gapiScript}function i_(n){return`__${n}${Math.floor(Math.random()*1e6)}`}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function o_(n,e){const t=Zl(n,"auth");if(t.isInitialized()){const i=t.getImmediate(),o=t.getOptions();if(mr(o,e??{}))return i;dn(i,"already-initialized")}return t.initialize({options:e})}function s_(n,e){const t=(e==null?void 0:e.persistence)||[],r=(Array.isArray(t)?t:[t]).map(rn);e!=null&&e.errorMap&&n._updateErrorMap(e.errorMap),n._initializeWithPersistence(r,e==null?void 0:e.popupRedirectResolver)}function a_(n,e,t){const r=sa(n);Q(/^https?:\/\//.test(e),r,"invalid-emulator-scheme");const i=!1,o=Nf(e),{host:s,port:l}=l_(e),u=l===null?"":`:${l}`,h={url:`${o}//${s}${u}/`},p=Object.freeze({host:s,port:l,protocol:o.replace(":",""),options:Object.freeze({disableWarnings:i})});if(!r._canInitEmulator){Q(r.config.emulator&&r.emulatorConfig,r,"emulator-config-failed"),Q(mr(h,r.config.emulator)&&mr(p,r.emulatorConfig),r,"emulator-config-failed");return}r.config.emulator=h,r.emulatorConfig=p,r.settings.appVerificationDisabledForTesting=!0,Do(s)?uf(`${o}//${s}${u}`):c_()}function Nf(n){const e=n.indexOf(":");return e<0?"":n.substr(0,e+1)}function l_(n){const e=Nf(n),t=/(\/\/)?([^?#/]+)/.exec(n.substr(e.length));if(!t)return{host:"",port:null};const r=t[2].split("@").pop()||"",i=/^(\[[^\]]+\])(:|$)/.exec(r);if(i){const o=i[1];return{host:o,port:Th(r.substr(o.length+1))}}else{const[o,s]=r.split(":");return{host:o,port:Th(s)}}}function Th(n){if(!n)return null;const e=Number(n);return isNaN(e)?null:e}function c_(){function n(){const e=document.createElement("p"),t=e.style;e.innerText="Running in emulator mode. Do not use with production credentials.",t.position="fixed",t.width="100%",t.backgroundColor="#ffffff",t.border=".1em solid #000000",t.color="#b50000",t.bottom="0px",t.left="0px",t.margin="0px",t.zIndex="10000",t.textAlign="center",e.classList.add("firebase-emulator-warning"),document.body.appendChild(e)}typeof console<"u"&&typeof console.info=="function"&&console.info("WARNING: You are using the Auth Emulator, which is intended for local testing only.  Do not use with production credentials."),typeof window<"u"&&typeof document<"u"&&(document.readyState==="loading"?window.addEventListener("DOMContentLoaded",n):n())}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Df{constructor(e,t){this.providerId=e,this.signInMethod=t}toJSON(){return nn("not implemented")}_getIdTokenResponse(e){return nn("not implemented")}_linkToIdToken(e,t){return nn("not implemented")}_getReauthenticationResolver(e){return nn("not implemented")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function zr(n,e){return Fv(n,"POST","/v1/accounts:signInWithIdp",rc(n,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const u_="http://localhost";class vr extends Df{constructor(){super(...arguments),this.pendingToken=null}static _fromParams(e){const t=new vr(e.providerId,e.signInMethod);return e.idToken||e.accessToken?(e.idToken&&(t.idToken=e.idToken),e.accessToken&&(t.accessToken=e.accessToken),e.nonce&&!e.pendingToken&&(t.nonce=e.nonce),e.pendingToken&&(t.pendingToken=e.pendingToken)):e.oauthToken&&e.oauthTokenSecret?(t.accessToken=e.oauthToken,t.secret=e.oauthTokenSecret):dn("argument-error"),t}toJSON(){return{idToken:this.idToken,accessToken:this.accessToken,secret:this.secret,nonce:this.nonce,pendingToken:this.pendingToken,providerId:this.providerId,signInMethod:this.signInMethod}}static fromJSON(e){const t=typeof e=="string"?JSON.parse(e):e,{providerId:r,signInMethod:i,...o}=t;if(!r||!i)return null;const s=new vr(r,i);return s.idToken=o.idToken||void 0,s.accessToken=o.accessToken||void 0,s.secret=o.secret,s.nonce=o.nonce,s.pendingToken=o.pendingToken||null,s}_getIdTokenResponse(e){const t=this.buildRequest();return zr(e,t)}_linkToIdToken(e,t){const r=this.buildRequest();return r.idToken=t,zr(e,r)}_getReauthenticationResolver(e){const t=this.buildRequest();return t.autoCreate=!1,zr(e,t)}buildRequest(){const e={requestUri:u_,returnSecureToken:!0};if(this.pendingToken)e.pendingToken=this.pendingToken;else{const t={};this.idToken&&(t.id_token=this.idToken),this.accessToken&&(t.access_token=this.accessToken),this.secret&&(t.oauth_token_secret=this.secret),t.providerId=this.providerId,this.nonce&&!this.pendingToken&&(t.nonce=this.nonce),e.postBody=No(t)}return e}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Mf{constructor(e){this.providerId=e,this.defaultLanguageCode=null,this.customParameters={}}setDefaultLanguage(e){this.defaultLanguageCode=e}setCustomParameters(e){return this.customParameters=e,this}getCustomParameters(){return this.customParameters}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Lo extends Mf{constructor(){super(...arguments),this.scopes=[]}addScope(e){return this.scopes.includes(e)||this.scopes.push(e),this}getScopes(){return[...this.scopes]}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xn extends Lo{constructor(){super("facebook.com")}static credential(e){return vr._fromParams({providerId:xn.PROVIDER_ID,signInMethod:xn.FACEBOOK_SIGN_IN_METHOD,accessToken:e})}static credentialFromResult(e){return xn.credentialFromTaggedObject(e)}static credentialFromError(e){return xn.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e||!("oauthAccessToken"in e)||!e.oauthAccessToken)return null;try{return xn.credential(e.oauthAccessToken)}catch{return null}}}xn.FACEBOOK_SIGN_IN_METHOD="facebook.com";xn.PROVIDER_ID="facebook.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class en extends Lo{constructor(){super("google.com"),this.addScope("profile")}static credential(e,t){return vr._fromParams({providerId:en.PROVIDER_ID,signInMethod:en.GOOGLE_SIGN_IN_METHOD,idToken:e,accessToken:t})}static credentialFromResult(e){return en.credentialFromTaggedObject(e)}static credentialFromError(e){return en.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e)return null;const{oauthIdToken:t,oauthAccessToken:r}=e;if(!t&&!r)return null;try{return en.credential(t,r)}catch{return null}}}en.GOOGLE_SIGN_IN_METHOD="google.com";en.PROVIDER_ID="google.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class kn extends Lo{constructor(){super("github.com")}static credential(e){return vr._fromParams({providerId:kn.PROVIDER_ID,signInMethod:kn.GITHUB_SIGN_IN_METHOD,accessToken:e})}static credentialFromResult(e){return kn.credentialFromTaggedObject(e)}static credentialFromError(e){return kn.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e||!("oauthAccessToken"in e)||!e.oauthAccessToken)return null;try{return kn.credential(e.oauthAccessToken)}catch{return null}}}kn.GITHUB_SIGN_IN_METHOD="github.com";kn.PROVIDER_ID="github.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Pn extends Lo{constructor(){super("twitter.com")}static credential(e,t){return vr._fromParams({providerId:Pn.PROVIDER_ID,signInMethod:Pn.TWITTER_SIGN_IN_METHOD,oauthToken:e,oauthTokenSecret:t})}static credentialFromResult(e){return Pn.credentialFromTaggedObject(e)}static credentialFromError(e){return Pn.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e)return null;const{oauthAccessToken:t,oauthTokenSecret:r}=e;if(!t||!r)return null;try{return Pn.credential(t,r)}catch{return null}}}Pn.TWITTER_SIGN_IN_METHOD="twitter.com";Pn.PROVIDER_ID="twitter.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ri{constructor(e){this.user=e.user,this.providerId=e.providerId,this._tokenResponse=e._tokenResponse,this.operationType=e.operationType}static async _fromIdTokenResponse(e,t,r,i=!1){const o=await Et._fromIdTokenResponse(e,r,i),s=Eh(r);return new ri({user:o,providerId:s,_tokenResponse:r,operationType:t})}static async _forOperation(e,t,r){await e._updateTokensIfNecessary(r,!0);const i=Eh(r);return new ri({user:e,providerId:i,_tokenResponse:r,operationType:t})}}function Eh(n){return n.providerId?n.providerId:"phoneNumber"in n?"phone":null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Fs extends yn{constructor(e,t,r,i){super(t.code,t.message),this.operationType=r,this.user=i,Object.setPrototypeOf(this,Fs.prototype),this.customData={appName:e.name,tenantId:e.tenantId??void 0,_serverResponse:t.customData._serverResponse,operationType:r}}static _fromErrorAndOperation(e,t,r,i){return new Fs(e,t,r,i)}}function Lf(n,e,t,r){return(e==="reauthenticate"?t._getReauthenticationResolver(n):t._getIdTokenResponse(n)).catch(o=>{throw o.code==="auth/multi-factor-auth-required"?Fs._fromErrorAndOperation(n,o,e,r):o})}async function h_(n,e,t=!1){const r=await go(n,e._linkToIdToken(n.auth,await n.getIdToken()),t);return ri._forOperation(n,"link",r)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function d_(n,e,t=!1){const{auth:r}=n;if(Lt(r.app))return Promise.reject(hr(r));const i="reauthenticate";try{const o=await go(n,Lf(r,i,e,n),t);Q(o.idToken,r,"internal-error");const s=ic(o.idToken);Q(s,r,"internal-error");const{sub:l}=s;return Q(n.uid===l,r,"user-mismatch"),ri._forOperation(n,i,o)}catch(o){throw(o==null?void 0:o.code)==="auth/user-not-found"&&dn(r,"user-mismatch"),o}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Vf(n,e,t=!1){if(Lt(n.app))return Promise.reject(hr(n));const r="signIn",i=await Lf(n,r,e),o=await ri._fromIdTokenResponse(n,r,i);return t||await n._updateCurrentUser(o.user),o}async function f_(n,e){return Vf(sa(n),e)}function p_(n,e,t,r){return Be(n).onIdTokenChanged(e,t,r)}function g_(n,e,t){return Be(n).beforeAuthStateChanged(e,t)}function m_(n,e,t,r){return Be(n).onAuthStateChanged(e,t,r)}function y_(n){return Be(n).signOut()}const Us="__sak";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ff{constructor(e,t){this.storageRetriever=e,this.type=t}_isAvailable(){try{return this.storage?(this.storage.setItem(Us,"1"),this.storage.removeItem(Us),Promise.resolve(!0)):Promise.resolve(!1)}catch{return Promise.resolve(!1)}}_set(e,t){return this.storage.setItem(e,JSON.stringify(t)),Promise.resolve()}_get(e){const t=this.storage.getItem(e);return Promise.resolve(t?JSON.parse(t):null)}_remove(e){return this.storage.removeItem(e),Promise.resolve()}get storage(){return this.storageRetriever()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const v_=1e3,__=10;class Uf extends Ff{constructor(){super(()=>window.localStorage,"LOCAL"),this.boundEventHandler=(e,t)=>this.onStorageEvent(e,t),this.listeners={},this.localCache={},this.pollTimer=null,this.fallbackToPolling=Rf(),this._shouldAllowMigration=!0}forAllChangedKeys(e){for(const t of Object.keys(this.listeners)){const r=this.storage.getItem(t),i=this.localCache[t];r!==i&&e(t,i,r)}}onStorageEvent(e,t=!1){if(!e.key){this.forAllChangedKeys((s,l,u)=>{this.notifyListeners(s,u)});return}const r=e.key;t?this.detachListener():this.stopPolling();const i=()=>{const s=this.storage.getItem(r);!t&&this.localCache[r]===s||this.notifyListeners(r,s)},o=this.storage.getItem(r);Yv()&&o!==e.newValue&&e.newValue!==e.oldValue?setTimeout(i,__):i()}notifyListeners(e,t){this.localCache[e]=t;const r=this.listeners[e];if(r)for(const i of Array.from(r))i(t&&JSON.parse(t))}startPolling(){this.stopPolling(),this.pollTimer=setInterval(()=>{this.forAllChangedKeys((e,t,r)=>{this.onStorageEvent(new StorageEvent("storage",{key:e,oldValue:t,newValue:r}),!0)})},v_)}stopPolling(){this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}attachListener(){window.addEventListener("storage",this.boundEventHandler)}detachListener(){window.removeEventListener("storage",this.boundEventHandler)}_addListener(e,t){Object.keys(this.listeners).length===0&&(this.fallbackToPolling?this.startPolling():this.attachListener()),this.listeners[e]||(this.listeners[e]=new Set,this.localCache[e]=this.storage.getItem(e)),this.listeners[e].add(t)}_removeListener(e,t){this.listeners[e]&&(this.listeners[e].delete(t),this.listeners[e].size===0&&delete this.listeners[e]),Object.keys(this.listeners).length===0&&(this.detachListener(),this.stopPolling())}async _set(e,t){await super._set(e,t),this.localCache[e]=JSON.stringify(t)}async _get(e){const t=await super._get(e);return this.localCache[e]=JSON.stringify(t),t}async _remove(e){await super._remove(e),delete this.localCache[e]}}Uf.type="LOCAL";const w_=Uf;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class qf extends Ff{constructor(){super(()=>window.sessionStorage,"SESSION")}_addListener(e,t){}_removeListener(e,t){}}qf.type="SESSION";const Bf=qf;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function b_(n){return Promise.all(n.map(async e=>{try{return{fulfilled:!0,value:await e}}catch(t){return{fulfilled:!1,reason:t}}}))}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class aa{constructor(e){this.eventTarget=e,this.handlersMap={},this.boundEventHandler=this.handleEvent.bind(this)}static _getInstance(e){const t=this.receivers.find(i=>i.isListeningto(e));if(t)return t;const r=new aa(e);return this.receivers.push(r),r}isListeningto(e){return this.eventTarget===e}async handleEvent(e){const t=e,{eventId:r,eventType:i,data:o}=t.data,s=this.handlersMap[i];if(!(s!=null&&s.size))return;t.ports[0].postMessage({status:"ack",eventId:r,eventType:i});const l=Array.from(s).map(async h=>h(t.origin,o)),u=await b_(l);t.ports[0].postMessage({status:"done",eventId:r,eventType:i,response:u})}_subscribe(e,t){Object.keys(this.handlersMap).length===0&&this.eventTarget.addEventListener("message",this.boundEventHandler),this.handlersMap[e]||(this.handlersMap[e]=new Set),this.handlersMap[e].add(t)}_unsubscribe(e,t){this.handlersMap[e]&&t&&this.handlersMap[e].delete(t),(!t||this.handlersMap[e].size===0)&&delete this.handlersMap[e],Object.keys(this.handlersMap).length===0&&this.eventTarget.removeEventListener("message",this.boundEventHandler)}}aa.receivers=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ac(n="",e=10){let t="";for(let r=0;r<e;r++)t+=Math.floor(Math.random()*10);return n+t}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class T_{constructor(e){this.target=e,this.handlers=new Set}removeMessageHandler(e){e.messageChannel&&(e.messageChannel.port1.removeEventListener("message",e.onMessage),e.messageChannel.port1.close()),this.handlers.delete(e)}async _send(e,t,r=50){const i=typeof MessageChannel<"u"?new MessageChannel:null;if(!i)throw new Error("connection_unavailable");let o,s;return new Promise((l,u)=>{const h=ac("",20);i.port1.start();const p=setTimeout(()=>{u(new Error("unsupported_event"))},r);s={messageChannel:i,onMessage(m){const g=m;if(g.data.eventId===h)switch(g.data.status){case"ack":clearTimeout(p),o=setTimeout(()=>{u(new Error("timeout"))},3e3);break;case"done":clearTimeout(o),l(g.data.response);break;default:clearTimeout(p),clearTimeout(o),u(new Error("invalid_response"));break}}},this.handlers.add(s),i.port1.addEventListener("message",s.onMessage),this.target.postMessage({eventType:e,eventId:h,data:t},[i.port2])}).finally(()=>{s&&this.removeMessageHandler(s)})}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function $t(){return window}function E_(n){$t().location.href=n}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function $f(){return typeof $t().WorkerGlobalScope<"u"&&typeof $t().importScripts=="function"}async function I_(){if(!(navigator!=null&&navigator.serviceWorker))return null;try{return(await navigator.serviceWorker.ready).active}catch{return null}}function A_(){var n;return((n=navigator==null?void 0:navigator.serviceWorker)==null?void 0:n.controller)||null}function S_(){return $f()?self:null}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const jf="firebaseLocalStorageDb",x_=1,qs="firebaseLocalStorage",zf="fbase_key";class Vo{constructor(e){this.request=e}toPromise(){return new Promise((e,t)=>{this.request.addEventListener("success",()=>{e(this.request.result)}),this.request.addEventListener("error",()=>{t(this.request.error)})})}}function la(n,e){return n.transaction([qs],e?"readwrite":"readonly").objectStore(qs)}function k_(){const n=indexedDB.deleteDatabase(jf);return new Vo(n).toPromise()}function Tl(){const n=indexedDB.open(jf,x_);return new Promise((e,t)=>{n.addEventListener("error",()=>{t(n.error)}),n.addEventListener("upgradeneeded",()=>{const r=n.result;try{r.createObjectStore(qs,{keyPath:zf})}catch(i){t(i)}}),n.addEventListener("success",async()=>{const r=n.result;r.objectStoreNames.contains(qs)?e(r):(r.close(),await k_(),e(await Tl()))})})}async function Ih(n,e,t){const r=la(n,!0).put({[zf]:e,value:t});return new Vo(r).toPromise()}async function P_(n,e){const t=la(n,!1).get(e),r=await new Vo(t).toPromise();return r===void 0?null:r.value}function Ah(n,e){const t=la(n,!0).delete(e);return new Vo(t).toPromise()}const C_=800,R_=3;class Wf{constructor(){this.type="LOCAL",this._shouldAllowMigration=!0,this.listeners={},this.localCache={},this.pollTimer=null,this.pendingWrites=0,this.receiver=null,this.sender=null,this.serviceWorkerReceiverAvailable=!1,this.activeServiceWorker=null,this._workerInitializationPromise=this.initializeServiceWorkerMessaging().then(()=>{},()=>{})}async _openDb(){return this.db?this.db:(this.db=await Tl(),this.db)}async _withRetries(e){let t=0;for(;;)try{const r=await this._openDb();return await e(r)}catch(r){if(t++>R_)throw r;this.db&&(this.db.close(),this.db=void 0)}}async initializeServiceWorkerMessaging(){return $f()?this.initializeReceiver():this.initializeSender()}async initializeReceiver(){this.receiver=aa._getInstance(S_()),this.receiver._subscribe("keyChanged",async(e,t)=>({keyProcessed:(await this._poll()).includes(t.key)})),this.receiver._subscribe("ping",async(e,t)=>["keyChanged"])}async initializeSender(){var t,r;if(this.activeServiceWorker=await I_(),!this.activeServiceWorker)return;this.sender=new T_(this.activeServiceWorker);const e=await this.sender._send("ping",{},800);e&&(t=e[0])!=null&&t.fulfilled&&(r=e[0])!=null&&r.value.includes("keyChanged")&&(this.serviceWorkerReceiverAvailable=!0)}async notifyServiceWorker(e){if(!(!this.sender||!this.activeServiceWorker||A_()!==this.activeServiceWorker))try{await this.sender._send("keyChanged",{key:e},this.serviceWorkerReceiverAvailable?800:50)}catch{}}async _isAvailable(){try{if(!indexedDB)return!1;const e=await Tl();return await Ih(e,Us,"1"),await Ah(e,Us),!0}catch{}return!1}async _withPendingWrite(e){this.pendingWrites++;try{await e()}finally{this.pendingWrites--}}async _set(e,t){return this._withPendingWrite(async()=>(await this._withRetries(r=>Ih(r,e,t)),this.localCache[e]=t,this.notifyServiceWorker(e)))}async _get(e){const t=await this._withRetries(r=>P_(r,e));return this.localCache[e]=t,t}async _remove(e){return this._withPendingWrite(async()=>(await this._withRetries(t=>Ah(t,e)),delete this.localCache[e],this.notifyServiceWorker(e)))}async _poll(){const e=await this._withRetries(i=>{const o=la(i,!1).getAll();return new Vo(o).toPromise()});if(!e)return[];if(this.pendingWrites!==0)return[];const t=[],r=new Set;if(e.length!==0)for(const{fbase_key:i,value:o}of e)r.add(i),JSON.stringify(this.localCache[i])!==JSON.stringify(o)&&(this.notifyListeners(i,o),t.push(i));for(const i of Object.keys(this.localCache))this.localCache[i]&&!r.has(i)&&(this.notifyListeners(i,null),t.push(i));return t}notifyListeners(e,t){this.localCache[e]=t;const r=this.listeners[e];if(r)for(const i of Array.from(r))i(t)}startPolling(){this.stopPolling(),this.pollTimer=setInterval(async()=>this._poll(),C_)}stopPolling(){this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}_addListener(e,t){Object.keys(this.listeners).length===0&&this.startPolling(),this.listeners[e]||(this.listeners[e]=new Set,this._get(e)),this.listeners[e].add(t)}_removeListener(e,t){this.listeners[e]&&(this.listeners[e].delete(t),this.listeners[e].size===0&&delete this.listeners[e]),Object.keys(this.listeners).length===0&&this.stopPolling()}}Wf.type="LOCAL";const O_=Wf;new Mo(3e4,6e4);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function N_(n,e){return e?rn(e):(Q(n._popupRedirectResolver,n,"argument-error"),n._popupRedirectResolver)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class lc extends Df{constructor(e){super("custom","custom"),this.params=e}_getIdTokenResponse(e){return zr(e,this._buildIdpRequest())}_linkToIdToken(e,t){return zr(e,this._buildIdpRequest(t))}_getReauthenticationResolver(e){return zr(e,this._buildIdpRequest())}_buildIdpRequest(e){const t={requestUri:this.params.requestUri,sessionId:this.params.sessionId,postBody:this.params.postBody,tenantId:this.params.tenantId,pendingToken:this.params.pendingToken,returnSecureToken:!0,returnIdpCredential:!0};return e&&(t.idToken=e),t}}function D_(n){return Vf(n.auth,new lc(n),n.bypassAuthState)}function M_(n){const{auth:e,user:t}=n;return Q(t,e,"internal-error"),d_(t,new lc(n),n.bypassAuthState)}async function L_(n){const{auth:e,user:t}=n;return Q(t,e,"internal-error"),h_(t,new lc(n),n.bypassAuthState)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Hf{constructor(e,t,r,i,o=!1){this.auth=e,this.resolver=r,this.user=i,this.bypassAuthState=o,this.pendingPromise=null,this.eventManager=null,this.filter=Array.isArray(t)?t:[t]}execute(){return new Promise(async(e,t)=>{this.pendingPromise={resolve:e,reject:t};try{this.eventManager=await this.resolver._initialize(this.auth),await this.onExecution(),this.eventManager.registerConsumer(this)}catch(r){this.reject(r)}})}async onAuthEvent(e){const{urlResponse:t,sessionId:r,postBody:i,tenantId:o,error:s,type:l}=e;if(s){this.reject(s);return}const u={auth:this.auth,requestUri:t,sessionId:r,tenantId:o||void 0,postBody:i||void 0,user:this.user,bypassAuthState:this.bypassAuthState};try{this.resolve(await this.getIdpTask(l)(u))}catch(h){this.reject(h)}}onError(e){this.reject(e)}getIdpTask(e){switch(e){case"signInViaPopup":case"signInViaRedirect":return D_;case"linkViaPopup":case"linkViaRedirect":return L_;case"reauthViaPopup":case"reauthViaRedirect":return M_;default:dn(this.auth,"internal-error")}}resolve(e){fn(this.pendingPromise,"Pending promise was never set"),this.pendingPromise.resolve(e),this.unregisterAndCleanUp()}reject(e){fn(this.pendingPromise,"Pending promise was never set"),this.pendingPromise.reject(e),this.unregisterAndCleanUp()}unregisterAndCleanUp(){this.eventManager&&this.eventManager.unregisterConsumer(this),this.pendingPromise=null,this.cleanUp()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const V_=new Mo(2e3,1e4);class Ur extends Hf{constructor(e,t,r,i,o){super(e,t,i,o),this.provider=r,this.authWindow=null,this.pollId=null,Ur.currentPopupAction&&Ur.currentPopupAction.cancel(),Ur.currentPopupAction=this}async executeNotNull(){const e=await this.execute();return Q(e,this.auth,"internal-error"),e}async onExecution(){fn(this.filter.length===1,"Popup operations only handle one event");const e=ac();this.authWindow=await this.resolver._openPopup(this.auth,this.provider,this.filter[0],e),this.authWindow.associatedEvent=e,this.resolver._originValidation(this.auth).catch(t=>{this.reject(t)}),this.resolver._isIframeWebStorageSupported(this.auth,t=>{t||this.reject(Bt(this.auth,"web-storage-unsupported"))}),this.pollUserCancellation()}get eventId(){var e;return((e=this.authWindow)==null?void 0:e.associatedEvent)||null}cancel(){this.reject(Bt(this.auth,"cancelled-popup-request"))}cleanUp(){this.authWindow&&this.authWindow.close(),this.pollId&&window.clearTimeout(this.pollId),this.authWindow=null,this.pollId=null,Ur.currentPopupAction=null}pollUserCancellation(){const e=()=>{var t,r;if((r=(t=this.authWindow)==null?void 0:t.window)!=null&&r.closed){this.pollId=window.setTimeout(()=>{this.pollId=null,this.reject(Bt(this.auth,"popup-closed-by-user"))},8e3);return}this.pollId=window.setTimeout(e,V_.get())};e()}}Ur.currentPopupAction=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const F_="pendingRedirect",bs=new Map;class U_ extends Hf{constructor(e,t,r=!1){super(e,["signInViaRedirect","linkViaRedirect","reauthViaRedirect","unknown"],t,void 0,r),this.eventId=null}async execute(){let e=bs.get(this.auth._key());if(!e){try{const r=await q_(this.resolver,this.auth)?await super.execute():null;e=()=>Promise.resolve(r)}catch(t){e=()=>Promise.reject(t)}bs.set(this.auth._key(),e)}return this.bypassAuthState||bs.set(this.auth._key(),()=>Promise.resolve(null)),e()}async onAuthEvent(e){if(e.type==="signInViaRedirect")return super.onAuthEvent(e);if(e.type==="unknown"){this.resolve(null);return}if(e.eventId){const t=await this.auth._redirectUserForId(e.eventId);if(t)return this.user=t,super.onAuthEvent(e);this.resolve(null)}}async onExecution(){}cleanUp(){}}async function q_(n,e){const t=j_(e),r=$_(n);if(!await r._isAvailable())return!1;const i=await r._get(t)==="true";return await r._remove(t),i}function B_(n,e){bs.set(n._key(),e)}function $_(n){return rn(n._redirectPersistence)}function j_(n){return ws(F_,n.config.apiKey,n.name)}async function z_(n,e,t=!1){if(Lt(n.app))return Promise.reject(hr(n));const r=sa(n),i=N_(r,e),s=await new U_(r,i,t).execute();return s&&!t&&(delete s.user._redirectEventId,await r._persistUserIfCurrent(s.user),await r._setRedirectUser(null,e)),s}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const W_=10*60*1e3;class H_{constructor(e){this.auth=e,this.cachedEventUids=new Set,this.consumers=new Set,this.queuedRedirectEvent=null,this.hasHandledPotentialRedirect=!1,this.lastProcessedEventTime=Date.now()}registerConsumer(e){this.consumers.add(e),this.queuedRedirectEvent&&this.isEventForConsumer(this.queuedRedirectEvent,e)&&(this.sendToConsumer(this.queuedRedirectEvent,e),this.saveEventToCache(this.queuedRedirectEvent),this.queuedRedirectEvent=null)}unregisterConsumer(e){this.consumers.delete(e)}onEvent(e){if(this.hasEventBeenHandled(e))return!1;let t=!1;return this.consumers.forEach(r=>{this.isEventForConsumer(e,r)&&(t=!0,this.sendToConsumer(e,r),this.saveEventToCache(e))}),this.hasHandledPotentialRedirect||!G_(e)||(this.hasHandledPotentialRedirect=!0,t||(this.queuedRedirectEvent=e,t=!0)),t}sendToConsumer(e,t){var r;if(e.error&&!Gf(e)){const i=((r=e.error.code)==null?void 0:r.split("auth/")[1])||"internal-error";t.onError(Bt(this.auth,i))}else t.onAuthEvent(e)}isEventForConsumer(e,t){const r=t.eventId===null||!!e.eventId&&e.eventId===t.eventId;return t.filter.includes(e.type)&&r}hasEventBeenHandled(e){return Date.now()-this.lastProcessedEventTime>=W_&&this.cachedEventUids.clear(),this.cachedEventUids.has(Sh(e))}saveEventToCache(e){this.cachedEventUids.add(Sh(e)),this.lastProcessedEventTime=Date.now()}}function Sh(n){return[n.type,n.eventId,n.sessionId,n.tenantId].filter(e=>e).join("-")}function Gf({type:n,error:e}){return n==="unknown"&&(e==null?void 0:e.code)==="auth/no-auth-event"}function G_(n){switch(n.type){case"signInViaRedirect":case"linkViaRedirect":case"reauthViaRedirect":return!0;case"unknown":return Gf(n);default:return!1}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function K_(n,e={}){return yi(n,"GET","/v1/projects",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Y_=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Q_=/^https?/;async function J_(n){if(n.config.emulator)return;const{authorizedDomains:e}=await K_(n);for(const t of e)try{if(X_(t))return}catch{}dn(n,"unauthorized-domain")}function X_(n){const e=wl(),{protocol:t,hostname:r}=new URL(e);if(n.startsWith("chrome-extension://")){const s=new URL(n);return s.hostname===""&&r===""?t==="chrome-extension:"&&n.replace("chrome-extension://","")===e.replace("chrome-extension://",""):t==="chrome-extension:"&&s.hostname===r}if(!Q_.test(t))return!1;if(Y_.test(n))return r===n;const i=n.replace(/\./g,"\\.");return new RegExp("^(.+\\."+i+"|"+i+")$","i").test(r)}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Z_=new Mo(3e4,6e4);function xh(){const n=$t().___jsl;if(n!=null&&n.H){for(const e of Object.keys(n.H))if(n.H[e].r=n.H[e].r||[],n.H[e].L=n.H[e].L||[],n.H[e].r=[...n.H[e].L],n.CP)for(let t=0;t<n.CP.length;t++)n.CP[t]=null}}function ew(n){return new Promise((e,t)=>{var i,o,s;function r(){xh(),gapi.load("gapi.iframes",{callback:()=>{e(gapi.iframes.getContext())},ontimeout:()=>{xh(),t(Bt(n,"network-request-failed"))},timeout:Z_.get()})}if((o=(i=$t().gapi)==null?void 0:i.iframes)!=null&&o.Iframe)e(gapi.iframes.getContext());else if((s=$t().gapi)!=null&&s.load)r();else{const l=i_("iframefcb");return $t()[l]=()=>{gapi.load?r():t(Bt(n,"network-request-failed"))},n_(`${r_()}?onload=${l}`).catch(u=>t(u))}}).catch(e=>{throw Ts=null,e})}let Ts=null;function tw(n){return Ts=Ts||ew(n),Ts}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const nw=new Mo(5e3,15e3),rw="__/auth/iframe",iw="emulator/auth/iframe",ow={style:{position:"absolute",top:"-100px",width:"1px",height:"1px"},"aria-hidden":"true",tabindex:"-1"},sw=new Map([["identitytoolkit.googleapis.com","p"],["staging-identitytoolkit.sandbox.googleapis.com","s"],["test-identitytoolkit.sandbox.googleapis.com","t"]]);function aw(n){const e=n.config;Q(e.authDomain,n,"auth-domain-config-required");const t=e.emulator?nc(e,iw):`https://${n.config.authDomain}/${rw}`,r={apiKey:e.apiKey,appName:n.name,v:mi},i=sw.get(n.config.apiHost);i&&(r.eid=i);const o=n._getFrameworks();return o.length&&(r.fw=o.join(",")),`${t}?${No(r).slice(1)}`}async function lw(n){const e=await tw(n),t=$t().gapi;return Q(t,n,"internal-error"),e.open({where:document.body,url:aw(n),messageHandlersFilter:t.iframes.CROSS_ORIGIN_IFRAMES_FILTER,attributes:ow,dontclear:!0},r=>new Promise(async(i,o)=>{await r.restyle({setHideOnLeave:!1});const s=Bt(n,"network-request-failed"),l=$t().setTimeout(()=>{o(s)},nw.get());function u(){$t().clearTimeout(l),i(r)}r.ping(u).then(u,()=>{o(s)})}))}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const cw={location:"yes",resizable:"yes",statusbar:"yes",toolbar:"no"},uw=500,hw=600,dw="_blank",fw="http://localhost";class kh{constructor(e){this.window=e,this.associatedEvent=null}close(){if(this.window)try{this.window.close()}catch{}}}function pw(n,e,t,r=uw,i=hw){const o=Math.max((window.screen.availHeight-i)/2,0).toString(),s=Math.max((window.screen.availWidth-r)/2,0).toString();let l="";const u={...cw,width:r.toString(),height:i.toString(),top:o,left:s},h=Qe().toLowerCase();t&&(l=Sf(h)?dw:t),If(h)&&(e=e||fw,u.scrollbars="yes");const p=Object.entries(u).reduce((g,[b,P])=>`${g}${b}=${P},`,"");if(Kv(h)&&l!=="_self")return gw(e||"",l),new kh(null);const m=window.open(e||"",l,p);Q(m,n,"popup-blocked");try{m.focus()}catch{}return new kh(m)}function gw(n,e){const t=document.createElement("a");t.href=n,t.target=e;const r=document.createEvent("MouseEvent");r.initMouseEvent("click",!0,!0,window,1,0,0,0,0,!1,!1,!1,!1,1,null),t.dispatchEvent(r)}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const mw="__/auth/handler",yw="emulator/auth/handler",vw=encodeURIComponent("fac");async function Ph(n,e,t,r,i,o){Q(n.config.authDomain,n,"auth-domain-config-required"),Q(n.config.apiKey,n,"invalid-api-key");const s={apiKey:n.config.apiKey,appName:n.name,authType:t,redirectUrl:r,v:mi,eventId:i};if(e instanceof Mf){e.setDefaultLanguage(n.languageCode),s.providerId=e.providerId||"",my(e.getCustomParameters())||(s.customParameters=JSON.stringify(e.getCustomParameters()));for(const[p,m]of Object.entries({}))s[p]=m}if(e instanceof Lo){const p=e.getScopes().filter(m=>m!=="");p.length>0&&(s.scopes=p.join(","))}n.tenantId&&(s.tid=n.tenantId);const l=s;for(const p of Object.keys(l))l[p]===void 0&&delete l[p];const u=await n._getAppCheckToken(),h=u?`#${vw}=${encodeURIComponent(u)}`:"";return`${_w(n)}?${No(l).slice(1)}${h}`}function _w({config:n}){return n.emulator?nc(n,yw):`https://${n.authDomain}/${mw}`}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const el="webStorageSupport";class ww{constructor(){this.eventManagers={},this.iframes={},this.originValidationPromises={},this._redirectPersistence=Bf,this._completeRedirectFn=z_,this._overrideRedirectResult=B_}async _openPopup(e,t,r,i){var s;fn((s=this.eventManagers[e._key()])==null?void 0:s.manager,"_initialize() not called before _openPopup()");const o=await Ph(e,t,r,wl(),i);return pw(e,o,ac())}async _openRedirect(e,t,r,i){await this._originValidation(e);const o=await Ph(e,t,r,wl(),i);return E_(o),new Promise(()=>{})}_initialize(e){const t=e._key();if(this.eventManagers[t]){const{manager:i,promise:o}=this.eventManagers[t];return i?Promise.resolve(i):(fn(o,"If manager is not set, promise should be"),o)}const r=this.initAndGetManager(e);return this.eventManagers[t]={promise:r},r.catch(()=>{delete this.eventManagers[t]}),r}async initAndGetManager(e){const t=await lw(e),r=new H_(e);return t.register("authEvent",i=>(Q(i==null?void 0:i.authEvent,e,"invalid-auth-event"),{status:r.onEvent(i.authEvent)?"ACK":"ERROR"}),gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER),this.eventManagers[e._key()]={manager:r},this.iframes[e._key()]=t,r}_isIframeWebStorageSupported(e,t){this.iframes[e._key()].send(el,{type:el},i=>{var s;const o=(s=i==null?void 0:i[0])==null?void 0:s[el];o!==void 0&&t(!!o),dn(e,"internal-error")},gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER)}_originValidation(e){const t=e._key();return this.originValidationPromises[t]||(this.originValidationPromises[t]=J_(e)),this.originValidationPromises[t]}get _shouldInitProactively(){return Rf()||Af()||oc()}}const bw=ww;var Ch="@firebase/auth",Rh="1.13.0";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Tw{constructor(e){this.auth=e,this.internalListeners=new Map}getUid(){var e;return this.assertAuthConfigured(),((e=this.auth.currentUser)==null?void 0:e.uid)||null}async getToken(e){return this.assertAuthConfigured(),await this.auth._initializationPromise,this.auth.currentUser?{accessToken:await this.auth.currentUser.getIdToken(e)}:null}addAuthTokenListener(e){if(this.assertAuthConfigured(),this.internalListeners.has(e))return;const t=this.auth.onIdTokenChanged(r=>{e((r==null?void 0:r.stsTokenManager.accessToken)||null)});this.internalListeners.set(e,t),this.updateProactiveRefresh()}removeAuthTokenListener(e){this.assertAuthConfigured();const t=this.internalListeners.get(e);t&&(this.internalListeners.delete(e),t(),this.updateProactiveRefresh())}assertAuthConfigured(){Q(this.auth._initializationPromise,"dependent-sdk-initialized-before-auth")}updateProactiveRefresh(){this.internalListeners.size>0?this.auth._startProactiveRefresh():this.auth._stopProactiveRefresh()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ew(n){switch(n){case"Node":return"node";case"ReactNative":return"rn";case"Worker":return"webworker";case"Cordova":return"cordova";case"WebExtension":return"web-extension";default:return}}function Iw(n){ni(new yr("auth",(e,{options:t})=>{const r=e.getProvider("app").getImmediate(),i=e.getProvider("heartbeat"),o=e.getProvider("app-check-internal"),{apiKey:s,authDomain:l}=r.options;Q(s&&!s.includes(":"),"invalid-api-key",{appName:r.name});const u={apiKey:s,authDomain:l,clientPlatform:n,apiHost:"identitytoolkit.googleapis.com",tokenApiHost:"securetoken.googleapis.com",apiScheme:"https",sdkClientVersion:Of(n)},h=new e_(r,i,o,u);return s_(h,t),h},"PUBLIC").setInstantiationMode("EXPLICIT").setInstanceCreatedCallback((e,t,r)=>{e.getProvider("auth-internal").initialize()})),ni(new yr("auth-internal",e=>{const t=sa(e.getProvider("auth").getImmediate());return(r=>new Tw(r))(t)},"PRIVATE").setInstantiationMode("EXPLICIT")),Vn(Ch,Rh,Ew(n)),Vn(Ch,Rh,"esm2020")}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Aw=5*60,Sw=cf("authIdTokenMaxAge")||Aw;let Oh=null;const xw=n=>async e=>{const t=e&&await e.getIdTokenResult(),r=t&&(new Date().getTime()-Date.parse(t.issuedAtTime))/1e3;if(r&&r>Sw)return;const i=t==null?void 0:t.token;Oh!==i&&(Oh=i,await fetch(n,{method:i?"POST":"DELETE",headers:i?{Authorization:`Bearer ${i}`}:{}}))};function kw(n=ff()){const e=Zl(n,"auth");if(e.isInitialized())return e.getImmediate();const t=o_(n,{popupRedirectResolver:bw,persistence:[O_,w_,Bf]}),r=cf("authTokenSyncURL");if(r&&typeof isSecureContext=="boolean"&&isSecureContext){const o=new URL(r,location.origin);if(location.origin===o.origin){const s=xw(o.toString());g_(t,s,()=>s(t.currentUser)),p_(t,l=>s(l))}}const i=af("auth");return i&&a_(t,`http://${i}`),t}function Pw(){var n;return((n=document.getElementsByTagName("head"))==null?void 0:n[0])??document}t_({loadJS(n){return new Promise((e,t)=>{const r=document.createElement("script");r.setAttribute("src",n),r.onload=e,r.onerror=i=>{const o=Bt("internal-error");o.customData=i,t(o)},r.type="text/javascript",r.charset="UTF-8",Pw().appendChild(r)})},gapiScript:"https://apis.google.com/js/api.js",recaptchaV2Script:"https://www.google.com/recaptcha/api.js",recaptchaEnterpriseScript:"https://www.google.com/recaptcha/enterprise.js?render="});Iw("Browser");const Kf={apiKey:"AIzaSyDgeMII4vDFmjXVKnrBYV8ane76eSzyUN8",authDomain:"overlay-runner.firebaseapp.com",databaseURL:"https://overlay-runner-default-rtdb.firebaseio.com",projectId:"overlay-runner",storageBucket:"overlay-runner.firebasestorage.app",messagingSenderId:"951272023115",appId:"1:951272023115:web:0f75edb7fb291a118119ce"};var Nh=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/var Fn,Yf;(function(){var n;/** @license

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/function e(E,v){function w(){}w.prototype=v.prototype,E.F=v.prototype,E.prototype=new w,E.prototype.constructor=E,E.D=function(I,T,S){for(var _=Array(arguments.length-2),xe=2;xe<arguments.length;xe++)_[xe-2]=arguments[xe];return v.prototype[T].apply(I,_)}}function t(){this.blockSize=-1}function r(){this.blockSize=-1,this.blockSize=64,this.g=Array(4),this.C=Array(this.blockSize),this.o=this.h=0,this.u()}e(r,t),r.prototype.u=function(){this.g[0]=1732584193,this.g[1]=4023233417,this.g[2]=2562383102,this.g[3]=271733878,this.o=this.h=0};function i(E,v,w){w||(w=0);const I=Array(16);if(typeof v=="string")for(var T=0;T<16;++T)I[T]=v.charCodeAt(w++)|v.charCodeAt(w++)<<8|v.charCodeAt(w++)<<16|v.charCodeAt(w++)<<24;else for(T=0;T<16;++T)I[T]=v[w++]|v[w++]<<8|v[w++]<<16|v[w++]<<24;v=E.g[0],w=E.g[1],T=E.g[2];let S=E.g[3],_;_=v+(S^w&(T^S))+I[0]+3614090360&4294967295,v=w+(_<<7&4294967295|_>>>25),_=S+(T^v&(w^T))+I[1]+3905402710&4294967295,S=v+(_<<12&4294967295|_>>>20),_=T+(w^S&(v^w))+I[2]+606105819&4294967295,T=S+(_<<17&4294967295|_>>>15),_=w+(v^T&(S^v))+I[3]+3250441966&4294967295,w=T+(_<<22&4294967295|_>>>10),_=v+(S^w&(T^S))+I[4]+4118548399&4294967295,v=w+(_<<7&4294967295|_>>>25),_=S+(T^v&(w^T))+I[5]+1200080426&4294967295,S=v+(_<<12&4294967295|_>>>20),_=T+(w^S&(v^w))+I[6]+2821735955&4294967295,T=S+(_<<17&4294967295|_>>>15),_=w+(v^T&(S^v))+I[7]+4249261313&4294967295,w=T+(_<<22&4294967295|_>>>10),_=v+(S^w&(T^S))+I[8]+1770035416&4294967295,v=w+(_<<7&4294967295|_>>>25),_=S+(T^v&(w^T))+I[9]+2336552879&4294967295,S=v+(_<<12&4294967295|_>>>20),_=T+(w^S&(v^w))+I[10]+4294925233&4294967295,T=S+(_<<17&4294967295|_>>>15),_=w+(v^T&(S^v))+I[11]+2304563134&4294967295,w=T+(_<<22&4294967295|_>>>10),_=v+(S^w&(T^S))+I[12]+1804603682&4294967295,v=w+(_<<7&4294967295|_>>>25),_=S+(T^v&(w^T))+I[13]+4254626195&4294967295,S=v+(_<<12&4294967295|_>>>20),_=T+(w^S&(v^w))+I[14]+2792965006&4294967295,T=S+(_<<17&4294967295|_>>>15),_=w+(v^T&(S^v))+I[15]+1236535329&4294967295,w=T+(_<<22&4294967295|_>>>10),_=v+(T^S&(w^T))+I[1]+4129170786&4294967295,v=w+(_<<5&4294967295|_>>>27),_=S+(w^T&(v^w))+I[6]+3225465664&4294967295,S=v+(_<<9&4294967295|_>>>23),_=T+(v^w&(S^v))+I[11]+643717713&4294967295,T=S+(_<<14&4294967295|_>>>18),_=w+(S^v&(T^S))+I[0]+3921069994&4294967295,w=T+(_<<20&4294967295|_>>>12),_=v+(T^S&(w^T))+I[5]+3593408605&4294967295,v=w+(_<<5&4294967295|_>>>27),_=S+(w^T&(v^w))+I[10]+38016083&4294967295,S=v+(_<<9&4294967295|_>>>23),_=T+(v^w&(S^v))+I[15]+3634488961&4294967295,T=S+(_<<14&4294967295|_>>>18),_=w+(S^v&(T^S))+I[4]+3889429448&4294967295,w=T+(_<<20&4294967295|_>>>12),_=v+(T^S&(w^T))+I[9]+568446438&4294967295,v=w+(_<<5&4294967295|_>>>27),_=S+(w^T&(v^w))+I[14]+3275163606&4294967295,S=v+(_<<9&4294967295|_>>>23),_=T+(v^w&(S^v))+I[3]+4107603335&4294967295,T=S+(_<<14&4294967295|_>>>18),_=w+(S^v&(T^S))+I[8]+1163531501&4294967295,w=T+(_<<20&4294967295|_>>>12),_=v+(T^S&(w^T))+I[13]+2850285829&4294967295,v=w+(_<<5&4294967295|_>>>27),_=S+(w^T&(v^w))+I[2]+4243563512&4294967295,S=v+(_<<9&4294967295|_>>>23),_=T+(v^w&(S^v))+I[7]+1735328473&4294967295,T=S+(_<<14&4294967295|_>>>18),_=w+(S^v&(T^S))+I[12]+2368359562&4294967295,w=T+(_<<20&4294967295|_>>>12),_=v+(w^T^S)+I[5]+4294588738&4294967295,v=w+(_<<4&4294967295|_>>>28),_=S+(v^w^T)+I[8]+2272392833&4294967295,S=v+(_<<11&4294967295|_>>>21),_=T+(S^v^w)+I[11]+1839030562&4294967295,T=S+(_<<16&4294967295|_>>>16),_=w+(T^S^v)+I[14]+4259657740&4294967295,w=T+(_<<23&4294967295|_>>>9),_=v+(w^T^S)+I[1]+2763975236&4294967295,v=w+(_<<4&4294967295|_>>>28),_=S+(v^w^T)+I[4]+1272893353&4294967295,S=v+(_<<11&4294967295|_>>>21),_=T+(S^v^w)+I[7]+4139469664&4294967295,T=S+(_<<16&4294967295|_>>>16),_=w+(T^S^v)+I[10]+3200236656&4294967295,w=T+(_<<23&4294967295|_>>>9),_=v+(w^T^S)+I[13]+681279174&4294967295,v=w+(_<<4&4294967295|_>>>28),_=S+(v^w^T)+I[0]+3936430074&4294967295,S=v+(_<<11&4294967295|_>>>21),_=T+(S^v^w)+I[3]+3572445317&4294967295,T=S+(_<<16&4294967295|_>>>16),_=w+(T^S^v)+I[6]+76029189&4294967295,w=T+(_<<23&4294967295|_>>>9),_=v+(w^T^S)+I[9]+3654602809&4294967295,v=w+(_<<4&4294967295|_>>>28),_=S+(v^w^T)+I[12]+3873151461&4294967295,S=v+(_<<11&4294967295|_>>>21),_=T+(S^v^w)+I[15]+530742520&4294967295,T=S+(_<<16&4294967295|_>>>16),_=w+(T^S^v)+I[2]+3299628645&4294967295,w=T+(_<<23&4294967295|_>>>9),_=v+(T^(w|~S))+I[0]+4096336452&4294967295,v=w+(_<<6&4294967295|_>>>26),_=S+(w^(v|~T))+I[7]+1126891415&4294967295,S=v+(_<<10&4294967295|_>>>22),_=T+(v^(S|~w))+I[14]+2878612391&4294967295,T=S+(_<<15&4294967295|_>>>17),_=w+(S^(T|~v))+I[5]+4237533241&4294967295,w=T+(_<<21&4294967295|_>>>11),_=v+(T^(w|~S))+I[12]+1700485571&4294967295,v=w+(_<<6&4294967295|_>>>26),_=S+(w^(v|~T))+I[3]+2399980690&4294967295,S=v+(_<<10&4294967295|_>>>22),_=T+(v^(S|~w))+I[10]+4293915773&4294967295,T=S+(_<<15&4294967295|_>>>17),_=w+(S^(T|~v))+I[1]+2240044497&4294967295,w=T+(_<<21&4294967295|_>>>11),_=v+(T^(w|~S))+I[8]+1873313359&4294967295,v=w+(_<<6&4294967295|_>>>26),_=S+(w^(v|~T))+I[15]+4264355552&4294967295,S=v+(_<<10&4294967295|_>>>22),_=T+(v^(S|~w))+I[6]+2734768916&4294967295,T=S+(_<<15&4294967295|_>>>17),_=w+(S^(T|~v))+I[13]+1309151649&4294967295,w=T+(_<<21&4294967295|_>>>11),_=v+(T^(w|~S))+I[4]+4149444226&4294967295,v=w+(_<<6&4294967295|_>>>26),_=S+(w^(v|~T))+I[11]+3174756917&4294967295,S=v+(_<<10&4294967295|_>>>22),_=T+(v^(S|~w))+I[2]+718787259&4294967295,T=S+(_<<15&4294967295|_>>>17),_=w+(S^(T|~v))+I[9]+3951481745&4294967295,E.g[0]=E.g[0]+v&4294967295,E.g[1]=E.g[1]+(T+(_<<21&4294967295|_>>>11))&4294967295,E.g[2]=E.g[2]+T&4294967295,E.g[3]=E.g[3]+S&4294967295}r.prototype.v=function(E,v){v===void 0&&(v=E.length);const w=v-this.blockSize,I=this.C;let T=this.h,S=0;for(;S<v;){if(T==0)for(;S<=w;)i(this,E,S),S+=this.blockSize;if(typeof E=="string"){for(;S<v;)if(I[T++]=E.charCodeAt(S++),T==this.blockSize){i(this,I),T=0;break}}else for(;S<v;)if(I[T++]=E[S++],T==this.blockSize){i(this,I),T=0;break}}this.h=T,this.o+=v},r.prototype.A=function(){var E=Array((this.h<56?this.blockSize:this.blockSize*2)-this.h);E[0]=128;for(var v=1;v<E.length-8;++v)E[v]=0;v=this.o*8;for(var w=E.length-8;w<E.length;++w)E[w]=v&255,v/=256;for(this.v(E),E=Array(16),v=0,w=0;w<4;++w)for(let I=0;I<32;I+=8)E[v++]=this.g[w]>>>I&255;return E};function o(E,v){var w=l;return Object.prototype.hasOwnProperty.call(w,E)?w[E]:w[E]=v(E)}function s(E,v){this.h=v;const w=[];let I=!0;for(let T=E.length-1;T>=0;T--){const S=E[T]|0;I&&S==v||(w[T]=S,I=!1)}this.g=w}var l={};function u(E){return-128<=E&&E<128?o(E,function(v){return new s([v|0],v<0?-1:0)}):new s([E|0],E<0?-1:0)}function h(E){if(isNaN(E)||!isFinite(E))return m;if(E<0)return C(h(-E));const v=[];let w=1;for(let I=0;E>=w;I++)v[I]=E/w|0,w*=4294967296;return new s(v,0)}function p(E,v){if(E.length==0)throw Error("number format error: empty string");if(v=v||10,v<2||36<v)throw Error("radix out of range: "+v);if(E.charAt(0)=="-")return C(p(E.substring(1),v));if(E.indexOf("-")>=0)throw Error('number format error: interior "-" character');const w=h(Math.pow(v,8));let I=m;for(let S=0;S<E.length;S+=8){var T=Math.min(8,E.length-S);const _=parseInt(E.substring(S,S+T),v);T<8?(T=h(Math.pow(v,T)),I=I.j(T).add(h(_))):(I=I.j(w),I=I.add(h(_)))}return I}var m=u(0),g=u(1),b=u(16777216);n=s.prototype,n.m=function(){if(A(this))return-C(this).m();let E=0,v=1;for(let w=0;w<this.g.length;w++){const I=this.i(w);E+=(I>=0?I:4294967296+I)*v,v*=4294967296}return E},n.toString=function(E){if(E=E||10,E<2||36<E)throw Error("radix out of range: "+E);if(P(this))return"0";if(A(this))return"-"+C(this).toString(E);const v=h(Math.pow(E,6));var w=this;let I="";for(;;){const T=G(w,v).g;w=$(w,T.j(v));let S=((w.g.length>0?w.g[0]:w.h)>>>0).toString(E);if(w=T,P(w))return S+I;for(;S.length<6;)S="0"+S;I=S+I}},n.i=function(E){return E<0?0:E<this.g.length?this.g[E]:this.h};function P(E){if(E.h!=0)return!1;for(let v=0;v<E.g.length;v++)if(E.g[v]!=0)return!1;return!0}function A(E){return E.h==-1}n.l=function(E){return E=$(this,E),A(E)?-1:P(E)?0:1};function C(E){const v=E.g.length,w=[];for(let I=0;I<v;I++)w[I]=~E.g[I];return new s(w,~E.h).add(g)}n.abs=function(){return A(this)?C(this):this},n.add=function(E){const v=Math.max(this.g.length,E.g.length),w=[];let I=0;for(let T=0;T<=v;T++){let S=I+(this.i(T)&65535)+(E.i(T)&65535),_=(S>>>16)+(this.i(T)>>>16)+(E.i(T)>>>16);I=_>>>16,S&=65535,_&=65535,w[T]=_<<16|S}return new s(w,w[w.length-1]&-2147483648?-1:0)};function $(E,v){return E.add(C(v))}n.j=function(E){if(P(this)||P(E))return m;if(A(this))return A(E)?C(this).j(C(E)):C(C(this).j(E));if(A(E))return C(this.j(C(E)));if(this.l(b)<0&&E.l(b)<0)return h(this.m()*E.m());const v=this.g.length+E.g.length,w=[];for(var I=0;I<2*v;I++)w[I]=0;for(I=0;I<this.g.length;I++)for(let T=0;T<E.g.length;T++){const S=this.i(I)>>>16,_=this.i(I)&65535,xe=E.i(T)>>>16,tt=E.i(T)&65535;w[2*I+2*T]+=_*tt,F(w,2*I+2*T),w[2*I+2*T+1]+=S*tt,F(w,2*I+2*T+1),w[2*I+2*T+1]+=_*xe,F(w,2*I+2*T+1),w[2*I+2*T+2]+=S*xe,F(w,2*I+2*T+2)}for(E=0;E<v;E++)w[E]=w[2*E+1]<<16|w[2*E];for(E=v;E<2*v;E++)w[E]=0;return new s(w,0)};function F(E,v){for(;(E[v]&65535)!=E[v];)E[v+1]+=E[v]>>>16,E[v]&=65535,v++}function V(E,v){this.g=E,this.h=v}function G(E,v){if(P(v))throw Error("division by zero");if(P(E))return new V(m,m);if(A(E))return v=G(C(E),v),new V(C(v.g),C(v.h));if(A(v))return v=G(E,C(v)),new V(C(v.g),v.h);if(E.g.length>30){if(A(E)||A(v))throw Error("slowDivide_ only works with positive integers.");for(var w=g,I=v;I.l(E)<=0;)w=z(w),I=z(I);var T=K(w,1),S=K(I,1);for(I=K(I,2),w=K(w,2);!P(I);){var _=S.add(I);_.l(E)<=0&&(T=T.add(w),S=_),I=K(I,1),w=K(w,1)}return v=$(E,T.j(v)),new V(T,v)}for(T=m;E.l(v)>=0;){for(w=Math.max(1,Math.floor(E.m()/v.m())),I=Math.ceil(Math.log(w)/Math.LN2),I=I<=48?1:Math.pow(2,I-48),S=h(w),_=S.j(v);A(_)||_.l(E)>0;)w-=I,S=h(w),_=S.j(v);P(S)&&(S=g),T=T.add(S),E=$(E,_)}return new V(T,E)}n.B=function(E){return G(this,E).h},n.and=function(E){const v=Math.max(this.g.length,E.g.length),w=[];for(let I=0;I<v;I++)w[I]=this.i(I)&E.i(I);return new s(w,this.h&E.h)},n.or=function(E){const v=Math.max(this.g.length,E.g.length),w=[];for(let I=0;I<v;I++)w[I]=this.i(I)|E.i(I);return new s(w,this.h|E.h)},n.xor=function(E){const v=Math.max(this.g.length,E.g.length),w=[];for(let I=0;I<v;I++)w[I]=this.i(I)^E.i(I);return new s(w,this.h^E.h)};function z(E){const v=E.g.length+1,w=[];for(let I=0;I<v;I++)w[I]=E.i(I)<<1|E.i(I-1)>>>31;return new s(w,E.h)}function K(E,v){const w=v>>5;v%=32;const I=E.g.length-w,T=[];for(let S=0;S<I;S++)T[S]=v>0?E.i(S+w)>>>v|E.i(S+w+1)<<32-v:E.i(S+w);return new s(T,E.h)}r.prototype.digest=r.prototype.A,r.prototype.reset=r.prototype.u,r.prototype.update=r.prototype.v,Yf=r,s.prototype.add=s.prototype.add,s.prototype.multiply=s.prototype.j,s.prototype.modulo=s.prototype.B,s.prototype.compare=s.prototype.l,s.prototype.toNumber=s.prototype.m,s.prototype.toString=s.prototype.toString,s.prototype.getBits=s.prototype.i,s.fromNumber=h,s.fromString=p,Fn=s}).apply(typeof Nh<"u"?Nh:typeof self<"u"?self:typeof window<"u"?window:{});var ss=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/var Qf,Qi,Jf,Es,El,Xf,Zf,ep;(function(){var n,e=Object.defineProperty;function t(a){a=[typeof globalThis=="object"&&globalThis,a,typeof window=="object"&&window,typeof self=="object"&&self,typeof ss=="object"&&ss];for(var d=0;d<a.length;++d){var f=a[d];if(f&&f.Math==Math)return f}throw Error("Cannot find global object")}var r=t(this);function i(a,d){if(d)e:{var f=r;a=a.split(".");for(var y=0;y<a.length-1;y++){var k=a[y];if(!(k in f))break e;f=f[k]}a=a[a.length-1],y=f[a],d=d(y),d!=y&&d!=null&&e(f,a,{configurable:!0,writable:!0,value:d})}}i("Symbol.dispose",function(a){return a||Symbol("Symbol.dispose")}),i("Array.prototype.values",function(a){return a||function(){return this[Symbol.iterator]()}}),i("Object.entries",function(a){return a||function(d){var f=[],y;for(y in d)Object.prototype.hasOwnProperty.call(d,y)&&f.push([y,d[y]]);return f}});/** @license

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/var o=o||{},s=this||self;function l(a){var d=typeof a;return d=="object"&&a!=null||d=="function"}function u(a,d,f){return a.call.apply(a.bind,arguments)}function h(a,d,f){return h=u,h.apply(null,arguments)}function p(a,d){var f=Array.prototype.slice.call(arguments,1);return function(){var y=f.slice();return y.push.apply(y,arguments),a.apply(this,y)}}function m(a,d){function f(){}f.prototype=d.prototype,a.Z=d.prototype,a.prototype=new f,a.prototype.constructor=a,a.Ob=function(y,k,O){for(var U=Array(arguments.length-2),ee=2;ee<arguments.length;ee++)U[ee-2]=arguments[ee];return d.prototype[k].apply(y,U)}}var g=typeof AsyncContext<"u"&&typeof AsyncContext.Snapshot=="function"?a=>a&&AsyncContext.Snapshot.wrap(a):a=>a;function b(a){const d=a.length;if(d>0){const f=Array(d);for(let y=0;y<d;y++)f[y]=a[y];return f}return[]}function P(a,d){for(let y=1;y<arguments.length;y++){const k=arguments[y];var f=typeof k;if(f=f!="object"?f:k?Array.isArray(k)?"array":f:"null",f=="array"||f=="object"&&typeof k.length=="number"){f=a.length||0;const O=k.length||0;a.length=f+O;for(let U=0;U<O;U++)a[f+U]=k[U]}else a.push(k)}}class A{constructor(d,f){this.i=d,this.j=f,this.h=0,this.g=null}get(){let d;return this.h>0?(this.h--,d=this.g,this.g=d.next,d.next=null):d=this.i(),d}}function C(a){s.setTimeout(()=>{throw a},0)}function $(){var a=E;let d=null;return a.g&&(d=a.g,a.g=a.g.next,a.g||(a.h=null),d.next=null),d}class F{constructor(){this.h=this.g=null}add(d,f){const y=V.get();y.set(d,f),this.h?this.h.next=y:this.g=y,this.h=y}}var V=new A(()=>new G,a=>a.reset());class G{constructor(){this.next=this.g=this.h=null}set(d,f){this.h=d,this.g=f,this.next=null}reset(){this.next=this.g=this.h=null}}let z,K=!1,E=new F,v=()=>{const a=Promise.resolve(void 0);z=()=>{a.then(w)}};function w(){for(var a;a=$();){try{a.h.call(a.g)}catch(f){C(f)}var d=V;d.j(a),d.h<100&&(d.h++,a.next=d.g,d.g=a)}K=!1}function I(){this.u=this.u,this.C=this.C}I.prototype.u=!1,I.prototype.dispose=function(){this.u||(this.u=!0,this.N())},I.prototype[Symbol.dispose]=function(){this.dispose()},I.prototype.N=function(){if(this.C)for(;this.C.length;)this.C.shift()()};function T(a,d){this.type=a,this.g=this.target=d,this.defaultPrevented=!1}T.prototype.h=function(){this.defaultPrevented=!0};var S=function(){if(!s.addEventListener||!Object.defineProperty)return!1;var a=!1,d=Object.defineProperty({},"passive",{get:function(){a=!0}});try{const f=()=>{};s.addEventListener("test",f,d),s.removeEventListener("test",f,d)}catch{}return a}();function _(a){return/^[\s\xa0]*$/.test(a)}function xe(a,d){T.call(this,a?a.type:""),this.relatedTarget=this.g=this.target=null,this.button=this.screenY=this.screenX=this.clientY=this.clientX=0,this.key="",this.metaKey=this.shiftKey=this.altKey=this.ctrlKey=!1,this.state=null,this.pointerId=0,this.pointerType="",this.i=null,a&&this.init(a,d)}m(xe,T),xe.prototype.init=function(a,d){const f=this.type=a.type,y=a.changedTouches&&a.changedTouches.length?a.changedTouches[0]:null;this.target=a.target||a.srcElement,this.g=d,d=a.relatedTarget,d||(f=="mouseover"?d=a.fromElement:f=="mouseout"&&(d=a.toElement)),this.relatedTarget=d,y?(this.clientX=y.clientX!==void 0?y.clientX:y.pageX,this.clientY=y.clientY!==void 0?y.clientY:y.pageY,this.screenX=y.screenX||0,this.screenY=y.screenY||0):(this.clientX=a.clientX!==void 0?a.clientX:a.pageX,this.clientY=a.clientY!==void 0?a.clientY:a.pageY,this.screenX=a.screenX||0,this.screenY=a.screenY||0),this.button=a.button,this.key=a.key||"",this.ctrlKey=a.ctrlKey,this.altKey=a.altKey,this.shiftKey=a.shiftKey,this.metaKey=a.metaKey,this.pointerId=a.pointerId||0,this.pointerType=a.pointerType,this.state=a.state,this.i=a,a.defaultPrevented&&xe.Z.h.call(this)},xe.prototype.h=function(){xe.Z.h.call(this);const a=this.i;a.preventDefault?a.preventDefault():a.returnValue=!1};var tt="closure_listenable_"+(Math.random()*1e6|0),Pr=0;function _n(a,d,f,y,k){this.listener=a,this.proxy=null,this.src=d,this.type=f,this.capture=!!y,this.ha=k,this.key=++Pr,this.da=this.fa=!1}function vt(a){a.da=!0,a.listener=null,a.proxy=null,a.src=null,a.ha=null}function bt(a,d,f){for(const y in a)d.call(f,a[y],y,a)}function nt(a,d){for(const f in a)d.call(void 0,a[f],f,a)}function ue(a){const d={};for(const f in a)d[f]=a[f];return d}const ke="constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");function ye(a,d){let f,y;for(let k=1;k<arguments.length;k++){y=arguments[k];for(f in y)a[f]=y[f];for(let O=0;O<ke.length;O++)f=ke[O],Object.prototype.hasOwnProperty.call(y,f)&&(a[f]=y[f])}}function Je(a){this.src=a,this.g={},this.h=0}Je.prototype.add=function(a,d,f,y,k){const O=a.toString();a=this.g[O],a||(a=this.g[O]=[],this.h++);const U=Cr(a,d,y,k);return U>-1?(d=a[U],f||(d.fa=!1)):(d=new _n(d,this.src,O,!!y,k),d.fa=f,a.push(d)),d};function Yt(a,d){const f=d.type;if(f in a.g){var y=a.g[f],k=Array.prototype.indexOf.call(y,d,void 0),O;(O=k>=0)&&Array.prototype.splice.call(y,k,1),O&&(vt(d),a.g[f].length==0&&(delete a.g[f],a.h--))}}function Cr(a,d,f,y){for(let k=0;k<a.length;++k){const O=a[k];if(!O.da&&O.listener==d&&O.capture==!!f&&O.ha==y)return k}return-1}var M="closure_lm_"+(Math.random()*1e6|0),B={};function te(a,d,f,y,k){if(Array.isArray(d)){for(let O=0;O<d.length;O++)te(a,d[O],f,y,k);return null}return f=hu(f),a&&a[tt]?a.J(d,f,l(y)?!!y.capture:!1,k):rt(a,d,f,!1,y,k)}function rt(a,d,f,y,k,O){if(!d)throw Error("Invalid event type");const U=l(k)?!!k.capture:!!k;let ee=Pa(a);if(ee||(a[M]=ee=new Je(a)),f=ee.add(d,f,y,U,O),f.proxy)return f;if(y=Ii(),f.proxy=y,y.src=a,y.listener=f,a.addEventListener)S||(k=U),k===void 0&&(k=!1),a.addEventListener(d.toString(),y,k);else if(a.attachEvent)a.attachEvent(ka(d.toString()),y);else if(a.addListener&&a.removeListener)a.addListener(y);else throw Error("addEventListener and attachEvent are unavailable.");return f}function Ii(){function a(f){return d.call(a.src,a.listener,f)}const d=Ho;return a}function Ai(a,d,f,y,k){if(Array.isArray(d))for(var O=0;O<d.length;O++)Ai(a,d[O],f,y,k);else y=l(y)?!!y.capture:!!y,f=hu(f),a&&a[tt]?(a=a.i,O=String(d).toString(),O in a.g&&(d=a.g[O],f=Cr(d,f,y,k),f>-1&&(vt(d[f]),Array.prototype.splice.call(d,f,1),d.length==0&&(delete a.g[O],a.h--)))):a&&(a=Pa(a))&&(d=a.g[d.toString()],a=-1,d&&(a=Cr(d,f,y,k)),(f=a>-1?d[a]:null)&&Rt(f))}function Rt(a){if(typeof a!="number"&&a&&!a.da){var d=a.src;if(d&&d[tt])Yt(d.i,a);else{var f=a.type,y=a.proxy;d.removeEventListener?d.removeEventListener(f,y,a.capture):d.detachEvent?d.detachEvent(ka(f),y):d.addListener&&d.removeListener&&d.removeListener(y),(f=Pa(d))?(Yt(f,a),f.h==0&&(f.src=null,d[M]=null)):vt(a)}}}function ka(a){return a in B?B[a]:B[a]="on"+a}function Ho(a,d){if(a.da)a=!0;else{d=new xe(d,this);const f=a.listener,y=a.ha||a.src;a.fa&&Rt(a),a=f.call(y,d)}return a}function Pa(a){return a=a[M],a instanceof Je?a:null}var Ca="__closure_events_fn_"+(Math.random()*1e9>>>0);function hu(a){return typeof a=="function"?a:(a[Ca]||(a[Ca]=function(d){return a.handleEvent(d)}),a[Ca])}function He(){I.call(this),this.i=new Je(this),this.M=this,this.G=null}m(He,I),He.prototype[tt]=!0,He.prototype.removeEventListener=function(a,d,f,y){Ai(this,a,d,f,y)};function Xe(a,d){var f,y=a.G;if(y)for(f=[];y;y=y.G)f.push(y);if(a=a.M,y=d.type||d,typeof d=="string")d=new T(d,a);else if(d instanceof T)d.target=d.target||a;else{var k=d;d=new T(y,a),ye(d,k)}k=!0;let O,U;if(f)for(U=f.length-1;U>=0;U--)O=d.g=f[U],k=Go(O,y,!0,d)&&k;if(O=d.g=a,k=Go(O,y,!0,d)&&k,k=Go(O,y,!1,d)&&k,f)for(U=0;U<f.length;U++)O=d.g=f[U],k=Go(O,y,!1,d)&&k}He.prototype.N=function(){if(He.Z.N.call(this),this.i){var a=this.i;for(const d in a.g){const f=a.g[d];for(let y=0;y<f.length;y++)vt(f[y]);delete a.g[d],a.h--}}this.G=null},He.prototype.J=function(a,d,f,y){return this.i.add(String(a),d,!1,f,y)},He.prototype.K=function(a,d,f,y){return this.i.add(String(a),d,!0,f,y)};function Go(a,d,f,y){if(d=a.i.g[String(d)],!d)return!0;d=d.concat();let k=!0;for(let O=0;O<d.length;++O){const U=d[O];if(U&&!U.da&&U.capture==f){const ee=U.listener,Ne=U.ha||U.src;U.fa&&Yt(a.i,U),k=ee.call(Ne,y)!==!1&&k}}return k&&!y.defaultPrevented}function bm(a,d){if(typeof a!="function")if(a&&typeof a.handleEvent=="function")a=h(a.handleEvent,a);else throw Error("Invalid listener argument");return Number(d)>2147483647?-1:s.setTimeout(a,d||0)}function du(a){a.g=bm(()=>{a.g=null,a.i&&(a.i=!1,du(a))},a.l);const d=a.h;a.h=null,a.m.apply(null,d)}class Tm extends I{constructor(d,f){super(),this.m=d,this.l=f,this.h=null,this.i=!1,this.g=null}j(d){this.h=arguments,this.g?this.i=!0:du(this)}N(){super.N(),this.g&&(s.clearTimeout(this.g),this.g=null,this.i=!1,this.h=null)}}function Si(a){I.call(this),this.h=a,this.g={}}m(Si,I);var fu=[];function pu(a){bt(a.g,function(d,f){this.g.hasOwnProperty(f)&&Rt(d)},a),a.g={}}Si.prototype.N=function(){Si.Z.N.call(this),pu(this)},Si.prototype.handleEvent=function(){throw Error("EventHandler.handleEvent not implemented")};var Ra=s.JSON.stringify,Em=s.JSON.parse,Im=class{stringify(a){return s.JSON.stringify(a,void 0)}parse(a){return s.JSON.parse(a,void 0)}};function gu(){}function mu(){}var xi={OPEN:"a",hb:"b",ERROR:"c",tb:"d"};function Oa(){T.call(this,"d")}m(Oa,T);function Na(){T.call(this,"c")}m(Na,T);var Zn={},yu=null;function Ko(){return yu=yu||new He}Zn.Ia="serverreachability";function vu(a){T.call(this,Zn.Ia,a)}m(vu,T);function ki(a){const d=Ko();Xe(d,new vu(d))}Zn.STAT_EVENT="statevent";function _u(a,d){T.call(this,Zn.STAT_EVENT,a),this.stat=d}m(_u,T);function Ze(a){const d=Ko();Xe(d,new _u(d,a))}Zn.Ja="timingevent";function wu(a,d){T.call(this,Zn.Ja,a),this.size=d}m(wu,T);function Pi(a,d){if(typeof a!="function")throw Error("Fn must not be null and must be a function");return s.setTimeout(function(){a()},d)}function Ci(){this.g=!0}Ci.prototype.ua=function(){this.g=!1};function Am(a,d,f,y,k,O){a.info(function(){if(a.g)if(O){var U="",ee=O.split("&");for(let de=0;de<ee.length;de++){var Ne=ee[de].split("=");if(Ne.length>1){const Ue=Ne[0];Ne=Ne[1];const Nt=Ue.split("_");U=Nt.length>=2&&Nt[1]=="type"?U+(Ue+"="+Ne+"&"):U+(Ue+"=redacted&")}}}else U=null;else U=O;return"XMLHTTP REQ ("+y+") [attempt "+k+"]: "+d+`
`+f+`
`+U})}function Sm(a,d,f,y,k,O,U){a.info(function(){return"XMLHTTP RESP ("+y+") [ attempt "+k+"]: "+d+`
`+f+`
`+O+" "+U})}function Rr(a,d,f,y){a.info(function(){return"XMLHTTP TEXT ("+d+"): "+km(a,f)+(y?" "+y:"")})}function xm(a,d){a.info(function(){return"TIMEOUT: "+d})}Ci.prototype.info=function(){};function km(a,d){if(!a.g)return d;if(!d)return null;try{const O=JSON.parse(d);if(O){for(a=0;a<O.length;a++)if(Array.isArray(O[a])){var f=O[a];if(!(f.length<2)){var y=f[1];if(Array.isArray(y)&&!(y.length<1)){var k=y[0];if(k!="noop"&&k!="stop"&&k!="close")for(let U=1;U<y.length;U++)y[U]=""}}}}return Ra(O)}catch{return d}}var Yo={NO_ERROR:0,cb:1,qb:2,pb:3,kb:4,ob:5,rb:6,Ga:7,TIMEOUT:8,ub:9},bu={ib:"complete",Fb:"success",ERROR:"error",Ga:"abort",xb:"ready",yb:"readystatechange",TIMEOUT:"timeout",sb:"incrementaldata",wb:"progress",lb:"downloadprogress",Nb:"uploadprogress"},Tu;function Da(){}m(Da,gu),Da.prototype.g=function(){return new XMLHttpRequest},Tu=new Da;function Ri(a){return encodeURIComponent(String(a))}function Pm(a){var d=1;a=a.split(":");const f=[];for(;d>0&&a.length;)f.push(a.shift()),d--;return a.length&&f.push(a.join(":")),f}function wn(a,d,f,y){this.j=a,this.i=d,this.l=f,this.S=y||1,this.V=new Si(this),this.H=45e3,this.J=null,this.o=!1,this.u=this.B=this.A=this.M=this.F=this.T=this.D=null,this.G=[],this.g=null,this.C=0,this.m=this.v=null,this.X=-1,this.K=!1,this.P=0,this.O=null,this.W=this.L=this.U=this.R=!1,this.h=new Eu}function Eu(){this.i=null,this.g="",this.h=!1}var Iu={},Ma={};function La(a,d,f){a.M=1,a.A=Jo(Ot(d)),a.u=f,a.R=!0,Au(a,null)}function Au(a,d){a.F=Date.now(),Qo(a),a.B=Ot(a.A);var f=a.B,y=a.S;Array.isArray(y)||(y=[String(y)]),Fu(f.i,"t",y),a.C=0,f=a.j.L,a.h=new Eu,a.g=nh(a.j,f?d:null,!a.u),a.P>0&&(a.O=new Tm(h(a.Y,a,a.g),a.P)),d=a.V,f=a.g,y=a.ba;var k="readystatechange";Array.isArray(k)||(k&&(fu[0]=k.toString()),k=fu);for(let O=0;O<k.length;O++){const U=te(f,k[O],y||d.handleEvent,!1,d.h||d);if(!U)break;d.g[U.key]=U}d=a.J?ue(a.J):{},a.u?(a.v||(a.v="POST"),d["Content-Type"]="application/x-www-form-urlencoded",a.g.ea(a.B,a.v,a.u,d)):(a.v="GET",a.g.ea(a.B,a.v,null,d)),ki(),Am(a.i,a.v,a.B,a.l,a.S,a.u)}wn.prototype.ba=function(a){a=a.target;const d=this.O;d&&En(a)==3?d.j():this.Y(a)},wn.prototype.Y=function(a){try{if(a==this.g)e:{const ee=En(this.g),Ne=this.g.ya(),de=this.g.ca();if(!(ee<3)&&(ee!=3||this.g&&(this.h.h||this.g.la()||Wu(this.g)))){this.K||ee!=4||Ne==7||(Ne==8||de<=0?ki(3):ki(2)),Va(this);var d=this.g.ca();this.X=d;var f=Cm(this);if(this.o=d==200,Sm(this.i,this.v,this.B,this.l,this.S,ee,d),this.o){if(this.U&&!this.L){t:{if(this.g){var y,k=this.g;if((y=k.g?k.g.getResponseHeader("X-HTTP-Initial-Response"):null)&&!_(y)){var O=y;break t}}O=null}if(a=O)Rr(this.i,this.l,a,"Initial handshake response via X-HTTP-Initial-Response"),this.L=!0,Fa(this,a);else{this.o=!1,this.m=3,Ze(12),er(this),Oi(this);break e}}if(this.R){a=!0;let Ue;for(;!this.K&&this.C<f.length;)if(Ue=Rm(this,f),Ue==Ma){ee==4&&(this.m=4,Ze(14),a=!1),Rr(this.i,this.l,null,"[Incomplete Response]");break}else if(Ue==Iu){this.m=4,Ze(15),Rr(this.i,this.l,f,"[Invalid Chunk]"),a=!1;break}else Rr(this.i,this.l,Ue,null),Fa(this,Ue);if(Su(this)&&this.C!=0&&(this.h.g=this.h.g.slice(this.C),this.C=0),ee!=4||f.length!=0||this.h.h||(this.m=1,Ze(16),a=!1),this.o=this.o&&a,!a)Rr(this.i,this.l,f,"[Invalid Chunked Response]"),er(this),Oi(this);else if(f.length>0&&!this.W){this.W=!0;var U=this.j;U.g==this&&U.aa&&!U.P&&(U.j.info("Great, no buffering proxy detected. Bytes received: "+f.length),Ha(U),U.P=!0,Ze(11))}}else Rr(this.i,this.l,f,null),Fa(this,f);ee==4&&er(this),this.o&&!this.K&&(ee==4?Xu(this.j,this):(this.o=!1,Qo(this)))}else Wm(this.g),d==400&&f.indexOf("Unknown SID")>0?(this.m=3,Ze(12)):(this.m=0,Ze(13)),er(this),Oi(this)}}}catch{}finally{}};function Cm(a){if(!Su(a))return a.g.la();const d=Wu(a.g);if(d==="")return"";let f="";const y=d.length,k=En(a.g)==4;if(!a.h.i){if(typeof TextDecoder>"u")return er(a),Oi(a),"";a.h.i=new s.TextDecoder}for(let O=0;O<y;O++)a.h.h=!0,f+=a.h.i.decode(d[O],{stream:!(k&&O==y-1)});return d.length=0,a.h.g+=f,a.C=0,a.h.g}function Su(a){return a.g?a.v=="GET"&&a.M!=2&&a.j.Aa:!1}function Rm(a,d){var f=a.C,y=d.indexOf(`
`,f);return y==-1?Ma:(f=Number(d.substring(f,y)),isNaN(f)?Iu:(y+=1,y+f>d.length?Ma:(d=d.slice(y,y+f),a.C=y+f,d)))}wn.prototype.cancel=function(){this.K=!0,er(this)};function Qo(a){a.T=Date.now()+a.H,xu(a,a.H)}function xu(a,d){if(a.D!=null)throw Error("WatchDog timer not null");a.D=Pi(h(a.aa,a),d)}function Va(a){a.D&&(s.clearTimeout(a.D),a.D=null)}wn.prototype.aa=function(){this.D=null;const a=Date.now();a-this.T>=0?(xm(this.i,this.B),this.M!=2&&(ki(),Ze(17)),er(this),this.m=2,Oi(this)):xu(this,this.T-a)};function Oi(a){a.j.I==0||a.K||Xu(a.j,a)}function er(a){Va(a);var d=a.O;d&&typeof d.dispose=="function"&&d.dispose(),a.O=null,pu(a.V),a.g&&(d=a.g,a.g=null,d.abort(),d.dispose())}function Fa(a,d){try{var f=a.j;if(f.I!=0&&(f.g==a||Ua(f.h,a))){if(!a.L&&Ua(f.h,a)&&f.I==3){try{var y=f.Ba.g.parse(d)}catch{y=null}if(Array.isArray(y)&&y.length==3){var k=y;if(k[0]==0){e:if(!f.v){if(f.g)if(f.g.F+3e3<a.F)ns(f),es(f);else break e;Wa(f),Ze(18)}}else f.xa=k[1],0<f.xa-f.K&&k[2]<37500&&f.F&&f.A==0&&!f.C&&(f.C=Pi(h(f.Va,f),6e3));Cu(f.h)<=1&&f.ta&&(f.ta=void 0)}else nr(f,11)}else if((a.L||f.g==a)&&ns(f),!_(d))for(k=f.Ba.g.parse(d),d=0;d<k.length;d++){let de=k[d];const Ue=de[0];if(!(Ue<=f.K))if(f.K=Ue,de=de[1],f.I==2)if(de[0]=="c"){f.M=de[1],f.ba=de[2];const Nt=de[3];Nt!=null&&(f.ka=Nt,f.j.info("VER="+f.ka));const rr=de[4];rr!=null&&(f.za=rr,f.j.info("SVER="+f.za));const In=de[5];In!=null&&typeof In=="number"&&In>0&&(y=1.5*In,f.O=y,f.j.info("backChannelRequestTimeoutMs_="+y)),y=f;const An=a.g;if(An){const is=An.g?An.g.getResponseHeader("X-Client-Wire-Protocol"):null;if(is){var O=y.h;O.g||is.indexOf("spdy")==-1&&is.indexOf("quic")==-1&&is.indexOf("h2")==-1||(O.j=O.l,O.g=new Set,O.h&&(qa(O,O.h),O.h=null))}if(y.G){const Ga=An.g?An.g.getResponseHeader("X-HTTP-Session-Id"):null;Ga&&(y.wa=Ga,ge(y.J,y.G,Ga))}}f.I=3,f.l&&f.l.ra(),f.aa&&(f.T=Date.now()-a.F,f.j.info("Handshake RTT: "+f.T+"ms")),y=f;var U=a;if(y.na=th(y,y.L?y.ba:null,y.W),U.L){Ru(y.h,U);var ee=U,Ne=y.O;Ne&&(ee.H=Ne),ee.D&&(Va(ee),Qo(ee)),y.g=U}else Qu(y);f.i.length>0&&ts(f)}else de[0]!="stop"&&de[0]!="close"||nr(f,7);else f.I==3&&(de[0]=="stop"||de[0]=="close"?de[0]=="stop"?nr(f,7):za(f):de[0]!="noop"&&f.l&&f.l.qa(de),f.A=0)}}ki(4)}catch{}}var Om=class{constructor(a,d){this.g=a,this.map=d}};function ku(a){this.l=a||10,s.PerformanceNavigationTiming?(a=s.performance.getEntriesByType("navigation"),a=a.length>0&&(a[0].nextHopProtocol=="hq"||a[0].nextHopProtocol=="h2")):a=!!(s.chrome&&s.chrome.loadTimes&&s.chrome.loadTimes()&&s.chrome.loadTimes().wasFetchedViaSpdy),this.j=a?this.l:1,this.g=null,this.j>1&&(this.g=new Set),this.h=null,this.i=[]}function Pu(a){return a.h?!0:a.g?a.g.size>=a.j:!1}function Cu(a){return a.h?1:a.g?a.g.size:0}function Ua(a,d){return a.h?a.h==d:a.g?a.g.has(d):!1}function qa(a,d){a.g?a.g.add(d):a.h=d}function Ru(a,d){a.h&&a.h==d?a.h=null:a.g&&a.g.has(d)&&a.g.delete(d)}ku.prototype.cancel=function(){if(this.i=Ou(this),this.h)this.h.cancel(),this.h=null;else if(this.g&&this.g.size!==0){for(const a of this.g.values())a.cancel();this.g.clear()}};function Ou(a){if(a.h!=null)return a.i.concat(a.h.G);if(a.g!=null&&a.g.size!==0){let d=a.i;for(const f of a.g.values())d=d.concat(f.G);return d}return b(a.i)}var Nu=RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");function Nm(a,d){if(a){a=a.split("&");for(let f=0;f<a.length;f++){const y=a[f].indexOf("=");let k,O=null;y>=0?(k=a[f].substring(0,y),O=a[f].substring(y+1)):k=a[f],d(k,O?decodeURIComponent(O.replace(/\+/g," ")):"")}}}function bn(a){this.g=this.o=this.j="",this.u=null,this.m=this.h="",this.l=!1;let d;a instanceof bn?(this.l=a.l,Ni(this,a.j),this.o=a.o,this.g=a.g,Di(this,a.u),this.h=a.h,Ba(this,Uu(a.i)),this.m=a.m):a&&(d=String(a).match(Nu))?(this.l=!1,Ni(this,d[1]||"",!0),this.o=Mi(d[2]||""),this.g=Mi(d[3]||"",!0),Di(this,d[4]),this.h=Mi(d[5]||"",!0),Ba(this,d[6]||"",!0),this.m=Mi(d[7]||"")):(this.l=!1,this.i=new Vi(null,this.l))}bn.prototype.toString=function(){const a=[];var d=this.j;d&&a.push(Li(d,Du,!0),":");var f=this.g;return(f||d=="file")&&(a.push("//"),(d=this.o)&&a.push(Li(d,Du,!0),"@"),a.push(Ri(f).replace(/%25([0-9a-fA-F]{2})/g,"%$1")),f=this.u,f!=null&&a.push(":",String(f))),(f=this.h)&&(this.g&&f.charAt(0)!="/"&&a.push("/"),a.push(Li(f,f.charAt(0)=="/"?Lm:Mm,!0))),(f=this.i.toString())&&a.push("?",f),(f=this.m)&&a.push("#",Li(f,Fm)),a.join("")},bn.prototype.resolve=function(a){const d=Ot(this);let f=!!a.j;f?Ni(d,a.j):f=!!a.o,f?d.o=a.o:f=!!a.g,f?d.g=a.g:f=a.u!=null;var y=a.h;if(f)Di(d,a.u);else if(f=!!a.h){if(y.charAt(0)!="/")if(this.g&&!this.h)y="/"+y;else{var k=d.h.lastIndexOf("/");k!=-1&&(y=d.h.slice(0,k+1)+y)}if(k=y,k==".."||k==".")y="";else if(k.indexOf("./")!=-1||k.indexOf("/.")!=-1){y=k.lastIndexOf("/",0)==0,k=k.split("/");const O=[];for(let U=0;U<k.length;){const ee=k[U++];ee=="."?y&&U==k.length&&O.push(""):ee==".."?((O.length>1||O.length==1&&O[0]!="")&&O.pop(),y&&U==k.length&&O.push("")):(O.push(ee),y=!0)}y=O.join("/")}else y=k}return f?d.h=y:f=a.i.toString()!=="",f?Ba(d,Uu(a.i)):f=!!a.m,f&&(d.m=a.m),d};function Ot(a){return new bn(a)}function Ni(a,d,f){a.j=f?Mi(d,!0):d,a.j&&(a.j=a.j.replace(/:$/,""))}function Di(a,d){if(d){if(d=Number(d),isNaN(d)||d<0)throw Error("Bad port number "+d);a.u=d}else a.u=null}function Ba(a,d,f){d instanceof Vi?(a.i=d,Um(a.i,a.l)):(f||(d=Li(d,Vm)),a.i=new Vi(d,a.l))}function ge(a,d,f){a.i.set(d,f)}function Jo(a){return ge(a,"zx",Math.floor(Math.random()*2147483648).toString(36)+Math.abs(Math.floor(Math.random()*2147483648)^Date.now()).toString(36)),a}function Mi(a,d){return a?d?decodeURI(a.replace(/%25/g,"%2525")):decodeURIComponent(a):""}function Li(a,d,f){return typeof a=="string"?(a=encodeURI(a).replace(d,Dm),f&&(a=a.replace(/%25([0-9a-fA-F]{2})/g,"%$1")),a):null}function Dm(a){return a=a.charCodeAt(0),"%"+(a>>4&15).toString(16)+(a&15).toString(16)}var Du=/[#\/\?@]/g,Mm=/[#\?:]/g,Lm=/[#\?]/g,Vm=/[#\?@]/g,Fm=/#/g;function Vi(a,d){this.h=this.g=null,this.i=a||null,this.j=!!d}function tr(a){a.g||(a.g=new Map,a.h=0,a.i&&Nm(a.i,function(d,f){a.add(decodeURIComponent(d.replace(/\+/g," ")),f)}))}n=Vi.prototype,n.add=function(a,d){tr(this),this.i=null,a=Or(this,a);let f=this.g.get(a);return f||this.g.set(a,f=[]),f.push(d),this.h+=1,this};function Mu(a,d){tr(a),d=Or(a,d),a.g.has(d)&&(a.i=null,a.h-=a.g.get(d).length,a.g.delete(d))}function Lu(a,d){return tr(a),d=Or(a,d),a.g.has(d)}n.forEach=function(a,d){tr(this),this.g.forEach(function(f,y){f.forEach(function(k){a.call(d,k,y,this)},this)},this)};function Vu(a,d){tr(a);let f=[];if(typeof d=="string")Lu(a,d)&&(f=f.concat(a.g.get(Or(a,d))));else for(a=Array.from(a.g.values()),d=0;d<a.length;d++)f=f.concat(a[d]);return f}n.set=function(a,d){return tr(this),this.i=null,a=Or(this,a),Lu(this,a)&&(this.h-=this.g.get(a).length),this.g.set(a,[d]),this.h+=1,this},n.get=function(a,d){return a?(a=Vu(this,a),a.length>0?String(a[0]):d):d};function Fu(a,d,f){Mu(a,d),f.length>0&&(a.i=null,a.g.set(Or(a,d),b(f)),a.h+=f.length)}n.toString=function(){if(this.i)return this.i;if(!this.g)return"";const a=[],d=Array.from(this.g.keys());for(let y=0;y<d.length;y++){var f=d[y];const k=Ri(f);f=Vu(this,f);for(let O=0;O<f.length;O++){let U=k;f[O]!==""&&(U+="="+Ri(f[O])),a.push(U)}}return this.i=a.join("&")};function Uu(a){const d=new Vi;return d.i=a.i,a.g&&(d.g=new Map(a.g),d.h=a.h),d}function Or(a,d){return d=String(d),a.j&&(d=d.toLowerCase()),d}function Um(a,d){d&&!a.j&&(tr(a),a.i=null,a.g.forEach(function(f,y){const k=y.toLowerCase();y!=k&&(Mu(this,y),Fu(this,k,f))},a)),a.j=d}function qm(a,d){const f=new Ci;if(s.Image){const y=new Image;y.onload=p(Tn,f,"TestLoadImage: loaded",!0,d,y),y.onerror=p(Tn,f,"TestLoadImage: error",!1,d,y),y.onabort=p(Tn,f,"TestLoadImage: abort",!1,d,y),y.ontimeout=p(Tn,f,"TestLoadImage: timeout",!1,d,y),s.setTimeout(function(){y.ontimeout&&y.ontimeout()},1e4),y.src=a}else d(!1)}function Bm(a,d){const f=new Ci,y=new AbortController,k=setTimeout(()=>{y.abort(),Tn(f,"TestPingServer: timeout",!1,d)},1e4);fetch(a,{signal:y.signal}).then(O=>{clearTimeout(k),O.ok?Tn(f,"TestPingServer: ok",!0,d):Tn(f,"TestPingServer: server error",!1,d)}).catch(()=>{clearTimeout(k),Tn(f,"TestPingServer: error",!1,d)})}function Tn(a,d,f,y,k){try{k&&(k.onload=null,k.onerror=null,k.onabort=null,k.ontimeout=null),y(f)}catch{}}function $m(){this.g=new Im}function $a(a){this.i=a.Sb||null,this.h=a.ab||!1}m($a,gu),$a.prototype.g=function(){return new Xo(this.i,this.h)};function Xo(a,d){He.call(this),this.H=a,this.o=d,this.m=void 0,this.status=this.readyState=0,this.responseType=this.responseText=this.response=this.statusText="",this.onreadystatechange=null,this.A=new Headers,this.h=null,this.F="GET",this.D="",this.g=!1,this.B=this.j=this.l=null,this.v=new AbortController}m(Xo,He),n=Xo.prototype,n.open=function(a,d){if(this.readyState!=0)throw this.abort(),Error("Error reopening a connection");this.F=a,this.D=d,this.readyState=1,Ui(this)},n.send=function(a){if(this.readyState!=1)throw this.abort(),Error("need to call open() first. ");if(this.v.signal.aborted)throw this.abort(),Error("Request was aborted.");this.g=!0;const d={headers:this.A,method:this.F,credentials:this.m,cache:void 0,signal:this.v.signal};a&&(d.body=a),(this.H||s).fetch(new Request(this.D,d)).then(this.Pa.bind(this),this.ga.bind(this))},n.abort=function(){this.response=this.responseText="",this.A=new Headers,this.status=0,this.v.abort(),this.j&&this.j.cancel("Request was aborted.").catch(()=>{}),this.readyState>=1&&this.g&&this.readyState!=4&&(this.g=!1,Fi(this)),this.readyState=0},n.Pa=function(a){if(this.g&&(this.l=a,this.h||(this.status=this.l.status,this.statusText=this.l.statusText,this.h=a.headers,this.readyState=2,Ui(this)),this.g&&(this.readyState=3,Ui(this),this.g)))if(this.responseType==="arraybuffer")a.arrayBuffer().then(this.Na.bind(this),this.ga.bind(this));else if(typeof s.ReadableStream<"u"&&"body"in a){if(this.j=a.body.getReader(),this.o){if(this.responseType)throw Error('responseType must be empty for "streamBinaryChunks" mode responses.');this.response=[]}else this.response=this.responseText="",this.B=new TextDecoder;qu(this)}else a.text().then(this.Oa.bind(this),this.ga.bind(this))};function qu(a){a.j.read().then(a.Ma.bind(a)).catch(a.ga.bind(a))}n.Ma=function(a){if(this.g){if(this.o&&a.value)this.response.push(a.value);else if(!this.o){var d=a.value?a.value:new Uint8Array(0);(d=this.B.decode(d,{stream:!a.done}))&&(this.response=this.responseText+=d)}a.done?Fi(this):Ui(this),this.readyState==3&&qu(this)}},n.Oa=function(a){this.g&&(this.response=this.responseText=a,Fi(this))},n.Na=function(a){this.g&&(this.response=a,Fi(this))},n.ga=function(){this.g&&Fi(this)};function Fi(a){a.readyState=4,a.l=null,a.j=null,a.B=null,Ui(a)}n.setRequestHeader=function(a,d){this.A.append(a,d)},n.getResponseHeader=function(a){return this.h&&this.h.get(a.toLowerCase())||""},n.getAllResponseHeaders=function(){if(!this.h)return"";const a=[],d=this.h.entries();for(var f=d.next();!f.done;)f=f.value,a.push(f[0]+": "+f[1]),f=d.next();return a.join(`\r
`)};function Ui(a){a.onreadystatechange&&a.onreadystatechange.call(a)}Object.defineProperty(Xo.prototype,"withCredentials",{get:function(){return this.m==="include"},set:function(a){this.m=a?"include":"same-origin"}});function Bu(a){let d="";return bt(a,function(f,y){d+=y,d+=":",d+=f,d+=`\r
`}),d}function ja(a,d,f){e:{for(y in f){var y=!1;break e}y=!0}y||(f=Bu(f),typeof a=="string"?f!=null&&Ri(f):ge(a,d,f))}function be(a){He.call(this),this.headers=new Map,this.L=a||null,this.h=!1,this.g=null,this.D="",this.o=0,this.l="",this.j=this.B=this.v=this.A=!1,this.m=null,this.F="",this.H=!1}m(be,He);var jm=/^https?$/i,zm=["POST","PUT"];n=be.prototype,n.Fa=function(a){this.H=a},n.ea=function(a,d,f,y){if(this.g)throw Error("[goog.net.XhrIo] Object is active with another request="+this.D+"; newUri="+a);d=d?d.toUpperCase():"GET",this.D=a,this.l="",this.o=0,this.A=!1,this.h=!0,this.g=this.L?this.L.g():Tu.g(),this.g.onreadystatechange=g(h(this.Ca,this));try{this.B=!0,this.g.open(d,String(a),!0),this.B=!1}catch(O){$u(this,O);return}if(a=f||"",f=new Map(this.headers),y)if(Object.getPrototypeOf(y)===Object.prototype)for(var k in y)f.set(k,y[k]);else if(typeof y.keys=="function"&&typeof y.get=="function")for(const O of y.keys())f.set(O,y.get(O));else throw Error("Unknown input type for opt_headers: "+String(y));y=Array.from(f.keys()).find(O=>O.toLowerCase()=="content-type"),k=s.FormData&&a instanceof s.FormData,!(Array.prototype.indexOf.call(zm,d,void 0)>=0)||y||k||f.set("Content-Type","application/x-www-form-urlencoded;charset=utf-8");for(const[O,U]of f)this.g.setRequestHeader(O,U);this.F&&(this.g.responseType=this.F),"withCredentials"in this.g&&this.g.withCredentials!==this.H&&(this.g.withCredentials=this.H);try{this.m&&(clearTimeout(this.m),this.m=null),this.v=!0,this.g.send(a),this.v=!1}catch(O){$u(this,O)}};function $u(a,d){a.h=!1,a.g&&(a.j=!0,a.g.abort(),a.j=!1),a.l=d,a.o=5,ju(a),Zo(a)}function ju(a){a.A||(a.A=!0,Xe(a,"complete"),Xe(a,"error"))}n.abort=function(a){this.g&&this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1,this.o=a||7,Xe(this,"complete"),Xe(this,"abort"),Zo(this))},n.N=function(){this.g&&(this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1),Zo(this,!0)),be.Z.N.call(this)},n.Ca=function(){this.u||(this.B||this.v||this.j?zu(this):this.Xa())},n.Xa=function(){zu(this)};function zu(a){if(a.h&&typeof o<"u"){if(a.v&&En(a)==4)setTimeout(a.Ca.bind(a),0);else if(Xe(a,"readystatechange"),En(a)==4){a.h=!1;try{const O=a.ca();e:switch(O){case 200:case 201:case 202:case 204:case 206:case 304:case 1223:var d=!0;break e;default:d=!1}var f;if(!(f=d)){var y;if(y=O===0){let U=String(a.D).match(Nu)[1]||null;!U&&s.self&&s.self.location&&(U=s.self.location.protocol.slice(0,-1)),y=!jm.test(U?U.toLowerCase():"")}f=y}if(f)Xe(a,"complete"),Xe(a,"success");else{a.o=6;try{var k=En(a)>2?a.g.statusText:""}catch{k=""}a.l=k+" ["+a.ca()+"]",ju(a)}}finally{Zo(a)}}}}function Zo(a,d){if(a.g){a.m&&(clearTimeout(a.m),a.m=null);const f=a.g;a.g=null,d||Xe(a,"ready");try{f.onreadystatechange=null}catch{}}}n.isActive=function(){return!!this.g};function En(a){return a.g?a.g.readyState:0}n.ca=function(){try{return En(this)>2?this.g.status:-1}catch{return-1}},n.la=function(){try{return this.g?this.g.responseText:""}catch{return""}},n.La=function(a){if(this.g){var d=this.g.responseText;return a&&d.indexOf(a)==0&&(d=d.substring(a.length)),Em(d)}};function Wu(a){try{if(!a.g)return null;if("response"in a.g)return a.g.response;switch(a.F){case"":case"text":return a.g.responseText;case"arraybuffer":if("mozResponseArrayBuffer"in a.g)return a.g.mozResponseArrayBuffer}return null}catch{return null}}function Wm(a){const d={};a=(a.g&&En(a)>=2&&a.g.getAllResponseHeaders()||"").split(`\r
`);for(let y=0;y<a.length;y++){if(_(a[y]))continue;var f=Pm(a[y]);const k=f[0];if(f=f[1],typeof f!="string")continue;f=f.trim();const O=d[k]||[];d[k]=O,O.push(f)}nt(d,function(y){return y.join(", ")})}n.ya=function(){return this.o},n.Ha=function(){return typeof this.l=="string"?this.l:String(this.l)};function qi(a,d,f){return f&&f.internalChannelParams&&f.internalChannelParams[a]||d}function Hu(a){this.za=0,this.i=[],this.j=new Ci,this.ba=this.na=this.J=this.W=this.g=this.wa=this.G=this.H=this.u=this.U=this.o=null,this.Ya=this.V=0,this.Sa=qi("failFast",!1,a),this.F=this.C=this.v=this.m=this.l=null,this.X=!0,this.xa=this.K=-1,this.Y=this.A=this.D=0,this.Qa=qi("baseRetryDelayMs",5e3,a),this.Za=qi("retryDelaySeedMs",1e4,a),this.Ta=qi("forwardChannelMaxRetries",2,a),this.va=qi("forwardChannelRequestTimeoutMs",2e4,a),this.ma=a&&a.xmlHttpFactory||void 0,this.Ua=a&&a.Rb||void 0,this.Aa=a&&a.useFetchStreams||!1,this.O=void 0,this.L=a&&a.supportsCrossDomainXhr||!1,this.M="",this.h=new ku(a&&a.concurrentRequestLimit),this.Ba=new $m,this.S=a&&a.fastHandshake||!1,this.R=a&&a.encodeInitMessageHeaders||!1,this.S&&this.R&&(this.R=!1),this.Ra=a&&a.Pb||!1,a&&a.ua&&this.j.ua(),a&&a.forceLongPolling&&(this.X=!1),this.aa=!this.S&&this.X&&a&&a.detectBufferingProxy||!1,this.ia=void 0,a&&a.longPollingTimeout&&a.longPollingTimeout>0&&(this.ia=a.longPollingTimeout),this.ta=void 0,this.T=0,this.P=!1,this.ja=this.B=null}n=Hu.prototype,n.ka=8,n.I=1,n.connect=function(a,d,f,y){Ze(0),this.W=a,this.H=d||{},f&&y!==void 0&&(this.H.OSID=f,this.H.OAID=y),this.F=this.X,this.J=th(this,null,this.W),ts(this)};function za(a){if(Gu(a),a.I==3){var d=a.V++,f=Ot(a.J);if(ge(f,"SID",a.M),ge(f,"RID",d),ge(f,"TYPE","terminate"),Bi(a,f),d=new wn(a,a.j,d),d.M=2,d.A=Jo(Ot(f)),f=!1,s.navigator&&s.navigator.sendBeacon)try{f=s.navigator.sendBeacon(d.A.toString(),"")}catch{}!f&&s.Image&&(new Image().src=d.A,f=!0),f||(d.g=nh(d.j,null),d.g.ea(d.A)),d.F=Date.now(),Qo(d)}eh(a)}function es(a){a.g&&(Ha(a),a.g.cancel(),a.g=null)}function Gu(a){es(a),a.v&&(s.clearTimeout(a.v),a.v=null),ns(a),a.h.cancel(),a.m&&(typeof a.m=="number"&&s.clearTimeout(a.m),a.m=null)}function ts(a){if(!Pu(a.h)&&!a.m){a.m=!0;var d=a.Ea;z||v(),K||(z(),K=!0),E.add(d,a),a.D=0}}function Hm(a,d){return Cu(a.h)>=a.h.j-(a.m?1:0)?!1:a.m?(a.i=d.G.concat(a.i),!0):a.I==1||a.I==2||a.D>=(a.Sa?0:a.Ta)?!1:(a.m=Pi(h(a.Ea,a,d),Zu(a,a.D)),a.D++,!0)}n.Ea=function(a){if(this.m)if(this.m=null,this.I==1){if(!a){this.V=Math.floor(Math.random()*1e5),a=this.V++;const k=new wn(this,this.j,a);let O=this.o;if(this.U&&(O?(O=ue(O),ye(O,this.U)):O=this.U),this.u!==null||this.R||(k.J=O,O=null),this.S)e:{for(var d=0,f=0;f<this.i.length;f++){t:{var y=this.i[f];if("__data__"in y.map&&(y=y.map.__data__,typeof y=="string")){y=y.length;break t}y=void 0}if(y===void 0)break;if(d+=y,d>4096){d=f;break e}if(d===4096||f===this.i.length-1){d=f+1;break e}}d=1e3}else d=1e3;d=Yu(this,k,d),f=Ot(this.J),ge(f,"RID",a),ge(f,"CVER",22),this.G&&ge(f,"X-HTTP-Session-Id",this.G),Bi(this,f),O&&(this.R?d="headers="+Ri(Bu(O))+"&"+d:this.u&&ja(f,this.u,O)),qa(this.h,k),this.Ra&&ge(f,"TYPE","init"),this.S?(ge(f,"$req",d),ge(f,"SID","null"),k.U=!0,La(k,f,null)):La(k,f,d),this.I=2}}else this.I==3&&(a?Ku(this,a):this.i.length==0||Pu(this.h)||Ku(this))};function Ku(a,d){var f;d?f=d.l:f=a.V++;const y=Ot(a.J);ge(y,"SID",a.M),ge(y,"RID",f),ge(y,"AID",a.K),Bi(a,y),a.u&&a.o&&ja(y,a.u,a.o),f=new wn(a,a.j,f,a.D+1),a.u===null&&(f.J=a.o),d&&(a.i=d.G.concat(a.i)),d=Yu(a,f,1e3),f.H=Math.round(a.va*.5)+Math.round(a.va*.5*Math.random()),qa(a.h,f),La(f,y,d)}function Bi(a,d){a.H&&bt(a.H,function(f,y){ge(d,y,f)}),a.l&&bt({},function(f,y){ge(d,y,f)})}function Yu(a,d,f){f=Math.min(a.i.length,f);const y=a.l?h(a.l.Ka,a.l,a):null;e:{var k=a.i;let ee=-1;for(;;){const Ne=["count="+f];ee==-1?f>0?(ee=k[0].g,Ne.push("ofs="+ee)):ee=0:Ne.push("ofs="+ee);let de=!0;for(let Ue=0;Ue<f;Ue++){var O=k[Ue].g;const Nt=k[Ue].map;if(O-=ee,O<0)ee=Math.max(0,k[Ue].g-100),de=!1;else try{O="req"+O+"_"||"";try{var U=Nt instanceof Map?Nt:Object.entries(Nt);for(const[rr,In]of U){let An=In;l(In)&&(An=Ra(In)),Ne.push(O+rr+"="+encodeURIComponent(An))}}catch(rr){throw Ne.push(O+"type="+encodeURIComponent("_badmap")),rr}}catch{y&&y(Nt)}}if(de){U=Ne.join("&");break e}}U=void 0}return a=a.i.splice(0,f),d.G=a,U}function Qu(a){if(!a.g&&!a.v){a.Y=1;var d=a.Da;z||v(),K||(z(),K=!0),E.add(d,a),a.A=0}}function Wa(a){return a.g||a.v||a.A>=3?!1:(a.Y++,a.v=Pi(h(a.Da,a),Zu(a,a.A)),a.A++,!0)}n.Da=function(){if(this.v=null,Ju(this),this.aa&&!(this.P||this.g==null||this.T<=0)){var a=4*this.T;this.j.info("BP detection timer enabled: "+a),this.B=Pi(h(this.Wa,this),a)}},n.Wa=function(){this.B&&(this.B=null,this.j.info("BP detection timeout reached."),this.j.info("Buffering proxy detected and switch to long-polling!"),this.F=!1,this.P=!0,Ze(10),es(this),Ju(this))};function Ha(a){a.B!=null&&(s.clearTimeout(a.B),a.B=null)}function Ju(a){a.g=new wn(a,a.j,"rpc",a.Y),a.u===null&&(a.g.J=a.o),a.g.P=0;var d=Ot(a.na);ge(d,"RID","rpc"),ge(d,"SID",a.M),ge(d,"AID",a.K),ge(d,"CI",a.F?"0":"1"),!a.F&&a.ia&&ge(d,"TO",a.ia),ge(d,"TYPE","xmlhttp"),Bi(a,d),a.u&&a.o&&ja(d,a.u,a.o),a.O&&(a.g.H=a.O);var f=a.g;a=a.ba,f.M=1,f.A=Jo(Ot(d)),f.u=null,f.R=!0,Au(f,a)}n.Va=function(){this.C!=null&&(this.C=null,es(this),Wa(this),Ze(19))};function ns(a){a.C!=null&&(s.clearTimeout(a.C),a.C=null)}function Xu(a,d){var f=null;if(a.g==d){ns(a),Ha(a),a.g=null;var y=2}else if(Ua(a.h,d))f=d.G,Ru(a.h,d),y=1;else return;if(a.I!=0){if(d.o)if(y==1){f=d.u?d.u.length:0,d=Date.now()-d.F;var k=a.D;y=Ko(),Xe(y,new wu(y,f)),ts(a)}else Qu(a);else if(k=d.m,k==3||k==0&&d.X>0||!(y==1&&Hm(a,d)||y==2&&Wa(a)))switch(f&&f.length>0&&(d=a.h,d.i=d.i.concat(f)),k){case 1:nr(a,5);break;case 4:nr(a,10);break;case 3:nr(a,6);break;default:nr(a,2)}}}function Zu(a,d){let f=a.Qa+Math.floor(Math.random()*a.Za);return a.isActive()||(f*=2),f*d}function nr(a,d){if(a.j.info("Error code "+d),d==2){var f=h(a.bb,a),y=a.Ua;const k=!y;y=new bn(y||"//www.google.com/images/cleardot.gif"),s.location&&s.location.protocol=="http"||Ni(y,"https"),Jo(y),k?qm(y.toString(),f):Bm(y.toString(),f)}else Ze(2);a.I=0,a.l&&a.l.pa(d),eh(a),Gu(a)}n.bb=function(a){a?(this.j.info("Successfully pinged google.com"),Ze(2)):(this.j.info("Failed to ping google.com"),Ze(1))};function eh(a){if(a.I=0,a.ja=[],a.l){const d=Ou(a.h);(d.length!=0||a.i.length!=0)&&(P(a.ja,d),P(a.ja,a.i),a.h.i.length=0,b(a.i),a.i.length=0),a.l.oa()}}function th(a,d,f){var y=f instanceof bn?Ot(f):new bn(f);if(y.g!="")d&&(y.g=d+"."+y.g),Di(y,y.u);else{var k=s.location;y=k.protocol,d=d?d+"."+k.hostname:k.hostname,k=+k.port;const O=new bn(null);y&&Ni(O,y),d&&(O.g=d),k&&Di(O,k),f&&(O.h=f),y=O}return f=a.G,d=a.wa,f&&d&&ge(y,f,d),ge(y,"VER",a.ka),Bi(a,y),y}function nh(a,d,f){if(d&&!a.L)throw Error("Can't create secondary domain capable XhrIo object.");return d=a.Aa&&!a.ma?new be(new $a({ab:f})):new be(a.ma),d.Fa(a.L),d}n.isActive=function(){return!!this.l&&this.l.isActive(this)};function rh(){}n=rh.prototype,n.ra=function(){},n.qa=function(){},n.pa=function(){},n.oa=function(){},n.isActive=function(){return!0},n.Ka=function(){};function rs(){}rs.prototype.g=function(a,d){return new dt(a,d)};function dt(a,d){He.call(this),this.g=new Hu(d),this.l=a,this.h=d&&d.messageUrlParams||null,a=d&&d.messageHeaders||null,d&&d.clientProtocolHeaderRequired&&(a?a["X-Client-Protocol"]="webchannel":a={"X-Client-Protocol":"webchannel"}),this.g.o=a,a=d&&d.initMessageHeaders||null,d&&d.messageContentType&&(a?a["X-WebChannel-Content-Type"]=d.messageContentType:a={"X-WebChannel-Content-Type":d.messageContentType}),d&&d.sa&&(a?a["X-WebChannel-Client-Profile"]=d.sa:a={"X-WebChannel-Client-Profile":d.sa}),this.g.U=a,(a=d&&d.Qb)&&!_(a)&&(this.g.u=a),this.A=d&&d.supportsCrossDomainXhr||!1,this.v=d&&d.sendRawJson||!1,(d=d&&d.httpSessionIdParam)&&!_(d)&&(this.g.G=d,a=this.h,a!==null&&d in a&&(a=this.h,d in a&&delete a[d])),this.j=new Nr(this)}m(dt,He),dt.prototype.m=function(){this.g.l=this.j,this.A&&(this.g.L=!0),this.g.connect(this.l,this.h||void 0)},dt.prototype.close=function(){za(this.g)},dt.prototype.o=function(a){var d=this.g;if(typeof a=="string"){var f={};f.__data__=a,a=f}else this.v&&(f={},f.__data__=Ra(a),a=f);d.i.push(new Om(d.Ya++,a)),d.I==3&&ts(d)},dt.prototype.N=function(){this.g.l=null,delete this.j,za(this.g),delete this.g,dt.Z.N.call(this)};function ih(a){Oa.call(this),a.__headers__&&(this.headers=a.__headers__,this.statusCode=a.__status__,delete a.__headers__,delete a.__status__);var d=a.__sm__;if(d){e:{for(const f in d){a=f;break e}a=void 0}(this.i=a)&&(a=this.i,d=d!==null&&a in d?d[a]:void 0),this.data=d}else this.data=a}m(ih,Oa);function oh(){Na.call(this),this.status=1}m(oh,Na);function Nr(a){this.g=a}m(Nr,rh),Nr.prototype.ra=function(){Xe(this.g,"a")},Nr.prototype.qa=function(a){Xe(this.g,new ih(a))},Nr.prototype.pa=function(a){Xe(this.g,new oh)},Nr.prototype.oa=function(){Xe(this.g,"b")},rs.prototype.createWebChannel=rs.prototype.g,dt.prototype.send=dt.prototype.o,dt.prototype.open=dt.prototype.m,dt.prototype.close=dt.prototype.close,ep=function(){return new rs},Zf=function(){return Ko()},Xf=Zn,El={jb:0,mb:1,nb:2,Hb:3,Mb:4,Jb:5,Kb:6,Ib:7,Gb:8,Lb:9,PROXY:10,NOPROXY:11,Eb:12,Ab:13,Bb:14,zb:15,Cb:16,Db:17,fb:18,eb:19,gb:20},Yo.NO_ERROR=0,Yo.TIMEOUT=8,Yo.HTTP_ERROR=6,Es=Yo,bu.COMPLETE="complete",Jf=bu,mu.EventType=xi,xi.OPEN="a",xi.CLOSE="b",xi.ERROR="c",xi.MESSAGE="d",He.prototype.listen=He.prototype.J,Qi=mu,be.prototype.listenOnce=be.prototype.K,be.prototype.getLastError=be.prototype.Ha,be.prototype.getLastErrorCode=be.prototype.ya,be.prototype.getStatus=be.prototype.ca,be.prototype.getResponseJson=be.prototype.La,be.prototype.getResponseText=be.prototype.la,be.prototype.send=be.prototype.ea,be.prototype.setWithCredentials=be.prototype.Fa,Qf=be}).apply(typeof ss<"u"?ss:typeof self<"u"?self:typeof window<"u"?window:{});/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ke{constructor(e){this.uid=e}isAuthenticated(){return this.uid!=null}toKey(){return this.isAuthenticated()?"uid:"+this.uid:"anonymous-user"}isEqual(e){return e.uid===this.uid}}Ke.UNAUTHENTICATED=new Ke(null),Ke.GOOGLE_CREDENTIALS=new Ke("google-credentials-uid"),Ke.FIRST_PARTY=new Ke("first-party-uid"),Ke.MOCK_USER=new Ke("mock-user");/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let vi="12.12.0";function Cw(n){vi=n}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const _r=new Jl("@firebase/firestore");function Dr(){return _r.logLevel}function j(n,...e){if(_r.logLevel<=ne.DEBUG){const t=e.map(cc);_r.debug(`Firestore (${vi}): ${n}`,...t)}}function pn(n,...e){if(_r.logLevel<=ne.ERROR){const t=e.map(cc);_r.error(`Firestore (${vi}): ${n}`,...t)}}function wr(n,...e){if(_r.logLevel<=ne.WARN){const t=e.map(cc);_r.warn(`Firestore (${vi}): ${n}`,...t)}}function cc(n){if(typeof n=="string")return n;try{return function(t){return JSON.stringify(t)}(n)}catch{return n}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Y(n,e,t){let r="Unexpected state";typeof e=="string"?r=e:t=e,tp(n,r,t)}function tp(n,e,t){let r=`FIRESTORE (${vi}) INTERNAL ASSERTION FAILED: ${e} (ID: ${n.toString(16)})`;if(t!==void 0)try{r+=" CONTEXT: "+JSON.stringify(t)}catch{r+=" CONTEXT: "+t}throw pn(r),new Error(r)}function he(n,e,t,r){let i="Unexpected state";typeof t=="string"?i=t:r=t,n||tp(e,i,r)}function X(n,e){return n}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const N={OK:"ok",CANCELLED:"cancelled",UNKNOWN:"unknown",INVALID_ARGUMENT:"invalid-argument",DEADLINE_EXCEEDED:"deadline-exceeded",NOT_FOUND:"not-found",ALREADY_EXISTS:"already-exists",PERMISSION_DENIED:"permission-denied",UNAUTHENTICATED:"unauthenticated",RESOURCE_EXHAUSTED:"resource-exhausted",FAILED_PRECONDITION:"failed-precondition",ABORTED:"aborted",OUT_OF_RANGE:"out-of-range",UNIMPLEMENTED:"unimplemented",INTERNAL:"internal",UNAVAILABLE:"unavailable",DATA_LOSS:"data-loss"};class q extends yn{constructor(e,t){super(e,t),this.code=e,this.message=t,this.toString=()=>`${this.name}: [code=${this.code}]: ${this.message}`}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class an{constructor(){this.promise=new Promise((e,t)=>{this.resolve=e,this.reject=t})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class np{constructor(e,t){this.user=t,this.type="OAuth",this.headers=new Map,this.headers.set("Authorization",`Bearer ${e}`)}}class Rw{getToken(){return Promise.resolve(null)}invalidateToken(){}start(e,t){e.enqueueRetryable(()=>t(Ke.UNAUTHENTICATED))}shutdown(){}}class Ow{constructor(e){this.token=e,this.changeListener=null}getToken(){return Promise.resolve(this.token)}invalidateToken(){}start(e,t){this.changeListener=t,e.enqueueRetryable(()=>t(this.token.user))}shutdown(){this.changeListener=null}}class Nw{constructor(e){this.t=e,this.currentUser=Ke.UNAUTHENTICATED,this.i=0,this.forceRefresh=!1,this.auth=null}start(e,t){he(this.o===void 0,42304);let r=this.i;const i=u=>this.i!==r?(r=this.i,t(u)):Promise.resolve();let o=new an;this.o=()=>{this.i++,this.currentUser=this.u(),o.resolve(),o=new an,e.enqueueRetryable(()=>i(this.currentUser))};const s=()=>{const u=o;e.enqueueRetryable(async()=>{await u.promise,await i(this.currentUser)})},l=u=>{j("FirebaseAuthCredentialsProvider","Auth detected"),this.auth=u,this.o&&(this.auth.addAuthTokenListener(this.o),s())};this.t.onInit(u=>l(u)),setTimeout(()=>{if(!this.auth){const u=this.t.getImmediate({optional:!0});u?l(u):(j("FirebaseAuthCredentialsProvider","Auth not yet detected"),o.resolve(),o=new an)}},0),s()}getToken(){const e=this.i,t=this.forceRefresh;return this.forceRefresh=!1,this.auth?this.auth.getToken(t).then(r=>this.i!==e?(j("FirebaseAuthCredentialsProvider","getToken aborted due to token change."),this.getToken()):r?(he(typeof r.accessToken=="string",31837,{l:r}),new np(r.accessToken,this.currentUser)):null):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.auth&&this.o&&this.auth.removeAuthTokenListener(this.o),this.o=void 0}u(){const e=this.auth&&this.auth.getUid();return he(e===null||typeof e=="string",2055,{h:e}),new Ke(e)}}class Dw{constructor(e,t,r){this.P=e,this.T=t,this.I=r,this.type="FirstParty",this.user=Ke.FIRST_PARTY,this.R=new Map}A(){return this.I?this.I():null}get headers(){this.R.set("X-Goog-AuthUser",this.P);const e=this.A();return e&&this.R.set("Authorization",e),this.T&&this.R.set("X-Goog-Iam-Authorization-Token",this.T),this.R}}class Mw{constructor(e,t,r){this.P=e,this.T=t,this.I=r}getToken(){return Promise.resolve(new Dw(this.P,this.T,this.I))}start(e,t){e.enqueueRetryable(()=>t(Ke.FIRST_PARTY))}shutdown(){}invalidateToken(){}}class Dh{constructor(e){this.value=e,this.type="AppCheck",this.headers=new Map,e&&e.length>0&&this.headers.set("x-firebase-appcheck",this.value)}}class Lw{constructor(e,t){this.V=t,this.forceRefresh=!1,this.appCheck=null,this.m=null,this.p=null,Lt(e)&&e.settings.appCheckToken&&(this.p=e.settings.appCheckToken)}start(e,t){he(this.o===void 0,3512);const r=o=>{o.error!=null&&j("FirebaseAppCheckTokenProvider",`Error getting App Check token; using placeholder token instead. Error: ${o.error.message}`);const s=o.token!==this.m;return this.m=o.token,j("FirebaseAppCheckTokenProvider",`Received ${s?"new":"existing"} token.`),s?t(o.token):Promise.resolve()};this.o=o=>{e.enqueueRetryable(()=>r(o))};const i=o=>{j("FirebaseAppCheckTokenProvider","AppCheck detected"),this.appCheck=o,this.o&&this.appCheck.addTokenListener(this.o)};this.V.onInit(o=>i(o)),setTimeout(()=>{if(!this.appCheck){const o=this.V.getImmediate({optional:!0});o?i(o):j("FirebaseAppCheckTokenProvider","AppCheck not yet detected")}},0)}getToken(){if(this.p)return Promise.resolve(new Dh(this.p));const e=this.forceRefresh;return this.forceRefresh=!1,this.appCheck?this.appCheck.getToken(e).then(t=>t?(he(typeof t.token=="string",44558,{tokenResult:t}),this.m=t.token,new Dh(t.token)):null):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.appCheck&&this.o&&this.appCheck.removeTokenListener(this.o),this.o=void 0}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Vw(n){const e=typeof self<"u"&&(self.crypto||self.msCrypto),t=new Uint8Array(n);if(e&&typeof e.getRandomValues=="function")e.getRandomValues(t);else for(let r=0;r<n;r++)t[r]=Math.floor(256*Math.random());return t}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class uc{static newId(){const e="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",t=62*Math.floor(4.129032258064516);let r="";for(;r.length<20;){const i=Vw(40);for(let o=0;o<i.length;++o)r.length<20&&i[o]<t&&(r+=e.charAt(i[o]%62))}return r}}function re(n,e){return n<e?-1:n>e?1:0}function Il(n,e){const t=Math.min(n.length,e.length);for(let r=0;r<t;r++){const i=n.charAt(r),o=e.charAt(r);if(i!==o)return tl(i)===tl(o)?re(i,o):tl(i)?1:-1}return re(n.length,e.length)}const Fw=55296,Uw=57343;function tl(n){const e=n.charCodeAt(0);return e>=Fw&&e<=Uw}function ii(n,e,t){return n.length===e.length&&n.every((r,i)=>t(r,e[i]))}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Mh="__name__";class Dt{constructor(e,t,r){t===void 0?t=0:t>e.length&&Y(637,{offset:t,range:e.length}),r===void 0?r=e.length-t:r>e.length-t&&Y(1746,{length:r,range:e.length-t}),this.segments=e,this.offset=t,this.len=r}get length(){return this.len}isEqual(e){return Dt.comparator(this,e)===0}child(e){const t=this.segments.slice(this.offset,this.limit());return e instanceof Dt?e.forEach(r=>{t.push(r)}):t.push(e),this.construct(t)}limit(){return this.offset+this.length}popFirst(e){return e=e===void 0?1:e,this.construct(this.segments,this.offset+e,this.length-e)}popLast(){return this.construct(this.segments,this.offset,this.length-1)}firstSegment(){return this.segments[this.offset]}lastSegment(){return this.get(this.length-1)}get(e){return this.segments[this.offset+e]}isEmpty(){return this.length===0}isPrefixOf(e){if(e.length<this.length)return!1;for(let t=0;t<this.length;t++)if(this.get(t)!==e.get(t))return!1;return!0}isImmediateParentOf(e){if(this.length+1!==e.length)return!1;for(let t=0;t<this.length;t++)if(this.get(t)!==e.get(t))return!1;return!0}forEach(e){for(let t=this.offset,r=this.limit();t<r;t++)e(this.segments[t])}toArray(){return this.segments.slice(this.offset,this.limit())}static comparator(e,t){const r=Math.min(e.length,t.length);for(let i=0;i<r;i++){const o=Dt.compareSegments(e.get(i),t.get(i));if(o!==0)return o}return re(e.length,t.length)}static compareSegments(e,t){const r=Dt.isNumericId(e),i=Dt.isNumericId(t);return r&&!i?-1:!r&&i?1:r&&i?Dt.extractNumericId(e).compare(Dt.extractNumericId(t)):Il(e,t)}static isNumericId(e){return e.startsWith("__id")&&e.endsWith("__")}static extractNumericId(e){return Fn.fromString(e.substring(4,e.length-2))}}class pe extends Dt{construct(e,t,r){return new pe(e,t,r)}canonicalString(){return this.toArray().join("/")}toString(){return this.canonicalString()}toUriEncodedString(){return this.toArray().map(encodeURIComponent).join("/")}static fromString(...e){const t=[];for(const r of e){if(r.indexOf("//")>=0)throw new q(N.INVALID_ARGUMENT,`Invalid segment (${r}). Paths must not contain // in them.`);t.push(...r.split("/").filter(i=>i.length>0))}return new pe(t)}static emptyPath(){return new pe([])}}const qw=/^[_a-zA-Z][_a-zA-Z0-9]*$/;class je extends Dt{construct(e,t,r){return new je(e,t,r)}static isValidIdentifier(e){return qw.test(e)}canonicalString(){return this.toArray().map(e=>(e=e.replace(/\\/g,"\\\\").replace(/`/g,"\\`"),je.isValidIdentifier(e)||(e="`"+e+"`"),e)).join(".")}toString(){return this.canonicalString()}isKeyField(){return this.length===1&&this.get(0)===Mh}static keyField(){return new je([Mh])}static fromServerFormat(e){const t=[];let r="",i=0;const o=()=>{if(r.length===0)throw new q(N.INVALID_ARGUMENT,`Invalid field path (${e}). Paths must not be empty, begin with '.', end with '.', or contain '..'`);t.push(r),r=""};let s=!1;for(;i<e.length;){const l=e[i];if(l==="\\"){if(i+1===e.length)throw new q(N.INVALID_ARGUMENT,"Path has trailing escape character: "+e);const u=e[i+1];if(u!=="\\"&&u!=="."&&u!=="`")throw new q(N.INVALID_ARGUMENT,"Path has invalid escape sequence: "+e);r+=u,i+=2}else l==="`"?(s=!s,i++):l!=="."||s?(r+=l,i++):(o(),i++)}if(o(),s)throw new q(N.INVALID_ARGUMENT,"Unterminated ` in path: "+e);return new je(t)}static emptyPath(){return new je([])}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class H{constructor(e){this.path=e}static fromPath(e){return new H(pe.fromString(e))}static fromName(e){return new H(pe.fromString(e).popFirst(5))}static empty(){return new H(pe.emptyPath())}get collectionGroup(){return this.path.popLast().lastSegment()}hasCollectionId(e){return this.path.length>=2&&this.path.get(this.path.length-2)===e}getCollectionGroup(){return this.path.get(this.path.length-2)}getCollectionPath(){return this.path.popLast()}isEqual(e){return e!==null&&pe.comparator(this.path,e.path)===0}toString(){return this.path.toString()}static comparator(e,t){return pe.comparator(e.path,t.path)}static isDocumentKey(e){return e.length%2==0}static fromSegments(e){return new H(new pe(e.slice()))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function rp(n,e,t){if(!t)throw new q(N.INVALID_ARGUMENT,`Function ${n}() cannot be called with an empty ${e}.`)}function Bw(n,e,t,r){if(e===!0&&r===!0)throw new q(N.INVALID_ARGUMENT,`${n} and ${t} cannot be used together.`)}function Lh(n){if(!H.isDocumentKey(n))throw new q(N.INVALID_ARGUMENT,`Invalid document reference. Document references must have an even number of segments, but ${n} has ${n.length}.`)}function Vh(n){if(H.isDocumentKey(n))throw new q(N.INVALID_ARGUMENT,`Invalid collection reference. Collection references must have an odd number of segments, but ${n} has ${n.length}.`)}function ip(n){return typeof n=="object"&&n!==null&&(Object.getPrototypeOf(n)===Object.prototype||Object.getPrototypeOf(n)===null)}function ca(n){if(n===void 0)return"undefined";if(n===null)return"null";if(typeof n=="string")return n.length>20&&(n=`${n.substring(0,20)}...`),JSON.stringify(n);if(typeof n=="number"||typeof n=="boolean")return""+n;if(typeof n=="object"){if(n instanceof Array)return"an array";{const e=function(r){return r.constructor?r.constructor.name:null}(n);return e?`a custom ${e} object`:"an object"}}return typeof n=="function"?"a function":Y(12329,{type:typeof n})}function yt(n,e){if("_delegate"in n&&(n=n._delegate),!(n instanceof e)){if(e.name===n.constructor.name)throw new q(N.INVALID_ARGUMENT,"Type does not match the expected instance. Did you pass a reference from a different Firestore SDK?");{const t=ca(n);throw new q(N.INVALID_ARGUMENT,`Expected type '${e.name}', but it was: ${t}`)}}return n}function $w(n,e){if(e<=0)throw new q(N.INVALID_ARGUMENT,`Function ${n}() requires a positive number, but it was: ${e}.`)}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Re(n,e){const t={typeString:n};return e&&(t.value=e),t}function Fo(n,e){if(!ip(n))throw new q(N.INVALID_ARGUMENT,"JSON must be an object");let t;for(const r in e)if(e[r]){const i=e[r].typeString,o="value"in e[r]?{value:e[r].value}:void 0;if(!(r in n)){t=`JSON missing required field: '${r}'`;break}const s=n[r];if(i&&typeof s!==i){t=`JSON field '${r}' must be a ${i}.`;break}if(o!==void 0&&s!==o.value){t=`Expected '${r}' field to equal '${o.value}'`;break}}if(t)throw new q(N.INVALID_ARGUMENT,t);return!0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Fh=-62135596800,Uh=1e6;class me{static now(){return me.fromMillis(Date.now())}static fromDate(e){return me.fromMillis(e.getTime())}static fromMillis(e){const t=Math.floor(e/1e3),r=Math.floor((e-1e3*t)*Uh);return new me(t,r)}constructor(e,t){if(this.seconds=e,this.nanoseconds=t,t<0)throw new q(N.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+t);if(t>=1e9)throw new q(N.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+t);if(e<Fh)throw new q(N.INVALID_ARGUMENT,"Timestamp seconds out of range: "+e);if(e>=253402300800)throw new q(N.INVALID_ARGUMENT,"Timestamp seconds out of range: "+e)}toDate(){return new Date(this.toMillis())}toMillis(){return 1e3*this.seconds+this.nanoseconds/Uh}_compareTo(e){return this.seconds===e.seconds?re(this.nanoseconds,e.nanoseconds):re(this.seconds,e.seconds)}isEqual(e){return e.seconds===this.seconds&&e.nanoseconds===this.nanoseconds}toString(){return"Timestamp(seconds="+this.seconds+", nanoseconds="+this.nanoseconds+")"}toJSON(){return{type:me._jsonSchemaVersion,seconds:this.seconds,nanoseconds:this.nanoseconds}}static fromJSON(e){if(Fo(e,me._jsonSchema))return new me(e.seconds,e.nanoseconds)}valueOf(){const e=this.seconds-Fh;return String(e).padStart(12,"0")+"."+String(this.nanoseconds).padStart(9,"0")}}me._jsonSchemaVersion="firestore/timestamp/1.0",me._jsonSchema={type:Re("string",me._jsonSchemaVersion),seconds:Re("number"),nanoseconds:Re("number")};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class J{static fromTimestamp(e){return new J(e)}static min(){return new J(new me(0,0))}static max(){return new J(new me(253402300799,999999999))}constructor(e){this.timestamp=e}compareTo(e){return this.timestamp._compareTo(e.timestamp)}isEqual(e){return this.timestamp.isEqual(e.timestamp)}toMicroseconds(){return 1e6*this.timestamp.seconds+this.timestamp.nanoseconds/1e3}toString(){return"SnapshotVersion("+this.timestamp.toString()+")"}toTimestamp(){return this.timestamp}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const mo=-1;function jw(n,e){const t=n.toTimestamp().seconds,r=n.toTimestamp().nanoseconds+1,i=J.fromTimestamp(r===1e9?new me(t+1,0):new me(t,r));return new $n(i,H.empty(),e)}function zw(n){return new $n(n.readTime,n.key,mo)}class $n{constructor(e,t,r){this.readTime=e,this.documentKey=t,this.largestBatchId=r}static min(){return new $n(J.min(),H.empty(),mo)}static max(){return new $n(J.max(),H.empty(),mo)}}function Ww(n,e){let t=n.readTime.compareTo(e.readTime);return t!==0?t:(t=H.comparator(n.documentKey,e.documentKey),t!==0?t:re(n.largestBatchId,e.largestBatchId))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Hw="The current tab is not in the required state to perform this operation. It might be necessary to refresh the browser tab.";class Gw{constructor(){this.onCommittedListeners=[]}addOnCommittedListener(e){this.onCommittedListeners.push(e)}raiseOnCommittedEvent(){this.onCommittedListeners.forEach(e=>e())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function _i(n){if(n.code!==N.FAILED_PRECONDITION||n.message!==Hw)throw n;j("LocalStore","Unexpectedly lost primary lease")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class D{constructor(e){this.nextCallback=null,this.catchCallback=null,this.result=void 0,this.error=void 0,this.isDone=!1,this.callbackAttached=!1,e(t=>{this.isDone=!0,this.result=t,this.nextCallback&&this.nextCallback(t)},t=>{this.isDone=!0,this.error=t,this.catchCallback&&this.catchCallback(t)})}catch(e){return this.next(void 0,e)}next(e,t){return this.callbackAttached&&Y(59440),this.callbackAttached=!0,this.isDone?this.error?this.wrapFailure(t,this.error):this.wrapSuccess(e,this.result):new D((r,i)=>{this.nextCallback=o=>{this.wrapSuccess(e,o).next(r,i)},this.catchCallback=o=>{this.wrapFailure(t,o).next(r,i)}})}toPromise(){return new Promise((e,t)=>{this.next(e,t)})}wrapUserFunction(e){try{const t=e();return t instanceof D?t:D.resolve(t)}catch(t){return D.reject(t)}}wrapSuccess(e,t){return e?this.wrapUserFunction(()=>e(t)):D.resolve(t)}wrapFailure(e,t){return e?this.wrapUserFunction(()=>e(t)):D.reject(t)}static resolve(e){return new D((t,r)=>{t(e)})}static reject(e){return new D((t,r)=>{r(e)})}static waitFor(e){return new D((t,r)=>{let i=0,o=0,s=!1;e.forEach(l=>{++i,l.next(()=>{++o,s&&o===i&&t()},u=>r(u))}),s=!0,o===i&&t()})}static or(e){let t=D.resolve(!1);for(const r of e)t=t.next(i=>i?D.resolve(i):r());return t}static forEach(e,t){const r=[];return e.forEach((i,o)=>{r.push(t.call(this,i,o))}),this.waitFor(r)}static mapArray(e,t){return new D((r,i)=>{const o=e.length,s=new Array(o);let l=0;for(let u=0;u<o;u++){const h=u;t(e[h]).next(p=>{s[h]=p,++l,l===o&&r(s)},p=>i(p))}})}static doWhile(e,t){return new D((r,i)=>{const o=()=>{e()===!0?t().next(()=>{o()},i):r()};o()})}}function Kw(n){const e=n.match(/Android ([\d.]+)/i),t=e?e[1].split(".").slice(0,2).join("."):"-1";return Number(t)}function wi(n){return n.name==="IndexedDbTransactionError"}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ua{constructor(e,t){this.previousValue=e,t&&(t.sequenceNumberHandler=r=>this.ae(r),this.ue=r=>t.writeSequenceNumber(r))}ae(e){return this.previousValue=Math.max(e,this.previousValue),this.previousValue}next(){const e=++this.previousValue;return this.ue&&this.ue(e),e}}ua.ce=-1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const hc=-1;function ha(n){return n==null}function Bs(n){return n===0&&1/n==-1/0}function Yw(n){return typeof n=="number"&&Number.isInteger(n)&&!Bs(n)&&n<=Number.MAX_SAFE_INTEGER&&n>=Number.MIN_SAFE_INTEGER}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const op="";function Qw(n){let e="";for(let t=0;t<n.length;t++)e.length>0&&(e=qh(e)),e=Jw(n.get(t),e);return qh(e)}function Jw(n,e){let t=e;const r=n.length;for(let i=0;i<r;i++){const o=n.charAt(i);switch(o){case"\0":t+="";break;case op:t+="";break;default:t+=o}}return t}function qh(n){return n+op+""}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Bh(n){let e=0;for(const t in n)Object.prototype.hasOwnProperty.call(n,t)&&e++;return e}function Yn(n,e){for(const t in n)Object.prototype.hasOwnProperty.call(n,t)&&e(t,n[t])}function sp(n){for(const e in n)if(Object.prototype.hasOwnProperty.call(n,e))return!1;return!0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class we{constructor(e,t){this.comparator=e,this.root=t||$e.EMPTY}insert(e,t){return new we(this.comparator,this.root.insert(e,t,this.comparator).copy(null,null,$e.BLACK,null,null))}remove(e){return new we(this.comparator,this.root.remove(e,this.comparator).copy(null,null,$e.BLACK,null,null))}get(e){let t=this.root;for(;!t.isEmpty();){const r=this.comparator(e,t.key);if(r===0)return t.value;r<0?t=t.left:r>0&&(t=t.right)}return null}indexOf(e){let t=0,r=this.root;for(;!r.isEmpty();){const i=this.comparator(e,r.key);if(i===0)return t+r.left.size;i<0?r=r.left:(t+=r.left.size+1,r=r.right)}return-1}isEmpty(){return this.root.isEmpty()}get size(){return this.root.size}minKey(){return this.root.minKey()}maxKey(){return this.root.maxKey()}inorderTraversal(e){return this.root.inorderTraversal(e)}forEach(e){this.inorderTraversal((t,r)=>(e(t,r),!1))}toString(){const e=[];return this.inorderTraversal((t,r)=>(e.push(`${t}:${r}`),!1)),`{${e.join(", ")}}`}reverseTraversal(e){return this.root.reverseTraversal(e)}getIterator(){return new as(this.root,null,this.comparator,!1)}getIteratorFrom(e){return new as(this.root,e,this.comparator,!1)}getReverseIterator(){return new as(this.root,null,this.comparator,!0)}getReverseIteratorFrom(e){return new as(this.root,e,this.comparator,!0)}}class as{constructor(e,t,r,i){this.isReverse=i,this.nodeStack=[];let o=1;for(;!e.isEmpty();)if(o=t?r(e.key,t):1,t&&i&&(o*=-1),o<0)e=this.isReverse?e.left:e.right;else{if(o===0){this.nodeStack.push(e);break}this.nodeStack.push(e),e=this.isReverse?e.right:e.left}}getNext(){let e=this.nodeStack.pop();const t={key:e.key,value:e.value};if(this.isReverse)for(e=e.left;!e.isEmpty();)this.nodeStack.push(e),e=e.right;else for(e=e.right;!e.isEmpty();)this.nodeStack.push(e),e=e.left;return t}hasNext(){return this.nodeStack.length>0}peek(){if(this.nodeStack.length===0)return null;const e=this.nodeStack[this.nodeStack.length-1];return{key:e.key,value:e.value}}}class $e{constructor(e,t,r,i,o){this.key=e,this.value=t,this.color=r??$e.RED,this.left=i??$e.EMPTY,this.right=o??$e.EMPTY,this.size=this.left.size+1+this.right.size}copy(e,t,r,i,o){return new $e(e??this.key,t??this.value,r??this.color,i??this.left,o??this.right)}isEmpty(){return!1}inorderTraversal(e){return this.left.inorderTraversal(e)||e(this.key,this.value)||this.right.inorderTraversal(e)}reverseTraversal(e){return this.right.reverseTraversal(e)||e(this.key,this.value)||this.left.reverseTraversal(e)}min(){return this.left.isEmpty()?this:this.left.min()}minKey(){return this.min().key}maxKey(){return this.right.isEmpty()?this.key:this.right.maxKey()}insert(e,t,r){let i=this;const o=r(e,i.key);return i=o<0?i.copy(null,null,null,i.left.insert(e,t,r),null):o===0?i.copy(null,t,null,null,null):i.copy(null,null,null,null,i.right.insert(e,t,r)),i.fixUp()}removeMin(){if(this.left.isEmpty())return $e.EMPTY;let e=this;return e.left.isRed()||e.left.left.isRed()||(e=e.moveRedLeft()),e=e.copy(null,null,null,e.left.removeMin(),null),e.fixUp()}remove(e,t){let r,i=this;if(t(e,i.key)<0)i.left.isEmpty()||i.left.isRed()||i.left.left.isRed()||(i=i.moveRedLeft()),i=i.copy(null,null,null,i.left.remove(e,t),null);else{if(i.left.isRed()&&(i=i.rotateRight()),i.right.isEmpty()||i.right.isRed()||i.right.left.isRed()||(i=i.moveRedRight()),t(e,i.key)===0){if(i.right.isEmpty())return $e.EMPTY;r=i.right.min(),i=i.copy(r.key,r.value,null,null,i.right.removeMin())}i=i.copy(null,null,null,null,i.right.remove(e,t))}return i.fixUp()}isRed(){return this.color}fixUp(){let e=this;return e.right.isRed()&&!e.left.isRed()&&(e=e.rotateLeft()),e.left.isRed()&&e.left.left.isRed()&&(e=e.rotateRight()),e.left.isRed()&&e.right.isRed()&&(e=e.colorFlip()),e}moveRedLeft(){let e=this.colorFlip();return e.right.left.isRed()&&(e=e.copy(null,null,null,null,e.right.rotateRight()),e=e.rotateLeft(),e=e.colorFlip()),e}moveRedRight(){let e=this.colorFlip();return e.left.left.isRed()&&(e=e.rotateRight(),e=e.colorFlip()),e}rotateLeft(){const e=this.copy(null,null,$e.RED,null,this.right.left);return this.right.copy(null,null,this.color,e,null)}rotateRight(){const e=this.copy(null,null,$e.RED,this.left.right,null);return this.left.copy(null,null,this.color,null,e)}colorFlip(){const e=this.left.copy(null,null,!this.left.color,null,null),t=this.right.copy(null,null,!this.right.color,null,null);return this.copy(null,null,!this.color,e,t)}checkMaxDepth(){const e=this.check();return Math.pow(2,e)<=this.size+1}check(){if(this.isRed()&&this.left.isRed())throw Y(43730,{key:this.key,value:this.value});if(this.right.isRed())throw Y(14113,{key:this.key,value:this.value});const e=this.left.check();if(e!==this.right.check())throw Y(27949);return e+(this.isRed()?0:1)}}$e.EMPTY=null,$e.RED=!0,$e.BLACK=!1;$e.EMPTY=new class{constructor(){this.size=0}get key(){throw Y(57766)}get value(){throw Y(16141)}get color(){throw Y(16727)}get left(){throw Y(29726)}get right(){throw Y(36894)}copy(e,t,r,i,o){return this}insert(e,t,r){return new $e(e,t)}remove(e,t){return this}isEmpty(){return!0}inorderTraversal(e){return!1}reverseTraversal(e){return!1}minKey(){return null}maxKey(){return null}isRed(){return!1}checkMaxDepth(){return!0}check(){return 0}};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Fe{constructor(e){this.comparator=e,this.data=new we(this.comparator)}has(e){return this.data.get(e)!==null}first(){return this.data.minKey()}last(){return this.data.maxKey()}get size(){return this.data.size}indexOf(e){return this.data.indexOf(e)}forEach(e){this.data.inorderTraversal((t,r)=>(e(t),!1))}forEachInRange(e,t){const r=this.data.getIteratorFrom(e[0]);for(;r.hasNext();){const i=r.getNext();if(this.comparator(i.key,e[1])>=0)return;t(i.key)}}forEachWhile(e,t){let r;for(r=t!==void 0?this.data.getIteratorFrom(t):this.data.getIterator();r.hasNext();)if(!e(r.getNext().key))return}firstAfterOrEqual(e){const t=this.data.getIteratorFrom(e);return t.hasNext()?t.getNext().key:null}getIterator(){return new $h(this.data.getIterator())}getIteratorFrom(e){return new $h(this.data.getIteratorFrom(e))}add(e){return this.copy(this.data.remove(e).insert(e,!0))}delete(e){return this.has(e)?this.copy(this.data.remove(e)):this}isEmpty(){return this.data.isEmpty()}unionWith(e){let t=this;return t.size<e.size&&(t=e,e=this),e.forEach(r=>{t=t.add(r)}),t}isEqual(e){if(!(e instanceof Fe)||this.size!==e.size)return!1;const t=this.data.getIterator(),r=e.data.getIterator();for(;t.hasNext();){const i=t.getNext().key,o=r.getNext().key;if(this.comparator(i,o)!==0)return!1}return!0}toArray(){const e=[];return this.forEach(t=>{e.push(t)}),e}toString(){const e=[];return this.forEach(t=>e.push(t)),"SortedSet("+e.toString()+")"}copy(e){const t=new Fe(this.comparator);return t.data=e,t}}class $h{constructor(e){this.iter=e}getNext(){return this.iter.getNext().key}hasNext(){return this.iter.hasNext()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class mt{constructor(e){this.fields=e,e.sort(je.comparator)}static empty(){return new mt([])}unionWith(e){let t=new Fe(je.comparator);for(const r of this.fields)t=t.add(r);for(const r of e)t=t.add(r);return new mt(t.toArray())}covers(e){for(const t of this.fields)if(t.isPrefixOf(e))return!0;return!1}isEqual(e){return ii(this.fields,e.fields,(t,r)=>t.isEqual(r))}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ap extends Error{constructor(){super(...arguments),this.name="Base64DecodeError"}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class We{constructor(e){this.binaryString=e}static fromBase64String(e){const t=function(i){try{return atob(i)}catch(o){throw typeof DOMException<"u"&&o instanceof DOMException?new ap("Invalid base64 string: "+o):o}}(e);return new We(t)}static fromUint8Array(e){const t=function(i){let o="";for(let s=0;s<i.length;++s)o+=String.fromCharCode(i[s]);return o}(e);return new We(t)}[Symbol.iterator](){let e=0;return{next:()=>e<this.binaryString.length?{value:this.binaryString.charCodeAt(e++),done:!1}:{value:void 0,done:!0}}}toBase64(){return function(t){return btoa(t)}(this.binaryString)}toUint8Array(){return function(t){const r=new Uint8Array(t.length);for(let i=0;i<t.length;i++)r[i]=t.charCodeAt(i);return r}(this.binaryString)}approximateByteSize(){return 2*this.binaryString.length}compareTo(e){return re(this.binaryString,e.binaryString)}isEqual(e){return this.binaryString===e.binaryString}}We.EMPTY_BYTE_STRING=new We("");const Xw=new RegExp(/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.(\d+))?Z$/);function jn(n){if(he(!!n,39018),typeof n=="string"){let e=0;const t=Xw.exec(n);if(he(!!t,46558,{timestamp:n}),t[1]){let i=t[1];i=(i+"000000000").substr(0,9),e=Number(i)}const r=new Date(n);return{seconds:Math.floor(r.getTime()/1e3),nanos:e}}return{seconds:Ae(n.seconds),nanos:Ae(n.nanos)}}function Ae(n){return typeof n=="number"?n:typeof n=="string"?Number(n):0}function zn(n){return typeof n=="string"?We.fromBase64String(n):We.fromUint8Array(n)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const lp="server_timestamp",cp="__type__",up="__previous_value__",hp="__local_write_time__";function dc(n){var t,r;return((r=(((t=n==null?void 0:n.mapValue)==null?void 0:t.fields)||{})[cp])==null?void 0:r.stringValue)===lp}function da(n){const e=n.mapValue.fields[up];return dc(e)?da(e):e}function yo(n){const e=jn(n.mapValue.fields[hp].timestampValue);return new me(e.seconds,e.nanos)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Zw{constructor(e,t,r,i,o,s,l,u,h,p,m){this.databaseId=e,this.appId=t,this.persistenceKey=r,this.host=i,this.ssl=o,this.forceLongPolling=s,this.autoDetectLongPolling=l,this.longPollingOptions=u,this.useFetchStreams=h,this.isUsingEmulator=p,this.apiKey=m}}const $s="(default)";class vo{constructor(e,t){this.projectId=e,this.database=t||$s}static empty(){return new vo("","")}get isDefaultDatabase(){return this.database===$s}isEqual(e){return e instanceof vo&&e.projectId===this.projectId&&e.database===this.database}}function eb(n,e){if(!Object.prototype.hasOwnProperty.apply(n.options,["projectId"]))throw new q(N.INVALID_ARGUMENT,'"projectId" not provided in firebase.initializeApp.');return new vo(n.options.projectId,e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const dp="__type__",tb="__max__",ls={mapValue:{}},fp="__vector__",js="value";function Wn(n){return"nullValue"in n?0:"booleanValue"in n?1:"integerValue"in n||"doubleValue"in n?2:"timestampValue"in n?3:"stringValue"in n?5:"bytesValue"in n?6:"referenceValue"in n?7:"geoPointValue"in n?8:"arrayValue"in n?9:"mapValue"in n?dc(n)?4:rb(n)?9007199254740991:nb(n)?10:11:Y(28295,{value:n})}function Gt(n,e){if(n===e)return!0;const t=Wn(n);if(t!==Wn(e))return!1;switch(t){case 0:case 9007199254740991:return!0;case 1:return n.booleanValue===e.booleanValue;case 4:return yo(n).isEqual(yo(e));case 3:return function(i,o){if(typeof i.timestampValue=="string"&&typeof o.timestampValue=="string"&&i.timestampValue.length===o.timestampValue.length)return i.timestampValue===o.timestampValue;const s=jn(i.timestampValue),l=jn(o.timestampValue);return s.seconds===l.seconds&&s.nanos===l.nanos}(n,e);case 5:return n.stringValue===e.stringValue;case 6:return function(i,o){return zn(i.bytesValue).isEqual(zn(o.bytesValue))}(n,e);case 7:return n.referenceValue===e.referenceValue;case 8:return function(i,o){return Ae(i.geoPointValue.latitude)===Ae(o.geoPointValue.latitude)&&Ae(i.geoPointValue.longitude)===Ae(o.geoPointValue.longitude)}(n,e);case 2:return function(i,o){if("integerValue"in i&&"integerValue"in o)return Ae(i.integerValue)===Ae(o.integerValue);if("doubleValue"in i&&"doubleValue"in o){const s=Ae(i.doubleValue),l=Ae(o.doubleValue);return s===l?Bs(s)===Bs(l):isNaN(s)&&isNaN(l)}return!1}(n,e);case 9:return ii(n.arrayValue.values||[],e.arrayValue.values||[],Gt);case 10:case 11:return function(i,o){const s=i.mapValue.fields||{},l=o.mapValue.fields||{};if(Bh(s)!==Bh(l))return!1;for(const u in s)if(s.hasOwnProperty(u)&&(l[u]===void 0||!Gt(s[u],l[u])))return!1;return!0}(n,e);default:return Y(52216,{left:n})}}function _o(n,e){return(n.values||[]).find(t=>Gt(t,e))!==void 0}function oi(n,e){if(n===e)return 0;const t=Wn(n),r=Wn(e);if(t!==r)return re(t,r);switch(t){case 0:case 9007199254740991:return 0;case 1:return re(n.booleanValue,e.booleanValue);case 2:return function(o,s){const l=Ae(o.integerValue||o.doubleValue),u=Ae(s.integerValue||s.doubleValue);return l<u?-1:l>u?1:l===u?0:isNaN(l)?isNaN(u)?0:-1:1}(n,e);case 3:return jh(n.timestampValue,e.timestampValue);case 4:return jh(yo(n),yo(e));case 5:return Il(n.stringValue,e.stringValue);case 6:return function(o,s){const l=zn(o),u=zn(s);return l.compareTo(u)}(n.bytesValue,e.bytesValue);case 7:return function(o,s){const l=o.split("/"),u=s.split("/");for(let h=0;h<l.length&&h<u.length;h++){const p=re(l[h],u[h]);if(p!==0)return p}return re(l.length,u.length)}(n.referenceValue,e.referenceValue);case 8:return function(o,s){const l=re(Ae(o.latitude),Ae(s.latitude));return l!==0?l:re(Ae(o.longitude),Ae(s.longitude))}(n.geoPointValue,e.geoPointValue);case 9:return zh(n.arrayValue,e.arrayValue);case 10:return function(o,s){var g,b,P,A;const l=o.fields||{},u=s.fields||{},h=(g=l[js])==null?void 0:g.arrayValue,p=(b=u[js])==null?void 0:b.arrayValue,m=re(((P=h==null?void 0:h.values)==null?void 0:P.length)||0,((A=p==null?void 0:p.values)==null?void 0:A.length)||0);return m!==0?m:zh(h,p)}(n.mapValue,e.mapValue);case 11:return function(o,s){if(o===ls.mapValue&&s===ls.mapValue)return 0;if(o===ls.mapValue)return 1;if(s===ls.mapValue)return-1;const l=o.fields||{},u=Object.keys(l),h=s.fields||{},p=Object.keys(h);u.sort(),p.sort();for(let m=0;m<u.length&&m<p.length;++m){const g=Il(u[m],p[m]);if(g!==0)return g;const b=oi(l[u[m]],h[p[m]]);if(b!==0)return b}return re(u.length,p.length)}(n.mapValue,e.mapValue);default:throw Y(23264,{he:t})}}function jh(n,e){if(typeof n=="string"&&typeof e=="string"&&n.length===e.length)return re(n,e);const t=jn(n),r=jn(e),i=re(t.seconds,r.seconds);return i!==0?i:re(t.nanos,r.nanos)}function zh(n,e){const t=n.values||[],r=e.values||[];for(let i=0;i<t.length&&i<r.length;++i){const o=oi(t[i],r[i]);if(o)return o}return re(t.length,r.length)}function si(n){return Al(n)}function Al(n){return"nullValue"in n?"null":"booleanValue"in n?""+n.booleanValue:"integerValue"in n?""+n.integerValue:"doubleValue"in n?""+n.doubleValue:"timestampValue"in n?function(t){const r=jn(t);return`time(${r.seconds},${r.nanos})`}(n.timestampValue):"stringValue"in n?n.stringValue:"bytesValue"in n?function(t){return zn(t).toBase64()}(n.bytesValue):"referenceValue"in n?function(t){return H.fromName(t).toString()}(n.referenceValue):"geoPointValue"in n?function(t){return`geo(${t.latitude},${t.longitude})`}(n.geoPointValue):"arrayValue"in n?function(t){let r="[",i=!0;for(const o of t.values||[])i?i=!1:r+=",",r+=Al(o);return r+"]"}(n.arrayValue):"mapValue"in n?function(t){const r=Object.keys(t.fields||{}).sort();let i="{",o=!0;for(const s of r)o?o=!1:i+=",",i+=`${s}:${Al(t.fields[s])}`;return i+"}"}(n.mapValue):Y(61005,{value:n})}function Is(n){switch(Wn(n)){case 0:case 1:return 4;case 2:return 8;case 3:case 8:return 16;case 4:const e=da(n);return e?16+Is(e):16;case 5:return 2*n.stringValue.length;case 6:return zn(n.bytesValue).approximateByteSize();case 7:return n.referenceValue.length;case 9:return function(r){return(r.values||[]).reduce((i,o)=>i+Is(o),0)}(n.arrayValue);case 10:case 11:return function(r){let i=0;return Yn(r.fields,(o,s)=>{i+=o.length+Is(s)}),i}(n.mapValue);default:throw Y(13486,{value:n})}}function Wh(n,e){return{referenceValue:`projects/${n.projectId}/databases/${n.database}/documents/${e.path.canonicalString()}`}}function Sl(n){return!!n&&"integerValue"in n}function fc(n){return!!n&&"arrayValue"in n}function Hh(n){return!!n&&"nullValue"in n}function Gh(n){return!!n&&"doubleValue"in n&&isNaN(Number(n.doubleValue))}function As(n){return!!n&&"mapValue"in n}function nb(n){var t,r;return((r=(((t=n==null?void 0:n.mapValue)==null?void 0:t.fields)||{})[dp])==null?void 0:r.stringValue)===fp}function io(n){if(n.geoPointValue)return{geoPointValue:{...n.geoPointValue}};if(n.timestampValue&&typeof n.timestampValue=="object")return{timestampValue:{...n.timestampValue}};if(n.mapValue){const e={mapValue:{fields:{}}};return Yn(n.mapValue.fields,(t,r)=>e.mapValue.fields[t]=io(r)),e}if(n.arrayValue){const e={arrayValue:{values:[]}};for(let t=0;t<(n.arrayValue.values||[]).length;++t)e.arrayValue.values[t]=io(n.arrayValue.values[t]);return e}return{...n}}function rb(n){return(((n.mapValue||{}).fields||{}).__type__||{}).stringValue===tb}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ct{constructor(e){this.value=e}static empty(){return new ct({mapValue:{}})}field(e){if(e.isEmpty())return this.value;{let t=this.value;for(let r=0;r<e.length-1;++r)if(t=(t.mapValue.fields||{})[e.get(r)],!As(t))return null;return t=(t.mapValue.fields||{})[e.lastSegment()],t||null}}set(e,t){this.getFieldsMap(e.popLast())[e.lastSegment()]=io(t)}setAll(e){let t=je.emptyPath(),r={},i=[];e.forEach((s,l)=>{if(!t.isImmediateParentOf(l)){const u=this.getFieldsMap(t);this.applyChanges(u,r,i),r={},i=[],t=l.popLast()}s?r[l.lastSegment()]=io(s):i.push(l.lastSegment())});const o=this.getFieldsMap(t);this.applyChanges(o,r,i)}delete(e){const t=this.field(e.popLast());As(t)&&t.mapValue.fields&&delete t.mapValue.fields[e.lastSegment()]}isEqual(e){return Gt(this.value,e.value)}getFieldsMap(e){let t=this.value;t.mapValue.fields||(t.mapValue={fields:{}});for(let r=0;r<e.length;++r){let i=t.mapValue.fields[e.get(r)];As(i)&&i.mapValue.fields||(i={mapValue:{fields:{}}},t.mapValue.fields[e.get(r)]=i),t=i}return t.mapValue.fields}applyChanges(e,t,r){Yn(t,(i,o)=>e[i]=o);for(const i of r)delete e[i]}clone(){return new ct(io(this.value))}}function pp(n){const e=[];return Yn(n.fields,(t,r)=>{const i=new je([t]);if(As(r)){const o=pp(r.mapValue).fields;if(o.length===0)e.push(i);else for(const s of o)e.push(i.child(s))}else e.push(i)}),new mt(e)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ye{constructor(e,t,r,i,o,s,l){this.key=e,this.documentType=t,this.version=r,this.readTime=i,this.createTime=o,this.data=s,this.documentState=l}static newInvalidDocument(e){return new Ye(e,0,J.min(),J.min(),J.min(),ct.empty(),0)}static newFoundDocument(e,t,r,i){return new Ye(e,1,t,J.min(),r,i,0)}static newNoDocument(e,t){return new Ye(e,2,t,J.min(),J.min(),ct.empty(),0)}static newUnknownDocument(e,t){return new Ye(e,3,t,J.min(),J.min(),ct.empty(),2)}convertToFoundDocument(e,t){return!this.createTime.isEqual(J.min())||this.documentType!==2&&this.documentType!==0||(this.createTime=e),this.version=e,this.documentType=1,this.data=t,this.documentState=0,this}convertToNoDocument(e){return this.version=e,this.documentType=2,this.data=ct.empty(),this.documentState=0,this}convertToUnknownDocument(e){return this.version=e,this.documentType=3,this.data=ct.empty(),this.documentState=2,this}setHasCommittedMutations(){return this.documentState=2,this}setHasLocalMutations(){return this.documentState=1,this.version=J.min(),this}setReadTime(e){return this.readTime=e,this}get hasLocalMutations(){return this.documentState===1}get hasCommittedMutations(){return this.documentState===2}get hasPendingWrites(){return this.hasLocalMutations||this.hasCommittedMutations}isValidDocument(){return this.documentType!==0}isFoundDocument(){return this.documentType===1}isNoDocument(){return this.documentType===2}isUnknownDocument(){return this.documentType===3}isEqual(e){return e instanceof Ye&&this.key.isEqual(e.key)&&this.version.isEqual(e.version)&&this.documentType===e.documentType&&this.documentState===e.documentState&&this.data.isEqual(e.data)}mutableCopy(){return new Ye(this.key,this.documentType,this.version,this.readTime,this.createTime,this.data.clone(),this.documentState)}toString(){return`Document(${this.key}, ${this.version}, ${JSON.stringify(this.data.value)}, {createTime: ${this.createTime}}), {documentType: ${this.documentType}}), {documentState: ${this.documentState}})`}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class zs{constructor(e,t){this.position=e,this.inclusive=t}}function Kh(n,e,t){let r=0;for(let i=0;i<n.position.length;i++){const o=e[i],s=n.position[i];if(o.field.isKeyField()?r=H.comparator(H.fromName(s.referenceValue),t.key):r=oi(s,t.data.field(o.field)),o.dir==="desc"&&(r*=-1),r!==0)break}return r}function Yh(n,e){if(n===null)return e===null;if(e===null||n.inclusive!==e.inclusive||n.position.length!==e.position.length)return!1;for(let t=0;t<n.position.length;t++)if(!Gt(n.position[t],e.position[t]))return!1;return!0}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wo{constructor(e,t="asc"){this.field=e,this.dir=t}}function ib(n,e){return n.dir===e.dir&&n.field.isEqual(e.field)}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class gp{}class Ce extends gp{constructor(e,t,r){super(),this.field=e,this.op=t,this.value=r}static create(e,t,r){return e.isKeyField()?t==="in"||t==="not-in"?this.createKeyFieldInFilter(e,t,r):new sb(e,t,r):t==="array-contains"?new cb(e,r):t==="in"?new ub(e,r):t==="not-in"?new hb(e,r):t==="array-contains-any"?new db(e,r):new Ce(e,t,r)}static createKeyFieldInFilter(e,t,r){return t==="in"?new ab(e,r):new lb(e,r)}matches(e){const t=e.data.field(this.field);return this.op==="!="?t!==null&&t.nullValue===void 0&&this.matchesComparison(oi(t,this.value)):t!==null&&Wn(this.value)===Wn(t)&&this.matchesComparison(oi(t,this.value))}matchesComparison(e){switch(this.op){case"<":return e<0;case"<=":return e<=0;case"==":return e===0;case"!=":return e!==0;case">":return e>0;case">=":return e>=0;default:return Y(47266,{operator:this.op})}}isInequality(){return["<","<=",">",">=","!=","not-in"].indexOf(this.op)>=0}getFlattenedFilters(){return[this]}getFilters(){return[this]}}class Ct extends gp{constructor(e,t){super(),this.filters=e,this.op=t,this.Pe=null}static create(e,t){return new Ct(e,t)}matches(e){return mp(this)?this.filters.find(t=>!t.matches(e))===void 0:this.filters.find(t=>t.matches(e))!==void 0}getFlattenedFilters(){return this.Pe!==null||(this.Pe=this.filters.reduce((e,t)=>e.concat(t.getFlattenedFilters()),[])),this.Pe}getFilters(){return Object.assign([],this.filters)}}function mp(n){return n.op==="and"}function yp(n){return ob(n)&&mp(n)}function ob(n){for(const e of n.filters)if(e instanceof Ct)return!1;return!0}function xl(n){if(n instanceof Ce)return n.field.canonicalString()+n.op.toString()+si(n.value);if(yp(n))return n.filters.map(e=>xl(e)).join(",");{const e=n.filters.map(t=>xl(t)).join(",");return`${n.op}(${e})`}}function vp(n,e){return n instanceof Ce?function(r,i){return i instanceof Ce&&r.op===i.op&&r.field.isEqual(i.field)&&Gt(r.value,i.value)}(n,e):n instanceof Ct?function(r,i){return i instanceof Ct&&r.op===i.op&&r.filters.length===i.filters.length?r.filters.reduce((o,s,l)=>o&&vp(s,i.filters[l]),!0):!1}(n,e):void Y(19439)}function _p(n){return n instanceof Ce?function(t){return`${t.field.canonicalString()} ${t.op} ${si(t.value)}`}(n):n instanceof Ct?function(t){return t.op.toString()+" {"+t.getFilters().map(_p).join(" ,")+"}"}(n):"Filter"}class sb extends Ce{constructor(e,t,r){super(e,t,r),this.key=H.fromName(r.referenceValue)}matches(e){const t=H.comparator(e.key,this.key);return this.matchesComparison(t)}}class ab extends Ce{constructor(e,t){super(e,"in",t),this.keys=wp("in",t)}matches(e){return this.keys.some(t=>t.isEqual(e.key))}}class lb extends Ce{constructor(e,t){super(e,"not-in",t),this.keys=wp("not-in",t)}matches(e){return!this.keys.some(t=>t.isEqual(e.key))}}function wp(n,e){var t;return(((t=e.arrayValue)==null?void 0:t.values)||[]).map(r=>H.fromName(r.referenceValue))}class cb extends Ce{constructor(e,t){super(e,"array-contains",t)}matches(e){const t=e.data.field(this.field);return fc(t)&&_o(t.arrayValue,this.value)}}class ub extends Ce{constructor(e,t){super(e,"in",t)}matches(e){const t=e.data.field(this.field);return t!==null&&_o(this.value.arrayValue,t)}}class hb extends Ce{constructor(e,t){super(e,"not-in",t)}matches(e){if(_o(this.value.arrayValue,{nullValue:"NULL_VALUE"}))return!1;const t=e.data.field(this.field);return t!==null&&t.nullValue===void 0&&!_o(this.value.arrayValue,t)}}class db extends Ce{constructor(e,t){super(e,"array-contains-any",t)}matches(e){const t=e.data.field(this.field);return!(!fc(t)||!t.arrayValue.values)&&t.arrayValue.values.some(r=>_o(this.value.arrayValue,r))}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fb{constructor(e,t=null,r=[],i=[],o=null,s=null,l=null){this.path=e,this.collectionGroup=t,this.orderBy=r,this.filters=i,this.limit=o,this.startAt=s,this.endAt=l,this.Te=null}}function Qh(n,e=null,t=[],r=[],i=null,o=null,s=null){return new fb(n,e,t,r,i,o,s)}function pc(n){const e=X(n);if(e.Te===null){let t=e.path.canonicalString();e.collectionGroup!==null&&(t+="|cg:"+e.collectionGroup),t+="|f:",t+=e.filters.map(r=>xl(r)).join(","),t+="|ob:",t+=e.orderBy.map(r=>function(o){return o.field.canonicalString()+o.dir}(r)).join(","),ha(e.limit)||(t+="|l:",t+=e.limit),e.startAt&&(t+="|lb:",t+=e.startAt.inclusive?"b:":"a:",t+=e.startAt.position.map(r=>si(r)).join(",")),e.endAt&&(t+="|ub:",t+=e.endAt.inclusive?"a:":"b:",t+=e.endAt.position.map(r=>si(r)).join(",")),e.Te=t}return e.Te}function gc(n,e){if(n.limit!==e.limit||n.orderBy.length!==e.orderBy.length)return!1;for(let t=0;t<n.orderBy.length;t++)if(!ib(n.orderBy[t],e.orderBy[t]))return!1;if(n.filters.length!==e.filters.length)return!1;for(let t=0;t<n.filters.length;t++)if(!vp(n.filters[t],e.filters[t]))return!1;return n.collectionGroup===e.collectionGroup&&!!n.path.isEqual(e.path)&&!!Yh(n.startAt,e.startAt)&&Yh(n.endAt,e.endAt)}function kl(n){return H.isDocumentKey(n.path)&&n.collectionGroup===null&&n.filters.length===0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class bi{constructor(e,t=null,r=[],i=[],o=null,s="F",l=null,u=null){this.path=e,this.collectionGroup=t,this.explicitOrderBy=r,this.filters=i,this.limit=o,this.limitType=s,this.startAt=l,this.endAt=u,this.Ee=null,this.Ie=null,this.Re=null,this.startAt,this.endAt}}function pb(n,e,t,r,i,o,s,l){return new bi(n,e,t,r,i,o,s,l)}function fa(n){return new bi(n)}function Jh(n){return n.filters.length===0&&n.limit===null&&n.startAt==null&&n.endAt==null&&(n.explicitOrderBy.length===0||n.explicitOrderBy.length===1&&n.explicitOrderBy[0].field.isKeyField())}function gb(n){return H.isDocumentKey(n.path)&&n.collectionGroup===null&&n.filters.length===0}function bp(n){return n.collectionGroup!==null}function oo(n){const e=X(n);if(e.Ee===null){e.Ee=[];const t=new Set;for(const o of e.explicitOrderBy)e.Ee.push(o),t.add(o.field.canonicalString());const r=e.explicitOrderBy.length>0?e.explicitOrderBy[e.explicitOrderBy.length-1].dir:"asc";(function(s){let l=new Fe(je.comparator);return s.filters.forEach(u=>{u.getFlattenedFilters().forEach(h=>{h.isInequality()&&(l=l.add(h.field))})}),l})(e).forEach(o=>{t.has(o.canonicalString())||o.isKeyField()||e.Ee.push(new wo(o,r))}),t.has(je.keyField().canonicalString())||e.Ee.push(new wo(je.keyField(),r))}return e.Ee}function jt(n){const e=X(n);return e.Ie||(e.Ie=mb(e,oo(n))),e.Ie}function mb(n,e){if(n.limitType==="F")return Qh(n.path,n.collectionGroup,e,n.filters,n.limit,n.startAt,n.endAt);{e=e.map(i=>{const o=i.dir==="desc"?"asc":"desc";return new wo(i.field,o)});const t=n.endAt?new zs(n.endAt.position,n.endAt.inclusive):null,r=n.startAt?new zs(n.startAt.position,n.startAt.inclusive):null;return Qh(n.path,n.collectionGroup,e,n.filters,n.limit,t,r)}}function Pl(n,e){const t=n.filters.concat([e]);return new bi(n.path,n.collectionGroup,n.explicitOrderBy.slice(),t,n.limit,n.limitType,n.startAt,n.endAt)}function yb(n,e){const t=n.explicitOrderBy.concat([e]);return new bi(n.path,n.collectionGroup,t,n.filters.slice(),n.limit,n.limitType,n.startAt,n.endAt)}function Ws(n,e,t){return new bi(n.path,n.collectionGroup,n.explicitOrderBy.slice(),n.filters.slice(),e,t,n.startAt,n.endAt)}function pa(n,e){return gc(jt(n),jt(e))&&n.limitType===e.limitType}function Tp(n){return`${pc(jt(n))}|lt:${n.limitType}`}function Mr(n){return`Query(target=${function(t){let r=t.path.canonicalString();return t.collectionGroup!==null&&(r+=" collectionGroup="+t.collectionGroup),t.filters.length>0&&(r+=`, filters: [${t.filters.map(i=>_p(i)).join(", ")}]`),ha(t.limit)||(r+=", limit: "+t.limit),t.orderBy.length>0&&(r+=`, orderBy: [${t.orderBy.map(i=>function(s){return`${s.field.canonicalString()} (${s.dir})`}(i)).join(", ")}]`),t.startAt&&(r+=", startAt: ",r+=t.startAt.inclusive?"b:":"a:",r+=t.startAt.position.map(i=>si(i)).join(",")),t.endAt&&(r+=", endAt: ",r+=t.endAt.inclusive?"a:":"b:",r+=t.endAt.position.map(i=>si(i)).join(",")),`Target(${r})`}(jt(n))}; limitType=${n.limitType})`}function ga(n,e){return e.isFoundDocument()&&function(r,i){const o=i.key.path;return r.collectionGroup!==null?i.key.hasCollectionId(r.collectionGroup)&&r.path.isPrefixOf(o):H.isDocumentKey(r.path)?r.path.isEqual(o):r.path.isImmediateParentOf(o)}(n,e)&&function(r,i){for(const o of oo(r))if(!o.field.isKeyField()&&i.data.field(o.field)===null)return!1;return!0}(n,e)&&function(r,i){for(const o of r.filters)if(!o.matches(i))return!1;return!0}(n,e)&&function(r,i){return!(r.startAt&&!function(s,l,u){const h=Kh(s,l,u);return s.inclusive?h<=0:h<0}(r.startAt,oo(r),i)||r.endAt&&!function(s,l,u){const h=Kh(s,l,u);return s.inclusive?h>=0:h>0}(r.endAt,oo(r),i))}(n,e)}function vb(n){return n.collectionGroup||(n.path.length%2==1?n.path.lastSegment():n.path.get(n.path.length-2))}function Ep(n){return(e,t)=>{let r=!1;for(const i of oo(n)){const o=_b(i,e,t);if(o!==0)return o;r=r||i.field.isKeyField()}return 0}}function _b(n,e,t){const r=n.field.isKeyField()?H.comparator(e.key,t.key):function(o,s,l){const u=s.data.field(o),h=l.data.field(o);return u!==null&&h!==null?oi(u,h):Y(42886)}(n.field,e,t);switch(n.dir){case"asc":return r;case"desc":return-1*r;default:return Y(19790,{direction:n.dir})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ar{constructor(e,t){this.mapKeyFn=e,this.equalsFn=t,this.inner={},this.innerSize=0}get(e){const t=this.mapKeyFn(e),r=this.inner[t];if(r!==void 0){for(const[i,o]of r)if(this.equalsFn(i,e))return o}}has(e){return this.get(e)!==void 0}set(e,t){const r=this.mapKeyFn(e),i=this.inner[r];if(i===void 0)return this.inner[r]=[[e,t]],void this.innerSize++;for(let o=0;o<i.length;o++)if(this.equalsFn(i[o][0],e))return void(i[o]=[e,t]);i.push([e,t]),this.innerSize++}delete(e){const t=this.mapKeyFn(e),r=this.inner[t];if(r===void 0)return!1;for(let i=0;i<r.length;i++)if(this.equalsFn(r[i][0],e))return r.length===1?delete this.inner[t]:r.splice(i,1),this.innerSize--,!0;return!1}forEach(e){Yn(this.inner,(t,r)=>{for(const[i,o]of r)e(i,o)})}isEmpty(){return sp(this.inner)}size(){return this.innerSize}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const wb=new we(H.comparator);function gn(){return wb}const Ip=new we(H.comparator);function Ji(...n){let e=Ip;for(const t of n)e=e.insert(t.key,t);return e}function Ap(n){let e=Ip;return n.forEach((t,r)=>e=e.insert(t,r.overlayedDocument)),e}function sr(){return so()}function Sp(){return so()}function so(){return new Ar(n=>n.toString(),(n,e)=>n.isEqual(e))}const bb=new we(H.comparator),Tb=new Fe(H.comparator);function ie(...n){let e=Tb;for(const t of n)e=e.add(t);return e}const Eb=new Fe(re);function Ib(){return Eb}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function mc(n,e){if(n.useProto3Json){if(isNaN(e))return{doubleValue:"NaN"};if(e===1/0)return{doubleValue:"Infinity"};if(e===-1/0)return{doubleValue:"-Infinity"}}return{doubleValue:Bs(e)?"-0":e}}function xp(n){return{integerValue:""+n}}function kp(n,e){return Yw(e)?xp(e):mc(n,e)}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ma{constructor(){this._=void 0}}function Ab(n,e,t){return n instanceof bo?function(i,o){const s={fields:{[cp]:{stringValue:lp},[hp]:{timestampValue:{seconds:i.seconds,nanos:i.nanoseconds}}}};return o&&dc(o)&&(o=da(o)),o&&(s.fields[up]=o),{mapValue:s}}(t,e):n instanceof To?Cp(n,e):n instanceof Eo?Rp(n,e):function(i,o){const s=Pp(i,o),l=Xh(s)+Xh(i.Ae);return Sl(s)&&Sl(i.Ae)?xp(l):mc(i.serializer,l)}(n,e)}function Sb(n,e,t){return n instanceof To?Cp(n,e):n instanceof Eo?Rp(n,e):t}function Pp(n,e){return n instanceof Io?function(r){return Sl(r)||function(o){return!!o&&"doubleValue"in o}(r)}(e)?e:{integerValue:0}:null}class bo extends ma{}class To extends ma{constructor(e){super(),this.elements=e}}function Cp(n,e){const t=Op(e);for(const r of n.elements)t.some(i=>Gt(i,r))||t.push(r);return{arrayValue:{values:t}}}class Eo extends ma{constructor(e){super(),this.elements=e}}function Rp(n,e){let t=Op(e);for(const r of n.elements)t=t.filter(i=>!Gt(i,r));return{arrayValue:{values:t}}}class Io extends ma{constructor(e,t){super(),this.serializer=e,this.Ae=t}}function Xh(n){return Ae(n.integerValue||n.doubleValue)}function Op(n){return fc(n)&&n.arrayValue.values?n.arrayValue.values.slice():[]}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Np{constructor(e,t){this.field=e,this.transform=t}}function xb(n,e){return n.field.isEqual(e.field)&&function(r,i){return r instanceof To&&i instanceof To||r instanceof Eo&&i instanceof Eo?ii(r.elements,i.elements,Gt):r instanceof Io&&i instanceof Io?Gt(r.Ae,i.Ae):r instanceof bo&&i instanceof bo}(n.transform,e.transform)}class kb{constructor(e,t){this.version=e,this.transformResults=t}}class At{constructor(e,t){this.updateTime=e,this.exists=t}static none(){return new At}static exists(e){return new At(void 0,e)}static updateTime(e){return new At(e)}get isNone(){return this.updateTime===void 0&&this.exists===void 0}isEqual(e){return this.exists===e.exists&&(this.updateTime?!!e.updateTime&&this.updateTime.isEqual(e.updateTime):!e.updateTime)}}function Ss(n,e){return n.updateTime!==void 0?e.isFoundDocument()&&e.version.isEqual(n.updateTime):n.exists===void 0||n.exists===e.isFoundDocument()}class ya{}function Dp(n,e){if(!n.hasLocalMutations||e&&e.fields.length===0)return null;if(e===null)return n.isNoDocument()?new yc(n.key,At.none()):new Uo(n.key,n.data,At.none());{const t=n.data,r=ct.empty();let i=new Fe(je.comparator);for(let o of e.fields)if(!i.has(o)){let s=t.field(o);s===null&&o.length>1&&(o=o.popLast(),s=t.field(o)),s===null?r.delete(o):r.set(o,s),i=i.add(o)}return new Qn(n.key,r,new mt(i.toArray()),At.none())}}function Pb(n,e,t){n instanceof Uo?function(i,o,s){const l=i.value.clone(),u=ed(i.fieldTransforms,o,s.transformResults);l.setAll(u),o.convertToFoundDocument(s.version,l).setHasCommittedMutations()}(n,e,t):n instanceof Qn?function(i,o,s){if(!Ss(i.precondition,o))return void o.convertToUnknownDocument(s.version);const l=ed(i.fieldTransforms,o,s.transformResults),u=o.data;u.setAll(Mp(i)),u.setAll(l),o.convertToFoundDocument(s.version,u).setHasCommittedMutations()}(n,e,t):function(i,o,s){o.convertToNoDocument(s.version).setHasCommittedMutations()}(0,e,t)}function ao(n,e,t,r){return n instanceof Uo?function(o,s,l,u){if(!Ss(o.precondition,s))return l;const h=o.value.clone(),p=td(o.fieldTransforms,u,s);return h.setAll(p),s.convertToFoundDocument(s.version,h).setHasLocalMutations(),null}(n,e,t,r):n instanceof Qn?function(o,s,l,u){if(!Ss(o.precondition,s))return l;const h=td(o.fieldTransforms,u,s),p=s.data;return p.setAll(Mp(o)),p.setAll(h),s.convertToFoundDocument(s.version,p).setHasLocalMutations(),l===null?null:l.unionWith(o.fieldMask.fields).unionWith(o.fieldTransforms.map(m=>m.field))}(n,e,t,r):function(o,s,l){return Ss(o.precondition,s)?(s.convertToNoDocument(s.version).setHasLocalMutations(),null):l}(n,e,t)}function Cb(n,e){let t=null;for(const r of n.fieldTransforms){const i=e.data.field(r.field),o=Pp(r.transform,i||null);o!=null&&(t===null&&(t=ct.empty()),t.set(r.field,o))}return t||null}function Zh(n,e){return n.type===e.type&&!!n.key.isEqual(e.key)&&!!n.precondition.isEqual(e.precondition)&&!!function(r,i){return r===void 0&&i===void 0||!(!r||!i)&&ii(r,i,(o,s)=>xb(o,s))}(n.fieldTransforms,e.fieldTransforms)&&(n.type===0?n.value.isEqual(e.value):n.type!==1||n.data.isEqual(e.data)&&n.fieldMask.isEqual(e.fieldMask))}class Uo extends ya{constructor(e,t,r,i=[]){super(),this.key=e,this.value=t,this.precondition=r,this.fieldTransforms=i,this.type=0}getFieldMask(){return null}}class Qn extends ya{constructor(e,t,r,i,o=[]){super(),this.key=e,this.data=t,this.fieldMask=r,this.precondition=i,this.fieldTransforms=o,this.type=1}getFieldMask(){return this.fieldMask}}function Mp(n){const e=new Map;return n.fieldMask.fields.forEach(t=>{if(!t.isEmpty()){const r=n.data.field(t);e.set(t,r)}}),e}function ed(n,e,t){const r=new Map;he(n.length===t.length,32656,{Ve:t.length,de:n.length});for(let i=0;i<t.length;i++){const o=n[i],s=o.transform,l=e.data.field(o.field);r.set(o.field,Sb(s,l,t[i]))}return r}function td(n,e,t){const r=new Map;for(const i of n){const o=i.transform,s=t.data.field(i.field);r.set(i.field,Ab(o,s,e))}return r}class yc extends ya{constructor(e,t){super(),this.key=e,this.precondition=t,this.type=2,this.fieldTransforms=[]}getFieldMask(){return null}}class Rb extends ya{constructor(e,t){super(),this.key=e,this.precondition=t,this.type=3,this.fieldTransforms=[]}getFieldMask(){return null}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ob{constructor(e,t,r,i){this.batchId=e,this.localWriteTime=t,this.baseMutations=r,this.mutations=i}applyToRemoteDocument(e,t){const r=t.mutationResults;for(let i=0;i<this.mutations.length;i++){const o=this.mutations[i];o.key.isEqual(e.key)&&Pb(o,e,r[i])}}applyToLocalView(e,t){for(const r of this.baseMutations)r.key.isEqual(e.key)&&(t=ao(r,e,t,this.localWriteTime));for(const r of this.mutations)r.key.isEqual(e.key)&&(t=ao(r,e,t,this.localWriteTime));return t}applyToLocalDocumentSet(e,t){const r=Sp();return this.mutations.forEach(i=>{const o=e.get(i.key),s=o.overlayedDocument;let l=this.applyToLocalView(s,o.mutatedFields);l=t.has(i.key)?null:l;const u=Dp(s,l);u!==null&&r.set(i.key,u),s.isValidDocument()||s.convertToNoDocument(J.min())}),r}keys(){return this.mutations.reduce((e,t)=>e.add(t.key),ie())}isEqual(e){return this.batchId===e.batchId&&ii(this.mutations,e.mutations,(t,r)=>Zh(t,r))&&ii(this.baseMutations,e.baseMutations,(t,r)=>Zh(t,r))}}class vc{constructor(e,t,r,i){this.batch=e,this.commitVersion=t,this.mutationResults=r,this.docVersions=i}static from(e,t,r){he(e.mutations.length===r.length,58842,{me:e.mutations.length,fe:r.length});let i=function(){return bb}();const o=e.mutations;for(let s=0;s<o.length;s++)i=i.insert(o[s].key,r[s].version);return new vc(e,t,r,i)}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Nb{constructor(e,t){this.largestBatchId=e,this.mutation=t}getKey(){return this.mutation.key}isEqual(e){return e!==null&&this.mutation===e.mutation}toString(){return`Overlay{
      largestBatchId: ${this.largestBatchId},
      mutation: ${this.mutation.toString()}
    }`}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Db{constructor(e,t){this.count=e,this.unchangedNames=t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var Pe,oe;function Mb(n){switch(n){case N.OK:return Y(64938);case N.CANCELLED:case N.UNKNOWN:case N.DEADLINE_EXCEEDED:case N.RESOURCE_EXHAUSTED:case N.INTERNAL:case N.UNAVAILABLE:case N.UNAUTHENTICATED:return!1;case N.INVALID_ARGUMENT:case N.NOT_FOUND:case N.ALREADY_EXISTS:case N.PERMISSION_DENIED:case N.FAILED_PRECONDITION:case N.ABORTED:case N.OUT_OF_RANGE:case N.UNIMPLEMENTED:case N.DATA_LOSS:return!0;default:return Y(15467,{code:n})}}function Lp(n){if(n===void 0)return pn("GRPC error has no .code"),N.UNKNOWN;switch(n){case Pe.OK:return N.OK;case Pe.CANCELLED:return N.CANCELLED;case Pe.UNKNOWN:return N.UNKNOWN;case Pe.DEADLINE_EXCEEDED:return N.DEADLINE_EXCEEDED;case Pe.RESOURCE_EXHAUSTED:return N.RESOURCE_EXHAUSTED;case Pe.INTERNAL:return N.INTERNAL;case Pe.UNAVAILABLE:return N.UNAVAILABLE;case Pe.UNAUTHENTICATED:return N.UNAUTHENTICATED;case Pe.INVALID_ARGUMENT:return N.INVALID_ARGUMENT;case Pe.NOT_FOUND:return N.NOT_FOUND;case Pe.ALREADY_EXISTS:return N.ALREADY_EXISTS;case Pe.PERMISSION_DENIED:return N.PERMISSION_DENIED;case Pe.FAILED_PRECONDITION:return N.FAILED_PRECONDITION;case Pe.ABORTED:return N.ABORTED;case Pe.OUT_OF_RANGE:return N.OUT_OF_RANGE;case Pe.UNIMPLEMENTED:return N.UNIMPLEMENTED;case Pe.DATA_LOSS:return N.DATA_LOSS;default:return Y(39323,{code:n})}}(oe=Pe||(Pe={}))[oe.OK=0]="OK",oe[oe.CANCELLED=1]="CANCELLED",oe[oe.UNKNOWN=2]="UNKNOWN",oe[oe.INVALID_ARGUMENT=3]="INVALID_ARGUMENT",oe[oe.DEADLINE_EXCEEDED=4]="DEADLINE_EXCEEDED",oe[oe.NOT_FOUND=5]="NOT_FOUND",oe[oe.ALREADY_EXISTS=6]="ALREADY_EXISTS",oe[oe.PERMISSION_DENIED=7]="PERMISSION_DENIED",oe[oe.UNAUTHENTICATED=16]="UNAUTHENTICATED",oe[oe.RESOURCE_EXHAUSTED=8]="RESOURCE_EXHAUSTED",oe[oe.FAILED_PRECONDITION=9]="FAILED_PRECONDITION",oe[oe.ABORTED=10]="ABORTED",oe[oe.OUT_OF_RANGE=11]="OUT_OF_RANGE",oe[oe.UNIMPLEMENTED=12]="UNIMPLEMENTED",oe[oe.INTERNAL=13]="INTERNAL",oe[oe.UNAVAILABLE=14]="UNAVAILABLE",oe[oe.DATA_LOSS=15]="DATA_LOSS";/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Lb(){return new TextEncoder}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Vb=new Fn([4294967295,4294967295],0);function nd(n){const e=Lb().encode(n),t=new Yf;return t.update(e),new Uint8Array(t.digest())}function rd(n){const e=new DataView(n.buffer),t=e.getUint32(0,!0),r=e.getUint32(4,!0),i=e.getUint32(8,!0),o=e.getUint32(12,!0);return[new Fn([t,r],0),new Fn([i,o],0)]}class _c{constructor(e,t,r){if(this.bitmap=e,this.padding=t,this.hashCount=r,t<0||t>=8)throw new Xi(`Invalid padding: ${t}`);if(r<0)throw new Xi(`Invalid hash count: ${r}`);if(e.length>0&&this.hashCount===0)throw new Xi(`Invalid hash count: ${r}`);if(e.length===0&&t!==0)throw new Xi(`Invalid padding when bitmap length is 0: ${t}`);this.ge=8*e.length-t,this.pe=Fn.fromNumber(this.ge)}ye(e,t,r){let i=e.add(t.multiply(Fn.fromNumber(r)));return i.compare(Vb)===1&&(i=new Fn([i.getBits(0),i.getBits(1)],0)),i.modulo(this.pe).toNumber()}we(e){return!!(this.bitmap[Math.floor(e/8)]&1<<e%8)}mightContain(e){if(this.ge===0)return!1;const t=nd(e),[r,i]=rd(t);for(let o=0;o<this.hashCount;o++){const s=this.ye(r,i,o);if(!this.we(s))return!1}return!0}static create(e,t,r){const i=e%8==0?0:8-e%8,o=new Uint8Array(Math.ceil(e/8)),s=new _c(o,i,t);return r.forEach(l=>s.insert(l)),s}insert(e){if(this.ge===0)return;const t=nd(e),[r,i]=rd(t);for(let o=0;o<this.hashCount;o++){const s=this.ye(r,i,o);this.Se(s)}}Se(e){const t=Math.floor(e/8),r=e%8;this.bitmap[t]|=1<<r}}class Xi extends Error{constructor(){super(...arguments),this.name="BloomFilterError"}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class va{constructor(e,t,r,i,o){this.snapshotVersion=e,this.targetChanges=t,this.targetMismatches=r,this.documentUpdates=i,this.resolvedLimboDocuments=o}static createSynthesizedRemoteEventForCurrentChange(e,t,r){const i=new Map;return i.set(e,qo.createSynthesizedTargetChangeForCurrentChange(e,t,r)),new va(J.min(),i,new we(re),gn(),ie())}}class qo{constructor(e,t,r,i,o){this.resumeToken=e,this.current=t,this.addedDocuments=r,this.modifiedDocuments=i,this.removedDocuments=o}static createSynthesizedTargetChangeForCurrentChange(e,t,r){return new qo(r,t,ie(),ie(),ie())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xs{constructor(e,t,r,i){this.be=e,this.removedTargetIds=t,this.key=r,this.De=i}}class Vp{constructor(e,t){this.targetId=e,this.Ce=t}}class Fp{constructor(e,t,r=We.EMPTY_BYTE_STRING,i=null){this.state=e,this.targetIds=t,this.resumeToken=r,this.cause=i}}class id{constructor(){this.ve=0,this.Fe=od(),this.Me=We.EMPTY_BYTE_STRING,this.xe=!1,this.Oe=!0}get current(){return this.xe}get resumeToken(){return this.Me}get Ne(){return this.ve!==0}get Be(){return this.Oe}Le(e){e.approximateByteSize()>0&&(this.Oe=!0,this.Me=e)}ke(){let e=ie(),t=ie(),r=ie();return this.Fe.forEach((i,o)=>{switch(o){case 0:e=e.add(i);break;case 2:t=t.add(i);break;case 1:r=r.add(i);break;default:Y(38017,{changeType:o})}}),new qo(this.Me,this.xe,e,t,r)}qe(){this.Oe=!1,this.Fe=od()}Ke(e,t){this.Oe=!0,this.Fe=this.Fe.insert(e,t)}Ue(e){this.Oe=!0,this.Fe=this.Fe.remove(e)}$e(){this.ve+=1}We(){this.ve-=1,he(this.ve>=0,3241,{ve:this.ve})}Qe(){this.Oe=!0,this.xe=!0}}class Fb{constructor(e){this.Ge=e,this.ze=new Map,this.je=gn(),this.Je=cs(),this.He=cs(),this.Ze=new we(re)}Xe(e){for(const t of e.be)e.De&&e.De.isFoundDocument()?this.Ye(t,e.De):this.et(t,e.key,e.De);for(const t of e.removedTargetIds)this.et(t,e.key,e.De)}tt(e){this.forEachTarget(e,t=>{const r=this.nt(t);switch(e.state){case 0:this.rt(t)&&r.Le(e.resumeToken);break;case 1:r.We(),r.Ne||r.qe(),r.Le(e.resumeToken);break;case 2:r.We(),r.Ne||this.removeTarget(t);break;case 3:this.rt(t)&&(r.Qe(),r.Le(e.resumeToken));break;case 4:this.rt(t)&&(this.it(t),r.Le(e.resumeToken));break;default:Y(56790,{state:e.state})}})}forEachTarget(e,t){e.targetIds.length>0?e.targetIds.forEach(t):this.ze.forEach((r,i)=>{this.rt(i)&&t(i)})}st(e){const t=e.targetId,r=e.Ce.count,i=this.ot(t);if(i){const o=i.target;if(kl(o))if(r===0){const s=new H(o.path);this.et(t,s,Ye.newNoDocument(s,J.min()))}else he(r===1,20013,{expectedCount:r});else{const s=this._t(t);if(s!==r){const l=this.ut(e),u=l?this.ct(l,e,s):1;if(u!==0){this.it(t);const h=u===2?"TargetPurposeExistenceFilterMismatchBloom":"TargetPurposeExistenceFilterMismatch";this.Ze=this.Ze.insert(t,h)}}}}}ut(e){const t=e.Ce.unchangedNames;if(!t||!t.bits)return null;const{bits:{bitmap:r="",padding:i=0},hashCount:o=0}=t;let s,l;try{s=zn(r).toUint8Array()}catch(u){if(u instanceof ap)return wr("Decoding the base64 bloom filter in existence filter failed ("+u.message+"); ignoring the bloom filter and falling back to full re-query."),null;throw u}try{l=new _c(s,i,o)}catch(u){return wr(u instanceof Xi?"BloomFilter error: ":"Applying bloom filter failed: ",u),null}return l.ge===0?null:l}ct(e,t,r){return t.Ce.count===r-this.Pt(e,t.targetId)?0:2}Pt(e,t){const r=this.Ge.getRemoteKeysForTarget(t);let i=0;return r.forEach(o=>{const s=this.Ge.ht(),l=`projects/${s.projectId}/databases/${s.database}/documents/${o.path.canonicalString()}`;e.mightContain(l)||(this.et(t,o,null),i++)}),i}Tt(e){const t=new Map;this.ze.forEach((o,s)=>{const l=this.ot(s);if(l){if(o.current&&kl(l.target)){const u=new H(l.target.path);this.Et(u).has(s)||this.It(s,u)||this.et(s,u,Ye.newNoDocument(u,e))}o.Be&&(t.set(s,o.ke()),o.qe())}});let r=ie();this.He.forEach((o,s)=>{let l=!0;s.forEachWhile(u=>{const h=this.ot(u);return!h||h.purpose==="TargetPurposeLimboResolution"||(l=!1,!1)}),l&&(r=r.add(o))}),this.je.forEach((o,s)=>s.setReadTime(e));const i=new va(e,t,this.Ze,this.je,r);return this.je=gn(),this.Je=cs(),this.He=cs(),this.Ze=new we(re),i}Ye(e,t){if(!this.rt(e))return;const r=this.It(e,t.key)?2:0;this.nt(e).Ke(t.key,r),this.je=this.je.insert(t.key,t),this.Je=this.Je.insert(t.key,this.Et(t.key).add(e)),this.He=this.He.insert(t.key,this.Rt(t.key).add(e))}et(e,t,r){if(!this.rt(e))return;const i=this.nt(e);this.It(e,t)?i.Ke(t,1):i.Ue(t),this.He=this.He.insert(t,this.Rt(t).delete(e)),this.He=this.He.insert(t,this.Rt(t).add(e)),r&&(this.je=this.je.insert(t,r))}removeTarget(e){this.ze.delete(e)}_t(e){const t=this.nt(e).ke();return this.Ge.getRemoteKeysForTarget(e).size+t.addedDocuments.size-t.removedDocuments.size}$e(e){this.nt(e).$e()}nt(e){let t=this.ze.get(e);return t||(t=new id,this.ze.set(e,t)),t}Rt(e){let t=this.He.get(e);return t||(t=new Fe(re),this.He=this.He.insert(e,t)),t}Et(e){let t=this.Je.get(e);return t||(t=new Fe(re),this.Je=this.Je.insert(e,t)),t}rt(e){const t=this.ot(e)!==null;return t||j("WatchChangeAggregator","Detected inactive target",e),t}ot(e){const t=this.ze.get(e);return t&&t.Ne?null:this.Ge.At(e)}it(e){this.ze.set(e,new id),this.Ge.getRemoteKeysForTarget(e).forEach(t=>{this.et(e,t,null)})}It(e,t){return this.Ge.getRemoteKeysForTarget(e).has(t)}}function cs(){return new we(H.comparator)}function od(){return new we(H.comparator)}const Ub={asc:"ASCENDING",desc:"DESCENDING"},qb={"<":"LESS_THAN","<=":"LESS_THAN_OR_EQUAL",">":"GREATER_THAN",">=":"GREATER_THAN_OR_EQUAL","==":"EQUAL","!=":"NOT_EQUAL","array-contains":"ARRAY_CONTAINS",in:"IN","not-in":"NOT_IN","array-contains-any":"ARRAY_CONTAINS_ANY"},Bb={and:"AND",or:"OR"};class $b{constructor(e,t){this.databaseId=e,this.useProto3Json=t}}function Cl(n,e){return n.useProto3Json||ha(e)?e:{value:e}}function Hs(n,e){return n.useProto3Json?`${new Date(1e3*e.seconds).toISOString().replace(/\.\d*/,"").replace("Z","")}.${("000000000"+e.nanoseconds).slice(-9)}Z`:{seconds:""+e.seconds,nanos:e.nanoseconds}}function Up(n,e){return n.useProto3Json?e.toBase64():e.toUint8Array()}function jb(n,e){return Hs(n,e.toTimestamp())}function zt(n){return he(!!n,49232),J.fromTimestamp(function(t){const r=jn(t);return new me(r.seconds,r.nanos)}(n))}function wc(n,e){return Rl(n,e).canonicalString()}function Rl(n,e){const t=function(i){return new pe(["projects",i.projectId,"databases",i.database])}(n).child("documents");return e===void 0?t:t.child(e)}function qp(n){const e=pe.fromString(n);return he(Wp(e),10190,{key:e.toString()}),e}function Ol(n,e){return wc(n.databaseId,e.path)}function nl(n,e){const t=qp(e);if(t.get(1)!==n.databaseId.projectId)throw new q(N.INVALID_ARGUMENT,"Tried to deserialize key from different project: "+t.get(1)+" vs "+n.databaseId.projectId);if(t.get(3)!==n.databaseId.database)throw new q(N.INVALID_ARGUMENT,"Tried to deserialize key from different database: "+t.get(3)+" vs "+n.databaseId.database);return new H($p(t))}function Bp(n,e){return wc(n.databaseId,e)}function zb(n){const e=qp(n);return e.length===4?pe.emptyPath():$p(e)}function Nl(n){return new pe(["projects",n.databaseId.projectId,"databases",n.databaseId.database]).canonicalString()}function $p(n){return he(n.length>4&&n.get(4)==="documents",29091,{key:n.toString()}),n.popFirst(5)}function sd(n,e,t){return{name:Ol(n,e),fields:t.value.mapValue.fields}}function Wb(n,e){let t;if("targetChange"in e){e.targetChange;const r=function(h){return h==="NO_CHANGE"?0:h==="ADD"?1:h==="REMOVE"?2:h==="CURRENT"?3:h==="RESET"?4:Y(39313,{state:h})}(e.targetChange.targetChangeType||"NO_CHANGE"),i=e.targetChange.targetIds||[],o=function(h,p){return h.useProto3Json?(he(p===void 0||typeof p=="string",58123),We.fromBase64String(p||"")):(he(p===void 0||p instanceof Buffer||p instanceof Uint8Array,16193),We.fromUint8Array(p||new Uint8Array))}(n,e.targetChange.resumeToken),s=e.targetChange.cause,l=s&&function(h){const p=h.code===void 0?N.UNKNOWN:Lp(h.code);return new q(p,h.message||"")}(s);t=new Fp(r,i,o,l||null)}else if("documentChange"in e){e.documentChange;const r=e.documentChange;r.document,r.document.name,r.document.updateTime;const i=nl(n,r.document.name),o=zt(r.document.updateTime),s=r.document.createTime?zt(r.document.createTime):J.min(),l=new ct({mapValue:{fields:r.document.fields}}),u=Ye.newFoundDocument(i,o,s,l),h=r.targetIds||[],p=r.removedTargetIds||[];t=new xs(h,p,u.key,u)}else if("documentDelete"in e){e.documentDelete;const r=e.documentDelete;r.document;const i=nl(n,r.document),o=r.readTime?zt(r.readTime):J.min(),s=Ye.newNoDocument(i,o),l=r.removedTargetIds||[];t=new xs([],l,s.key,s)}else if("documentRemove"in e){e.documentRemove;const r=e.documentRemove;r.document;const i=nl(n,r.document),o=r.removedTargetIds||[];t=new xs([],o,i,null)}else{if(!("filter"in e))return Y(11601,{Vt:e});{e.filter;const r=e.filter;r.targetId;const{count:i=0,unchangedNames:o}=r,s=new Db(i,o),l=r.targetId;t=new Vp(l,s)}}return t}function Hb(n,e){let t;if(e instanceof Uo)t={update:sd(n,e.key,e.value)};else if(e instanceof yc)t={delete:Ol(n,e.key)};else if(e instanceof Qn)t={update:sd(n,e.key,e.data),updateMask:tT(e.fieldMask)};else{if(!(e instanceof Rb))return Y(16599,{dt:e.type});t={verify:Ol(n,e.key)}}return e.fieldTransforms.length>0&&(t.updateTransforms=e.fieldTransforms.map(r=>function(o,s){const l=s.transform;if(l instanceof bo)return{fieldPath:s.field.canonicalString(),setToServerValue:"REQUEST_TIME"};if(l instanceof To)return{fieldPath:s.field.canonicalString(),appendMissingElements:{values:l.elements}};if(l instanceof Eo)return{fieldPath:s.field.canonicalString(),removeAllFromArray:{values:l.elements}};if(l instanceof Io)return{fieldPath:s.field.canonicalString(),increment:l.Ae};throw Y(20930,{transform:s.transform})}(0,r))),e.precondition.isNone||(t.currentDocument=function(i,o){return o.updateTime!==void 0?{updateTime:jb(i,o.updateTime)}:o.exists!==void 0?{exists:o.exists}:Y(27497)}(n,e.precondition)),t}function Gb(n,e){return n&&n.length>0?(he(e!==void 0,14353),n.map(t=>function(i,o){let s=i.updateTime?zt(i.updateTime):zt(o);return s.isEqual(J.min())&&(s=zt(o)),new kb(s,i.transformResults||[])}(t,e))):[]}function Kb(n,e){return{documents:[Bp(n,e.path)]}}function Yb(n,e){const t={structuredQuery:{}},r=e.path;let i;e.collectionGroup!==null?(i=r,t.structuredQuery.from=[{collectionId:e.collectionGroup,allDescendants:!0}]):(i=r.popLast(),t.structuredQuery.from=[{collectionId:r.lastSegment()}]),t.parent=Bp(n,i);const o=function(h){if(h.length!==0)return zp(Ct.create(h,"and"))}(e.filters);o&&(t.structuredQuery.where=o);const s=function(h){if(h.length!==0)return h.map(p=>function(g){return{field:Lr(g.field),direction:Xb(g.dir)}}(p))}(e.orderBy);s&&(t.structuredQuery.orderBy=s);const l=Cl(n,e.limit);return l!==null&&(t.structuredQuery.limit=l),e.startAt&&(t.structuredQuery.startAt=function(h){return{before:h.inclusive,values:h.position}}(e.startAt)),e.endAt&&(t.structuredQuery.endAt=function(h){return{before:!h.inclusive,values:h.position}}(e.endAt)),{ft:t,parent:i}}function Qb(n){let e=zb(n.parent);const t=n.structuredQuery,r=t.from?t.from.length:0;let i=null;if(r>0){he(r===1,65062);const p=t.from[0];p.allDescendants?i=p.collectionId:e=e.child(p.collectionId)}let o=[];t.where&&(o=function(m){const g=jp(m);return g instanceof Ct&&yp(g)?g.getFilters():[g]}(t.where));let s=[];t.orderBy&&(s=function(m){return m.map(g=>function(P){return new wo(Vr(P.field),function(C){switch(C){case"ASCENDING":return"asc";case"DESCENDING":return"desc";default:return}}(P.direction))}(g))}(t.orderBy));let l=null;t.limit&&(l=function(m){let g;return g=typeof m=="object"?m.value:m,ha(g)?null:g}(t.limit));let u=null;t.startAt&&(u=function(m){const g=!!m.before,b=m.values||[];return new zs(b,g)}(t.startAt));let h=null;return t.endAt&&(h=function(m){const g=!m.before,b=m.values||[];return new zs(b,g)}(t.endAt)),pb(e,i,s,o,l,"F",u,h)}function Jb(n,e){const t=function(i){switch(i){case"TargetPurposeListen":return null;case"TargetPurposeExistenceFilterMismatch":return"existence-filter-mismatch";case"TargetPurposeExistenceFilterMismatchBloom":return"existence-filter-mismatch-bloom";case"TargetPurposeLimboResolution":return"limbo-document";default:return Y(28987,{purpose:i})}}(e.purpose);return t==null?null:{"goog-listen-tags":t}}function jp(n){return n.unaryFilter!==void 0?function(t){switch(t.unaryFilter.op){case"IS_NAN":const r=Vr(t.unaryFilter.field);return Ce.create(r,"==",{doubleValue:NaN});case"IS_NULL":const i=Vr(t.unaryFilter.field);return Ce.create(i,"==",{nullValue:"NULL_VALUE"});case"IS_NOT_NAN":const o=Vr(t.unaryFilter.field);return Ce.create(o,"!=",{doubleValue:NaN});case"IS_NOT_NULL":const s=Vr(t.unaryFilter.field);return Ce.create(s,"!=",{nullValue:"NULL_VALUE"});case"OPERATOR_UNSPECIFIED":return Y(61313);default:return Y(60726)}}(n):n.fieldFilter!==void 0?function(t){return Ce.create(Vr(t.fieldFilter.field),function(i){switch(i){case"EQUAL":return"==";case"NOT_EQUAL":return"!=";case"GREATER_THAN":return">";case"GREATER_THAN_OR_EQUAL":return">=";case"LESS_THAN":return"<";case"LESS_THAN_OR_EQUAL":return"<=";case"ARRAY_CONTAINS":return"array-contains";case"IN":return"in";case"NOT_IN":return"not-in";case"ARRAY_CONTAINS_ANY":return"array-contains-any";case"OPERATOR_UNSPECIFIED":return Y(58110);default:return Y(50506)}}(t.fieldFilter.op),t.fieldFilter.value)}(n):n.compositeFilter!==void 0?function(t){return Ct.create(t.compositeFilter.filters.map(r=>jp(r)),function(i){switch(i){case"AND":return"and";case"OR":return"or";default:return Y(1026)}}(t.compositeFilter.op))}(n):Y(30097,{filter:n})}function Xb(n){return Ub[n]}function Zb(n){return qb[n]}function eT(n){return Bb[n]}function Lr(n){return{fieldPath:n.canonicalString()}}function Vr(n){return je.fromServerFormat(n.fieldPath)}function zp(n){return n instanceof Ce?function(t){if(t.op==="=="){if(Gh(t.value))return{unaryFilter:{field:Lr(t.field),op:"IS_NAN"}};if(Hh(t.value))return{unaryFilter:{field:Lr(t.field),op:"IS_NULL"}}}else if(t.op==="!="){if(Gh(t.value))return{unaryFilter:{field:Lr(t.field),op:"IS_NOT_NAN"}};if(Hh(t.value))return{unaryFilter:{field:Lr(t.field),op:"IS_NOT_NULL"}}}return{fieldFilter:{field:Lr(t.field),op:Zb(t.op),value:t.value}}}(n):n instanceof Ct?function(t){const r=t.getFilters().map(i=>zp(i));return r.length===1?r[0]:{compositeFilter:{op:eT(t.op),filters:r}}}(n):Y(54877,{filter:n})}function tT(n){const e=[];return n.fields.forEach(t=>e.push(t.canonicalString())),{fieldPaths:e}}function Wp(n){return n.length>=4&&n.get(0)==="projects"&&n.get(2)==="databases"}function Hp(n){return!!n&&typeof n._toProto=="function"&&n._protoValueType==="ProtoValue"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class On{constructor(e,t,r,i,o=J.min(),s=J.min(),l=We.EMPTY_BYTE_STRING,u=null){this.target=e,this.targetId=t,this.purpose=r,this.sequenceNumber=i,this.snapshotVersion=o,this.lastLimboFreeSnapshotVersion=s,this.resumeToken=l,this.expectedCount=u}withSequenceNumber(e){return new On(this.target,this.targetId,this.purpose,e,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,this.expectedCount)}withResumeToken(e,t){return new On(this.target,this.targetId,this.purpose,this.sequenceNumber,t,this.lastLimboFreeSnapshotVersion,e,null)}withExpectedCount(e){return new On(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,e)}withLastLimboFreeSnapshotVersion(e){return new On(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,e,this.resumeToken,this.expectedCount)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class nT{constructor(e){this.yt=e}}function rT(n){const e=Qb({parent:n.parent,structuredQuery:n.structuredQuery});return n.limitType==="LAST"?Ws(e,e.limit,"L"):e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class iT{constructor(){this.bn=new oT}addToCollectionParentIndex(e,t){return this.bn.add(t),D.resolve()}getCollectionParents(e,t){return D.resolve(this.bn.getEntries(t))}addFieldIndex(e,t){return D.resolve()}deleteFieldIndex(e,t){return D.resolve()}deleteAllFieldIndexes(e){return D.resolve()}createTargetIndexes(e,t){return D.resolve()}getDocumentsMatchingTarget(e,t){return D.resolve(null)}getIndexType(e,t){return D.resolve(0)}getFieldIndexes(e,t){return D.resolve([])}getNextCollectionGroupToUpdate(e){return D.resolve(null)}getMinOffset(e,t){return D.resolve($n.min())}getMinOffsetFromCollectionGroup(e,t){return D.resolve($n.min())}updateCollectionGroup(e,t,r){return D.resolve()}updateIndexEntries(e,t){return D.resolve()}}class oT{constructor(){this.index={}}add(e){const t=e.lastSegment(),r=e.popLast(),i=this.index[t]||new Fe(pe.comparator),o=!i.has(r);return this.index[t]=i.add(r),o}has(e){const t=e.lastSegment(),r=e.popLast(),i=this.index[t];return i&&i.has(r)}getEntries(e){return(this.index[e]||new Fe(pe.comparator)).toArray()}}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ad={didRun:!1,sequenceNumbersCollected:0,targetsRemoved:0,documentsRemoved:0},Gp=41943040;class st{static withCacheSize(e){return new st(e,st.DEFAULT_COLLECTION_PERCENTILE,st.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT)}constructor(e,t,r){this.cacheSizeCollectionThreshold=e,this.percentileToCollect=t,this.maximumSequenceNumbersToCollect=r}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */st.DEFAULT_COLLECTION_PERCENTILE=10,st.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT=1e3,st.DEFAULT=new st(Gp,st.DEFAULT_COLLECTION_PERCENTILE,st.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT),st.DISABLED=new st(-1,0,0);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ai{constructor(e){this.sr=e}next(){return this.sr+=2,this.sr}static _r(){return new ai(0)}static ar(){return new ai(-1)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ld="LruGarbageCollector",sT=1048576;function cd([n,e],[t,r]){const i=re(n,t);return i===0?re(e,r):i}class aT{constructor(e){this.Pr=e,this.buffer=new Fe(cd),this.Tr=0}Er(){return++this.Tr}Ir(e){const t=[e,this.Er()];if(this.buffer.size<this.Pr)this.buffer=this.buffer.add(t);else{const r=this.buffer.last();cd(t,r)<0&&(this.buffer=this.buffer.delete(r).add(t))}}get maxValue(){return this.buffer.last()[0]}}class lT{constructor(e,t,r){this.garbageCollector=e,this.asyncQueue=t,this.localStore=r,this.Rr=null}start(){this.garbageCollector.params.cacheSizeCollectionThreshold!==-1&&this.Ar(6e4)}stop(){this.Rr&&(this.Rr.cancel(),this.Rr=null)}get started(){return this.Rr!==null}Ar(e){j(ld,`Garbage collection scheduled in ${e}ms`),this.Rr=this.asyncQueue.enqueueAfterDelay("lru_garbage_collection",e,async()=>{this.Rr=null;try{await this.localStore.collectGarbage(this.garbageCollector)}catch(t){wi(t)?j(ld,"Ignoring IndexedDB error during garbage collection: ",t):await _i(t)}await this.Ar(3e5)})}}class cT{constructor(e,t){this.Vr=e,this.params=t}calculateTargetCount(e,t){return this.Vr.dr(e).next(r=>Math.floor(t/100*r))}nthSequenceNumber(e,t){if(t===0)return D.resolve(ua.ce);const r=new aT(t);return this.Vr.forEachTarget(e,i=>r.Ir(i.sequenceNumber)).next(()=>this.Vr.mr(e,i=>r.Ir(i))).next(()=>r.maxValue)}removeTargets(e,t,r){return this.Vr.removeTargets(e,t,r)}removeOrphanedDocuments(e,t){return this.Vr.removeOrphanedDocuments(e,t)}collect(e,t){return this.params.cacheSizeCollectionThreshold===-1?(j("LruGarbageCollector","Garbage collection skipped; disabled"),D.resolve(ad)):this.getCacheSize(e).next(r=>r<this.params.cacheSizeCollectionThreshold?(j("LruGarbageCollector",`Garbage collection skipped; Cache size ${r} is lower than threshold ${this.params.cacheSizeCollectionThreshold}`),ad):this.gr(e,t))}getCacheSize(e){return this.Vr.getCacheSize(e)}gr(e,t){let r,i,o,s,l,u,h;const p=Date.now();return this.calculateTargetCount(e,this.params.percentileToCollect).next(m=>(m>this.params.maximumSequenceNumbersToCollect?(j("LruGarbageCollector",`Capping sequence numbers to collect down to the maximum of ${this.params.maximumSequenceNumbersToCollect} from ${m}`),i=this.params.maximumSequenceNumbersToCollect):i=m,s=Date.now(),this.nthSequenceNumber(e,i))).next(m=>(r=m,l=Date.now(),this.removeTargets(e,r,t))).next(m=>(o=m,u=Date.now(),this.removeOrphanedDocuments(e,r))).next(m=>(h=Date.now(),Dr()<=ne.DEBUG&&j("LruGarbageCollector",`LRU Garbage Collection
	Counted targets in ${s-p}ms
	Determined least recently used ${i} in `+(l-s)+`ms
	Removed ${o} targets in `+(u-l)+`ms
	Removed ${m} documents in `+(h-u)+`ms
Total Duration: ${h-p}ms`),D.resolve({didRun:!0,sequenceNumbersCollected:i,targetsRemoved:o,documentsRemoved:m})))}}function uT(n,e){return new cT(n,e)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class hT{constructor(){this.changes=new Ar(e=>e.toString(),(e,t)=>e.isEqual(t)),this.changesApplied=!1}addEntry(e){this.assertNotApplied(),this.changes.set(e.key,e)}removeEntry(e,t){this.assertNotApplied(),this.changes.set(e,Ye.newInvalidDocument(e).setReadTime(t))}getEntry(e,t){this.assertNotApplied();const r=this.changes.get(t);return r!==void 0?D.resolve(r):this.getFromCache(e,t)}getEntries(e,t){return this.getAllFromCache(e,t)}apply(e){return this.assertNotApplied(),this.changesApplied=!0,this.applyChanges(e)}assertNotApplied(){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class dT{constructor(e,t){this.overlayedDocument=e,this.mutatedFields=t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fT{constructor(e,t,r,i){this.remoteDocumentCache=e,this.mutationQueue=t,this.documentOverlayCache=r,this.indexManager=i}getDocument(e,t){let r=null;return this.documentOverlayCache.getOverlay(e,t).next(i=>(r=i,this.remoteDocumentCache.getEntry(e,t))).next(i=>(r!==null&&ao(r.mutation,i,mt.empty(),me.now()),i))}getDocuments(e,t){return this.remoteDocumentCache.getEntries(e,t).next(r=>this.getLocalViewOfDocuments(e,r,ie()).next(()=>r))}getLocalViewOfDocuments(e,t,r=ie()){const i=sr();return this.populateOverlays(e,i,t).next(()=>this.computeViews(e,t,i,r).next(o=>{let s=Ji();return o.forEach((l,u)=>{s=s.insert(l,u.overlayedDocument)}),s}))}getOverlayedDocuments(e,t){const r=sr();return this.populateOverlays(e,r,t).next(()=>this.computeViews(e,t,r,ie()))}populateOverlays(e,t,r){const i=[];return r.forEach(o=>{t.has(o)||i.push(o)}),this.documentOverlayCache.getOverlays(e,i).next(o=>{o.forEach((s,l)=>{t.set(s,l)})})}computeViews(e,t,r,i){let o=gn();const s=so(),l=function(){return so()}();return t.forEach((u,h)=>{const p=r.get(h.key);i.has(h.key)&&(p===void 0||p.mutation instanceof Qn)?o=o.insert(h.key,h):p!==void 0?(s.set(h.key,p.mutation.getFieldMask()),ao(p.mutation,h,p.mutation.getFieldMask(),me.now())):s.set(h.key,mt.empty())}),this.recalculateAndSaveOverlays(e,o).next(u=>(u.forEach((h,p)=>s.set(h,p)),t.forEach((h,p)=>l.set(h,new dT(p,s.get(h)??null))),l))}recalculateAndSaveOverlays(e,t){const r=so();let i=new we((s,l)=>s-l),o=ie();return this.mutationQueue.getAllMutationBatchesAffectingDocumentKeys(e,t).next(s=>{for(const l of s)l.keys().forEach(u=>{const h=t.get(u);if(h===null)return;let p=r.get(u)||mt.empty();p=l.applyToLocalView(h,p),r.set(u,p);const m=(i.get(l.batchId)||ie()).add(u);i=i.insert(l.batchId,m)})}).next(()=>{const s=[],l=i.getReverseIterator();for(;l.hasNext();){const u=l.getNext(),h=u.key,p=u.value,m=Sp();p.forEach(g=>{if(!o.has(g)){const b=Dp(t.get(g),r.get(g));b!==null&&m.set(g,b),o=o.add(g)}}),s.push(this.documentOverlayCache.saveOverlays(e,h,m))}return D.waitFor(s)}).next(()=>r)}recalculateAndSaveOverlaysForDocumentKeys(e,t){return this.remoteDocumentCache.getEntries(e,t).next(r=>this.recalculateAndSaveOverlays(e,r))}getDocumentsMatchingQuery(e,t,r,i){return gb(t)?this.getDocumentsMatchingDocumentQuery(e,t.path):bp(t)?this.getDocumentsMatchingCollectionGroupQuery(e,t,r,i):this.getDocumentsMatchingCollectionQuery(e,t,r,i)}getNextDocuments(e,t,r,i){return this.remoteDocumentCache.getAllFromCollectionGroup(e,t,r,i).next(o=>{const s=i-o.size>0?this.documentOverlayCache.getOverlaysForCollectionGroup(e,t,r.largestBatchId,i-o.size):D.resolve(sr());let l=mo,u=o;return s.next(h=>D.forEach(h,(p,m)=>(l<m.largestBatchId&&(l=m.largestBatchId),o.get(p)?D.resolve():this.remoteDocumentCache.getEntry(e,p).next(g=>{u=u.insert(p,g)}))).next(()=>this.populateOverlays(e,h,o)).next(()=>this.computeViews(e,u,h,ie())).next(p=>({batchId:l,changes:Ap(p)})))})}getDocumentsMatchingDocumentQuery(e,t){return this.getDocument(e,new H(t)).next(r=>{let i=Ji();return r.isFoundDocument()&&(i=i.insert(r.key,r)),i})}getDocumentsMatchingCollectionGroupQuery(e,t,r,i){const o=t.collectionGroup;let s=Ji();return this.indexManager.getCollectionParents(e,o).next(l=>D.forEach(l,u=>{const h=function(m,g){return new bi(g,null,m.explicitOrderBy.slice(),m.filters.slice(),m.limit,m.limitType,m.startAt,m.endAt)}(t,u.child(o));return this.getDocumentsMatchingCollectionQuery(e,h,r,i).next(p=>{p.forEach((m,g)=>{s=s.insert(m,g)})})}).next(()=>s))}getDocumentsMatchingCollectionQuery(e,t,r,i){let o;return this.documentOverlayCache.getOverlaysForCollection(e,t.path,r.largestBatchId).next(s=>(o=s,this.remoteDocumentCache.getDocumentsMatchingQuery(e,t,r,o,i))).next(s=>{o.forEach((u,h)=>{const p=h.getKey();s.get(p)===null&&(s=s.insert(p,Ye.newInvalidDocument(p)))});let l=Ji();return s.forEach((u,h)=>{const p=o.get(u);p!==void 0&&ao(p.mutation,h,mt.empty(),me.now()),ga(t,h)&&(l=l.insert(u,h))}),l})}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class pT{constructor(e){this.serializer=e,this.Nr=new Map,this.Br=new Map}getBundleMetadata(e,t){return D.resolve(this.Nr.get(t))}saveBundleMetadata(e,t){return this.Nr.set(t.id,function(i){return{id:i.id,version:i.version,createTime:zt(i.createTime)}}(t)),D.resolve()}getNamedQuery(e,t){return D.resolve(this.Br.get(t))}saveNamedQuery(e,t){return this.Br.set(t.name,function(i){return{name:i.name,query:rT(i.bundledQuery),readTime:zt(i.readTime)}}(t)),D.resolve()}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class gT{constructor(){this.overlays=new we(H.comparator),this.Lr=new Map}getOverlay(e,t){return D.resolve(this.overlays.get(t))}getOverlays(e,t){const r=sr();return D.forEach(t,i=>this.getOverlay(e,i).next(o=>{o!==null&&r.set(i,o)})).next(()=>r)}saveOverlays(e,t,r){return r.forEach((i,o)=>{this.St(e,t,o)}),D.resolve()}removeOverlaysForBatchId(e,t,r){const i=this.Lr.get(r);return i!==void 0&&(i.forEach(o=>this.overlays=this.overlays.remove(o)),this.Lr.delete(r)),D.resolve()}getOverlaysForCollection(e,t,r){const i=sr(),o=t.length+1,s=new H(t.child("")),l=this.overlays.getIteratorFrom(s);for(;l.hasNext();){const u=l.getNext().value,h=u.getKey();if(!t.isPrefixOf(h.path))break;h.path.length===o&&u.largestBatchId>r&&i.set(u.getKey(),u)}return D.resolve(i)}getOverlaysForCollectionGroup(e,t,r,i){let o=new we((h,p)=>h-p);const s=this.overlays.getIterator();for(;s.hasNext();){const h=s.getNext().value;if(h.getKey().getCollectionGroup()===t&&h.largestBatchId>r){let p=o.get(h.largestBatchId);p===null&&(p=sr(),o=o.insert(h.largestBatchId,p)),p.set(h.getKey(),h)}}const l=sr(),u=o.getIterator();for(;u.hasNext()&&(u.getNext().value.forEach((h,p)=>l.set(h,p)),!(l.size()>=i)););return D.resolve(l)}St(e,t,r){const i=this.overlays.get(r.key);if(i!==null){const s=this.Lr.get(i.largestBatchId).delete(r.key);this.Lr.set(i.largestBatchId,s)}this.overlays=this.overlays.insert(r.key,new Nb(t,r));let o=this.Lr.get(t);o===void 0&&(o=ie(),this.Lr.set(t,o)),this.Lr.set(t,o.add(r.key))}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class mT{constructor(){this.sessionToken=We.EMPTY_BYTE_STRING}getSessionToken(e){return D.resolve(this.sessionToken)}setSessionToken(e,t){return this.sessionToken=t,D.resolve()}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class bc{constructor(){this.kr=new Fe(qe.qr),this.Kr=new Fe(qe.Ur)}isEmpty(){return this.kr.isEmpty()}addReference(e,t){const r=new qe(e,t);this.kr=this.kr.add(r),this.Kr=this.Kr.add(r)}$r(e,t){e.forEach(r=>this.addReference(r,t))}removeReference(e,t){this.Wr(new qe(e,t))}Qr(e,t){e.forEach(r=>this.removeReference(r,t))}Gr(e){const t=new H(new pe([])),r=new qe(t,e),i=new qe(t,e+1),o=[];return this.Kr.forEachInRange([r,i],s=>{this.Wr(s),o.push(s.key)}),o}zr(){this.kr.forEach(e=>this.Wr(e))}Wr(e){this.kr=this.kr.delete(e),this.Kr=this.Kr.delete(e)}jr(e){const t=new H(new pe([])),r=new qe(t,e),i=new qe(t,e+1);let o=ie();return this.Kr.forEachInRange([r,i],s=>{o=o.add(s.key)}),o}containsKey(e){const t=new qe(e,0),r=this.kr.firstAfterOrEqual(t);return r!==null&&e.isEqual(r.key)}}class qe{constructor(e,t){this.key=e,this.Jr=t}static qr(e,t){return H.comparator(e.key,t.key)||re(e.Jr,t.Jr)}static Ur(e,t){return re(e.Jr,t.Jr)||H.comparator(e.key,t.key)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class yT{constructor(e,t){this.indexManager=e,this.referenceDelegate=t,this.mutationQueue=[],this.Yn=1,this.Hr=new Fe(qe.qr)}checkEmpty(e){return D.resolve(this.mutationQueue.length===0)}addMutationBatch(e,t,r,i){const o=this.Yn;this.Yn++,this.mutationQueue.length>0&&this.mutationQueue[this.mutationQueue.length-1];const s=new Ob(o,t,r,i);this.mutationQueue.push(s);for(const l of i)this.Hr=this.Hr.add(new qe(l.key,o)),this.indexManager.addToCollectionParentIndex(e,l.key.path.popLast());return D.resolve(s)}lookupMutationBatch(e,t){return D.resolve(this.Zr(t))}getNextMutationBatchAfterBatchId(e,t){const r=t+1,i=this.Xr(r),o=i<0?0:i;return D.resolve(this.mutationQueue.length>o?this.mutationQueue[o]:null)}getHighestUnacknowledgedBatchId(){return D.resolve(this.mutationQueue.length===0?hc:this.Yn-1)}getAllMutationBatches(e){return D.resolve(this.mutationQueue.slice())}getAllMutationBatchesAffectingDocumentKey(e,t){const r=new qe(t,0),i=new qe(t,Number.POSITIVE_INFINITY),o=[];return this.Hr.forEachInRange([r,i],s=>{const l=this.Zr(s.Jr);o.push(l)}),D.resolve(o)}getAllMutationBatchesAffectingDocumentKeys(e,t){let r=new Fe(re);return t.forEach(i=>{const o=new qe(i,0),s=new qe(i,Number.POSITIVE_INFINITY);this.Hr.forEachInRange([o,s],l=>{r=r.add(l.Jr)})}),D.resolve(this.Yr(r))}getAllMutationBatchesAffectingQuery(e,t){const r=t.path,i=r.length+1;let o=r;H.isDocumentKey(o)||(o=o.child(""));const s=new qe(new H(o),0);let l=new Fe(re);return this.Hr.forEachWhile(u=>{const h=u.key.path;return!!r.isPrefixOf(h)&&(h.length===i&&(l=l.add(u.Jr)),!0)},s),D.resolve(this.Yr(l))}Yr(e){const t=[];return e.forEach(r=>{const i=this.Zr(r);i!==null&&t.push(i)}),t}removeMutationBatch(e,t){he(this.ei(t.batchId,"removed")===0,55003),this.mutationQueue.shift();let r=this.Hr;return D.forEach(t.mutations,i=>{const o=new qe(i.key,t.batchId);return r=r.delete(o),this.referenceDelegate.markPotentiallyOrphaned(e,i.key)}).next(()=>{this.Hr=r})}nr(e){}containsKey(e,t){const r=new qe(t,0),i=this.Hr.firstAfterOrEqual(r);return D.resolve(t.isEqual(i&&i.key))}performConsistencyCheck(e){return this.mutationQueue.length,D.resolve()}ei(e,t){return this.Xr(e)}Xr(e){return this.mutationQueue.length===0?0:e-this.mutationQueue[0].batchId}Zr(e){const t=this.Xr(e);return t<0||t>=this.mutationQueue.length?null:this.mutationQueue[t]}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class vT{constructor(e){this.ti=e,this.docs=function(){return new we(H.comparator)}(),this.size=0}setIndexManager(e){this.indexManager=e}addEntry(e,t){const r=t.key,i=this.docs.get(r),o=i?i.size:0,s=this.ti(t);return this.docs=this.docs.insert(r,{document:t.mutableCopy(),size:s}),this.size+=s-o,this.indexManager.addToCollectionParentIndex(e,r.path.popLast())}removeEntry(e){const t=this.docs.get(e);t&&(this.docs=this.docs.remove(e),this.size-=t.size)}getEntry(e,t){const r=this.docs.get(t);return D.resolve(r?r.document.mutableCopy():Ye.newInvalidDocument(t))}getEntries(e,t){let r=gn();return t.forEach(i=>{const o=this.docs.get(i);r=r.insert(i,o?o.document.mutableCopy():Ye.newInvalidDocument(i))}),D.resolve(r)}getDocumentsMatchingQuery(e,t,r,i){let o=gn();const s=t.path,l=new H(s.child("__id-9223372036854775808__")),u=this.docs.getIteratorFrom(l);for(;u.hasNext();){const{key:h,value:{document:p}}=u.getNext();if(!s.isPrefixOf(h.path))break;h.path.length>s.length+1||Ww(zw(p),r)<=0||(i.has(p.key)||ga(t,p))&&(o=o.insert(p.key,p.mutableCopy()))}return D.resolve(o)}getAllFromCollectionGroup(e,t,r,i){Y(9500)}ni(e,t){return D.forEach(this.docs,r=>t(r))}newChangeBuffer(e){return new _T(this)}getSize(e){return D.resolve(this.size)}}class _T extends hT{constructor(e){super(),this.Mr=e}applyChanges(e){const t=[];return this.changes.forEach((r,i)=>{i.isValidDocument()?t.push(this.Mr.addEntry(e,i)):this.Mr.removeEntry(r)}),D.waitFor(t)}getFromCache(e,t){return this.Mr.getEntry(e,t)}getAllFromCache(e,t){return this.Mr.getEntries(e,t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wT{constructor(e){this.persistence=e,this.ri=new Ar(t=>pc(t),gc),this.lastRemoteSnapshotVersion=J.min(),this.highestTargetId=0,this.ii=0,this.si=new bc,this.targetCount=0,this.oi=ai._r()}forEachTarget(e,t){return this.ri.forEach((r,i)=>t(i)),D.resolve()}getLastRemoteSnapshotVersion(e){return D.resolve(this.lastRemoteSnapshotVersion)}getHighestSequenceNumber(e){return D.resolve(this.ii)}allocateTargetId(e){return this.highestTargetId=this.oi.next(),D.resolve(this.highestTargetId)}setTargetsMetadata(e,t,r){return r&&(this.lastRemoteSnapshotVersion=r),t>this.ii&&(this.ii=t),D.resolve()}lr(e){this.ri.set(e.target,e);const t=e.targetId;t>this.highestTargetId&&(this.oi=new ai(t),this.highestTargetId=t),e.sequenceNumber>this.ii&&(this.ii=e.sequenceNumber)}addTargetData(e,t){return this.lr(t),this.targetCount+=1,D.resolve()}updateTargetData(e,t){return this.lr(t),D.resolve()}removeTargetData(e,t){return this.ri.delete(t.target),this.si.Gr(t.targetId),this.targetCount-=1,D.resolve()}removeTargets(e,t,r){let i=0;const o=[];return this.ri.forEach((s,l)=>{l.sequenceNumber<=t&&r.get(l.targetId)===null&&(this.ri.delete(s),o.push(this.removeMatchingKeysForTargetId(e,l.targetId)),i++)}),D.waitFor(o).next(()=>i)}getTargetCount(e){return D.resolve(this.targetCount)}getTargetData(e,t){const r=this.ri.get(t)||null;return D.resolve(r)}addMatchingKeys(e,t,r){return this.si.$r(t,r),D.resolve()}removeMatchingKeys(e,t,r){this.si.Qr(t,r);const i=this.persistence.referenceDelegate,o=[];return i&&t.forEach(s=>{o.push(i.markPotentiallyOrphaned(e,s))}),D.waitFor(o)}removeMatchingKeysForTargetId(e,t){return this.si.Gr(t),D.resolve()}getMatchingKeysForTargetId(e,t){const r=this.si.jr(t);return D.resolve(r)}containsKey(e,t){return D.resolve(this.si.containsKey(t))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Kp{constructor(e,t){this._i={},this.overlays={},this.ai=new ua(0),this.ui=!1,this.ui=!0,this.ci=new mT,this.referenceDelegate=e(this),this.li=new wT(this),this.indexManager=new iT,this.remoteDocumentCache=function(i){return new vT(i)}(r=>this.referenceDelegate.hi(r)),this.serializer=new nT(t),this.Pi=new pT(this.serializer)}start(){return Promise.resolve()}shutdown(){return this.ui=!1,Promise.resolve()}get started(){return this.ui}setDatabaseDeletedListener(){}setNetworkEnabled(){}getIndexManager(e){return this.indexManager}getDocumentOverlayCache(e){let t=this.overlays[e.toKey()];return t||(t=new gT,this.overlays[e.toKey()]=t),t}getMutationQueue(e,t){let r=this._i[e.toKey()];return r||(r=new yT(t,this.referenceDelegate),this._i[e.toKey()]=r),r}getGlobalsCache(){return this.ci}getTargetCache(){return this.li}getRemoteDocumentCache(){return this.remoteDocumentCache}getBundleCache(){return this.Pi}runTransaction(e,t,r){j("MemoryPersistence","Starting transaction:",e);const i=new bT(this.ai.next());return this.referenceDelegate.Ti(),r(i).next(o=>this.referenceDelegate.Ei(i).next(()=>o)).toPromise().then(o=>(i.raiseOnCommittedEvent(),o))}Ii(e,t){return D.or(Object.values(this._i).map(r=>()=>r.containsKey(e,t)))}}class bT extends Gw{constructor(e){super(),this.currentSequenceNumber=e}}class Tc{constructor(e){this.persistence=e,this.Ri=new bc,this.Ai=null}static Vi(e){return new Tc(e)}get di(){if(this.Ai)return this.Ai;throw Y(60996)}addReference(e,t,r){return this.Ri.addReference(r,t),this.di.delete(r.toString()),D.resolve()}removeReference(e,t,r){return this.Ri.removeReference(r,t),this.di.add(r.toString()),D.resolve()}markPotentiallyOrphaned(e,t){return this.di.add(t.toString()),D.resolve()}removeTarget(e,t){this.Ri.Gr(t.targetId).forEach(i=>this.di.add(i.toString()));const r=this.persistence.getTargetCache();return r.getMatchingKeysForTargetId(e,t.targetId).next(i=>{i.forEach(o=>this.di.add(o.toString()))}).next(()=>r.removeTargetData(e,t))}Ti(){this.Ai=new Set}Ei(e){const t=this.persistence.getRemoteDocumentCache().newChangeBuffer();return D.forEach(this.di,r=>{const i=H.fromPath(r);return this.mi(e,i).next(o=>{o||t.removeEntry(i,J.min())})}).next(()=>(this.Ai=null,t.apply(e)))}updateLimboDocument(e,t){return this.mi(e,t).next(r=>{r?this.di.delete(t.toString()):this.di.add(t.toString())})}hi(e){return 0}mi(e,t){return D.or([()=>D.resolve(this.Ri.containsKey(t)),()=>this.persistence.getTargetCache().containsKey(e,t),()=>this.persistence.Ii(e,t)])}}class Gs{constructor(e,t){this.persistence=e,this.fi=new Ar(r=>Qw(r.path),(r,i)=>r.isEqual(i)),this.garbageCollector=uT(this,t)}static Vi(e,t){return new Gs(e,t)}Ti(){}Ei(e){return D.resolve()}forEachTarget(e,t){return this.persistence.getTargetCache().forEachTarget(e,t)}dr(e){const t=this.pr(e);return this.persistence.getTargetCache().getTargetCount(e).next(r=>t.next(i=>r+i))}pr(e){let t=0;return this.mr(e,r=>{t++}).next(()=>t)}mr(e,t){return D.forEach(this.fi,(r,i)=>this.wr(e,r,i).next(o=>o?D.resolve():t(i)))}removeTargets(e,t,r){return this.persistence.getTargetCache().removeTargets(e,t,r)}removeOrphanedDocuments(e,t){let r=0;const i=this.persistence.getRemoteDocumentCache(),o=i.newChangeBuffer();return i.ni(e,s=>this.wr(e,s,t).next(l=>{l||(r++,o.removeEntry(s,J.min()))})).next(()=>o.apply(e)).next(()=>r)}markPotentiallyOrphaned(e,t){return this.fi.set(t,e.currentSequenceNumber),D.resolve()}removeTarget(e,t){const r=t.withSequenceNumber(e.currentSequenceNumber);return this.persistence.getTargetCache().updateTargetData(e,r)}addReference(e,t,r){return this.fi.set(r,e.currentSequenceNumber),D.resolve()}removeReference(e,t,r){return this.fi.set(r,e.currentSequenceNumber),D.resolve()}updateLimboDocument(e,t){return this.fi.set(t,e.currentSequenceNumber),D.resolve()}hi(e){let t=e.key.toString().length;return e.isFoundDocument()&&(t+=Is(e.data.value)),t}wr(e,t,r){return D.or([()=>this.persistence.Ii(e,t),()=>this.persistence.getTargetCache().containsKey(e,t),()=>{const i=this.fi.get(t);return D.resolve(i!==void 0&&i>r)}])}getCacheSize(e){return this.persistence.getRemoteDocumentCache().getSize(e)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ec{constructor(e,t,r,i){this.targetId=e,this.fromCache=t,this.Ts=r,this.Es=i}static Is(e,t){let r=ie(),i=ie();for(const o of t.docChanges)switch(o.type){case 0:r=r.add(o.doc.key);break;case 1:i=i.add(o.doc.key)}return new Ec(e,t.fromCache,r,i)}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class TT{constructor(){this._documentReadCount=0}get documentReadCount(){return this._documentReadCount}incrementDocumentReadCount(e){this._documentReadCount+=e}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ET{constructor(){this.Rs=!1,this.As=!1,this.Vs=100,this.ds=function(){return uy()?8:Kw(Qe())>0?6:4}()}initialize(e,t){this.fs=e,this.indexManager=t,this.Rs=!0}getDocumentsMatchingQuery(e,t,r,i){const o={result:null};return this.gs(e,t).next(s=>{o.result=s}).next(()=>{if(!o.result)return this.ps(e,t,i,r).next(s=>{o.result=s})}).next(()=>{if(o.result)return;const s=new TT;return this.ys(e,t,s).next(l=>{if(o.result=l,this.As)return this.ws(e,t,s,l.size)})}).next(()=>o.result)}ws(e,t,r,i){return r.documentReadCount<this.Vs?(Dr()<=ne.DEBUG&&j("QueryEngine","SDK will not create cache indexes for query:",Mr(t),"since it only creates cache indexes for collection contains","more than or equal to",this.Vs,"documents"),D.resolve()):(Dr()<=ne.DEBUG&&j("QueryEngine","Query:",Mr(t),"scans",r.documentReadCount,"local documents and returns",i,"documents as results."),r.documentReadCount>this.ds*i?(Dr()<=ne.DEBUG&&j("QueryEngine","The SDK decides to create cache indexes for query:",Mr(t),"as using cache indexes may help improve performance."),this.indexManager.createTargetIndexes(e,jt(t))):D.resolve())}gs(e,t){if(Jh(t))return D.resolve(null);let r=jt(t);return this.indexManager.getIndexType(e,r).next(i=>i===0?null:(t.limit!==null&&i===1&&(t=Ws(t,null,"F"),r=jt(t)),this.indexManager.getDocumentsMatchingTarget(e,r).next(o=>{const s=ie(...o);return this.fs.getDocuments(e,s).next(l=>this.indexManager.getMinOffset(e,r).next(u=>{const h=this.Ss(t,l);return this.bs(t,h,s,u.readTime)?this.gs(e,Ws(t,null,"F")):this.Ds(e,h,t,u)}))})))}ps(e,t,r,i){return Jh(t)||i.isEqual(J.min())?D.resolve(null):this.fs.getDocuments(e,r).next(o=>{const s=this.Ss(t,o);return this.bs(t,s,r,i)?D.resolve(null):(Dr()<=ne.DEBUG&&j("QueryEngine","Re-using previous result from %s to execute query: %s",i.toString(),Mr(t)),this.Ds(e,s,t,jw(i,mo)).next(l=>l))})}Ss(e,t){let r=new Fe(Ep(e));return t.forEach((i,o)=>{ga(e,o)&&(r=r.add(o))}),r}bs(e,t,r,i){if(e.limit===null)return!1;if(r.size!==t.size)return!0;const o=e.limitType==="F"?t.last():t.first();return!!o&&(o.hasPendingWrites||o.version.compareTo(i)>0)}ys(e,t,r){return Dr()<=ne.DEBUG&&j("QueryEngine","Using full collection scan to execute query:",Mr(t)),this.fs.getDocumentsMatchingQuery(e,t,$n.min(),r)}Ds(e,t,r,i){return this.fs.getDocumentsMatchingQuery(e,r,i).next(o=>(t.forEach(s=>{o=o.insert(s.key,s)}),o))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ic="LocalStore",IT=3e8;class AT{constructor(e,t,r,i){this.persistence=e,this.Cs=t,this.serializer=i,this.vs=new we(re),this.Fs=new Ar(o=>pc(o),gc),this.Ms=new Map,this.xs=e.getRemoteDocumentCache(),this.li=e.getTargetCache(),this.Pi=e.getBundleCache(),this.Os(r)}Os(e){this.documentOverlayCache=this.persistence.getDocumentOverlayCache(e),this.indexManager=this.persistence.getIndexManager(e),this.mutationQueue=this.persistence.getMutationQueue(e,this.indexManager),this.localDocuments=new fT(this.xs,this.mutationQueue,this.documentOverlayCache,this.indexManager),this.xs.setIndexManager(this.indexManager),this.Cs.initialize(this.localDocuments,this.indexManager)}collectGarbage(e){return this.persistence.runTransaction("Collect garbage","readwrite-primary",t=>e.collect(t,this.vs))}}function ST(n,e,t,r){return new AT(n,e,t,r)}async function Yp(n,e){const t=X(n);return await t.persistence.runTransaction("Handle user change","readonly",r=>{let i;return t.mutationQueue.getAllMutationBatches(r).next(o=>(i=o,t.Os(e),t.mutationQueue.getAllMutationBatches(r))).next(o=>{const s=[],l=[];let u=ie();for(const h of i){s.push(h.batchId);for(const p of h.mutations)u=u.add(p.key)}for(const h of o){l.push(h.batchId);for(const p of h.mutations)u=u.add(p.key)}return t.localDocuments.getDocuments(r,u).next(h=>({Ns:h,removedBatchIds:s,addedBatchIds:l}))})})}function xT(n,e){const t=X(n);return t.persistence.runTransaction("Acknowledge batch","readwrite-primary",r=>{const i=e.batch.keys(),o=t.xs.newChangeBuffer({trackRemovals:!0});return function(l,u,h,p){const m=h.batch,g=m.keys();let b=D.resolve();return g.forEach(P=>{b=b.next(()=>p.getEntry(u,P)).next(A=>{const C=h.docVersions.get(P);he(C!==null,48541),A.version.compareTo(C)<0&&(m.applyToRemoteDocument(A,h),A.isValidDocument()&&(A.setReadTime(h.commitVersion),p.addEntry(A)))})}),b.next(()=>l.mutationQueue.removeMutationBatch(u,m))}(t,r,e,o).next(()=>o.apply(r)).next(()=>t.mutationQueue.performConsistencyCheck(r)).next(()=>t.documentOverlayCache.removeOverlaysForBatchId(r,i,e.batch.batchId)).next(()=>t.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(r,function(l){let u=ie();for(let h=0;h<l.mutationResults.length;++h)l.mutationResults[h].transformResults.length>0&&(u=u.add(l.batch.mutations[h].key));return u}(e))).next(()=>t.localDocuments.getDocuments(r,i))})}function Qp(n){const e=X(n);return e.persistence.runTransaction("Get last remote snapshot version","readonly",t=>e.li.getLastRemoteSnapshotVersion(t))}function kT(n,e){const t=X(n),r=e.snapshotVersion;let i=t.vs;return t.persistence.runTransaction("Apply remote event","readwrite-primary",o=>{const s=t.xs.newChangeBuffer({trackRemovals:!0});i=t.vs;const l=[];e.targetChanges.forEach((p,m)=>{const g=i.get(m);if(!g)return;l.push(t.li.removeMatchingKeys(o,p.removedDocuments,m).next(()=>t.li.addMatchingKeys(o,p.addedDocuments,m)));let b=g.withSequenceNumber(o.currentSequenceNumber);e.targetMismatches.get(m)!==null?b=b.withResumeToken(We.EMPTY_BYTE_STRING,J.min()).withLastLimboFreeSnapshotVersion(J.min()):p.resumeToken.approximateByteSize()>0&&(b=b.withResumeToken(p.resumeToken,r)),i=i.insert(m,b),function(A,C,$){return A.resumeToken.approximateByteSize()===0||C.snapshotVersion.toMicroseconds()-A.snapshotVersion.toMicroseconds()>=IT?!0:$.addedDocuments.size+$.modifiedDocuments.size+$.removedDocuments.size>0}(g,b,p)&&l.push(t.li.updateTargetData(o,b))});let u=gn(),h=ie();if(e.documentUpdates.forEach(p=>{e.resolvedLimboDocuments.has(p)&&l.push(t.persistence.referenceDelegate.updateLimboDocument(o,p))}),l.push(PT(o,s,e.documentUpdates).next(p=>{u=p.Bs,h=p.Ls})),!r.isEqual(J.min())){const p=t.li.getLastRemoteSnapshotVersion(o).next(m=>t.li.setTargetsMetadata(o,o.currentSequenceNumber,r));l.push(p)}return D.waitFor(l).next(()=>s.apply(o)).next(()=>t.localDocuments.getLocalViewOfDocuments(o,u,h)).next(()=>u)}).then(o=>(t.vs=i,o))}function PT(n,e,t){let r=ie(),i=ie();return t.forEach(o=>r=r.add(o)),e.getEntries(n,r).next(o=>{let s=gn();return t.forEach((l,u)=>{const h=o.get(l);u.isFoundDocument()!==h.isFoundDocument()&&(i=i.add(l)),u.isNoDocument()&&u.version.isEqual(J.min())?(e.removeEntry(l,u.readTime),s=s.insert(l,u)):!h.isValidDocument()||u.version.compareTo(h.version)>0||u.version.compareTo(h.version)===0&&h.hasPendingWrites?(e.addEntry(u),s=s.insert(l,u)):j(Ic,"Ignoring outdated watch update for ",l,". Current version:",h.version," Watch version:",u.version)}),{Bs:s,Ls:i}})}function CT(n,e){const t=X(n);return t.persistence.runTransaction("Get next mutation batch","readonly",r=>(e===void 0&&(e=hc),t.mutationQueue.getNextMutationBatchAfterBatchId(r,e)))}function RT(n,e){const t=X(n);return t.persistence.runTransaction("Allocate target","readwrite",r=>{let i;return t.li.getTargetData(r,e).next(o=>o?(i=o,D.resolve(i)):t.li.allocateTargetId(r).next(s=>(i=new On(e,s,"TargetPurposeListen",r.currentSequenceNumber),t.li.addTargetData(r,i).next(()=>i))))}).then(r=>{const i=t.vs.get(r.targetId);return(i===null||r.snapshotVersion.compareTo(i.snapshotVersion)>0)&&(t.vs=t.vs.insert(r.targetId,r),t.Fs.set(e,r.targetId)),r})}async function Dl(n,e,t){const r=X(n),i=r.vs.get(e),o=t?"readwrite":"readwrite-primary";try{t||await r.persistence.runTransaction("Release target",o,s=>r.persistence.referenceDelegate.removeTarget(s,i))}catch(s){if(!wi(s))throw s;j(Ic,`Failed to update sequence numbers for target ${e}: ${s}`)}r.vs=r.vs.remove(e),r.Fs.delete(i.target)}function ud(n,e,t){const r=X(n);let i=J.min(),o=ie();return r.persistence.runTransaction("Execute query","readwrite",s=>function(u,h,p){const m=X(u),g=m.Fs.get(p);return g!==void 0?D.resolve(m.vs.get(g)):m.li.getTargetData(h,p)}(r,s,jt(e)).next(l=>{if(l)return i=l.lastLimboFreeSnapshotVersion,r.li.getMatchingKeysForTargetId(s,l.targetId).next(u=>{o=u})}).next(()=>r.Cs.getDocumentsMatchingQuery(s,e,t?i:J.min(),t?o:ie())).next(l=>(OT(r,vb(e),l),{documents:l,ks:o})))}function OT(n,e,t){let r=n.Ms.get(e)||J.min();t.forEach((i,o)=>{o.readTime.compareTo(r)>0&&(r=o.readTime)}),n.Ms.set(e,r)}class hd{constructor(){this.activeTargetIds=Ib()}Qs(e){this.activeTargetIds=this.activeTargetIds.add(e)}Gs(e){this.activeTargetIds=this.activeTargetIds.delete(e)}Ws(){const e={activeTargetIds:this.activeTargetIds.toArray(),updateTimeMs:Date.now()};return JSON.stringify(e)}}class NT{constructor(){this.vo=new hd,this.Fo={},this.onlineStateHandler=null,this.sequenceNumberHandler=null}addPendingMutation(e){}updateMutationState(e,t,r){}addLocalQueryTarget(e,t=!0){return t&&this.vo.Qs(e),this.Fo[e]||"not-current"}updateQueryState(e,t,r){this.Fo[e]=t}removeLocalQueryTarget(e){this.vo.Gs(e)}isLocalQueryTarget(e){return this.vo.activeTargetIds.has(e)}clearQueryState(e){delete this.Fo[e]}getAllActiveQueryTargets(){return this.vo.activeTargetIds}isActiveQueryTarget(e){return this.vo.activeTargetIds.has(e)}start(){return this.vo=new hd,Promise.resolve()}handleUserChange(e,t,r){}setOnlineState(e){}shutdown(){}writeSequenceNumber(e){}notifyBundleLoaded(e){}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class DT{Mo(e){}shutdown(){}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const dd="ConnectivityMonitor";class fd{constructor(){this.xo=()=>this.Oo(),this.No=()=>this.Bo(),this.Lo=[],this.ko()}Mo(e){this.Lo.push(e)}shutdown(){window.removeEventListener("online",this.xo),window.removeEventListener("offline",this.No)}ko(){window.addEventListener("online",this.xo),window.addEventListener("offline",this.No)}Oo(){j(dd,"Network connectivity changed: AVAILABLE");for(const e of this.Lo)e(0)}Bo(){j(dd,"Network connectivity changed: UNAVAILABLE");for(const e of this.Lo)e(1)}static v(){return typeof window<"u"&&window.addEventListener!==void 0&&window.removeEventListener!==void 0}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let us=null;function Ml(){return us===null?us=function(){return 268435456+Math.round(2147483648*Math.random())}():us++,"0x"+us.toString(16)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const rl="RestConnection",MT={BatchGetDocuments:"batchGet",Commit:"commit",RunQuery:"runQuery",RunAggregationQuery:"runAggregationQuery",ExecutePipeline:"executePipeline"};class LT{get qo(){return!1}constructor(e){this.databaseInfo=e,this.databaseId=e.databaseId;const t=e.ssl?"https":"http",r=encodeURIComponent(this.databaseId.projectId),i=encodeURIComponent(this.databaseId.database);this.Ko=t+"://"+e.host,this.Uo=`projects/${r}/databases/${i}`,this.$o=this.databaseId.database===$s?`project_id=${r}`:`project_id=${r}&database_id=${i}`}Wo(e,t,r,i,o){const s=Ml(),l=this.Qo(e,t.toUriEncodedString());j(rl,`Sending RPC '${e}' ${s}:`,l,r);const u={"google-cloud-resource-prefix":this.Uo,"x-goog-request-params":this.$o};this.Go(u,i,o);const{host:h}=new URL(l),p=Do(h);return this.zo(e,l,u,r,p).then(m=>(j(rl,`Received RPC '${e}' ${s}: `,m),m),m=>{throw wr(rl,`RPC '${e}' ${s} failed with error: `,m,"url: ",l,"request:",r),m})}jo(e,t,r,i,o,s){return this.Wo(e,t,r,i,o)}Go(e,t,r){e["X-Goog-Api-Client"]=function(){return"gl-js/ fire/"+vi}(),e["Content-Type"]="text/plain",this.databaseInfo.appId&&(e["X-Firebase-GMPID"]=this.databaseInfo.appId),t&&t.headers.forEach((i,o)=>e[o]=i),r&&r.headers.forEach((i,o)=>e[o]=i)}Qo(e,t){const r=MT[e];let i=`${this.Ko}/v1/${t}:${r}`;return this.databaseInfo.apiKey&&(i=`${i}?key=${encodeURIComponent(this.databaseInfo.apiKey)}`),i}terminate(){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class VT{constructor(e){this.Jo=e.Jo,this.Ho=e.Ho}Zo(e){this.Xo=e}Yo(e){this.e_=e}t_(e){this.n_=e}onMessage(e){this.r_=e}close(){this.Ho()}send(e){this.Jo(e)}i_(){this.Xo()}s_(){this.e_()}o_(e){this.n_(e)}__(e){this.r_(e)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ge="WebChannelConnection",$i=(n,e,t)=>{n.listen(e,r=>{try{t(r)}catch(i){setTimeout(()=>{throw i},0)}})};class Wr extends LT{constructor(e){super(e),this.a_=[],this.forceLongPolling=e.forceLongPolling,this.autoDetectLongPolling=e.autoDetectLongPolling,this.useFetchStreams=e.useFetchStreams,this.longPollingOptions=e.longPollingOptions}static u_(){if(!Wr.c_){const e=Zf();$i(e,Xf.STAT_EVENT,t=>{t.stat===El.PROXY?j(Ge,"STAT_EVENT: detected buffering proxy"):t.stat===El.NOPROXY&&j(Ge,"STAT_EVENT: detected no buffering proxy")}),Wr.c_=!0}}zo(e,t,r,i,o){const s=Ml();return new Promise((l,u)=>{const h=new Qf;h.setWithCredentials(!0),h.listenOnce(Jf.COMPLETE,()=>{try{switch(h.getLastErrorCode()){case Es.NO_ERROR:const m=h.getResponseJson();j(Ge,`XHR for RPC '${e}' ${s} received:`,JSON.stringify(m)),l(m);break;case Es.TIMEOUT:j(Ge,`RPC '${e}' ${s} timed out`),u(new q(N.DEADLINE_EXCEEDED,"Request time out"));break;case Es.HTTP_ERROR:const g=h.getStatus();if(j(Ge,`RPC '${e}' ${s} failed with status:`,g,"response text:",h.getResponseText()),g>0){let b=h.getResponseJson();Array.isArray(b)&&(b=b[0]);const P=b==null?void 0:b.error;if(P&&P.status&&P.message){const A=function($){const F=$.toLowerCase().replace(/_/g,"-");return Object.values(N).indexOf(F)>=0?F:N.UNKNOWN}(P.status);u(new q(A,P.message))}else u(new q(N.UNKNOWN,"Server responded with status "+h.getStatus()))}else u(new q(N.UNAVAILABLE,"Connection failed."));break;default:Y(9055,{l_:e,streamId:s,h_:h.getLastErrorCode(),P_:h.getLastError()})}}finally{j(Ge,`RPC '${e}' ${s} completed.`)}});const p=JSON.stringify(i);j(Ge,`RPC '${e}' ${s} sending request:`,i),h.send(t,"POST",p,r,15)})}T_(e,t,r){const i=Ml(),o=[this.Ko,"/","google.firestore.v1.Firestore","/",e,"/channel"],s=this.createWebChannelTransport(),l={httpSessionIdParam:"gsessionid",initMessageHeaders:{},messageUrlParams:{database:`projects/${this.databaseId.projectId}/databases/${this.databaseId.database}`},sendRawJson:!0,supportsCrossDomainXhr:!0,internalChannelParams:{forwardChannelRequestTimeoutMs:6e5},forceLongPolling:this.forceLongPolling,detectBufferingProxy:this.autoDetectLongPolling},u=this.longPollingOptions.timeoutSeconds;u!==void 0&&(l.longPollingTimeout=Math.round(1e3*u)),this.useFetchStreams&&(l.useFetchStreams=!0),this.Go(l.initMessageHeaders,t,r),l.encodeInitMessageHeaders=!0;const h=o.join("");j(Ge,`Creating RPC '${e}' stream ${i}: ${h}`,l);const p=s.createWebChannel(h,l);this.E_(p);let m=!1,g=!1;const b=new VT({Jo:P=>{g?j(Ge,`Not sending because RPC '${e}' stream ${i} is closed:`,P):(m||(j(Ge,`Opening RPC '${e}' stream ${i} transport.`),p.open(),m=!0),j(Ge,`RPC '${e}' stream ${i} sending:`,P),p.send(P))},Ho:()=>p.close()});return $i(p,Qi.EventType.OPEN,()=>{g||(j(Ge,`RPC '${e}' stream ${i} transport opened.`),b.i_())}),$i(p,Qi.EventType.CLOSE,()=>{g||(g=!0,j(Ge,`RPC '${e}' stream ${i} transport closed`),b.o_(),this.I_(p))}),$i(p,Qi.EventType.ERROR,P=>{g||(g=!0,wr(Ge,`RPC '${e}' stream ${i} transport errored. Name:`,P.name,"Message:",P.message),b.o_(new q(N.UNAVAILABLE,"The operation could not be completed")))}),$i(p,Qi.EventType.MESSAGE,P=>{var A;if(!g){const C=P.data[0];he(!!C,16349);const $=C,F=($==null?void 0:$.error)||((A=$[0])==null?void 0:A.error);if(F){j(Ge,`RPC '${e}' stream ${i} received error:`,F);const V=F.status;let G=function(E){const v=Pe[E];if(v!==void 0)return Lp(v)}(V),z=F.message;V==="NOT_FOUND"&&z.includes("database")&&z.includes("does not exist")&&z.includes(this.databaseId.database)&&wr(`Database '${this.databaseId.database}' not found. Please check your project configuration.`),G===void 0&&(G=N.INTERNAL,z="Unknown error status: "+V+" with message "+F.message),g=!0,b.o_(new q(G,z)),p.close()}else j(Ge,`RPC '${e}' stream ${i} received:`,C),b.__(C)}}),Wr.u_(),setTimeout(()=>{b.s_()},0),b}terminate(){this.a_.forEach(e=>e.close()),this.a_=[]}E_(e){this.a_.push(e)}I_(e){this.a_=this.a_.filter(t=>t===e)}Go(e,t,r){super.Go(e,t,r),this.databaseInfo.apiKey&&(e["x-goog-api-key"]=this.databaseInfo.apiKey)}createWebChannelTransport(){return ep()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function FT(n){return new Wr(n)}function il(){return typeof document<"u"?document:null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function _a(n){return new $b(n,!0)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */Wr.c_=!1;class Jp{constructor(e,t,r=1e3,i=1.5,o=6e4){this.Ci=e,this.timerId=t,this.R_=r,this.A_=i,this.V_=o,this.d_=0,this.m_=null,this.f_=Date.now(),this.reset()}reset(){this.d_=0}g_(){this.d_=this.V_}p_(e){this.cancel();const t=Math.floor(this.d_+this.y_()),r=Math.max(0,Date.now()-this.f_),i=Math.max(0,t-r);i>0&&j("ExponentialBackoff",`Backing off for ${i} ms (base delay: ${this.d_} ms, delay with jitter: ${t} ms, last attempt: ${r} ms ago)`),this.m_=this.Ci.enqueueAfterDelay(this.timerId,i,()=>(this.f_=Date.now(),e())),this.d_*=this.A_,this.d_<this.R_&&(this.d_=this.R_),this.d_>this.V_&&(this.d_=this.V_)}w_(){this.m_!==null&&(this.m_.skipDelay(),this.m_=null)}cancel(){this.m_!==null&&(this.m_.cancel(),this.m_=null)}y_(){return(Math.random()-.5)*this.d_}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const pd="PersistentStream";class Xp{constructor(e,t,r,i,o,s,l,u){this.Ci=e,this.S_=r,this.b_=i,this.connection=o,this.authCredentialsProvider=s,this.appCheckCredentialsProvider=l,this.listener=u,this.state=0,this.D_=0,this.C_=null,this.v_=null,this.stream=null,this.F_=0,this.M_=new Jp(e,t)}x_(){return this.state===1||this.state===5||this.O_()}O_(){return this.state===2||this.state===3}start(){this.F_=0,this.state!==4?this.auth():this.N_()}async stop(){this.x_()&&await this.close(0)}B_(){this.state=0,this.M_.reset()}L_(){this.O_()&&this.C_===null&&(this.C_=this.Ci.enqueueAfterDelay(this.S_,6e4,()=>this.k_()))}q_(e){this.K_(),this.stream.send(e)}async k_(){if(this.O_())return this.close(0)}K_(){this.C_&&(this.C_.cancel(),this.C_=null)}U_(){this.v_&&(this.v_.cancel(),this.v_=null)}async close(e,t){this.K_(),this.U_(),this.M_.cancel(),this.D_++,e!==4?this.M_.reset():t&&t.code===N.RESOURCE_EXHAUSTED?(pn(t.toString()),pn("Using maximum backoff delay to prevent overloading the backend."),this.M_.g_()):t&&t.code===N.UNAUTHENTICATED&&this.state!==3&&(this.authCredentialsProvider.invalidateToken(),this.appCheckCredentialsProvider.invalidateToken()),this.stream!==null&&(this.W_(),this.stream.close(),this.stream=null),this.state=e,await this.listener.t_(t)}W_(){}auth(){this.state=1;const e=this.Q_(this.D_),t=this.D_;Promise.all([this.authCredentialsProvider.getToken(),this.appCheckCredentialsProvider.getToken()]).then(([r,i])=>{this.D_===t&&this.G_(r,i)},r=>{e(()=>{const i=new q(N.UNKNOWN,"Fetching auth token failed: "+r.message);return this.z_(i)})})}G_(e,t){const r=this.Q_(this.D_);this.stream=this.j_(e,t),this.stream.Zo(()=>{r(()=>this.listener.Zo())}),this.stream.Yo(()=>{r(()=>(this.state=2,this.v_=this.Ci.enqueueAfterDelay(this.b_,1e4,()=>(this.O_()&&(this.state=3),Promise.resolve())),this.listener.Yo()))}),this.stream.t_(i=>{r(()=>this.z_(i))}),this.stream.onMessage(i=>{r(()=>++this.F_==1?this.J_(i):this.onNext(i))})}N_(){this.state=5,this.M_.p_(async()=>{this.state=0,this.start()})}z_(e){return j(pd,`close with error: ${e}`),this.stream=null,this.close(4,e)}Q_(e){return t=>{this.Ci.enqueueAndForget(()=>this.D_===e?t():(j(pd,"stream callback skipped by getCloseGuardedDispatcher."),Promise.resolve()))}}}class UT extends Xp{constructor(e,t,r,i,o,s){super(e,"listen_stream_connection_backoff","listen_stream_idle","health_check_timeout",t,r,i,s),this.serializer=o}j_(e,t){return this.connection.T_("Listen",e,t)}J_(e){return this.onNext(e)}onNext(e){this.M_.reset();const t=Wb(this.serializer,e),r=function(o){if(!("targetChange"in o))return J.min();const s=o.targetChange;return s.targetIds&&s.targetIds.length?J.min():s.readTime?zt(s.readTime):J.min()}(e);return this.listener.H_(t,r)}Z_(e){const t={};t.database=Nl(this.serializer),t.addTarget=function(o,s){let l;const u=s.target;if(l=kl(u)?{documents:Kb(o,u)}:{query:Yb(o,u).ft},l.targetId=s.targetId,s.resumeToken.approximateByteSize()>0){l.resumeToken=Up(o,s.resumeToken);const h=Cl(o,s.expectedCount);h!==null&&(l.expectedCount=h)}else if(s.snapshotVersion.compareTo(J.min())>0){l.readTime=Hs(o,s.snapshotVersion.toTimestamp());const h=Cl(o,s.expectedCount);h!==null&&(l.expectedCount=h)}return l}(this.serializer,e);const r=Jb(this.serializer,e);r&&(t.labels=r),this.q_(t)}X_(e){const t={};t.database=Nl(this.serializer),t.removeTarget=e,this.q_(t)}}class qT extends Xp{constructor(e,t,r,i,o,s){super(e,"write_stream_connection_backoff","write_stream_idle","health_check_timeout",t,r,i,s),this.serializer=o}get Y_(){return this.F_>0}start(){this.lastStreamToken=void 0,super.start()}W_(){this.Y_&&this.ea([])}j_(e,t){return this.connection.T_("Write",e,t)}J_(e){return he(!!e.streamToken,31322),this.lastStreamToken=e.streamToken,he(!e.writeResults||e.writeResults.length===0,55816),this.listener.ta()}onNext(e){he(!!e.streamToken,12678),this.lastStreamToken=e.streamToken,this.M_.reset();const t=Gb(e.writeResults,e.commitTime),r=zt(e.commitTime);return this.listener.na(r,t)}ra(){const e={};e.database=Nl(this.serializer),this.q_(e)}ea(e){const t={streamToken:this.lastStreamToken,writes:e.map(r=>Hb(this.serializer,r))};this.q_(t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class BT{}class $T extends BT{constructor(e,t,r,i){super(),this.authCredentials=e,this.appCheckCredentials=t,this.connection=r,this.serializer=i,this.ia=!1}sa(){if(this.ia)throw new q(N.FAILED_PRECONDITION,"The client has already been terminated.")}Wo(e,t,r,i){return this.sa(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then(([o,s])=>this.connection.Wo(e,Rl(t,r),i,o,s)).catch(o=>{throw o.name==="FirebaseError"?(o.code===N.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),o):new q(N.UNKNOWN,o.toString())})}jo(e,t,r,i,o){return this.sa(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then(([s,l])=>this.connection.jo(e,Rl(t,r),i,s,l,o)).catch(s=>{throw s.name==="FirebaseError"?(s.code===N.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),s):new q(N.UNKNOWN,s.toString())})}terminate(){this.ia=!0,this.connection.terminate()}}function jT(n,e,t,r){return new $T(n,e,t,r)}class zT{constructor(e,t){this.asyncQueue=e,this.onlineStateHandler=t,this.state="Unknown",this.oa=0,this._a=null,this.aa=!0}ua(){this.oa===0&&(this.ca("Unknown"),this._a=this.asyncQueue.enqueueAfterDelay("online_state_timeout",1e4,()=>(this._a=null,this.la("Backend didn't respond within 10 seconds."),this.ca("Offline"),Promise.resolve())))}ha(e){this.state==="Online"?this.ca("Unknown"):(this.oa++,this.oa>=1&&(this.Pa(),this.la(`Connection failed 1 times. Most recent error: ${e.toString()}`),this.ca("Offline")))}set(e){this.Pa(),this.oa=0,e==="Online"&&(this.aa=!1),this.ca(e)}ca(e){e!==this.state&&(this.state=e,this.onlineStateHandler(e))}la(e){const t=`Could not reach Cloud Firestore backend. ${e}
This typically indicates that your device does not have a healthy Internet connection at the moment. The client will operate in offline mode until it is able to successfully connect to the backend.`;this.aa?(pn(t),this.aa=!1):j("OnlineStateTracker",t)}Pa(){this._a!==null&&(this._a.cancel(),this._a=null)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const br="RemoteStore";class WT{constructor(e,t,r,i,o){this.localStore=e,this.datastore=t,this.asyncQueue=r,this.remoteSyncer={},this.Ta=[],this.Ea=new Map,this.Ia=new Set,this.Ra=[],this.Aa=o,this.Aa.Mo(s=>{r.enqueueAndForget(async()=>{Sr(this)&&(j(br,"Restarting streams for network reachability change."),await async function(u){const h=X(u);h.Ia.add(4),await Bo(h),h.Va.set("Unknown"),h.Ia.delete(4),await wa(h)}(this))})}),this.Va=new zT(r,i)}}async function wa(n){if(Sr(n))for(const e of n.Ra)await e(!0)}async function Bo(n){for(const e of n.Ra)await e(!1)}function Zp(n,e){const t=X(n);t.Ea.has(e.targetId)||(t.Ea.set(e.targetId,e),kc(t)?xc(t):Ti(t).O_()&&Sc(t,e))}function Ac(n,e){const t=X(n),r=Ti(t);t.Ea.delete(e),r.O_()&&eg(t,e),t.Ea.size===0&&(r.O_()?r.L_():Sr(t)&&t.Va.set("Unknown"))}function Sc(n,e){if(n.da.$e(e.targetId),e.resumeToken.approximateByteSize()>0||e.snapshotVersion.compareTo(J.min())>0){const t=n.remoteSyncer.getRemoteKeysForTarget(e.targetId).size;e=e.withExpectedCount(t)}Ti(n).Z_(e)}function eg(n,e){n.da.$e(e),Ti(n).X_(e)}function xc(n){n.da=new Fb({getRemoteKeysForTarget:e=>n.remoteSyncer.getRemoteKeysForTarget(e),At:e=>n.Ea.get(e)||null,ht:()=>n.datastore.serializer.databaseId}),Ti(n).start(),n.Va.ua()}function kc(n){return Sr(n)&&!Ti(n).x_()&&n.Ea.size>0}function Sr(n){return X(n).Ia.size===0}function tg(n){n.da=void 0}async function HT(n){n.Va.set("Online")}async function GT(n){n.Ea.forEach((e,t)=>{Sc(n,e)})}async function KT(n,e){tg(n),kc(n)?(n.Va.ha(e),xc(n)):n.Va.set("Unknown")}async function YT(n,e,t){if(n.Va.set("Online"),e instanceof Fp&&e.state===2&&e.cause)try{await async function(i,o){const s=o.cause;for(const l of o.targetIds)i.Ea.has(l)&&(await i.remoteSyncer.rejectListen(l,s),i.Ea.delete(l),i.da.removeTarget(l))}(n,e)}catch(r){j(br,"Failed to remove targets %s: %s ",e.targetIds.join(","),r),await Ks(n,r)}else if(e instanceof xs?n.da.Xe(e):e instanceof Vp?n.da.st(e):n.da.tt(e),!t.isEqual(J.min()))try{const r=await Qp(n.localStore);t.compareTo(r)>=0&&await function(o,s){const l=o.da.Tt(s);return l.targetChanges.forEach((u,h)=>{if(u.resumeToken.approximateByteSize()>0){const p=o.Ea.get(h);p&&o.Ea.set(h,p.withResumeToken(u.resumeToken,s))}}),l.targetMismatches.forEach((u,h)=>{const p=o.Ea.get(u);if(!p)return;o.Ea.set(u,p.withResumeToken(We.EMPTY_BYTE_STRING,p.snapshotVersion)),eg(o,u);const m=new On(p.target,u,h,p.sequenceNumber);Sc(o,m)}),o.remoteSyncer.applyRemoteEvent(l)}(n,t)}catch(r){j(br,"Failed to raise snapshot:",r),await Ks(n,r)}}async function Ks(n,e,t){if(!wi(e))throw e;n.Ia.add(1),await Bo(n),n.Va.set("Offline"),t||(t=()=>Qp(n.localStore)),n.asyncQueue.enqueueRetryable(async()=>{j(br,"Retrying IndexedDB access"),await t(),n.Ia.delete(1),await wa(n)})}function ng(n,e){return e().catch(t=>Ks(n,t,e))}async function ba(n){const e=X(n),t=Hn(e);let r=e.Ta.length>0?e.Ta[e.Ta.length-1].batchId:hc;for(;QT(e);)try{const i=await CT(e.localStore,r);if(i===null){e.Ta.length===0&&t.L_();break}r=i.batchId,JT(e,i)}catch(i){await Ks(e,i)}rg(e)&&ig(e)}function QT(n){return Sr(n)&&n.Ta.length<10}function JT(n,e){n.Ta.push(e);const t=Hn(n);t.O_()&&t.Y_&&t.ea(e.mutations)}function rg(n){return Sr(n)&&!Hn(n).x_()&&n.Ta.length>0}function ig(n){Hn(n).start()}async function XT(n){Hn(n).ra()}async function ZT(n){const e=Hn(n);for(const t of n.Ta)e.ea(t.mutations)}async function eE(n,e,t){const r=n.Ta.shift(),i=vc.from(r,e,t);await ng(n,()=>n.remoteSyncer.applySuccessfulWrite(i)),await ba(n)}async function tE(n,e){e&&Hn(n).Y_&&await async function(r,i){if(function(s){return Mb(s)&&s!==N.ABORTED}(i.code)){const o=r.Ta.shift();Hn(r).B_(),await ng(r,()=>r.remoteSyncer.rejectFailedWrite(o.batchId,i)),await ba(r)}}(n,e),rg(n)&&ig(n)}async function gd(n,e){const t=X(n);t.asyncQueue.verifyOperationInProgress(),j(br,"RemoteStore received new credentials");const r=Sr(t);t.Ia.add(3),await Bo(t),r&&t.Va.set("Unknown"),await t.remoteSyncer.handleCredentialChange(e),t.Ia.delete(3),await wa(t)}async function nE(n,e){const t=X(n);e?(t.Ia.delete(2),await wa(t)):e||(t.Ia.add(2),await Bo(t),t.Va.set("Unknown"))}function Ti(n){return n.ma||(n.ma=function(t,r,i){const o=X(t);return o.sa(),new UT(r,o.connection,o.authCredentials,o.appCheckCredentials,o.serializer,i)}(n.datastore,n.asyncQueue,{Zo:HT.bind(null,n),Yo:GT.bind(null,n),t_:KT.bind(null,n),H_:YT.bind(null,n)}),n.Ra.push(async e=>{e?(n.ma.B_(),kc(n)?xc(n):n.Va.set("Unknown")):(await n.ma.stop(),tg(n))})),n.ma}function Hn(n){return n.fa||(n.fa=function(t,r,i){const o=X(t);return o.sa(),new qT(r,o.connection,o.authCredentials,o.appCheckCredentials,o.serializer,i)}(n.datastore,n.asyncQueue,{Zo:()=>Promise.resolve(),Yo:XT.bind(null,n),t_:tE.bind(null,n),ta:ZT.bind(null,n),na:eE.bind(null,n)}),n.Ra.push(async e=>{e?(n.fa.B_(),await ba(n)):(await n.fa.stop(),n.Ta.length>0&&(j(br,`Stopping write stream with ${n.Ta.length} pending writes`),n.Ta=[]))})),n.fa}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Pc{constructor(e,t,r,i,o){this.asyncQueue=e,this.timerId=t,this.targetTimeMs=r,this.op=i,this.removalCallback=o,this.deferred=new an,this.then=this.deferred.promise.then.bind(this.deferred.promise),this.deferred.promise.catch(s=>{})}get promise(){return this.deferred.promise}static createAndSchedule(e,t,r,i,o){const s=Date.now()+r,l=new Pc(e,t,s,i,o);return l.start(r),l}start(e){this.timerHandle=setTimeout(()=>this.handleDelayElapsed(),e)}skipDelay(){return this.handleDelayElapsed()}cancel(e){this.timerHandle!==null&&(this.clearTimeout(),this.deferred.reject(new q(N.CANCELLED,"Operation cancelled"+(e?": "+e:""))))}handleDelayElapsed(){this.asyncQueue.enqueueAndForget(()=>this.timerHandle!==null?(this.clearTimeout(),this.op().then(e=>this.deferred.resolve(e))):Promise.resolve())}clearTimeout(){this.timerHandle!==null&&(this.removalCallback(this),clearTimeout(this.timerHandle),this.timerHandle=null)}}function Cc(n,e){if(pn("AsyncQueue",`${e}: ${n}`),wi(n))return new q(N.UNAVAILABLE,`${e}: ${n}`);throw n}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Hr{static emptySet(e){return new Hr(e.comparator)}constructor(e){this.comparator=e?(t,r)=>e(t,r)||H.comparator(t.key,r.key):(t,r)=>H.comparator(t.key,r.key),this.keyedMap=Ji(),this.sortedSet=new we(this.comparator)}has(e){return this.keyedMap.get(e)!=null}get(e){return this.keyedMap.get(e)}first(){return this.sortedSet.minKey()}last(){return this.sortedSet.maxKey()}isEmpty(){return this.sortedSet.isEmpty()}indexOf(e){const t=this.keyedMap.get(e);return t?this.sortedSet.indexOf(t):-1}get size(){return this.sortedSet.size}forEach(e){this.sortedSet.inorderTraversal((t,r)=>(e(t),!1))}add(e){const t=this.delete(e.key);return t.copy(t.keyedMap.insert(e.key,e),t.sortedSet.insert(e,null))}delete(e){const t=this.get(e);return t?this.copy(this.keyedMap.remove(e),this.sortedSet.remove(t)):this}isEqual(e){if(!(e instanceof Hr)||this.size!==e.size)return!1;const t=this.sortedSet.getIterator(),r=e.sortedSet.getIterator();for(;t.hasNext();){const i=t.getNext().key,o=r.getNext().key;if(!i.isEqual(o))return!1}return!0}toString(){const e=[];return this.forEach(t=>{e.push(t.toString())}),e.length===0?"DocumentSet ()":`DocumentSet (
  `+e.join(`  
`)+`
)`}copy(e,t){const r=new Hr;return r.comparator=this.comparator,r.keyedMap=e,r.sortedSet=t,r}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class md{constructor(){this.ga=new we(H.comparator)}track(e){const t=e.doc.key,r=this.ga.get(t);r?e.type!==0&&r.type===3?this.ga=this.ga.insert(t,e):e.type===3&&r.type!==1?this.ga=this.ga.insert(t,{type:r.type,doc:e.doc}):e.type===2&&r.type===2?this.ga=this.ga.insert(t,{type:2,doc:e.doc}):e.type===2&&r.type===0?this.ga=this.ga.insert(t,{type:0,doc:e.doc}):e.type===1&&r.type===0?this.ga=this.ga.remove(t):e.type===1&&r.type===2?this.ga=this.ga.insert(t,{type:1,doc:r.doc}):e.type===0&&r.type===1?this.ga=this.ga.insert(t,{type:2,doc:e.doc}):Y(63341,{Vt:e,pa:r}):this.ga=this.ga.insert(t,e)}ya(){const e=[];return this.ga.inorderTraversal((t,r)=>{e.push(r)}),e}}class li{constructor(e,t,r,i,o,s,l,u,h){this.query=e,this.docs=t,this.oldDocs=r,this.docChanges=i,this.mutatedKeys=o,this.fromCache=s,this.syncStateChanged=l,this.excludesMetadataChanges=u,this.hasCachedResults=h}static fromInitialDocuments(e,t,r,i,o){const s=[];return t.forEach(l=>{s.push({type:0,doc:l})}),new li(e,t,Hr.emptySet(t),s,r,i,!0,!1,o)}get hasPendingWrites(){return!this.mutatedKeys.isEmpty()}isEqual(e){if(!(this.fromCache===e.fromCache&&this.hasCachedResults===e.hasCachedResults&&this.syncStateChanged===e.syncStateChanged&&this.mutatedKeys.isEqual(e.mutatedKeys)&&pa(this.query,e.query)&&this.docs.isEqual(e.docs)&&this.oldDocs.isEqual(e.oldDocs)))return!1;const t=this.docChanges,r=e.docChanges;if(t.length!==r.length)return!1;for(let i=0;i<t.length;i++)if(t[i].type!==r[i].type||!t[i].doc.isEqual(r[i].doc))return!1;return!0}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class rE{constructor(){this.wa=void 0,this.Sa=[]}ba(){return this.Sa.some(e=>e.Da())}}class iE{constructor(){this.queries=yd(),this.onlineState="Unknown",this.Ca=new Set}terminate(){(function(t,r){const i=X(t),o=i.queries;i.queries=yd(),o.forEach((s,l)=>{for(const u of l.Sa)u.onError(r)})})(this,new q(N.ABORTED,"Firestore shutting down"))}}function yd(){return new Ar(n=>Tp(n),pa)}async function Rc(n,e){const t=X(n);let r=3;const i=e.query;let o=t.queries.get(i);o?!o.ba()&&e.Da()&&(r=2):(o=new rE,r=e.Da()?0:1);try{switch(r){case 0:o.wa=await t.onListen(i,!0);break;case 1:o.wa=await t.onListen(i,!1);break;case 2:await t.onFirstRemoteStoreListen(i)}}catch(s){const l=Cc(s,`Initialization of query '${Mr(e.query)}' failed`);return void e.onError(l)}t.queries.set(i,o),o.Sa.push(e),e.va(t.onlineState),o.wa&&e.Fa(o.wa)&&Nc(t)}async function Oc(n,e){const t=X(n),r=e.query;let i=3;const o=t.queries.get(r);if(o){const s=o.Sa.indexOf(e);s>=0&&(o.Sa.splice(s,1),o.Sa.length===0?i=e.Da()?0:1:!o.ba()&&e.Da()&&(i=2))}switch(i){case 0:return t.queries.delete(r),t.onUnlisten(r,!0);case 1:return t.queries.delete(r),t.onUnlisten(r,!1);case 2:return t.onLastRemoteStoreUnlisten(r);default:return}}function oE(n,e){const t=X(n);let r=!1;for(const i of e){const o=i.query,s=t.queries.get(o);if(s){for(const l of s.Sa)l.Fa(i)&&(r=!0);s.wa=i}}r&&Nc(t)}function sE(n,e,t){const r=X(n),i=r.queries.get(e);if(i)for(const o of i.Sa)o.onError(t);r.queries.delete(e)}function Nc(n){n.Ca.forEach(e=>{e.next()})}var Ll,vd;(vd=Ll||(Ll={})).Ma="default",vd.Cache="cache";class Dc{constructor(e,t,r){this.query=e,this.xa=t,this.Oa=!1,this.Na=null,this.onlineState="Unknown",this.options=r||{}}Fa(e){if(!this.options.includeMetadataChanges){const r=[];for(const i of e.docChanges)i.type!==3&&r.push(i);e=new li(e.query,e.docs,e.oldDocs,r,e.mutatedKeys,e.fromCache,e.syncStateChanged,!0,e.hasCachedResults)}let t=!1;return this.Oa?this.Ba(e)&&(this.xa.next(e),t=!0):this.La(e,this.onlineState)&&(this.ka(e),t=!0),this.Na=e,t}onError(e){this.xa.error(e)}va(e){this.onlineState=e;let t=!1;return this.Na&&!this.Oa&&this.La(this.Na,e)&&(this.ka(this.Na),t=!0),t}La(e,t){if(!e.fromCache||!this.Da())return!0;const r=t!=="Offline";return(!this.options.qa||!r)&&(!e.docs.isEmpty()||e.hasCachedResults||t==="Offline")}Ba(e){if(e.docChanges.length>0)return!0;const t=this.Na&&this.Na.hasPendingWrites!==e.hasPendingWrites;return!(!e.syncStateChanged&&!t)&&this.options.includeMetadataChanges===!0}ka(e){e=li.fromInitialDocuments(e.query,e.docs,e.mutatedKeys,e.fromCache,e.hasCachedResults),this.Oa=!0,this.xa.next(e)}Da(){return this.options.source!==Ll.Cache}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class og{constructor(e){this.key=e}}class sg{constructor(e){this.key=e}}class aE{constructor(e,t){this.query=e,this.Za=t,this.Xa=null,this.hasCachedResults=!1,this.current=!1,this.Ya=ie(),this.mutatedKeys=ie(),this.eu=Ep(e),this.tu=new Hr(this.eu)}get nu(){return this.Za}ru(e,t){const r=t?t.iu:new md,i=t?t.tu:this.tu;let o=t?t.mutatedKeys:this.mutatedKeys,s=i,l=!1;const u=this.query.limitType==="F"&&i.size===this.query.limit?i.last():null,h=this.query.limitType==="L"&&i.size===this.query.limit?i.first():null;if(e.inorderTraversal((p,m)=>{const g=i.get(p),b=ga(this.query,m)?m:null,P=!!g&&this.mutatedKeys.has(g.key),A=!!b&&(b.hasLocalMutations||this.mutatedKeys.has(b.key)&&b.hasCommittedMutations);let C=!1;g&&b?g.data.isEqual(b.data)?P!==A&&(r.track({type:3,doc:b}),C=!0):this.su(g,b)||(r.track({type:2,doc:b}),C=!0,(u&&this.eu(b,u)>0||h&&this.eu(b,h)<0)&&(l=!0)):!g&&b?(r.track({type:0,doc:b}),C=!0):g&&!b&&(r.track({type:1,doc:g}),C=!0,(u||h)&&(l=!0)),C&&(b?(s=s.add(b),o=A?o.add(p):o.delete(p)):(s=s.delete(p),o=o.delete(p)))}),this.query.limit!==null)for(;s.size>this.query.limit;){const p=this.query.limitType==="F"?s.last():s.first();s=s.delete(p.key),o=o.delete(p.key),r.track({type:1,doc:p})}return{tu:s,iu:r,bs:l,mutatedKeys:o}}su(e,t){return e.hasLocalMutations&&t.hasCommittedMutations&&!t.hasLocalMutations}applyChanges(e,t,r,i){const o=this.tu;this.tu=e.tu,this.mutatedKeys=e.mutatedKeys;const s=e.iu.ya();s.sort((p,m)=>function(b,P){const A=C=>{switch(C){case 0:return 1;case 2:case 3:return 2;case 1:return 0;default:return Y(20277,{Vt:C})}};return A(b)-A(P)}(p.type,m.type)||this.eu(p.doc,m.doc)),this.ou(r),i=i??!1;const l=t&&!i?this._u():[],u=this.Ya.size===0&&this.current&&!i?1:0,h=u!==this.Xa;return this.Xa=u,s.length!==0||h?{snapshot:new li(this.query,e.tu,o,s,e.mutatedKeys,u===0,h,!1,!!r&&r.resumeToken.approximateByteSize()>0),au:l}:{au:l}}va(e){return this.current&&e==="Offline"?(this.current=!1,this.applyChanges({tu:this.tu,iu:new md,mutatedKeys:this.mutatedKeys,bs:!1},!1)):{au:[]}}uu(e){return!this.Za.has(e)&&!!this.tu.has(e)&&!this.tu.get(e).hasLocalMutations}ou(e){e&&(e.addedDocuments.forEach(t=>this.Za=this.Za.add(t)),e.modifiedDocuments.forEach(t=>{}),e.removedDocuments.forEach(t=>this.Za=this.Za.delete(t)),this.current=e.current)}_u(){if(!this.current)return[];const e=this.Ya;this.Ya=ie(),this.tu.forEach(r=>{this.uu(r.key)&&(this.Ya=this.Ya.add(r.key))});const t=[];return e.forEach(r=>{this.Ya.has(r)||t.push(new sg(r))}),this.Ya.forEach(r=>{e.has(r)||t.push(new og(r))}),t}cu(e){this.Za=e.ks,this.Ya=ie();const t=this.ru(e.documents);return this.applyChanges(t,!0)}lu(){return li.fromInitialDocuments(this.query,this.tu,this.mutatedKeys,this.Xa===0,this.hasCachedResults)}}const Mc="SyncEngine";class lE{constructor(e,t,r){this.query=e,this.targetId=t,this.view=r}}class cE{constructor(e){this.key=e,this.hu=!1}}class uE{constructor(e,t,r,i,o,s){this.localStore=e,this.remoteStore=t,this.eventManager=r,this.sharedClientState=i,this.currentUser=o,this.maxConcurrentLimboResolutions=s,this.Pu={},this.Tu=new Ar(l=>Tp(l),pa),this.Eu=new Map,this.Iu=new Set,this.Ru=new we(H.comparator),this.Au=new Map,this.Vu=new bc,this.du={},this.mu=new Map,this.fu=ai.ar(),this.onlineState="Unknown",this.gu=void 0}get isPrimaryClient(){return this.gu===!0}}async function hE(n,e,t=!0){const r=dg(n);let i;const o=r.Tu.get(e);return o?(r.sharedClientState.addLocalQueryTarget(o.targetId),i=o.view.lu()):i=await ag(r,e,t,!0),i}async function dE(n,e){const t=dg(n);await ag(t,e,!0,!1)}async function ag(n,e,t,r){const i=await RT(n.localStore,jt(e)),o=i.targetId,s=n.sharedClientState.addLocalQueryTarget(o,t);let l;return r&&(l=await fE(n,e,o,s==="current",i.resumeToken)),n.isPrimaryClient&&t&&Zp(n.remoteStore,i),l}async function fE(n,e,t,r,i){n.pu=(m,g,b)=>async function(A,C,$,F){let V=C.view.ru($);V.bs&&(V=await ud(A.localStore,C.query,!1).then(({documents:E})=>C.view.ru(E,V)));const G=F&&F.targetChanges.get(C.targetId),z=F&&F.targetMismatches.get(C.targetId)!=null,K=C.view.applyChanges(V,A.isPrimaryClient,G,z);return wd(A,C.targetId,K.au),K.snapshot}(n,m,g,b);const o=await ud(n.localStore,e,!0),s=new aE(e,o.ks),l=s.ru(o.documents),u=qo.createSynthesizedTargetChangeForCurrentChange(t,r&&n.onlineState!=="Offline",i),h=s.applyChanges(l,n.isPrimaryClient,u);wd(n,t,h.au);const p=new lE(e,t,s);return n.Tu.set(e,p),n.Eu.has(t)?n.Eu.get(t).push(e):n.Eu.set(t,[e]),h.snapshot}async function pE(n,e,t){const r=X(n),i=r.Tu.get(e),o=r.Eu.get(i.targetId);if(o.length>1)return r.Eu.set(i.targetId,o.filter(s=>!pa(s,e))),void r.Tu.delete(e);r.isPrimaryClient?(r.sharedClientState.removeLocalQueryTarget(i.targetId),r.sharedClientState.isActiveQueryTarget(i.targetId)||await Dl(r.localStore,i.targetId,!1).then(()=>{r.sharedClientState.clearQueryState(i.targetId),t&&Ac(r.remoteStore,i.targetId),Vl(r,i.targetId)}).catch(_i)):(Vl(r,i.targetId),await Dl(r.localStore,i.targetId,!0))}async function gE(n,e){const t=X(n),r=t.Tu.get(e),i=t.Eu.get(r.targetId);t.isPrimaryClient&&i.length===1&&(t.sharedClientState.removeLocalQueryTarget(r.targetId),Ac(t.remoteStore,r.targetId))}async function mE(n,e,t){const r=EE(n);try{const i=await function(s,l){const u=X(s),h=me.now(),p=l.reduce((b,P)=>b.add(P.key),ie());let m,g;return u.persistence.runTransaction("Locally write mutations","readwrite",b=>{let P=gn(),A=ie();return u.xs.getEntries(b,p).next(C=>{P=C,P.forEach(($,F)=>{F.isValidDocument()||(A=A.add($))})}).next(()=>u.localDocuments.getOverlayedDocuments(b,P)).next(C=>{m=C;const $=[];for(const F of l){const V=Cb(F,m.get(F.key).overlayedDocument);V!=null&&$.push(new Qn(F.key,V,pp(V.value.mapValue),At.exists(!0)))}return u.mutationQueue.addMutationBatch(b,h,$,l)}).next(C=>{g=C;const $=C.applyToLocalDocumentSet(m,A);return u.documentOverlayCache.saveOverlays(b,C.batchId,$)})}).then(()=>({batchId:g.batchId,changes:Ap(m)}))}(r.localStore,e);r.sharedClientState.addPendingMutation(i.batchId),function(s,l,u){let h=s.du[s.currentUser.toKey()];h||(h=new we(re)),h=h.insert(l,u),s.du[s.currentUser.toKey()]=h}(r,i.batchId,t),await $o(r,i.changes),await ba(r.remoteStore)}catch(i){const o=Cc(i,"Failed to persist write");t.reject(o)}}async function lg(n,e){const t=X(n);try{const r=await kT(t.localStore,e);e.targetChanges.forEach((i,o)=>{const s=t.Au.get(o);s&&(he(i.addedDocuments.size+i.modifiedDocuments.size+i.removedDocuments.size<=1,22616),i.addedDocuments.size>0?s.hu=!0:i.modifiedDocuments.size>0?he(s.hu,14607):i.removedDocuments.size>0&&(he(s.hu,42227),s.hu=!1))}),await $o(t,r,e)}catch(r){await _i(r)}}function _d(n,e,t){const r=X(n);if(r.isPrimaryClient&&t===0||!r.isPrimaryClient&&t===1){const i=[];r.Tu.forEach((o,s)=>{const l=s.view.va(e);l.snapshot&&i.push(l.snapshot)}),function(s,l){const u=X(s);u.onlineState=l;let h=!1;u.queries.forEach((p,m)=>{for(const g of m.Sa)g.va(l)&&(h=!0)}),h&&Nc(u)}(r.eventManager,e),i.length&&r.Pu.H_(i),r.onlineState=e,r.isPrimaryClient&&r.sharedClientState.setOnlineState(e)}}async function yE(n,e,t){const r=X(n);r.sharedClientState.updateQueryState(e,"rejected",t);const i=r.Au.get(e),o=i&&i.key;if(o){let s=new we(H.comparator);s=s.insert(o,Ye.newNoDocument(o,J.min()));const l=ie().add(o),u=new va(J.min(),new Map,new we(re),s,l);await lg(r,u),r.Ru=r.Ru.remove(o),r.Au.delete(e),Lc(r)}else await Dl(r.localStore,e,!1).then(()=>Vl(r,e,t)).catch(_i)}async function vE(n,e){const t=X(n),r=e.batch.batchId;try{const i=await xT(t.localStore,e);ug(t,r,null),cg(t,r),t.sharedClientState.updateMutationState(r,"acknowledged"),await $o(t,i)}catch(i){await _i(i)}}async function _E(n,e,t){const r=X(n);try{const i=await function(s,l){const u=X(s);return u.persistence.runTransaction("Reject batch","readwrite-primary",h=>{let p;return u.mutationQueue.lookupMutationBatch(h,l).next(m=>(he(m!==null,37113),p=m.keys(),u.mutationQueue.removeMutationBatch(h,m))).next(()=>u.mutationQueue.performConsistencyCheck(h)).next(()=>u.documentOverlayCache.removeOverlaysForBatchId(h,p,l)).next(()=>u.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(h,p)).next(()=>u.localDocuments.getDocuments(h,p))})}(r.localStore,e);ug(r,e,t),cg(r,e),r.sharedClientState.updateMutationState(e,"rejected",t),await $o(r,i)}catch(i){await _i(i)}}function cg(n,e){(n.mu.get(e)||[]).forEach(t=>{t.resolve()}),n.mu.delete(e)}function ug(n,e,t){const r=X(n);let i=r.du[r.currentUser.toKey()];if(i){const o=i.get(e);o&&(t?o.reject(t):o.resolve(),i=i.remove(e)),r.du[r.currentUser.toKey()]=i}}function Vl(n,e,t=null){n.sharedClientState.removeLocalQueryTarget(e);for(const r of n.Eu.get(e))n.Tu.delete(r),t&&n.Pu.yu(r,t);n.Eu.delete(e),n.isPrimaryClient&&n.Vu.Gr(e).forEach(r=>{n.Vu.containsKey(r)||hg(n,r)})}function hg(n,e){n.Iu.delete(e.path.canonicalString());const t=n.Ru.get(e);t!==null&&(Ac(n.remoteStore,t),n.Ru=n.Ru.remove(e),n.Au.delete(t),Lc(n))}function wd(n,e,t){for(const r of t)r instanceof og?(n.Vu.addReference(r.key,e),wE(n,r)):r instanceof sg?(j(Mc,"Document no longer in limbo: "+r.key),n.Vu.removeReference(r.key,e),n.Vu.containsKey(r.key)||hg(n,r.key)):Y(19791,{wu:r})}function wE(n,e){const t=e.key,r=t.path.canonicalString();n.Ru.get(t)||n.Iu.has(r)||(j(Mc,"New document in limbo: "+t),n.Iu.add(r),Lc(n))}function Lc(n){for(;n.Iu.size>0&&n.Ru.size<n.maxConcurrentLimboResolutions;){const e=n.Iu.values().next().value;n.Iu.delete(e);const t=new H(pe.fromString(e)),r=n.fu.next();n.Au.set(r,new cE(t)),n.Ru=n.Ru.insert(t,r),Zp(n.remoteStore,new On(jt(fa(t.path)),r,"TargetPurposeLimboResolution",ua.ce))}}async function $o(n,e,t){const r=X(n),i=[],o=[],s=[];r.Tu.isEmpty()||(r.Tu.forEach((l,u)=>{s.push(r.pu(u,e,t).then(h=>{var p;if((h||t)&&r.isPrimaryClient){const m=h?!h.fromCache:(p=t==null?void 0:t.targetChanges.get(u.targetId))==null?void 0:p.current;r.sharedClientState.updateQueryState(u.targetId,m?"current":"not-current")}if(h){i.push(h);const m=Ec.Is(u.targetId,h);o.push(m)}}))}),await Promise.all(s),r.Pu.H_(i),await async function(u,h){const p=X(u);try{await p.persistence.runTransaction("notifyLocalViewChanges","readwrite",m=>D.forEach(h,g=>D.forEach(g.Ts,b=>p.persistence.referenceDelegate.addReference(m,g.targetId,b)).next(()=>D.forEach(g.Es,b=>p.persistence.referenceDelegate.removeReference(m,g.targetId,b)))))}catch(m){if(!wi(m))throw m;j(Ic,"Failed to update sequence numbers: "+m)}for(const m of h){const g=m.targetId;if(!m.fromCache){const b=p.vs.get(g),P=b.snapshotVersion,A=b.withLastLimboFreeSnapshotVersion(P);p.vs=p.vs.insert(g,A)}}}(r.localStore,o))}async function bE(n,e){const t=X(n);if(!t.currentUser.isEqual(e)){j(Mc,"User change. New user:",e.toKey());const r=await Yp(t.localStore,e);t.currentUser=e,function(o,s){o.mu.forEach(l=>{l.forEach(u=>{u.reject(new q(N.CANCELLED,s))})}),o.mu.clear()}(t,"'waitForPendingWrites' promise is rejected due to a user change."),t.sharedClientState.handleUserChange(e,r.removedBatchIds,r.addedBatchIds),await $o(t,r.Ns)}}function TE(n,e){const t=X(n),r=t.Au.get(e);if(r&&r.hu)return ie().add(r.key);{let i=ie();const o=t.Eu.get(e);if(!o)return i;for(const s of o){const l=t.Tu.get(s);i=i.unionWith(l.view.nu)}return i}}function dg(n){const e=X(n);return e.remoteStore.remoteSyncer.applyRemoteEvent=lg.bind(null,e),e.remoteStore.remoteSyncer.getRemoteKeysForTarget=TE.bind(null,e),e.remoteStore.remoteSyncer.rejectListen=yE.bind(null,e),e.Pu.H_=oE.bind(null,e.eventManager),e.Pu.yu=sE.bind(null,e.eventManager),e}function EE(n){const e=X(n);return e.remoteStore.remoteSyncer.applySuccessfulWrite=vE.bind(null,e),e.remoteStore.remoteSyncer.rejectFailedWrite=_E.bind(null,e),e}class Ys{constructor(){this.kind="memory",this.synchronizeTabs=!1}async initialize(e){this.serializer=_a(e.databaseInfo.databaseId),this.sharedClientState=this.Du(e),this.persistence=this.Cu(e),await this.persistence.start(),this.localStore=this.vu(e),this.gcScheduler=this.Fu(e,this.localStore),this.indexBackfillerScheduler=this.Mu(e,this.localStore)}Fu(e,t){return null}Mu(e,t){return null}vu(e){return ST(this.persistence,new ET,e.initialUser,this.serializer)}Cu(e){return new Kp(Tc.Vi,this.serializer)}Du(e){return new NT}async terminate(){var e,t;(e=this.gcScheduler)==null||e.stop(),(t=this.indexBackfillerScheduler)==null||t.stop(),this.sharedClientState.shutdown(),await this.persistence.shutdown()}}Ys.provider={build:()=>new Ys};class IE extends Ys{constructor(e){super(),this.cacheSizeBytes=e}Fu(e,t){he(this.persistence.referenceDelegate instanceof Gs,46915);const r=this.persistence.referenceDelegate.garbageCollector;return new lT(r,e.asyncQueue,t)}Cu(e){const t=this.cacheSizeBytes!==void 0?st.withCacheSize(this.cacheSizeBytes):st.DEFAULT;return new Kp(r=>Gs.Vi(r,t),this.serializer)}}class Fl{async initialize(e,t){this.localStore||(this.localStore=e.localStore,this.sharedClientState=e.sharedClientState,this.datastore=this.createDatastore(t),this.remoteStore=this.createRemoteStore(t),this.eventManager=this.createEventManager(t),this.syncEngine=this.createSyncEngine(t,!e.synchronizeTabs),this.sharedClientState.onlineStateHandler=r=>_d(this.syncEngine,r,1),this.remoteStore.remoteSyncer.handleCredentialChange=bE.bind(null,this.syncEngine),await nE(this.remoteStore,this.syncEngine.isPrimaryClient))}createEventManager(e){return function(){return new iE}()}createDatastore(e){const t=_a(e.databaseInfo.databaseId),r=FT(e.databaseInfo);return jT(e.authCredentials,e.appCheckCredentials,r,t)}createRemoteStore(e){return function(r,i,o,s,l){return new WT(r,i,o,s,l)}(this.localStore,this.datastore,e.asyncQueue,t=>_d(this.syncEngine,t,0),function(){return fd.v()?new fd:new DT}())}createSyncEngine(e,t){return function(i,o,s,l,u,h,p){const m=new uE(i,o,s,l,u,h);return p&&(m.gu=!0),m}(this.localStore,this.remoteStore,this.eventManager,this.sharedClientState,e.initialUser,e.maxConcurrentLimboResolutions,t)}async terminate(){var e,t;await async function(i){const o=X(i);j(br,"RemoteStore shutting down."),o.Ia.add(5),await Bo(o),o.Aa.shutdown(),o.Va.set("Unknown")}(this.remoteStore),(e=this.datastore)==null||e.terminate(),(t=this.eventManager)==null||t.terminate()}}Fl.provider={build:()=>new Fl};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Vc{constructor(e){this.observer=e,this.muted=!1}next(e){this.muted||this.observer.next&&this.Ou(this.observer.next,e)}error(e){this.muted||(this.observer.error?this.Ou(this.observer.error,e):pn("Uncaught Error in snapshot listener:",e.toString()))}Nu(){this.muted=!0}Ou(e,t){setTimeout(()=>{this.muted||e(t)},0)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Gn="FirestoreClient";class AE{constructor(e,t,r,i,o){this.authCredentials=e,this.appCheckCredentials=t,this.asyncQueue=r,this._databaseInfo=i,this.user=Ke.UNAUTHENTICATED,this.clientId=uc.newId(),this.authCredentialListener=()=>Promise.resolve(),this.appCheckCredentialListener=()=>Promise.resolve(),this._uninitializedComponentsProvider=o,this.authCredentials.start(r,async s=>{j(Gn,"Received user=",s.uid),await this.authCredentialListener(s),this.user=s}),this.appCheckCredentials.start(r,s=>(j(Gn,"Received new app check token=",s),this.appCheckCredentialListener(s,this.user)))}get configuration(){return{asyncQueue:this.asyncQueue,databaseInfo:this._databaseInfo,clientId:this.clientId,authCredentials:this.authCredentials,appCheckCredentials:this.appCheckCredentials,initialUser:this.user,maxConcurrentLimboResolutions:100}}setCredentialChangeListener(e){this.authCredentialListener=e}setAppCheckTokenChangeListener(e){this.appCheckCredentialListener=e}terminate(){this.asyncQueue.enterRestrictedMode();const e=new an;return this.asyncQueue.enqueueAndForgetEvenWhileRestricted(async()=>{try{this._onlineComponents&&await this._onlineComponents.terminate(),this._offlineComponents&&await this._offlineComponents.terminate(),this.authCredentials.shutdown(),this.appCheckCredentials.shutdown(),e.resolve()}catch(t){const r=Cc(t,"Failed to shutdown persistence");e.reject(r)}}),e.promise}}async function ol(n,e){n.asyncQueue.verifyOperationInProgress(),j(Gn,"Initializing OfflineComponentProvider");const t=n.configuration;await e.initialize(t);let r=t.initialUser;n.setCredentialChangeListener(async i=>{r.isEqual(i)||(await Yp(e.localStore,i),r=i)}),e.persistence.setDatabaseDeletedListener(()=>n.terminate()),n._offlineComponents=e}async function bd(n,e){n.asyncQueue.verifyOperationInProgress();const t=await SE(n);j(Gn,"Initializing OnlineComponentProvider"),await e.initialize(t,n.configuration),n.setCredentialChangeListener(r=>gd(e.remoteStore,r)),n.setAppCheckTokenChangeListener((r,i)=>gd(e.remoteStore,i)),n._onlineComponents=e}async function SE(n){if(!n._offlineComponents)if(n._uninitializedComponentsProvider){j(Gn,"Using user provided OfflineComponentProvider");try{await ol(n,n._uninitializedComponentsProvider._offline)}catch(e){const t=e;if(!function(i){return i.name==="FirebaseError"?i.code===N.FAILED_PRECONDITION||i.code===N.UNIMPLEMENTED:!(typeof DOMException<"u"&&i instanceof DOMException)||i.code===22||i.code===20||i.code===11}(t))throw t;wr("Error using user provided cache. Falling back to memory cache: "+t),await ol(n,new Ys)}}else j(Gn,"Using default OfflineComponentProvider"),await ol(n,new IE(void 0));return n._offlineComponents}async function fg(n){return n._onlineComponents||(n._uninitializedComponentsProvider?(j(Gn,"Using user provided OnlineComponentProvider"),await bd(n,n._uninitializedComponentsProvider._online)):(j(Gn,"Using default OnlineComponentProvider"),await bd(n,new Fl))),n._onlineComponents}function xE(n){return fg(n).then(e=>e.syncEngine)}async function Qs(n){const e=await fg(n),t=e.eventManager;return t.onListen=hE.bind(null,e.syncEngine),t.onUnlisten=pE.bind(null,e.syncEngine),t.onFirstRemoteStoreListen=dE.bind(null,e.syncEngine),t.onLastRemoteStoreUnlisten=gE.bind(null,e.syncEngine),t}function kE(n,e,t,r){const i=new Vc(r),o=new Dc(e,i,t);return n.asyncQueue.enqueueAndForget(async()=>Rc(await Qs(n),o)),()=>{i.Nu(),n.asyncQueue.enqueueAndForget(async()=>Oc(await Qs(n),o))}}function PE(n,e,t={}){const r=new an;return n.asyncQueue.enqueueAndForget(async()=>function(o,s,l,u,h){const p=new Vc({next:g=>{p.Nu(),s.enqueueAndForget(()=>Oc(o,m));const b=g.docs.has(l);!b&&g.fromCache?h.reject(new q(N.UNAVAILABLE,"Failed to get document because the client is offline.")):b&&g.fromCache&&u&&u.source==="server"?h.reject(new q(N.UNAVAILABLE,'Failed to get document from server. (However, this document does exist in the local cache. Run again without setting source to "server" to retrieve the cached document.)')):h.resolve(g)},error:g=>h.reject(g)}),m=new Dc(fa(l.path),p,{includeMetadataChanges:!0,qa:!0});return Rc(o,m)}(await Qs(n),n.asyncQueue,e,t,r)),r.promise}function CE(n,e,t={}){const r=new an;return n.asyncQueue.enqueueAndForget(async()=>function(o,s,l,u,h){const p=new Vc({next:g=>{p.Nu(),s.enqueueAndForget(()=>Oc(o,m)),g.fromCache&&u.source==="server"?h.reject(new q(N.UNAVAILABLE,'Failed to get documents from server. (However, these documents may exist in the local cache. Run again without setting source to "server" to retrieve the cached documents.)')):h.resolve(g)},error:g=>h.reject(g)}),m=new Dc(l,p,{includeMetadataChanges:!0,qa:!0});return Rc(o,m)}(await Qs(n),n.asyncQueue,e,t,r)),r.promise}function RE(n,e){const t=new an;return n.asyncQueue.enqueueAndForget(async()=>mE(await xE(n),e,t)),t.promise}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function pg(n){const e={};return n.timeoutSeconds!==void 0&&(e.timeoutSeconds=n.timeoutSeconds),e}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const OE="ComponentProvider",Td=new Map;function NE(n,e,t,r,i){return new Zw(n,e,t,i.host,i.ssl,i.experimentalForceLongPolling,i.experimentalAutoDetectLongPolling,pg(i.experimentalLongPollingOptions),i.useFetchStreams,i.isUsingEmulator,r)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const gg="firestore.googleapis.com",Ed=!0;class Id{constructor(e){if(e.host===void 0){if(e.ssl!==void 0)throw new q(N.INVALID_ARGUMENT,"Can't provide ssl option if host option is not set");this.host=gg,this.ssl=Ed}else this.host=e.host,this.ssl=e.ssl??Ed;if(this.isUsingEmulator=e.emulatorOptions!==void 0,this.credentials=e.credentials,this.ignoreUndefinedProperties=!!e.ignoreUndefinedProperties,this.localCache=e.localCache,e.cacheSizeBytes===void 0)this.cacheSizeBytes=Gp;else{if(e.cacheSizeBytes!==-1&&e.cacheSizeBytes<sT)throw new q(N.INVALID_ARGUMENT,"cacheSizeBytes must be at least 1048576");this.cacheSizeBytes=e.cacheSizeBytes}Bw("experimentalForceLongPolling",e.experimentalForceLongPolling,"experimentalAutoDetectLongPolling",e.experimentalAutoDetectLongPolling),this.experimentalForceLongPolling=!!e.experimentalForceLongPolling,this.experimentalForceLongPolling?this.experimentalAutoDetectLongPolling=!1:e.experimentalAutoDetectLongPolling===void 0?this.experimentalAutoDetectLongPolling=!0:this.experimentalAutoDetectLongPolling=!!e.experimentalAutoDetectLongPolling,this.experimentalLongPollingOptions=pg(e.experimentalLongPollingOptions??{}),function(r){if(r.timeoutSeconds!==void 0){if(isNaN(r.timeoutSeconds))throw new q(N.INVALID_ARGUMENT,`invalid long polling timeout: ${r.timeoutSeconds} (must not be NaN)`);if(r.timeoutSeconds<5)throw new q(N.INVALID_ARGUMENT,`invalid long polling timeout: ${r.timeoutSeconds} (minimum allowed value is 5)`);if(r.timeoutSeconds>30)throw new q(N.INVALID_ARGUMENT,`invalid long polling timeout: ${r.timeoutSeconds} (maximum allowed value is 30)`)}}(this.experimentalLongPollingOptions),this.useFetchStreams=!!e.useFetchStreams}isEqual(e){return this.host===e.host&&this.ssl===e.ssl&&this.credentials===e.credentials&&this.cacheSizeBytes===e.cacheSizeBytes&&this.experimentalForceLongPolling===e.experimentalForceLongPolling&&this.experimentalAutoDetectLongPolling===e.experimentalAutoDetectLongPolling&&function(r,i){return r.timeoutSeconds===i.timeoutSeconds}(this.experimentalLongPollingOptions,e.experimentalLongPollingOptions)&&this.ignoreUndefinedProperties===e.ignoreUndefinedProperties&&this.useFetchStreams===e.useFetchStreams}}class Ta{constructor(e,t,r,i){this._authCredentials=e,this._appCheckCredentials=t,this._databaseId=r,this._app=i,this.type="firestore-lite",this._persistenceKey="(lite)",this._settings=new Id({}),this._settingsFrozen=!1,this._emulatorOptions={},this._terminateTask="notTerminated"}get app(){if(!this._app)throw new q(N.FAILED_PRECONDITION,"Firestore was not initialized using the Firebase SDK. 'app' is not available");return this._app}get _initialized(){return this._settingsFrozen}get _terminated(){return this._terminateTask!=="notTerminated"}_setSettings(e){if(this._settingsFrozen)throw new q(N.FAILED_PRECONDITION,"Firestore has already been started and its settings can no longer be changed. You can only modify settings before calling any other methods on a Firestore object.");this._settings=new Id(e),this._emulatorOptions=e.emulatorOptions||{},e.credentials!==void 0&&(this._authCredentials=function(r){if(!r)return new Rw;switch(r.type){case"firstParty":return new Mw(r.sessionIndex||"0",r.iamToken||null,r.authTokenFactory||null);case"provider":return r.client;default:throw new q(N.INVALID_ARGUMENT,"makeAuthCredentialsProvider failed due to invalid credential type")}}(e.credentials))}_getSettings(){return this._settings}_getEmulatorOptions(){return this._emulatorOptions}_freezeSettings(){return this._settingsFrozen=!0,this._settings}_delete(){return this._terminateTask==="notTerminated"&&(this._terminateTask=this._terminate()),this._terminateTask}async _restart(){this._terminateTask==="notTerminated"?await this._terminate():this._terminateTask="notTerminated"}toJSON(){return{app:this._app,databaseId:this._databaseId,settings:this._settings}}_terminate(){return function(t){const r=Td.get(t);r&&(j(OE,"Removing Datastore"),Td.delete(t),r.terminate())}(this),Promise.resolve()}}function DE(n,e,t,r={}){var h;n=yt(n,Ta);const i=Do(e),o=n._getSettings(),s={...o,emulatorOptions:n._getEmulatorOptions()},l=`${e}:${t}`;i&&uf(`https://${l}`),o.host!==gg&&o.host!==l&&wr("Host has been set in both settings() and connectFirestoreEmulator(), emulator host will be used.");const u={...o,host:l,ssl:i,emulatorOptions:r};if(!mr(u,s)&&(n._setSettings(u),r.mockUserToken)){let p,m;if(typeof r.mockUserToken=="string")p=r.mockUserToken,m=Ke.MOCK_USER;else{p=ry(r.mockUserToken,(h=n._app)==null?void 0:h.options.projectId);const g=r.mockUserToken.sub||r.mockUserToken.user_id;if(!g)throw new q(N.INVALID_ARGUMENT,"mockUserToken must contain 'sub' or 'user_id' field!");m=new Ke(g)}n._authCredentials=new Ow(new np(p,m))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class vn{constructor(e,t,r){this.converter=t,this._query=r,this.type="query",this.firestore=e}withConverter(e){return new vn(this.firestore,e,this._query)}}class Ee{constructor(e,t,r){this.converter=t,this._key=r,this.type="document",this.firestore=e}get _path(){return this._key.path}get id(){return this._key.path.lastSegment()}get path(){return this._key.path.canonicalString()}get parent(){return new Un(this.firestore,this.converter,this._key.path.popLast())}withConverter(e){return new Ee(this.firestore,e,this._key)}toJSON(){return{type:Ee._jsonSchemaVersion,referencePath:this._key.toString()}}static fromJSON(e,t,r){if(Fo(t,Ee._jsonSchema))return new Ee(e,r||null,new H(pe.fromString(t.referencePath)))}}Ee._jsonSchemaVersion="firestore/documentReference/1.0",Ee._jsonSchema={type:Re("string",Ee._jsonSchemaVersion),referencePath:Re("string")};class Un extends vn{constructor(e,t,r){super(e,t,fa(r)),this._path=r,this.type="collection"}get id(){return this._query.path.lastSegment()}get path(){return this._query.path.canonicalString()}get parent(){const e=this._path.popLast();return e.isEmpty()?null:new Ee(this.firestore,null,new H(e))}withConverter(e){return new Un(this.firestore,e,this._path)}}function Jn(n,e,...t){if(n=Be(n),rp("collection","path",e),n instanceof Ta){const r=pe.fromString(e,...t);return Vh(r),new Un(n,null,r)}{if(!(n instanceof Ee||n instanceof Un))throw new q(N.INVALID_ARGUMENT,"Expected first argument to collection() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const r=n._path.child(pe.fromString(e,...t));return Vh(r),new Un(n.firestore,null,r)}}function _e(n,e,...t){if(n=Be(n),arguments.length===1&&(e=uc.newId()),rp("doc","path",e),n instanceof Ta){const r=pe.fromString(e,...t);return Lh(r),new Ee(n,null,new H(r))}{if(!(n instanceof Ee||n instanceof Un))throw new q(N.INVALID_ARGUMENT,"Expected first argument to doc() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const r=n._path.child(pe.fromString(e,...t));return Lh(r),new Ee(n.firestore,n instanceof Un?n.converter:null,new H(r))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ad="AsyncQueue";class Sd{constructor(e=Promise.resolve()){this.Yu=[],this.ec=!1,this.tc=[],this.nc=null,this.rc=!1,this.sc=!1,this.oc=[],this.M_=new Jp(this,"async_queue_retry"),this._c=()=>{const r=il();r&&j(Ad,"Visibility state changed to "+r.visibilityState),this.M_.w_()},this.ac=e;const t=il();t&&typeof t.addEventListener=="function"&&t.addEventListener("visibilitychange",this._c)}get isShuttingDown(){return this.ec}enqueueAndForget(e){this.enqueue(e)}enqueueAndForgetEvenWhileRestricted(e){this.uc(),this.cc(e)}enterRestrictedMode(e){if(!this.ec){this.ec=!0,this.sc=e||!1;const t=il();t&&typeof t.removeEventListener=="function"&&t.removeEventListener("visibilitychange",this._c)}}enqueue(e){if(this.uc(),this.ec)return new Promise(()=>{});const t=new an;return this.cc(()=>this.ec&&this.sc?Promise.resolve():(e().then(t.resolve,t.reject),t.promise)).then(()=>t.promise)}enqueueRetryable(e){this.enqueueAndForget(()=>(this.Yu.push(e),this.lc()))}async lc(){if(this.Yu.length!==0){try{await this.Yu[0](),this.Yu.shift(),this.M_.reset()}catch(e){if(!wi(e))throw e;j(Ad,"Operation failed with retryable error: "+e)}this.Yu.length>0&&this.M_.p_(()=>this.lc())}}cc(e){const t=this.ac.then(()=>(this.rc=!0,e().catch(r=>{throw this.nc=r,this.rc=!1,pn("INTERNAL UNHANDLED ERROR: ",xd(r)),r}).then(r=>(this.rc=!1,r))));return this.ac=t,t}enqueueAfterDelay(e,t,r){this.uc(),this.oc.indexOf(e)>-1&&(t=0);const i=Pc.createAndSchedule(this,e,t,r,o=>this.hc(o));return this.tc.push(i),i}uc(){this.nc&&Y(47125,{Pc:xd(this.nc)})}verifyOperationInProgress(){}async Tc(){let e;do e=this.ac,await e;while(e!==this.ac)}Ec(e){for(const t of this.tc)if(t.timerId===e)return!0;return!1}Ic(e){return this.Tc().then(()=>{this.tc.sort((t,r)=>t.targetTimeMs-r.targetTimeMs);for(const t of this.tc)if(t.skipDelay(),e!=="all"&&t.timerId===e)break;return this.Tc()})}Rc(e){this.oc.push(e)}hc(e){const t=this.tc.indexOf(e);this.tc.splice(t,1)}}function xd(n){let e=n.message||"";return n.stack&&(e=n.stack.includes(n.message)?n.stack:n.message+`
`+n.stack),e}class Kn extends Ta{constructor(e,t,r,i){super(e,t,r,i),this.type="firestore",this._queue=new Sd,this._persistenceKey=(i==null?void 0:i.name)||"[DEFAULT]"}async _terminate(){if(this._firestoreClient){const e=this._firestoreClient.terminate();this._queue=new Sd(e),this._firestoreClient=void 0,await e}}}function ME(n,e){const t=typeof n=="object"?n:ff(),r=typeof n=="string"?n:$s,i=Zl(t,"firestore").getImmediate({identifier:r});if(!i._initialized){const o=ty("firestore");o&&DE(i,...o)}return i}function Ea(n){if(n._terminated)throw new q(N.FAILED_PRECONDITION,"The client has already been terminated.");return n._firestoreClient||LE(n),n._firestoreClient}function LE(n){var r,i,o,s;const e=n._freezeSettings(),t=NE(n._databaseId,((r=n._app)==null?void 0:r.options.appId)||"",n._persistenceKey,(i=n._app)==null?void 0:i.options.apiKey,e);n._componentsProvider||(o=e.localCache)!=null&&o._offlineComponentProvider&&((s=e.localCache)!=null&&s._onlineComponentProvider)&&(n._componentsProvider={_offline:e.localCache._offlineComponentProvider,_online:e.localCache._onlineComponentProvider}),n._firestoreClient=new AE(n._authCredentials,n._appCheckCredentials,n._queue,t,n._componentsProvider&&function(u){const h=u==null?void 0:u._online.build();return{_offline:u==null?void 0:u._offline.build(h),_online:h}}(n._componentsProvider))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _t{constructor(e){this._byteString=e}static fromBase64String(e){try{return new _t(We.fromBase64String(e))}catch(t){throw new q(N.INVALID_ARGUMENT,"Failed to construct data from Base64 string: "+t)}}static fromUint8Array(e){return new _t(We.fromUint8Array(e))}toBase64(){return this._byteString.toBase64()}toUint8Array(){return this._byteString.toUint8Array()}toString(){return"Bytes(base64: "+this.toBase64()+")"}isEqual(e){return this._byteString.isEqual(e._byteString)}toJSON(){return{type:_t._jsonSchemaVersion,bytes:this.toBase64()}}static fromJSON(e){if(Fo(e,_t._jsonSchema))return _t.fromBase64String(e.bytes)}}_t._jsonSchemaVersion="firestore/bytes/1.0",_t._jsonSchema={type:Re("string",_t._jsonSchemaVersion),bytes:Re("string")};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Fc{constructor(...e){for(let t=0;t<e.length;++t)if(e[t].length===0)throw new q(N.INVALID_ARGUMENT,"Invalid field name at argument $(i + 1). Field names must not be empty.");this._internalPath=new je(e)}isEqual(e){return this._internalPath.isEqual(e._internalPath)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class jo{constructor(e){this._methodName=e}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Wt{constructor(e,t){if(!isFinite(e)||e<-90||e>90)throw new q(N.INVALID_ARGUMENT,"Latitude must be a number between -90 and 90, but was: "+e);if(!isFinite(t)||t<-180||t>180)throw new q(N.INVALID_ARGUMENT,"Longitude must be a number between -180 and 180, but was: "+t);this._lat=e,this._long=t}get latitude(){return this._lat}get longitude(){return this._long}isEqual(e){return this._lat===e._lat&&this._long===e._long}_compareTo(e){return re(this._lat,e._lat)||re(this._long,e._long)}toJSON(){return{latitude:this._lat,longitude:this._long,type:Wt._jsonSchemaVersion}}static fromJSON(e){if(Fo(e,Wt._jsonSchema))return new Wt(e.latitude,e.longitude)}}Wt._jsonSchemaVersion="firestore/geoPoint/1.0",Wt._jsonSchema={type:Re("string",Wt._jsonSchemaVersion),latitude:Re("number"),longitude:Re("number")};/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class St{constructor(e){this._values=(e||[]).map(t=>t)}toArray(){return this._values.map(e=>e)}isEqual(e){return function(r,i){if(r.length!==i.length)return!1;for(let o=0;o<r.length;++o)if(r[o]!==i[o])return!1;return!0}(this._values,e._values)}toJSON(){return{type:St._jsonSchemaVersion,vectorValues:this._values}}static fromJSON(e){if(Fo(e,St._jsonSchema)){if(Array.isArray(e.vectorValues)&&e.vectorValues.every(t=>typeof t=="number"))return new St(e.vectorValues);throw new q(N.INVALID_ARGUMENT,"Expected 'vectorValues' field to be a number array")}}}St._jsonSchemaVersion="firestore/vectorValue/1.0",St._jsonSchema={type:Re("string",St._jsonSchemaVersion),vectorValues:Re("object")};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const VE=/^__.*__$/;class FE{constructor(e,t,r){this.data=e,this.fieldMask=t,this.fieldTransforms=r}toMutation(e,t){return this.fieldMask!==null?new Qn(e,this.data,this.fieldMask,t,this.fieldTransforms):new Uo(e,this.data,t,this.fieldTransforms)}}class mg{constructor(e,t,r){this.data=e,this.fieldMask=t,this.fieldTransforms=r}toMutation(e,t){return new Qn(e,this.data,this.fieldMask,t,this.fieldTransforms)}}function yg(n){switch(n){case 0:case 2:case 1:return!0;case 3:case 4:return!1;default:throw Y(40011,{dataSource:n})}}class Uc{constructor(e,t,r,i,o,s){this.settings=e,this.databaseId=t,this.serializer=r,this.ignoreUndefinedProperties=i,o===void 0&&this.Ac(),this.fieldTransforms=o||[],this.fieldMask=s||[]}get path(){return this.settings.path}get dataSource(){return this.settings.dataSource}i(e){return new Uc({...this.settings,...e},this.databaseId,this.serializer,this.ignoreUndefinedProperties,this.fieldTransforms,this.fieldMask)}dc(e){var i;const t=(i=this.path)==null?void 0:i.child(e),r=this.i({path:t,arrayElement:!1});return r.mc(e),r}fc(e){var i;const t=(i=this.path)==null?void 0:i.child(e),r=this.i({path:t,arrayElement:!1});return r.Ac(),r}gc(e){return this.i({path:void 0,arrayElement:!0})}yc(e){return Js(e,this.settings.methodName,this.settings.hasConverter||!1,this.path,this.settings.targetDoc)}contains(e){return this.fieldMask.find(t=>e.isPrefixOf(t))!==void 0||this.fieldTransforms.find(t=>e.isPrefixOf(t.field))!==void 0}Ac(){if(this.path)for(let e=0;e<this.path.length;e++)this.mc(this.path.get(e))}mc(e){if(e.length===0)throw this.yc("Document fields must not be empty");if(yg(this.dataSource)&&VE.test(e))throw this.yc('Document fields cannot begin and end with "__"')}}class UE{constructor(e,t,r){this.databaseId=e,this.ignoreUndefinedProperties=t,this.serializer=r||_a(e)}I(e,t,r,i=!1){return new Uc({dataSource:e,methodName:t,targetDoc:r,path:je.emptyPath(),arrayElement:!1,hasConverter:i},this.databaseId,this.serializer,this.ignoreUndefinedProperties)}}function qc(n){const e=n._freezeSettings(),t=_a(n._databaseId);return new UE(n._databaseId,!!e.ignoreUndefinedProperties,t)}function qE(n,e,t,r,i,o={}){const s=n.I(o.merge||o.mergeFields?2:0,e,t,i);jc("Data must be an object, but it was:",s,r);const l=vg(r,s);let u,h;if(o.merge)u=new mt(s.fieldMask),h=s.fieldTransforms;else if(o.mergeFields){const p=[];for(const m of o.mergeFields){const g=ci(e,m,t);if(!s.contains(g))throw new q(N.INVALID_ARGUMENT,`Field '${g}' is specified in your field mask but missing from your input data.`);bg(p,g)||p.push(g)}u=new mt(p),h=s.fieldTransforms.filter(m=>u.covers(m.field))}else u=null,h=s.fieldTransforms;return new FE(new ct(l),u,h)}class Ia extends jo{_toFieldTransform(e){if(e.dataSource!==2)throw e.dataSource===1?e.yc(`${this._methodName}() can only appear at the top level of your update data`):e.yc(`${this._methodName}() cannot be used with set() unless you pass {merge:true}`);return e.fieldMask.push(e.path),null}isEqual(e){return e instanceof Ia}}class Bc extends jo{_toFieldTransform(e){return new Np(e.path,new bo)}isEqual(e){return e instanceof Bc}}class $c extends jo{constructor(e,t){super(e),this.bc=t}_toFieldTransform(e){const t=new Io(e.serializer,kp(e.serializer,this.bc));return new Np(e.path,t)}isEqual(e){return e instanceof $c&&this.bc===e.bc}}function BE(n,e,t,r){const i=n.I(1,e,t);jc("Data must be an object, but it was:",i,r);const o=[],s=ct.empty();Yn(r,(u,h)=>{const p=wg(e,u,t);h=Be(h);const m=i.fc(p);if(h instanceof Ia)o.push(p);else{const g=zo(h,m);g!=null&&(o.push(p),s.set(p,g))}});const l=new mt(o);return new mg(s,l,i.fieldTransforms)}function $E(n,e,t,r,i,o){const s=n.I(1,e,t),l=[ci(e,r,t)],u=[i];if(o.length%2!=0)throw new q(N.INVALID_ARGUMENT,`Function ${e}() needs to be called with an even number of arguments that alternate between field names and values.`);for(let g=0;g<o.length;g+=2)l.push(ci(e,o[g])),u.push(o[g+1]);const h=[],p=ct.empty();for(let g=l.length-1;g>=0;--g)if(!bg(h,l[g])){const b=l[g];let P=u[g];P=Be(P);const A=s.fc(b);if(P instanceof Ia)h.push(b);else{const C=zo(P,A);C!=null&&(h.push(b),p.set(b,C))}}const m=new mt(h);return new mg(p,m,s.fieldTransforms)}function jE(n,e,t,r=!1){return zo(t,n.I(r?4:3,e))}function zo(n,e){if(_g(n=Be(n)))return jc("Unsupported field value:",e,n),vg(n,e);if(n instanceof jo)return function(r,i){if(!yg(i.dataSource))throw i.yc(`${r._methodName}() can only be used with update() and set()`);if(!i.path)throw i.yc(`${r._methodName}() is not currently supported inside arrays`);const o=r._toFieldTransform(i);o&&i.fieldTransforms.push(o)}(n,e),null;if(n===void 0&&e.ignoreUndefinedProperties)return null;if(e.path&&e.fieldMask.push(e.path),n instanceof Array){if(e.settings.arrayElement&&e.dataSource!==4)throw e.yc("Nested arrays are not supported");return function(r,i){const o=[];let s=0;for(const l of r){let u=zo(l,i.gc(s));u==null&&(u={nullValue:"NULL_VALUE"}),o.push(u),s++}return{arrayValue:{values:o}}}(n,e)}return function(r,i){if((r=Be(r))===null)return{nullValue:"NULL_VALUE"};if(typeof r=="number")return kp(i.serializer,r);if(typeof r=="boolean")return{booleanValue:r};if(typeof r=="string")return{stringValue:r};if(r instanceof Date){const o=me.fromDate(r);return{timestampValue:Hs(i.serializer,o)}}if(r instanceof me){const o=new me(r.seconds,1e3*Math.floor(r.nanoseconds/1e3));return{timestampValue:Hs(i.serializer,o)}}if(r instanceof Wt)return{geoPointValue:{latitude:r.latitude,longitude:r.longitude}};if(r instanceof _t)return{bytesValue:Up(i.serializer,r._byteString)};if(r instanceof Ee){const o=i.databaseId,s=r.firestore._databaseId;if(!s.isEqual(o))throw i.yc(`Document reference is for database ${s.projectId}/${s.database} but should be for database ${o.projectId}/${o.database}`);return{referenceValue:wc(r.firestore._databaseId||i.databaseId,r._key.path)}}if(r instanceof St)return function(s,l){const u=s instanceof St?s.toArray():s;return{mapValue:{fields:{[dp]:{stringValue:fp},[js]:{arrayValue:{values:u.map(p=>{if(typeof p!="number")throw l.yc("VectorValues must only contain numeric values.");return mc(l.serializer,p)})}}}}}}(r,i);if(Hp(r))return r._toProto(i.serializer);throw i.yc(`Unsupported field value: ${ca(r)}`)}(n,e)}function vg(n,e){const t={};return sp(n)?e.path&&e.path.length>0&&e.fieldMask.push(e.path):Yn(n,(r,i)=>{const o=zo(i,e.dc(r));o!=null&&(t[r]=o)}),{mapValue:{fields:t}}}function _g(n){return!(typeof n!="object"||n===null||n instanceof Array||n instanceof Date||n instanceof me||n instanceof Wt||n instanceof _t||n instanceof Ee||n instanceof jo||n instanceof St||Hp(n))}function jc(n,e,t){if(!_g(t)||!ip(t)){const r=ca(t);throw r==="an object"?e.yc(n+" a custom object"):e.yc(n+" "+r)}}function ci(n,e,t){if((e=Be(e))instanceof Fc)return e._internalPath;if(typeof e=="string")return wg(n,e);throw Js("Field path arguments must be of type string or ",n,!1,void 0,t)}const zE=new RegExp("[~\\*/\\[\\]]");function wg(n,e,t){if(e.search(zE)>=0)throw Js(`Invalid field path (${e}). Paths must not contain '~', '*', '/', '[', or ']'`,n,!1,void 0,t);try{return new Fc(...e.split("."))._internalPath}catch{throw Js(`Invalid field path (${e}). Paths must not be empty, begin with '.', end with '.', or contain '..'`,n,!1,void 0,t)}}function Js(n,e,t,r,i){const o=r&&!r.isEmpty(),s=i!==void 0;let l=`Function ${e}() called with invalid data`;t&&(l+=" (via `toFirestore()`)"),l+=". ";let u="";return(o||s)&&(u+=" (found",o&&(u+=` in field ${r}`),s&&(u+=` in document ${i}`),u+=")"),new q(N.INVALID_ARGUMENT,l+n+u)}function bg(n,e){return n.some(t=>t.isEqual(e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class WE{convertValue(e,t="none"){switch(Wn(e)){case 0:return null;case 1:return e.booleanValue;case 2:return Ae(e.integerValue||e.doubleValue);case 3:return this.convertTimestamp(e.timestampValue);case 4:return this.convertServerTimestamp(e,t);case 5:return e.stringValue;case 6:return this.convertBytes(zn(e.bytesValue));case 7:return this.convertReference(e.referenceValue);case 8:return this.convertGeoPoint(e.geoPointValue);case 9:return this.convertArray(e.arrayValue,t);case 11:return this.convertObject(e.mapValue,t);case 10:return this.convertVectorValue(e.mapValue);default:throw Y(62114,{value:e})}}convertObject(e,t){return this.convertObjectMap(e.fields,t)}convertObjectMap(e,t="none"){const r={};return Yn(e,(i,o)=>{r[i]=this.convertValue(o,t)}),r}convertVectorValue(e){var r,i,o;const t=(o=(i=(r=e.fields)==null?void 0:r[js].arrayValue)==null?void 0:i.values)==null?void 0:o.map(s=>Ae(s.doubleValue));return new St(t)}convertGeoPoint(e){return new Wt(Ae(e.latitude),Ae(e.longitude))}convertArray(e,t){return(e.values||[]).map(r=>this.convertValue(r,t))}convertServerTimestamp(e,t){switch(t){case"previous":const r=da(e);return r==null?null:this.convertValue(r,t);case"estimate":return this.convertTimestamp(yo(e));default:return null}}convertTimestamp(e){const t=jn(e);return new me(t.seconds,t.nanos)}convertDocumentKey(e,t){const r=pe.fromString(e);he(Wp(r),9688,{name:e});const i=new vo(r.get(1),r.get(3)),o=new H(r.popFirst(5));return i.isEqual(t)||pn(`Document ${o} contains a document reference within a different database (${i.projectId}/${i.database}) which is not supported. It will be treated as a reference in the current database (${t.projectId}/${t.database}) instead.`),o}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class zc extends WE{constructor(e){super(),this.firestore=e}convertBytes(e){return new _t(e)}convertReference(e){const t=this.convertDocumentKey(e,this.firestore._databaseId);return new Ee(this.firestore,null,t)}}function Tr(){return new Bc("serverTimestamp")}function Xs(n){return new $c("increment",n)}const kd="@firebase/firestore",Pd="4.14.0";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Cd(n){return function(t,r){if(typeof t!="object"||t===null)return!1;const i=t;for(const o of r)if(o in i&&typeof i[o]=="function")return!0;return!1}(n,["next","error","complete"])}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Tg{constructor(e,t,r,i,o){this._firestore=e,this._userDataWriter=t,this._key=r,this._document=i,this._converter=o}get id(){return this._key.path.lastSegment()}get ref(){return new Ee(this._firestore,this._converter,this._key)}exists(){return this._document!==null}data(){if(this._document){if(this._converter){const e=new HE(this._firestore,this._userDataWriter,this._key,this._document,null);return this._converter.fromFirestore(e)}return this._userDataWriter.convertValue(this._document.data.value)}}_fieldsProto(){var e;return((e=this._document)==null?void 0:e.data.clone().value.mapValue.fields)??void 0}get(e){if(this._document){const t=this._document.data.field(ci("DocumentSnapshot.get",e));if(t!==null)return this._userDataWriter.convertValue(t)}}}class HE extends Tg{data(){return super.data()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Eg(n){if(n.limitType==="L"&&n.explicitOrderBy.length===0)throw new q(N.UNIMPLEMENTED,"limitToLast() queries require specifying at least one orderBy() clause")}class Wc{}class Hc extends Wc{}function GE(n,e,...t){let r=[];e instanceof Wc&&r.push(e),r=r.concat(t),function(o){const s=o.filter(u=>u instanceof Kc).length,l=o.filter(u=>u instanceof Gc).length;if(s>1||s>0&&l>0)throw new q(N.INVALID_ARGUMENT,"InvalidQuery. When using composite filters, you cannot use more than one filter at the top level. Consider nesting the multiple filters within an `and(...)` statement. For example: change `query(query, where(...), or(...))` to `query(query, and(where(...), or(...)))`.")}(r);for(const i of r)n=i._apply(n);return n}class Gc extends Hc{constructor(e,t,r){super(),this._field=e,this._op=t,this._value=r,this.type="where"}static _create(e,t,r){return new Gc(e,t,r)}_apply(e){const t=this._parse(e);return Ig(e._query,t),new vn(e.firestore,e.converter,Pl(e._query,t))}_parse(e){const t=qc(e.firestore);return function(o,s,l,u,h,p,m){let g;if(h.isKeyField()){if(p==="array-contains"||p==="array-contains-any")throw new q(N.INVALID_ARGUMENT,`Invalid Query. You can't perform '${p}' queries on documentId().`);if(p==="in"||p==="not-in"){Od(m,p);const P=[];for(const A of m)P.push(Rd(u,o,A));g={arrayValue:{values:P}}}else g=Rd(u,o,m)}else p!=="in"&&p!=="not-in"&&p!=="array-contains-any"||Od(m,p),g=jE(l,s,m,p==="in"||p==="not-in");return Ce.create(h,p,g)}(e._query,"where",t,e.firestore._databaseId,this._field,this._op,this._value)}}class Kc extends Wc{constructor(e,t){super(),this.type=e,this._queryConstraints=t}static _create(e,t){return new Kc(e,t)}_parse(e){const t=this._queryConstraints.map(r=>r._parse(e)).filter(r=>r.getFilters().length>0);return t.length===1?t[0]:Ct.create(t,this._getOperator())}_apply(e){const t=this._parse(e);return t.getFilters().length===0?e:(function(i,o){let s=i;const l=o.getFlattenedFilters();for(const u of l)Ig(s,u),s=Pl(s,u)}(e._query,t),new vn(e.firestore,e.converter,Pl(e._query,t)))}_getQueryConstraints(){return this._queryConstraints}_getOperator(){return this.type==="and"?"and":"or"}}class Yc extends Hc{constructor(e,t){super(),this._field=e,this._direction=t,this.type="orderBy"}static _create(e,t){return new Yc(e,t)}_apply(e){const t=function(i,o,s){if(i.startAt!==null)throw new q(N.INVALID_ARGUMENT,"Invalid query. You must not call startAt() or startAfter() before calling orderBy().");if(i.endAt!==null)throw new q(N.INVALID_ARGUMENT,"Invalid query. You must not call endAt() or endBefore() before calling orderBy().");return new wo(o,s)}(e._query,this._field,this._direction);return new vn(e.firestore,e.converter,yb(e._query,t))}}function KE(n,e="asc"){const t=e,r=ci("orderBy",n);return Yc._create(r,t)}class Qc extends Hc{constructor(e,t,r){super(),this.type=e,this._limit=t,this._limitType=r}static _create(e,t,r){return new Qc(e,t,r)}_apply(e){return new vn(e.firestore,e.converter,Ws(e._query,this._limit,this._limitType))}}function YE(n){return $w("limit",n),Qc._create("limit",n,"F")}function Rd(n,e,t){if(typeof(t=Be(t))=="string"){if(t==="")throw new q(N.INVALID_ARGUMENT,"Invalid query. When querying with documentId(), you must provide a valid document ID, but it was an empty string.");if(!bp(e)&&t.indexOf("/")!==-1)throw new q(N.INVALID_ARGUMENT,`Invalid query. When querying a collection by documentId(), you must provide a plain document ID, but '${t}' contains a '/' character.`);const r=e.path.child(pe.fromString(t));if(!H.isDocumentKey(r))throw new q(N.INVALID_ARGUMENT,`Invalid query. When querying a collection group by documentId(), the value provided must result in a valid document path, but '${r}' is not because it has an odd number of segments (${r.length}).`);return Wh(n,new H(r))}if(t instanceof Ee)return Wh(n,t._key);throw new q(N.INVALID_ARGUMENT,`Invalid query. When querying with documentId(), you must provide a valid string or a DocumentReference, but it was: ${ca(t)}.`)}function Od(n,e){if(!Array.isArray(n)||n.length===0)throw new q(N.INVALID_ARGUMENT,`Invalid Query. A non-empty array is required for '${e.toString()}' filters.`)}function Ig(n,e){const t=function(i,o){for(const s of i)for(const l of s.getFlattenedFilters())if(o.indexOf(l.op)>=0)return l.op;return null}(n.filters,function(i){switch(i){case"!=":return["!=","not-in"];case"array-contains-any":case"in":return["not-in"];case"not-in":return["array-contains-any","in","not-in","!="];default:return[]}}(e.op));if(t!==null)throw t===e.op?new q(N.INVALID_ARGUMENT,`Invalid query. You cannot use more than one '${e.op.toString()}' filter.`):new q(N.INVALID_ARGUMENT,`Invalid query. You cannot use '${e.op.toString()}' filters with '${t.toString()}' filters.`)}function QE(n,e,t){let r;return r=n?t&&(t.merge||t.mergeFields)?n.toFirestore(e,t):n.toFirestore(e):e,r}class Zi{constructor(e,t){this.hasPendingWrites=e,this.fromCache=t}isEqual(e){return this.hasPendingWrites===e.hasPendingWrites&&this.fromCache===e.fromCache}}class dr extends Tg{constructor(e,t,r,i,o,s){super(e,t,r,i,s),this._firestore=e,this._firestoreImpl=e,this.metadata=o}exists(){return super.exists()}data(e={}){if(this._document){if(this._converter){const t=new ks(this._firestore,this._userDataWriter,this._key,this._document,this.metadata,null);return this._converter.fromFirestore(t,e)}return this._userDataWriter.convertValue(this._document.data.value,e.serverTimestamps)}}get(e,t={}){if(this._document){const r=this._document.data.field(ci("DocumentSnapshot.get",e));if(r!==null)return this._userDataWriter.convertValue(r,t.serverTimestamps)}}toJSON(){if(this.metadata.hasPendingWrites)throw new q(N.FAILED_PRECONDITION,"DocumentSnapshot.toJSON() attempted to serialize a document with pending writes. Await waitForPendingWrites() before invoking toJSON().");const e=this._document,t={};return t.type=dr._jsonSchemaVersion,t.bundle="",t.bundleSource="DocumentSnapshot",t.bundleName=this._key.toString(),!e||!e.isValidDocument()||!e.isFoundDocument()?t:(this._userDataWriter.convertObjectMap(e.data.value.mapValue.fields,"previous"),t.bundle=(this._firestore,this.ref.path,"NOT SUPPORTED"),t)}}dr._jsonSchemaVersion="firestore/documentSnapshot/1.0",dr._jsonSchema={type:Re("string",dr._jsonSchemaVersion),bundleSource:Re("string","DocumentSnapshot"),bundleName:Re("string"),bundle:Re("string")};class ks extends dr{data(e={}){return super.data(e)}}class fr{constructor(e,t,r,i){this._firestore=e,this._userDataWriter=t,this._snapshot=i,this.metadata=new Zi(i.hasPendingWrites,i.fromCache),this.query=r}get docs(){const e=[];return this.forEach(t=>e.push(t)),e}get size(){return this._snapshot.docs.size}get empty(){return this.size===0}forEach(e,t){this._snapshot.docs.forEach(r=>{e.call(t,new ks(this._firestore,this._userDataWriter,r.key,r,new Zi(this._snapshot.mutatedKeys.has(r.key),this._snapshot.fromCache),this.query.converter))})}docChanges(e={}){const t=!!e.includeMetadataChanges;if(t&&this._snapshot.excludesMetadataChanges)throw new q(N.INVALID_ARGUMENT,"To include metadata changes with your document changes, you must also pass { includeMetadataChanges:true } to onSnapshot().");return this._cachedChanges&&this._cachedChangesIncludeMetadataChanges===t||(this._cachedChanges=function(i,o){if(i._snapshot.oldDocs.isEmpty()){let s=0;return i._snapshot.docChanges.map(l=>{const u=new ks(i._firestore,i._userDataWriter,l.doc.key,l.doc,new Zi(i._snapshot.mutatedKeys.has(l.doc.key),i._snapshot.fromCache),i.query.converter);return l.doc,{type:"added",doc:u,oldIndex:-1,newIndex:s++}})}{let s=i._snapshot.oldDocs;return i._snapshot.docChanges.filter(l=>o||l.type!==3).map(l=>{const u=new ks(i._firestore,i._userDataWriter,l.doc.key,l.doc,new Zi(i._snapshot.mutatedKeys.has(l.doc.key),i._snapshot.fromCache),i.query.converter);let h=-1,p=-1;return l.type!==0&&(h=s.indexOf(l.doc.key),s=s.delete(l.doc.key)),l.type!==1&&(s=s.add(l.doc),p=s.indexOf(l.doc.key)),{type:JE(l.type),doc:u,oldIndex:h,newIndex:p}})}}(this,t),this._cachedChangesIncludeMetadataChanges=t),this._cachedChanges}toJSON(){if(this.metadata.hasPendingWrites)throw new q(N.FAILED_PRECONDITION,"QuerySnapshot.toJSON() attempted to serialize a document with pending writes. Await waitForPendingWrites() before invoking toJSON().");const e={};e.type=fr._jsonSchemaVersion,e.bundleSource="QuerySnapshot",e.bundleName=uc.newId(),this._firestore._databaseId.database,this._firestore._databaseId.projectId;const t=[],r=[],i=[];return this.docs.forEach(o=>{o._document!==null&&(t.push(o._document),r.push(this._userDataWriter.convertObjectMap(o._document.data.value.mapValue.fields,"previous")),i.push(o.ref.path))}),e.bundle=(this._firestore,this.query._query,e.bundleName,"NOT SUPPORTED"),e}}function JE(n){switch(n){case 0:return"added";case 2:case 3:return"modified";case 1:return"removed";default:return Y(61501,{type:n})}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */fr._jsonSchemaVersion="firestore/querySnapshot/1.0",fr._jsonSchema={type:Re("string",fr._jsonSchemaVersion),bundleSource:Re("string","QuerySnapshot"),bundleName:Re("string"),bundle:Re("string")};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function xr(n){n=yt(n,Ee);const e=yt(n.firestore,Kn),t=Ea(e);return PE(t,n._key).then(r=>Ag(e,n,r))}function Jc(n){n=yt(n,vn);const e=yt(n.firestore,Kn),t=Ea(e),r=new zc(e);return Eg(n._query),CE(t,n._query).then(i=>new fr(e,r,n,i))}function Kt(n,e,t){n=yt(n,Ee);const r=yt(n.firestore,Kn),i=QE(n.converter,e,t),o=qc(r);return Xc(r,[qE(o,"setDoc",n._key,i,n.converter!==null,t).toMutation(n._key,At.none())])}function Er(n,e,t,...r){n=yt(n,Ee);const i=yt(n.firestore,Kn),o=qc(i);let s;return s=typeof(e=Be(e))=="string"||e instanceof Fc?$E(o,"updateDoc",n._key,e,t,r):BE(o,"updateDoc",n._key,e),Xc(i,[s.toMutation(n._key,At.exists(!0))])}function Ao(n){return Xc(yt(n.firestore,Kn),[new yc(n._key,At.none())])}function Wo(n,...e){var h,p,m;n=Be(n);let t={includeMetadataChanges:!1,source:"default"},r=0;typeof e[r]!="object"||Cd(e[r])||(t=e[r++]);const i={includeMetadataChanges:t.includeMetadataChanges,source:t.source};if(Cd(e[r])){const g=e[r];e[r]=(h=g.next)==null?void 0:h.bind(g),e[r+1]=(p=g.error)==null?void 0:p.bind(g),e[r+2]=(m=g.complete)==null?void 0:m.bind(g)}let o,s,l;if(n instanceof Ee)s=yt(n.firestore,Kn),l=fa(n._key.path),o={next:g=>{e[r]&&e[r](Ag(s,n,g))},error:e[r+1],complete:e[r+2]};else{const g=yt(n,vn);s=yt(g.firestore,Kn),l=g._query;const b=new zc(s);o={next:P=>{e[r]&&e[r](new fr(s,b,g,P))},error:e[r+1],complete:e[r+2]},Eg(n._query)}const u=Ea(s);return kE(u,l,i,o)}function Xc(n,e){const t=Ea(n);return RE(t,e)}function Ag(n,e,t){const r=t.docs.get(e._key),i=new zc(n);return new dr(n,i,e._key,r,new Zi(t.hasPendingWrites,t.fromCache),e.converter)}(function(e,t=!0){Cw(mi),ni(new yr("firestore",(r,{instanceIdentifier:i,options:o})=>{const s=r.getProvider("app").getImmediate(),l=new Kn(new Nw(r.getProvider("auth-internal")),new Lw(s,r.getProvider("app-check-internal")),eb(s,i),s);return o={useFetchStreams:t,...o},l._setSettings(o),l},"PUBLIC").setMultipleInstances(!0)),Vn(kd,Pd,e),Vn(kd,Pd,"esm2020")})();let W=null;function XE(){let n;Ds().length===0?n=ec(Kf):n=Ds()[0],W=ME(n),console.log("[OpenOverlay] Firestore initialized")}async function ZE(n){if(!W){console.error("[OpenOverlay] Firestore not initialized");return}const e=_e(W,"users",n.uid);(await xr(e)).exists()?(await Er(e,{displayName:n.displayName||"Anonymous",photoURL:n.photoURL||"",email:n.email||""}),console.log("[OpenOverlay] User profile updated")):(await Kt(e,{uid:n.uid,displayName:n.displayName||"Anonymous",email:n.email||"",photoURL:n.photoURL||"",bio:"",createdAt:Tr(),followersCount:0,followingCount:0}),console.log("[OpenOverlay] User profile created"))}async function Sg(n){if(!W)return null;const e=_e(W,"users",n),t=await xr(e);return t.exists()?t.data():null}async function eI(n){const e=ce();if(!W||!e||e.uid===n)return;const t=_e(W,"users",e.uid,"following",n);await Kt(t,{followedAt:Tr()});const r=_e(W,"users",n,"followers",e.uid);await Kt(r,{followedAt:Tr()});const i=_e(W,"users",e.uid),o=_e(W,"users",n);await Er(i,{followingCount:Xs(1)}),await Er(o,{followersCount:Xs(1)}),console.log("[OpenOverlay] Followed user:",n)}async function tI(n){const e=ce();if(!W||!e||e.uid===n)return;const t=_e(W,"users",e.uid,"following",n);await Ao(t);const r=_e(W,"users",n,"followers",e.uid);await Ao(r);const i=_e(W,"users",e.uid),o=_e(W,"users",n);await Er(i,{followingCount:Xs(-1)}),await Er(o,{followersCount:Xs(-1)}),console.log("[OpenOverlay] Unfollowed user:",n)}async function nI(n){const e=ce();if(!W||!e)return!1;const t=_e(W,"users",e.uid,"following",n);return(await xr(t)).exists()}async function rI(n,e=50){if(!W)return[];const t=Jn(W,"users",n,"following"),r=GE(t,KE("followedAt","desc"),YE(e)),i=await Jc(r),o=[];for(const s of i.docs){const l=await Sg(s.id);l&&o.push(l)}return o}async function xg(n,e,t){const r=ce();if(!W||!r)return console.log("[OpenOverlay] Not logged in, skipping cloud save"),!1;try{const i=_e(W,"pageDrawings",n,"contributors",r.uid);return await Kt(i,{userId:r.uid,userDisplayName:r.displayName||"Anonymous",userPhotoURL:r.photoURL||"",pageUrl:e,items:JSON.stringify(t),updatedAt:Tr()}),console.log("[OpenOverlay] Drawing saved to cloud (public)"),!0}catch(i){return console.error("[OpenOverlay] Failed to save drawing to cloud:",i),!1}}async function iI(n){if(!W)return null;const e=ce();try{const t=Jn(W,"pageDrawings",n,"contributors"),r=await Jc(t),i=[],o=[],s=[];return r.docs.forEach(l=>{const u=l.data(),h=JSON.parse(u.items||"[]");s.push({userId:u.userId,displayName:u.userDisplayName,photoURL:u.userPhotoURL}),e&&u.userId===e.uid?i.push(...h):h.forEach(p=>{o.push({...p,_ownerId:u.userId,_ownerName:u.userDisplayName,_readOnly:!0})})}),console.log("[OpenOverlay] Loaded drawings:",i.length,"mine,",o.length,"from others"),{myItems:i,otherItems:o,contributors:s}}catch(t){return console.error("[OpenOverlay] Failed to load drawings from cloud:",t),null}}async function oI(n){const e=ce();if(!W||!e)return!1;try{const t=_e(W,"pageDrawings",n,"contributors",e.uid);return await Ao(t),console.log("[OpenOverlay] Drawing deleted from cloud"),!0}catch(t){return console.error("[OpenOverlay] Failed to delete drawing from cloud:",t),!1}}let hs=null;function sI(n,e){if(!W)return console.log("[OpenOverlay] Cannot subscribe to drawings: Firestore not initialized"),null;hs&&hs();const t=ce(),r=Jn(W,"pageDrawings",n,"contributors");return hs=Wo(r,i=>{const o=[],s=[],l=[];i.docs.forEach(u=>{const h=u.data(),p=JSON.parse(h.items||"[]");l.push({userId:h.userId,displayName:h.userDisplayName,photoURL:h.userPhotoURL}),t&&h.userId===t.uid?o.push(...p):p.forEach(m=>{s.push({...m,_ownerId:h.userId,_ownerName:h.userDisplayName,_readOnly:!0})})}),console.log("[OpenOverlay] Real-time drawing update:",o.length,"mine,",s.length,"from others"),e({myItems:o,otherItems:s,contributors:l})},i=>{console.error("[OpenOverlay] Drawing subscription error:",i)}),console.log("[OpenOverlay] Subscribed to drawings on page:",n),hs}function kr(){return W!==null}function Zs(){return ce()!==null}let ds=null;async function aI(n,e){if(!W)return console.log("[OpenOverlay] Cannot save annotation: Firestore not initialized"),!1;try{const t=_e(W,"pageAnnotations",n,"annotations",e.id),r={...e,reactions:e.reactions||[],replies:e.replies||[],updatedAt:Tr()};return console.log("[OpenOverlay] Saving to Firestore:",t.path),await Kt(t,r,{merge:!0}),console.log("[OpenOverlay] Annotation saved to cloud successfully"),!0}catch(t){return console.error("[OpenOverlay] Failed to save annotation:",(t==null?void 0:t.message)||t),(t==null?void 0:t.code)==="permission-denied"&&console.error("[OpenOverlay] Firestore security rules may need to be updated"),!1}}async function lI(n,e){if(!W)return!1;try{const t=_e(W,"pageAnnotations",n,"annotations",e);return await Ao(t),console.log("[OpenOverlay] Annotation deleted from cloud"),!0}catch(t){return console.error("[OpenOverlay] Failed to delete annotation:",t),!1}}async function kg(n){if(!W)return[];try{const e=Jn(W,"pageAnnotations",n,"annotations"),t=await Jc(e),r=[];return t.forEach(i=>{r.push({id:i.id,...i.data()})}),r.sort((i,o)=>(o.createdAt||0)-(i.createdAt||0)),console.log("[OpenOverlay] Fetched",r.length,"annotations from cloud"),r}catch(e){return console.error("[OpenOverlay] Failed to fetch annotations:",e),[]}}function cI(n,e){if(!W)return console.log("[OpenOverlay] Cannot subscribe to annotations: Firestore not initialized"),null;ds&&ds();const t=Jn(W,"pageAnnotations",n,"annotations");return ds=Wo(t,r=>{const i=[];r.forEach(o=>{i.push({id:o.id,...o.data()})}),i.sort((o,s)=>(s.createdAt||0)-(o.createdAt||0)),console.log("[OpenOverlay] Real-time update:",i.length,"annotations"),e(i)},r=>{console.error("[OpenOverlay] Annotation subscription error:",r),kg(n).then(e)}),ds}async function uI(n,e,t){if(!W)return!1;try{const r=_e(W,"pageAnnotations",n,"annotations",e),i=await xr(r);if(!i.exists())return!1;const s=i.data().replies||[];return s.push(t),await Er(r,{replies:s}),console.log("[OpenOverlay] Reply added"),!0}catch(r){return console.error("[OpenOverlay] Failed to add reply:",r),!1}}async function hI(n,e,t,r){if(!W)return!1;try{const i=_e(W,"pageAnnotations",n,"annotations",e),o=await xr(i);if(!o.exists())return!1;let l=o.data().reactions||[];const u=l.find(h=>h.emoji===t);return u?u.users.includes(r)?(u.users=u.users.filter(h=>h!==r),u.count=u.users.length,u.count===0&&(l=l.filter(h=>h.emoji!==t))):(u.users.push(r),u.count=u.users.length):l.push({emoji:t,count:1,users:[r]}),await Er(i,{reactions:l}),!0}catch(i){return console.error("[OpenOverlay] Failed to toggle reaction:",i),!1}}let ar=null,Nd=0;async function dI(n,e){const t=ce();if(!W||!t){console.log("[OpenOverlay] Cannot sync position: db=",!!W,"user=",!!t);return}try{const r=_e(W,"pageGames",n,"players",t.uid);await Kt(r,{...e,odlPlayerId:t.uid,displayName:e.displayName||t.displayName||"Player",updatedAt:Date.now()},{merge:!0})}catch(r){const i=Date.now();i-Nd>1e4&&(Nd=i,console.error("[OpenOverlay] Position sync error:",(r==null?void 0:r.message)||r))}}function fI(n,e){if(!W)return console.log("[OpenOverlay] Cannot subscribe to players: Firestore not initialized"),null;const t=ce();console.log("[OpenOverlay] Subscribing to players for page:",n,"currentUser:",t==null?void 0:t.uid),ar&&ar();const r=Jn(W,"pageGames",n,"players");return ar=Wo(r,i=>{const o=new Map,s=Date.now(),l=3e4;i.forEach(u=>{const h=u.data(),p=s-h.updatedAt;t&&u.id===t.uid||p>l||o.set(u.id,h)}),o.size>0&&console.log("[OpenOverlay] Got",o.size,"other players from snapshot"),e(o)},i=>{console.error("[OpenOverlay] Player subscription error:",i)}),console.log("[OpenOverlay] Subscribed to players on page:",n),ar}async function Pg(n){const e=ce();if(!(!W||!e))try{const t=_e(W,"pageGames",n,"players",e.uid);await Ao(t),console.log("[OpenOverlay] Player removed from page")}catch(t){console.error("[OpenOverlay] Failed to remove player:",t)}}function Cg(){ar&&(ar(),ar=null)}let lr=null;function pI(n,e){if(!W)return console.log("[OpenOverlay] Cannot subscribe to tag game: Firestore not initialized"),null;lr&&lr();const t=_e(W,"pageGames",n,"gameState","tag");return lr=Wo(t,r=>{r.exists()?e(r.data()):e(null)},r=>{console.error("[OpenOverlay] Tag game subscription error:",r),e(null)}),console.log("[OpenOverlay] Subscribed to tag game"),lr}function gI(){lr&&(lr(),lr=null)}async function mI(n){const e=ce();if(!W||!e)return!1;try{const t=_e(W,"pageGames",n,"gameState","tag"),r=await xr(t);if(r.exists()){const i=r.data();return console.log("[OpenOverlay] Joined existing tag game, IT is:",i.itPlayerId),i.itPlayerId===e.uid}return await Kt(t,{itPlayerId:e.uid,lastTagTime:Date.now(),gameActive:!0}),console.log("[OpenOverlay] Started new tag game - you are IT!"),!0}catch(t){return console.error("[OpenOverlay] Failed to start tag game:",t),!1}}async function yI(n,e){const t=ce();if(!W||!t)return!1;try{const r=_e(W,"pageGames",n,"gameState","tag"),i=await xr(r);return i.exists()?i.data().itPlayerId!==t.uid?(console.log("[OpenOverlay] Cannot tag - you are not IT"),!1):(await Kt(r,{itPlayerId:e,lastTagTime:Date.now(),gameActive:!0}),console.log("[OpenOverlay] Tagged player:",e),!0):!1}catch(r){return console.error("[OpenOverlay] Failed to tag player:",r),!1}}async function vI(n,e){if(!W)return console.error("[OpenOverlay] Cannot submit feedback: Firestore not initialized"),!1;const t=ce();try{const r=Jn(W,"feedback"),i=_e(r);return await Kt(i,{type:n,message:e,userId:(t==null?void 0:t.uid)||null,userEmail:(t==null?void 0:t.email)||null,userName:(t==null?void 0:t.displayName)||null,pageUrl:window.location.href,userAgent:navigator.userAgent,timestamp:Tr()}),console.log("[OpenOverlay] Feedback submitted successfully"),!0}catch(r){return console.error("[OpenOverlay] Failed to submit feedback:",r),!1}}let fs=null;async function _I(n,e){const t=ce();if(!W||!t)return console.log("[OpenOverlay] Not logged in, skipping course cloud save"),!1;try{const r=_e(W,"pageCourses",n,"courses",t.uid);return await Kt(r,{...e,authorId:t.uid,authorName:t.displayName||"Anonymous",updatedAt:Tr()}),console.log("[OpenOverlay] Course saved to cloud"),!0}catch(r){return console.error("[OpenOverlay] Failed to save course to cloud:",r),!1}}function wI(n,e){if(!W)return console.log("[OpenOverlay] Cannot subscribe to courses: Firestore not initialized"),null;fs&&fs();const t=ce(),r=Jn(W,"pageCourses",n,"courses");return fs=Wo(r,i=>{let o=null;const s=[];i.forEach(l=>{const u=l.data();t&&l.id===t.uid?o=u:s.push(u)}),console.log("[OpenOverlay] Course update: mine=",!!o,"others=",s.length),e({myCourse:o,otherCourses:s})},i=>{console.error("[OpenOverlay] Course subscription error:",i)}),console.log("[OpenOverlay] Subscribed to courses on page:",n),fs}let sl=null,ui=null,Zc=null;const Ps=[];function bI(){Ds().length===0?sl=ec(Kf):sl=Ds()[0],ui=kw(sl),m_(ui,async n=>{Zc=n,console.log("[OpenOverlay] Auth state changed:",(n==null?void 0:n.displayName)||"signed out"),n&&await ZE(n),Ps.forEach(e=>e(n))}),console.log("[OpenOverlay] Auth initialized")}async function TI(){if(!ui)return console.error("[OpenOverlay] Auth not initialized"),null;const n=await new Promise(e=>{chrome.runtime.sendMessage({type:"GOOGLE_SIGN_IN"},e)});if(!n.success||!n.token)throw new Error(n.error||"Failed to get auth token");try{const e=en.credential(null,n.token),t=await f_(ui,e);return console.log("[OpenOverlay] Signed in as:",t.user.displayName),t.user}catch(e){throw console.error("[OpenOverlay] Sign in error:",e),(e==null?void 0:e.code)==="auth/invalid-credential"&&await new Promise(t=>{chrome.runtime.sendMessage({type:"GOOGLE_SIGN_OUT"},()=>t())}),e}}async function EI(){ui&&(await new Promise(n=>{chrome.runtime.sendMessage({type:"GOOGLE_SIGN_OUT"},()=>n())}),await y_(ui),console.log("[OpenOverlay] Signed out"))}function ce(){return Zc}function Rg(n){return Ps.push(n),n(Zc),()=>{const e=Ps.indexOf(n);e>-1&&Ps.splice(e,1)}}let ze=[],eo=null,ji=null,ht=null,cr=null,qn=new Set;const al=["#ffeb3b","#ff9800","#4caf50","#2196f3","#e91e63"],eu=["👍","❤️","😂","😮","😢","😡","🔥","👀","💯","🎉"],II=`
  .oo-annotate-btn {
    position: absolute;
    background: #22c55e;
    color: white;
    border: none;
    padding: 6px 12px;
    border-radius: 6px;
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
    box-shadow: 0 2px 8px rgba(0,0,0,0.2);
    z-index: 2147483646;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    transition: transform 0.1s;
  }

  .oo-annotate-btn:hover {
    transform: scale(1.05);
  }

  .oo-annotation-form {
    position: absolute;
    background: #1a1a1a;
    border-radius: 12px;
    padding: 16px;
    box-shadow: 0 8px 32px rgba(0,0,0,0.3);
    z-index: 2147483646;
    width: 300px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  }

  .oo-annotation-form textarea {
    width: 100%;
    height: 80px;
    background: #2a2a2a;
    border: 1px solid #333;
    border-radius: 8px;
    color: #fff;
    padding: 10px;
    font-size: 14px;
    resize: none;
    font-family: inherit;
  }

  .oo-annotation-form textarea:focus {
    outline: none;
    border-color: #22c55e;
  }

  .oo-annotation-form .colors {
    display: flex;
    gap: 6px;
    margin: 12px 0;
  }

  .oo-annotation-form .color-btn {
    width: 24px;
    height: 24px;
    border-radius: 50%;
    border: 2px solid transparent;
    cursor: pointer;
    transition: transform 0.1s;
  }

  .oo-annotation-form .color-btn:hover {
    transform: scale(1.2);
  }

  .oo-annotation-form .color-btn.active {
    border-color: #fff;
  }

  .oo-annotation-form .actions {
    display: flex;
    justify-content: flex-end;
    gap: 8px;
    margin-top: 12px;
  }

  .oo-annotation-form button {
    padding: 8px 16px;
    border: none;
    border-radius: 6px;
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
    font-family: inherit;
  }

  .oo-annotation-form .cancel-btn {
    background: #333;
    color: #fff;
  }

  .oo-annotation-form .save-btn {
    background: #22c55e;
    color: #fff;
  }

  .oo-popup {
    position: absolute;
    background: #1a1a1a;
    border-radius: 12px;
    box-shadow: 0 8px 32px rgba(0,0,0,0.4);
    z-index: 2147483646;
    max-width: 320px;
    min-width: 200px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    pointer-events: auto;
    padding: 14px;
  }

  .oo-popup .popup-quote {
    font-size: 18px;
    font-weight: 700;
    color: #fff;
    line-height: 1.3;
    margin-bottom: 8px;
  }

  .oo-popup .popup-author {
    text-align: right;
    color: #888;
    font-size: 12px;
    margin-bottom: 10px;
  }

  .oo-popup .popup-footer {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
  }

  .oo-popup .popup-reactions {
    display: flex;
    gap: 4px;
    flex-wrap: wrap;
    flex: 1;
  }

  .oo-popup .reaction {
    background: #222;
    border: 1px solid #333;
    border-radius: 12px;
    padding: 2px 6px;
    font-size: 12px;
    cursor: pointer;
    transition: background 0.1s;
    display: flex;
    align-items: center;
    gap: 2px;
  }

  .oo-popup .reaction:hover {
    background: #333;
  }

  .oo-popup .reaction .count {
    color: #888;
    font-size: 11px;
  }

  .oo-popup .reaction.active {
    background: #22c55e33;
    border-color: #22c55e;
  }

  .oo-popup .popup-actions {
    display: flex;
    gap: 6px;
    align-items: center;
  }

  .oo-popup .comment-btn {
    background: #222;
    border: 1px solid #333;
    border-radius: 12px;
    padding: 2px 8px;
    font-size: 12px;
    cursor: pointer;
    color: #888;
    display: flex;
    align-items: center;
    gap: 4px;
  }

  .oo-popup .comment-btn:hover {
    background: #333;
    color: #fff;
  }

  .oo-popup .add-reaction {
    background: #222;
    border: 1px solid #333;
    border-radius: 12px;
    padding: 2px 6px;
    font-size: 14px;
    cursor: pointer;
    color: #888;
  }

  .oo-popup .add-reaction:hover {
    background: #333;
    border-color: #22c55e;
    color: #22c55e;
  }

  .oo-popup .maximize-btn {
    background: none;
    border: none;
    color: #666;
    font-size: 14px;
    cursor: pointer;
    padding: 2px 4px;
  }

  .oo-popup .maximize-btn:hover {
    color: #fff;
  }

  .oo-popup .bookmark-btn {
    background: transparent;
    border: none;
    padding: 2px 4px;
    cursor: pointer;
    font-size: 14px;
    color: #888;
    transition: color 0.15s;
  }

  .oo-popup .bookmark-btn:hover {
    color: #fff;
  }

  .oo-popup .bookmark-btn.active {
    color: #f59e0b;
  }

  .oo-popup .delete-btn {
    background: transparent;
    border: none;
    padding: 2px 4px;
    cursor: pointer;
    font-size: 14px;
    color: #666;
    transition: color 0.15s;
  }

  .oo-popup .delete-btn:hover {
    color: #ef4444;
  }

  .oo-comment-panel .delete-btn {
    background: #ef4444;
    color: white;
    border: none;
    padding: 8px 16px;
    border-radius: 6px;
    cursor: pointer;
    font-size: 13px;
    margin-top: 12px;
  }

  .oo-comment-panel .delete-btn:hover {
    background: #dc2626;
  }

  .oo-popup .popup-reply-section {
    margin-top: 10px;
    padding-top: 10px;
    border-top: 1px solid #333;
    display: none;
  }

  .oo-popup .popup-reply-section.open {
    display: block;
  }

  .oo-popup .popup-reply-input {
    display: flex;
    gap: 6px;
  }

  .oo-popup .popup-reply-input input {
    flex: 1;
    background: #222;
    border: 1px solid #333;
    border-radius: 14px;
    padding: 6px 10px;
    color: #fff;
    font-size: 12px;
  }

  .oo-popup .popup-reply-input input:focus {
    outline: none;
    border-color: #22c55e;
  }

  .oo-popup .popup-reply-input button {
    background: #22c55e;
    border: none;
    border-radius: 50%;
    width: 26px;
    height: 26px;
    color: white;
    font-size: 12px;
    cursor: pointer;
  }

  .oo-popup .quick-emojis {
    display: flex;
    gap: 2px;
    margin-top: 8px;
  }

  .oo-popup .quick-emoji {
    background: none;
    border: none;
    font-size: 16px;
    cursor: pointer;
    padding: 2px;
    border-radius: 4px;
    opacity: 0.6;
    transition: opacity 0.1s, transform 0.1s;
  }

  .oo-popup .quick-emoji:hover {
    opacity: 1;
    transform: scale(1.2);
  }

  .oo-popup-emoji-picker {
    position: absolute;
    background: #222;
    border-radius: 10px;
    padding: 6px;
    box-shadow: 0 4px 16px rgba(0,0,0,0.4);
    display: flex;
    flex-wrap: wrap;
    gap: 2px;
    width: 180px;
    bottom: 100%;
    left: 0;
    margin-bottom: 4px;
  }

  .oo-popup-emoji-picker .emoji-btn {
    width: 28px;
    height: 28px;
    border: none;
    background: transparent;
    border-radius: 4px;
    font-size: 16px;
    cursor: pointer;
  }

  .oo-popup-emoji-picker .emoji-btn:hover {
    background: #333;
  }

  .oo-comment-panel {
    position: fixed;
    right: 0;
    top: 0;
    width: 360px;
    height: 100vh;
    background: #111;
    box-shadow: -4px 0 24px rgba(0,0,0,0.3);
    z-index: 2147483646;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    display: flex;
    flex-direction: column;
    transform: translateX(100%);
    transition: transform 0.2s ease-out;
  }

  .oo-comment-panel.open {
    transform: translateX(0);
  }

  .oo-comment-panel .header {
    padding: 16px;
    border-bottom: 1px solid #222;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .oo-comment-panel .header h3 {
    margin: 0;
    color: #fff;
    font-size: 16px;
  }

  .oo-comment-panel .close-btn {
    background: none;
    border: none;
    color: #888;
    font-size: 24px;
    cursor: pointer;
    padding: 0;
    line-height: 1;
  }

  .oo-comment-panel .highlighted-text {
    padding: 16px;
    background: #1a1a1a;
    border-bottom: 1px solid #222;
  }

  .oo-comment-panel .highlighted-text blockquote {
    margin: 0;
    padding-left: 12px;
    border-left: 3px solid #22c55e;
    color: #aaa;
    font-style: italic;
  }

  .oo-comment-panel .main-comment {
    padding: 16px;
    border-bottom: 1px solid #222;
  }

  .oo-comment-panel .author-info {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 8px;
  }

  .oo-comment-panel .avatar {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    background: #333;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #888;
    font-size: 14px;
  }

  .oo-comment-panel .author-name {
    color: #fff;
    font-weight: 600;
    font-size: 14px;
  }

  .oo-comment-panel .timestamp {
    color: #666;
    font-size: 12px;
  }

  .oo-comment-panel .comment-text {
    color: #ddd;
    font-size: 14px;
    line-height: 1.5;
  }

  .oo-comment-panel .reactions {
    display: flex;
    gap: 8px;
    margin-top: 12px;
    flex-wrap: wrap;
  }

  .oo-comment-panel .reaction {
    background: #222;
    border: 1px solid #333;
    border-radius: 16px;
    padding: 4px 10px;
    font-size: 13px;
    cursor: pointer;
    transition: background 0.1s;
  }

  .oo-comment-panel .reaction:hover {
    background: #333;
  }

  .oo-comment-panel .reaction .emoji {
    margin-right: 4px;
  }

  .oo-comment-panel .reaction .count {
    color: #888;
  }

  .oo-comment-panel .add-reaction {
    background: #1a1a1a;
    border: 1px dashed #444;
    color: #888;
    font-size: 16px;
    min-width: 36px;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .oo-comment-panel .add-reaction:hover {
    border-color: #22c55e;
    color: #22c55e;
  }

  .oo-comment-panel .reaction.active {
    background: #22c55e33;
    border-color: #22c55e;
  }

  .oo-emoji-picker {
    position: absolute;
    background: #222;
    border-radius: 12px;
    padding: 8px;
    box-shadow: 0 4px 16px rgba(0,0,0,0.4);
    display: flex;
    flex-wrap: wrap;
    gap: 4px;
    width: 200px;
    z-index: 10;
  }

  .oo-emoji-picker .emoji-btn {
    width: 32px;
    height: 32px;
    border: none;
    background: transparent;
    border-radius: 6px;
    font-size: 18px;
    cursor: pointer;
    transition: background 0.1s, transform 0.1s;
  }

  .oo-emoji-picker .emoji-btn:hover {
    background: #333;
    transform: scale(1.2);
  }

  .oo-comment-panel .replies-section {
    flex: 1;
    overflow-y: auto;
    padding: 16px;
  }

  .oo-comment-panel .reply {
    margin-bottom: 16px;
    padding-bottom: 16px;
    border-bottom: 1px solid #222;
  }

  .oo-comment-panel .reply:last-child {
    border-bottom: none;
  }

  .oo-comment-panel .reply-input {
    padding: 16px;
    border-top: 1px solid #222;
    display: flex;
    gap: 8px;
  }

  .oo-comment-panel .reply-input input {
    flex: 1;
    background: #222;
    border: 1px solid #333;
    border-radius: 20px;
    padding: 10px 16px;
    color: #fff;
    font-size: 14px;
  }

  .oo-comment-panel .reply-input input:focus {
    outline: none;
    border-color: #22c55e;
  }

  .oo-comment-panel .reply-input button {
    background: #22c55e;
    border: none;
    border-radius: 50%;
    width: 40px;
    height: 40px;
    color: white;
    font-size: 18px;
    cursor: pointer;
  }
`;function AI(){console.log("[OpenOverlay] initAnnotations starting..."),ji=document.createElement("div"),ji.id="openoverlay-annotations",ji.style.cssText=`
    position: fixed;
    top: 0;
    left: 0;
    width: 0;
    height: 0;
    z-index: 2147483646;
    pointer-events: none;
  `,ht=ji.attachShadow({mode:"open"});const n=document.createElement("style");n.textContent=II,ht.appendChild(n),document.body.appendChild(ji),document.addEventListener("mouseup",xI),document.addEventListener("selectionchange",SI),VI(),jI(),Aa(),console.log("[OpenOverlay] Annotations initialized")}let ll=null;function SI(){ll&&clearTimeout(ll),ll=window.setTimeout(()=>{Og()},100)}function xI(n){var e,t;(e=n.target)!=null&&e.closest("#openoverlay-annotations")||(t=n.target)!=null&&t.closest("#openoverlay-ui")||setTimeout(Og,10)}function Og(){const n=window.getSelection();if(!n||n.isCollapsed||!n.toString().trim()){ea();return}if(n.toString().trim().length<3){ea();return}const r=n.getRangeAt(0).getBoundingClientRect();kI(r,n)}function kI(n,e){if(ea(),!ht)return;const t=document.createElement("button");t.className="oo-annotate-btn",t.textContent="+ Annotate",t.style.pointerEvents="auto";const r=Math.max(10,Math.min(n.left+n.width/2-50,window.innerWidth-110)),i=n.bottom+2,o=i+32>window.innerHeight?n.top-34:i;t.style.left=`${r}px`,t.style.top=`${o}px`,t.onclick=s=>{s.preventDefault(),s.stopPropagation(),PI(n,e)},ht.appendChild(t),eo=t}function ea(){eo&&(ht!=null&&ht.contains(eo))&&eo.remove(),eo=null}function PI(n,e){var g,b;if(ea(),!ht)return;const t=e.toString().trim(),r=e.getRangeAt(0),i=e.anchorNode,o=e.focusNode,s=document.createElement("div");s.className="oo-annotation-form",s.style.pointerEvents="auto";const l=Math.max(10,Math.min(n.left,window.innerWidth-320)),u=n.bottom+4,h=180,p=u+h>window.innerHeight?Math.max(10,n.top-h-4):u;s.style.left=`${l}px`,s.style.top=`${p}px`;let m=al[0];s.innerHTML=`
    <textarea placeholder="Add your annotation..." autofocus></textarea>
    <div class="colors">
      ${al.map((P,A)=>`
        <div class="color-btn ${A===0?"active":""}"
             data-color="${P}"
             style="background: ${P}"></div>
      `).join("")}
    </div>
    <div class="actions">
      <button class="cancel-btn">Cancel</button>
      <button class="save-btn">Save</button>
    </div>
  `,s.querySelectorAll(".color-btn").forEach(P=>{P.addEventListener("click",()=>{s.querySelectorAll(".color-btn").forEach(A=>A.classList.remove("active")),P.classList.add("active"),m=P.dataset.color||al[0]})}),(g=s.querySelector(".cancel-btn"))==null||g.addEventListener("click",()=>{var P;s.remove(),(P=window.getSelection())==null||P.removeAllRanges()}),(b=s.querySelector(".save-btn"))==null||b.addEventListener("click",()=>{var V;const P=s.querySelector("textarea"),A=P.value.trim();if(!A){P.focus();return}const{contextBefore:C,contextAfter:$}=RI(r,t),F={id:CI(),text:t,contextBefore:C,contextAfter:$,anchorSelector:Dd(i),anchorOffset:e.anchorOffset,focusSelector:Dd(o),focusOffset:e.focusOffset,comment:A,color:m,authorId:"local-user",authorName:"You",createdAt:Date.now(),reactions:[],replies:[]};ze.push(F),xt(),Aa(),LI(F),s.remove(),(V=window.getSelection())==null||V.removeAllRanges(),console.log("[OpenOverlay] Annotation created:",F.id)}),ht.appendChild(s),setTimeout(()=>{var P;(P=s.querySelector("textarea"))==null||P.focus()},10)}function Dd(n){if(!n)return"body";const e=n.nodeType===Node.TEXT_NODE?n.parentElement:n;if(!e)return"body";const t=[];let r=e;for(;r&&r!==document.body&&r!==document.documentElement;){let i=r.tagName.toLowerCase();if(r.id){t.unshift(`#${CSS.escape(r.id)}`);break}const o=r.parentElement;if(o){const l=Array.from(o.children).indexOf(r)+1;i+=`:nth-child(${l})`}t.unshift(i),r=r.parentElement}return t.join(" > ")||"body"}function CI(){return Math.random().toString(36).substr(2,9)}function RI(n,e){var r;try{const i=n.commonAncestorContainer,o=i.nodeType===Node.TEXT_NODE?i.parentElement:i;if(!o)return{contextBefore:"",contextAfter:""};const s=o.textContent||"",l=((r=n.startContainer.textContent)==null?void 0:r.substring(0,n.startOffset))||"";let u="";const h=document.createTreeWalker(o,NodeFilter.SHOW_TEXT,null);let p;for(;p=h.nextNode();){if(p===n.startContainer){u+=l;break}u+=p.textContent||""}const m=u.slice(-30),g=u.length+e.length,b=s.substring(g,g+30);return{contextBefore:m,contextAfter:b}}catch(i){return console.warn("[OpenOverlay] Failed to get selection context:",i),{contextBefore:"",contextAfter:""}}}function tu(){document.querySelectorAll(".oo-highlight").forEach(n=>{const e=n.parentNode;e&&(e.replaceChild(document.createTextNode(n.textContent||""),n),e.normalize())})}function Aa(){tu();for(const n of ze)try{OI(n)}catch(e){console.warn("[OpenOverlay] Failed to highlight annotation:",n.id,e)}}function OI(n){(n.contextBefore||"")+n.text+(n.contextAfter||"");const e=n.text,t=[],r=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,null);let i="",o;for(;o=r.nextNode();){const h=o.textContent||"";t.push({node:o,start:i.length,end:i.length+h.length}),i+=h}let s=-1;if(n.contextBefore||n.contextAfter){const h=n.contextBefore||"",p=n.contextAfter||"";let m=0;for(;m<i.length;){const g=i.indexOf(e,m);if(g===-1)break;const b=h===""||i.substring(Math.max(0,g-h.length),g).endsWith(h),P=p===""||i.substring(g+e.length,g+e.length+p.length).startsWith(p);if(b&&P){s=g;break}m=g+1}}if(s===-1&&(s=i.indexOf(e)),s===-1)return;let l=null,u=0;for(const h of t)if(s>=h.start&&s<h.end){l=h.node,u=s-h.start;break}if(l)try{const h=document.createRange();h.setStart(l,u),h.setEnd(l,u+e.length);const p=document.createElement("span");p.className="oo-highlight",p.dataset.annotationId=n.id,p.style.cssText=`
      background: ${n.color}40;
      border-bottom: 2px solid ${n.color};
      cursor: pointer;
      transition: background 0.15s;
    `,p.addEventListener("mouseenter",m=>{p.style.background=`${n.color}60`,Ul(n,m,p)}),p.addEventListener("mouseleave",m=>{p.style.background=`${n.color}40`,Ng()}),h.surroundContents(p)}catch(h){console.warn("[OpenOverlay] Failed to highlight annotation:",n.id,h)}}let pr=null,Vt=null,Gr=null,Kr=!1;function Ng(){Kr||(Gr&&clearTimeout(Gr),Gr=window.setTimeout(()=>{Cn()},150))}function to(){Gr&&(clearTimeout(Gr),Gr=null)}function Ul(n,e,t){var A,C,$,F;if(Ht)return;if(pr&&(Vt==null?void 0:Vt.id)===n.id){to();return}if(to(),Cn(),Kr=!1,!ht)return;Vt=n;const r=document.createElement("div");r.className="oo-popup";let i,o;if(t){const V=t.getBoundingClientRect();i=V.left,o=V.bottom+4}else i=e.clientX-100,o=e.clientY+10;i<10&&(i=10),i+320>window.innerWidth&&(i=window.innerWidth-330),o+200>window.innerHeight&&(o=t?t.getBoundingClientRect().top-200:e.clientY-200),r.style.left=`${i}px`,r.style.top=`${o}px`;const s=n.reactions.filter(V=>V.count>0),l=n.replies.length,u=ce(),h=u?n.authorId===u.uid:n.authorId==="local-user";r.innerHTML=`
    <div class="popup-quote">"${Tt(n.comment)}"</div>
    <div class="popup-author">— ${Tt(n.authorName)}</div>
    <div class="popup-footer">
      <div class="popup-reactions" id="popup-reactions">
        ${s.map(V=>`
          <div class="reaction ${V.userReacted?"active":""}" data-emoji="${V.emoji}">
            <span class="emoji">${V.emoji}</span>
            <span class="count">${V.count}</span>
          </div>
        `).join("")}
      </div>
      <div class="popup-actions">
        <button class="comment-btn" id="popup-comment-btn" title="Comments">
          💬 ${l>0?l:""}
        </button>
        <button class="add-reaction" id="popup-add-reaction" title="React">+</button>
        <button class="bookmark-btn ${qn.has(n.id)?"active":""}" id="popup-bookmark-btn" title="Bookmark">🔖</button>
        <button class="maximize-btn" title="Open in sidebar">⛶</button>
        ${h?'<button class="delete-btn" id="popup-delete-btn" title="Delete annotation">🗑️</button>':""}
      </div>
    </div>
    <div class="popup-reply-section" id="popup-reply-section">
      <div class="popup-reply-input">
        <input type="text" placeholder="Add a comment..." />
        <button>➤</button>
      </div>
      <div class="quick-emojis">
        ${eu.slice(0,6).map(V=>`
          <button class="quick-emoji" data-emoji="${V}">${V}</button>
        `).join("")}
      </div>
    </div>
  `,r.addEventListener("mouseenter",()=>{to()}),r.addEventListener("mouseleave",()=>{Ng()}),r.addEventListener("click",V=>{V.stopPropagation(),Kr=!0,to()}),(A=r.querySelector(".maximize-btn"))==null||A.addEventListener("click",V=>{V.stopPropagation(),Kr=!1,Cn(),MI(n)}),(C=r.querySelector("#popup-bookmark-btn"))==null||C.addEventListener("click",V=>{V.stopPropagation(),BI(n.id);const G=r.querySelector("#popup-bookmark-btn");G==null||G.classList.toggle("active",qn.has(n.id))}),($=r.querySelector("#popup-delete-btn"))==null||$.addEventListener("click",V=>{V.stopPropagation(),confirm("Delete this annotation and all its comments?")&&($g(n.id),Cn())});const p=r.querySelector("#popup-comment-btn"),m=r.querySelector("#popup-reply-section");p==null||p.addEventListener("click",V=>{if(V.stopPropagation(),m==null||m.classList.toggle("open"),m!=null&&m.classList.contains("open")){const G=r.querySelector(".popup-reply-input input");G==null||G.focus()}}),r.querySelectorAll(".reaction").forEach(V=>{V.addEventListener("click",G=>{G.stopPropagation();const z=V.dataset.emoji;if(!z)return;const K=n.reactions.find(E=>E.emoji===z);K&&(K.userReacted?(K.count--,K.userReacted=!1,K.count<=0&&(n.reactions=n.reactions.filter(E=>E.emoji!==z))):(K.count++,K.userReacted=!0),xt(),Ir(n,z),Cn(),Ul(n,G))})}),(F=r.querySelector("#popup-add-reaction"))==null||F.addEventListener("click",V=>{V.stopPropagation();const G=r.querySelector("#popup-reactions");Mg(r,n,G)}),r.querySelectorAll(".quick-emoji").forEach(V=>{V.addEventListener("click",G=>{G.stopPropagation();const z=V.dataset.emoji;if(!z)return;let K=n.reactions.find(E=>E.emoji===z);K?K.userReacted||(K.count++,K.userReacted=!0):n.reactions.push({emoji:z,count:1,userReacted:!0}),xt(),Ir(n,z),Cn(),Ul(n,G)})});const g=r.querySelector(".popup-reply-input input"),b=r.querySelector(".popup-reply-input button"),P=()=>{const V=g.value.trim();if(!V)return;const G=ce(),z={authorName:(G==null?void 0:G.displayName)||"You",text:V,createdAt:Date.now()};n.replies.push(z),xt(),Bg(n,z),g.value="";const K=r.querySelector("#popup-comment-btn");K&&(K.innerHTML=`💬 ${n.replies.length}`)};b==null||b.addEventListener("click",V=>{V.stopPropagation(),P()}),g==null||g.addEventListener("keypress",V=>{V.key==="Enter"&&(V.stopPropagation(),P())}),ht.appendChild(r),pr=r,setTimeout(()=>{document.addEventListener("click",Vg)},10)}function NI(n){return`
    ${n.reactions.map(e=>`
      <div class="reaction ${e.userReacted?"active":""}" data-emoji="${e.emoji}">
        <span class="emoji">${e.emoji}</span>
        <span class="count">${e.count}</span>
      </div>
    `).join("")}
    <div class="reaction add-reaction" id="popup-add-reaction">😀+</div>
  `}function DI(n,e){var r;const t=n.querySelector("#popup-reactions");t&&(t.querySelectorAll(".reaction:not(.add-reaction)").forEach(i=>{i.addEventListener("click",o=>{o.stopPropagation();const s=i.dataset.emoji;if(!s)return;const l=e.reactions.find(u=>u.emoji===s);l&&(l.userReacted?(l.count--,l.userReacted=!1,l.count<=0&&(e.reactions=e.reactions.filter(u=>u.emoji!==s))):(l.count++,l.userReacted=!0),xt(),Ir(e,s),Dg(n,e))})}),(r=t.querySelector("#popup-add-reaction"))==null||r.addEventListener("click",i=>{i.stopPropagation(),Mg(n,e,t)}))}function Dg(n,e){const t=n.querySelector("#popup-reactions");t&&(t.innerHTML=NI(e),DI(n,e))}let Yr=null;function Mg(n,e,t){ta();const r=document.createElement("div");r.className="oo-popup-emoji-picker",r.innerHTML=eu.map(i=>`
    <button class="emoji-btn" data-emoji="${i}">${i}</button>
  `).join(""),r.querySelectorAll(".emoji-btn").forEach(i=>{i.addEventListener("click",o=>{o.stopPropagation();const s=i.dataset.emoji;if(!s)return;let l=e.reactions.find(u=>u.emoji===s);l?l.userReacted||(l.count++,l.userReacted=!0):e.reactions.push({emoji:s,count:1,userReacted:!0}),xt(),Ir(e,s),Dg(n,e),ta()})}),t.appendChild(r),Yr=r,setTimeout(()=>{document.addEventListener("click",Lg)},10)}function Lg(n){Yr&&!Yr.contains(n.target)&&ta()}function ta(){document.removeEventListener("click",Lg),Yr&&(Yr.remove(),Yr=null)}function Vg(n){Kr&&pr&&!pr.contains(n.target)&&Cn()}function Cn(){to(),document.removeEventListener("click",Vg),ta(),pr&&(pr.remove(),pr=null),Vt=null,Kr=!1}let Ht=null;function MI(n){var h,p,m;if(Cn(),Cs(),!ht)return;const e=document.createElement("div");e.className="oo-comment-panel open",e.style.pointerEvents="auto";const t=Bl(n.createdAt),r=ce(),i=r?n.authorId===r.uid:n.authorId==="local-user";e.innerHTML=`
    <div class="header">
      <h3>Annotation</h3>
      <button class="close-btn">&times;</button>
    </div>
    <div class="highlighted-text">
      <blockquote>"${Tt(n.text)}"</blockquote>
    </div>
    <div class="main-comment">
      <div class="author-info">
        <div class="avatar">${n.authorName.charAt(0).toUpperCase()}</div>
        <div>
          <div class="author-name">${Tt(n.authorName)}</div>
          <div class="timestamp">${t}</div>
        </div>
      </div>
      <div class="comment-text">${Tt(n.comment)}</div>
      <div class="reactions" id="reactions-container">
        ${n.reactions.map(g=>`
          <div class="reaction ${g.userReacted?"active":""}" data-emoji="${g.emoji}">
            <span class="emoji">${g.emoji}</span>
            <span class="count">${g.count}</span>
          </div>
        `).join("")}
        <div class="reaction add-reaction" id="add-reaction-btn">😀+</div>
      </div>
      ${i?'<button class="delete-btn" id="panel-delete-btn">🗑️ Delete Annotation</button>':""}
    </div>
    <div class="replies-section">
      ${n.replies.map(g=>`
        <div class="reply">
          <div class="author-info">
            <div class="avatar">${g.authorName.charAt(0).toUpperCase()}</div>
            <div>
              <div class="author-name">${Tt(g.authorName)}</div>
              <div class="timestamp">${Bl(g.createdAt)}</div>
            </div>
          </div>
          <div class="comment-text">${Tt(g.text)}</div>
        </div>
      `).join("")}
    </div>
    <div class="reply-input">
      <input type="text" placeholder="Add a reply..." />
      <button>➤</button>
    </div>
  `,e.addEventListener("click",g=>{g.stopPropagation()}),(h=e.querySelector(".close-btn"))==null||h.addEventListener("click",g=>{g.stopPropagation(),Cs()}),(p=e.querySelector("#panel-delete-btn"))==null||p.addEventListener("click",g=>{g.stopPropagation(),confirm("Delete this annotation and all its comments?")&&($g(n.id),Cs())});const o=e.querySelector(".reply-input input"),s=e.querySelector(".reply-input button"),l=()=>{const g=o.value.trim();if(!g)return;const b=ce(),P=(b==null?void 0:b.displayName)||"You",A={authorName:P,text:g,createdAt:Date.now()};n.replies.push(A),xt(),Bg(n,A);const C=e.querySelector(".replies-section");if(C){const $=`
        <div class="reply">
          <div class="author-info">
            <div class="avatar">${P.charAt(0).toUpperCase()}</div>
            <div>
              <div class="author-name">${Tt(P)}</div>
              <div class="timestamp">just now</div>
            </div>
          </div>
          <div class="comment-text">${Tt(g)}</div>
        </div>
      `;C.insertAdjacentHTML("beforeend",$)}o.value="",o.focus()};s==null||s.addEventListener("click",g=>{g.stopPropagation(),l()}),o==null||o.addEventListener("keypress",g=>{g.key==="Enter"&&(g.stopPropagation(),l())});const u=e.querySelector("#reactions-container");e.querySelectorAll(".reaction:not(.add-reaction)").forEach(g=>{g.addEventListener("click",b=>{b.stopPropagation();const P=g.dataset.emoji;if(!P)return;const A=n.reactions.find(C=>C.emoji===P);A&&(A.userReacted?(A.count--,A.userReacted=!1,A.count<=0&&(n.reactions=n.reactions.filter(C=>C.emoji!==P))):(A.count++,A.userReacted=!0),xt(),Ir(n,P),nu(n,u))})}),(m=e.querySelector("#add-reaction-btn"))==null||m.addEventListener("click",g=>{g.stopPropagation(),Fg(n,g.target,u)}),ht.appendChild(e),Ht=e,cr=n,setTimeout(()=>o==null?void 0:o.focus(),100),setTimeout(()=>{document.addEventListener("click",qg)},50)}let Qr=null;function Fg(n,e,t){ql();const r=document.createElement("div");r.className="oo-emoji-picker",e.getBoundingClientRect(),r.style.bottom="40px",r.style.left="0",r.innerHTML=eu.map(i=>`
    <button class="emoji-btn" data-emoji="${i}">${i}</button>
  `).join(""),r.querySelectorAll(".emoji-btn").forEach(i=>{i.addEventListener("click",o=>{o.stopPropagation();const s=i.dataset.emoji;if(!s)return;let l=n.reactions.find(u=>u.emoji===s);l?l.userReacted||(l.count++,l.userReacted=!0):n.reactions.push({emoji:s,count:1,userReacted:!0}),xt(),Ir(n,s),nu(n,t),ql()})}),t.style.position="relative",t.appendChild(r),Qr=r,setTimeout(()=>{document.addEventListener("click",Ug)},10)}function Ug(n){Qr&&!Qr.contains(n.target)&&ql()}function ql(){document.removeEventListener("click",Ug),Qr&&(Qr.remove(),Qr=null)}function nu(n,e){var t;e&&(e.innerHTML=`
    ${n.reactions.map(r=>`
      <div class="reaction ${r.userReacted?"active":""}" data-emoji="${r.emoji}">
        <span class="emoji">${r.emoji}</span>
        <span class="count">${r.count}</span>
      </div>
    `).join("")}
    <div class="reaction add-reaction" id="add-reaction-btn">😀+</div>
  `,e.querySelectorAll(".reaction:not(.add-reaction)").forEach(r=>{r.addEventListener("click",i=>{i.stopPropagation();const o=r.dataset.emoji;if(!o)return;const s=n.reactions.find(l=>l.emoji===o);s&&(s.userReacted?(s.count--,s.userReacted=!1,s.count<=0&&(n.reactions=n.reactions.filter(l=>l.emoji!==o))):(s.count++,s.userReacted=!0),xt(),Ir(n,o),nu(n,e))})}),(t=e.querySelector("#add-reaction-btn"))==null||t.addEventListener("click",r=>{r.stopPropagation(),Fg(n,r.target,e)}))}function qg(n){Ht&&!Ht.contains(n.target)&&Cs()}function Cs(){document.removeEventListener("click",qg),Ht&&(Ht.remove(),Ht=null),cr=null}function Tt(n){const e=document.createElement("div");return e.textContent=n,e.innerHTML}function Bl(n){const e=Math.floor((Date.now()-n)/1e3);return e<60?"just now":e<3600?`${Math.floor(e/60)}m ago`:e<86400?`${Math.floor(e/3600)}h ago`:e<604800?`${Math.floor(e/86400)}d ago`:new Date(n).toLocaleDateString()}function xt(){const n=Xn();localStorage.setItem(`oo_annotations_${n}`,JSON.stringify(ze)),console.log("[OpenOverlay] Saved",ze.length,"annotations locally")}async function LI(n){if(!kr()){console.log("[OpenOverlay] Firestore not available, skipping cloud save");return}const e=ce(),t=Xn();console.log("[OpenOverlay] Saving annotation to cloud:",n.id,"pageKey:",t);const r={id:n.id,pageKey:t,text:n.text,contextBefore:n.contextBefore||"",contextAfter:n.contextAfter||"",anchorSelector:n.anchorSelector,anchorOffset:n.anchorOffset,focusSelector:n.focusSelector,focusOffset:n.focusOffset,comment:n.comment,color:n.color,authorId:(e==null?void 0:e.uid)||n.authorId,authorName:(e==null?void 0:e.displayName)||n.authorName,createdAt:n.createdAt,reactions:n.reactions.map(i=>({emoji:i.emoji,count:i.count,users:i.userReacted&&e?[e.uid]:[]})),replies:n.replies.map(i=>({authorId:"",authorName:i.authorName,text:i.text,createdAt:i.createdAt}))};await aI(t,r)}async function Ir(n,e){if(!kr())return;const t=ce();if(!t)return;const r=Xn();await hI(r,n.id,e,t.uid)}async function Bg(n,e){if(!kr())return;const t=ce(),r=Xn();await uI(r,n.id,{authorId:(t==null?void 0:t.uid)||"",authorName:(t==null?void 0:t.displayName)||e.authorName,text:e.text,createdAt:e.createdAt})}function VI(){const n=Xn(),e=localStorage.getItem(`oo_annotations_${n}`);if(e)try{ze=JSON.parse(e),console.log("[OpenOverlay] Loaded",ze.length,"annotations from localStorage")}catch{console.warn("[OpenOverlay] Failed to load annotations"),ze=[]}FI()}async function FI(){if(!kr()){console.log("[OpenOverlay] Firestore not available, skipping real-time sync");return}const n=Xn();if(console.log("[OpenOverlay] Setting up real-time sync for page:",n),!cI(n,t=>{Md(t)})){console.log("[OpenOverlay] Real-time subscription failed, trying one-time fetch");const t=await kg(n);Md(t)}}function Md(n){const e=ce();if(console.log("[OpenOverlay] Processing",n.length,"cloud annotations"),n.length===0){console.log("[OpenOverlay] No cloud annotations found");return}const t=new Map;for(const i of ze)t.set(i.id,i);for(const i of n){const o=t.get(i.id),s={id:i.id,text:i.text,contextBefore:i.contextBefore||"",contextAfter:i.contextAfter||"",anchorSelector:i.anchorSelector,anchorOffset:i.anchorOffset,focusSelector:i.focusSelector,focusOffset:i.focusOffset,comment:i.comment,color:i.color,authorId:i.authorId,authorName:i.authorName,createdAt:i.createdAt,reactions:(i.reactions||[]).map(l=>({emoji:l.emoji,count:l.count,userReacted:e?l.users.includes(e.uid):!1})),replies:(i.replies||[]).map(l=>({authorName:l.authorName,text:l.text,createdAt:l.createdAt}))};(!o||i.createdAt>=o.createdAt)&&t.set(i.id,s)}ze=Array.from(t.values()),console.log("[OpenOverlay] Merged to",ze.length,"total annotations");const r=Xn();localStorage.setItem(`oo_annotations_${r}`,JSON.stringify(ze)),tu(),Aa(),UI()}function UI(){if(Vt){const n=ze.find(e=>e.id===(Vt==null?void 0:Vt.id));n&&(Vt=n)}if(Ht&&cr){const n=ze.find(e=>e.id===(cr==null?void 0:cr.id));n&&qI(n)}}function qI(n){if(!Ht||!ht)return;const e=Ht.querySelector(".replies-section");e&&(e.innerHTML=n.replies.map(t=>`
    <div class="reply">
      <div class="author-info">
        <div class="avatar">${t.authorName.charAt(0).toUpperCase()}</div>
        <div>
          <div class="author-name">${Tt(t.authorName)}</div>
          <div class="timestamp">${Bl(t.createdAt)}</div>
        </div>
      </div>
      <div class="comment-text">${Tt(t.text)}</div>
    </div>
  `).join(""),cr=n,console.log("[OpenOverlay] Comment panel refreshed with",n.replies.length,"replies"))}async function $g(n){const e=ze.find(i=>i.id===n);if(!e)return;const t=ce();if(!(t?e.authorId===t.uid:e.authorId==="local-user")){console.warn("[OpenOverlay] Cannot delete: not the author");return}if(ze=ze.filter(i=>i.id!==n),xt(),kr()){const i=Xn();await lI(i,n)}qn.has(n)&&(qn.delete(n),jg(n)),tu(),Aa(),console.log("[OpenOverlay] Annotation deleted:",n)}function BI(n){if(qn.has(n))qn.delete(n),jg(n),console.log("[OpenOverlay] Removed bookmark");else{qn.add(n);const e=ze.find(t=>t.id===n);e&&($I(e),console.log("[OpenOverlay] Added bookmark"))}}function $I(n){const e=Sa();e.some(t=>t.id===n.id)||(e.push({id:n.id,pageUrl:window.location.href,pageTitle:document.title,text:n.text,comment:n.comment,authorName:n.authorName,bookmarkedAt:Date.now()}),localStorage.setItem("oo_bookmarks",JSON.stringify(e)))}function jg(n){const e=Sa().filter(t=>t.id!==n);localStorage.setItem("oo_bookmarks",JSON.stringify(e))}function Sa(){try{return JSON.parse(localStorage.getItem("oo_bookmarks")||"[]")}catch{return[]}}function jI(){const n=Sa();qn=new Set(n.map(e=>e.id))}function Xn(){return btoa(window.location.href).slice(0,32)}let zi=null,R=null,ps=!1,tn="none",zg="solid",Wg="normal",Hg="none",no=!1,Jr=!1,De="normal",xa="",lo="play",Ld="spawn",$l=!1,qt=!1;const zI=["#ff3366","#ff6b35","#f59e0b","#22c55e","#06b6d4","#3b82f6","#8b5cf6","#ec4899","#ef4444","#000000","#ffffff","#6b7280"],WI=[{id:"solid",label:"━",title:"Solid"},{id:"spray",label:"░",title:"Spray"},{id:"dots",label:"•••",title:"Dots"},{id:"square",label:"▬",title:"Square"},{id:"rainbow",label:"🌈",title:"Rainbow"},{id:"glow",label:"✦",title:"Glow"}],HI=[{id:"normal",label:"A",title:"Normal"},{id:"rainbow",label:"🌈",title:"Rainbow"},{id:"aged",label:"🏚️",title:"Aged"}],GI=[{id:"none",label:"✏️",title:"Freehand"},{id:"line",label:"╱",title:"Line"},{id:"rectangle",label:"▢",title:"Rectangle"},{id:"circle",label:"○",title:"Circle"},{id:"triangle",label:"△",title:"Triangle"},{id:"star",label:"☆",title:"Star"}],KI=`
  * {
    box-sizing: border-box;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  }

  .fab-container {
    all: initial;
    position: fixed !important;
    right: 18px !important;
    bottom: 18px !important;
    z-index: 2147483647 !important;
    display: flex !important;
    flex-direction: column-reverse !important;
    align-items: center !important;
    gap: 8px !important;
    pointer-events: auto !important;
    touch-action: none !important;
    visibility: visible !important;
    opacity: 1 !important;
    transform: none !important;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif !important;
  }

  .fab-container.dragging {
    opacity: 0.8;
  }

  .fab-container.dragging .fab {
    cursor: grabbing;
  }

  .fab {
    all: initial;
    width: 56px !important;
    height: 56px !important;
    min-width: 56px !important;
    min-height: 56px !important;
    border-radius: 50% !important;
    border: none !important;
    background: rgba(255, 255, 255, 0.95) !important;
    color: #222 !important;
    font-size: 20px !important;
    cursor: pointer !important;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15) !important;
    transition: transform 0.15s, background 0.15s !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    visibility: visible !important;
    opacity: 1 !important;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif !important;
  }

  .fab:hover {
    transform: scale(1.05);
  }

  .fab.open {
    background: #22c55e;
    color: white;
  }

  .mini {
    width: 44px;
    height: 44px;
    border-radius: 50%;
    border: none;
    background: #fff;
    color: #222;
    font-size: 18px;
    cursor: pointer;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.12);
    transition: transform 0.15s, opacity 0.15s;
    opacity: 0;
    transform: scale(0.5);
    pointer-events: none;
  }

  .mini.show {
    opacity: 1;
    transform: scale(1);
    pointer-events: auto;
  }

  .mini:hover {
    transform: scale(1.1);
  }

  .mini.active {
    background: #22c55e;
    color: white;
  }

  .toolbar {
    position: fixed;
    right: 90px;
    bottom: 18px;
    background: #111;
    color: #fff;
    padding: 10px;
    border-radius: 10px;
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.3);
    display: none;
    flex-direction: column;
    gap: 8px;
    align-items: stretch;
    pointer-events: auto;
    z-index: 2147483647;
    max-width: 320px;
  }

  .toolbar.game-mode {
    flex-direction: column;
    align-items: stretch;
  }

  .toolbar-drag-handle {
    cursor: grab;
    padding: 2px 8px;
    color: #666;
    font-size: 12px;
    user-select: none;
    text-align: center;
  }

  .toolbar-drag-handle:hover {
    color: #999;
  }

  .toolbar-drag-handle:active {
    cursor: grabbing;
  }

  .toolbar.game-mode .toolbar-drag-handle {
    align-self: center;
    margin-bottom: -4px;
  }

  .toolbar.show {
    display: flex;
  }

  .toolbar-row {
    display: flex;
    align-items: center;
    gap: 6px;
    flex-wrap: wrap;
  }

  .toolbar-section {
    display: flex;
    align-items: center;
    gap: 4px;
  }

  .toolbar-divider {
    display: none;
  }

  .toolbar label {
    font-size: 11px;
    color: #888;
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }

  .toolbar input[type="color"] {
    width: 24px;
    height: 24px;
    border: 2px solid #333;
    border-radius: 50%;
    cursor: pointer;
    padding: 0;
    background: none;
    flex-shrink: 0;
  }

  .toolbar input[type="color"]::-webkit-color-swatch-wrapper {
    padding: 0;
  }

  .toolbar input[type="color"]::-webkit-color-swatch {
    border: none;
    border-radius: 50%;
  }

  .toolbar input[type="range"] {
    height: 6px;
    -webkit-appearance: none;
    background: #333;
    border-radius: 3px;
  }

  .toolbar input[type="range"]::-webkit-slider-thumb {
    -webkit-appearance: none;
    width: 18px;
    height: 18px;
    background: #fff;
    border-radius: 50%;
    cursor: pointer;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
  }

  .quick-colors {
    display: grid;
    grid-template-columns: repeat(4, 14px);
    gap: 2px;
  }

  .quick-color {
    width: 14px;
    height: 14px;
    border-radius: 50%;
    border: 2px solid transparent;
    cursor: pointer;
    transition: transform 0.1s;
  }

  .quick-color:hover {
    transform: scale(1.15);
  }

  .quick-color.active {
    border-color: #fff;
    box-shadow: 0 0 0 1px #000;
  }

  .quick-color[data-color="#ffffff"] {
    border-color: #ccc;
  }

  .quick-color[data-color="#000000"] {
    border-color: #333;
  }

  .toolbar.game-mode .quick-colors {
    grid-template-columns: repeat(4, 14px);
  }

  .brush-styles {
    display: flex;
    gap: 2px;
  }

  .brush-btn {
    width: 28px;
    height: 28px;
    border: none;
    background: #222;
    color: #aaa;
    border-radius: 6px;
    cursor: pointer;
    font-size: 14px;
    transition: background 0.1s;
  }

  .brush-btn:hover {
    background: #333;
  }

  .brush-btn.active {
    background: #22c55e;
    color: white;
  }

  .tool-btn {
    width: 32px;
    height: 32px;
    border: none;
    background: #222;
    color: #aaa;
    border-radius: 8px;
    cursor: pointer;
    font-size: 16px;
    transition: background 0.1s;
  }

  .tool-btn:hover {
    background: #333;
  }

  .tool-btn.active {
    background: #ef4444;
    color: white;
  }

  .shape-tools {
    display: flex;
    gap: 2px;
  }

  .shape-btn {
    width: 28px;
    height: 28px;
    border: none;
    background: #222;
    color: #aaa;
    border-radius: 6px;
    cursor: pointer;
    font-size: 14px;
    transition: background 0.1s;
  }

  .shape-btn:hover {
    background: #333;
  }

  .shape-btn.active {
    background: #8b5cf6;
    color: white;
  }

  .fill-btn {
    width: 28px;
    height: 28px;
    border: none;
    background: #222;
    color: #aaa;
    border-radius: 6px;
    cursor: pointer;
    font-size: 16px;
    margin-left: 4px;
  }

  .fill-btn:hover {
    background: #333;
  }

  .fill-btn.active {
    background: #f59e0b;
    color: white;
  }

  .toolbar button.action-btn {
    padding: 5px 10px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 11px;
    font-weight: 600;
    transition: background 0.1s;
  }

  .btn-undo {
    background: #333;
    color: #fff;
  }

  .btn-undo:hover {
    background: #444;
  }

  .btn-clear {
    background: #333;
    color: #fff;
  }

  .btn-clear:hover {
    background: #444;
  }

  .btn-save {
    background: #22c55e;
    color: white;
  }

  .btn-save:hover {
    background: #16a34a;
  }

  .btn-cancel {
    background: #333;
    color: white;
  }

  .btn-cancel:hover {
    background: #444;
  }

  .size-display {
    font-size: 11px;
    color: #888;
    min-width: 20px;
    text-align: center;
  }

  .opacity-display {
    font-size: 11px;
    color: #888;
    min-width: 28px;
    text-align: center;
  }

  .draw-controls, .text-controls {
    display: none;
    flex-direction: column;
    gap: 6px;
  }

  .draw-controls.active, .text-controls.active {
    display: flex;
  }

  .text-input {
    background: #222;
    border: 1px solid #333;
    border-radius: 6px;
    color: #fff;
    padding: 6px 10px;
    font-size: 13px;
    flex: 1;
    min-width: 100px;
    font-family: inherit;
  }

  .text-input:focus {
    outline: none;
    border-color: #22c55e;
  }

  .text-input::placeholder {
    color: #666;
  }

  .text-styles {
    display: flex;
    gap: 2px;
  }

  .text-style-btn {
    width: 32px;
    height: 32px;
    border: none;
    background: #222;
    color: #aaa;
    border-radius: 6px;
    cursor: pointer;
    font-size: 14px;
    transition: background 0.1s;
  }

  .text-style-btn:hover {
    background: #333;
  }

  .text-style-btn.active {
    background: #22c55e;
    color: white;
  }

  .place-hint {
    font-size: 11px;
    color: #666;
    font-style: italic;
  }

  .game-controls {
    display: none;
    flex-direction: column;
    gap: 8px;
  }

  .game-controls.active {
    display: flex;
  }

  .game-row {
    display: flex;
    align-items: center;
    gap: 6px;
    justify-content: center;
  }

  .game-actions {
    display: flex;
    gap: 4px;
    margin-left: auto;
  }

  .game-colors {
    display: flex;
    gap: 3px;
  }

  .toolbar.game-mode .drawing-only {
    display: none !important;
  }

  .toolbar.game-mode > .toolbar-row,
  .toolbar.game-mode > .toolbar-section,
  .toolbar.game-mode > .toolbar-divider {
    display: none !important;
  }

  .toolbar.game-mode > .toolbar-drag-handle,
  .toolbar.game-mode > .game-controls {
    display: flex !important;
  }

  .char-style-toggle {
    display: flex;
    background: #222;
    border-radius: 4px;
    padding: 2px;
  }

  .char-style-btn {
    padding: 3px 6px;
    border: none;
    background: transparent;
    border-radius: 3px;
    cursor: pointer;
    font-size: 14px;
    transition: background 0.1s;
  }

  .char-style-btn:hover {
    background: #333;
  }

  .char-style-btn.active {
    background: #22c55e;
  }

  .char-customize-select {
    background: #222;
    color: #fff;
    border: 1px solid #333;
    border-radius: 4px;
    padding: 3px 4px;
    font-size: 14px;
    cursor: pointer;
    min-width: 36px;
    text-align: center;
  }

  .char-customize-select:hover {
    border-color: #555;
  }

  .char-customize-select:focus {
    outline: none;
    border-color: #22c55e;
  }

  .screen-name-section {
    margin: 16px 0;
    padding: 12px;
    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
    border-radius: 10px;
    border: 2px solid #0f3460;
  }

  .screen-name-label {
    display: block;
    font-size: 13px;
    color: #e94560;
    margin-bottom: 8px;
    text-transform: uppercase;
    letter-spacing: 1px;
    font-weight: bold;
    text-align: center;
  }

  .screen-name-input {
    width: 100%;
    background: #0a0a15;
    color: #fff;
    border: 2px solid #e94560;
    border-radius: 8px;
    padding: 10px 14px;
    font-size: 18px;
    font-family: "Comic Sans MS", "Chalkboard SE", cursive;
    text-align: center;
    box-sizing: border-box;
  }

  .screen-name-input::placeholder {
    color: #666;
    font-style: italic;
  }

  .screen-name-input:focus {
    outline: none;
    border-color: #22c55e;
    background: #111;
    box-shadow: 0 0 10px rgba(233, 69, 96, 0.3);
  }

  .game-mode-toggle {
    display: flex;
    background: #222;
    border-radius: 6px;
    padding: 2px;
  }

  .game-mode-btn {
    padding: 4px 8px;
    border: none;
    background: transparent;
    color: #888;
    border-radius: 4px;
    cursor: pointer;
    font-size: 14px;
    transition: background 0.1s, color 0.1s;
  }

  .game-mode-btn:hover {
    color: #fff;
  }

  .game-mode-btn.active {
    background: #22c55e;
    color: white;
  }

  .build-tools-section {
    display: flex;
    align-items: center;
  }

  .game-tools {
    display: flex;
    gap: 2px;
  }

  .game-tool-btn {
    width: 28px;
    height: 28px;
    padding: 0;
    border: none;
    background: #222;
    color: #aaa;
    border-radius: 4px;
    cursor: pointer;
    font-size: 13px;
    transition: background 0.1s;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .game-tool-btn:hover {
    background: #333;
  }

  .game-tool-btn.active {
    background: #3b82f6;
    color: white;
  }

  .multiplayer-btn {
    padding: 4px 8px;
    border: none;
    background: #7c3aed;
    color: #fff;
    border-radius: 4px;
    cursor: pointer;
    font-size: 11px;
    font-weight: 600;
    transition: background 0.1s;
  }

  .multiplayer-btn:hover {
    background: #6d28d9;
  }

  .multiplayer-btn.active {
    background: #22c55e;
  }

  .mini.game-btn {
    background: #8b5cf6;
    color: white;
  }

  .mini.game-btn.active {
    background: #22c55e;
  }

  /* Profile button */
  .mini.profile-btn {
    padding: 0;
    overflow: hidden;
  }

  .mini.profile-btn img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    border-radius: 50%;
  }

  /* Profile modal */
  .profile-modal {
    position: fixed;
    bottom: 80px;
    right: 20px;
    width: 320px;
    max-height: calc(100vh - 100px);
    background: #111;
    border-radius: 16px;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
    display: none;
    flex-direction: column;
    overflow-y: auto;
    z-index: 2147483647;
    pointer-events: auto;
  }

  .profile-modal.show {
    display: flex;
  }

  .profile-close {
    position: absolute;
    top: 10px;
    right: 10px;
    width: 28px;
    height: 28px;
    border: none;
    background: #333;
    color: #fff;
    border-radius: 50%;
    font-size: 18px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 10;
  }

  .profile-close:hover {
    background: #444;
  }

  .profile-header {
    padding: 20px;
    display: flex;
    align-items: center;
    gap: 16px;
    border-bottom: 1px solid #333;
  }

  .profile-avatar {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    object-fit: cover;
    border: 2px solid #3b82f6;
  }

  .profile-info {
    flex: 1;
  }

  .profile-name {
    font-size: 18px;
    font-weight: bold;
    color: #fff;
    margin: 0 0 4px 0;
  }

  .profile-email {
    font-size: 12px;
    color: #888;
    margin: 0;
  }

  .profile-stats {
    display: flex;
    gap: 20px;
    padding: 16px 20px;
    border-bottom: 1px solid #333;
  }

  .profile-stat {
    text-align: center;
    cursor: pointer;
  }

  .profile-stat:hover {
    opacity: 0.8;
  }

  .profile-stat-value {
    font-size: 20px;
    font-weight: bold;
    color: #fff;
  }

  .profile-stat-label {
    font-size: 11px;
    color: #888;
    text-transform: uppercase;
  }

  .profile-bio {
    padding: 16px 20px;
    color: #ccc;
    font-size: 14px;
    border-bottom: 1px solid #333;
  }

  .profile-bio-empty {
    color: #666;
    font-style: italic;
  }

  .profile-actions {
    padding: 16px 20px;
    display: flex;
    gap: 10px;
  }

  .feedback-section {
    padding: 12px 20px;
    border-bottom: 1px solid #333;
    background: linear-gradient(135deg, rgba(34, 197, 94, 0.1) 0%, rgba(59, 130, 246, 0.1) 100%);
  }

  .feedback-header {
    color: #fff;
    font-size: 13px;
    font-weight: 600;
    margin-bottom: 10px;
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .beta-badge {
    background: linear-gradient(135deg, #22c55e, #3b82f6);
    color: white;
    font-size: 9px;
    font-weight: 700;
    padding: 2px 6px;
    border-radius: 4px;
    letter-spacing: 0.5px;
  }

  .feedback-form {
    display: flex;
    flex-direction: column;
    gap: 8px;
  }

  .feedback-select {
    background: #222;
    border: 1px solid #333;
    border-radius: 6px;
    color: #fff;
    padding: 8px 10px;
    font-size: 13px;
    cursor: pointer;
  }

  .feedback-select:focus {
    outline: none;
    border-color: #22c55e;
  }

  .feedback-textarea {
    background: #222;
    border: 1px solid #333;
    border-radius: 6px;
    color: #fff;
    padding: 8px 10px;
    font-size: 13px;
    resize: none;
    font-family: inherit;
  }

  .feedback-textarea:focus {
    outline: none;
    border-color: #22c55e;
  }

  .feedback-textarea::placeholder {
    color: #666;
  }

  .feedback-submit {
    background: #22c55e;
    color: white;
    border: none;
    border-radius: 6px;
    padding: 8px 16px;
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
    transition: background 0.2s;
  }

  .feedback-submit:hover {
    background: #16a34a;
  }

  .feedback-submit:disabled {
    background: #333;
    color: #666;
    cursor: not-allowed;
  }

  .feedback-success {
    color: #22c55e;
    font-size: 13px;
    text-align: center;
    padding: 10px;
  }

  .profile-settings {
    padding: 12px 20px;
    border-bottom: 1px solid #333;
  }

  .profile-settings-header {
    color: #888;
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 8px;
  }

  .profile-setting-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 8px 0;
  }

  .profile-setting-label {
    color: #ccc;
    font-size: 14px;
  }

  .profile-contributors {
    margin-top: 16px;
    padding-top: 12px;
    border-top: 1px solid #333;
  }

  .profile-contributors-header {
    color: #888;
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 8px;
  }

  .contributors-list {
    max-height: 150px;
    overflow-y: auto;
  }

  .no-contributors {
    color: #666;
    font-size: 13px;
    font-style: italic;
    padding: 8px 0;
  }

  .contributor-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 6px 0;
    gap: 10px;
  }

  .contributor-info {
    display: flex;
    align-items: center;
    gap: 8px;
    flex: 1;
    min-width: 0;
  }

  .contributor-avatar {
    width: 24px;
    height: 24px;
    border-radius: 50%;
    background: #333;
    object-fit: cover;
    flex-shrink: 0;
  }

  .contributor-name {
    color: #ddd;
    font-size: 13px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .contributor-toggle {
    flex-shrink: 0;
  }

  .contributor-actions {
    display: flex;
    align-items: center;
    gap: 8px;
    flex-shrink: 0;
  }

  .follow-btn {
    padding: 4px 10px;
    border-radius: 12px;
    border: none;
    font-size: 11px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s;
  }

  .follow-btn.follow {
    background: #3b82f6;
    color: white;
  }

  .follow-btn.follow:hover {
    background: #2563eb;
  }

  .follow-btn.following {
    background: #333;
    color: #aaa;
  }

  .follow-btn.following:hover {
    background: #ef4444;
    color: white;
  }

  .toggle-switch {
    position: relative;
    width: 44px;
    height: 24px;
    background: #333;
    border-radius: 12px;
    cursor: pointer;
    transition: background 0.2s;
  }

  .toggle-switch.active {
    background: #22c55e;
  }

  .toggle-switch::after {
    content: '';
    position: absolute;
    top: 2px;
    left: 2px;
    width: 20px;
    height: 20px;
    background: #fff;
    border-radius: 50%;
    transition: transform 0.2s;
  }

  .toggle-switch.active::after {
    transform: translateX(20px);
  }

  .toggle-switch.small {
    width: 32px;
    height: 18px;
    border-radius: 9px;
  }

  .toggle-switch.small::after {
    width: 14px;
    height: 14px;
  }

  .toggle-switch.small.active::after {
    transform: translateX(14px);
  }

  .profile-bookmarks {
    padding: 12px 20px;
    border-bottom: 1px solid #333;
    max-height: 200px;
    overflow-y: auto;
  }

  .profile-bookmarks-header {
    color: #888;
    font-size: 12px;
    text-transform: uppercase;
    margin-bottom: 10px;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .profile-bookmarks-count {
    background: #333;
    padding: 2px 8px;
    border-radius: 10px;
    font-size: 11px;
  }

  .bookmark-item {
    background: #222;
    border-radius: 8px;
    padding: 10px;
    margin-bottom: 8px;
    cursor: pointer;
    transition: background 0.15s;
  }

  .bookmark-item:hover {
    background: #333;
  }

  .bookmark-quote {
    color: #fff;
    font-size: 13px;
    margin-bottom: 4px;
    font-style: italic;
  }

  .bookmark-meta {
    color: #888;
    font-size: 11px;
  }

  .no-bookmarks {
    color: #666;
    font-size: 13px;
    font-style: italic;
    text-align: center;
    padding: 20px;
  }

  .profile-btn {
    flex: 1;
    padding: 10px 16px;
    border: none;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    transition: background 0.15s;
  }

  .profile-btn.primary {
    background: #3b82f6;
    color: white;
  }

  .profile-btn.primary:hover {
    background: #2563eb;
  }

  .profile-btn.secondary {
    background: #333;
    color: #fff;
  }

  .profile-btn.secondary:hover {
    background: #444;
  }

  .profile-btn.danger {
    background: #ef4444;
    color: white;
  }

  .profile-btn.danger:hover {
    background: #dc2626;
  }

  .login-prompt {
    padding: 40px 20px;
    text-align: center;
  }

  .login-prompt p {
    color: #888;
    margin: 0 0 20px 0;
  }

  .login-btn {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    padding: 12px 24px;
    background: #fff;
    color: #333;
    border: none;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
  }

  .login-btn:hover {
    background: #f0f0f0;
  }

  .login-btn img {
    width: 20px;
    height: 20px;
  }
`;function YI(){if(console.log("[OpenOverlay] initUI starting..."),!document.body){console.error("[OpenOverlay] No document.body!");return}zi=document.createElement("div"),zi.id="openoverlay-ui",zi.style.cssText=`
    all: initial;
    position: fixed !important;
    top: 0 !important;
    left: 0 !important;
    right: 0 !important;
    bottom: 0 !important;
    width: 100vw !important;
    height: 100vh !important;
    z-index: 2147483647 !important;
    pointer-events: none !important;
    overflow: visible !important;
    display: block !important;
    visibility: visible !important;
    opacity: 1 !important;
    transform: none !important;
    margin: 0 !important;
    padding: 0 !important;
    border: none !important;
    box-sizing: border-box !important;
  `,R=zi.attachShadow({mode:"open"});const n=document.createElement("style");n.textContent=KI,R.appendChild(n);const e=document.createElement("div");e.className="fab-container";const t=document.createElement("button");t.className="fab",t.textContent="•••",t.title="OpenOverlay",t.onclick=()=>{var A;qt&&(qt=!1,(A=R==null?void 0:R.querySelector("#oo-profile-modal"))==null||A.classList.remove("show")),r0()},e.appendChild(t);const r=document.createElement("button");r.className="mini",r.textContent="✏️",r.title="Draw",r.onclick=()=>cl("draw"),e.appendChild(r);const i=document.createElement("button");i.className="mini",i.textContent="T",i.title="Text",i.onclick=()=>cl("text"),e.appendChild(i);const o=document.createElement("button");o.className="mini game-btn",o.textContent="🎮",o.title="Game",o.onclick=()=>cl("game"),e.appendChild(o);const s=document.createElement("button");s.className="mini profile-btn",s.id="oo-profile-btn",s.textContent="⚙️",s.title="Settings & Profile",s.onclick=t0,e.appendChild(s),R.appendChild(e);let l=!1,u=0,h=0,p=18,m=18;const g=localStorage.getItem("oo_fab_position");if(g)try{const A=JSON.parse(g);e.style.right=A.right+"px",e.style.bottom=A.bottom+"px",p=A.right,m=A.bottom}catch{}t.addEventListener("pointerdown",A=>{if(A.shiftKey){A.preventDefault(),l=!0,u=A.clientX,h=A.clientY;const C=getComputedStyle(e);p=parseInt(C.right)||18,m=parseInt(C.bottom)||18,e.classList.add("dragging"),t.setPointerCapture(A.pointerId)}}),t.addEventListener("pointermove",A=>{if(!l)return;A.preventDefault();const C=u-A.clientX,$=h-A.clientY,F=Math.max(10,Math.min(window.innerWidth-70,p+C)),V=Math.max(10,Math.min(window.innerHeight-70,m+$));e.style.right=F+"px",e.style.bottom=V+"px"}),t.addEventListener("pointerup",A=>{if(l){l=!1,e.classList.remove("dragging"),t.releasePointerCapture(A.pointerId);const C=getComputedStyle(e);localStorage.setItem("oo_fab_position",JSON.stringify({right:parseInt(C.right)||18,bottom:parseInt(C.bottom)||18}))}});const b=document.createElement("div");b.className="profile-modal",b.id="oo-profile-modal",b.innerHTML=`
    <button class="profile-close" id="profile-close-btn">&times;</button>
    <div class="login-prompt" id="login-prompt">
      <p>Sign in to save your drawings and follow other users</p>
      <button class="login-btn" id="google-login-btn">
        <svg width="20" height="20" viewBox="0 0 24 24">
          <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
          <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
          <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
          <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
        </svg>
        Sign in with Google
      </button>
    </div>
    <div class="profile-content" id="profile-content" style="display: none;">
      <div class="profile-header">
        <img class="profile-avatar" id="profile-avatar" src="" alt="Profile">
        <div class="profile-info">
          <h3 class="profile-name" id="profile-name">User Name</h3>
          <p class="profile-email" id="profile-email">email@example.com</p>
        </div>
      </div>
      <div class="screen-name-section">
        <label class="screen-name-label">Your Game Name</label>
        <input type="text" class="screen-name-input" id="oo-screen-name" placeholder="Pick a nickname!" maxlength="12">
      </div>
      <div class="profile-stats">
        <div class="profile-stat" id="followers-stat">
          <div class="profile-stat-value" id="followers-count">0</div>
          <div class="profile-stat-label">Followers</div>
        </div>
        <div class="profile-stat" id="following-stat">
          <div class="profile-stat-value" id="following-count">0</div>
          <div class="profile-stat-label">Following</div>
        </div>
      </div>
      <div class="profile-bio" id="profile-bio">
        <span class="profile-bio-empty">No bio yet</span>
      </div>
      <div class="profile-settings">
        <div class="profile-settings-header">Drawing Visibility</div>
        <div class="profile-setting-row">
          <span class="profile-setting-label">Show all drawings</span>
          <div class="toggle-switch active" id="toggle-all-drawings" title="Master toggle - hide all drawings"></div>
        </div>
        <div class="profile-setting-row">
          <span class="profile-setting-label">My drawings</span>
          <div class="toggle-switch active" id="toggle-my-drawings" title="Show or hide your own drawings"></div>
        </div>
        <div class="profile-setting-row">
          <span class="profile-setting-label">Only people I follow</span>
          <div class="toggle-switch" id="toggle-following-only" title="Show only drawings from users you follow"></div>
        </div>
        <div class="profile-contributors" id="contributors-section">
          <div class="profile-contributors-header">Contributors on this page</div>
          <div id="contributors-list" class="contributors-list">
            <div class="no-contributors">No other contributors yet</div>
          </div>
        </div>
      </div>
      <div class="profile-bookmarks" id="profile-bookmarks">
        <div class="profile-bookmarks-header">
          Bookmarks <span class="profile-bookmarks-count" id="bookmarks-count">0</span>
        </div>
        <div id="bookmarks-list"></div>
      </div>
      <div class="feedback-section">
        <div class="feedback-header">
          <span class="beta-badge">BETA</span>
          Send Feedback
        </div>
        <div class="feedback-form" id="feedback-form">
          <select id="feedback-type" class="feedback-select">
            <option value="bug">🐛 Bug Report</option>
            <option value="feature">💡 Feature Request</option>
            <option value="other">💬 Other Feedback</option>
          </select>
          <textarea id="feedback-text" class="feedback-textarea" placeholder="Describe the issue or suggestion..." rows="3"></textarea>
          <button class="feedback-submit" id="feedback-submit">Send Feedback</button>
        </div>
        <div class="feedback-success" id="feedback-success" style="display:none;">
          ✓ Thanks for your feedback!
        </div>
      </div>
      <div class="profile-actions">
        <button class="profile-btn danger" id="signout-btn">Sign Out</button>
      </div>
    </div>
  `,R.appendChild(b);const P=document.createElement("div");P.className="toolbar",P.id="oo-toolbar",P.innerHTML=`
    <!-- DRAG HANDLE -->
    <div class="toolbar-drag-handle" id="oo-drag-handle" title="Drag to move">⠿</div>

    <!-- DRAW MODE CONTROLS -->
    <div class="draw-controls active" id="draw-controls">
      <!-- Row 1: Brushes + Tools -->
      <div class="toolbar-row">
        <div class="brush-styles" id="oo-brushes">
          ${WI.map(A=>`
            <button class="brush-btn ${A.id==="solid"?"active":""}"
                    data-brush="${A.id}" title="${A.title}">${A.label}</button>
          `).join("")}
        </div>
        <button class="tool-btn" id="oo-eraser" title="Eraser">🧹</button>
        <button class="tool-btn" id="oo-layer-bg" title="Background">⬇️</button>
        <button class="tool-btn" id="oo-layer-fg" title="Foreground">⬆️</button>
      </div>
      <!-- Row 2: Shapes -->
      <div class="toolbar-row">
        <div class="shape-tools" id="oo-shapes">
          ${GI.map(A=>`
            <button class="shape-btn ${A.id==="none"?"active":""}"
                    data-shape="${A.id}" title="${A.title}">${A.label}</button>
          `).join("")}
        </div>
        <button class="fill-btn" id="oo-fill-toggle" title="Toggle fill">◧</button>
      </div>
    </div>

    <!-- TEXT MODE CONTROLS -->
    <div class="text-controls" id="text-controls">
      <div class="toolbar-row">
        <input type="text" class="text-input" id="oo-text-input" placeholder="Type text...">
        <div class="text-styles" id="oo-text-styles">
          ${HI.map(A=>`
            <button class="text-style-btn ${A.id==="normal"?"active":""}"
                    data-style="${A.id}" title="${A.title}">${A.label}</button>
          `).join("")}
        </div>
        <button class="tool-btn" id="oo-text-layer-bg" title="Background (behind character)">⬇️</button>
        <button class="tool-btn" id="oo-text-layer-fg" title="Foreground (in front of character)">⬆️</button>
      </div>
      <span class="place-hint">Click page to place (default: regular layer)</span>
    </div>

    <!-- GAME MODE CONTROLS -->
    <div class="game-controls" id="game-controls">
      <!-- Row 1: Mode + Character + Multiplayer -->
      <div class="game-row">
        <div class="game-mode-toggle">
          <button class="game-mode-btn active" data-mode="play" data-playmode="explore" title="Explore">🚶</button>
          <button class="game-mode-btn" data-mode="play" data-playmode="race" title="Race">🏃</button>
          <button class="game-mode-btn" data-mode="build" title="Build">🔨</button>
        </div>
        <button class="multiplayer-btn" id="oo-multiplayer-setup" title="Setup for multiplayer (resize window)">👥 MP</button>
        <button class="multiplayer-btn" id="oo-tag-game" title="Start or join tag game">🏷️ Tag</button>
        <div class="char-style-toggle">
          <button class="char-style-btn active" id="oo-char-boy" title="Boy">👦</button>
          <button class="char-style-btn" id="oo-char-girl" title="Girl">👧</button>
        </div>
        <select class="char-customize-select" id="oo-hat-select" title="Hat">
          <option value="none">🎩</option>
          <option value="cap">🧢</option>
          <option value="tophat">🎩</option>
          <option value="crown">👑</option>
          <option value="beanie">🧶</option>
          <option value="party">🎉</option>
        </select>
        <select class="char-customize-select" id="oo-accessory-select" title="Face">
          <option value="none">😊</option>
          <option value="glasses">👓</option>
          <option value="sunglasses">🕶️</option>
          <option value="mustache">🥸</option>
          <option value="beard">🧔</option>
          <option value="mask">🦸</option>
        </select>
      </div>

      <!-- Row 2: Build Tools (hidden by default, shown when build mode selected) -->
      <div class="game-row build-tools-section" style="display: none;">
        <div class="game-tools" id="game-tools">
          <button class="game-tool-btn" data-tool="select" title="Select">✋</button>
          <button class="game-tool-btn active" data-tool="spawn" title="Spawn">👤</button>
          <button class="game-tool-btn" data-tool="start" title="Start">🏁</button>
          <button class="game-tool-btn" data-tool="finish" title="Finish">🏆</button>
          <button class="game-tool-btn" data-tool="checkpoint" title="Checkpoint">🚩</button>
          <button class="game-tool-btn" data-tool="trampoline" title="Bounce">🔶</button>
          <button class="game-tool-btn" data-tool="speedBoost" title="Speed">💨</button>
          <button class="game-tool-btn" data-tool="highJump" title="Jump">🦘</button>
          <button class="game-tool-btn" data-tool="spike" title="Spike">🔺</button>
        </div>
      </div>

      <!-- Row 3: Colors + Actions -->
      <div class="game-row">
        <input type="color" id="oo-game-color" value="#ff3366" title="Color">
        <div class="quick-colors game-colors" id="oo-game-quick-colors"></div>
        <div class="game-actions">
          <button class="action-btn btn-undo" id="oo-game-undo" title="Undo">↩</button>
          <button class="action-btn btn-clear" id="oo-game-clear" title="Clear">🗑</button>
          <button class="action-btn btn-cancel" id="oo-game-cancel">✕</button>
          <button class="action-btn btn-save" id="oo-game-save">✓</button>
        </div>
      </div>
    </div>

    <!-- SHARED CONTROLS -->
    <!-- Color Row -->
    <div class="toolbar-row">
      <input type="color" id="oo-color" value="#ff3366" title="Color">
      <div class="quick-colors" id="oo-quick-colors">
        ${zI.map((A,C)=>`
          <div class="quick-color ${C===0?"active":""}"
               data-color="${A}"
               style="background: ${A}"
               title="${A}"></div>
        `).join("")}
      </div>
    </div>

    <!-- Size/Opacity Row (hidden in game mode) -->
    <div class="toolbar-row drawing-only">
      <label>Size</label>
      <input type="range" id="oo-size" min="1" max="150" value="24" style="width: 80px;">
      <span class="size-display" id="oo-size-display">24</span>
      <label style="margin-left: 8px;">Op</label>
      <input type="range" id="oo-opacity" min="10" max="100" value="100" style="width: 60px;">
      <span class="opacity-display" id="oo-opacity-display">100%</span>
    </div>

    <!-- Actions Row -->
    <div class="toolbar-row">
      <button class="action-btn btn-undo" id="oo-undo" title="Undo">↩</button>
      <button class="action-btn btn-clear" id="oo-clear" title="Clear All">🗑</button>
      <div style="flex: 1;"></div>
      <button class="action-btn btn-cancel" id="oo-cancel">Cancel</button>
      <button class="action-btn btn-save" id="oo-save">Save</button>
    </div>
  `,R.appendChild(P),QI(P),document.body.appendChild(zi),document.addEventListener("oo:hidetoolbar",()=>{const A=R==null?void 0:R.querySelector(".toolbar");A==null||A.classList.remove("show"),tn="none",lo="play";const C=R==null?void 0:R.querySelectorAll(".mini");C==null||C.forEach($=>$.classList.remove("active"))}),console.log("[OpenOverlay] UI initialized")}function QI(n){var _,xe,tt,Pr,_n,vt,bt,nt,ue,ke,ye,Je,Yt,Cr;n.querySelectorAll(".brush-btn").forEach(M=>{M.addEventListener("click",()=>{zg=M.dataset.brush||"solid",n.querySelectorAll(".brush-btn").forEach(te=>te.classList.remove("active")),M.classList.add("active"),it()})}),n.querySelectorAll(".text-style-btn").forEach(M=>{M.addEventListener("click",()=>{Wg=M.dataset.style||"normal",n.querySelectorAll(".text-style-btn").forEach(te=>te.classList.remove("active")),M.classList.add("active"),it()})}),n.querySelectorAll(".shape-btn").forEach(M=>{M.addEventListener("click",()=>{Hg=M.dataset.shape||"none",n.querySelectorAll(".shape-btn").forEach(te=>te.classList.remove("active")),M.classList.add("active"),it()})});const e=n.querySelector("#oo-fill-toggle");e==null||e.addEventListener("click",()=>{no=!no,e.classList.toggle("active",no),e.textContent=no?"◼":"◧",it()});const t=n.querySelector("#oo-text-input");t==null||t.addEventListener("input",()=>{xa=t.value,it()}),n.querySelectorAll(".quick-color").forEach(M=>{M.addEventListener("click",()=>{const B=M.dataset.color||"#ff3366",te=n.querySelector("#oo-color");te&&(te.value=B),n.querySelectorAll(".quick-color").forEach(rt=>rt.classList.remove("active")),M.classList.add("active"),it(),tn==="game"&&document.dispatchEvent(new CustomEvent("oo:playercolor",{detail:{color:B}}))})}),(_=n.querySelector("#oo-color"))==null||_.addEventListener("input",()=>{const M=n.querySelector("#oo-color");n.querySelectorAll(".quick-color").forEach(B=>B.classList.remove("active")),it(),tn==="game"&&M&&document.dispatchEvent(new CustomEvent("oo:playercolor",{detail:{color:M.value}}))});const r=n.querySelector("#oo-size"),i=n.querySelector("#oo-size-display");r==null||r.addEventListener("input",()=>{i&&(i.textContent=r.value),it()});const o=n.querySelector("#oo-opacity"),s=n.querySelector("#oo-opacity-display");o==null||o.addEventListener("input",()=>{s&&(s.textContent=o.value+"%"),it()}),(xe=n.querySelector("#oo-eraser"))==null||xe.addEventListener("click",()=>{var M;Jr=!Jr,(M=n.querySelector("#oo-eraser"))==null||M.classList.toggle("active",Jr),it()}),(tt=n.querySelector("#oo-layer-bg"))==null||tt.addEventListener("click",()=>{var M,B;De==="background"?De="normal":De="background",(M=n.querySelector("#oo-layer-bg"))==null||M.classList.toggle("active",De==="background"),(B=n.querySelector("#oo-layer-fg"))==null||B.classList.remove("active"),it()}),(Pr=n.querySelector("#oo-layer-fg"))==null||Pr.addEventListener("click",()=>{var M,B;De==="foreground"?De="normal":De="foreground",(M=n.querySelector("#oo-layer-fg"))==null||M.classList.toggle("active",De==="foreground"),(B=n.querySelector("#oo-layer-bg"))==null||B.classList.remove("active"),it()}),(_n=n.querySelector("#oo-text-layer-bg"))==null||_n.addEventListener("click",()=>{var M,B;De==="background"?De="normal":De="background",(M=n.querySelector("#oo-text-layer-bg"))==null||M.classList.toggle("active",De==="background"),(B=n.querySelector("#oo-text-layer-fg"))==null||B.classList.remove("active"),it()}),(vt=n.querySelector("#oo-text-layer-fg"))==null||vt.addEventListener("click",()=>{var M,B;De==="foreground"?De="normal":De="foreground",(M=n.querySelector("#oo-text-layer-fg"))==null||M.classList.toggle("active",De==="foreground"),(B=n.querySelector("#oo-text-layer-bg"))==null||B.classList.remove("active"),it()}),(bt=n.querySelector("#oo-undo"))==null||bt.addEventListener("click",()=>{document.dispatchEvent(new CustomEvent("oo:undo"))}),(nt=n.querySelector("#oo-clear"))==null||nt.addEventListener("click",()=>{document.dispatchEvent(new CustomEvent("oo:clear"))}),(ue=n.querySelector("#oo-cancel"))==null||ue.addEventListener("click",()=>{co("none"),document.dispatchEvent(new CustomEvent("oo:cancel"))}),(ke=n.querySelector("#oo-save"))==null||ke.addEventListener("click",()=>{co("none"),document.dispatchEvent(new CustomEvent("oo:save"))}),n.querySelectorAll(".game-mode-btn").forEach(M=>{M.addEventListener("click",()=>{const B=M.dataset.mode,te=M.dataset.playmode;lo=B,n.querySelectorAll(".game-mode-btn").forEach(Ii=>Ii.classList.remove("active")),M.classList.add("active");const rt=n.querySelector(".build-tools-section");rt&&(rt.style.display=B==="build"?"flex":"none"),document.dispatchEvent(new CustomEvent("oo:gamemode",{detail:{mode:B,tool:Ld,playmode:te||"explore"}}))})}),n.querySelectorAll(".game-tool-btn[data-tool]").forEach(M=>{M.addEventListener("click",()=>{const B=M.dataset.tool||"platform";Ld=B,n.querySelectorAll(".game-tool-btn[data-tool]").forEach(te=>te.classList.remove("active")),M.classList.add("active"),document.dispatchEvent(new CustomEvent("oo:gamemode",{detail:{mode:lo,tool:B}}))})});const l=n.querySelector("#oo-char-boy"),u=n.querySelector("#oo-char-girl");l==null||l.addEventListener("click",()=>{l.classList.add("active"),u==null||u.classList.remove("active"),document.dispatchEvent(new CustomEvent("oo:playerstyle",{detail:{isGirl:!1}})),localStorage.setItem("oo_player_girl","false")}),u==null||u.addEventListener("click",()=>{u.classList.add("active"),l==null||l.classList.remove("active"),document.dispatchEvent(new CustomEvent("oo:playerstyle",{detail:{isGirl:!0}})),localStorage.setItem("oo_player_girl","true")}),localStorage.getItem("oo_player_girl")==="true"&&(l==null||l.classList.remove("active"),u==null||u.classList.add("active"));const h=n.querySelector("#oo-hat-select");h==null||h.addEventListener("change",()=>{const M=h.value;document.dispatchEvent(new CustomEvent("oo:playerhat",{detail:{hat:M}}))});const p=localStorage.getItem("oo_player_hat");p&&h&&(h.value=p);const m=n.querySelector("#oo-accessory-select");m==null||m.addEventListener("change",()=>{const M=m.value;document.dispatchEvent(new CustomEvent("oo:playeraccessory",{detail:{accessory:M}}))});const g=localStorage.getItem("oo_player_accessory");g&&m&&(m.value=g);const b=n.querySelector("#oo-game-color");b==null||b.addEventListener("input",()=>{document.dispatchEvent(new CustomEvent("oo:playercolor",{detail:{color:b.value}}))});const P=n.querySelector("#oo-game-quick-colors");if(P){const M=["#ff3366","#22c55e","#3b82f6","#f59e0b","#8b5cf6","#fff","#000"];P.innerHTML=M.map((B,te)=>`
      <div class="quick-color ${te===0?"active":""}" data-color="${B}" style="background: ${B}" title="${B}"></div>
    `).join(""),P.querySelectorAll(".quick-color").forEach(B=>{B.addEventListener("click",()=>{const te=B.dataset.color||"#ff3366";b&&(b.value=te),P.querySelectorAll(".quick-color").forEach(rt=>rt.classList.remove("active")),B.classList.add("active"),document.dispatchEvent(new CustomEvent("oo:playercolor",{detail:{color:te}}))})})}(ye=n.querySelector("#oo-game-undo"))==null||ye.addEventListener("click",()=>{document.dispatchEvent(new CustomEvent("oo:undo"))}),(Je=n.querySelector("#oo-game-clear"))==null||Je.addEventListener("click",()=>{document.dispatchEvent(new CustomEvent("oo:clear"))}),(Yt=n.querySelector("#oo-game-cancel"))==null||Yt.addEventListener("click",()=>{co("none"),document.dispatchEvent(new CustomEvent("oo:cancel"))}),(Cr=n.querySelector("#oo-game-save"))==null||Cr.addEventListener("click",()=>{document.dispatchEvent(new CustomEvent("oo:save")),document.dispatchEvent(new CustomEvent("oo:gamemode",{detail:{mode:"play",playmode:"explore"}})),n.classList.remove("show"),tn="none"}),document.addEventListener("click",M=>{if($l){$l=!1;return}if(tn!=="game"||!n.classList.contains("show")||lo==="build")return;const B=M.composedPath(),te=R==null?void 0:R.host;te&&B.includes(te)||(document.dispatchEvent(new CustomEvent("oo:save")),document.dispatchEvent(new CustomEvent("oo:gamemode",{detail:{mode:"play",playmode:"explore"}})),n.classList.remove("show"),tn="none")}),document.addEventListener("click",M=>{var rt;if(!qt)return;const B=M.composedPath(),te=R==null?void 0:R.host;te&&B.includes(te)||(qt=!1,(rt=R==null?void 0:R.querySelector("#oo-profile-modal"))==null||rt.classList.remove("show"))});const A=n.querySelector("#oo-multiplayer-setup");A==null||A.addEventListener("click",async()=>{const M=A;M.textContent="⏳",M.disabled=!0;try{const B=await chrome.runtime.sendMessage({type:"SETUP_MULTIPLAYER"});B!=null&&B.success?(M.textContent="✓ Ready",M.classList.add("active"),setTimeout(()=>{M.textContent="👥 MP",M.disabled=!1},2e3)):(M.textContent="❌ Error",setTimeout(()=>{M.textContent="👥 MP",M.disabled=!1,M.classList.remove("active")},2e3))}catch(B){console.error("[OpenOverlay] Multiplayer setup error:",B),M.textContent="👥 MP",M.disabled=!1}});const C=n.querySelector("#oo-tag-game");let $=!1;C==null||C.addEventListener("click",async()=>{if($){document.dispatchEvent(new CustomEvent("oo:toggletag"));return}C.textContent="⏳",C.disabled=!0;try{const M=await chrome.runtime.sendMessage({type:"SETUP_MULTIPLAYER"});M!=null&&M.success?(console.log("[OpenOverlay UI] Multiplayer setup complete, starting tag game"),document.dispatchEvent(new CustomEvent("oo:toggletag"))):(console.error("[OpenOverlay UI] Multiplayer setup failed:",M==null?void 0:M.error),C.textContent="❌",setTimeout(()=>{C.textContent="🏷️ Tag",C.disabled=!1},1500))}catch(M){console.error("[OpenOverlay UI] Error setting up multiplayer:",M),C.textContent="❌",setTimeout(()=>{C.textContent="🏷️ Tag",C.disabled=!1},1500)}}),document.addEventListener("oo:tagstatechange",M=>{const{isTagMode:B,isIt:te}=M.detail;$=B,C.disabled=!1,B?te?(C.textContent="🏷️ IT!",C.classList.add("active")):(C.textContent="🏷️ Run!",C.classList.add("active")):(C.textContent="🏷️ Tag",C.classList.remove("active"))});const F=n.querySelector("#oo-drag-handle");let V=!1,G=0,z=0,K=0,E=0;F==null||F.addEventListener("pointerdown",M=>{const B=M;V=!0,G=B.clientX,z=B.clientY;const te=n.getBoundingClientRect();K=te.left,E=te.top,n.style.right="auto",n.style.bottom="auto",n.style.left=`${te.left}px`,n.style.top=`${te.top}px`,F.style.cursor="grabbing",B.preventDefault()}),document.addEventListener("pointermove",M=>{if(!V)return;const B=M.clientX-G,te=M.clientY-z;n.style.left=`${K+B}px`,n.style.top=`${E+te}px`}),document.addEventListener("pointerup",()=>{V&&(V=!1,F&&(F.style.cursor="grab"))});const v=R.querySelector("#google-login-btn"),w=R.querySelector("#signout-btn"),I=R.querySelector("#profile-close-btn");I==null||I.addEventListener("click",()=>{qt=!1;const M=R==null?void 0:R.querySelector("#oo-profile-modal");M==null||M.classList.remove("show")}),v==null||v.addEventListener("click",async()=>{try{await TI()}catch(M){console.error("[OpenOverlay] Login failed:",M)}}),w==null||w.addEventListener("click",async()=>{try{await EI(),qt=!1;const M=R==null?void 0:R.querySelector("#oo-profile-modal");M==null||M.classList.remove("show")}catch(M){console.error("[OpenOverlay] Sign out failed:",M)}});const T=R.querySelector("#oo-screen-name");if(T){const M=localStorage.getItem("oo_screen_name");M&&(T.value=M),T.addEventListener("change",()=>{const B=T.value.trim();localStorage.setItem("oo_screen_name",B),document.dispatchEvent(new CustomEvent("oo:screenname",{detail:{name:B}}))}),T.addEventListener("keydown",B=>{B.stopPropagation(),B.key==="Enter"&&T.blur()})}const S=R.querySelector("#feedback-submit");S==null||S.addEventListener("click",async()=>{var Ho;const M=R==null?void 0:R.querySelector("#feedback-type"),B=R==null?void 0:R.querySelector("#feedback-text"),te=R==null?void 0:R.querySelector("#feedback-form"),rt=R==null?void 0:R.querySelector("#feedback-success"),Ii=M==null?void 0:M.value,Ai=(Ho=B==null?void 0:B.value)==null?void 0:Ho.trim();if(!Ai){B==null||B.focus();return}const Rt=S;Rt.disabled=!0,Rt.textContent="Sending...",await vI(Ii,Ai)?(te.style.display="none",rt.style.display="block",setTimeout(()=>{B.value="",M.selectedIndex=0,te.style.display="block",rt.style.display="none",Rt.disabled=!1,Rt.textContent="Send Feedback"},3e3)):(Rt.disabled=!1,Rt.textContent="Send Feedback",alert("Failed to send feedback. Please try again."))}),JI(R),document.addEventListener("oo:contributors",M=>{ZI(R,M.detail.contributors)}),Rg(M=>{e0(M)})}let Me={showAll:!0,showMine:!0,showFollowing:!1,hiddenUsers:new Set};function JI(n){XI();const e=n.querySelector("#toggle-all-drawings"),t=n.querySelector("#toggle-my-drawings"),r=n.querySelector("#toggle-following-only");e==null||e.classList.toggle("active",Me.showAll),t==null||t.classList.toggle("active",Me.showMine),r==null||r.classList.toggle("active",Me.showFollowing),e==null||e.addEventListener("click",()=>{Me.showAll=!Me.showAll,e.classList.toggle("active",Me.showAll),document.dispatchEvent(new CustomEvent("oo:visibility:all",{detail:{show:Me.showAll}}))}),t==null||t.addEventListener("click",()=>{Me.showMine=!Me.showMine,t.classList.toggle("active",Me.showMine),document.dispatchEvent(new CustomEvent("oo:visibility:mine",{detail:{show:Me.showMine}}))}),r==null||r.addEventListener("click",()=>{Me.showFollowing=!Me.showFollowing,r.classList.toggle("active",Me.showFollowing),document.dispatchEvent(new CustomEvent("oo:visibility:following",{detail:{show:Me.showFollowing}}))})}function XI(){try{const n=localStorage.getItem("oo_visibility_prefs");if(n){const e=JSON.parse(n);Me={showAll:e.showAll??!0,showMine:e.showMine??!0,showFollowing:e.showFollowing??!1,hiddenUsers:new Set(e.hiddenUsers??[])}}}catch{}}async function ZI(n,e){const t=n.querySelector("#contributors-list");if(!t)return;const r=ce(),i=e.filter(s=>s.userId!==(r==null?void 0:r.uid));if(i.length===0){t.innerHTML='<div class="no-contributors">No other contributors yet</div>';return}const o=new Map;r&&await Promise.all(i.map(async s=>{const l=await nI(r.uid,s.userId);o.set(s.userId,l)})),t.innerHTML=i.map(s=>{var m;const l=!Me.hiddenUsers.has(s.userId),u=s.photoURL||"",h=((m=s.displayName)==null?void 0:m.charAt(0).toUpperCase())||"?",p=o.get(s.userId)||!1;return`
      <div class="contributor-row" data-user-id="${s.userId}">
        <div class="contributor-info">
          ${u?`<img src="${u}" class="contributor-avatar" alt="${s.displayName}">`:`<div class="contributor-avatar" style="display:flex;align-items:center;justify-content:center;color:#888;font-size:12px;">${h}</div>`}
          <span class="contributor-name">${qr(s.displayName)}</span>
        </div>
        <div class="contributor-actions">
          ${r?`
            <button class="follow-btn ${p?"following":"follow"}"
                    data-follow-user="${s.userId}"
                    data-user-name="${qr(s.displayName)}"
                    data-user-photo="${u}">
              ${p?"Following":"Follow"}
            </button>
          `:""}
          <div class="toggle-switch small ${l?"active":""}" data-toggle-user="${s.userId}" title="Show/hide this user's drawings"></div>
        </div>
      </div>
    `}).join(""),t.querySelectorAll("[data-toggle-user]").forEach(s=>{s.addEventListener("click",()=>{const l=s.getAttribute("data-toggle-user");if(!l)return;const u=s.classList.toggle("active");u?Me.hiddenUsers.delete(l):Me.hiddenUsers.add(l),document.dispatchEvent(new CustomEvent("oo:visibility:user",{detail:{userId:l,show:u}}))})}),t.querySelectorAll("[data-follow-user]").forEach(s=>{s.addEventListener("click",async()=>{const l=s.getAttribute("data-follow-user"),u=s.getAttribute("data-user-name")||"",h=s.getAttribute("data-user-photo")||"";if(!l||!r)return;const p=s,m=p.classList.contains("following");p.disabled=!0;try{m?(await tI(r.uid,l),p.classList.remove("following"),p.classList.add("follow"),p.textContent="Follow"):(await eI(r.uid,l,u,h),p.classList.remove("follow"),p.classList.add("following"),p.textContent="Following")}catch(g){console.error("[OpenOverlay] Follow action failed:",g),m?(p.classList.add("following"),p.classList.remove("follow"),p.textContent="Following"):(p.classList.add("follow"),p.classList.remove("following"),p.textContent="Follow")}finally{p.disabled=!1}})})}function e0(n){var i;const e=R==null?void 0:R.querySelector("#oo-profile-btn"),t=R==null?void 0:R.querySelector("#login-prompt"),r=R==null?void 0:R.querySelector("#profile-content");if(!(!e||!t||!r))if(n){n.photoURL?e.innerHTML=`<img src="${n.photoURL}" alt="Profile">`:e.textContent=((i=n.displayName)==null?void 0:i.charAt(0).toUpperCase())||"👤",t.style.display="none",r.style.display="block";const o=R==null?void 0:R.querySelector("#profile-avatar"),s=R==null?void 0:R.querySelector("#profile-name"),l=R==null?void 0:R.querySelector("#profile-email");o&&(o.src=n.photoURL||""),s&&(s.textContent=n.displayName||"Anonymous"),l&&(l.textContent=n.email||""),Sg(n.uid).then(u=>{if(u){const h=R==null?void 0:R.querySelector("#followers-count"),p=R==null?void 0:R.querySelector("#following-count"),m=R==null?void 0:R.querySelector("#profile-bio");h&&(h.textContent=String(u.followersCount||0)),p&&(p.textContent=String(u.followingCount||0)),m&&(m.innerHTML=u.bio?u.bio:'<span class="profile-bio-empty">No bio yet</span>')}})}else e.textContent="👤",t.style.display="block",r.style.display="none"}function t0(){qt=!qt;const n=R==null?void 0:R.querySelector("#oo-profile-modal");n==null||n.classList.toggle("show",qt),qt&&n0()}function n0(){const n=R==null?void 0:R.querySelector("#bookmarks-list"),e=R==null?void 0:R.querySelector("#bookmarks-count");if(!n)return;const t=Sa();if(e&&(e.textContent=String(t.length)),t.length===0){n.innerHTML='<div class="no-bookmarks">No bookmarks yet</div>';return}n.innerHTML=t.slice(0,10).map(r=>`
    <div class="bookmark-item" data-url="${qr(r.pageUrl)}">
      <div class="bookmark-quote">"${qr(Vd(r.comment,50))}"</div>
      <div class="bookmark-meta">${qr(Vd(r.pageTitle,30))} • ${qr(r.authorName)}</div>
    </div>
  `).join(""),n.querySelectorAll(".bookmark-item").forEach(r=>{r.addEventListener("click",()=>{const i=r.dataset.url;i&&window.open(i,"_blank")})})}function qr(n){const e=document.createElement("div");return e.textContent=n,e.innerHTML}function Vd(n,e){return n.length<=e?n:n.slice(0,e)+"..."}function it(){document.dispatchEvent(new CustomEvent("oo:settings",{detail:{color:hi(),size:di(),opacity:fi(),brush:ru(),textStyle:Kg(),eraser:Jr,layer:De}}))}function r0(){ps=!ps;const n=R==null?void 0:R.querySelector(".fab"),e=R==null?void 0:R.querySelectorAll(".mini");n==null||n.classList.toggle("open",ps),e==null||e.forEach(t=>t.classList.toggle("show",ps))}function cl(n){co(tn===n?"none":n)}function co(n){var h,p,m,g,b;const e=tn;tn=n;const t=R==null?void 0:R.querySelectorAll(".mini");t==null||t.forEach((P,A)=>{A===0&&P.classList.toggle("active",n==="draw"),A===1&&P.classList.toggle("active",n==="text"),A===2&&P.classList.toggle("active",n==="game")});const r=R==null?void 0:R.querySelector(".toolbar");r==null||r.classList.toggle("show",n!=="none"),r==null||r.classList.toggle("game-mode",n==="game");const i=R==null?void 0:R.querySelector("#draw-controls"),o=R==null?void 0:R.querySelector("#text-controls"),s=R==null?void 0:R.querySelector("#game-controls");i==null||i.classList.toggle("active",n==="draw"),o==null||o.classList.toggle("active",n==="text"),s==null||s.classList.toggle("active",n==="game");const l=R==null?void 0:R.querySelector("#oo-size"),u=R==null?void 0:R.querySelector("#oo-size-display");if(l&&u&&(n==="text"?(l.value="32",l.max="200",u.textContent="32"):n==="draw"&&(l.value="4",l.max="150",u.textContent="4")),n!=="none"&&(Jr=!1,(h=R==null?void 0:R.querySelector("#oo-eraser"))==null||h.classList.remove("active"),De="normal",(p=R==null?void 0:R.querySelector("#oo-layer-bg"))==null||p.classList.remove("active"),(m=R==null?void 0:R.querySelector("#oo-layer-fg"))==null||m.classList.remove("active"),(g=R==null?void 0:R.querySelector("#oo-text-layer-bg"))==null||g.classList.remove("active"),(b=R==null?void 0:R.querySelector("#oo-text-layer-fg"))==null||b.classList.remove("active")),n!=="text"){xa="";const P=R==null?void 0:R.querySelector("#oo-text-input");P&&(P.value="")}if(document.dispatchEvent(new CustomEvent("oo:mode",{detail:{mode:n}})),n==="game"){$l=!0,lo="play";const P=R==null?void 0:R.querySelectorAll(".game-mode-btn");P==null||P.forEach(C=>{const $=C.dataset.mode,F=C.dataset.playmode;C.classList.toggle("active",$==="play"&&F==="explore")});const A=R==null?void 0:R.querySelector(".build-tools-section");A&&(A.style.display="none"),document.dispatchEvent(new CustomEvent("oo:gamemode",{detail:{mode:"play",playmode:"explore"}}))}else e==="game"&&document.dispatchEvent(new CustomEvent("oo:gamemode",{detail:{mode:"none"}}));console.log("[OpenOverlay] Mode:",n)}function hi(){const n=R==null?void 0:R.querySelector("#oo-color");return(n==null?void 0:n.value)||"#ff3366"}function di(){const n=R==null?void 0:R.querySelector("#oo-size");return parseInt((n==null?void 0:n.value)||"4",10)}function fi(){const n=R==null?void 0:R.querySelector("#oo-opacity");return parseInt((n==null?void 0:n.value)||"100",10)/100}function ru(){return zg}function Gg(){return Jr}function jl(){return De}function Kg(){return Wg}function i0(){return Hg}function Yg(){return no}function o0(){return xa}function s0(){xa="";const n=R==null?void 0:R.querySelector("#oo-text-input");n&&(n.value="")}let se=null,L=null,Le=null,at=null,pt=null,ur=null,pi=!1,ft="none",iu=!1,ae=[],Fr=[],Ve={showAll:!0,showMine:!0,showFollowing:!1,hiddenUsers:new Set},Nn=null,gs=[],Xr=[],Qt=null,Zr="none",on=null,sn=null,Qg=!1,ul=0,lt=null,zl={x:0,y:0},Ft="none",Rs={x:0,y:0,size:0};const ms=10,Jg=30;function Xg(n){if(n===document.body||n===document.documentElement)return"body";if(n.id)return`#${CSS.escape(n.id)}`;const e=[];let t=n;for(;t&&t!==document.body&&t!==document.documentElement;){let r=t.tagName.toLowerCase();if(t.className&&typeof t.className=="string"){const o=t.className.trim().split(/\s+/).slice(0,2);o.length>0&&o[0]&&(r+="."+o.map(s=>CSS.escape(s)).join("."))}const i=t.parentElement;if(i){const o=Array.from(i.children).filter(s=>s.tagName===t.tagName);if(o.length>1){const s=o.indexOf(t)+1;r+=`:nth-of-type(${s})`}}if(e.unshift(r),e.length>=4)break;t=t.parentElement}return e.join(" > ")||"body"}function Zg(n,e){se&&(se.style.pointerEvents="none");const t=document.elementsFromPoint(n,e);se&&(se.style.pointerEvents=ft==="draw"?"auto":"none");for(const r of t){if(r.id==="oo-canvas"||r.id==="openoverlay-ui"||r===document.body||r===document.documentElement)continue;const i=r.getBoundingClientRect();if(!(i.width<20||i.height<20))return r}return document.body}function a0(){console.log("[OpenOverlay] initCanvas starting..."),se=document.createElement("canvas"),se.id="oo-canvas",se.style.cssText=`
    position: absolute;
    top: 0;
    left: 0;
    z-index: 2147483640;
    pointer-events: none;
  `,document.body.appendChild(se),L=se.getContext("2d"),Le=document.createElement("canvas"),at=Le.getContext("2d"),pt=document.createElement("canvas"),pt.id="oo-background-canvas",pt.style.cssText=`
    position: absolute;
    top: 0;
    left: 0;
    z-index: 2147483635;
    pointer-events: none;
  `,document.body.appendChild(pt),ur=pt.getContext("2d"),Wi(),window.addEventListener("resize",Wi);const n=/yahoo|facebook|twitter|instagram|tiktok|reddit/i.test(window.location.hostname),e=n?500:150;let t=null;window.addEventListener("scroll",()=>{t&&clearTimeout(t),t=window.setTimeout(()=>{pi||fe()},e)},{passive:!0});let r=null;new ResizeObserver(()=>{n?(r&&clearTimeout(r),r=window.setTimeout(Wi,500)):Wi()}).observe(document.documentElement);const o=n?2e3:500;let s=null,l=!1;new MutationObserver(()=>{l||(l=!0,s&&clearTimeout(s),s=window.setTimeout(()=>{l=!1,pi||(Wi(),fe())},o))}).observe(document.body,{childList:!0,subtree:!1}),n&&console.log("[OpenOverlay] Heavy site detected, using longer debounce"),document.addEventListener("oo:mode",h=>{ft=h.detail.mode,se&&(se.style.pointerEvents=ft==="draw"||ft==="text"?"auto":"none",se.style.cursor=ft==="draw"?"crosshair":ft==="text"?"text":"default")}),document.addEventListener("oo:save",S0),document.addEventListener("oo:cancel",x0),document.addEventListener("oo:undo",I0),document.addEventListener("oo:clear",A0),document.addEventListener("oo:visibility:all",h=>{Ve.showAll=h.detail.show,Hi(),fe(),console.log("[OpenOverlay] Visibility - show all:",h.detail.show)}),document.addEventListener("oo:visibility:mine",h=>{Ve.showMine=h.detail.show,Hi(),fe(),console.log("[OpenOverlay] Visibility - show mine:",h.detail.show)}),document.addEventListener("oo:visibility:following",h=>{Ve.showFollowing=h.detail.show,Hi(),fe(),console.log("[OpenOverlay] Visibility - following only:",h.detail.show)}),document.addEventListener("oo:visibility:user",h=>{const{userId:p,show:m}=h.detail;m?Ve.hiddenUsers.delete(p):Ve.hiddenUsers.add(p),Hi(),fe(),console.log("[OpenOverlay] Visibility - user",p,":",m?"shown":"hidden")}),document.addEventListener("oo:toggleothers",h=>{Ve.showAll=h.detail.show,Hi(),fe()}),v0(),document.addEventListener("oo:gamemode",h=>{iu=h.detail.mode==="build"||h.detail.mode==="play",(h.detail.mode==="play"||h.detail.mode==="build")&&fe()}),document.addEventListener("oo:settings",h=>{if(lt&&ft==="text"){const p=ae.find(m=>m.type==="text"&&m.id===lt);p&&(p.size=h.detail.size,p.color=h.detail.color,p.opacity=h.detail.opacity,p.style=h.detail.textStyle,fe())}}),se.addEventListener("pointerdown",l0),se.addEventListener("pointermove",h0),se.addEventListener("pointerup",qd),se.addEventListener("pointerleave",qd),ou(),k0(),console.log("[OpenOverlay] Canvas initialized")}let Fd=0,Ud=0;function Wi(){if(!se||!L)return;const n=Math.max(document.body.scrollWidth||0,document.body.offsetWidth||0,document.documentElement.scrollWidth||0,document.documentElement.offsetWidth||0,window.innerWidth||0),e=Math.max(document.body.scrollHeight||0,document.body.offsetHeight||0,document.documentElement.scrollHeight||0,document.documentElement.offsetHeight||0,window.innerHeight||0);if(n===Fd&&e===Ud)return;Fd=n,Ud=e;const t=window.devicePixelRatio||1;se.style.width=`${n}px`,se.style.height=`${e}px`,se.width=n*t,se.height=e*t,L.scale(t,t),Le&&at&&(Le.width=n*t,Le.height=e*t,at.setTransform(1,0,0,1,0,0),at.scale(t,t)),pt&&ur&&(pt.style.width=`${n}px`,pt.style.height=`${e}px`,pt.width=n*t,pt.height=e*t,ur.scale(t,t)),fe()}function l0(n){if(ft==="text"){u0(n);return}if(ft!=="draw")return;pi=!0;const e=Zg(n.clientX,n.clientY);if(e){const r=e.getBoundingClientRect();Qt={element:e,selector:Xg(e),bounds:r}}const t=i0();t!=="none"?(Zr=t,on={x:n.pageX,y:n.pageY},sn={x:n.pageX,y:n.pageY},Qg=Yg()):Xr=[{x:n.pageX,y:n.pageY}]}function na(n){if(!L)return null;const e=tm(n);if(!e)return null;L.font=`bold ${n.size||32}px Impact, Arial, sans-serif`;const r=L.measureText(n.text).width,i=n.size;return{x:e.x,y:e.y,width:r,height:i,centerX:e.x+r/2,centerY:e.y+i/2}}function em(n,e,t){const r=na(t);if(!r)return"none";const i=8,o=t.rotation||0,s=[{x:r.x+r.width+i,y:r.y+r.height+i,mode:"resize"}],l=r.centerX,u=r.y-i-Jg,h=Math.cos(o),p=Math.sin(o),m=l-r.centerX,g=u-r.centerY,b=r.centerX+m*h-g*p,P=r.centerY+m*p+g*h;if(Math.abs(n-b)<ms&&Math.abs(e-P)<ms)return"rotate";const A=s[0].x-r.centerX,C=s[0].y-r.centerY,$=r.centerX+A*h-C*p,F=r.centerY+A*p+C*h;return Math.abs(n-$)<ms&&Math.abs(e-F)<ms?"resize":"none"}function c0(n){if(!se||ft!=="text")return;if(lt){const t=ae.find(r=>r.type==="text"&&r.id===lt);if(t){const r=em(n.pageX,n.pageY,t);if(r==="resize"){se.style.cursor="nwse-resize";return}else if(r==="rotate"){se.style.cursor="crosshair";return}}}nm(n.pageX,n.pageY)?se.style.cursor="grab":se.style.cursor="default"}function u0(n){if(lt){const g=ae.find(b=>b.type==="text"&&b.id===lt);if(g){const b=em(n.pageX,n.pageY,g);if(b!=="none"){Ft=b,na(g)&&(Rs={x:n.pageX,y:n.pageY,size:g.size,rotation:g.rotation||0});return}}}const e=nm(n.pageX,n.pageY);if(e){lt=e.id,Ft="move";const g=tm(e);g&&(zl={x:n.pageX-g.x,y:n.pageY-g.y}),se&&(se.style.cursor="grabbing"),fe();return}const t=o0();if(!t||!t.trim()){lt&&(lt=null,Ft="none",fe());return}const r=Zg(n.clientX,n.clientY);if(!r)return;const i=r.getBoundingClientRect(),o=window.scrollX,s=window.scrollY,l=i.left+o,u=i.top+s,h=(n.pageX-l)/i.width,p=(n.pageY-u)/i.height,m={type:"text",id:d0(),anchorSelector:Xg(r),x:h,y:p,anchorBounds:{x:l,y:u,width:i.width,height:i.height},text:t,color:hi(),size:di(),opacity:fi(),style:Kg(),rotation:0,layer:jl()};ae.push(m),lt=m.id,s0(),fe()}function tm(n){let e=null;try{e=document.querySelector(n.anchorSelector)}catch{}if(!e)return null;const t=e.getBoundingClientRect(),r=window.scrollX,i=window.scrollY;return{x:t.left+r+n.x*t.width,y:t.top+i+n.y*t.height}}function h0(n){if(ft==="text"&&Ft==="none"&&c0(n),lt&&ft==="text"&&Ft!=="none"){const e=ae.find(t=>t.type==="text"&&t.id===lt);if(!e)return;if(Ft==="move"){let t=null;try{t=document.querySelector(e.anchorSelector)}catch{}if(t){const r=t.getBoundingClientRect(),i=window.scrollX,o=window.scrollY,s=n.pageX-zl.x,l=n.pageY-zl.y;e.x=(s-r.left-i)/r.width,e.y=(l-r.top-o)/r.height,fe()}}else if(Ft==="resize"){if(na(e)){const r=n.pageX-Rs.x,i=n.pageY-Rs.y,o=(r+i)/2,s=Math.max(12,Math.min(200,Rs.size+o));e.size=s,fe()}}else if(Ft==="rotate"){const t=na(e);if(t){const r=Math.atan2(n.pageY-t.centerY,n.pageX-t.centerX);e.rotation=r+Math.PI/2,fe()}}return}if(!(!pi||!L)){if(Zr!=="none"&&on){sn={x:n.pageX,y:n.pageY},fe(),p0();return}Xr.push({x:n.pageX,y:n.pageY}),fe(),f0(Xr,hi(),di(),fi(),ru(),Gg())}}function qd(){if(Ft!=="none"){Ft="none",se&&(se.style.cursor="grab");return}if(pi){if(pi=!1,Zr!=="none"&&on&&sn&&Qt){const n=Qt.element.getBoundingClientRect(),e=window.scrollX,t=window.scrollY,r=n.left+e,i=n.top+t,o=(on.x-r)/n.width,s=(on.y-i)/n.height,l=(sn.x-r)/n.width,u=(sn.y-i)/n.height;ae.push({type:"shape",id:"shape_"+Date.now(),anchorSelector:Qt.selector,x1:o,y1:s,x2:l,y2:u,anchorBounds:{x:r,y:i,width:n.width,height:n.height},shape:Zr,color:hi(),width:di(),opacity:fi(),filled:Qg,layer:jl()}),on=null,sn=null,Zr="none",Qt=null,fe();return}if(Xr.length>1&&Qt){const n=Qt.element.getBoundingClientRect(),e=window.scrollX,t=window.scrollY,r=n.left+e,i=n.top+t,o=Xr.map(s=>({x:(s.x-r)/n.width,y:(s.y-i)/n.height}));ae.push({type:"stroke",anchorSelector:Qt.selector,points:o,anchorBounds:{x:r,y:i,width:n.width,height:n.height},color:hi(),width:di(),opacity:fi(),brush:ru(),eraser:Gg(),layer:jl()})}Xr=[],Qt=null,fe()}}function nm(n,e){const t=window.scrollX,r=window.scrollY;for(let i=ae.length-1;i>=0;i--){const o=ae[i];if(o.type!=="text")continue;let s=null;try{s=document.querySelector(o.anchorSelector)}catch{}if(!s)continue;const l=s.getBoundingClientRect(),u={x:l.left+t,y:l.top+r,width:l.width,height:l.height},h=u.x+o.x*u.width,p=u.y+o.y*u.height,m=o.text.length*o.size*.6,g=o.size,b=10;if(n>=h-b&&n<=h+m+b&&e>=p-b&&e<=p+g+b)return o}return null}function d0(){return Math.random().toString(36).substr(2,9)}function f0(n,e,t,r,i,o){if(!(!L||n.length<2)){switch(L.save(),L.globalAlpha=r,o&&(L.globalCompositeOperation="destination-out",L.globalAlpha=1),i){case"spray":om(L,n,e,t);break;case"dots":sm(L,n,e,t);break;case"square":am(L,n,e,t);break;case"rainbow":g0(L,n,t);break;case"glow":lm(L,n,e,t);break;default:im(L,n,e,t)}L.restore()}}function Bd(n,e){if(!L||n.points.length<2)return;const t=n.points.map(r=>({x:e.x+r.x*e.width,y:e.y+r.y*e.height}));switch(L.save(),L.globalAlpha=n.opacity,n.eraser&&(L.globalCompositeOperation="destination-out",L.globalAlpha=1),n.brush){case"spray":om(L,t,n.color,n.width);break;case"dots":sm(L,t,n.color,n.width);break;case"square":am(L,t,n.color,n.width);break;case"rainbow":m0(L,t,n.width);break;case"glow":lm(L,t,n.color,n.width);break;default:im(L,t,n.color,n.width)}L.restore()}function p0(){if(!L||!on||!sn)return;const n=hi(),e=di(),t=fi(),r=Yg();L.save(),L.globalAlpha=t,L.strokeStyle=n,L.fillStyle=n,L.lineWidth=e,L.lineCap="round",L.lineJoin="round";const i=on.x,o=on.y,s=sn.x,l=sn.y;rm(L,Zr,i,o,s,l,r),L.restore()}function $d(n,e){if(!L)return;const t=e.x+n.x1*e.width,r=e.y+n.y1*e.height,i=e.x+n.x2*e.width,o=e.y+n.y2*e.height;L.save(),L.globalAlpha=n.opacity,L.strokeStyle=n.color,L.fillStyle=n.color,L.lineWidth=n.width,L.lineCap="round",L.lineJoin="round",rm(L,n.shape,t,r,i,o,n.filled),L.restore()}function rm(n,e,t,r,i,o,s){const l=Math.min(t,i),u=Math.min(r,o),h=Math.abs(i-t),p=Math.abs(o-r),m=(t+i)/2,g=(r+o)/2;switch(n.beginPath(),e){case"line":n.moveTo(t,r),n.lineTo(i,o),n.stroke();break;case"rectangle":s&&n.fillRect(l,u,h,p),n.strokeRect(l,u,h,p);break;case"circle":const b=Math.sqrt(h*h+p*p)/2;n.arc(m,g,b,0,Math.PI*2),s&&n.fill(),n.stroke();break;case"triangle":n.moveTo(m,u),n.lineTo(l,u+p),n.lineTo(l+h,u+p),n.closePath(),s&&n.fill(),n.stroke();break;case"star":const P=Math.min(h,p)/2,A=P*.4,C=5;for(let $=0;$<C*2;$++){const F=$%2===0?P:A,V=Math.PI/C*$-Math.PI/2,G=m+F*Math.cos(V),z=g+F*Math.sin(V);$===0?n.moveTo(G,z):n.lineTo(G,z)}n.closePath(),s&&n.fill(),n.stroke();break}}function im(n,e,t,r){n.beginPath(),n.strokeStyle=t,n.lineWidth=r,n.lineCap="round",n.lineJoin="round",n.moveTo(e[0].x,e[0].y);for(let i=1;i<e.length;i++)n.lineTo(e[i].x,e[i].y);n.stroke()}function om(n,e,t,r){n.fillStyle=t;const i=Math.max(10,r*2);for(const o of e)for(let s=0;s<i;s++){const l=Math.random()*Math.PI*2,u=Math.random()*r,h=o.x+Math.cos(l)*u,p=o.y+Math.sin(l)*u;n.beginPath(),n.arc(h,p,.5,0,Math.PI*2),n.fill()}}function sm(n,e,t,r){n.fillStyle=t;const i=Math.max(r*.8,4);let o=0;for(let s=0;s<e.length;s++){if(s===0){n.beginPath(),n.arc(e[0].x,e[0].y,r/2,0,Math.PI*2),n.fill();continue}const l=e[s].x-e[s-1].x,u=e[s].y-e[s-1].y,h=Math.sqrt(l*l+u*u);o+=h,o>=i&&(n.beginPath(),n.arc(e[s].x,e[s].y,r/2,0,Math.PI*2),n.fill(),o=0)}}function am(n,e,t,r){n.beginPath(),n.strokeStyle=t,n.lineWidth=r,n.lineCap="square",n.lineJoin="bevel",n.moveTo(e[0].x,e[0].y);for(let i=1;i<e.length;i++)n.lineTo(e[i].x,e[i].y);n.stroke()}function g0(n,e,t){n.lineWidth=t,n.lineCap="round",n.lineJoin="round";for(let r=1;r<e.length;r++){const i=`hsl(${ul}, 100%, 50%)`;n.beginPath(),n.strokeStyle=i,n.shadowColor=i,n.shadowBlur=t*.8,n.moveTo(e[r-1].x,e[r-1].y),n.lineTo(e[r].x,e[r].y),n.stroke(),ul=(ul+2)%360}n.shadowBlur=0}function m0(n,e,t){n.lineWidth=t,n.lineCap="round",n.lineJoin="round";let r=0;for(let i=1;i<e.length;i++){const o=`hsl(${r}, 100%, 50%)`;n.beginPath(),n.strokeStyle=o,n.shadowColor=o,n.shadowBlur=t*.8,n.moveTo(e[i-1].x,e[i-1].y),n.lineTo(e[i].x,e[i].y),n.stroke(),r=(r+2)%360}n.shadowBlur=0}function lm(n,e,t,r){const i=r*3;let o=1/0,s=1/0,l=-1/0,u=-1/0;for(const A of e)o=Math.min(o,A.x),s=Math.min(s,A.y),l=Math.max(l,A.x),u=Math.max(u,A.y);const h=Math.ceil(l-o+i*2),p=Math.ceil(u-s+i*2),m=document.createElement("canvas");m.width=h,m.height=p;const g=m.getContext("2d");if(!g)return;const b=o-i,P=s-i;g.strokeStyle=t,g.lineWidth=r,g.lineCap="round",g.lineJoin="round",g.shadowColor=t,g.shadowBlur=r*2.5,g.beginPath(),g.moveTo(e[0].x-b,e[0].y-P);for(let A=1;A<e.length;A++)g.lineTo(e[A].x-b,e[A].y-P);g.stroke(),g.shadowBlur=r,g.stroke(),n.drawImage(m,b,P)}function y0(){const{showAll:n,showMine:e,showFollowing:t,hiddenUsers:r}=Ve;if(!n)return[];const i=[];e&&i.push(...ae.map(o=>({item:o,isOtherUser:!1})));for(const o of Fr){const s=o._ownerId;s&&(r.has(s)||t&&!((Nn==null?void 0:Nn.has(s))??!1)||i.push({item:o,isOtherUser:!0}))}return i}function Hi(){const n={showAll:Ve.showAll,showMine:Ve.showMine,showFollowing:Ve.showFollowing,hiddenUsers:Array.from(Ve.hiddenUsers)};localStorage.setItem("oo_visibility_prefs",JSON.stringify(n))}function v0(){try{const n=localStorage.getItem("oo_visibility_prefs");if(n){const e=JSON.parse(n);Ve={showAll:e.showAll!==!1,showMine:e.showMine!==!1,showFollowing:e.showFollowing===!0,hiddenUsers:new Set(Array.isArray(e.hiddenUsers)?e.hiddenUsers:[])},console.log("[OpenOverlay] Loaded visibility prefs:",{showAll:Ve.showAll,showMine:Ve.showMine,showFollowing:Ve.showFollowing,hiddenUsers:Ve.hiddenUsers.size}),(!Ve.showAll||!Ve.showMine)&&(console.warn("[OpenOverlay] Visibility prefs seem corrupted, resetting to defaults"),Ve={showAll:!0,showMine:!0,showFollowing:!1,hiddenUsers:new Set},localStorage.removeItem("oo_visibility_prefs"))}}catch(n){console.warn("[OpenOverlay] Failed to load visibility prefs, using defaults:",n),localStorage.removeItem("oo_visibility_prefs")}}async function _0(){const n=ce();if(!n){Nn=new Set;return}try{const e=await rI(n.uid);Nn=new Set(e.map(t=>t.uid)),console.log("[OpenOverlay] Loaded following cache:",Nn.size,"users")}catch(e){console.warn("[OpenOverlay] Failed to load following cache:",e),Nn=new Set}}function fe(){if(!L||!se)return;L.clearRect(0,0,se.width,se.height),Le&&at&&at.clearRect(0,0,Le.width,Le.height),pt&&ur&&ur.clearRect(0,0,pt.width,pt.height);const n=window.scrollX,e=window.scrollY,t=(u,h,p=!1)=>{let m=null;try{m=document.querySelector(h.anchorSelector)}catch{}if(!m)return;const g=m.getBoundingClientRect();if(g.width===0||g.height===0)return;const b={x:g.left+n,y:g.top+e,width:g.width,height:g.height},P=L;L=u,h.type==="text"?(jd(h,b),!p&&h.id===lt&&u===P&&w0(h,b)):h.type==="shape"?$d(h,b):Bd(h,b),L=P},r=u=>{if(!at)return;let h=null;try{h=document.querySelector(u.anchorSelector)}catch{return}if(!h)return;const p=h.getBoundingClientRect();if(p.width===0||p.height===0)return;const m={x:p.left+n,y:p.top+e,width:p.width,height:p.height},g=L;L=at,u.type==="text"?jd(u,m):u.type==="shape"?$d(u,m):(u.type==="stroke"||!u.type)&&Bd(u,m),L=g},i=y0(),o=i.filter(({item:u})=>u.layer==="background"),s=i.filter(({item:u})=>{const h=u.layer;return!h||h==="normal"}),l=i.filter(({item:u})=>u.layer==="foreground");if(ur)for(const{item:u,isOtherUser:h}of o)t(ur,u,h);for(const{item:u,isOtherUser:h}of s)t(L,u,h),r(u);for(const{item:u,isOtherUser:h}of l)t(L,u,h)}function w0(n,e){if(!L)return;const t=e.x+n.x*e.width,r=e.y+n.y*e.height;L.font=`bold ${n.size||32}px Impact, Arial, sans-serif`;const o=L.measureText(n.text).width,s=n.size,l=8,u=t+o/2,h=r+s/2,p=n.rotation||0;L.save(),L.translate(u,h),L.rotate(p),L.translate(-u,-h),L.strokeStyle="#22c55e",L.lineWidth=2,L.setLineDash([5,3]),L.strokeRect(t-l,r-l,o+l*2,s+l*2),L.setLineDash([]),L.fillStyle="#22c55e";const m=8;L.fillRect(t+o+l-m/2,r+s+l-m/2,m,m);const g=r-l-Jg;L.beginPath(),L.arc(u,g,6,0,Math.PI*2),L.fill(),L.beginPath(),L.strokeStyle="#22c55e",L.setLineDash([]),L.lineWidth=2,L.moveTo(u,r-l),L.lineTo(u,g+6),L.stroke(),L.restore()}function jd(n,e){if(!L)return;const t=e.x+n.x*e.width,r=e.y+n.y*e.height;L.save(),L.globalAlpha=n.opacity||1,L.font=`bold ${n.size||32}px Impact, Arial, sans-serif`,L.textBaseline="top";const i=n.rotation||0;if(i!==0){const o=L.measureText(n.text),s=t+o.width/2,l=r+n.size/2;L.translate(s,l),L.rotate(i),L.translate(-s,-l)}switch(n.style){case"rainbow":T0(L,n.text,t,r,n.size);break;case"aged":E0(L,n.text,t,r,n.size,n.color);break;default:b0(L,n.text,t,r,n.color)}L.restore()}function b0(n,e,t,r,i){n.strokeStyle="#000",n.lineWidth=3,n.strokeText(e,t,r),n.fillStyle=i,n.fillText(e,t,r)}function T0(n,e,t,r,i){const o=n.measureText(e).width,s=n.createLinearGradient(t,r,t+o,r);s.addColorStop(0,"hsl(0, 100%, 50%)"),s.addColorStop(.17,"hsl(60, 100%, 50%)"),s.addColorStop(.33,"hsl(120, 100%, 50%)"),s.addColorStop(.5,"hsl(180, 100%, 50%)"),s.addColorStop(.67,"hsl(240, 100%, 50%)"),s.addColorStop(.83,"hsl(300, 100%, 50%)"),s.addColorStop(1,"hsl(360, 100%, 50%)");let l=0;for(let u=0;u<e.length;u++){const h=e[u],p=n.measureText(h).width,g=(l+p/2)/o*360;n.shadowColor=`hsl(${g}, 100%, 50%)`,n.shadowBlur=i*.2,n.shadowOffsetX=0,n.shadowOffsetY=0,n.fillStyle=s,n.fillText(h,t+l,r),l+=p}n.shadowBlur=0,n.strokeStyle="#000",n.lineWidth=3,n.strokeText(e,t,r),n.fillStyle=s,n.fillText(e,t,r)}function E0(n,e,t,r,i,o){n.shadowColor="rgba(0,0,0,0.5)",n.shadowBlur=4,n.shadowOffsetX=2,n.shadowOffsetY=2,n.strokeStyle="#222",n.lineWidth=4,n.strokeText(e,t,r),n.shadowBlur=0,n.shadowOffsetX=0,n.shadowOffsetY=0;const s=n.createLinearGradient(t,r,t,r+i);s.addColorStop(0,zd(o,20)),s.addColorStop(.5,o),s.addColorStop(1,zd(o,-30)),n.fillStyle=s,n.fillText(e,t,r),n.globalAlpha=.3,n.strokeStyle="#000",n.lineWidth=1;const l=n.measureText(e).width;for(let u=0;u<5;u++){const h=t+Math.random()*l,p=r+Math.random()*i;n.beginPath(),n.moveTo(h,p),n.lineTo(h+Math.random()*10-5,p+Math.random()*10),n.stroke()}}function zd(n,e){const t=n.replace("#",""),r=Math.max(0,Math.min(255,parseInt(t.substr(0,2),16)+e)),i=Math.max(0,Math.min(255,parseInt(t.substr(2,2),16)+e)),o=Math.max(0,Math.min(255,parseInt(t.substr(4,2),16)+e));return`rgb(${r},${i},${o})`}function I0(){iu||ae.length>0&&(ae.pop(),fe(),console.log("[OpenOverlay] Undo - items remaining:",ae.length))}async function A0(){if(iu)return;ft==="text"?(ae=ae.filter(e=>e.type!=="text"),console.log("[OpenOverlay] Cleared text stamps (drawings preserved)")):(ae=ae.filter(e=>e.type==="text"),console.log("[OpenOverlay] Cleared drawings (text stamps preserved)"));const n=su();ae.length>0?(localStorage.setItem(`oo_drawing_${n}`,JSON.stringify(ae)),Zs()&&await xg(n,window.location.href,ae)):(localStorage.removeItem(`oo_drawing_${n}`),Zs()&&await oI(n)),fe()}async function S0(){console.log("[OpenOverlay] Saving",ae.length,"items"),lt=null;const n=su(),e=JSON.stringify(ae);localStorage.setItem(`oo_drawing_${n}`,e),Zs()&&await xg(n,window.location.href,ae),fe(),console.log("[OpenOverlay] Drawing saved")}function x0(){console.log("[OpenOverlay] Canceling drawing"),ou()}async function ou(){const n=su();if(kr()){if(sI(n,i=>{ae=i.myItems,Fr=i.otherItems,gs=i.contributors,localStorage.setItem(`oo_drawing_${n}`,JSON.stringify(ae)),console.log("[OpenOverlay] Real-time update:",ae.length,"mine,",Fr.length,"from others"),i.contributors.length>0&&console.log("[OpenOverlay] Contributors:",i.contributors.map(o=>o.displayName).join(", ")),document.dispatchEvent(new CustomEvent("oo:contributors",{detail:{contributors:gs}})),fe()})){console.log("[OpenOverlay] Subscribed to real-time drawing updates");return}console.log("[OpenOverlay] Real-time subscription failed, trying one-time fetch");const r=await iI(n);if(r!==null){ae=r.myItems,Fr=r.otherItems,gs=r.contributors,localStorage.setItem(`oo_drawing_${n}`,JSON.stringify(ae)),console.log("[OpenOverlay] Loaded from cloud:",ae.length,"mine,",Fr.length,"from others"),document.dispatchEvent(new CustomEvent("oo:contributors",{detail:{contributors:gs}})),fe();return}}Fr=[];const e=localStorage.getItem(`oo_drawing_${n}`);if(e)try{ae=JSON.parse(e),console.log("[OpenOverlay] Loaded",ae.length,"items from localStorage"),fe()}catch{console.warn("[OpenOverlay] Failed to load drawings"),ae=[]}else ae=[]}function su(){return btoa(window.location.href).slice(0,32)}function k0(){Rg(n=>{n?(console.log("[OpenOverlay] User logged in, reloading drawings from cloud"),_0()):(console.log("[OpenOverlay] User logged out, reloading public drawings"),Nn=null),ou()})}function Gi(n,e,t,r,i){if(!Le||!at)return{floor:!1,floorY:0,ceiling:!1,ceilingY:0,leftWall:!1,leftWallX:0,rightWall:!1,rightWallX:0,slopeAngle:0,slopeAheadY:0};const o=window.devicePixelRatio||1;let s=!1,l=0,u=!1,h=0,p=!1,m=0,g=!1,b=0,P=0,A=0;const C=Math.max(1,Math.floor(t*.5*o)),$=Math.floor((n+t/2)*o),F=Math.max(0,$-Math.floor(C/2));try{const V=e+r,G=Math.floor((V-5)*o),z=Math.floor(20*o);if(F>=0&&G>=0&&F+C<=Le.width&&G+z<=Le.height){const nt=at.getImageData(F,G,C,z);for(let ue=0;ue<z;ue++){let ke=!1;for(let ye=0;ye<C;ye++){const Je=(ue*C+ye)*4;if(nt.data[Je+3]>30){ke=!0;break}}if(ke){const ye=G/o+ue/o;ye>=V-8&&(s=!0,l=ye);break}}}const K=e,E=Math.max(0,Math.floor((K-15)*o)),v=Math.floor(15*o);if(F>=0&&E>=0&&F+C<=Le.width&&E+v<=Le.height){const nt=at.getImageData(F,E,C,v);for(let ue=v-1;ue>=0;ue--){let ke=!1;for(let ye=0;ye<C;ye++){const Je=(ue*C+ye)*4;if(nt.data[Je+3]>30){ke=!0;break}}if(ke){const ye=E/o+(ue+1)/o;ye<=K+5&&(u=!0,h=ye);break}}}const w=Math.floor(e*o),I=Math.floor(r*.85*o),T=Math.floor(10*o),S=Math.max(0,Math.floor(n*o)-T);if(S>=0&&w>=0&&S+T<=Le.width&&w+I<=Le.height){const nt=at.getImageData(S,w,T,I);e:for(let ue=T-1;ue>=0;ue--)for(let ke=0;ke<I;ke++){const ye=(ke*T+ue)*4;if(nt.data[ye+3]>30){p=!0,m=(S+ue+1)/o;break e}}}const _=Math.floor((n+t)*o);if(_>=0&&w>=0&&_+T<=Le.width&&w+I<=Le.height){const nt=at.getImageData(_,w,T,I);e:for(let ue=0;ue<T;ue++)for(let ke=0;ke<I;ke++){const ye=(ke*T+ue)*4;if(nt.data[ye+3]>30){g=!0,b=(_+ue)/o;break e}}}const xe=e+r,tt=20,Pr=i!==!1?n+t+tt:n-tt,_n=Math.floor(Pr*o),vt=Math.floor((xe-30)*o),bt=Math.floor(50*o);if(_n>=0&&_n<Le.width&&vt>=0&&vt+bt<=Le.height){const nt=at.getImageData(_n,vt,1,bt);for(let ue=0;ue<bt;ue++)if(nt.data[ue*4+3]>30){A=vt/o+ue/o;const Je=(s?l:xe)-A;P=Math.atan2(Je,tt)*(180/Math.PI);break}}}catch{}return{floor:s,floorY:l,ceiling:u,ceilingY:h,leftWall:p,leftWallX:m,rightWall:g,rightWallX:b,slopeAngle:P,slopeAheadY:A}}let ve=null,c=null,gt=null,Z=null,Se="none",So="spawn",x={x:100,y:100,vx:0,vy:0,width:23,height:38,onGround:!1,facingRight:!0,animFrame:0,jumpsRemaining:2,maxJumps:2},hl=!1,Ki=0,ys=0,Jt=!1,Os=0,Wd=0;const P0=12e4,C0=2e3;let Mt=localStorage.getItem("oo_player_color")||"#ffffff",xo=localStorage.getItem("oo_player_hat")||"none",ko=localStorage.getItem("oo_player_accessory")||"none",Wl=localStorage.getItem("oo_screen_name")||"",au=localStorage.getItem("oo_player_girl")==="true",uo=[],It=new Map,Rn=new Map,dl=0,Hd=0,Gd=0;const R0=80;let Oe=!1,wt=null,ln=0,Te=!1,Xt=null,Dn=null,gr=0;const ra=3e3,cm=5e3,um=3e3;let Hl=0;const O0=5e3;function Po(){const n=ce();return n?wt!=null&&wt.gameActive?wt.itPlayerId===n.uid:Te:!1}let le={id:vm(),name:"New Course",checkpoints:[],authorId:"local-user",authorName:"You",createdAt:Date.now()},Co=[];const N0=.6,Kd=-12,Yd=3,D0=.7,Qd=14,fl=6,Zt={};let Br=null,Gl=0,ut=!1,Kl=0,Ei=0,or=0,Bn=3,lu=3,cn=!1,Yl=0;const Jd=2e3,M0=2e3;let cu=0,ia=!1,kt="explore",un=!1,uu=0;const hm=2e3;let Ie=null,ot=null,ei=!1,Ut=0,ho=localStorage.getItem("oo_player_name")||"";function L0(){console.log("[OpenOverlay] initGame starting..."),ve=document.createElement("canvas"),ve.id="oo-game-canvas",ve.style.cssText=`
    position: absolute;
    top: 0;
    left: 0;
    z-index: 2147483638;
    pointer-events: none;
  `,document.body.appendChild(ve),c=ve.getContext("2d"),gt=document.createElement("canvas"),gt.id="oo-overlay-canvas",gt.style.cssText=`
    position: absolute;
    top: 0;
    left: 0;
    z-index: 2147483646;
    pointer-events: none;
  `,document.body.appendChild(gt),Z=gt.getContext("2d"),pl(),window.addEventListener("resize",pl),new ResizeObserver(pl).observe(document.body),document.addEventListener("keydown",tA),document.addEventListener("keyup",nA),document.addEventListener("oo:gamemode",t=>{Xd(t.detail.mode,t.detail.tool,t.detail.playmode)}),document.addEventListener("oo:undo",()=>{Se==="build"&&le.checkpoints.length>0&&(le.checkpoints.pop(),gi(),et())}),document.addEventListener("oo:clear",()=>{Se==="build"&&(le.checkpoints=[],gi(),et())}),document.addEventListener("oo:playercolor",t=>{Mt=t.detail.color,localStorage.setItem("oo_player_color",Mt),et()}),document.addEventListener("oo:playerstyle",t=>{au=t.detail.isGirl,et()}),document.addEventListener("oo:playerhat",t=>{xo=t.detail.hat,localStorage.setItem("oo_player_hat",xo),et()}),document.addEventListener("oo:playeraccessory",t=>{ko=t.detail.accessory,localStorage.setItem("oo_player_accessory",ko),et()}),document.addEventListener("oo:screenname",t=>{Wl=t.detail.name,localStorage.setItem("oo_screen_name",Wl),Ro()}),document.addEventListener("oo:toggletag",()=>{console.log("[OpenOverlay] Tag toggle requested, gameMode:",Se),Se!=="play"&&(console.log("[OpenOverlay] Auto-switching to play mode for tag"),Xd("play","explore")),uA()}),ve.addEventListener("pointerdown",iA),ve.addEventListener("pointermove",oA),ve.addEventListener("pointerup",sA),ve.addEventListener("contextmenu",t=>{Se==="build"&&t.preventDefault()}),aA(),et();const e=()=>{Se==="play"&&(Cg(),Pg(mn()))};window.addEventListener("beforeunload",e),window.addEventListener("pagehide",e),document.addEventListener("visibilitychange",()=>{document.hidden&&Se==="play"&&Ro()}),console.log("[OpenOverlay] Game initialized")}function pl(){if(!ve||!c)return;const n=Math.max(document.body.scrollWidth,document.body.offsetWidth,document.documentElement.scrollWidth,document.documentElement.offsetWidth),e=Math.max(document.body.scrollHeight,document.body.offsetHeight,document.documentElement.scrollHeight,document.documentElement.offsetHeight),t=window.devicePixelRatio||1;ve.style.width=`${n}px`,ve.style.height=`${e}px`,ve.width=n*t,ve.height=e*t,c.scale(t,t),gt&&Z&&(gt.style.width=`${n}px`,gt.style.height=`${e}px`,gt.width=n*t,gt.height=e*t,Z.scale(t,t)),et()}function Xd(n,e,t){if(Se=n,e&&(So=e),t&&(kt=t),ve&&(ve.style.pointerEvents=n==="build"?"auto":"none",ve.style.cursor=n==="build"?"crosshair":"default"),n==="play"){ut=!1,Ei=0,or=0,le.checkpoints.forEach(i=>i.reached=!1),Bn=lu,cn=!1,un=!1,Ie=null,ei=!1;const r=mn();console.log("[OpenOverlay] Subscribing to players on page:",r),fI(r,i=>{if(It=i,i.size>0&&(console.log("[OpenOverlay] Received",i.size,"other players"),i.forEach((o,s)=>{console.log("[OpenOverlay] Player",s,"at",o.x,o.y)}),Oe)){const o=ce(),s=Date.now();let l=null;for(const[p,m]of i)m.taggedPlayerId===(o==null?void 0:o.uid)&&m.taggedAt&&s-m.taggedAt<cm&&!Te&&s>ln&&(console.log("[OpenOverlay] EXPLICITLY TAGGED by:",p,"via taggedPlayerId"),Te=!0,Xt=p,ln=s+ra,Pt("You're IT!","Tag someone!",2e3),Ql(),document.dispatchEvent(new CustomEvent("oo:tagstatechange",{detail:{isTagMode:!0,isIt:!0,gameActive:!0}})));for(const[p,m]of i){if(console.log("[OpenOverlay] Checking player",p,"isIt:",m.isIt),m.isIt){l=p,console.log("[OpenOverlay] Found IT player in sync:",m.displayName,"id:",p);break}p===Xt&&!m.isIt&&(console.log("[OpenOverlay] Clearing lastTaggedByPlayerId - sync caught up"),Xt=null)}const u=s<ln,h=l===Xt;l&&Te&&o&&!u&&!h?l<o.uid?(console.log("[OpenOverlay] Tiebreaker: other player wins (lower ID), giving up IT"),Te=!1,Xt=null,document.dispatchEvent(new CustomEvent("oo:tagstatechange",{detail:{isTagMode:!0,isIt:!1,gameActive:!0}}))):console.log("[OpenOverlay] Tiebreaker: we win (lower ID), keeping IT"):l&&Te&&u?console.log("[OpenOverlay] Skipping tiebreaker - in tag cooldown"):l&&Te&&h?console.log("[OpenOverlay] Skipping tiebreaker - was tagged by this player (stale sync)"):l&&!Te&&console.log("[OpenOverlay] Other player is IT, we are not")}}),pI(r,i=>{const o=wt;wt=i,console.log("[OpenOverlay] Tag game state changed:",i);const s=ce(),l=(i==null?void 0:i.itPlayerId)===(s==null?void 0:s.uid);document.dispatchEvent(new CustomEvent("oo:tagstatechange",{detail:{isTagMode:Oe,isIt:l,gameActive:(i==null?void 0:i.gameActive)??!1}})),i!=null&&i.gameActive&&(console.log('[OpenOverlay] Tag game active, "it" is:',i.itPlayerId),(o==null?void 0:o.itPlayerId)!==i.itPlayerId&&(l?Pt("You're IT!","Tag someone!",2e3):(o==null?void 0:o.itPlayerId)===(s==null?void 0:s.uid)&&Pt("You're not IT!","Run away!",2e3)))}),pm(),kt==="race"&&document.dispatchEvent(new CustomEvent("oo:hidetoolbar")),V0()}else n==="build"?(ei=!1,un=!1,Ie=null,Oe=!1,Te=!1,Xt=null,Dn=null,gr=0,wt=null):(ei=!1,un=!1,Ie=null,Cg(),gI(),Pg(mn()),It.clear(),Rn.clear(),Oe=!1,Te=!1,Xt=null,Dn=null,gr=0,wt=null);et()}function V0(){Br&&(cancelAnimationFrame(Br),Br=null),Gl=performance.now(),Br=requestAnimationFrame(dm)}function dm(n){const e=Math.min((n-Gl)/16.67,3);Gl=n,U0(e),et(),Se==="play"||Se==="build"?Br=requestAnimationFrame(dm):Br=null}function fm(){const n=le.checkpoints.find(r=>r.type==="spawn"),e=le.checkpoints.find(r=>r.type==="start"),t=n||e;t?(x.x=t.x-x.width/2,x.y=t.y-x.height-10):(x.x=window.scrollX+window.innerWidth/2-x.width/2,x.y=window.scrollY+100),x.vx=0,x.vy=0,x.onGround=!1,x.jumpsRemaining=x.maxJumps}function pm(){if(fm(),kt==="explore"){un=!1,ut=!1,Pt("Explore!","No timer, unlimited respawns",2e3),setTimeout(()=>{},150);return}un=!0,uu=performance.now(),Pt("Get Ready!","2")}function Pt(n,e,t=1e3){Ie={text:n,subtext:e,endTime:performance.now()+t}}function Ql(){Hl=performance.now()+um}function gm(n){ot&&Yi();const{top10:e}=cA();ot=document.createElement("div"),ot.id="oo-game-popup",ot.style.cssText=`
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background: rgba(0,0,0,0.7);
    z-index: 2147483647;
    display: flex;
    align-items: center;
    justify-content: center;
    font-family: system-ui, -apple-system, sans-serif;
  `;const t=n==="finish",r=t?"🏆 RACE COMPLETE!":"💀 GAME OVER",i=t?"#22c55e":"#ef4444",o=(Ei/1e3).toFixed(2),s=t&&Ut===le.bestTime;let l="";e.length>0&&(l=`
      <div style="margin-top: 15px; max-height: 200px; overflow-y: auto;">
        <div style="color: #fbbf24; font-weight: bold; margin-bottom: 8px;">🏆 Today's Best</div>
        ${e.slice(0,5).map((g,b)=>`
          <div style="display: flex; justify-content: space-between; color: ${b<3?["#fbbf24","#c0c0c0","#cd7f32"][b]:"#888"}; font-size: 13px; padding: 2px 0;">
            <span>${b+1}. ${g.name.slice(0,10)}</span>
            <span>${(g.time/1e3).toFixed(2)}s</span>
          </div>
        `).join("")}
      </div>
    `);const u=document.createElement("div");u.style.cssText=`
    background: #111;
    border: 3px solid ${i};
    border-radius: 12px;
    padding: 25px 35px;
    text-align: center;
    min-width: 300px;
    max-width: 400px;
    box-shadow: 0 10px 40px rgba(0,0,0,0.8);
  `,u.innerHTML=`
    <div style="color: ${i}; font-size: 24px; font-weight: bold; margin-bottom: 15px;">${r}</div>
    <div style="color: #fff; font-size: 40px; font-weight: bold; font-family: monospace;">${o}s</div>
    ${s?'<div style="color: #fbbf24; font-size: 14px; margin-top: 5px;">⭐ NEW PERSONAL BEST!</div>':""}
    ${t?`
      <div style="margin-top: 15px;">
        <input type="text" id="oo-popup-name" placeholder="Enter name..." value="${ho}"
          style="padding: 8px 12px; border-radius: 6px; border: 2px solid #333; background: #222; color: #fff; font-size: 14px; width: 180px; text-align: center;">
      </div>
    `:""}
    ${l}
    <div style="display: flex; gap: 10px; justify-content: center; margin-top: 20px;">
      <button id="oo-popup-retry" style="padding: 10px 25px; background: ${i}; color: white; border: none; border-radius: 8px; font-size: 14px; font-weight: bold; cursor: pointer;">
        🔄 Retry
      </button>
      <button id="oo-popup-close" style="padding: 10px 25px; background: #333; color: white; border: none; border-radius: 8px; font-size: 14px; font-weight: bold; cursor: pointer;">
        ✕ Close
      </button>
    </div>
  `,ot.appendChild(u),document.body.appendChild(ot);const h=ot.querySelector("#oo-popup-retry"),p=ot.querySelector("#oo-popup-close"),m=ot.querySelector("#oo-popup-name");h==null||h.addEventListener("click",()=>{t&&m&&m.value.trim()&&vs(m.value.trim(),Ut),Yi(),Zd()}),p==null||p.addEventListener("click",()=>{t&&m&&m.value.trim()&&vs(m.value.trim(),Ut),Yi(),ef()}),ot.addEventListener("click",g=>{g.target===ot&&(t&&m&&m.value.trim()&&vs(m.value.trim(),Ut),Yi(),ef())}),m==null||m.focus(),m==null||m.addEventListener("keydown",g=>{g.key==="Enter"&&m.value.trim()&&(vs(m.value.trim(),Ut),Yi(),Zd())})}function Yi(){ot&&(ot.remove(),ot=null)}function Zd(){ut=!1,Ei=0,or=0,le.checkpoints.forEach(n=>n.reached=!1),Bn=lu,cn=!1,ei=!1,uo=[],pm()}function ef(){document.dispatchEvent(new CustomEvent("oo:gamemode",{detail:{mode:"build"}})),ut=!1,ei=!1}function mm(){cn||(cn=!0,Yl=performance.now(),kt==="race"&&ut&&(Bn--,console.log("[OpenOverlay] Died! Lives remaining:",Bn)))}let tf=!1;function F0(){const n=performance.now();for(const[t,r]of It){let i=Rn.get(t);if(!i){i={x:r.x,y:r.y,vx:r.vx,vy:r.vy,lastSyncTime:n,targetX:r.x,targetY:r.y},Rn.set(t,i);continue}const o=Math.abs(r.x-i.targetX)>.1||Math.abs(r.y-i.targetY)>.1,s=Math.abs(r.vx-i.vx)>.1||Math.abs(r.vy-i.vy)>.1;if(o||s){i.vx=r.vx,i.vy=r.vy,i.lastSyncTime=n;const m=5;i.targetX=r.x+r.vx*m,i.targetY=r.y+r.vy*m}i.x+=i.vx*.5,i.y+=i.vy*.5;const l=.12,u=i.targetX-i.x,h=i.targetY-i.y;(Math.abs(u)>1||Math.abs(h)>1)&&(i.x+=u*l,i.y+=h*l),Math.sqrt(u*u+h*h)>150&&(i.x=r.x,i.y=r.y)}for(const t of Rn.keys())It.has(t)||Rn.delete(t);const e=Date.now();for(const[t,r]of It)r.updatedAt&&e-r.updatedAt>O0&&(console.log("[OpenOverlay] Removing stale player:",t),It.delete(t),Rn.delete(t))}function U0(n){if(Se!=="play")return;if(F0(),un){const F=performance.now()-uu,V=hm-F;V>1e3?Ie={text:"Get Ready!",subtext:"2",endTime:performance.now()+100}:V>0?Ie={text:"Get Ready!",subtext:"1",endTime:performance.now()+100}:(un=!1,Ie={text:"GO!",endTime:performance.now()+500},kt==="race"&&(ut=!0,Kl=performance.now()));return}if(cn){const F=Jd-(performance.now()-Yl);if(F>0&&(Ie={text:"You fell!",subtext:`Respawning in ${Math.ceil(F/1e3)}...`,endTime:performance.now()+100}),performance.now()-Yl>=Jd){if(kt==="race"&&Bn<=0){ut=!1,cn=!1,gm("gameover");return}cn=!1,fm(),Ie=null,setTimeout(()=>{},100)}return}Ie&&performance.now()>Ie.endTime&&(Ie=null);const t=performance.now()<cu?Yd*2:Yd;if(Zt.ArrowLeft||Zt.KeyA)x.vx=-t,x.facingRight=!1,ys=performance.now(),Jt=!1;else if(Zt.ArrowRight||Zt.KeyD)x.vx=t,x.facingRight=!0,ys=performance.now(),Jt=!1;else{const F=Ki>0?.92:D0;x.vx*=F,Math.abs(x.vx)<.1&&(x.vx=0)}Ki>0&&Ki--,x.onGround&&Math.abs(x.vx)<.1?(performance.now()-ys>P0&&!Jt&&(Jt=!0,Wd=performance.now(),Os=0),Jt&&(performance.now()-Wd<C0?Os+=.15:(Jt=!1,ys=performance.now()))):(Jt=!1,Os=0);const r=Zt.ArrowUp||Zt.KeyW||Zt.Space;if(r&&!tf&&x.jumpsRemaining>0){const F=ia?Kd*1.5:Kd;x.vy=F,x.onGround=!1,x.jumpsRemaining--,ia=!1}tf=r,x.vy+=N0*n,x.vy>Qd&&(x.vy=Qd);const i=50,o=x.vx>=0;x.onGround=!1;const s=x.vx*n,l=x.vy*n,u=Math.sqrt(s*s+l*l),h=Math.max(1,Math.ceil(u/fl)),p=s/h,m=l/h;for(let F=0;F<h;F++){const V=x.x+p,G=x.y+m,z=Gi(V,x.y,x.width,x.height,o);let K=!0;x.vx<0&&z.leftWall&&(x.x=z.leftWallX,x.vx=0,K=!1),x.vx>0&&z.rightWall&&(x.x=z.rightWallX-x.width,x.vx=0,K=!1),K&&Math.abs(x.vx)>.5&&z.slopeAheadY>0&&z.slopeAngle>i&&(x.vx=0,K=!1);let E=!0;if(x.vy<0){const v=Gi(x.x,G,x.width,x.height,o);v.ceiling&&(x.y=v.ceilingY,x.vy=1,E=!1)}if(K&&(x.x+=p),E&&(x.y+=m),x.vy>=0){const v=Gi(x.x,x.y,x.width,x.height,o);if(v.floor){const w=v.floorY-x.height,I=x.y-w,S=x.vy>5?2:8;if(I<=S&&I>=-fl){!hl&&Math.abs(x.vx)>.5&&(Ki=8),x.y=w,x.vy=0,x.onGround=!0,x.jumpsRemaining=x.maxJumps;break}}}}const g=Gi(x.x,x.y,x.width,x.height,o);x.vy<0&&g.ceiling&&(x.y=g.ceilingY,x.vy=1);const b=g.leftWall&&x.x<g.leftWallX,P=g.rightWall&&x.x+x.width>g.rightWallX;if(b&&P){const F=g.leftWallX-x.x,V=x.x+x.width-g.rightWallX;F<V?x.x=g.leftWallX:x.x=g.rightWallX-x.width,x.vx=0}else b?(x.x=g.leftWallX,x.vx=0):P&&(x.x=g.rightWallX-x.width,x.vx=0);if(x.vy>0&&!x.onGround&&g.floor){const F=g.floorY-x.height,V=x.y-F;V<=8&&V>=-fl&&(!hl&&Math.abs(x.vx)>.5&&(Ki=8),x.y=F,x.vy=0,x.onGround=!0,x.jumpsRemaining=x.maxJumps)}if(x.onGround&&Math.abs(x.vx)>.5){const F=Math.abs(x.vx),V=Math.min(3,Math.ceil(F*.3));for(let G=1;G<=V;G++){const z=x.y-G,K=Gi(x.x,z,x.width,x.height,o);if(K.floor&&!K.leftWall&&!K.rightWall){const E=K.floorY-x.height,v=x.y-E;if(v>0&&v<=V){x.y=E;break}}}}hl=x.onGround;const A=Math.max(document.body.scrollHeight,window.innerHeight),C=Math.max(document.body.scrollWidth,window.innerWidth);(x.y>A+M0||x.x<-100||x.x>C+100)&&mm(),Math.abs(x.vx)>.5?x.animFrame=(x.animFrame+.15*n)%4:x.animFrame=0,q0(),B0(),Oe&&$0(),ut&&kt==="race"&&(Ei=performance.now()-Kl);const $=performance.now();if(Se==="play"&&$-dl>R0){const F=Math.abs(x.x-Hd)>5||Math.abs(x.y-Gd)>5,V=$-dl>5e3;(F||V)&&(dl=$,Hd=x.x,Gd=x.y,Ro())}}function Ro(){const n=mn(),e=ce(),t=Oe&&Po();Oe&&console.log("[OpenOverlay] Syncing player with isIt:",t,"isTagMode:",Oe,"localIsIt:",Te);const r=Date.now();Dn&&r-gr>cm&&(Dn=null,gr=0);const i={x:x.x,y:x.y+x.height,vx:x.vx,vy:x.vy,facingRight:x.facingRight,animFrame:x.animFrame,onGround:x.onGround,isDead:cn,playerColor:Mt,playerHat:xo,playerAccessory:ko,isGirlMode:au,displayName:Wl||(e==null?void 0:e.displayName)||"",updatedAt:r,isIt:Oe&&Po(),tagCooldownUntil:ln};Dn&&(i.taggedPlayerId=Dn,i.taggedAt=gr),dI(n,i)}function q0(){if(kt!=="race")return;const n=[...le.checkpoints,...Co.flatMap(t=>t.checkpoints)],e=n.filter(t=>t.type==="checkpoint").length;for(const t of n){if(t.reached)continue;const r=x.x+x.width/2,i=x.y+x.height/2;if(Math.hypot(r-t.x,i-t.y)<50)if(t.type==="start"&&!ut)ut=!0,Kl=performance.now(),t.reached=!0,console.log("[OpenOverlay] Race started!");else if(t.type==="checkpoint"&&ut){const s=or+1;t.order===s&&(t.reached=!0,or++,console.log("[OpenOverlay] Checkpoint",or,"of",e,"reached!"),Pt(`Flag ${or}/${e}`,"",1500))}else t.type==="finish"&&ut&&or>=e&&(t.reached=!0,ut=!1,Ut=Ei,console.log("[OpenOverlay] Race finished! Time:",(Ut/1e3).toFixed(2)+"s"),(!le.bestTime||Ut<le.bestTime)&&(le.bestTime=Ut,gi()),gm("finish"),document.dispatchEvent(new CustomEvent("oo:racefinish",{detail:{time:Ut,bestTime:le.bestTime}})))}}function B0(){const n=[...le.checkpoints,...Co.flatMap(e=>e.checkpoints)];for(const e of n){if(!["trampoline","speedBoost","highJump","spike"].includes(e.type))continue;const t=e.width||60,r=e.height||20,i=e.x-t/2,o=e.x+t/2,s=e.y-r,l=e.y,u=x.x,h=x.x+x.width,p=x.y,m=x.y+x.height;if(h>i&&u<o&&m>s&&p<l)switch(e.type){case"trampoline":x.vy>0&&(x.vy=-20,x.onGround=!1,x.jumpsRemaining=x.maxJumps);break;case"speedBoost":cu=performance.now()+3e3;break;case"highJump":ia=!0;break;case"spike":cn||(uo.push({x:x.x+x.width/2,y:x.y+x.height,createdAt:performance.now()}),mm());break}}}function $0(){if(!Oe||!ce())return;const e=Date.now(),t=mn(),r=x.x+x.width/2,i=x.y+x.height,o=Po();for(const[s,l]of It){const u=Rn.get(s),h=u?u.x:l.x,p=u?u.y:l.y,m=r-h,g=i-p;if(Math.sqrt(m*m+g*g)<40){const P=e>ln,A=!l.tagCooldownUntil||e>l.tagCooldownUntil;o&&P&&A&&(console.log("[OpenOverlay] TAGGING player:",s),Te=!1,Dn=s,gr=e,yI(t,s).catch(()=>{console.log("[OpenOverlay] Firebase tag update failed, using local state")}),ln=e+ra,Pt("Tagged!",l.displayName||"Player",1500),Ql(),document.dispatchEvent(new CustomEvent("oo:tagstatechange",{detail:{isTagMode:!0,isIt:!1,gameActive:!0}})),Ro());const C=!l.tagCooldownUntil||e>l.tagCooldownUntil;!o&&l.isIt&&P&&C&&(console.log("[OpenOverlay] GOT TAGGED by:",s),Te=!0,ln=e+ra,Xt=s,Pt("You're IT!","Tag someone!",2e3),Ql(),document.dispatchEvent(new CustomEvent("oo:tagstatechange",{detail:{isTagMode:!0,isIt:!0,gameActive:!0}})))}}}function et(){if(!(!c||!ve)){c.clearRect(0,0,ve.width,ve.height),Z&&gt&&Z.clearRect(0,0,gt.width,gt.height),j0();for(const n of le.checkpoints)nf(n);for(const n of Co)for(const e of n.checkpoints)nf(e,n.authorName);(Se==="play"||Se==="build")&&(z0(),G0(),Se==="play"&&J0()),Se==="build"&&eA()}}function j0(){if(!c)return;const n=performance.now(),e=5e3;uo=uo.filter(t=>n-t.createdAt<e);for(const t of uo){const r=n-t.createdAt,i=Math.max(0,1-r/e);c.save(),c.globalAlpha=i,c.fillStyle="#dc2626",c.beginPath(),c.arc(t.x,t.y,12,0,Math.PI*2),c.fill(),c.fillStyle="#b91c1c";for(let o=0;o<5;o++){const s=o/5*Math.PI*2+Math.random()*.5,l=15+Math.random()*10,u=Math.cos(s)*l,h=Math.sin(s)*l*.5;c.beginPath(),c.arc(t.x+u,t.y+h,4+Math.random()*3,0,Math.PI*2),c.fill()}c.restore()}}function nf(n,e){if(!c)return;const t=n.x,r=n.y;if(c.save(),e&&(n.type==="start"||n.type==="finish")&&(c.font="10px Arial",c.fillStyle="rgba(255,255,255,0.7)",c.textAlign="center",c.fillText(`by ${e}`,t,r+15)),n.type==="start"){const i=n.reached?"#86efac":"#22c55e",o=80,s=70;c.strokeStyle="#444",c.lineWidth=6,c.beginPath(),c.moveTo(t-o/2,r),c.lineTo(t-o/2,r-s),c.stroke(),c.beginPath(),c.moveTo(t+o/2,r),c.lineTo(t+o/2,r-s),c.stroke(),c.fillStyle=i,c.fillRect(t-o/2-3,r-s-15,o+6,20),c.strokeStyle="#166534",c.lineWidth=2,c.strokeRect(t-o/2-3,r-s-15,o+6,20),c.fillStyle="#fff",c.font="bold 14px sans-serif",c.textAlign="center",c.fillText("START",t,r-s-1)}else if(n.type==="finish"){c.strokeStyle="#444",c.lineWidth=6,c.beginPath(),c.moveTo(t-80/2,r),c.lineTo(t-80/2,r-70),c.stroke(),c.beginPath(),c.moveTo(t+80/2,r),c.lineTo(t+80/2,r-70),c.stroke();const s=r-70-15,l=20,u=8;c.fillStyle=n.reached?"#fbbf24":"#111",c.fillRect(t-80/2-3,s,86,l);for(let h=0;h<Math.ceil(86/u);h++)for(let p=0;p<Math.ceil(l/u);p++)(h+p)%2===0&&(c.fillStyle="#fff",c.fillRect(t-80/2-3+h*u,s+p*u,u,Math.min(u,l-p*u)));c.strokeStyle="#444",c.lineWidth=2,c.strokeRect(t-80/2-3,s,86,l),c.fillStyle="#fff",c.font="bold 11px sans-serif",c.textAlign="center",c.fillText("FINISH",t,r+15)}else if(n.type==="spawn"){if(Se!=="build"){c.restore();return}const i="#a855f7";c.fillStyle=i,c.beginPath(),c.moveTo(t,r-20),c.lineTo(t-10,r-35),c.lineTo(t+10,r-35),c.closePath(),c.fill(),c.strokeStyle=i,c.lineWidth=2,c.beginPath(),c.arc(t,r-55,8,0,Math.PI*2),c.stroke(),c.beginPath(),c.moveTo(t,r-47),c.lineTo(t,r-30),c.stroke(),c.beginPath(),c.moveTo(t-10,r-42),c.lineTo(t+10,r-42),c.stroke(),c.beginPath(),c.moveTo(t,r-30),c.lineTo(t-8,r-15),c.moveTo(t,r-30),c.lineTo(t+8,r-15),c.stroke(),c.fillStyle="#fff",c.font="bold 10px sans-serif",c.textAlign="center",c.fillText("SPAWN",t,r+5)}else if(n.type==="trampoline"){const i=n.width||60,o=n.height||20;c.fillStyle="#f97316",c.fillRect(t-i/2,r-o,i,o),c.strokeStyle="#c2410c",c.lineWidth=2,c.strokeRect(t-i/2,r-o,i,o),c.strokeStyle="#c2410c",c.lineWidth=2;const s=3,l=i/s;for(let u=0;u<s;u++){const h=t-i/2+l/2+u*l;c.beginPath(),c.moveTo(h,r),c.lineTo(h-4,r-o/3),c.lineTo(h+4,r-o*2/3),c.lineTo(h,r-o),c.stroke()}}else if(n.type==="speedBoost"){const i=n.width||60,o=n.height||20,s=performance.now()<cu;c.fillStyle=s?"#60a5fa":"#3b82f6",c.fillRect(t-i/2,r-o,i,o),c.strokeStyle="#1d4ed8",c.lineWidth=2,c.strokeRect(t-i/2,r-o,i,o),c.fillStyle="#fff",c.font="bold 14px sans-serif",c.textAlign="center",c.textBaseline="middle",c.fillText(">>",t,r-o/2)}else if(n.type==="highJump"){const i=n.width||60,o=n.height||20,s=ia;c.fillStyle=s?"#86efac":"#22c55e",c.fillRect(t-i/2,r-o,i,o),c.strokeStyle="#15803d",c.lineWidth=2,c.strokeRect(t-i/2,r-o,i,o),c.fillStyle="#fff",c.font="bold 16px sans-serif",c.textAlign="center",c.textBaseline="middle",c.fillText("^",t,r-o/2)}else if(n.type==="spike"){const i=n.width||60,o=n.height||30,s=4,l=i/s;c.fillStyle="#ef4444";for(let u=0;u<s;u++){const h=t-i/2+u*l;c.beginPath(),c.moveTo(h,r),c.lineTo(h+l/2,r-o),c.lineTo(h+l,r),c.closePath(),c.fill()}c.strokeStyle="#991b1b",c.lineWidth=1;for(let u=0;u<s;u++){const h=t-i/2+u*l;c.beginPath(),c.moveTo(h,r),c.lineTo(h+l/2,r-o),c.lineTo(h+l,r),c.closePath(),c.stroke()}}else if(n.type==="checkpoint"){const i=n.reached?"#fbbf24":"#3b82f6";c.strokeStyle="#444",c.lineWidth=4,c.beginPath(),c.moveTo(t,r),c.lineTo(t,r-50),c.stroke(),c.fillStyle=i,c.beginPath(),c.moveTo(t,r-50),c.lineTo(t+35,r-40),c.lineTo(t,r-30),c.closePath(),c.fill(),c.fillStyle="#fff",c.font="bold 12px sans-serif",c.textAlign="center",c.textBaseline="middle",c.fillText(String(n.order),t+15,r-40)}c.restore()}function z0(){if(c)for(const[n,e]of It){const t=`logged_${n}`;window[t]||(window[t]=!0,console.log("[OpenOverlay] Remote player data:",n,JSON.stringify({isGirlMode:e.isGirlMode,playerHat:e.playerHat,playerColor:e.playerColor,displayName:e.displayName,playerAccessory:e.playerAccessory,isIt:e.isIt}))),W0(n,e)}}function W0(n,e){if(!c||e.isDead)return;const t=Rn.get(n),r=t?t.x:e.x,i=t?t.y:e.y,o=30,s=50,l=r,u=i-s;c.save(),c.globalAlpha=.85,e.facingRight||(c.translate(l+o/2,0),c.scale(-1,1),c.translate(-(l+o/2),0));const h=7,p=13,m=11,g=l+o/2,b=u+h+3,P=b+h,A=P+p,C=e.playerColor||"#ffffff";c.strokeStyle=C,c.lineWidth=3,c.lineCap="round",c.lineJoin="round",c.shadowColor="rgba(0,0,0,0.3)",c.shadowBlur=4,c.shadowOffsetX=2,c.shadowOffsetY=2;const $=Math.abs(e.vx)>.5,F=e.animFrame||0;if(e.isGirlMode){c.fillStyle=C,c.beginPath(),c.moveTo(g-h-2,b+8),c.lineTo(g-h-1,b-2),c.quadraticCurveTo(g-h+2,b-h-4,g,b-h-3),c.quadraticCurveTo(g+h-2,b-h-4,g+h+1,b-2),c.lineTo(g+h+2,b+8),c.quadraticCurveTo(g+h,b+10,g+h-2,b+10),c.lineTo(g-h+2,b+10),c.quadraticCurveTo(g-h,b+10,g-h-2,b+8),c.closePath(),c.fill(),c.fillStyle="#fff",c.beginPath(),c.arc(g,b,h-1,0,Math.PI*2),c.fill(),c.fillStyle=C,c.beginPath(),c.moveTo(g-h+2,b-2),c.quadraticCurveTo(g-2,b-h-2,g,b-h+1),c.quadraticCurveTo(g+2,b-h-2,g+h-2,b-2),c.quadraticCurveTo(g,b-1,g-h+2,b-2),c.closePath(),c.fill(),c.fillStyle=C,$?(c.beginPath(),c.arc(g+2,b,1.5,0,Math.PI*2),c.fill(),c.lineWidth=2,c.beginPath(),c.moveTo(g,b+4),c.lineTo(g+4,b+4),c.stroke(),c.lineWidth=3):(c.beginPath(),c.arc(g-3,b,1.5,0,Math.PI*2),c.fill(),c.beginPath(),c.arc(g+3,b,1.5,0,Math.PI*2),c.fill(),c.lineWidth=1.5,c.beginPath(),c.arc(g,b+3,2.5,.2*Math.PI,.8*Math.PI),c.stroke(),c.lineWidth=3),c.fillStyle=C,c.beginPath(),c.moveTo(g,P),c.lineTo(g-8,A+1),c.lineTo(g+8,A+1),c.closePath(),c.fill(),c.strokeStyle="#fff",c.lineWidth=2;const z=$?Math.sin(F*Math.PI)*6:0;c.beginPath(),c.moveTo(g-3,A),c.lineTo(g-5+z,A+m),c.moveTo(g+3,A),c.lineTo(g+5-z,A+m),c.stroke(),c.lineWidth=3,c.strokeStyle=C}else{c.beginPath(),c.arc(g,b,h,0,Math.PI*2),c.stroke(),c.fillStyle=C,c.beginPath(),c.moveTo(g-6,b-h+1),c.lineTo(g-3,b-h-4),c.lineTo(g+8,b-h+3),c.quadraticCurveTo(g,b-h-1,g-6,b-h+1),c.closePath(),c.fill(),c.stroke(),c.fillStyle=C,$?(c.beginPath(),c.arc(g+3,b-1,2,0,Math.PI*2),c.fill(),c.beginPath(),c.moveTo(g+1,b+4),c.lineTo(g+5,b+4),c.stroke()):(c.beginPath(),c.arc(g-3,b-1,1.5,0,Math.PI*2),c.fill(),c.beginPath(),c.arc(g+3,b-1,1.5,0,Math.PI*2),c.fill(),c.lineWidth=1.5,c.beginPath(),c.arc(g,b+3,3,.2*Math.PI,.8*Math.PI),c.stroke(),c.lineWidth=3),c.beginPath(),c.moveTo(g,P),c.lineTo(g,A),c.stroke();const z=P+3,K=$?Math.sin(F*Math.PI)*6:0;c.beginPath(),c.moveTo(g,z),c.lineTo(g-m,z+6+K),c.moveTo(g,z),c.lineTo(g+m,z+6-K),c.stroke();const E=$?Math.sin(F*Math.PI)*8:0;c.beginPath(),c.moveTo(g,A),c.lineTo(g-6+E,A+m),c.moveTo(g,A),c.lineTo(g+6-E,A+m),c.stroke()}if(e.playerHat&&e.playerHat!=="none"&&H0(g,b,h,e.playerHat,C),c.restore(),c.save(),c.globalAlpha=.9,e.displayName){c.shadowColor="transparent",c.fillStyle="rgba(0,0,0,0.7)",c.font='bold 11px "Comic Sans MS", "Chalkboard SE", cursive';const z=c.measureText(e.displayName).width;c.fillRect(g-z/2-5,b-h-22,z+10,16),c.fillStyle=e.playerColor||"#fff",c.textAlign="center",c.textBaseline="middle",c.fillText(e.displayName,g,b-h-14)}c.restore(),Oe&&e.isIt&&(c.save(),c.shadowColor="#ff0000",c.shadowBlur=15,c.fillStyle="#ff0000",c.font="bold 16px sans-serif",c.textAlign="center",c.textBaseline="middle",c.fillText("IT",g,b-h-25),c.restore());const G=Date.now();Oe&&e.tagCooldownUntil&&e.tagCooldownUntil>G&&ym(g,u+s/2,e.tagCooldownUntil,G)}function H0(n,e,t,r,i){if(!c)return;const o=e-t;switch(r){case"cap":c.fillStyle="#ef4444",c.beginPath(),c.ellipse(n,o-2,t+2,5,0,0,Math.PI*2),c.fill(),c.fillRect(n-2,o-4,t+8,4);break;case"tophat":c.fillStyle="#1a1a1a",c.fillRect(n-12,o-2,24,4),c.fillRect(n-8,o-18,16,16),c.fillStyle=i,c.fillRect(n-8,o-6,16,3);break;case"crown":c.fillStyle="#fbbf24",c.beginPath(),c.moveTo(n-10,o),c.lineTo(n-10,o-8),c.lineTo(n-6,o-4),c.lineTo(n-3,o-12),c.lineTo(n,o-6),c.lineTo(n+3,o-12),c.lineTo(n+6,o-4),c.lineTo(n+10,o-8),c.lineTo(n+10,o),c.closePath(),c.fill(),c.fillStyle="#dc2626",c.beginPath(),c.arc(n,o-5,2,0,Math.PI*2),c.fill();break;case"beanie":c.fillStyle="#3b82f6",c.beginPath(),c.arc(n,o,t+1,Math.PI,0),c.fill(),c.fillStyle="#fff",c.beginPath(),c.arc(n,o-t-3,4,0,Math.PI*2),c.fill();break;case"party":c.fillStyle="#ec4899",c.beginPath(),c.moveTo(n,o-20),c.lineTo(n-10,o),c.lineTo(n+10,o),c.closePath(),c.fill(),c.strokeStyle="#fbbf24",c.lineWidth=2,c.beginPath(),c.moveTo(n-8,o-4),c.lineTo(n+8,o-4),c.moveTo(n-5,o-10),c.lineTo(n+5,o-10),c.stroke(),c.lineWidth=3;break}}function G0(){if(!c)return;const n=x.x,e=x.y,t=x.width;c.save(),x.facingRight||(c.translate(n+t/2,0),c.scale(-1,1),c.translate(-(n+t/2),0));const r=7,i=13,o=11,s=n+t/2,l=e+r+3,u=l+r,h=u+i;c.strokeStyle=Mt,c.lineWidth=3,c.lineCap="round",c.lineJoin="round",c.shadowColor="rgba(0,0,0,0.3)",c.shadowBlur=4,c.shadowOffsetX=2,c.shadowOffsetY=2;const p=Math.abs(x.vx)>.5;au?(c.fillStyle=Mt,c.beginPath(),c.moveTo(s-r-2,l+8),c.lineTo(s-r-1,l-2),c.quadraticCurveTo(s-r+2,l-r-4,s,l-r-3),c.quadraticCurveTo(s+r-2,l-r-4,s+r+1,l-2),c.lineTo(s+r+2,l+8),c.quadraticCurveTo(s+r,l+10,s+r-2,l+10),c.lineTo(s-r+2,l+10),c.quadraticCurveTo(s-r,l+10,s-r-2,l+8),c.closePath(),c.fill(),c.fillStyle="#fff",c.beginPath(),c.arc(s,l,r-1,0,Math.PI*2),c.fill(),c.fillStyle=Mt,c.beginPath(),c.moveTo(s-r+2,l-2),c.quadraticCurveTo(s-2,l-r-2,s,l-r+1),c.quadraticCurveTo(s+2,l-r-2,s+r-2,l-2),c.quadraticCurveTo(s,l-1,s-r+2,l-2),c.closePath(),c.fill(),c.fillStyle=Mt,p?(c.beginPath(),c.arc(s+2,l,1.5,0,Math.PI*2),c.fill(),c.lineWidth=2,c.beginPath(),c.moveTo(s,l+4),c.lineTo(s+4,l+4),c.stroke(),c.lineWidth=3):(c.beginPath(),c.arc(s-3,l,1.5,0,Math.PI*2),c.fill(),c.beginPath(),c.arc(s+3,l,1.5,0,Math.PI*2),c.fill(),c.lineWidth=1.5,c.beginPath(),c.arc(s,l+3,2.5,.2*Math.PI,.8*Math.PI),c.stroke(),c.lineWidth=3),c.fillStyle=Mt,c.beginPath(),c.moveTo(s,u),c.lineTo(s-8,h+1),c.lineTo(s+8,h+1),c.closePath(),c.fill()):(c.beginPath(),c.arc(s,l,r,0,Math.PI*2),c.stroke(),c.fillStyle=Mt,c.beginPath(),c.moveTo(s-6,l-r+1),c.lineTo(s-3,l-r-4),c.lineTo(s+8,l-r+3),c.quadraticCurveTo(s,l-r-1,s-6,l-r+1),c.closePath(),c.fill(),c.stroke(),c.fillStyle=Mt,p?(c.beginPath(),c.arc(s+3,l-1,2,0,Math.PI*2),c.fill(),c.beginPath(),c.moveTo(s+1,l+4),c.lineTo(s+5,l+4),c.stroke()):(c.beginPath(),c.arc(s-3,l-1,1.5,0,Math.PI*2),c.fill(),c.beginPath(),c.arc(s+3,l-1,1.5,0,Math.PI*2),c.fill(),c.beginPath(),c.arc(s,l+3,3,.1*Math.PI,.9*Math.PI),c.stroke()),c.beginPath(),c.moveTo(s,u),c.lineTo(s,h),c.stroke());const m=Math.sin(x.animFrame*Math.PI),g=m*.5,b=m*.6,P=Jt?Math.sin(Os*3)*.5:0;if(c.beginPath(),c.moveTo(s,u+4),Jt){const C=s-o*Math.cos(-.8+P),$=u+4+o*Math.sin(-.8+P);c.lineTo(C,$)}else c.lineTo(s-o*Math.cos(.6+g),u+4+o*Math.sin(.6+g));if(c.stroke(),c.beginPath(),c.moveTo(s,u+4),c.lineTo(s+o*Math.cos(.6-g),u+4+o*Math.sin(.6-g)),c.stroke(),!x.onGround&&x.vy<0)c.beginPath(),c.moveTo(s,h),c.lineTo(s-5,h+o*.7),c.stroke(),c.beginPath(),c.moveTo(s,h),c.lineTo(s+5,h+o*.7),c.stroke();else if(!x.onGround)c.beginPath(),c.moveTo(s,h),c.lineTo(s-8,h+o),c.stroke(),c.beginPath(),c.moveTo(s,h),c.lineTo(s+8,h+o),c.stroke();else{const C=Math.abs(x.vx)>.5;c.beginPath(),c.moveTo(s,h),c.lineTo(s-o*(C?Math.sin(b)*.8:.3),h+o*(C?Math.cos(b*.5):.95)),c.stroke(),c.beginPath(),c.moveTo(s,h),c.lineTo(s+o*(C?Math.sin(b)*.8:.3),h+o*(C?Math.cos(b*.5):.95)),c.stroke()}K0(s,l,r),c.restore(),Oe&&Po()&&(c.save(),c.shadowColor="#ff0000",c.shadowBlur=15,c.fillStyle="#ff0000",c.font="bold 16px sans-serif",c.textAlign="center",c.textBaseline="middle",c.fillText("IT",s,l-r-20),c.restore());const A=Date.now();Oe&&ln>A&&ym(s,x.y+x.height/2,ln,A)}function ym(n,e,t,r){if(!c)return;const i=t-r;if(i<=0)return;const o=6,s=ra/o,l=Math.ceil(i/s),u=35,h=Math.PI*2/o;c.save();for(let p=0;p<l;p++){const m=-Math.PI/2+p*h,g=m+h-.05;c.fillStyle="rgba(0, 200, 255, 0.3)",c.strokeStyle="rgba(0, 200, 255, 0.7)",c.lineWidth=2,c.beginPath(),c.moveTo(n,e),c.arc(n,e,u,m,g),c.closePath(),c.fill(),c.stroke()}c.strokeStyle="rgba(0, 200, 255, 0.5)",c.lineWidth=3,c.beginPath(),c.arc(n,e,u,0,Math.PI*2),c.stroke(),c.restore()}function K0(n,e,t){c&&(c.shadowBlur=0,xo!=="none"&&Y0(n,e,t),ko!=="none"&&Q0(n,e,t))}function Y0(n,e,t){if(!c)return;const r=e-t;switch(xo){case"cap":c.fillStyle="#ef4444",c.beginPath(),c.ellipse(n,r-2,t+2,5,0,0,Math.PI*2),c.fill(),c.fillRect(n-2,r-4,t+8,4);break;case"tophat":c.fillStyle="#1a1a1a",c.fillRect(n-7,r-18,14,16),c.fillRect(n-12,r-2,24,4);break;case"crown":c.fillStyle="#fbbf24",c.beginPath(),c.moveTo(n-10,r),c.lineTo(n-10,r-8),c.lineTo(n-6,r-4),c.lineTo(n-3,r-12),c.lineTo(n,r-6),c.lineTo(n+3,r-12),c.lineTo(n+6,r-4),c.lineTo(n+10,r-8),c.lineTo(n+10,r),c.closePath(),c.fill(),c.fillStyle="#dc2626",c.beginPath(),c.arc(n,r-5,2,0,Math.PI*2),c.fill();break;case"beanie":c.fillStyle="#3b82f6",c.beginPath(),c.arc(n,r,t+1,Math.PI,0),c.fill(),c.fillStyle="#fff",c.beginPath(),c.arc(n,r-t-3,4,0,Math.PI*2),c.fill();break;case"party":c.fillStyle="#ec4899",c.beginPath(),c.moveTo(n,r-20),c.lineTo(n-10,r),c.lineTo(n+10,r),c.closePath(),c.fill(),c.strokeStyle="#fbbf24",c.lineWidth=2,c.beginPath(),c.moveTo(n-8,r-4),c.lineTo(n+8,r-4),c.moveTo(n-5,r-10),c.lineTo(n+5,r-10),c.stroke(),c.lineWidth=3;break}}function Q0(n,e,t){if(c)switch(ko){case"glasses":c.strokeStyle="#333",c.lineWidth=1.5,c.beginPath(),c.arc(n-4,e-1,4,0,Math.PI*2),c.arc(n+4,e-1,4,0,Math.PI*2),c.stroke(),c.beginPath(),c.moveTo(n-1,e-1),c.lineTo(n+1,e-1),c.stroke(),c.lineWidth=3;break;case"sunglasses":c.fillStyle="#1a1a1a",c.fillRect(n-9,e-3,7,5),c.fillRect(n+2,e-3,7,5),c.fillRect(n-2,e-2,4,2);break;case"mustache":c.fillStyle="#4a3728",c.beginPath(),c.moveTo(n-8,e+3),c.quadraticCurveTo(n-4,e+6,n,e+4),c.quadraticCurveTo(n+4,e+6,n+8,e+3),c.quadraticCurveTo(n+4,e+4,n,e+3),c.quadraticCurveTo(n-4,e+4,n-8,e+3),c.fill();break;case"beard":c.fillStyle="#4a3728",c.beginPath(),c.moveTo(n-t+2,e+2),c.quadraticCurveTo(n-t,e+10,n,e+14),c.quadraticCurveTo(n+t,e+10,n+t-2,e+2),c.quadraticCurveTo(n,e+6,n-t+2,e+2),c.fill();break;case"mask":c.fillStyle="#1a1a1a",c.beginPath(),c.ellipse(n,e-1,t-1,4,0,0,Math.PI*2),c.fill(),c.fillStyle="#fff",c.beginPath(),c.ellipse(n-4,e-1,2.5,2,0,0,Math.PI*2),c.ellipse(n+4,e-1,2.5,2,0,0,Math.PI*2),c.fill();break}}function J0(){if(!c)return;const n=window.scrollX,e=window.scrollY;c.save();const t=kt==="race"?260:180;c.fillStyle="rgba(0,0,0,0.8)",c.fillRect(n+10,e+10,t,70);let r="EXPLORE MODE",i="#22c55e";if(Oe?(r="TAG MODE",i="#f97316"):kt==="race"&&(r="RACE MODE",i="#ef4444"),c.fillStyle=i,c.font="bold 11px sans-serif",c.fillText(r,n+20,e+25),kt==="race"){const o=(Ei/1e3).toFixed(2);c.fillStyle="#fff",c.font="bold 20px monospace";const s=un?"Ready...":ut?`${o}s`:Bn<=0?"GAME OVER":`${o}s`;c.fillText(s,n+20,e+48),c.font="14px sans-serif",c.fillStyle="#888",c.fillText("Lives:",n+155,e+48);for(let l=0;l<lu;l++){const u=n+200+l*20,h=e+40;l<Bn?(c.strokeStyle="#22c55e",c.lineWidth=2,c.beginPath(),c.arc(u,h-6,4,0,Math.PI*2),c.stroke(),c.beginPath(),c.moveTo(u,h-2),c.lineTo(u,h+6),c.stroke(),c.beginPath(),c.moveTo(u-4,h+1),c.lineTo(u+4,h+1),c.stroke(),c.beginPath(),c.moveTo(u,h+6),c.lineTo(u-3,h+12),c.moveTo(u,h+6),c.lineTo(u+3,h+12),c.stroke()):(c.strokeStyle="#ef4444",c.lineWidth=2,c.beginPath(),c.moveTo(u-5,h-8),c.lineTo(u+5,h+8),c.moveTo(u+5,h-8),c.lineTo(u-5,h+8),c.stroke())}le.bestTime&&(c.fillStyle="#fbbf24",c.font="12px monospace",c.fillText(`Best: ${(le.bestTime/1e3).toFixed(2)}s`,n+20,e+66)),Bn<=0&&(c.fillStyle="#ef4444",c.font="bold 14px sans-serif",c.fillText("GAME OVER - Press Play to retry",n+20,e+100))}else if(Oe){if(Po())c.fillStyle="#ff4444",c.font="bold 16px sans-serif",c.fillText("You're IT! Tag someone!",n+20,e+48);else{let s="";if(wt!=null&&wt.itPlayerId){for(const[l,u]of It)if(l===wt.itPlayerId){s=u.displayName||"Another player";break}}if(!s){for(const[,l]of It)if(l.isIt){s=l.displayName||"Another player";break}}s?(c.fillStyle="#22c55e",c.font="bold 16px sans-serif",c.fillText("Run! "+s+" is IT!",n+20,e+48)):(c.fillStyle="#fff",c.font="16px sans-serif",c.fillText("Waiting for IT player...",n+20,e+48))}c.fillStyle="#888",c.font="12px sans-serif",c.fillText("Touch another player to tag them",n+20,e+66)}else c.fillStyle="#fff",c.font="16px sans-serif",c.fillText("Explore freely!",n+20,e+48),c.fillStyle="#888",c.font="12px sans-serif",c.fillText("No timer, unlimited respawns",n+20,e+66);if(c.fillStyle="#666",c.font="11px sans-serif",c.fillText("WASD/Arrows, Space=jump, L=leaderboard",n+10,e+95),X0(),Z0(),un&&Z){const o=performance.now()-uu,l=hm-o>1e3?"2":"1";Z.fillStyle="rgba(0, 0, 0, 0.5)",Z.fillRect(n,e,window.innerWidth,window.innerHeight),Z.fillStyle="#fff",Z.font="bold 120px sans-serif",Z.textAlign="center",Z.textBaseline="middle",Z.fillText(l,n+window.innerWidth/2,e+window.innerHeight/2),Z.textBaseline="alphabetic",Z.textAlign="left"}c.restore()}function X0(){if(!Z||!Ie)return;const n=window.scrollX,e=window.scrollY,t=200,r=Ie.subtext?60:40,i=n+20,o=e+window.innerHeight-r-20;Z.fillStyle="rgba(0, 0, 0, 0.9)",Z.fillRect(i,o,t,r),Z.strokeStyle=Ie.text==="GO!"?"#22c55e":Ie.text==="GAME OVER"?"#ef4444":Ie.text==="You fell!"?"#f59e0b":"#3b82f6",Z.lineWidth=2,Z.strokeRect(i,o,t,r),Z.fillStyle="#fff",Z.font="bold 16px sans-serif",Z.textAlign="center";const s=Ie.subtext?o+22:o+26;Z.fillText(Ie.text,i+t/2,s),Ie.subtext&&(Z.fillStyle="#888",Z.font="13px sans-serif",Z.fillText(Ie.subtext,i+t/2,o+44)),Z.textAlign="left"}function Z0(){if(!Z||performance.now()>Hl)return;const n=window.scrollX,e=window.scrollY,t=window.innerWidth,r=window.innerHeight,o=(Hl-performance.now())/um,s=Math.min(.7,o*.9);Z.save(),Z.fillStyle=`rgba(220, 38, 38, ${s*.3})`,Z.fillRect(n,e,t,r);const l=Math.min(1,o*1.5);Z.font="bold 72px sans-serif",Z.textAlign="center",Z.textBaseline="middle",Z.shadowColor="#ff0000",Z.shadowBlur=30,Z.fillStyle=`rgba(255, 255, 255, ${l})`,Z.fillText("NO TAG BACKS",n+t/2,e+r/2),Z.shadowBlur=15,Z.fillText("NO TAG BACKS",n+t/2,e+r/2),Z.restore()}function eA(){if(!c)return;const n=window.scrollX,e=window.scrollY;c.save(),c.fillStyle="rgba(0,0,0,0.8)",c.fillRect(n+10,e+10,200,35),c.fillStyle="#22c55e",c.font="bold 14px sans-serif",c.fillText("BUILD MODE",n+20,e+32),c.fillStyle="#888",c.font="12px sans-serif";const t=So.charAt(0).toUpperCase()+So.slice(1);c.fillText(`Tool: ${t}`,n+115,e+32),c.restore()}function tA(n){var r;if(Se!=="play"||ei)return;let e=document.activeElement;for(;(r=e==null?void 0:e.shadowRoot)!=null&&r.activeElement;)e=e.shadowRoot.activeElement;if(!(e&&(e.tagName==="INPUT"||e.tagName==="TEXTAREA"||e.isContentEditable))){if(Zt[n.code]=!0,n.code==="Tab"||n.code==="KeyL"){n.preventDefault(),et();return}["ArrowUp","ArrowDown","ArrowLeft","ArrowRight","Space"].includes(n.code)&&n.preventDefault()}}function nA(n){Zt[n.code]=!1}let ti=null;function rA(n,e){for(const t of le.checkpoints)if(t.width&&t.height){const r=t.x-t.width/2,i=t.x+t.width/2,o=t.y-t.height,s=t.y;if(n>=r&&n<=i&&e>=o&&e<=s)return t}else if(Math.hypot(n-t.x,e-t.y)<40)return t;return null}function iA(n){if(Se!=="build")return;const e=n.pageX,t=n.pageY,r=rA(e,t);if(r){if(n.button===2||n.shiftKey){le.checkpoints=le.checkpoints.filter(l=>l.id!==r.id),gi(),et();return}ti=r,ve&&(ve.style.cursor="grabbing");return}if(So==="select")return;const i=So;(i==="start"||i==="finish"||i==="spawn")&&(le.checkpoints=le.checkpoints.filter(l=>l.type!==i));const o=i==="start"?0:i==="finish"?999:i==="spawn"?-1:i==="checkpoint"?le.checkpoints.filter(l=>l.type==="checkpoint").length+1:0,s={id:vm(),type:i,x:e,y:t,order:o,reached:!1};i==="trampoline"||i==="speedBoost"||i==="highJump"?(s.width=60,s.height=20):i==="spike"&&(s.width=60,s.height=30),le.checkpoints.push(s),gi(),et()}function oA(n){Se==="build"&&ti&&(ti.x=n.pageX,ti.y=n.pageY,et())}function sA(n){ti&&(gi(),ti=null,ve&&(ve.style.cursor="crosshair"))}function vm(){return Math.random().toString(36).substr(2,9)}async function gi(){const n=mn();localStorage.setItem(`oo_course_${n}`,JSON.stringify(le)),Zs()&&await _I(n,le),console.log("[OpenOverlay] Course saved")}function aA(){const n=mn();kr()&&wI(n,t=>{t.myCourse&&(le=t.myCourse,le.checkpoints.forEach(r=>r.reached=!1),localStorage.setItem(`oo_course_${n}`,JSON.stringify(le))),Co=t.otherCourses.map(r=>({...r,checkpoints:(r.checkpoints||[]).map(i=>({...i,reached:!1}))})),console.log("[OpenOverlay] Course sync: mine=",le.checkpoints.length,"elements, others=",Co.length,"courses"),Se!=="none"&&et()});const e=localStorage.getItem(`oo_course_${n}`);if(e)try{le=JSON.parse(e),le.checkpoints.forEach(t=>t.reached=!1),console.log("[OpenOverlay] Course loaded from localStorage:",le.checkpoints.length,"checkpoints")}catch{console.warn("[OpenOverlay] Failed to load course")}}function mn(){return btoa(window.location.href).slice(0,32)}function _m(){return`oo_scores_${mn()}`}function lA(){const n=new Date;return new Date(n.getFullYear(),n.getMonth(),n.getDate()).getTime()}function wm(){const n=localStorage.getItem(_m());if(!n)return[];try{const e=JSON.parse(n),t=lA();return e.filter(r=>r.timestamp>=t)}catch{return[]}}function vs(n,e){const t=wm();t.push({name:n,time:e,timestamp:Date.now()}),t.sort((r,i)=>r.time-i.time),localStorage.setItem(_m(),JSON.stringify(t)),localStorage.setItem("oo_player_name",n),ho=n}function cA(){const n=wm(),e=n.slice(0,10);let t=null,r=-1;if(ho){const i=n.filter(o=>o.name===ho);i.length>0&&(t=i[0],r=n.findIndex(o=>o.name===ho&&o.time===t.time)+1)}return{top10:e,playerBest:t,playerRank:r}}function uA(){if(console.log("[OpenOverlay] toggleTagMode called, current isTagMode:",Oe),Oe)Oe=!1,Te=!1,Xt=null,Dn=null,gr=0,console.log("[OpenOverlay] Left tag mode"),document.dispatchEvent(new CustomEvent("oo:tagstatechange",{detail:{isTagMode:!1,isIt:!1,gameActive:!1}})),Pt("Left tag game","",1500);else{Oe=!0;const n=mn();console.log("[OpenOverlay] Starting/joining tag game on page:",n);let e=!1;for(const[,t]of It)if(t.isIt){e=!0;break}Te=!e,console.log("[OpenOverlay] localIsIt:",Te,"someoneElseIsIt:",e),document.dispatchEvent(new CustomEvent("oo:tagstatechange",{detail:{isTagMode:!0,isIt:Te,gameActive:!0}})),Ro(),console.log("[OpenOverlay] Forced sync with isIt:",Te),Te?Pt("You're IT!","Tag another player!",2e3):Pt("Tag Mode!","Avoid being tagged!",2e3),mI(n).then(t=>{console.log("[OpenOverlay] startTagGame returned:",t),t&&!Te&&(Te=!0,document.dispatchEvent(new CustomEvent("oo:tagstatechange",{detail:{isTagMode:!0,isIt:!0,gameActive:!0}})))}).catch(t=>{console.log("[OpenOverlay] Firebase unavailable, using local tag state:",Te)})}}if(window.__OPENOVERLAY_V2__)console.log("[OpenOverlay] Already injected, skipping");else{let n=function(){console.log("[OpenOverlay] init() called"),console.log("[OpenOverlay] document.body exists:",!!document.body);try{XE(),bI()}catch(e){console.warn("[OpenOverlay] Firebase init failed (may be incognito):",e)}try{YI(),a0(),AI(),L0(),console.log("[OpenOverlay] Ready!")}catch(e){console.error("[OpenOverlay] UI init error:",e)}};window.__OPENOVERLAY_V2__=!0,console.log("[OpenOverlay] v2.0.0 starting..."),document.body?n():document.readyState==="loading"?document.addEventListener("DOMContentLoaded",n):setTimeout(n,100)}
})()
