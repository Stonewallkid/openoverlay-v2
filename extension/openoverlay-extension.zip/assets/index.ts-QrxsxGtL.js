(function(){const Ym=()=>{};var ch={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const lf=function(n){const e=[];let t=0;for(let r=0;r<n.length;r++){let i=n.charCodeAt(r);i<128?e[t++]=i:i<2048?(e[t++]=i>>6|192,e[t++]=i&63|128):(i&64512)===55296&&r+1<n.length&&(n.charCodeAt(r+1)&64512)===56320?(i=65536+((i&1023)<<10)+(n.charCodeAt(++r)&1023),e[t++]=i>>18|240,e[t++]=i>>12&63|128,e[t++]=i>>6&63|128,e[t++]=i&63|128):(e[t++]=i>>12|224,e[t++]=i>>6&63|128,e[t++]=i&63|128)}return e},Qm=function(n){const e=[];let t=0,r=0;for(;t<n.length;){const i=n[t++];if(i<128)e[r++]=String.fromCharCode(i);else if(i>191&&i<224){const o=n[t++];e[r++]=String.fromCharCode((i&31)<<6|o&63)}else if(i>239&&i<365){const o=n[t++],s=n[t++],l=n[t++],u=((i&7)<<18|(o&63)<<12|(s&63)<<6|l&63)-65536;e[r++]=String.fromCharCode(55296+(u>>10)),e[r++]=String.fromCharCode(56320+(u&1023))}else{const o=n[t++],s=n[t++];e[r++]=String.fromCharCode((i&15)<<12|(o&63)<<6|s&63)}}return e.join("")},cf={byteToCharMap_:null,charToByteMap_:null,byteToCharMapWebSafe_:null,charToByteMapWebSafe_:null,ENCODED_VALS_BASE:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",get ENCODED_VALS(){return this.ENCODED_VALS_BASE+"+/="},get ENCODED_VALS_WEBSAFE(){return this.ENCODED_VALS_BASE+"-_."},HAS_NATIVE_SUPPORT:typeof atob=="function",encodeByteArray(n,e){if(!Array.isArray(n))throw Error("encodeByteArray takes an array as a parameter");this.init_();const t=e?this.byteToCharMapWebSafe_:this.byteToCharMap_,r=[];for(let i=0;i<n.length;i+=3){const o=n[i],s=i+1<n.length,l=s?n[i+1]:0,u=i+2<n.length,h=u?n[i+2]:0,p=o>>2,m=(o&3)<<4|l>>4;let g=(l&15)<<2|h>>6,b=h&63;u||(b=64,s||(g=64)),r.push(t[p],t[m],t[g],t[b])}return r.join("")},encodeString(n,e){return this.HAS_NATIVE_SUPPORT&&!e?btoa(n):this.encodeByteArray(lf(n),e)},decodeString(n,e){return this.HAS_NATIVE_SUPPORT&&!e?atob(n):Qm(this.decodeStringToByteArray(n,e))},decodeStringToByteArray(n,e){this.init_();const t=e?this.charToByteMapWebSafe_:this.charToByteMap_,r=[];for(let i=0;i<n.length;){const o=t[n.charAt(i++)],l=i<n.length?t[n.charAt(i)]:0;++i;const h=i<n.length?t[n.charAt(i)]:64;++i;const m=i<n.length?t[n.charAt(i)]:64;if(++i,o==null||l==null||h==null||m==null)throw new Xm;const g=o<<2|l>>4;if(r.push(g),h!==64){const b=l<<4&240|h>>2;if(r.push(b),m!==64){const P=h<<6&192|m;r.push(P)}}}return r},init_(){if(!this.byteToCharMap_){this.byteToCharMap_={},this.charToByteMap_={},this.byteToCharMapWebSafe_={},this.charToByteMapWebSafe_={};for(let n=0;n<this.ENCODED_VALS.length;n++)this.byteToCharMap_[n]=this.ENCODED_VALS.charAt(n),this.charToByteMap_[this.byteToCharMap_[n]]=n,this.byteToCharMapWebSafe_[n]=this.ENCODED_VALS_WEBSAFE.charAt(n),this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[n]]=n,n>=this.ENCODED_VALS_BASE.length&&(this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(n)]=n,this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(n)]=n)}}};class Xm extends Error{constructor(){super(...arguments),this.name="DecodeBase64StringError"}}const Jm=function(n){const e=lf(n);return cf.encodeByteArray(e,!0)},Ms=function(n){return Jm(n).replace(/\./g,"")},uf=function(n){try{return cf.decodeString(n,!0)}catch(e){console.error("base64Decode failed: ",e)}return null};/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Zm(){if(typeof self<"u")return self;if(typeof window<"u")return window;if(typeof global<"u")return global;throw new Error("Unable to locate global object.")}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ey=()=>Zm().__FIREBASE_DEFAULTS__,ty=()=>{if(typeof process>"u"||typeof ch>"u")return;const n=ch.__FIREBASE_DEFAULTS__;if(n)return JSON.parse(n)},ny=()=>{if(typeof document>"u")return;let n;try{n=document.cookie.match(/__FIREBASE_DEFAULTS__=([^;]+)/)}catch{return}const e=n&&uf(n[1]);return e&&JSON.parse(e)},la=()=>{try{return Ym()||ey()||ty()||ny()}catch(n){console.info(`Unable to get __FIREBASE_DEFAULTS__ due to: ${n}`);return}},hf=n=>{var e,t;return(t=(e=la())==null?void 0:e.emulatorHosts)==null?void 0:t[n]},ry=n=>{const e=hf(n);if(!e)return;const t=e.lastIndexOf(":");if(t<=0||t+1===e.length)throw new Error(`Invalid host ${e} with no separate hostname and port!`);const r=parseInt(e.substring(t+1),10);return e[0]==="["?[e.substring(1,t-1),r]:[e.substring(0,t),r]},df=()=>{var n;return(n=la())==null?void 0:n.config},ff=n=>{var e;return(e=la())==null?void 0:e[`_${n}`]};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class iy{constructor(){this.reject=()=>{},this.resolve=()=>{},this.promise=new Promise((e,t)=>{this.resolve=e,this.reject=t})}wrapCallback(e){return(t,r)=>{t?this.reject(t):this.resolve(r),typeof e=="function"&&(this.promise.catch(()=>{}),e.length===1?e(t):e(t,r))}}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function oy(n,e){if(n.uid)throw new Error('The "uid" field is no longer supported by mockUserToken. Please use "sub" instead for Firebase Auth User ID.');const t={alg:"none",type:"JWT"},r=e||"demo-project",i=n.iat||0,o=n.sub||n.user_id;if(!o)throw new Error("mockUserToken must contain 'sub' or 'user_id' field!");const s={iss:`https://securetoken.google.com/${r}`,aud:r,iat:i,exp:i+3600,auth_time:i,sub:o,user_id:o,firebase:{sign_in_provider:"custom",identities:{}},...n};return[Ms(JSON.stringify(t)),Ms(JSON.stringify(s)),""].join(".")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Xe(){return typeof navigator<"u"&&typeof navigator.userAgent=="string"?navigator.userAgent:""}function sy(){return typeof window<"u"&&!!(window.cordova||window.phonegap||window.PhoneGap)&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i.test(Xe())}function ay(){var e;const n=(e=la())==null?void 0:e.forceEnvironment;if(n==="node")return!0;if(n==="browser")return!1;try{return Object.prototype.toString.call(global.process)==="[object process]"}catch{return!1}}function ly(){return typeof navigator<"u"&&navigator.userAgent==="Cloudflare-Workers"}function cy(){const n=typeof chrome=="object"?chrome.runtime:typeof browser=="object"?browser.runtime:void 0;return typeof n=="object"&&n.id!==void 0}function uy(){return typeof navigator=="object"&&navigator.product==="ReactNative"}function hy(){const n=Xe();return n.indexOf("MSIE ")>=0||n.indexOf("Trident/")>=0}function dy(){return!ay()&&!!navigator.userAgent&&navigator.userAgent.includes("Safari")&&!navigator.userAgent.includes("Chrome")}function fy(){try{return typeof indexedDB=="object"}catch{return!1}}function py(){return new Promise((n,e)=>{try{let t=!0;const r="validate-browser-context-for-indexeddb-analytics-module",i=self.indexedDB.open(r);i.onsuccess=()=>{i.result.close(),t||self.indexedDB.deleteDatabase(r),n(!0)},i.onupgradeneeded=()=>{t=!1},i.onerror=()=>{var o;e(((o=i.error)==null?void 0:o.message)||"")}}catch(t){e(t)}})}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const gy="FirebaseError";class yn extends Error{constructor(e,t,r){super(t),this.code=e,this.customData=r,this.name=gy,Object.setPrototypeOf(this,yn.prototype),Error.captureStackTrace&&Error.captureStackTrace(this,Mo.prototype.create)}}class Mo{constructor(e,t,r){this.service=e,this.serviceName=t,this.errors=r}create(e,...t){const r=t[0]||{},i=`${this.service}/${e}`,o=this.errors[e],s=o?my(o,r):"Error",l=`${this.serviceName}: ${s} (${i}).`;return new yn(i,l,r)}}function my(n,e){return n.replace(yy,(t,r)=>{const i=e[r];return i!=null?String(i):`<${r}?>`})}const yy=/\{\$([^}]+)}/g;function vy(n){for(const e in n)if(Object.prototype.hasOwnProperty.call(n,e))return!1;return!0}function mr(n,e){if(n===e)return!0;const t=Object.keys(n),r=Object.keys(e);for(const i of t){if(!r.includes(i))return!1;const o=n[i],s=e[i];if(uh(o)&&uh(s)){if(!mr(o,s))return!1}else if(o!==s)return!1}for(const i of r)if(!t.includes(i))return!1;return!0}function uh(n){return n!==null&&typeof n=="object"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Lo(n){const e=[];for(const[t,r]of Object.entries(n))Array.isArray(r)?r.forEach(i=>{e.push(encodeURIComponent(t)+"="+encodeURIComponent(i))}):e.push(encodeURIComponent(t)+"="+encodeURIComponent(r));return e.length?"&"+e.join("&"):""}function _y(n,e){const t=new wy(n,e);return t.subscribe.bind(t)}class wy{constructor(e,t){this.observers=[],this.unsubscribes=[],this.observerCount=0,this.task=Promise.resolve(),this.finalized=!1,this.onNoObservers=t,this.task.then(()=>{e(this)}).catch(r=>{this.error(r)})}next(e){this.forEachObserver(t=>{t.next(e)})}error(e){this.forEachObserver(t=>{t.error(e)}),this.close(e)}complete(){this.forEachObserver(e=>{e.complete()}),this.close()}subscribe(e,t,r){let i;if(e===void 0&&t===void 0&&r===void 0)throw new Error("Missing Observer.");by(e,["next","error","complete"])?i=e:i={next:e,error:t,complete:r},i.next===void 0&&(i.next=Ka),i.error===void 0&&(i.error=Ka),i.complete===void 0&&(i.complete=Ka);const o=this.unsubscribeOne.bind(this,this.observers.length);return this.finalized&&this.task.then(()=>{try{this.finalError?i.error(this.finalError):i.complete()}catch{}}),this.observers.push(i),o}unsubscribeOne(e){this.observers===void 0||this.observers[e]===void 0||(delete this.observers[e],this.observerCount-=1,this.observerCount===0&&this.onNoObservers!==void 0&&this.onNoObservers(this))}forEachObserver(e){if(!this.finalized)for(let t=0;t<this.observers.length;t++)this.sendOne(t,e)}sendOne(e,t){this.task.then(()=>{if(this.observers!==void 0&&this.observers[e]!==void 0)try{t(this.observers[e])}catch(r){typeof console<"u"&&console.error&&console.error(r)}})}close(e){this.finalized||(this.finalized=!0,e!==void 0&&(this.finalError=e),this.task.then(()=>{this.observers=void 0,this.onNoObservers=void 0}))}}function by(n,e){if(typeof n!="object"||n===null)return!1;for(const t of e)if(t in n&&typeof n[t]=="function")return!0;return!1}function Ka(){}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function $e(n){return n&&n._delegate?n._delegate:n}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Vo(n){try{return(n.startsWith("http://")||n.startsWith("https://")?new URL(n).hostname:n).endsWith(".cloudworkstations.dev")}catch{return!1}}async function pf(n){return(await fetch(n,{credentials:"include"})).ok}class yr{constructor(e,t,r){this.name=e,this.instanceFactory=t,this.type=r,this.multipleInstances=!1,this.serviceProps={},this.instantiationMode="LAZY",this.onInstanceCreated=null}setInstantiationMode(e){return this.instantiationMode=e,this}setMultipleInstances(e){return this.multipleInstances=e,this}setServiceProps(e){return this.serviceProps=e,this}setInstanceCreatedCallback(e){return this.onInstanceCreated=e,this}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ir="[DEFAULT]";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ty{constructor(e,t){this.name=e,this.container=t,this.component=null,this.instances=new Map,this.instancesDeferred=new Map,this.instancesOptions=new Map,this.onInitCallbacks=new Map}get(e){const t=this.normalizeInstanceIdentifier(e);if(!this.instancesDeferred.has(t)){const r=new iy;if(this.instancesDeferred.set(t,r),this.isInitialized(t)||this.shouldAutoInitialize())try{const i=this.getOrInitializeService({instanceIdentifier:t});i&&r.resolve(i)}catch{}}return this.instancesDeferred.get(t).promise}getImmediate(e){const t=this.normalizeInstanceIdentifier(e==null?void 0:e.identifier),r=(e==null?void 0:e.optional)??!1;if(this.isInitialized(t)||this.shouldAutoInitialize())try{return this.getOrInitializeService({instanceIdentifier:t})}catch(i){if(r)return null;throw i}else{if(r)return null;throw Error(`Service ${this.name} is not available`)}}getComponent(){return this.component}setComponent(e){if(e.name!==this.name)throw Error(`Mismatching Component ${e.name} for Provider ${this.name}.`);if(this.component)throw Error(`Component for ${this.name} has already been provided`);if(this.component=e,!!this.shouldAutoInitialize()){if(Iy(e))try{this.getOrInitializeService({instanceIdentifier:ir})}catch{}for(const[t,r]of this.instancesDeferred.entries()){const i=this.normalizeInstanceIdentifier(t);try{const o=this.getOrInitializeService({instanceIdentifier:i});r.resolve(o)}catch{}}}}clearInstance(e=ir){this.instancesDeferred.delete(e),this.instancesOptions.delete(e),this.instances.delete(e)}async delete(){const e=Array.from(this.instances.values());await Promise.all([...e.filter(t=>"INTERNAL"in t).map(t=>t.INTERNAL.delete()),...e.filter(t=>"_delete"in t).map(t=>t._delete())])}isComponentSet(){return this.component!=null}isInitialized(e=ir){return this.instances.has(e)}getOptions(e=ir){return this.instancesOptions.get(e)||{}}initialize(e={}){const{options:t={}}=e,r=this.normalizeInstanceIdentifier(e.instanceIdentifier);if(this.isInitialized(r))throw Error(`${this.name}(${r}) has already been initialized`);if(!this.isComponentSet())throw Error(`Component ${this.name} has not been registered yet`);const i=this.getOrInitializeService({instanceIdentifier:r,options:t});for(const[o,s]of this.instancesDeferred.entries()){const l=this.normalizeInstanceIdentifier(o);r===l&&s.resolve(i)}return i}onInit(e,t){const r=this.normalizeInstanceIdentifier(t),i=this.onInitCallbacks.get(r)??new Set;i.add(e),this.onInitCallbacks.set(r,i);const o=this.instances.get(r);return o&&e(o,r),()=>{i.delete(e)}}invokeOnInitCallbacks(e,t){const r=this.onInitCallbacks.get(t);if(r)for(const i of r)try{i(e,t)}catch{}}getOrInitializeService({instanceIdentifier:e,options:t={}}){let r=this.instances.get(e);if(!r&&this.component&&(r=this.component.instanceFactory(this.container,{instanceIdentifier:Ey(e),options:t}),this.instances.set(e,r),this.instancesOptions.set(e,t),this.invokeOnInitCallbacks(r,e),this.component.onInstanceCreated))try{this.component.onInstanceCreated(this.container,e,r)}catch{}return r||null}normalizeInstanceIdentifier(e=ir){return this.component?this.component.multipleInstances?e:ir:e}shouldAutoInitialize(){return!!this.component&&this.component.instantiationMode!=="EXPLICIT"}}function Ey(n){return n===ir?void 0:n}function Iy(n){return n.instantiationMode==="EAGER"}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ay{constructor(e){this.name=e,this.providers=new Map}addComponent(e){const t=this.getProvider(e.name);if(t.isComponentSet())throw new Error(`Component ${e.name} has already been registered with ${this.name}`);t.setComponent(e)}addOrOverwriteComponent(e){this.getProvider(e.name).isComponentSet()&&this.providers.delete(e.name),this.addComponent(e)}getProvider(e){if(this.providers.has(e))return this.providers.get(e);const t=new Ty(e,this);return this.providers.set(e,t),t}getProviders(){return Array.from(this.providers.values())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var re;(function(n){n[n.DEBUG=0]="DEBUG",n[n.VERBOSE=1]="VERBOSE",n[n.INFO=2]="INFO",n[n.WARN=3]="WARN",n[n.ERROR=4]="ERROR",n[n.SILENT=5]="SILENT"})(re||(re={}));const Sy={debug:re.DEBUG,verbose:re.VERBOSE,info:re.INFO,warn:re.WARN,error:re.ERROR,silent:re.SILENT},xy=re.INFO,ky={[re.DEBUG]:"log",[re.VERBOSE]:"log",[re.INFO]:"info",[re.WARN]:"warn",[re.ERROR]:"error"},Py=(n,e,...t)=>{if(e<n.logLevel)return;const r=new Date().toISOString(),i=ky[e];if(i)console[i](`[${r}]  ${n.name}:`,...t);else throw new Error(`Attempted to log a message with an invalid logType (value: ${e})`)};class Ql{constructor(e){this.name=e,this._logLevel=xy,this._logHandler=Py,this._userLogHandler=null}get logLevel(){return this._logLevel}set logLevel(e){if(!(e in re))throw new TypeError(`Invalid value "${e}" assigned to \`logLevel\``);this._logLevel=e}setLogLevel(e){this._logLevel=typeof e=="string"?Sy[e]:e}get logHandler(){return this._logHandler}set logHandler(e){if(typeof e!="function")throw new TypeError("Value assigned to `logHandler` must be a function");this._logHandler=e}get userLogHandler(){return this._userLogHandler}set userLogHandler(e){this._userLogHandler=e}debug(...e){this._userLogHandler&&this._userLogHandler(this,re.DEBUG,...e),this._logHandler(this,re.DEBUG,...e)}log(...e){this._userLogHandler&&this._userLogHandler(this,re.VERBOSE,...e),this._logHandler(this,re.VERBOSE,...e)}info(...e){this._userLogHandler&&this._userLogHandler(this,re.INFO,...e),this._logHandler(this,re.INFO,...e)}warn(...e){this._userLogHandler&&this._userLogHandler(this,re.WARN,...e),this._logHandler(this,re.WARN,...e)}error(...e){this._userLogHandler&&this._userLogHandler(this,re.ERROR,...e),this._logHandler(this,re.ERROR,...e)}}const Cy=(n,e)=>e.some(t=>n instanceof t);let hh,dh;function Ry(){return hh||(hh=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction])}function Oy(){return dh||(dh=[IDBCursor.prototype.advance,IDBCursor.prototype.continue,IDBCursor.prototype.continuePrimaryKey])}const gf=new WeakMap,gl=new WeakMap,mf=new WeakMap,Ya=new WeakMap,Xl=new WeakMap;function Ny(n){const e=new Promise((t,r)=>{const i=()=>{n.removeEventListener("success",o),n.removeEventListener("error",s)},o=()=>{t(Mn(n.result)),i()},s=()=>{r(n.error),i()};n.addEventListener("success",o),n.addEventListener("error",s)});return e.then(t=>{t instanceof IDBCursor&&gf.set(t,n)}).catch(()=>{}),Xl.set(e,n),e}function Dy(n){if(gl.has(n))return;const e=new Promise((t,r)=>{const i=()=>{n.removeEventListener("complete",o),n.removeEventListener("error",s),n.removeEventListener("abort",s)},o=()=>{t(),i()},s=()=>{r(n.error||new DOMException("AbortError","AbortError")),i()};n.addEventListener("complete",o),n.addEventListener("error",s),n.addEventListener("abort",s)});gl.set(n,e)}let ml={get(n,e,t){if(n instanceof IDBTransaction){if(e==="done")return gl.get(n);if(e==="objectStoreNames")return n.objectStoreNames||mf.get(n);if(e==="store")return t.objectStoreNames[1]?void 0:t.objectStore(t.objectStoreNames[0])}return Mn(n[e])},set(n,e,t){return n[e]=t,!0},has(n,e){return n instanceof IDBTransaction&&(e==="done"||e==="store")?!0:e in n}};function My(n){ml=n(ml)}function Ly(n){return n===IDBDatabase.prototype.transaction&&!("objectStoreNames"in IDBTransaction.prototype)?function(e,...t){const r=n.call(Qa(this),e,...t);return mf.set(r,e.sort?e.sort():[e]),Mn(r)}:Oy().includes(n)?function(...e){return n.apply(Qa(this),e),Mn(gf.get(this))}:function(...e){return Mn(n.apply(Qa(this),e))}}function Vy(n){return typeof n=="function"?Ly(n):(n instanceof IDBTransaction&&Dy(n),Cy(n,Ry())?new Proxy(n,ml):n)}function Mn(n){if(n instanceof IDBRequest)return Ny(n);if(Ya.has(n))return Ya.get(n);const e=Vy(n);return e!==n&&(Ya.set(n,e),Xl.set(e,n)),e}const Qa=n=>Xl.get(n);function Fy(n,e,{blocked:t,upgrade:r,blocking:i,terminated:o}={}){const s=indexedDB.open(n,e),l=Mn(s);return r&&s.addEventListener("upgradeneeded",u=>{r(Mn(s.result),u.oldVersion,u.newVersion,Mn(s.transaction),u)}),t&&s.addEventListener("blocked",u=>t(u.oldVersion,u.newVersion,u)),l.then(u=>{o&&u.addEventListener("close",()=>o()),i&&u.addEventListener("versionchange",h=>i(h.oldVersion,h.newVersion,h))}).catch(()=>{}),l}const Uy=["get","getKey","getAll","getAllKeys","count"],qy=["put","add","delete","clear"],Xa=new Map;function fh(n,e){if(!(n instanceof IDBDatabase&&!(e in n)&&typeof e=="string"))return;if(Xa.get(e))return Xa.get(e);const t=e.replace(/FromIndex$/,""),r=e!==t,i=qy.includes(t);if(!(t in(r?IDBIndex:IDBObjectStore).prototype)||!(i||Uy.includes(t)))return;const o=async function(s,...l){const u=this.transaction(s,i?"readwrite":"readonly");let h=u.store;return r&&(h=h.index(l.shift())),(await Promise.all([h[t](...l),i&&u.done]))[0]};return Xa.set(e,o),o}My(n=>({...n,get:(e,t,r)=>fh(e,t)||n.get(e,t,r),has:(e,t)=>!!fh(e,t)||n.has(e,t)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class By{constructor(e){this.container=e}getPlatformInfoString(){return this.container.getProviders().map(t=>{if($y(t)){const r=t.getImmediate();return`${r.library}/${r.version}`}else return null}).filter(t=>t).join(" ")}}function $y(n){const e=n.getComponent();return(e==null?void 0:e.type)==="VERSION"}const yl="@firebase/app",ph="0.14.11";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const hn=new Ql("@firebase/app"),jy="@firebase/app-compat",zy="@firebase/analytics-compat",Wy="@firebase/analytics",Hy="@firebase/app-check-compat",Gy="@firebase/app-check",Ky="@firebase/auth",Yy="@firebase/auth-compat",Qy="@firebase/database",Xy="@firebase/data-connect",Jy="@firebase/database-compat",Zy="@firebase/functions",ev="@firebase/functions-compat",tv="@firebase/installations",nv="@firebase/installations-compat",rv="@firebase/messaging",iv="@firebase/messaging-compat",ov="@firebase/performance",sv="@firebase/performance-compat",av="@firebase/remote-config",lv="@firebase/remote-config-compat",cv="@firebase/storage",uv="@firebase/storage-compat",hv="@firebase/firestore",dv="@firebase/ai",fv="@firebase/firestore-compat",pv="firebase",gv="12.12.0";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const vl="[DEFAULT]",mv={[yl]:"fire-core",[jy]:"fire-core-compat",[Wy]:"fire-analytics",[zy]:"fire-analytics-compat",[Gy]:"fire-app-check",[Hy]:"fire-app-check-compat",[Ky]:"fire-auth",[Yy]:"fire-auth-compat",[Qy]:"fire-rtdb",[Xy]:"fire-data-connect",[Jy]:"fire-rtdb-compat",[Zy]:"fire-fn",[ev]:"fire-fn-compat",[tv]:"fire-iid",[nv]:"fire-iid-compat",[rv]:"fire-fcm",[iv]:"fire-fcm-compat",[ov]:"fire-perf",[sv]:"fire-perf-compat",[av]:"fire-rc",[lv]:"fire-rc-compat",[cv]:"fire-gcs",[uv]:"fire-gcs-compat",[hv]:"fire-fst",[fv]:"fire-fst-compat",[dv]:"fire-vertex","fire-js":"fire-js",[pv]:"fire-js-all"};/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const go=new Map,yv=new Map,_l=new Map;function gh(n,e){try{n.container.addComponent(e)}catch(t){hn.debug(`Component ${e.name} failed to register with FirebaseApp ${n.name}`,t)}}function ci(n){const e=n.name;if(_l.has(e))return hn.debug(`There were multiple attempts to register component ${e}.`),!1;_l.set(e,n);for(const t of go.values())gh(t,n);for(const t of yv.values())gh(t,n);return!0}function Jl(n,e){const t=n.container.getProvider("heartbeat").getImmediate({optional:!0});return t&&t.triggerHeartbeat(),n.container.getProvider(e)}function Mt(n){return n==null?!1:n.settings!==void 0}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const vv={"no-app":"No Firebase App '{$appName}' has been created - call initializeApp() first","bad-app-name":"Illegal App name: '{$appName}'","duplicate-app":"Firebase App named '{$appName}' already exists with different options or config","app-deleted":"Firebase App named '{$appName}' already deleted","server-app-deleted":"Firebase Server App has been deleted","no-options":"Need to provide options, when not being deployed to hosting via source.","invalid-app-argument":"firebase.{$appName}() takes either no argument or a Firebase App instance.","invalid-log-argument":"First argument to `onLog` must be null or a function.","idb-open":"Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.","idb-get":"Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.","idb-set":"Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.","idb-delete":"Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}.","finalization-registry-not-supported":"FirebaseServerApp deleteOnDeref field defined but the JS runtime does not support FinalizationRegistry.","invalid-server-app-environment":"FirebaseServerApp is not for use in browser environments."},Ln=new Mo("app","Firebase",vv);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _v{constructor(e,t,r){this._isDeleted=!1,this._options={...e},this._config={...t},this._name=t.name,this._automaticDataCollectionEnabled=t.automaticDataCollectionEnabled,this._container=r,this.container.addComponent(new yr("app",()=>this,"PUBLIC"))}get automaticDataCollectionEnabled(){return this.checkDestroyed(),this._automaticDataCollectionEnabled}set automaticDataCollectionEnabled(e){this.checkDestroyed(),this._automaticDataCollectionEnabled=e}get name(){return this.checkDestroyed(),this._name}get options(){return this.checkDestroyed(),this._options}get config(){return this.checkDestroyed(),this._config}get container(){return this._container}get isDeleted(){return this._isDeleted}set isDeleted(e){this._isDeleted=e}checkDestroyed(){if(this.isDeleted)throw Ln.create("app-deleted",{appName:this._name})}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const wi=gv;function Zl(n,e={}){let t=n;typeof e!="object"&&(e={name:e});const r={name:vl,automaticDataCollectionEnabled:!0,...e},i=r.name;if(typeof i!="string"||!i)throw Ln.create("bad-app-name",{appName:String(i)});if(t||(t=df()),!t)throw Ln.create("no-options");const o=go.get(i);if(o){if(mr(t,o.options)&&mr(r,o.config))return o;throw Ln.create("duplicate-app",{appName:i})}const s=new Ay(i);for(const u of _l.values())s.addComponent(u);const l=new _v(t,r,s);return go.set(i,l),l}function yf(n=vl){const e=go.get(n);if(!e&&n===vl&&df())return Zl();if(!e)throw Ln.create("no-app",{appName:n});return e}function Ls(){return Array.from(go.values())}function Vn(n,e,t){let r=mv[n]??n;t&&(r+=`-${t}`);const i=r.match(/\s|\//),o=e.match(/\s|\//);if(i||o){const s=[`Unable to register library "${r}" with version "${e}":`];i&&s.push(`library name "${r}" contains illegal characters (whitespace or "/")`),i&&o&&s.push("and"),o&&s.push(`version name "${e}" contains illegal characters (whitespace or "/")`),hn.warn(s.join(" "));return}ci(new yr(`${r}-version`,()=>({library:r,version:e}),"VERSION"))}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const wv="firebase-heartbeat-database",bv=1,mo="firebase-heartbeat-store";let Ja=null;function vf(){return Ja||(Ja=Fy(wv,bv,{upgrade:(n,e)=>{switch(e){case 0:try{n.createObjectStore(mo)}catch(t){console.warn(t)}}}}).catch(n=>{throw Ln.create("idb-open",{originalErrorMessage:n.message})})),Ja}async function Tv(n){try{const t=(await vf()).transaction(mo),r=await t.objectStore(mo).get(_f(n));return await t.done,r}catch(e){if(e instanceof yn)hn.warn(e.message);else{const t=Ln.create("idb-get",{originalErrorMessage:e==null?void 0:e.message});hn.warn(t.message)}}}async function mh(n,e){try{const r=(await vf()).transaction(mo,"readwrite");await r.objectStore(mo).put(e,_f(n)),await r.done}catch(t){if(t instanceof yn)hn.warn(t.message);else{const r=Ln.create("idb-set",{originalErrorMessage:t==null?void 0:t.message});hn.warn(r.message)}}}function _f(n){return`${n.name}!${n.options.appId}`}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ev=1024,Iv=30;class Av{constructor(e){this.container=e,this._heartbeatsCache=null;const t=this.container.getProvider("app").getImmediate();this._storage=new xv(t),this._heartbeatsCachePromise=this._storage.read().then(r=>(this._heartbeatsCache=r,r))}async triggerHeartbeat(){var e,t;try{const i=this.container.getProvider("platform-logger").getImmediate().getPlatformInfoString(),o=yh();if(((e=this._heartbeatsCache)==null?void 0:e.heartbeats)==null&&(this._heartbeatsCache=await this._heartbeatsCachePromise,((t=this._heartbeatsCache)==null?void 0:t.heartbeats)==null)||this._heartbeatsCache.lastSentHeartbeatDate===o||this._heartbeatsCache.heartbeats.some(s=>s.date===o))return;if(this._heartbeatsCache.heartbeats.push({date:o,agent:i}),this._heartbeatsCache.heartbeats.length>Iv){const s=kv(this._heartbeatsCache.heartbeats);this._heartbeatsCache.heartbeats.splice(s,1)}return this._storage.overwrite(this._heartbeatsCache)}catch(r){hn.warn(r)}}async getHeartbeatsHeader(){var e;try{if(this._heartbeatsCache===null&&await this._heartbeatsCachePromise,((e=this._heartbeatsCache)==null?void 0:e.heartbeats)==null||this._heartbeatsCache.heartbeats.length===0)return"";const t=yh(),{heartbeatsToSend:r,unsentEntries:i}=Sv(this._heartbeatsCache.heartbeats),o=Ms(JSON.stringify({version:2,heartbeats:r}));return this._heartbeatsCache.lastSentHeartbeatDate=t,i.length>0?(this._heartbeatsCache.heartbeats=i,await this._storage.overwrite(this._heartbeatsCache)):(this._heartbeatsCache.heartbeats=[],this._storage.overwrite(this._heartbeatsCache)),o}catch(t){return hn.warn(t),""}}}function yh(){return new Date().toISOString().substring(0,10)}function Sv(n,e=Ev){const t=[];let r=n.slice();for(const i of n){const o=t.find(s=>s.agent===i.agent);if(o){if(o.dates.push(i.date),vh(t)>e){o.dates.pop();break}}else if(t.push({agent:i.agent,dates:[i.date]}),vh(t)>e){t.pop();break}r=r.slice(1)}return{heartbeatsToSend:t,unsentEntries:r}}class xv{constructor(e){this.app=e,this._canUseIndexedDBPromise=this.runIndexedDBEnvironmentCheck()}async runIndexedDBEnvironmentCheck(){return fy()?py().then(()=>!0).catch(()=>!1):!1}async read(){if(await this._canUseIndexedDBPromise){const t=await Tv(this.app);return t!=null&&t.heartbeats?t:{heartbeats:[]}}else return{heartbeats:[]}}async overwrite(e){if(await this._canUseIndexedDBPromise){const r=await this.read();return mh(this.app,{lastSentHeartbeatDate:e.lastSentHeartbeatDate??r.lastSentHeartbeatDate,heartbeats:e.heartbeats})}else return}async add(e){if(await this._canUseIndexedDBPromise){const r=await this.read();return mh(this.app,{lastSentHeartbeatDate:e.lastSentHeartbeatDate??r.lastSentHeartbeatDate,heartbeats:[...r.heartbeats,...e.heartbeats]})}else return}}function vh(n){return Ms(JSON.stringify({version:2,heartbeats:n})).length}function kv(n){if(n.length===0)return-1;let e=0,t=n[0].date;for(let r=1;r<n.length;r++)n[r].date<t&&(t=n[r].date,e=r);return e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Pv(n){ci(new yr("platform-logger",e=>new By(e),"PRIVATE")),ci(new yr("heartbeat",e=>new Av(e),"PRIVATE")),Vn(yl,ph,n),Vn(yl,ph,"esm2020"),Vn("fire-js","")}Pv("");var Cv="firebase",Rv="12.12.1";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */Vn(Cv,Rv,"app");function wf(){return{"dependent-sdk-initialized-before-auth":"Another Firebase SDK was initialized and is trying to use Auth before Auth is initialized. Please be sure to call `initializeAuth` or `getAuth` before starting any other Firebase SDK."}}const Ov=wf,bf=new Mo("auth","Firebase",wf());/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Vs=new Ql("@firebase/auth");function Nv(n,...e){Vs.logLevel<=re.WARN&&Vs.warn(`Auth (${wi}): ${n}`,...e)}function bs(n,...e){Vs.logLevel<=re.ERROR&&Vs.error(`Auth (${wi}): ${n}`,...e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function dn(n,...e){throw ec(n,...e)}function qt(n,...e){return ec(n,...e)}function Tf(n,e,t){const r={...Ov(),[e]:t};return new Mo("auth","Firebase",r).create(e,{appName:n.name})}function hr(n){return Tf(n,"operation-not-supported-in-this-environment","Operations that alter the current user are not supported in conjunction with FirebaseServerApp")}function ec(n,...e){if(typeof n!="string"){const t=e[0],r=[...e.slice(1)];return r[0]&&(r[0].appName=n.name),n._errorFactory.create(t,...r)}return bf.create(n,...e)}function Q(n,e,...t){if(!n)throw ec(e,...t)}function nn(n){const e="INTERNAL ASSERTION FAILED: "+n;throw bs(e),new Error(e)}function fn(n,e){n||nn(e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function wl(){var n;return typeof self<"u"&&((n=self.location)==null?void 0:n.href)||""}function Dv(){return _h()==="http:"||_h()==="https:"}function _h(){var n;return typeof self<"u"&&((n=self.location)==null?void 0:n.protocol)||null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Mv(){return typeof navigator<"u"&&navigator&&"onLine"in navigator&&typeof navigator.onLine=="boolean"&&(Dv()||cy()||"connection"in navigator)?navigator.onLine:!0}function Lv(){if(typeof navigator>"u")return null;const n=navigator;return n.languages&&n.languages[0]||n.language||null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Fo{constructor(e,t){this.shortDelay=e,this.longDelay=t,fn(t>e,"Short delay should be less than long delay!"),this.isMobile=sy()||uy()}get(){return Mv()?this.isMobile?this.longDelay:this.shortDelay:Math.min(5e3,this.shortDelay)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function tc(n,e){fn(n.emulator,"Emulator should always be set here");const{url:t}=n.emulator;return e?`${t}${e.startsWith("/")?e.slice(1):e}`:t}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ef{static initialize(e,t,r){this.fetchImpl=e,t&&(this.headersImpl=t),r&&(this.responseImpl=r)}static fetch(){if(this.fetchImpl)return this.fetchImpl;if(typeof self<"u"&&"fetch"in self)return self.fetch;if(typeof globalThis<"u"&&globalThis.fetch)return globalThis.fetch;if(typeof fetch<"u")return fetch;nn("Could not find fetch implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static headers(){if(this.headersImpl)return this.headersImpl;if(typeof self<"u"&&"Headers"in self)return self.Headers;if(typeof globalThis<"u"&&globalThis.Headers)return globalThis.Headers;if(typeof Headers<"u")return Headers;nn("Could not find Headers implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static response(){if(this.responseImpl)return this.responseImpl;if(typeof self<"u"&&"Response"in self)return self.Response;if(typeof globalThis<"u"&&globalThis.Response)return globalThis.Response;if(typeof Response<"u")return Response;nn("Could not find Response implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Vv={CREDENTIAL_MISMATCH:"custom-token-mismatch",MISSING_CUSTOM_TOKEN:"internal-error",INVALID_IDENTIFIER:"invalid-email",MISSING_CONTINUE_URI:"internal-error",INVALID_PASSWORD:"wrong-password",MISSING_PASSWORD:"missing-password",INVALID_LOGIN_CREDENTIALS:"invalid-credential",EMAIL_EXISTS:"email-already-in-use",PASSWORD_LOGIN_DISABLED:"operation-not-allowed",INVALID_IDP_RESPONSE:"invalid-credential",INVALID_PENDING_TOKEN:"invalid-credential",FEDERATED_USER_ID_ALREADY_LINKED:"credential-already-in-use",MISSING_REQ_TYPE:"internal-error",EMAIL_NOT_FOUND:"user-not-found",RESET_PASSWORD_EXCEED_LIMIT:"too-many-requests",EXPIRED_OOB_CODE:"expired-action-code",INVALID_OOB_CODE:"invalid-action-code",MISSING_OOB_CODE:"internal-error",CREDENTIAL_TOO_OLD_LOGIN_AGAIN:"requires-recent-login",INVALID_ID_TOKEN:"invalid-user-token",TOKEN_EXPIRED:"user-token-expired",USER_NOT_FOUND:"user-token-expired",TOO_MANY_ATTEMPTS_TRY_LATER:"too-many-requests",PASSWORD_DOES_NOT_MEET_REQUIREMENTS:"password-does-not-meet-requirements",INVALID_CODE:"invalid-verification-code",INVALID_SESSION_INFO:"invalid-verification-id",INVALID_TEMPORARY_PROOF:"invalid-credential",MISSING_SESSION_INFO:"missing-verification-id",SESSION_EXPIRED:"code-expired",MISSING_ANDROID_PACKAGE_NAME:"missing-android-pkg-name",UNAUTHORIZED_DOMAIN:"unauthorized-continue-uri",INVALID_OAUTH_CLIENT_ID:"invalid-oauth-client-id",ADMIN_ONLY_OPERATION:"admin-restricted-operation",INVALID_MFA_PENDING_CREDENTIAL:"invalid-multi-factor-session",MFA_ENROLLMENT_NOT_FOUND:"multi-factor-info-not-found",MISSING_MFA_ENROLLMENT_ID:"missing-multi-factor-info",MISSING_MFA_PENDING_CREDENTIAL:"missing-multi-factor-session",SECOND_FACTOR_EXISTS:"second-factor-already-in-use",SECOND_FACTOR_LIMIT_EXCEEDED:"maximum-second-factor-count-exceeded",BLOCKING_FUNCTION_ERROR_RESPONSE:"internal-error",RECAPTCHA_NOT_ENABLED:"recaptcha-not-enabled",MISSING_RECAPTCHA_TOKEN:"missing-recaptcha-token",INVALID_RECAPTCHA_TOKEN:"invalid-recaptcha-token",INVALID_RECAPTCHA_ACTION:"invalid-recaptcha-action",MISSING_CLIENT_TYPE:"missing-client-type",MISSING_RECAPTCHA_VERSION:"missing-recaptcha-version",INVALID_RECAPTCHA_VERSION:"invalid-recaptcha-version",INVALID_REQ_TYPE:"invalid-req-type"};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Fv=["/v1/accounts:signInWithCustomToken","/v1/accounts:signInWithEmailLink","/v1/accounts:signInWithIdp","/v1/accounts:signInWithPassword","/v1/accounts:signInWithPhoneNumber","/v1/token"],Uv=new Fo(3e4,6e4);function nc(n,e){return n.tenantId&&!e.tenantId?{...e,tenantId:n.tenantId}:e}async function bi(n,e,t,r,i={}){return If(n,i,async()=>{let o={},s={};r&&(e==="GET"?s=r:o={body:JSON.stringify(r)});const l=Lo({key:n.config.apiKey,...s}).slice(1),u=await n._getAdditionalHeaders();u["Content-Type"]="application/json",n.languageCode&&(u["X-Firebase-Locale"]=n.languageCode);const h={method:e,headers:u,...o};return ly()||(h.referrerPolicy="no-referrer"),n.emulatorConfig&&Vo(n.emulatorConfig.host)&&(h.credentials="include"),Ef.fetch()(await Af(n,n.config.apiHost,t,l),h)})}async function If(n,e,t){n._canInitEmulator=!1;const r={...Vv,...e};try{const i=new Bv(n),o=await Promise.race([t(),i.promise]);i.clearNetworkTimeout();const s=await o.json();if("needConfirmation"in s)throw as(n,"account-exists-with-different-credential",s);if(o.ok&&!("errorMessage"in s))return s;{const l=o.ok?s.errorMessage:s.error.message,[u,h]=l.split(" : ");if(u==="FEDERATED_USER_ID_ALREADY_LINKED")throw as(n,"credential-already-in-use",s);if(u==="EMAIL_EXISTS")throw as(n,"email-already-in-use",s);if(u==="USER_DISABLED")throw as(n,"user-disabled",s);const p=r[u]||u.toLowerCase().replace(/[_\s]+/g,"-");if(h)throw Tf(n,p,h);dn(n,p)}}catch(i){if(i instanceof yn)throw i;dn(n,"network-request-failed",{message:String(i)})}}async function qv(n,e,t,r,i={}){const o=await bi(n,e,t,r,i);return"mfaPendingCredential"in o&&dn(n,"multi-factor-auth-required",{_serverResponse:o}),o}async function Af(n,e,t,r){const i=`${e}${t}?${r}`,o=n,s=o.config.emulator?tc(n.config,i):`${n.config.apiScheme}://${i}`;return Fv.includes(t)&&(await o._persistenceManagerAvailable,o._getPersistenceType()==="COOKIE")?o._getPersistence()._getFinalTarget(s).toString():s}class Bv{clearNetworkTimeout(){clearTimeout(this.timer)}constructor(e){this.auth=e,this.timer=null,this.promise=new Promise((t,r)=>{this.timer=setTimeout(()=>r(qt(this.auth,"network-request-failed")),Uv.get())})}}function as(n,e,t){const r={appName:n.name};t.email&&(r.email=t.email),t.phoneNumber&&(r.phoneNumber=t.phoneNumber);const i=qt(n,e,r);return i.customData._tokenResponse=t,i}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function $v(n,e){return bi(n,"POST","/v1/accounts:delete",e)}async function Fs(n,e){return bi(n,"POST","/v1/accounts:lookup",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function oo(n){if(n)try{const e=new Date(Number(n));if(!isNaN(e.getTime()))return e.toUTCString()}catch{}}async function jv(n,e=!1){const t=$e(n),r=await t.getIdToken(e),i=rc(r);Q(i&&i.exp&&i.auth_time&&i.iat,t.auth,"internal-error");const o=typeof i.firebase=="object"?i.firebase:void 0,s=o==null?void 0:o.sign_in_provider;return{claims:i,token:r,authTime:oo(Za(i.auth_time)),issuedAtTime:oo(Za(i.iat)),expirationTime:oo(Za(i.exp)),signInProvider:s||null,signInSecondFactor:(o==null?void 0:o.sign_in_second_factor)||null}}function Za(n){return Number(n)*1e3}function rc(n){const[e,t,r]=n.split(".");if(e===void 0||t===void 0||r===void 0)return bs("JWT malformed, contained fewer than 3 sections"),null;try{const i=uf(t);return i?JSON.parse(i):(bs("Failed to decode base64 JWT payload"),null)}catch(i){return bs("Caught error parsing JWT payload as JSON",i==null?void 0:i.toString()),null}}function wh(n){const e=rc(n);return Q(e,"internal-error"),Q(typeof e.exp<"u","internal-error"),Q(typeof e.iat<"u","internal-error"),Number(e.exp)-Number(e.iat)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function yo(n,e,t=!1){if(t)return e;try{return await e}catch(r){throw r instanceof yn&&zv(r)&&n.auth.currentUser===n&&await n.auth.signOut(),r}}function zv({code:n}){return n==="auth/user-disabled"||n==="auth/user-token-expired"}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Wv{constructor(e){this.user=e,this.isRunning=!1,this.timerId=null,this.errorBackoff=3e4}_start(){this.isRunning||(this.isRunning=!0,this.schedule())}_stop(){this.isRunning&&(this.isRunning=!1,this.timerId!==null&&clearTimeout(this.timerId))}getInterval(e){if(e){const t=this.errorBackoff;return this.errorBackoff=Math.min(this.errorBackoff*2,96e4),t}else{this.errorBackoff=3e4;const r=(this.user.stsTokenManager.expirationTime??0)-Date.now()-3e5;return Math.max(0,r)}}schedule(e=!1){if(!this.isRunning)return;const t=this.getInterval(e);this.timerId=setTimeout(async()=>{await this.iteration()},t)}async iteration(){try{await this.user.getIdToken(!0)}catch(e){(e==null?void 0:e.code)==="auth/network-request-failed"&&this.schedule(!0);return}this.schedule()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class bl{constructor(e,t){this.createdAt=e,this.lastLoginAt=t,this._initializeTime()}_initializeTime(){this.lastSignInTime=oo(this.lastLoginAt),this.creationTime=oo(this.createdAt)}_copy(e){this.createdAt=e.createdAt,this.lastLoginAt=e.lastLoginAt,this._initializeTime()}toJSON(){return{createdAt:this.createdAt,lastLoginAt:this.lastLoginAt}}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Us(n){var m;const e=n.auth,t=await n.getIdToken(),r=await yo(n,Fs(e,{idToken:t}));Q(r==null?void 0:r.users.length,e,"internal-error");const i=r.users[0];n._notifyReloadListener(i);const o=(m=i.providerUserInfo)!=null&&m.length?Sf(i.providerUserInfo):[],s=Gv(n.providerData,o),l=n.isAnonymous,u=!(n.email&&i.passwordHash)&&!(s!=null&&s.length),h=l?u:!1,p={uid:i.localId,displayName:i.displayName||null,photoURL:i.photoUrl||null,email:i.email||null,emailVerified:i.emailVerified||!1,phoneNumber:i.phoneNumber||null,tenantId:i.tenantId||null,providerData:s,metadata:new bl(i.createdAt,i.lastLoginAt),isAnonymous:h};Object.assign(n,p)}async function Hv(n){const e=$e(n);await Us(e),await e.auth._persistUserIfCurrent(e),e.auth._notifyListenersIfCurrent(e)}function Gv(n,e){return[...n.filter(r=>!e.some(i=>i.providerId===r.providerId)),...e]}function Sf(n){return n.map(({providerId:e,...t})=>({providerId:e,uid:t.rawId||"",displayName:t.displayName||null,email:t.email||null,phoneNumber:t.phoneNumber||null,photoURL:t.photoUrl||null}))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Kv(n,e){const t=await If(n,{},async()=>{const r=Lo({grant_type:"refresh_token",refresh_token:e}).slice(1),{tokenApiHost:i,apiKey:o}=n.config,s=await Af(n,i,"/v1/token",`key=${o}`),l=await n._getAdditionalHeaders();l["Content-Type"]="application/x-www-form-urlencoded";const u={method:"POST",headers:l,body:r};return n.emulatorConfig&&Vo(n.emulatorConfig.host)&&(u.credentials="include"),Ef.fetch()(s,u)});return{accessToken:t.access_token,expiresIn:t.expires_in,refreshToken:t.refresh_token}}async function Yv(n,e){return bi(n,"POST","/v2/accounts:revokeToken",nc(n,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Yr{constructor(){this.refreshToken=null,this.accessToken=null,this.expirationTime=null}get isExpired(){return!this.expirationTime||Date.now()>this.expirationTime-3e4}updateFromServerResponse(e){Q(e.idToken,"internal-error"),Q(typeof e.idToken<"u","internal-error"),Q(typeof e.refreshToken<"u","internal-error");const t="expiresIn"in e&&typeof e.expiresIn<"u"?Number(e.expiresIn):wh(e.idToken);this.updateTokensAndExpiration(e.idToken,e.refreshToken,t)}updateFromIdToken(e){Q(e.length!==0,"internal-error");const t=wh(e);this.updateTokensAndExpiration(e,null,t)}async getToken(e,t=!1){return!t&&this.accessToken&&!this.isExpired?this.accessToken:(Q(this.refreshToken,e,"user-token-expired"),this.refreshToken?(await this.refresh(e,this.refreshToken),this.accessToken):null)}clearRefreshToken(){this.refreshToken=null}async refresh(e,t){const{accessToken:r,refreshToken:i,expiresIn:o}=await Kv(e,t);this.updateTokensAndExpiration(r,i,Number(o))}updateTokensAndExpiration(e,t,r){this.refreshToken=t||null,this.accessToken=e||null,this.expirationTime=Date.now()+r*1e3}static fromJSON(e,t){const{refreshToken:r,accessToken:i,expirationTime:o}=t,s=new Yr;return r&&(Q(typeof r=="string","internal-error",{appName:e}),s.refreshToken=r),i&&(Q(typeof i=="string","internal-error",{appName:e}),s.accessToken=i),o&&(Q(typeof o=="number","internal-error",{appName:e}),s.expirationTime=o),s}toJSON(){return{refreshToken:this.refreshToken,accessToken:this.accessToken,expirationTime:this.expirationTime}}_assign(e){this.accessToken=e.accessToken,this.refreshToken=e.refreshToken,this.expirationTime=e.expirationTime}_clone(){return Object.assign(new Yr,this.toJSON())}_performRefresh(){return nn("not implemented")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Sn(n,e){Q(typeof n=="string"||typeof n>"u","internal-error",{appName:e})}class Et{constructor({uid:e,auth:t,stsTokenManager:r,...i}){this.providerId="firebase",this.proactiveRefresh=new Wv(this),this.reloadUserInfo=null,this.reloadListener=null,this.uid=e,this.auth=t,this.stsTokenManager=r,this.accessToken=r.accessToken,this.displayName=i.displayName||null,this.email=i.email||null,this.emailVerified=i.emailVerified||!1,this.phoneNumber=i.phoneNumber||null,this.photoURL=i.photoURL||null,this.isAnonymous=i.isAnonymous||!1,this.tenantId=i.tenantId||null,this.providerData=i.providerData?[...i.providerData]:[],this.metadata=new bl(i.createdAt||void 0,i.lastLoginAt||void 0)}async getIdToken(e){const t=await yo(this,this.stsTokenManager.getToken(this.auth,e));return Q(t,this.auth,"internal-error"),this.accessToken!==t&&(this.accessToken=t,await this.auth._persistUserIfCurrent(this),this.auth._notifyListenersIfCurrent(this)),t}getIdTokenResult(e){return jv(this,e)}reload(){return Hv(this)}_assign(e){this!==e&&(Q(this.uid===e.uid,this.auth,"internal-error"),this.displayName=e.displayName,this.photoURL=e.photoURL,this.email=e.email,this.emailVerified=e.emailVerified,this.phoneNumber=e.phoneNumber,this.isAnonymous=e.isAnonymous,this.tenantId=e.tenantId,this.providerData=e.providerData.map(t=>({...t})),this.metadata._copy(e.metadata),this.stsTokenManager._assign(e.stsTokenManager))}_clone(e){const t=new Et({...this,auth:e,stsTokenManager:this.stsTokenManager._clone()});return t.metadata._copy(this.metadata),t}_onReload(e){Q(!this.reloadListener,this.auth,"internal-error"),this.reloadListener=e,this.reloadUserInfo&&(this._notifyReloadListener(this.reloadUserInfo),this.reloadUserInfo=null)}_notifyReloadListener(e){this.reloadListener?this.reloadListener(e):this.reloadUserInfo=e}_startProactiveRefresh(){this.proactiveRefresh._start()}_stopProactiveRefresh(){this.proactiveRefresh._stop()}async _updateTokensIfNecessary(e,t=!1){let r=!1;e.idToken&&e.idToken!==this.stsTokenManager.accessToken&&(this.stsTokenManager.updateFromServerResponse(e),r=!0),t&&await Us(this),await this.auth._persistUserIfCurrent(this),r&&this.auth._notifyListenersIfCurrent(this)}async delete(){if(Mt(this.auth.app))return Promise.reject(hr(this.auth));const e=await this.getIdToken();return await yo(this,$v(this.auth,{idToken:e})),this.stsTokenManager.clearRefreshToken(),this.auth.signOut()}toJSON(){return{uid:this.uid,email:this.email||void 0,emailVerified:this.emailVerified,displayName:this.displayName||void 0,isAnonymous:this.isAnonymous,photoURL:this.photoURL||void 0,phoneNumber:this.phoneNumber||void 0,tenantId:this.tenantId||void 0,providerData:this.providerData.map(e=>({...e})),stsTokenManager:this.stsTokenManager.toJSON(),_redirectEventId:this._redirectEventId,...this.metadata.toJSON(),apiKey:this.auth.config.apiKey,appName:this.auth.name}}get refreshToken(){return this.stsTokenManager.refreshToken||""}static _fromJSON(e,t){const r=t.displayName??void 0,i=t.email??void 0,o=t.phoneNumber??void 0,s=t.photoURL??void 0,l=t.tenantId??void 0,u=t._redirectEventId??void 0,h=t.createdAt??void 0,p=t.lastLoginAt??void 0,{uid:m,emailVerified:g,isAnonymous:b,providerData:P,stsTokenManager:A}=t;Q(m&&A,e,"internal-error");const O=Yr.fromJSON(this.name,A);Q(typeof m=="string",e,"internal-error"),Sn(r,e.name),Sn(i,e.name),Q(typeof g=="boolean",e,"internal-error"),Q(typeof b=="boolean",e,"internal-error"),Sn(o,e.name),Sn(s,e.name),Sn(l,e.name),Sn(u,e.name),Sn(h,e.name),Sn(p,e.name);const F=new Et({uid:m,auth:e,email:i,emailVerified:g,displayName:r,isAnonymous:b,photoURL:s,phoneNumber:o,tenantId:l,stsTokenManager:O,createdAt:h,lastLoginAt:p});return P&&Array.isArray(P)&&(F.providerData=P.map(U=>({...U}))),u&&(F._redirectEventId=u),F}static async _fromIdTokenResponse(e,t,r=!1){const i=new Yr;i.updateFromServerResponse(t);const o=new Et({uid:t.localId,auth:e,stsTokenManager:i,isAnonymous:r});return await Us(o),o}static async _fromGetAccountInfoResponse(e,t,r){const i=t.users[0];Q(i.localId!==void 0,"internal-error");const o=i.providerUserInfo!==void 0?Sf(i.providerUserInfo):[],s=!(i.email&&i.passwordHash)&&!(o!=null&&o.length),l=new Yr;l.updateFromIdToken(r);const u=new Et({uid:i.localId,auth:e,stsTokenManager:l,isAnonymous:s}),h={uid:i.localId,displayName:i.displayName||null,photoURL:i.photoUrl||null,email:i.email||null,emailVerified:i.emailVerified||!1,phoneNumber:i.phoneNumber||null,tenantId:i.tenantId||null,providerData:o,metadata:new bl(i.createdAt,i.lastLoginAt),isAnonymous:!(i.email&&i.passwordHash)&&!(o!=null&&o.length)};return Object.assign(u,h),u}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const bh=new Map;function rn(n){fn(n instanceof Function,"Expected a class definition");let e=bh.get(n);return e?(fn(e instanceof n,"Instance stored in cache mismatched with class"),e):(e=new n,bh.set(n,e),e)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xf{constructor(){this.type="NONE",this.storage={}}async _isAvailable(){return!0}async _set(e,t){this.storage[e]=t}async _get(e){const t=this.storage[e];return t===void 0?null:t}async _remove(e){delete this.storage[e]}_addListener(e,t){}_removeListener(e,t){}}xf.type="NONE";const Th=xf;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ts(n,e,t){return`firebase:${n}:${e}:${t}`}class Qr{constructor(e,t,r){this.persistence=e,this.auth=t,this.userKey=r;const{config:i,name:o}=this.auth;this.fullUserKey=Ts(this.userKey,i.apiKey,o),this.fullPersistenceKey=Ts("persistence",i.apiKey,o),this.boundEventHandler=t._onStorageEvent.bind(t),this.persistence._addListener(this.fullUserKey,this.boundEventHandler)}setCurrentUser(e){return this.persistence._set(this.fullUserKey,e.toJSON())}async getCurrentUser(){const e=await this.persistence._get(this.fullUserKey);if(!e)return null;if(typeof e=="string"){const t=await Fs(this.auth,{idToken:e}).catch(()=>{});return t?Et._fromGetAccountInfoResponse(this.auth,t,e):null}return Et._fromJSON(this.auth,e)}removeCurrentUser(){return this.persistence._remove(this.fullUserKey)}savePersistenceForRedirect(){return this.persistence._set(this.fullPersistenceKey,this.persistence.type)}async setPersistence(e){if(this.persistence===e)return;const t=await this.getCurrentUser();if(await this.removeCurrentUser(),this.persistence=e,t)return this.setCurrentUser(t)}delete(){this.persistence._removeListener(this.fullUserKey,this.boundEventHandler)}static async create(e,t,r="authUser"){if(!t.length)return new Qr(rn(Th),e,r);const i=(await Promise.all(t.map(async h=>{if(await h._isAvailable())return h}))).filter(h=>h);let o=i[0]||rn(Th);const s=Ts(r,e.config.apiKey,e.name);let l=null;for(const h of t)try{const p=await h._get(s);if(p){let m;if(typeof p=="string"){const g=await Fs(e,{idToken:p}).catch(()=>{});if(!g)break;m=await Et._fromGetAccountInfoResponse(e,g,p)}else m=Et._fromJSON(e,p);h!==o&&(l=m),o=h;break}}catch{}const u=i.filter(h=>h._shouldAllowMigration);return!o._shouldAllowMigration||!u.length?new Qr(o,e,r):(o=u[0],l&&await o._set(s,l.toJSON()),await Promise.all(t.map(async h=>{if(h!==o)try{await h._remove(s)}catch{}})),new Qr(o,e,r))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Eh(n){const e=n.toLowerCase();if(e.includes("opera/")||e.includes("opr/")||e.includes("opios/"))return"Opera";if(Rf(e))return"IEMobile";if(e.includes("msie")||e.includes("trident/"))return"IE";if(e.includes("edge/"))return"Edge";if(kf(e))return"Firefox";if(e.includes("silk/"))return"Silk";if(Nf(e))return"Blackberry";if(Df(e))return"Webos";if(Pf(e))return"Safari";if((e.includes("chrome/")||Cf(e))&&!e.includes("edge/"))return"Chrome";if(Of(e))return"Android";{const t=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,r=n.match(t);if((r==null?void 0:r.length)===2)return r[1]}return"Other"}function kf(n=Xe()){return/firefox\//i.test(n)}function Pf(n=Xe()){const e=n.toLowerCase();return e.includes("safari/")&&!e.includes("chrome/")&&!e.includes("crios/")&&!e.includes("android")}function Cf(n=Xe()){return/crios\//i.test(n)}function Rf(n=Xe()){return/iemobile/i.test(n)}function Of(n=Xe()){return/android/i.test(n)}function Nf(n=Xe()){return/blackberry/i.test(n)}function Df(n=Xe()){return/webos/i.test(n)}function ic(n=Xe()){return/iphone|ipad|ipod/i.test(n)||/macintosh/i.test(n)&&/mobile/i.test(n)}function Qv(n=Xe()){var e;return ic(n)&&!!((e=window.navigator)!=null&&e.standalone)}function Xv(){return hy()&&document.documentMode===10}function Mf(n=Xe()){return ic(n)||Of(n)||Df(n)||Nf(n)||/windows phone/i.test(n)||Rf(n)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Lf(n,e=[]){let t;switch(n){case"Browser":t=Eh(Xe());break;case"Worker":t=`${Eh(Xe())}-${n}`;break;default:t=n}const r=e.length?e.join(","):"FirebaseCore-web";return`${t}/JsCore/${wi}/${r}`}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Jv{constructor(e){this.auth=e,this.queue=[]}pushCallback(e,t){const r=o=>new Promise((s,l)=>{try{const u=e(o);s(u)}catch(u){l(u)}});r.onAbort=t,this.queue.push(r);const i=this.queue.length-1;return()=>{this.queue[i]=()=>Promise.resolve()}}async runMiddleware(e){if(this.auth.currentUser===e)return;const t=[];try{for(const r of this.queue)await r(e),r.onAbort&&t.push(r.onAbort)}catch(r){t.reverse();for(const i of t)try{i()}catch{}throw this.auth._errorFactory.create("login-blocked",{originalMessage:r==null?void 0:r.message})}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Zv(n,e={}){return bi(n,"GET","/v2/passwordPolicy",nc(n,e))}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const e_=6;class t_{constructor(e){var r;const t=e.customStrengthOptions;this.customStrengthOptions={},this.customStrengthOptions.minPasswordLength=t.minPasswordLength??e_,t.maxPasswordLength&&(this.customStrengthOptions.maxPasswordLength=t.maxPasswordLength),t.containsLowercaseCharacter!==void 0&&(this.customStrengthOptions.containsLowercaseLetter=t.containsLowercaseCharacter),t.containsUppercaseCharacter!==void 0&&(this.customStrengthOptions.containsUppercaseLetter=t.containsUppercaseCharacter),t.containsNumericCharacter!==void 0&&(this.customStrengthOptions.containsNumericCharacter=t.containsNumericCharacter),t.containsNonAlphanumericCharacter!==void 0&&(this.customStrengthOptions.containsNonAlphanumericCharacter=t.containsNonAlphanumericCharacter),this.enforcementState=e.enforcementState,this.enforcementState==="ENFORCEMENT_STATE_UNSPECIFIED"&&(this.enforcementState="OFF"),this.allowedNonAlphanumericCharacters=((r=e.allowedNonAlphanumericCharacters)==null?void 0:r.join(""))??"",this.forceUpgradeOnSignin=e.forceUpgradeOnSignin??!1,this.schemaVersion=e.schemaVersion}validatePassword(e){const t={isValid:!0,passwordPolicy:this};return this.validatePasswordLengthOptions(e,t),this.validatePasswordCharacterOptions(e,t),t.isValid&&(t.isValid=t.meetsMinPasswordLength??!0),t.isValid&&(t.isValid=t.meetsMaxPasswordLength??!0),t.isValid&&(t.isValid=t.containsLowercaseLetter??!0),t.isValid&&(t.isValid=t.containsUppercaseLetter??!0),t.isValid&&(t.isValid=t.containsNumericCharacter??!0),t.isValid&&(t.isValid=t.containsNonAlphanumericCharacter??!0),t}validatePasswordLengthOptions(e,t){const r=this.customStrengthOptions.minPasswordLength,i=this.customStrengthOptions.maxPasswordLength;r&&(t.meetsMinPasswordLength=e.length>=r),i&&(t.meetsMaxPasswordLength=e.length<=i)}validatePasswordCharacterOptions(e,t){this.updatePasswordCharacterOptionsStatuses(t,!1,!1,!1,!1);let r;for(let i=0;i<e.length;i++)r=e.charAt(i),this.updatePasswordCharacterOptionsStatuses(t,r>="a"&&r<="z",r>="A"&&r<="Z",r>="0"&&r<="9",this.allowedNonAlphanumericCharacters.includes(r))}updatePasswordCharacterOptionsStatuses(e,t,r,i,o){this.customStrengthOptions.containsLowercaseLetter&&(e.containsLowercaseLetter||(e.containsLowercaseLetter=t)),this.customStrengthOptions.containsUppercaseLetter&&(e.containsUppercaseLetter||(e.containsUppercaseLetter=r)),this.customStrengthOptions.containsNumericCharacter&&(e.containsNumericCharacter||(e.containsNumericCharacter=i)),this.customStrengthOptions.containsNonAlphanumericCharacter&&(e.containsNonAlphanumericCharacter||(e.containsNonAlphanumericCharacter=o))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class n_{constructor(e,t,r,i){this.app=e,this.heartbeatServiceProvider=t,this.appCheckServiceProvider=r,this.config=i,this.currentUser=null,this.emulatorConfig=null,this.operations=Promise.resolve(),this.authStateSubscription=new Ih(this),this.idTokenSubscription=new Ih(this),this.beforeStateQueue=new Jv(this),this.redirectUser=null,this.isProactiveRefreshEnabled=!1,this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION=1,this._canInitEmulator=!0,this._isInitialized=!1,this._deleted=!1,this._initializationPromise=null,this._popupRedirectResolver=null,this._errorFactory=bf,this._agentRecaptchaConfig=null,this._tenantRecaptchaConfigs={},this._projectPasswordPolicy=null,this._tenantPasswordPolicies={},this._resolvePersistenceManagerAvailable=void 0,this.lastNotifiedUid=void 0,this.languageCode=null,this.tenantId=null,this.settings={appVerificationDisabledForTesting:!1},this.frameworks=[],this.name=e.name,this.clientVersion=i.sdkClientVersion,this._persistenceManagerAvailable=new Promise(o=>this._resolvePersistenceManagerAvailable=o)}_initializeWithPersistence(e,t){return t&&(this._popupRedirectResolver=rn(t)),this._initializationPromise=this.queue(async()=>{var r,i,o;if(!this._deleted&&(this.persistenceManager=await Qr.create(this,e),(r=this._resolvePersistenceManagerAvailable)==null||r.call(this),!this._deleted)){if((i=this._popupRedirectResolver)!=null&&i._shouldInitProactively)try{await this._popupRedirectResolver._initialize(this)}catch{}await this.initializeCurrentUser(t),this.lastNotifiedUid=((o=this.currentUser)==null?void 0:o.uid)||null,!this._deleted&&(this._isInitialized=!0)}}),this._initializationPromise}async _onStorageEvent(){if(this._deleted)return;const e=await this.assertedPersistence.getCurrentUser();if(!(!this.currentUser&&!e)){if(this.currentUser&&e&&this.currentUser.uid===e.uid){this._currentUser._assign(e),await this.currentUser.getIdToken();return}await this._updateCurrentUser(e,!0)}}async initializeCurrentUserFromIdToken(e){try{const t=await Fs(this,{idToken:e}),r=await Et._fromGetAccountInfoResponse(this,t,e);await this.directlySetCurrentUser(r)}catch(t){console.warn("FirebaseServerApp could not login user with provided authIdToken: ",t),await this.directlySetCurrentUser(null)}}async initializeCurrentUser(e){var o;if(Mt(this.app)){const s=this.app.settings.authIdToken;return s?new Promise(l=>{setTimeout(()=>this.initializeCurrentUserFromIdToken(s).then(l,l))}):this.directlySetCurrentUser(null)}const t=await this.assertedPersistence.getCurrentUser();let r=t,i=!1;if(e&&this.config.authDomain){await this.getOrInitRedirectPersistenceManager();const s=(o=this.redirectUser)==null?void 0:o._redirectEventId,l=r==null?void 0:r._redirectEventId,u=await this.tryRedirectSignIn(e);(!s||s===l)&&(u!=null&&u.user)&&(r=u.user,i=!0)}if(!r)return this.directlySetCurrentUser(null);if(!r._redirectEventId){if(i)try{await this.beforeStateQueue.runMiddleware(r)}catch(s){r=t,this._popupRedirectResolver._overrideRedirectResult(this,()=>Promise.reject(s))}return r?this.reloadAndSetCurrentUserOrClear(r):this.directlySetCurrentUser(null)}return Q(this._popupRedirectResolver,this,"argument-error"),await this.getOrInitRedirectPersistenceManager(),this.redirectUser&&this.redirectUser._redirectEventId===r._redirectEventId?this.directlySetCurrentUser(r):this.reloadAndSetCurrentUserOrClear(r)}async tryRedirectSignIn(e){let t=null;try{t=await this._popupRedirectResolver._completeRedirectFn(this,e,!0)}catch{await this._setRedirectUser(null)}return t}async reloadAndSetCurrentUserOrClear(e){try{await Us(e)}catch(t){if((t==null?void 0:t.code)!=="auth/network-request-failed")return this.directlySetCurrentUser(null)}return this.directlySetCurrentUser(e)}useDeviceLanguage(){this.languageCode=Lv()}async _delete(){this._deleted=!0}async updateCurrentUser(e){if(Mt(this.app))return Promise.reject(hr(this));const t=e?$e(e):null;return t&&Q(t.auth.config.apiKey===this.config.apiKey,this,"invalid-user-token"),this._updateCurrentUser(t&&t._clone(this))}async _updateCurrentUser(e,t=!1){if(!this._deleted)return e&&Q(this.tenantId===e.tenantId,this,"tenant-id-mismatch"),t||await this.beforeStateQueue.runMiddleware(e),this.queue(async()=>{await this.directlySetCurrentUser(e),this.notifyAuthListeners()})}async signOut(){return Mt(this.app)?Promise.reject(hr(this)):(await this.beforeStateQueue.runMiddleware(null),(this.redirectPersistenceManager||this._popupRedirectResolver)&&await this._setRedirectUser(null),this._updateCurrentUser(null,!0))}setPersistence(e){return Mt(this.app)?Promise.reject(hr(this)):this.queue(async()=>{await this.assertedPersistence.setPersistence(rn(e))})}_getRecaptchaConfig(){return this.tenantId==null?this._agentRecaptchaConfig:this._tenantRecaptchaConfigs[this.tenantId]}async validatePassword(e){this._getPasswordPolicyInternal()||await this._updatePasswordPolicy();const t=this._getPasswordPolicyInternal();return t.schemaVersion!==this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION?Promise.reject(this._errorFactory.create("unsupported-password-policy-schema-version",{})):t.validatePassword(e)}_getPasswordPolicyInternal(){return this.tenantId===null?this._projectPasswordPolicy:this._tenantPasswordPolicies[this.tenantId]}async _updatePasswordPolicy(){const e=await Zv(this),t=new t_(e);this.tenantId===null?this._projectPasswordPolicy=t:this._tenantPasswordPolicies[this.tenantId]=t}_getPersistenceType(){return this.assertedPersistence.persistence.type}_getPersistence(){return this.assertedPersistence.persistence}_updateErrorMap(e){this._errorFactory=new Mo("auth","Firebase",e())}onAuthStateChanged(e,t,r){return this.registerStateListener(this.authStateSubscription,e,t,r)}beforeAuthStateChanged(e,t){return this.beforeStateQueue.pushCallback(e,t)}onIdTokenChanged(e,t,r){return this.registerStateListener(this.idTokenSubscription,e,t,r)}authStateReady(){return new Promise((e,t)=>{if(this.currentUser)e();else{const r=this.onAuthStateChanged(()=>{r(),e()},t)}})}async revokeAccessToken(e){if(this.currentUser){const t=await this.currentUser.getIdToken(),r={providerId:"apple.com",tokenType:"ACCESS_TOKEN",token:e,idToken:t};this.tenantId!=null&&(r.tenantId=this.tenantId),await Yv(this,r)}}toJSON(){var e;return{apiKey:this.config.apiKey,authDomain:this.config.authDomain,appName:this.name,currentUser:(e=this._currentUser)==null?void 0:e.toJSON()}}async _setRedirectUser(e,t){const r=await this.getOrInitRedirectPersistenceManager(t);return e===null?r.removeCurrentUser():r.setCurrentUser(e)}async getOrInitRedirectPersistenceManager(e){if(!this.redirectPersistenceManager){const t=e&&rn(e)||this._popupRedirectResolver;Q(t,this,"argument-error"),this.redirectPersistenceManager=await Qr.create(this,[rn(t._redirectPersistence)],"redirectUser"),this.redirectUser=await this.redirectPersistenceManager.getCurrentUser()}return this.redirectPersistenceManager}async _redirectUserForId(e){var t,r;return this._isInitialized&&await this.queue(async()=>{}),((t=this._currentUser)==null?void 0:t._redirectEventId)===e?this._currentUser:((r=this.redirectUser)==null?void 0:r._redirectEventId)===e?this.redirectUser:null}async _persistUserIfCurrent(e){if(e===this.currentUser)return this.queue(async()=>this.directlySetCurrentUser(e))}_notifyListenersIfCurrent(e){e===this.currentUser&&this.notifyAuthListeners()}_key(){return`${this.config.authDomain}:${this.config.apiKey}:${this.name}`}_startProactiveRefresh(){this.isProactiveRefreshEnabled=!0,this.currentUser&&this._currentUser._startProactiveRefresh()}_stopProactiveRefresh(){this.isProactiveRefreshEnabled=!1,this.currentUser&&this._currentUser._stopProactiveRefresh()}get _currentUser(){return this.currentUser}notifyAuthListeners(){var t;if(!this._isInitialized)return;this.idTokenSubscription.next(this.currentUser);const e=((t=this.currentUser)==null?void 0:t.uid)??null;this.lastNotifiedUid!==e&&(this.lastNotifiedUid=e,this.authStateSubscription.next(this.currentUser))}registerStateListener(e,t,r,i){if(this._deleted)return()=>{};const o=typeof t=="function"?t:t.next.bind(t);let s=!1;const l=this._isInitialized?Promise.resolve():this._initializationPromise;if(Q(l,this,"internal-error"),l.then(()=>{s||o(this.currentUser)}),typeof t=="function"){const u=e.addObserver(t,r,i);return()=>{s=!0,u()}}else{const u=e.addObserver(t);return()=>{s=!0,u()}}}async directlySetCurrentUser(e){this.currentUser&&this.currentUser!==e&&this._currentUser._stopProactiveRefresh(),e&&this.isProactiveRefreshEnabled&&e._startProactiveRefresh(),this.currentUser=e,e?await this.assertedPersistence.setCurrentUser(e):await this.assertedPersistence.removeCurrentUser()}queue(e){return this.operations=this.operations.then(e,e),this.operations}get assertedPersistence(){return Q(this.persistenceManager,this,"internal-error"),this.persistenceManager}_logFramework(e){!e||this.frameworks.includes(e)||(this.frameworks.push(e),this.frameworks.sort(),this.clientVersion=Lf(this.config.clientPlatform,this._getFrameworks()))}_getFrameworks(){return this.frameworks}async _getAdditionalHeaders(){var i;const e={"X-Client-Version":this.clientVersion};this.app.options.appId&&(e["X-Firebase-gmpid"]=this.app.options.appId);const t=await((i=this.heartbeatServiceProvider.getImmediate({optional:!0}))==null?void 0:i.getHeartbeatsHeader());t&&(e["X-Firebase-Client"]=t);const r=await this._getAppCheckToken();return r&&(e["X-Firebase-AppCheck"]=r),e}async _getAppCheckToken(){var t;if(Mt(this.app)&&this.app.settings.appCheckToken)return this.app.settings.appCheckToken;const e=await((t=this.appCheckServiceProvider.getImmediate({optional:!0}))==null?void 0:t.getToken());return e!=null&&e.error&&Nv(`Error while retrieving App Check token: ${e.error}`),e==null?void 0:e.token}}function ca(n){return $e(n)}class Ih{constructor(e){this.auth=e,this.observer=null,this.addObserver=_y(t=>this.observer=t)}get next(){return Q(this.observer,this.auth,"internal-error"),this.observer.next.bind(this.observer)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let oc={async loadJS(){throw new Error("Unable to load external scripts")},recaptchaV2Script:"",recaptchaEnterpriseScript:"",gapiScript:""};function r_(n){oc=n}function i_(n){return oc.loadJS(n)}function o_(){return oc.gapiScript}function s_(n){return`__${n}${Math.floor(Math.random()*1e6)}`}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function a_(n,e){const t=Jl(n,"auth");if(t.isInitialized()){const i=t.getImmediate(),o=t.getOptions();if(mr(o,e??{}))return i;dn(i,"already-initialized")}return t.initialize({options:e})}function l_(n,e){const t=(e==null?void 0:e.persistence)||[],r=(Array.isArray(t)?t:[t]).map(rn);e!=null&&e.errorMap&&n._updateErrorMap(e.errorMap),n._initializeWithPersistence(r,e==null?void 0:e.popupRedirectResolver)}function c_(n,e,t){const r=ca(n);Q(/^https?:\/\//.test(e),r,"invalid-emulator-scheme");const i=!1,o=Vf(e),{host:s,port:l}=u_(e),u=l===null?"":`:${l}`,h={url:`${o}//${s}${u}/`},p=Object.freeze({host:s,port:l,protocol:o.replace(":",""),options:Object.freeze({disableWarnings:i})});if(!r._canInitEmulator){Q(r.config.emulator&&r.emulatorConfig,r,"emulator-config-failed"),Q(mr(h,r.config.emulator)&&mr(p,r.emulatorConfig),r,"emulator-config-failed");return}r.config.emulator=h,r.emulatorConfig=p,r.settings.appVerificationDisabledForTesting=!0,Vo(s)?pf(`${o}//${s}${u}`):h_()}function Vf(n){const e=n.indexOf(":");return e<0?"":n.substr(0,e+1)}function u_(n){const e=Vf(n),t=/(\/\/)?([^?#/]+)/.exec(n.substr(e.length));if(!t)return{host:"",port:null};const r=t[2].split("@").pop()||"",i=/^(\[[^\]]+\])(:|$)/.exec(r);if(i){const o=i[1];return{host:o,port:Ah(r.substr(o.length+1))}}else{const[o,s]=r.split(":");return{host:o,port:Ah(s)}}}function Ah(n){if(!n)return null;const e=Number(n);return isNaN(e)?null:e}function h_(){function n(){const e=document.createElement("p"),t=e.style;e.innerText="Running in emulator mode. Do not use with production credentials.",t.position="fixed",t.width="100%",t.backgroundColor="#ffffff",t.border=".1em solid #000000",t.color="#b50000",t.bottom="0px",t.left="0px",t.margin="0px",t.zIndex="10000",t.textAlign="center",e.classList.add("firebase-emulator-warning"),document.body.appendChild(e)}typeof console<"u"&&typeof console.info=="function"&&console.info("WARNING: You are using the Auth Emulator, which is intended for local testing only.  Do not use with production credentials."),typeof window<"u"&&typeof document<"u"&&(document.readyState==="loading"?window.addEventListener("DOMContentLoaded",n):n())}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ff{constructor(e,t){this.providerId=e,this.signInMethod=t}toJSON(){return nn("not implemented")}_getIdTokenResponse(e){return nn("not implemented")}_linkToIdToken(e,t){return nn("not implemented")}_getReauthenticationResolver(e){return nn("not implemented")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Xr(n,e){return qv(n,"POST","/v1/accounts:signInWithIdp",nc(n,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const d_="http://localhost";class vr extends Ff{constructor(){super(...arguments),this.pendingToken=null}static _fromParams(e){const t=new vr(e.providerId,e.signInMethod);return e.idToken||e.accessToken?(e.idToken&&(t.idToken=e.idToken),e.accessToken&&(t.accessToken=e.accessToken),e.nonce&&!e.pendingToken&&(t.nonce=e.nonce),e.pendingToken&&(t.pendingToken=e.pendingToken)):e.oauthToken&&e.oauthTokenSecret?(t.accessToken=e.oauthToken,t.secret=e.oauthTokenSecret):dn("argument-error"),t}toJSON(){return{idToken:this.idToken,accessToken:this.accessToken,secret:this.secret,nonce:this.nonce,pendingToken:this.pendingToken,providerId:this.providerId,signInMethod:this.signInMethod}}static fromJSON(e){const t=typeof e=="string"?JSON.parse(e):e,{providerId:r,signInMethod:i,...o}=t;if(!r||!i)return null;const s=new vr(r,i);return s.idToken=o.idToken||void 0,s.accessToken=o.accessToken||void 0,s.secret=o.secret,s.nonce=o.nonce,s.pendingToken=o.pendingToken||null,s}_getIdTokenResponse(e){const t=this.buildRequest();return Xr(e,t)}_linkToIdToken(e,t){const r=this.buildRequest();return r.idToken=t,Xr(e,r)}_getReauthenticationResolver(e){const t=this.buildRequest();return t.autoCreate=!1,Xr(e,t)}buildRequest(){const e={requestUri:d_,returnSecureToken:!0};if(this.pendingToken)e.pendingToken=this.pendingToken;else{const t={};this.idToken&&(t.id_token=this.idToken),this.accessToken&&(t.access_token=this.accessToken),this.secret&&(t.oauth_token_secret=this.secret),t.providerId=this.providerId,this.nonce&&!this.pendingToken&&(t.nonce=this.nonce),e.postBody=Lo(t)}return e}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Uf{constructor(e){this.providerId=e,this.defaultLanguageCode=null,this.customParameters={}}setDefaultLanguage(e){this.defaultLanguageCode=e}setCustomParameters(e){return this.customParameters=e,this}getCustomParameters(){return this.customParameters}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Uo extends Uf{constructor(){super(...arguments),this.scopes=[]}addScope(e){return this.scopes.includes(e)||this.scopes.push(e),this}getScopes(){return[...this.scopes]}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xn extends Uo{constructor(){super("facebook.com")}static credential(e){return vr._fromParams({providerId:xn.PROVIDER_ID,signInMethod:xn.FACEBOOK_SIGN_IN_METHOD,accessToken:e})}static credentialFromResult(e){return xn.credentialFromTaggedObject(e)}static credentialFromError(e){return xn.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e||!("oauthAccessToken"in e)||!e.oauthAccessToken)return null;try{return xn.credential(e.oauthAccessToken)}catch{return null}}}xn.FACEBOOK_SIGN_IN_METHOD="facebook.com";xn.PROVIDER_ID="facebook.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class en extends Uo{constructor(){super("google.com"),this.addScope("profile")}static credential(e,t){return vr._fromParams({providerId:en.PROVIDER_ID,signInMethod:en.GOOGLE_SIGN_IN_METHOD,idToken:e,accessToken:t})}static credentialFromResult(e){return en.credentialFromTaggedObject(e)}static credentialFromError(e){return en.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e)return null;const{oauthIdToken:t,oauthAccessToken:r}=e;if(!t&&!r)return null;try{return en.credential(t,r)}catch{return null}}}en.GOOGLE_SIGN_IN_METHOD="google.com";en.PROVIDER_ID="google.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class kn extends Uo{constructor(){super("github.com")}static credential(e){return vr._fromParams({providerId:kn.PROVIDER_ID,signInMethod:kn.GITHUB_SIGN_IN_METHOD,accessToken:e})}static credentialFromResult(e){return kn.credentialFromTaggedObject(e)}static credentialFromError(e){return kn.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e||!("oauthAccessToken"in e)||!e.oauthAccessToken)return null;try{return kn.credential(e.oauthAccessToken)}catch{return null}}}kn.GITHUB_SIGN_IN_METHOD="github.com";kn.PROVIDER_ID="github.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Pn extends Uo{constructor(){super("twitter.com")}static credential(e,t){return vr._fromParams({providerId:Pn.PROVIDER_ID,signInMethod:Pn.TWITTER_SIGN_IN_METHOD,oauthToken:e,oauthTokenSecret:t})}static credentialFromResult(e){return Pn.credentialFromTaggedObject(e)}static credentialFromError(e){return Pn.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e)return null;const{oauthAccessToken:t,oauthTokenSecret:r}=e;if(!t||!r)return null;try{return Pn.credential(t,r)}catch{return null}}}Pn.TWITTER_SIGN_IN_METHOD="twitter.com";Pn.PROVIDER_ID="twitter.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ui{constructor(e){this.user=e.user,this.providerId=e.providerId,this._tokenResponse=e._tokenResponse,this.operationType=e.operationType}static async _fromIdTokenResponse(e,t,r,i=!1){const o=await Et._fromIdTokenResponse(e,r,i),s=Sh(r);return new ui({user:o,providerId:s,_tokenResponse:r,operationType:t})}static async _forOperation(e,t,r){await e._updateTokensIfNecessary(r,!0);const i=Sh(r);return new ui({user:e,providerId:i,_tokenResponse:r,operationType:t})}}function Sh(n){return n.providerId?n.providerId:"phoneNumber"in n?"phone":null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class qs extends yn{constructor(e,t,r,i){super(t.code,t.message),this.operationType=r,this.user=i,Object.setPrototypeOf(this,qs.prototype),this.customData={appName:e.name,tenantId:e.tenantId??void 0,_serverResponse:t.customData._serverResponse,operationType:r}}static _fromErrorAndOperation(e,t,r,i){return new qs(e,t,r,i)}}function qf(n,e,t,r){return(e==="reauthenticate"?t._getReauthenticationResolver(n):t._getIdTokenResponse(n)).catch(o=>{throw o.code==="auth/multi-factor-auth-required"?qs._fromErrorAndOperation(n,o,e,r):o})}async function f_(n,e,t=!1){const r=await yo(n,e._linkToIdToken(n.auth,await n.getIdToken()),t);return ui._forOperation(n,"link",r)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function p_(n,e,t=!1){const{auth:r}=n;if(Mt(r.app))return Promise.reject(hr(r));const i="reauthenticate";try{const o=await yo(n,qf(r,i,e,n),t);Q(o.idToken,r,"internal-error");const s=rc(o.idToken);Q(s,r,"internal-error");const{sub:l}=s;return Q(n.uid===l,r,"user-mismatch"),ui._forOperation(n,i,o)}catch(o){throw(o==null?void 0:o.code)==="auth/user-not-found"&&dn(r,"user-mismatch"),o}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Bf(n,e,t=!1){if(Mt(n.app))return Promise.reject(hr(n));const r="signIn",i=await qf(n,r,e),o=await ui._fromIdTokenResponse(n,r,i);return t||await n._updateCurrentUser(o.user),o}async function g_(n,e){return Bf(ca(n),e)}function m_(n,e,t,r){return $e(n).onIdTokenChanged(e,t,r)}function y_(n,e,t){return $e(n).beforeAuthStateChanged(e,t)}function v_(n,e,t,r){return $e(n).onAuthStateChanged(e,t,r)}function __(n){return $e(n).signOut()}const Bs="__sak";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class $f{constructor(e,t){this.storageRetriever=e,this.type=t}_isAvailable(){try{return this.storage?(this.storage.setItem(Bs,"1"),this.storage.removeItem(Bs),Promise.resolve(!0)):Promise.resolve(!1)}catch{return Promise.resolve(!1)}}_set(e,t){return this.storage.setItem(e,JSON.stringify(t)),Promise.resolve()}_get(e){const t=this.storage.getItem(e);return Promise.resolve(t?JSON.parse(t):null)}_remove(e){return this.storage.removeItem(e),Promise.resolve()}get storage(){return this.storageRetriever()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const w_=1e3,b_=10;class jf extends $f{constructor(){super(()=>window.localStorage,"LOCAL"),this.boundEventHandler=(e,t)=>this.onStorageEvent(e,t),this.listeners={},this.localCache={},this.pollTimer=null,this.fallbackToPolling=Mf(),this._shouldAllowMigration=!0}forAllChangedKeys(e){for(const t of Object.keys(this.listeners)){const r=this.storage.getItem(t),i=this.localCache[t];r!==i&&e(t,i,r)}}onStorageEvent(e,t=!1){if(!e.key){this.forAllChangedKeys((s,l,u)=>{this.notifyListeners(s,u)});return}const r=e.key;t?this.detachListener():this.stopPolling();const i=()=>{const s=this.storage.getItem(r);!t&&this.localCache[r]===s||this.notifyListeners(r,s)},o=this.storage.getItem(r);Xv()&&o!==e.newValue&&e.newValue!==e.oldValue?setTimeout(i,b_):i()}notifyListeners(e,t){this.localCache[e]=t;const r=this.listeners[e];if(r)for(const i of Array.from(r))i(t&&JSON.parse(t))}startPolling(){this.stopPolling(),this.pollTimer=setInterval(()=>{this.forAllChangedKeys((e,t,r)=>{this.onStorageEvent(new StorageEvent("storage",{key:e,oldValue:t,newValue:r}),!0)})},w_)}stopPolling(){this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}attachListener(){window.addEventListener("storage",this.boundEventHandler)}detachListener(){window.removeEventListener("storage",this.boundEventHandler)}_addListener(e,t){Object.keys(this.listeners).length===0&&(this.fallbackToPolling?this.startPolling():this.attachListener()),this.listeners[e]||(this.listeners[e]=new Set,this.localCache[e]=this.storage.getItem(e)),this.listeners[e].add(t)}_removeListener(e,t){this.listeners[e]&&(this.listeners[e].delete(t),this.listeners[e].size===0&&delete this.listeners[e]),Object.keys(this.listeners).length===0&&(this.detachListener(),this.stopPolling())}async _set(e,t){await super._set(e,t),this.localCache[e]=JSON.stringify(t)}async _get(e){const t=await super._get(e);return this.localCache[e]=JSON.stringify(t),t}async _remove(e){await super._remove(e),delete this.localCache[e]}}jf.type="LOCAL";const T_=jf;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class zf extends $f{constructor(){super(()=>window.sessionStorage,"SESSION")}_addListener(e,t){}_removeListener(e,t){}}zf.type="SESSION";const Wf=zf;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function E_(n){return Promise.all(n.map(async e=>{try{return{fulfilled:!0,value:await e}}catch(t){return{fulfilled:!1,reason:t}}}))}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ua{constructor(e){this.eventTarget=e,this.handlersMap={},this.boundEventHandler=this.handleEvent.bind(this)}static _getInstance(e){const t=this.receivers.find(i=>i.isListeningto(e));if(t)return t;const r=new ua(e);return this.receivers.push(r),r}isListeningto(e){return this.eventTarget===e}async handleEvent(e){const t=e,{eventId:r,eventType:i,data:o}=t.data,s=this.handlersMap[i];if(!(s!=null&&s.size))return;t.ports[0].postMessage({status:"ack",eventId:r,eventType:i});const l=Array.from(s).map(async h=>h(t.origin,o)),u=await E_(l);t.ports[0].postMessage({status:"done",eventId:r,eventType:i,response:u})}_subscribe(e,t){Object.keys(this.handlersMap).length===0&&this.eventTarget.addEventListener("message",this.boundEventHandler),this.handlersMap[e]||(this.handlersMap[e]=new Set),this.handlersMap[e].add(t)}_unsubscribe(e,t){this.handlersMap[e]&&t&&this.handlersMap[e].delete(t),(!t||this.handlersMap[e].size===0)&&delete this.handlersMap[e],Object.keys(this.handlersMap).length===0&&this.eventTarget.removeEventListener("message",this.boundEventHandler)}}ua.receivers=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function sc(n="",e=10){let t="";for(let r=0;r<e;r++)t+=Math.floor(Math.random()*10);return n+t}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class I_{constructor(e){this.target=e,this.handlers=new Set}removeMessageHandler(e){e.messageChannel&&(e.messageChannel.port1.removeEventListener("message",e.onMessage),e.messageChannel.port1.close()),this.handlers.delete(e)}async _send(e,t,r=50){const i=typeof MessageChannel<"u"?new MessageChannel:null;if(!i)throw new Error("connection_unavailable");let o,s;return new Promise((l,u)=>{const h=sc("",20);i.port1.start();const p=setTimeout(()=>{u(new Error("unsupported_event"))},r);s={messageChannel:i,onMessage(m){const g=m;if(g.data.eventId===h)switch(g.data.status){case"ack":clearTimeout(p),o=setTimeout(()=>{u(new Error("timeout"))},3e3);break;case"done":clearTimeout(o),l(g.data.response);break;default:clearTimeout(p),clearTimeout(o),u(new Error("invalid_response"));break}}},this.handlers.add(s),i.port1.addEventListener("message",s.onMessage),this.target.postMessage({eventType:e,eventId:h,data:t},[i.port2])}).finally(()=>{s&&this.removeMessageHandler(s)})}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Bt(){return window}function A_(n){Bt().location.href=n}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Hf(){return typeof Bt().WorkerGlobalScope<"u"&&typeof Bt().importScripts=="function"}async function S_(){if(!(navigator!=null&&navigator.serviceWorker))return null;try{return(await navigator.serviceWorker.ready).active}catch{return null}}function x_(){var n;return((n=navigator==null?void 0:navigator.serviceWorker)==null?void 0:n.controller)||null}function k_(){return Hf()?self:null}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Gf="firebaseLocalStorageDb",P_=1,$s="firebaseLocalStorage",Kf="fbase_key";class qo{constructor(e){this.request=e}toPromise(){return new Promise((e,t)=>{this.request.addEventListener("success",()=>{e(this.request.result)}),this.request.addEventListener("error",()=>{t(this.request.error)})})}}function ha(n,e){return n.transaction([$s],e?"readwrite":"readonly").objectStore($s)}function C_(){const n=indexedDB.deleteDatabase(Gf);return new qo(n).toPromise()}function Tl(){const n=indexedDB.open(Gf,P_);return new Promise((e,t)=>{n.addEventListener("error",()=>{t(n.error)}),n.addEventListener("upgradeneeded",()=>{const r=n.result;try{r.createObjectStore($s,{keyPath:Kf})}catch(i){t(i)}}),n.addEventListener("success",async()=>{const r=n.result;r.objectStoreNames.contains($s)?e(r):(r.close(),await C_(),e(await Tl()))})})}async function xh(n,e,t){const r=ha(n,!0).put({[Kf]:e,value:t});return new qo(r).toPromise()}async function R_(n,e){const t=ha(n,!1).get(e),r=await new qo(t).toPromise();return r===void 0?null:r.value}function kh(n,e){const t=ha(n,!0).delete(e);return new qo(t).toPromise()}const O_=800,N_=3;class Yf{constructor(){this.type="LOCAL",this._shouldAllowMigration=!0,this.listeners={},this.localCache={},this.pollTimer=null,this.pendingWrites=0,this.receiver=null,this.sender=null,this.serviceWorkerReceiverAvailable=!1,this.activeServiceWorker=null,this._workerInitializationPromise=this.initializeServiceWorkerMessaging().then(()=>{},()=>{})}async _openDb(){return this.db?this.db:(this.db=await Tl(),this.db)}async _withRetries(e){let t=0;for(;;)try{const r=await this._openDb();return await e(r)}catch(r){if(t++>N_)throw r;this.db&&(this.db.close(),this.db=void 0)}}async initializeServiceWorkerMessaging(){return Hf()?this.initializeReceiver():this.initializeSender()}async initializeReceiver(){this.receiver=ua._getInstance(k_()),this.receiver._subscribe("keyChanged",async(e,t)=>({keyProcessed:(await this._poll()).includes(t.key)})),this.receiver._subscribe("ping",async(e,t)=>["keyChanged"])}async initializeSender(){var t,r;if(this.activeServiceWorker=await S_(),!this.activeServiceWorker)return;this.sender=new I_(this.activeServiceWorker);const e=await this.sender._send("ping",{},800);e&&(t=e[0])!=null&&t.fulfilled&&(r=e[0])!=null&&r.value.includes("keyChanged")&&(this.serviceWorkerReceiverAvailable=!0)}async notifyServiceWorker(e){if(!(!this.sender||!this.activeServiceWorker||x_()!==this.activeServiceWorker))try{await this.sender._send("keyChanged",{key:e},this.serviceWorkerReceiverAvailable?800:50)}catch{}}async _isAvailable(){try{if(!indexedDB)return!1;const e=await Tl();return await xh(e,Bs,"1"),await kh(e,Bs),!0}catch{}return!1}async _withPendingWrite(e){this.pendingWrites++;try{await e()}finally{this.pendingWrites--}}async _set(e,t){return this._withPendingWrite(async()=>(await this._withRetries(r=>xh(r,e,t)),this.localCache[e]=t,this.notifyServiceWorker(e)))}async _get(e){const t=await this._withRetries(r=>R_(r,e));return this.localCache[e]=t,t}async _remove(e){return this._withPendingWrite(async()=>(await this._withRetries(t=>kh(t,e)),delete this.localCache[e],this.notifyServiceWorker(e)))}async _poll(){const e=await this._withRetries(i=>{const o=ha(i,!1).getAll();return new qo(o).toPromise()});if(!e)return[];if(this.pendingWrites!==0)return[];const t=[],r=new Set;if(e.length!==0)for(const{fbase_key:i,value:o}of e)r.add(i),JSON.stringify(this.localCache[i])!==JSON.stringify(o)&&(this.notifyListeners(i,o),t.push(i));for(const i of Object.keys(this.localCache))this.localCache[i]&&!r.has(i)&&(this.notifyListeners(i,null),t.push(i));return t}notifyListeners(e,t){this.localCache[e]=t;const r=this.listeners[e];if(r)for(const i of Array.from(r))i(t)}startPolling(){this.stopPolling(),this.pollTimer=setInterval(async()=>this._poll(),O_)}stopPolling(){this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}_addListener(e,t){Object.keys(this.listeners).length===0&&this.startPolling(),this.listeners[e]||(this.listeners[e]=new Set,this._get(e)),this.listeners[e].add(t)}_removeListener(e,t){this.listeners[e]&&(this.listeners[e].delete(t),this.listeners[e].size===0&&delete this.listeners[e]),Object.keys(this.listeners).length===0&&this.stopPolling()}}Yf.type="LOCAL";const D_=Yf;new Fo(3e4,6e4);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function M_(n,e){return e?rn(e):(Q(n._popupRedirectResolver,n,"argument-error"),n._popupRedirectResolver)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ac extends Ff{constructor(e){super("custom","custom"),this.params=e}_getIdTokenResponse(e){return Xr(e,this._buildIdpRequest())}_linkToIdToken(e,t){return Xr(e,this._buildIdpRequest(t))}_getReauthenticationResolver(e){return Xr(e,this._buildIdpRequest())}_buildIdpRequest(e){const t={requestUri:this.params.requestUri,sessionId:this.params.sessionId,postBody:this.params.postBody,tenantId:this.params.tenantId,pendingToken:this.params.pendingToken,returnSecureToken:!0,returnIdpCredential:!0};return e&&(t.idToken=e),t}}function L_(n){return Bf(n.auth,new ac(n),n.bypassAuthState)}function V_(n){const{auth:e,user:t}=n;return Q(t,e,"internal-error"),p_(t,new ac(n),n.bypassAuthState)}async function F_(n){const{auth:e,user:t}=n;return Q(t,e,"internal-error"),f_(t,new ac(n),n.bypassAuthState)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Qf{constructor(e,t,r,i,o=!1){this.auth=e,this.resolver=r,this.user=i,this.bypassAuthState=o,this.pendingPromise=null,this.eventManager=null,this.filter=Array.isArray(t)?t:[t]}execute(){return new Promise(async(e,t)=>{this.pendingPromise={resolve:e,reject:t};try{this.eventManager=await this.resolver._initialize(this.auth),await this.onExecution(),this.eventManager.registerConsumer(this)}catch(r){this.reject(r)}})}async onAuthEvent(e){const{urlResponse:t,sessionId:r,postBody:i,tenantId:o,error:s,type:l}=e;if(s){this.reject(s);return}const u={auth:this.auth,requestUri:t,sessionId:r,tenantId:o||void 0,postBody:i||void 0,user:this.user,bypassAuthState:this.bypassAuthState};try{this.resolve(await this.getIdpTask(l)(u))}catch(h){this.reject(h)}}onError(e){this.reject(e)}getIdpTask(e){switch(e){case"signInViaPopup":case"signInViaRedirect":return L_;case"linkViaPopup":case"linkViaRedirect":return F_;case"reauthViaPopup":case"reauthViaRedirect":return V_;default:dn(this.auth,"internal-error")}}resolve(e){fn(this.pendingPromise,"Pending promise was never set"),this.pendingPromise.resolve(e),this.unregisterAndCleanUp()}reject(e){fn(this.pendingPromise,"Pending promise was never set"),this.pendingPromise.reject(e),this.unregisterAndCleanUp()}unregisterAndCleanUp(){this.eventManager&&this.eventManager.unregisterConsumer(this),this.pendingPromise=null,this.cleanUp()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const U_=new Fo(2e3,1e4);class Hr extends Qf{constructor(e,t,r,i,o){super(e,t,i,o),this.provider=r,this.authWindow=null,this.pollId=null,Hr.currentPopupAction&&Hr.currentPopupAction.cancel(),Hr.currentPopupAction=this}async executeNotNull(){const e=await this.execute();return Q(e,this.auth,"internal-error"),e}async onExecution(){fn(this.filter.length===1,"Popup operations only handle one event");const e=sc();this.authWindow=await this.resolver._openPopup(this.auth,this.provider,this.filter[0],e),this.authWindow.associatedEvent=e,this.resolver._originValidation(this.auth).catch(t=>{this.reject(t)}),this.resolver._isIframeWebStorageSupported(this.auth,t=>{t||this.reject(qt(this.auth,"web-storage-unsupported"))}),this.pollUserCancellation()}get eventId(){var e;return((e=this.authWindow)==null?void 0:e.associatedEvent)||null}cancel(){this.reject(qt(this.auth,"cancelled-popup-request"))}cleanUp(){this.authWindow&&this.authWindow.close(),this.pollId&&window.clearTimeout(this.pollId),this.authWindow=null,this.pollId=null,Hr.currentPopupAction=null}pollUserCancellation(){const e=()=>{var t,r;if((r=(t=this.authWindow)==null?void 0:t.window)!=null&&r.closed){this.pollId=window.setTimeout(()=>{this.pollId=null,this.reject(qt(this.auth,"popup-closed-by-user"))},8e3);return}this.pollId=window.setTimeout(e,U_.get())};e()}}Hr.currentPopupAction=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const q_="pendingRedirect",Es=new Map;class B_ extends Qf{constructor(e,t,r=!1){super(e,["signInViaRedirect","linkViaRedirect","reauthViaRedirect","unknown"],t,void 0,r),this.eventId=null}async execute(){let e=Es.get(this.auth._key());if(!e){try{const r=await $_(this.resolver,this.auth)?await super.execute():null;e=()=>Promise.resolve(r)}catch(t){e=()=>Promise.reject(t)}Es.set(this.auth._key(),e)}return this.bypassAuthState||Es.set(this.auth._key(),()=>Promise.resolve(null)),e()}async onAuthEvent(e){if(e.type==="signInViaRedirect")return super.onAuthEvent(e);if(e.type==="unknown"){this.resolve(null);return}if(e.eventId){const t=await this.auth._redirectUserForId(e.eventId);if(t)return this.user=t,super.onAuthEvent(e);this.resolve(null)}}async onExecution(){}cleanUp(){}}async function $_(n,e){const t=W_(e),r=z_(n);if(!await r._isAvailable())return!1;const i=await r._get(t)==="true";return await r._remove(t),i}function j_(n,e){Es.set(n._key(),e)}function z_(n){return rn(n._redirectPersistence)}function W_(n){return Ts(q_,n.config.apiKey,n.name)}async function H_(n,e,t=!1){if(Mt(n.app))return Promise.reject(hr(n));const r=ca(n),i=M_(r,e),s=await new B_(r,i,t).execute();return s&&!t&&(delete s.user._redirectEventId,await r._persistUserIfCurrent(s.user),await r._setRedirectUser(null,e)),s}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const G_=10*60*1e3;class K_{constructor(e){this.auth=e,this.cachedEventUids=new Set,this.consumers=new Set,this.queuedRedirectEvent=null,this.hasHandledPotentialRedirect=!1,this.lastProcessedEventTime=Date.now()}registerConsumer(e){this.consumers.add(e),this.queuedRedirectEvent&&this.isEventForConsumer(this.queuedRedirectEvent,e)&&(this.sendToConsumer(this.queuedRedirectEvent,e),this.saveEventToCache(this.queuedRedirectEvent),this.queuedRedirectEvent=null)}unregisterConsumer(e){this.consumers.delete(e)}onEvent(e){if(this.hasEventBeenHandled(e))return!1;let t=!1;return this.consumers.forEach(r=>{this.isEventForConsumer(e,r)&&(t=!0,this.sendToConsumer(e,r),this.saveEventToCache(e))}),this.hasHandledPotentialRedirect||!Y_(e)||(this.hasHandledPotentialRedirect=!0,t||(this.queuedRedirectEvent=e,t=!0)),t}sendToConsumer(e,t){var r;if(e.error&&!Xf(e)){const i=((r=e.error.code)==null?void 0:r.split("auth/")[1])||"internal-error";t.onError(qt(this.auth,i))}else t.onAuthEvent(e)}isEventForConsumer(e,t){const r=t.eventId===null||!!e.eventId&&e.eventId===t.eventId;return t.filter.includes(e.type)&&r}hasEventBeenHandled(e){return Date.now()-this.lastProcessedEventTime>=G_&&this.cachedEventUids.clear(),this.cachedEventUids.has(Ph(e))}saveEventToCache(e){this.cachedEventUids.add(Ph(e)),this.lastProcessedEventTime=Date.now()}}function Ph(n){return[n.type,n.eventId,n.sessionId,n.tenantId].filter(e=>e).join("-")}function Xf({type:n,error:e}){return n==="unknown"&&(e==null?void 0:e.code)==="auth/no-auth-event"}function Y_(n){switch(n.type){case"signInViaRedirect":case"linkViaRedirect":case"reauthViaRedirect":return!0;case"unknown":return Xf(n);default:return!1}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Q_(n,e={}){return bi(n,"GET","/v1/projects",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const X_=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,J_=/^https?/;async function Z_(n){if(n.config.emulator)return;const{authorizedDomains:e}=await Q_(n);for(const t of e)try{if(ew(t))return}catch{}dn(n,"unauthorized-domain")}function ew(n){const e=wl(),{protocol:t,hostname:r}=new URL(e);if(n.startsWith("chrome-extension://")){const s=new URL(n);return s.hostname===""&&r===""?t==="chrome-extension:"&&n.replace("chrome-extension://","")===e.replace("chrome-extension://",""):t==="chrome-extension:"&&s.hostname===r}if(!J_.test(t))return!1;if(X_.test(n))return r===n;const i=n.replace(/\./g,"\\.");return new RegExp("^(.+\\."+i+"|"+i+")$","i").test(r)}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const tw=new Fo(3e4,6e4);function Ch(){const n=Bt().___jsl;if(n!=null&&n.H){for(const e of Object.keys(n.H))if(n.H[e].r=n.H[e].r||[],n.H[e].L=n.H[e].L||[],n.H[e].r=[...n.H[e].L],n.CP)for(let t=0;t<n.CP.length;t++)n.CP[t]=null}}function nw(n){return new Promise((e,t)=>{var i,o,s;function r(){Ch(),gapi.load("gapi.iframes",{callback:()=>{e(gapi.iframes.getContext())},ontimeout:()=>{Ch(),t(qt(n,"network-request-failed"))},timeout:tw.get()})}if((o=(i=Bt().gapi)==null?void 0:i.iframes)!=null&&o.Iframe)e(gapi.iframes.getContext());else if((s=Bt().gapi)!=null&&s.load)r();else{const l=s_("iframefcb");return Bt()[l]=()=>{gapi.load?r():t(qt(n,"network-request-failed"))},i_(`${o_()}?onload=${l}`).catch(u=>t(u))}}).catch(e=>{throw Is=null,e})}let Is=null;function rw(n){return Is=Is||nw(n),Is}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const iw=new Fo(5e3,15e3),ow="__/auth/iframe",sw="emulator/auth/iframe",aw={style:{position:"absolute",top:"-100px",width:"1px",height:"1px"},"aria-hidden":"true",tabindex:"-1"},lw=new Map([["identitytoolkit.googleapis.com","p"],["staging-identitytoolkit.sandbox.googleapis.com","s"],["test-identitytoolkit.sandbox.googleapis.com","t"]]);function cw(n){const e=n.config;Q(e.authDomain,n,"auth-domain-config-required");const t=e.emulator?tc(e,sw):`https://${n.config.authDomain}/${ow}`,r={apiKey:e.apiKey,appName:n.name,v:wi},i=lw.get(n.config.apiHost);i&&(r.eid=i);const o=n._getFrameworks();return o.length&&(r.fw=o.join(",")),`${t}?${Lo(r).slice(1)}`}async function uw(n){const e=await rw(n),t=Bt().gapi;return Q(t,n,"internal-error"),e.open({where:document.body,url:cw(n),messageHandlersFilter:t.iframes.CROSS_ORIGIN_IFRAMES_FILTER,attributes:aw,dontclear:!0},r=>new Promise(async(i,o)=>{await r.restyle({setHideOnLeave:!1});const s=qt(n,"network-request-failed"),l=Bt().setTimeout(()=>{o(s)},iw.get());function u(){Bt().clearTimeout(l),i(r)}r.ping(u).then(u,()=>{o(s)})}))}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const hw={location:"yes",resizable:"yes",statusbar:"yes",toolbar:"no"},dw=500,fw=600,pw="_blank",gw="http://localhost";class Rh{constructor(e){this.window=e,this.associatedEvent=null}close(){if(this.window)try{this.window.close()}catch{}}}function mw(n,e,t,r=dw,i=fw){const o=Math.max((window.screen.availHeight-i)/2,0).toString(),s=Math.max((window.screen.availWidth-r)/2,0).toString();let l="";const u={...hw,width:r.toString(),height:i.toString(),top:o,left:s},h=Xe().toLowerCase();t&&(l=Cf(h)?pw:t),kf(h)&&(e=e||gw,u.scrollbars="yes");const p=Object.entries(u).reduce((g,[b,P])=>`${g}${b}=${P},`,"");if(Qv(h)&&l!=="_self")return yw(e||"",l),new Rh(null);const m=window.open(e||"",l,p);Q(m,n,"popup-blocked");try{m.focus()}catch{}return new Rh(m)}function yw(n,e){const t=document.createElement("a");t.href=n,t.target=e;const r=document.createEvent("MouseEvent");r.initMouseEvent("click",!0,!0,window,1,0,0,0,0,!1,!1,!1,!1,1,null),t.dispatchEvent(r)}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const vw="__/auth/handler",_w="emulator/auth/handler",ww=encodeURIComponent("fac");async function Oh(n,e,t,r,i,o){Q(n.config.authDomain,n,"auth-domain-config-required"),Q(n.config.apiKey,n,"invalid-api-key");const s={apiKey:n.config.apiKey,appName:n.name,authType:t,redirectUrl:r,v:wi,eventId:i};if(e instanceof Uf){e.setDefaultLanguage(n.languageCode),s.providerId=e.providerId||"",vy(e.getCustomParameters())||(s.customParameters=JSON.stringify(e.getCustomParameters()));for(const[p,m]of Object.entries({}))s[p]=m}if(e instanceof Uo){const p=e.getScopes().filter(m=>m!=="");p.length>0&&(s.scopes=p.join(","))}n.tenantId&&(s.tid=n.tenantId);const l=s;for(const p of Object.keys(l))l[p]===void 0&&delete l[p];const u=await n._getAppCheckToken(),h=u?`#${ww}=${encodeURIComponent(u)}`:"";return`${bw(n)}?${Lo(l).slice(1)}${h}`}function bw({config:n}){return n.emulator?tc(n,_w):`https://${n.authDomain}/${vw}`}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const el="webStorageSupport";class Tw{constructor(){this.eventManagers={},this.iframes={},this.originValidationPromises={},this._redirectPersistence=Wf,this._completeRedirectFn=H_,this._overrideRedirectResult=j_}async _openPopup(e,t,r,i){var s;fn((s=this.eventManagers[e._key()])==null?void 0:s.manager,"_initialize() not called before _openPopup()");const o=await Oh(e,t,r,wl(),i);return mw(e,o,sc())}async _openRedirect(e,t,r,i){await this._originValidation(e);const o=await Oh(e,t,r,wl(),i);return A_(o),new Promise(()=>{})}_initialize(e){const t=e._key();if(this.eventManagers[t]){const{manager:i,promise:o}=this.eventManagers[t];return i?Promise.resolve(i):(fn(o,"If manager is not set, promise should be"),o)}const r=this.initAndGetManager(e);return this.eventManagers[t]={promise:r},r.catch(()=>{delete this.eventManagers[t]}),r}async initAndGetManager(e){const t=await uw(e),r=new K_(e);return t.register("authEvent",i=>(Q(i==null?void 0:i.authEvent,e,"invalid-auth-event"),{status:r.onEvent(i.authEvent)?"ACK":"ERROR"}),gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER),this.eventManagers[e._key()]={manager:r},this.iframes[e._key()]=t,r}_isIframeWebStorageSupported(e,t){this.iframes[e._key()].send(el,{type:el},i=>{var s;const o=(s=i==null?void 0:i[0])==null?void 0:s[el];o!==void 0&&t(!!o),dn(e,"internal-error")},gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER)}_originValidation(e){const t=e._key();return this.originValidationPromises[t]||(this.originValidationPromises[t]=Z_(e)),this.originValidationPromises[t]}get _shouldInitProactively(){return Mf()||Pf()||ic()}}const Ew=Tw;var Nh="@firebase/auth",Dh="1.13.0";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Iw{constructor(e){this.auth=e,this.internalListeners=new Map}getUid(){var e;return this.assertAuthConfigured(),((e=this.auth.currentUser)==null?void 0:e.uid)||null}async getToken(e){return this.assertAuthConfigured(),await this.auth._initializationPromise,this.auth.currentUser?{accessToken:await this.auth.currentUser.getIdToken(e)}:null}addAuthTokenListener(e){if(this.assertAuthConfigured(),this.internalListeners.has(e))return;const t=this.auth.onIdTokenChanged(r=>{e((r==null?void 0:r.stsTokenManager.accessToken)||null)});this.internalListeners.set(e,t),this.updateProactiveRefresh()}removeAuthTokenListener(e){this.assertAuthConfigured();const t=this.internalListeners.get(e);t&&(this.internalListeners.delete(e),t(),this.updateProactiveRefresh())}assertAuthConfigured(){Q(this.auth._initializationPromise,"dependent-sdk-initialized-before-auth")}updateProactiveRefresh(){this.internalListeners.size>0?this.auth._startProactiveRefresh():this.auth._stopProactiveRefresh()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Aw(n){switch(n){case"Node":return"node";case"ReactNative":return"rn";case"Worker":return"webworker";case"Cordova":return"cordova";case"WebExtension":return"web-extension";default:return}}function Sw(n){ci(new yr("auth",(e,{options:t})=>{const r=e.getProvider("app").getImmediate(),i=e.getProvider("heartbeat"),o=e.getProvider("app-check-internal"),{apiKey:s,authDomain:l}=r.options;Q(s&&!s.includes(":"),"invalid-api-key",{appName:r.name});const u={apiKey:s,authDomain:l,clientPlatform:n,apiHost:"identitytoolkit.googleapis.com",tokenApiHost:"securetoken.googleapis.com",apiScheme:"https",sdkClientVersion:Lf(n)},h=new n_(r,i,o,u);return l_(h,t),h},"PUBLIC").setInstantiationMode("EXPLICIT").setInstanceCreatedCallback((e,t,r)=>{e.getProvider("auth-internal").initialize()})),ci(new yr("auth-internal",e=>{const t=ca(e.getProvider("auth").getImmediate());return(r=>new Iw(r))(t)},"PRIVATE").setInstantiationMode("EXPLICIT")),Vn(Nh,Dh,Aw(n)),Vn(Nh,Dh,"esm2020")}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const xw=5*60,kw=ff("authIdTokenMaxAge")||xw;let Mh=null;const Pw=n=>async e=>{const t=e&&await e.getIdTokenResult(),r=t&&(new Date().getTime()-Date.parse(t.issuedAtTime))/1e3;if(r&&r>kw)return;const i=t==null?void 0:t.token;Mh!==i&&(Mh=i,await fetch(n,{method:i?"POST":"DELETE",headers:i?{Authorization:`Bearer ${i}`}:{}}))};function Cw(n=yf()){const e=Jl(n,"auth");if(e.isInitialized())return e.getImmediate();const t=a_(n,{popupRedirectResolver:Ew,persistence:[D_,T_,Wf]}),r=ff("authTokenSyncURL");if(r&&typeof isSecureContext=="boolean"&&isSecureContext){const o=new URL(r,location.origin);if(location.origin===o.origin){const s=Pw(o.toString());y_(t,s,()=>s(t.currentUser)),m_(t,l=>s(l))}}const i=hf("auth");return i&&c_(t,`http://${i}`),t}function Rw(){var n;return((n=document.getElementsByTagName("head"))==null?void 0:n[0])??document}r_({loadJS(n){return new Promise((e,t)=>{const r=document.createElement("script");r.setAttribute("src",n),r.onload=e,r.onerror=i=>{const o=qt("internal-error");o.customData=i,t(o)},r.type="text/javascript",r.charset="UTF-8",Rw().appendChild(r)})},gapiScript:"https://apis.google.com/js/api.js",recaptchaV2Script:"https://www.google.com/recaptcha/api.js",recaptchaEnterpriseScript:"https://www.google.com/recaptcha/enterprise.js?render="});Sw("Browser");const Jf={apiKey:"AIzaSyDgeMII4vDFmjXVKnrBYV8ane76eSzyUN8",authDomain:"overlay-runner.firebaseapp.com",databaseURL:"https://overlay-runner-default-rtdb.firebaseio.com",projectId:"overlay-runner",storageBucket:"overlay-runner.firebasestorage.app",messagingSenderId:"951272023115",appId:"1:951272023115:web:0f75edb7fb291a118119ce"};var Lh=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/var Fn,Zf;(function(){var n;/** @license

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/function e(T,v){function w(){}w.prototype=v.prototype,T.F=v.prototype,T.prototype=new w,T.prototype.constructor=T,T.D=function(I,E,S){for(var _=Array(arguments.length-2),xe=2;xe<arguments.length;xe++)_[xe-2]=arguments[xe];return v.prototype[E].apply(I,_)}}function t(){this.blockSize=-1}function r(){this.blockSize=-1,this.blockSize=64,this.g=Array(4),this.C=Array(this.blockSize),this.o=this.h=0,this.u()}e(r,t),r.prototype.u=function(){this.g[0]=1732584193,this.g[1]=4023233417,this.g[2]=2562383102,this.g[3]=271733878,this.o=this.h=0};function i(T,v,w){w||(w=0);const I=Array(16);if(typeof v=="string")for(var E=0;E<16;++E)I[E]=v.charCodeAt(w++)|v.charCodeAt(w++)<<8|v.charCodeAt(w++)<<16|v.charCodeAt(w++)<<24;else for(E=0;E<16;++E)I[E]=v[w++]|v[w++]<<8|v[w++]<<16|v[w++]<<24;v=T.g[0],w=T.g[1],E=T.g[2];let S=T.g[3],_;_=v+(S^w&(E^S))+I[0]+3614090360&4294967295,v=w+(_<<7&4294967295|_>>>25),_=S+(E^v&(w^E))+I[1]+3905402710&4294967295,S=v+(_<<12&4294967295|_>>>20),_=E+(w^S&(v^w))+I[2]+606105819&4294967295,E=S+(_<<17&4294967295|_>>>15),_=w+(v^E&(S^v))+I[3]+3250441966&4294967295,w=E+(_<<22&4294967295|_>>>10),_=v+(S^w&(E^S))+I[4]+4118548399&4294967295,v=w+(_<<7&4294967295|_>>>25),_=S+(E^v&(w^E))+I[5]+1200080426&4294967295,S=v+(_<<12&4294967295|_>>>20),_=E+(w^S&(v^w))+I[6]+2821735955&4294967295,E=S+(_<<17&4294967295|_>>>15),_=w+(v^E&(S^v))+I[7]+4249261313&4294967295,w=E+(_<<22&4294967295|_>>>10),_=v+(S^w&(E^S))+I[8]+1770035416&4294967295,v=w+(_<<7&4294967295|_>>>25),_=S+(E^v&(w^E))+I[9]+2336552879&4294967295,S=v+(_<<12&4294967295|_>>>20),_=E+(w^S&(v^w))+I[10]+4294925233&4294967295,E=S+(_<<17&4294967295|_>>>15),_=w+(v^E&(S^v))+I[11]+2304563134&4294967295,w=E+(_<<22&4294967295|_>>>10),_=v+(S^w&(E^S))+I[12]+1804603682&4294967295,v=w+(_<<7&4294967295|_>>>25),_=S+(E^v&(w^E))+I[13]+4254626195&4294967295,S=v+(_<<12&4294967295|_>>>20),_=E+(w^S&(v^w))+I[14]+2792965006&4294967295,E=S+(_<<17&4294967295|_>>>15),_=w+(v^E&(S^v))+I[15]+1236535329&4294967295,w=E+(_<<22&4294967295|_>>>10),_=v+(E^S&(w^E))+I[1]+4129170786&4294967295,v=w+(_<<5&4294967295|_>>>27),_=S+(w^E&(v^w))+I[6]+3225465664&4294967295,S=v+(_<<9&4294967295|_>>>23),_=E+(v^w&(S^v))+I[11]+643717713&4294967295,E=S+(_<<14&4294967295|_>>>18),_=w+(S^v&(E^S))+I[0]+3921069994&4294967295,w=E+(_<<20&4294967295|_>>>12),_=v+(E^S&(w^E))+I[5]+3593408605&4294967295,v=w+(_<<5&4294967295|_>>>27),_=S+(w^E&(v^w))+I[10]+38016083&4294967295,S=v+(_<<9&4294967295|_>>>23),_=E+(v^w&(S^v))+I[15]+3634488961&4294967295,E=S+(_<<14&4294967295|_>>>18),_=w+(S^v&(E^S))+I[4]+3889429448&4294967295,w=E+(_<<20&4294967295|_>>>12),_=v+(E^S&(w^E))+I[9]+568446438&4294967295,v=w+(_<<5&4294967295|_>>>27),_=S+(w^E&(v^w))+I[14]+3275163606&4294967295,S=v+(_<<9&4294967295|_>>>23),_=E+(v^w&(S^v))+I[3]+4107603335&4294967295,E=S+(_<<14&4294967295|_>>>18),_=w+(S^v&(E^S))+I[8]+1163531501&4294967295,w=E+(_<<20&4294967295|_>>>12),_=v+(E^S&(w^E))+I[13]+2850285829&4294967295,v=w+(_<<5&4294967295|_>>>27),_=S+(w^E&(v^w))+I[2]+4243563512&4294967295,S=v+(_<<9&4294967295|_>>>23),_=E+(v^w&(S^v))+I[7]+1735328473&4294967295,E=S+(_<<14&4294967295|_>>>18),_=w+(S^v&(E^S))+I[12]+2368359562&4294967295,w=E+(_<<20&4294967295|_>>>12),_=v+(w^E^S)+I[5]+4294588738&4294967295,v=w+(_<<4&4294967295|_>>>28),_=S+(v^w^E)+I[8]+2272392833&4294967295,S=v+(_<<11&4294967295|_>>>21),_=E+(S^v^w)+I[11]+1839030562&4294967295,E=S+(_<<16&4294967295|_>>>16),_=w+(E^S^v)+I[14]+4259657740&4294967295,w=E+(_<<23&4294967295|_>>>9),_=v+(w^E^S)+I[1]+2763975236&4294967295,v=w+(_<<4&4294967295|_>>>28),_=S+(v^w^E)+I[4]+1272893353&4294967295,S=v+(_<<11&4294967295|_>>>21),_=E+(S^v^w)+I[7]+4139469664&4294967295,E=S+(_<<16&4294967295|_>>>16),_=w+(E^S^v)+I[10]+3200236656&4294967295,w=E+(_<<23&4294967295|_>>>9),_=v+(w^E^S)+I[13]+681279174&4294967295,v=w+(_<<4&4294967295|_>>>28),_=S+(v^w^E)+I[0]+3936430074&4294967295,S=v+(_<<11&4294967295|_>>>21),_=E+(S^v^w)+I[3]+3572445317&4294967295,E=S+(_<<16&4294967295|_>>>16),_=w+(E^S^v)+I[6]+76029189&4294967295,w=E+(_<<23&4294967295|_>>>9),_=v+(w^E^S)+I[9]+3654602809&4294967295,v=w+(_<<4&4294967295|_>>>28),_=S+(v^w^E)+I[12]+3873151461&4294967295,S=v+(_<<11&4294967295|_>>>21),_=E+(S^v^w)+I[15]+530742520&4294967295,E=S+(_<<16&4294967295|_>>>16),_=w+(E^S^v)+I[2]+3299628645&4294967295,w=E+(_<<23&4294967295|_>>>9),_=v+(E^(w|~S))+I[0]+4096336452&4294967295,v=w+(_<<6&4294967295|_>>>26),_=S+(w^(v|~E))+I[7]+1126891415&4294967295,S=v+(_<<10&4294967295|_>>>22),_=E+(v^(S|~w))+I[14]+2878612391&4294967295,E=S+(_<<15&4294967295|_>>>17),_=w+(S^(E|~v))+I[5]+4237533241&4294967295,w=E+(_<<21&4294967295|_>>>11),_=v+(E^(w|~S))+I[12]+1700485571&4294967295,v=w+(_<<6&4294967295|_>>>26),_=S+(w^(v|~E))+I[3]+2399980690&4294967295,S=v+(_<<10&4294967295|_>>>22),_=E+(v^(S|~w))+I[10]+4293915773&4294967295,E=S+(_<<15&4294967295|_>>>17),_=w+(S^(E|~v))+I[1]+2240044497&4294967295,w=E+(_<<21&4294967295|_>>>11),_=v+(E^(w|~S))+I[8]+1873313359&4294967295,v=w+(_<<6&4294967295|_>>>26),_=S+(w^(v|~E))+I[15]+4264355552&4294967295,S=v+(_<<10&4294967295|_>>>22),_=E+(v^(S|~w))+I[6]+2734768916&4294967295,E=S+(_<<15&4294967295|_>>>17),_=w+(S^(E|~v))+I[13]+1309151649&4294967295,w=E+(_<<21&4294967295|_>>>11),_=v+(E^(w|~S))+I[4]+4149444226&4294967295,v=w+(_<<6&4294967295|_>>>26),_=S+(w^(v|~E))+I[11]+3174756917&4294967295,S=v+(_<<10&4294967295|_>>>22),_=E+(v^(S|~w))+I[2]+718787259&4294967295,E=S+(_<<15&4294967295|_>>>17),_=w+(S^(E|~v))+I[9]+3951481745&4294967295,T.g[0]=T.g[0]+v&4294967295,T.g[1]=T.g[1]+(E+(_<<21&4294967295|_>>>11))&4294967295,T.g[2]=T.g[2]+E&4294967295,T.g[3]=T.g[3]+S&4294967295}r.prototype.v=function(T,v){v===void 0&&(v=T.length);const w=v-this.blockSize,I=this.C;let E=this.h,S=0;for(;S<v;){if(E==0)for(;S<=w;)i(this,T,S),S+=this.blockSize;if(typeof T=="string"){for(;S<v;)if(I[E++]=T.charCodeAt(S++),E==this.blockSize){i(this,I),E=0;break}}else for(;S<v;)if(I[E++]=T[S++],E==this.blockSize){i(this,I),E=0;break}}this.h=E,this.o+=v},r.prototype.A=function(){var T=Array((this.h<56?this.blockSize:this.blockSize*2)-this.h);T[0]=128;for(var v=1;v<T.length-8;++v)T[v]=0;v=this.o*8;for(var w=T.length-8;w<T.length;++w)T[w]=v&255,v/=256;for(this.v(T),T=Array(16),v=0,w=0;w<4;++w)for(let I=0;I<32;I+=8)T[v++]=this.g[w]>>>I&255;return T};function o(T,v){var w=l;return Object.prototype.hasOwnProperty.call(w,T)?w[T]:w[T]=v(T)}function s(T,v){this.h=v;const w=[];let I=!0;for(let E=T.length-1;E>=0;E--){const S=T[E]|0;I&&S==v||(w[E]=S,I=!1)}this.g=w}var l={};function u(T){return-128<=T&&T<128?o(T,function(v){return new s([v|0],v<0?-1:0)}):new s([T|0],T<0?-1:0)}function h(T){if(isNaN(T)||!isFinite(T))return m;if(T<0)return O(h(-T));const v=[];let w=1;for(let I=0;T>=w;I++)v[I]=T/w|0,w*=4294967296;return new s(v,0)}function p(T,v){if(T.length==0)throw Error("number format error: empty string");if(v=v||10,v<2||36<v)throw Error("radix out of range: "+v);if(T.charAt(0)=="-")return O(p(T.substring(1),v));if(T.indexOf("-")>=0)throw Error('number format error: interior "-" character');const w=h(Math.pow(v,8));let I=m;for(let S=0;S<T.length;S+=8){var E=Math.min(8,T.length-S);const _=parseInt(T.substring(S,S+E),v);E<8?(E=h(Math.pow(v,E)),I=I.j(E).add(h(_))):(I=I.j(w),I=I.add(h(_)))}return I}var m=u(0),g=u(1),b=u(16777216);n=s.prototype,n.m=function(){if(A(this))return-O(this).m();let T=0,v=1;for(let w=0;w<this.g.length;w++){const I=this.i(w);T+=(I>=0?I:4294967296+I)*v,v*=4294967296}return T},n.toString=function(T){if(T=T||10,T<2||36<T)throw Error("radix out of range: "+T);if(P(this))return"0";if(A(this))return"-"+O(this).toString(T);const v=h(Math.pow(T,6));var w=this;let I="";for(;;){const E=H(w,v).g;w=F(w,E.j(v));let S=((w.g.length>0?w.g[0]:w.h)>>>0).toString(T);if(w=E,P(w))return S+I;for(;S.length<6;)S="0"+S;I=S+I}},n.i=function(T){return T<0?0:T<this.g.length?this.g[T]:this.h};function P(T){if(T.h!=0)return!1;for(let v=0;v<T.g.length;v++)if(T.g[v]!=0)return!1;return!0}function A(T){return T.h==-1}n.l=function(T){return T=F(this,T),A(T)?-1:P(T)?0:1};function O(T){const v=T.g.length,w=[];for(let I=0;I<v;I++)w[I]=~T.g[I];return new s(w,~T.h).add(g)}n.abs=function(){return A(this)?O(this):this},n.add=function(T){const v=Math.max(this.g.length,T.g.length),w=[];let I=0;for(let E=0;E<=v;E++){let S=I+(this.i(E)&65535)+(T.i(E)&65535),_=(S>>>16)+(this.i(E)>>>16)+(T.i(E)>>>16);I=_>>>16,S&=65535,_&=65535,w[E]=_<<16|S}return new s(w,w[w.length-1]&-2147483648?-1:0)};function F(T,v){return T.add(O(v))}n.j=function(T){if(P(this)||P(T))return m;if(A(this))return A(T)?O(this).j(O(T)):O(O(this).j(T));if(A(T))return O(this.j(O(T)));if(this.l(b)<0&&T.l(b)<0)return h(this.m()*T.m());const v=this.g.length+T.g.length,w=[];for(var I=0;I<2*v;I++)w[I]=0;for(I=0;I<this.g.length;I++)for(let E=0;E<T.g.length;E++){const S=this.i(I)>>>16,_=this.i(I)&65535,xe=T.i(E)>>>16,rt=T.i(E)&65535;w[2*I+2*E]+=_*rt,U(w,2*I+2*E),w[2*I+2*E+1]+=S*rt,U(w,2*I+2*E+1),w[2*I+2*E+1]+=_*xe,U(w,2*I+2*E+1),w[2*I+2*E+2]+=S*xe,U(w,2*I+2*E+2)}for(T=0;T<v;T++)w[T]=w[2*T+1]<<16|w[2*T];for(T=v;T<2*v;T++)w[T]=0;return new s(w,0)};function U(T,v){for(;(T[v]&65535)!=T[v];)T[v+1]+=T[v]>>>16,T[v]&=65535,v++}function V(T,v){this.g=T,this.h=v}function H(T,v){if(P(v))throw Error("division by zero");if(P(T))return new V(m,m);if(A(T))return v=H(O(T),v),new V(O(v.g),O(v.h));if(A(v))return v=H(T,O(v)),new V(O(v.g),v.h);if(T.g.length>30){if(A(T)||A(v))throw Error("slowDivide_ only works with positive integers.");for(var w=g,I=v;I.l(T)<=0;)w=z(w),I=z(I);var E=K(w,1),S=K(I,1);for(I=K(I,2),w=K(w,2);!P(I);){var _=S.add(I);_.l(T)<=0&&(E=E.add(w),S=_),I=K(I,1),w=K(w,1)}return v=F(T,E.j(v)),new V(E,v)}for(E=m;T.l(v)>=0;){for(w=Math.max(1,Math.floor(T.m()/v.m())),I=Math.ceil(Math.log(w)/Math.LN2),I=I<=48?1:Math.pow(2,I-48),S=h(w),_=S.j(v);A(_)||_.l(T)>0;)w-=I,S=h(w),_=S.j(v);P(S)&&(S=g),E=E.add(S),T=F(T,_)}return new V(E,T)}n.B=function(T){return H(this,T).h},n.and=function(T){const v=Math.max(this.g.length,T.g.length),w=[];for(let I=0;I<v;I++)w[I]=this.i(I)&T.i(I);return new s(w,this.h&T.h)},n.or=function(T){const v=Math.max(this.g.length,T.g.length),w=[];for(let I=0;I<v;I++)w[I]=this.i(I)|T.i(I);return new s(w,this.h|T.h)},n.xor=function(T){const v=Math.max(this.g.length,T.g.length),w=[];for(let I=0;I<v;I++)w[I]=this.i(I)^T.i(I);return new s(w,this.h^T.h)};function z(T){const v=T.g.length+1,w=[];for(let I=0;I<v;I++)w[I]=T.i(I)<<1|T.i(I-1)>>>31;return new s(w,T.h)}function K(T,v){const w=v>>5;v%=32;const I=T.g.length-w,E=[];for(let S=0;S<I;S++)E[S]=v>0?T.i(S+w)>>>v|T.i(S+w+1)<<32-v:T.i(S+w);return new s(E,T.h)}r.prototype.digest=r.prototype.A,r.prototype.reset=r.prototype.u,r.prototype.update=r.prototype.v,Zf=r,s.prototype.add=s.prototype.add,s.prototype.multiply=s.prototype.j,s.prototype.modulo=s.prototype.B,s.prototype.compare=s.prototype.l,s.prototype.toNumber=s.prototype.m,s.prototype.toString=s.prototype.toString,s.prototype.getBits=s.prototype.i,s.fromNumber=h,s.fromString=p,Fn=s}).apply(typeof Lh<"u"?Lh:typeof self<"u"?self:typeof window<"u"?window:{});var ls=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/var ep,Ji,tp,As,El,np,rp,ip;(function(){var n,e=Object.defineProperty;function t(a){a=[typeof globalThis=="object"&&globalThis,a,typeof window=="object"&&window,typeof self=="object"&&self,typeof ls=="object"&&ls];for(var d=0;d<a.length;++d){var f=a[d];if(f&&f.Math==Math)return f}throw Error("Cannot find global object")}var r=t(this);function i(a,d){if(d)e:{var f=r;a=a.split(".");for(var y=0;y<a.length-1;y++){var k=a[y];if(!(k in f))break e;f=f[k]}a=a[a.length-1],y=f[a],d=d(y),d!=y&&d!=null&&e(f,a,{configurable:!0,writable:!0,value:d})}}i("Symbol.dispose",function(a){return a||Symbol("Symbol.dispose")}),i("Array.prototype.values",function(a){return a||function(){return this[Symbol.iterator]()}}),i("Object.entries",function(a){return a||function(d){var f=[],y;for(y in d)Object.prototype.hasOwnProperty.call(d,y)&&f.push([y,d[y]]);return f}});/** @license

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/var o=o||{},s=this||self;function l(a){var d=typeof a;return d=="object"&&a!=null||d=="function"}function u(a,d,f){return a.call.apply(a.bind,arguments)}function h(a,d,f){return h=u,h.apply(null,arguments)}function p(a,d){var f=Array.prototype.slice.call(arguments,1);return function(){var y=f.slice();return y.push.apply(y,arguments),a.apply(this,y)}}function m(a,d){function f(){}f.prototype=d.prototype,a.Z=d.prototype,a.prototype=new f,a.prototype.constructor=a,a.Ob=function(y,k,R){for(var q=Array(arguments.length-2),ee=2;ee<arguments.length;ee++)q[ee-2]=arguments[ee];return d.prototype[k].apply(y,q)}}var g=typeof AsyncContext<"u"&&typeof AsyncContext.Snapshot=="function"?a=>a&&AsyncContext.Snapshot.wrap(a):a=>a;function b(a){const d=a.length;if(d>0){const f=Array(d);for(let y=0;y<d;y++)f[y]=a[y];return f}return[]}function P(a,d){for(let y=1;y<arguments.length;y++){const k=arguments[y];var f=typeof k;if(f=f!="object"?f:k?Array.isArray(k)?"array":f:"null",f=="array"||f=="object"&&typeof k.length=="number"){f=a.length||0;const R=k.length||0;a.length=f+R;for(let q=0;q<R;q++)a[f+q]=k[q]}else a.push(k)}}class A{constructor(d,f){this.i=d,this.j=f,this.h=0,this.g=null}get(){let d;return this.h>0?(this.h--,d=this.g,this.g=d.next,d.next=null):d=this.i(),d}}function O(a){s.setTimeout(()=>{throw a},0)}function F(){var a=T;let d=null;return a.g&&(d=a.g,a.g=a.g.next,a.g||(a.h=null),d.next=null),d}class U{constructor(){this.h=this.g=null}add(d,f){const y=V.get();y.set(d,f),this.h?this.h.next=y:this.g=y,this.h=y}}var V=new A(()=>new H,a=>a.reset());class H{constructor(){this.next=this.g=this.h=null}set(d,f){this.h=d,this.g=f,this.next=null}reset(){this.next=this.g=this.h=null}}let z,K=!1,T=new U,v=()=>{const a=Promise.resolve(void 0);z=()=>{a.then(w)}};function w(){for(var a;a=F();){try{a.h.call(a.g)}catch(f){O(f)}var d=V;d.j(a),d.h<100&&(d.h++,a.next=d.g,d.g=a)}K=!1}function I(){this.u=this.u,this.C=this.C}I.prototype.u=!1,I.prototype.dispose=function(){this.u||(this.u=!0,this.N())},I.prototype[Symbol.dispose]=function(){this.dispose()},I.prototype.N=function(){if(this.C)for(;this.C.length;)this.C.shift()()};function E(a,d){this.type=a,this.g=this.target=d,this.defaultPrevented=!1}E.prototype.h=function(){this.defaultPrevented=!0};var S=function(){if(!s.addEventListener||!Object.defineProperty)return!1;var a=!1,d=Object.defineProperty({},"passive",{get:function(){a=!0}});try{const f=()=>{};s.addEventListener("test",f,d),s.removeEventListener("test",f,d)}catch{}return a}();function _(a){return/^[\s\xa0]*$/.test(a)}function xe(a,d){E.call(this,a?a.type:""),this.relatedTarget=this.g=this.target=null,this.button=this.screenY=this.screenX=this.clientY=this.clientX=0,this.key="",this.metaKey=this.shiftKey=this.altKey=this.ctrlKey=!1,this.state=null,this.pointerId=0,this.pointerType="",this.i=null,a&&this.init(a,d)}m(xe,E),xe.prototype.init=function(a,d){const f=this.type=a.type,y=a.changedTouches&&a.changedTouches.length?a.changedTouches[0]:null;this.target=a.target||a.srcElement,this.g=d,d=a.relatedTarget,d||(f=="mouseover"?d=a.fromElement:f=="mouseout"&&(d=a.toElement)),this.relatedTarget=d,y?(this.clientX=y.clientX!==void 0?y.clientX:y.pageX,this.clientY=y.clientY!==void 0?y.clientY:y.pageY,this.screenX=y.screenX||0,this.screenY=y.screenY||0):(this.clientX=a.clientX!==void 0?a.clientX:a.pageX,this.clientY=a.clientY!==void 0?a.clientY:a.pageY,this.screenX=a.screenX||0,this.screenY=a.screenY||0),this.button=a.button,this.key=a.key||"",this.ctrlKey=a.ctrlKey,this.altKey=a.altKey,this.shiftKey=a.shiftKey,this.metaKey=a.metaKey,this.pointerId=a.pointerId||0,this.pointerType=a.pointerType,this.state=a.state,this.i=a,a.defaultPrevented&&xe.Z.h.call(this)},xe.prototype.h=function(){xe.Z.h.call(this);const a=this.i;a.preventDefault?a.preventDefault():a.returnValue=!1};var rt="closure_listenable_"+(Math.random()*1e6|0),Or=0;function _n(a,d,f,y,k){this.listener=a,this.proxy=null,this.src=d,this.type=f,this.capture=!!y,this.ha=k,this.key=++Or,this.da=this.fa=!1}function vt(a){a.da=!0,a.listener=null,a.proxy=null,a.src=null,a.ha=null}function bt(a,d,f){for(const y in a)d.call(f,a[y],y,a)}function it(a,d){for(const f in a)d.call(void 0,a[f],f,a)}function ue(a){const d={};for(const f in a)d[f]=a[f];return d}const ke="constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");function ye(a,d){let f,y;for(let k=1;k<arguments.length;k++){y=arguments[k];for(f in y)a[f]=y[f];for(let R=0;R<ke.length;R++)f=ke[R],Object.prototype.hasOwnProperty.call(y,f)&&(a[f]=y[f])}}function Je(a){this.src=a,this.g={},this.h=0}Je.prototype.add=function(a,d,f,y,k){const R=a.toString();a=this.g[R],a||(a=this.g[R]=[],this.h++);const q=Nr(a,d,y,k);return q>-1?(d=a[q],f||(d.fa=!1)):(d=new _n(d,this.src,R,!!y,k),d.fa=f,a.push(d)),d};function Kt(a,d){const f=d.type;if(f in a.g){var y=a.g[f],k=Array.prototype.indexOf.call(y,d,void 0),R;(R=k>=0)&&Array.prototype.splice.call(y,k,1),R&&(vt(d),a.g[f].length==0&&(delete a.g[f],a.h--))}}function Nr(a,d,f,y){for(let k=0;k<a.length;++k){const R=a[k];if(!R.da&&R.listener==d&&R.capture==!!f&&R.ha==y)return k}return-1}var Dr="closure_lm_"+(Math.random()*1e6|0),N={};function $(a,d,f,y,k){if(Array.isArray(d)){for(let R=0;R<d.length;R++)$(a,d[R],f,y,k);return null}return f=pu(f),a&&a[rt]?a.J(d,f,l(y)?!!y.capture:!1,k):te(a,d,f,!1,y,k)}function te(a,d,f,y,k,R){if(!d)throw Error("Invalid event type");const q=l(k)?!!k.capture:!!k;let ee=Vr(a);if(ee||(a[Dr]=ee=new Je(a)),f=ee.add(d,f,y,q,R),f.proxy)return f;if(y=ot(),f.proxy=y,y.src=a,y.listener=f,a.addEventListener)S||(k=q),k===void 0&&(k=!1),a.addEventListener(d.toString(),y,k);else if(a.attachEvent)a.attachEvent(Yt(d.toString()),y);else if(a.addListener&&a.removeListener)a.addListener(y);else throw Error("addEventListener and attachEvent are unavailable.");return f}function ot(){function a(f){return d.call(a.src,a.listener,f)}const d=fu;return a}function Mr(a,d,f,y,k){if(Array.isArray(d))for(var R=0;R<d.length;R++)Mr(a,d[R],f,y,k);else y=l(y)?!!y.capture:!!y,f=pu(f),a&&a[rt]?(a=a.i,R=String(d).toString(),R in a.g&&(d=a.g[R],f=Nr(d,f,y,k),f>-1&&(vt(d[f]),Array.prototype.splice.call(d,f,1),d.length==0&&(delete a.g[R],a.h--)))):a&&(a=Vr(a))&&(d=a.g[d.toString()],a=-1,d&&(a=Nr(d,f,y,k)),(f=a>-1?d[a]:null)&&Lr(f))}function Lr(a){if(typeof a!="number"&&a&&!a.da){var d=a.src;if(d&&d[rt])Kt(d.i,a);else{var f=a.type,y=a.proxy;d.removeEventListener?d.removeEventListener(f,y,a.capture):d.detachEvent?d.detachEvent(Yt(f),y):d.addListener&&d.removeListener&&d.removeListener(y),(f=Vr(d))?(Kt(f,a),f.h==0&&(f.src=null,d[Dr]=null)):vt(a)}}}function Yt(a){return a in N?N[a]:N[a]="on"+a}function fu(a,d){if(a.da)a=!0;else{d=new xe(d,this);const f=a.listener,y=a.ha||a.src;a.fa&&Lr(a),a=f.call(y,d)}return a}function Vr(a){return a=a[Dr],a instanceof Je?a:null}var Ca="__closure_events_fn_"+(Math.random()*1e9>>>0);function pu(a){return typeof a=="function"?a:(a[Ca]||(a[Ca]=function(d){return a.handleEvent(d)}),a[Ca])}function Ge(){I.call(this),this.i=new Je(this),this.M=this,this.G=null}m(Ge,I),Ge.prototype[rt]=!0,Ge.prototype.removeEventListener=function(a,d,f,y){Mr(this,a,d,f,y)};function Ze(a,d){var f,y=a.G;if(y)for(f=[];y;y=y.G)f.push(y);if(a=a.M,y=d.type||d,typeof d=="string")d=new E(d,a);else if(d instanceof E)d.target=d.target||a;else{var k=d;d=new E(y,a),ye(d,k)}k=!0;let R,q;if(f)for(q=f.length-1;q>=0;q--)R=d.g=f[q],k=Yo(R,y,!0,d)&&k;if(R=d.g=a,k=Yo(R,y,!0,d)&&k,k=Yo(R,y,!1,d)&&k,f)for(q=0;q<f.length;q++)R=d.g=f[q],k=Yo(R,y,!1,d)&&k}Ge.prototype.N=function(){if(Ge.Z.N.call(this),this.i){var a=this.i;for(const d in a.g){const f=a.g[d];for(let y=0;y<f.length;y++)vt(f[y]);delete a.g[d],a.h--}}this.G=null},Ge.prototype.J=function(a,d,f,y){return this.i.add(String(a),d,!1,f,y)},Ge.prototype.K=function(a,d,f,y){return this.i.add(String(a),d,!0,f,y)};function Yo(a,d,f,y){if(d=a.i.g[String(d)],!d)return!0;d=d.concat();let k=!0;for(let R=0;R<d.length;++R){const q=d[R];if(q&&!q.da&&q.capture==f){const ee=q.listener,Ne=q.ha||q.src;q.fa&&Kt(a.i,q),k=ee.call(Ne,y)!==!1&&k}}return k&&!y.defaultPrevented}function Em(a,d){if(typeof a!="function")if(a&&typeof a.handleEvent=="function")a=h(a.handleEvent,a);else throw Error("Invalid listener argument");return Number(d)>2147483647?-1:s.setTimeout(a,d||0)}function gu(a){a.g=Em(()=>{a.g=null,a.i&&(a.i=!1,gu(a))},a.l);const d=a.h;a.h=null,a.m.apply(null,d)}class Im extends I{constructor(d,f){super(),this.m=d,this.l=f,this.h=null,this.i=!1,this.g=null}j(d){this.h=arguments,this.g?this.i=!0:gu(this)}N(){super.N(),this.g&&(s.clearTimeout(this.g),this.g=null,this.i=!1,this.h=null)}}function ki(a){I.call(this),this.h=a,this.g={}}m(ki,I);var mu=[];function yu(a){bt(a.g,function(d,f){this.g.hasOwnProperty(f)&&Lr(d)},a),a.g={}}ki.prototype.N=function(){ki.Z.N.call(this),yu(this)},ki.prototype.handleEvent=function(){throw Error("EventHandler.handleEvent not implemented")};var Ra=s.JSON.stringify,Am=s.JSON.parse,Sm=class{stringify(a){return s.JSON.stringify(a,void 0)}parse(a){return s.JSON.parse(a,void 0)}};function vu(){}function _u(){}var Pi={OPEN:"a",hb:"b",ERROR:"c",tb:"d"};function Oa(){E.call(this,"d")}m(Oa,E);function Na(){E.call(this,"c")}m(Na,E);var Zn={},wu=null;function Qo(){return wu=wu||new Ge}Zn.Ia="serverreachability";function bu(a){E.call(this,Zn.Ia,a)}m(bu,E);function Ci(a){const d=Qo();Ze(d,new bu(d))}Zn.STAT_EVENT="statevent";function Tu(a,d){E.call(this,Zn.STAT_EVENT,a),this.stat=d}m(Tu,E);function et(a){const d=Qo();Ze(d,new Tu(d,a))}Zn.Ja="timingevent";function Eu(a,d){E.call(this,Zn.Ja,a),this.size=d}m(Eu,E);function Ri(a,d){if(typeof a!="function")throw Error("Fn must not be null and must be a function");return s.setTimeout(function(){a()},d)}function Oi(){this.g=!0}Oi.prototype.ua=function(){this.g=!1};function xm(a,d,f,y,k,R){a.info(function(){if(a.g)if(R){var q="",ee=R.split("&");for(let fe=0;fe<ee.length;fe++){var Ne=ee[fe].split("=");if(Ne.length>1){const qe=Ne[0];Ne=Ne[1];const Ot=qe.split("_");q=Ot.length>=2&&Ot[1]=="type"?q+(qe+"="+Ne+"&"):q+(qe+"=redacted&")}}}else q=null;else q=R;return"XMLHTTP REQ ("+y+") [attempt "+k+"]: "+d+`
`+f+`
`+q})}function km(a,d,f,y,k,R,q){a.info(function(){return"XMLHTTP RESP ("+y+") [ attempt "+k+"]: "+d+`
`+f+`
`+R+" "+q})}function Fr(a,d,f,y){a.info(function(){return"XMLHTTP TEXT ("+d+"): "+Cm(a,f)+(y?" "+y:"")})}function Pm(a,d){a.info(function(){return"TIMEOUT: "+d})}Oi.prototype.info=function(){};function Cm(a,d){if(!a.g)return d;if(!d)return null;try{const R=JSON.parse(d);if(R){for(a=0;a<R.length;a++)if(Array.isArray(R[a])){var f=R[a];if(!(f.length<2)){var y=f[1];if(Array.isArray(y)&&!(y.length<1)){var k=y[0];if(k!="noop"&&k!="stop"&&k!="close")for(let q=1;q<y.length;q++)y[q]=""}}}}return Ra(R)}catch{return d}}var Xo={NO_ERROR:0,cb:1,qb:2,pb:3,kb:4,ob:5,rb:6,Ga:7,TIMEOUT:8,ub:9},Iu={ib:"complete",Fb:"success",ERROR:"error",Ga:"abort",xb:"ready",yb:"readystatechange",TIMEOUT:"timeout",sb:"incrementaldata",wb:"progress",lb:"downloadprogress",Nb:"uploadprogress"},Au;function Da(){}m(Da,vu),Da.prototype.g=function(){return new XMLHttpRequest},Au=new Da;function Ni(a){return encodeURIComponent(String(a))}function Rm(a){var d=1;a=a.split(":");const f=[];for(;d>0&&a.length;)f.push(a.shift()),d--;return a.length&&f.push(a.join(":")),f}function wn(a,d,f,y){this.j=a,this.i=d,this.l=f,this.S=y||1,this.V=new ki(this),this.H=45e3,this.J=null,this.o=!1,this.u=this.B=this.A=this.M=this.F=this.T=this.D=null,this.G=[],this.g=null,this.C=0,this.m=this.v=null,this.X=-1,this.K=!1,this.P=0,this.O=null,this.W=this.L=this.U=this.R=!1,this.h=new Su}function Su(){this.i=null,this.g="",this.h=!1}var xu={},Ma={};function La(a,d,f){a.M=1,a.A=Zo(Rt(d)),a.u=f,a.R=!0,ku(a,null)}function ku(a,d){a.F=Date.now(),Jo(a),a.B=Rt(a.A);var f=a.B,y=a.S;Array.isArray(y)||(y=[String(y)]),Bu(f.i,"t",y),a.C=0,f=a.j.L,a.h=new Su,a.g=oh(a.j,f?d:null,!a.u),a.P>0&&(a.O=new Im(h(a.Y,a,a.g),a.P)),d=a.V,f=a.g,y=a.ba;var k="readystatechange";Array.isArray(k)||(k&&(mu[0]=k.toString()),k=mu);for(let R=0;R<k.length;R++){const q=$(f,k[R],y||d.handleEvent,!1,d.h||d);if(!q)break;d.g[q.key]=q}d=a.J?ue(a.J):{},a.u?(a.v||(a.v="POST"),d["Content-Type"]="application/x-www-form-urlencoded",a.g.ea(a.B,a.v,a.u,d)):(a.v="GET",a.g.ea(a.B,a.v,null,d)),Ci(),xm(a.i,a.v,a.B,a.l,a.S,a.u)}wn.prototype.ba=function(a){a=a.target;const d=this.O;d&&En(a)==3?d.j():this.Y(a)},wn.prototype.Y=function(a){try{if(a==this.g)e:{const ee=En(this.g),Ne=this.g.ya(),fe=this.g.ca();if(!(ee<3)&&(ee!=3||this.g&&(this.h.h||this.g.la()||Ku(this.g)))){this.K||ee!=4||Ne==7||(Ne==8||fe<=0?Ci(3):Ci(2)),Va(this);var d=this.g.ca();this.X=d;var f=Om(this);if(this.o=d==200,km(this.i,this.v,this.B,this.l,this.S,ee,d),this.o){if(this.U&&!this.L){t:{if(this.g){var y,k=this.g;if((y=k.g?k.g.getResponseHeader("X-HTTP-Initial-Response"):null)&&!_(y)){var R=y;break t}}R=null}if(a=R)Fr(this.i,this.l,a,"Initial handshake response via X-HTTP-Initial-Response"),this.L=!0,Fa(this,a);else{this.o=!1,this.m=3,et(12),er(this),Di(this);break e}}if(this.R){a=!0;let qe;for(;!this.K&&this.C<f.length;)if(qe=Nm(this,f),qe==Ma){ee==4&&(this.m=4,et(14),a=!1),Fr(this.i,this.l,null,"[Incomplete Response]");break}else if(qe==xu){this.m=4,et(15),Fr(this.i,this.l,f,"[Invalid Chunk]"),a=!1;break}else Fr(this.i,this.l,qe,null),Fa(this,qe);if(Pu(this)&&this.C!=0&&(this.h.g=this.h.g.slice(this.C),this.C=0),ee!=4||f.length!=0||this.h.h||(this.m=1,et(16),a=!1),this.o=this.o&&a,!a)Fr(this.i,this.l,f,"[Invalid Chunked Response]"),er(this),Di(this);else if(f.length>0&&!this.W){this.W=!0;var q=this.j;q.g==this&&q.aa&&!q.P&&(q.j.info("Great, no buffering proxy detected. Bytes received: "+f.length),Ha(q),q.P=!0,et(11))}}else Fr(this.i,this.l,f,null),Fa(this,f);ee==4&&er(this),this.o&&!this.K&&(ee==4?th(this.j,this):(this.o=!1,Jo(this)))}else Gm(this.g),d==400&&f.indexOf("Unknown SID")>0?(this.m=3,et(12)):(this.m=0,et(13)),er(this),Di(this)}}}catch{}finally{}};function Om(a){if(!Pu(a))return a.g.la();const d=Ku(a.g);if(d==="")return"";let f="";const y=d.length,k=En(a.g)==4;if(!a.h.i){if(typeof TextDecoder>"u")return er(a),Di(a),"";a.h.i=new s.TextDecoder}for(let R=0;R<y;R++)a.h.h=!0,f+=a.h.i.decode(d[R],{stream:!(k&&R==y-1)});return d.length=0,a.h.g+=f,a.C=0,a.h.g}function Pu(a){return a.g?a.v=="GET"&&a.M!=2&&a.j.Aa:!1}function Nm(a,d){var f=a.C,y=d.indexOf(`
`,f);return y==-1?Ma:(f=Number(d.substring(f,y)),isNaN(f)?xu:(y+=1,y+f>d.length?Ma:(d=d.slice(y,y+f),a.C=y+f,d)))}wn.prototype.cancel=function(){this.K=!0,er(this)};function Jo(a){a.T=Date.now()+a.H,Cu(a,a.H)}function Cu(a,d){if(a.D!=null)throw Error("WatchDog timer not null");a.D=Ri(h(a.aa,a),d)}function Va(a){a.D&&(s.clearTimeout(a.D),a.D=null)}wn.prototype.aa=function(){this.D=null;const a=Date.now();a-this.T>=0?(Pm(this.i,this.B),this.M!=2&&(Ci(),et(17)),er(this),this.m=2,Di(this)):Cu(this,this.T-a)};function Di(a){a.j.I==0||a.K||th(a.j,a)}function er(a){Va(a);var d=a.O;d&&typeof d.dispose=="function"&&d.dispose(),a.O=null,yu(a.V),a.g&&(d=a.g,a.g=null,d.abort(),d.dispose())}function Fa(a,d){try{var f=a.j;if(f.I!=0&&(f.g==a||Ua(f.h,a))){if(!a.L&&Ua(f.h,a)&&f.I==3){try{var y=f.Ba.g.parse(d)}catch{y=null}if(Array.isArray(y)&&y.length==3){var k=y;if(k[0]==0){e:if(!f.v){if(f.g)if(f.g.F+3e3<a.F)is(f),ns(f);else break e;Wa(f),et(18)}}else f.xa=k[1],0<f.xa-f.K&&k[2]<37500&&f.F&&f.A==0&&!f.C&&(f.C=Ri(h(f.Va,f),6e3));Nu(f.h)<=1&&f.ta&&(f.ta=void 0)}else nr(f,11)}else if((a.L||f.g==a)&&is(f),!_(d))for(k=f.Ba.g.parse(d),d=0;d<k.length;d++){let fe=k[d];const qe=fe[0];if(!(qe<=f.K))if(f.K=qe,fe=fe[1],f.I==2)if(fe[0]=="c"){f.M=fe[1],f.ba=fe[2];const Ot=fe[3];Ot!=null&&(f.ka=Ot,f.j.info("VER="+f.ka));const rr=fe[4];rr!=null&&(f.za=rr,f.j.info("SVER="+f.za));const In=fe[5];In!=null&&typeof In=="number"&&In>0&&(y=1.5*In,f.O=y,f.j.info("backChannelRequestTimeoutMs_="+y)),y=f;const An=a.g;if(An){const ss=An.g?An.g.getResponseHeader("X-Client-Wire-Protocol"):null;if(ss){var R=y.h;R.g||ss.indexOf("spdy")==-1&&ss.indexOf("quic")==-1&&ss.indexOf("h2")==-1||(R.j=R.l,R.g=new Set,R.h&&(qa(R,R.h),R.h=null))}if(y.G){const Ga=An.g?An.g.getResponseHeader("X-HTTP-Session-Id"):null;Ga&&(y.wa=Ga,ge(y.J,y.G,Ga))}}f.I=3,f.l&&f.l.ra(),f.aa&&(f.T=Date.now()-a.F,f.j.info("Handshake RTT: "+f.T+"ms")),y=f;var q=a;if(y.na=ih(y,y.L?y.ba:null,y.W),q.L){Du(y.h,q);var ee=q,Ne=y.O;Ne&&(ee.H=Ne),ee.D&&(Va(ee),Jo(ee)),y.g=q}else Zu(y);f.i.length>0&&rs(f)}else fe[0]!="stop"&&fe[0]!="close"||nr(f,7);else f.I==3&&(fe[0]=="stop"||fe[0]=="close"?fe[0]=="stop"?nr(f,7):za(f):fe[0]!="noop"&&f.l&&f.l.qa(fe),f.A=0)}}Ci(4)}catch{}}var Dm=class{constructor(a,d){this.g=a,this.map=d}};function Ru(a){this.l=a||10,s.PerformanceNavigationTiming?(a=s.performance.getEntriesByType("navigation"),a=a.length>0&&(a[0].nextHopProtocol=="hq"||a[0].nextHopProtocol=="h2")):a=!!(s.chrome&&s.chrome.loadTimes&&s.chrome.loadTimes()&&s.chrome.loadTimes().wasFetchedViaSpdy),this.j=a?this.l:1,this.g=null,this.j>1&&(this.g=new Set),this.h=null,this.i=[]}function Ou(a){return a.h?!0:a.g?a.g.size>=a.j:!1}function Nu(a){return a.h?1:a.g?a.g.size:0}function Ua(a,d){return a.h?a.h==d:a.g?a.g.has(d):!1}function qa(a,d){a.g?a.g.add(d):a.h=d}function Du(a,d){a.h&&a.h==d?a.h=null:a.g&&a.g.has(d)&&a.g.delete(d)}Ru.prototype.cancel=function(){if(this.i=Mu(this),this.h)this.h.cancel(),this.h=null;else if(this.g&&this.g.size!==0){for(const a of this.g.values())a.cancel();this.g.clear()}};function Mu(a){if(a.h!=null)return a.i.concat(a.h.G);if(a.g!=null&&a.g.size!==0){let d=a.i;for(const f of a.g.values())d=d.concat(f.G);return d}return b(a.i)}var Lu=RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");function Mm(a,d){if(a){a=a.split("&");for(let f=0;f<a.length;f++){const y=a[f].indexOf("=");let k,R=null;y>=0?(k=a[f].substring(0,y),R=a[f].substring(y+1)):k=a[f],d(k,R?decodeURIComponent(R.replace(/\+/g," ")):"")}}}function bn(a){this.g=this.o=this.j="",this.u=null,this.m=this.h="",this.l=!1;let d;a instanceof bn?(this.l=a.l,Mi(this,a.j),this.o=a.o,this.g=a.g,Li(this,a.u),this.h=a.h,Ba(this,$u(a.i)),this.m=a.m):a&&(d=String(a).match(Lu))?(this.l=!1,Mi(this,d[1]||"",!0),this.o=Vi(d[2]||""),this.g=Vi(d[3]||"",!0),Li(this,d[4]),this.h=Vi(d[5]||"",!0),Ba(this,d[6]||"",!0),this.m=Vi(d[7]||"")):(this.l=!1,this.i=new Ui(null,this.l))}bn.prototype.toString=function(){const a=[];var d=this.j;d&&a.push(Fi(d,Vu,!0),":");var f=this.g;return(f||d=="file")&&(a.push("//"),(d=this.o)&&a.push(Fi(d,Vu,!0),"@"),a.push(Ni(f).replace(/%25([0-9a-fA-F]{2})/g,"%$1")),f=this.u,f!=null&&a.push(":",String(f))),(f=this.h)&&(this.g&&f.charAt(0)!="/"&&a.push("/"),a.push(Fi(f,f.charAt(0)=="/"?Fm:Vm,!0))),(f=this.i.toString())&&a.push("?",f),(f=this.m)&&a.push("#",Fi(f,qm)),a.join("")},bn.prototype.resolve=function(a){const d=Rt(this);let f=!!a.j;f?Mi(d,a.j):f=!!a.o,f?d.o=a.o:f=!!a.g,f?d.g=a.g:f=a.u!=null;var y=a.h;if(f)Li(d,a.u);else if(f=!!a.h){if(y.charAt(0)!="/")if(this.g&&!this.h)y="/"+y;else{var k=d.h.lastIndexOf("/");k!=-1&&(y=d.h.slice(0,k+1)+y)}if(k=y,k==".."||k==".")y="";else if(k.indexOf("./")!=-1||k.indexOf("/.")!=-1){y=k.lastIndexOf("/",0)==0,k=k.split("/");const R=[];for(let q=0;q<k.length;){const ee=k[q++];ee=="."?y&&q==k.length&&R.push(""):ee==".."?((R.length>1||R.length==1&&R[0]!="")&&R.pop(),y&&q==k.length&&R.push("")):(R.push(ee),y=!0)}y=R.join("/")}else y=k}return f?d.h=y:f=a.i.toString()!=="",f?Ba(d,$u(a.i)):f=!!a.m,f&&(d.m=a.m),d};function Rt(a){return new bn(a)}function Mi(a,d,f){a.j=f?Vi(d,!0):d,a.j&&(a.j=a.j.replace(/:$/,""))}function Li(a,d){if(d){if(d=Number(d),isNaN(d)||d<0)throw Error("Bad port number "+d);a.u=d}else a.u=null}function Ba(a,d,f){d instanceof Ui?(a.i=d,Bm(a.i,a.l)):(f||(d=Fi(d,Um)),a.i=new Ui(d,a.l))}function ge(a,d,f){a.i.set(d,f)}function Zo(a){return ge(a,"zx",Math.floor(Math.random()*2147483648).toString(36)+Math.abs(Math.floor(Math.random()*2147483648)^Date.now()).toString(36)),a}function Vi(a,d){return a?d?decodeURI(a.replace(/%25/g,"%2525")):decodeURIComponent(a):""}function Fi(a,d,f){return typeof a=="string"?(a=encodeURI(a).replace(d,Lm),f&&(a=a.replace(/%25([0-9a-fA-F]{2})/g,"%$1")),a):null}function Lm(a){return a=a.charCodeAt(0),"%"+(a>>4&15).toString(16)+(a&15).toString(16)}var Vu=/[#\/\?@]/g,Vm=/[#\?:]/g,Fm=/[#\?]/g,Um=/[#\?@]/g,qm=/#/g;function Ui(a,d){this.h=this.g=null,this.i=a||null,this.j=!!d}function tr(a){a.g||(a.g=new Map,a.h=0,a.i&&Mm(a.i,function(d,f){a.add(decodeURIComponent(d.replace(/\+/g," ")),f)}))}n=Ui.prototype,n.add=function(a,d){tr(this),this.i=null,a=Ur(this,a);let f=this.g.get(a);return f||this.g.set(a,f=[]),f.push(d),this.h+=1,this};function Fu(a,d){tr(a),d=Ur(a,d),a.g.has(d)&&(a.i=null,a.h-=a.g.get(d).length,a.g.delete(d))}function Uu(a,d){return tr(a),d=Ur(a,d),a.g.has(d)}n.forEach=function(a,d){tr(this),this.g.forEach(function(f,y){f.forEach(function(k){a.call(d,k,y,this)},this)},this)};function qu(a,d){tr(a);let f=[];if(typeof d=="string")Uu(a,d)&&(f=f.concat(a.g.get(Ur(a,d))));else for(a=Array.from(a.g.values()),d=0;d<a.length;d++)f=f.concat(a[d]);return f}n.set=function(a,d){return tr(this),this.i=null,a=Ur(this,a),Uu(this,a)&&(this.h-=this.g.get(a).length),this.g.set(a,[d]),this.h+=1,this},n.get=function(a,d){return a?(a=qu(this,a),a.length>0?String(a[0]):d):d};function Bu(a,d,f){Fu(a,d),f.length>0&&(a.i=null,a.g.set(Ur(a,d),b(f)),a.h+=f.length)}n.toString=function(){if(this.i)return this.i;if(!this.g)return"";const a=[],d=Array.from(this.g.keys());for(let y=0;y<d.length;y++){var f=d[y];const k=Ni(f);f=qu(this,f);for(let R=0;R<f.length;R++){let q=k;f[R]!==""&&(q+="="+Ni(f[R])),a.push(q)}}return this.i=a.join("&")};function $u(a){const d=new Ui;return d.i=a.i,a.g&&(d.g=new Map(a.g),d.h=a.h),d}function Ur(a,d){return d=String(d),a.j&&(d=d.toLowerCase()),d}function Bm(a,d){d&&!a.j&&(tr(a),a.i=null,a.g.forEach(function(f,y){const k=y.toLowerCase();y!=k&&(Fu(this,y),Bu(this,k,f))},a)),a.j=d}function $m(a,d){const f=new Oi;if(s.Image){const y=new Image;y.onload=p(Tn,f,"TestLoadImage: loaded",!0,d,y),y.onerror=p(Tn,f,"TestLoadImage: error",!1,d,y),y.onabort=p(Tn,f,"TestLoadImage: abort",!1,d,y),y.ontimeout=p(Tn,f,"TestLoadImage: timeout",!1,d,y),s.setTimeout(function(){y.ontimeout&&y.ontimeout()},1e4),y.src=a}else d(!1)}function jm(a,d){const f=new Oi,y=new AbortController,k=setTimeout(()=>{y.abort(),Tn(f,"TestPingServer: timeout",!1,d)},1e4);fetch(a,{signal:y.signal}).then(R=>{clearTimeout(k),R.ok?Tn(f,"TestPingServer: ok",!0,d):Tn(f,"TestPingServer: server error",!1,d)}).catch(()=>{clearTimeout(k),Tn(f,"TestPingServer: error",!1,d)})}function Tn(a,d,f,y,k){try{k&&(k.onload=null,k.onerror=null,k.onabort=null,k.ontimeout=null),y(f)}catch{}}function zm(){this.g=new Sm}function $a(a){this.i=a.Sb||null,this.h=a.ab||!1}m($a,vu),$a.prototype.g=function(){return new es(this.i,this.h)};function es(a,d){Ge.call(this),this.H=a,this.o=d,this.m=void 0,this.status=this.readyState=0,this.responseType=this.responseText=this.response=this.statusText="",this.onreadystatechange=null,this.A=new Headers,this.h=null,this.F="GET",this.D="",this.g=!1,this.B=this.j=this.l=null,this.v=new AbortController}m(es,Ge),n=es.prototype,n.open=function(a,d){if(this.readyState!=0)throw this.abort(),Error("Error reopening a connection");this.F=a,this.D=d,this.readyState=1,Bi(this)},n.send=function(a){if(this.readyState!=1)throw this.abort(),Error("need to call open() first. ");if(this.v.signal.aborted)throw this.abort(),Error("Request was aborted.");this.g=!0;const d={headers:this.A,method:this.F,credentials:this.m,cache:void 0,signal:this.v.signal};a&&(d.body=a),(this.H||s).fetch(new Request(this.D,d)).then(this.Pa.bind(this),this.ga.bind(this))},n.abort=function(){this.response=this.responseText="",this.A=new Headers,this.status=0,this.v.abort(),this.j&&this.j.cancel("Request was aborted.").catch(()=>{}),this.readyState>=1&&this.g&&this.readyState!=4&&(this.g=!1,qi(this)),this.readyState=0},n.Pa=function(a){if(this.g&&(this.l=a,this.h||(this.status=this.l.status,this.statusText=this.l.statusText,this.h=a.headers,this.readyState=2,Bi(this)),this.g&&(this.readyState=3,Bi(this),this.g)))if(this.responseType==="arraybuffer")a.arrayBuffer().then(this.Na.bind(this),this.ga.bind(this));else if(typeof s.ReadableStream<"u"&&"body"in a){if(this.j=a.body.getReader(),this.o){if(this.responseType)throw Error('responseType must be empty for "streamBinaryChunks" mode responses.');this.response=[]}else this.response=this.responseText="",this.B=new TextDecoder;ju(this)}else a.text().then(this.Oa.bind(this),this.ga.bind(this))};function ju(a){a.j.read().then(a.Ma.bind(a)).catch(a.ga.bind(a))}n.Ma=function(a){if(this.g){if(this.o&&a.value)this.response.push(a.value);else if(!this.o){var d=a.value?a.value:new Uint8Array(0);(d=this.B.decode(d,{stream:!a.done}))&&(this.response=this.responseText+=d)}a.done?qi(this):Bi(this),this.readyState==3&&ju(this)}},n.Oa=function(a){this.g&&(this.response=this.responseText=a,qi(this))},n.Na=function(a){this.g&&(this.response=a,qi(this))},n.ga=function(){this.g&&qi(this)};function qi(a){a.readyState=4,a.l=null,a.j=null,a.B=null,Bi(a)}n.setRequestHeader=function(a,d){this.A.append(a,d)},n.getResponseHeader=function(a){return this.h&&this.h.get(a.toLowerCase())||""},n.getAllResponseHeaders=function(){if(!this.h)return"";const a=[],d=this.h.entries();for(var f=d.next();!f.done;)f=f.value,a.push(f[0]+": "+f[1]),f=d.next();return a.join(`\r
`)};function Bi(a){a.onreadystatechange&&a.onreadystatechange.call(a)}Object.defineProperty(es.prototype,"withCredentials",{get:function(){return this.m==="include"},set:function(a){this.m=a?"include":"same-origin"}});function zu(a){let d="";return bt(a,function(f,y){d+=y,d+=":",d+=f,d+=`\r
`}),d}function ja(a,d,f){e:{for(y in f){var y=!1;break e}y=!0}y||(f=zu(f),typeof a=="string"?f!=null&&Ni(f):ge(a,d,f))}function Te(a){Ge.call(this),this.headers=new Map,this.L=a||null,this.h=!1,this.g=null,this.D="",this.o=0,this.l="",this.j=this.B=this.v=this.A=!1,this.m=null,this.F="",this.H=!1}m(Te,Ge);var Wm=/^https?$/i,Hm=["POST","PUT"];n=Te.prototype,n.Fa=function(a){this.H=a},n.ea=function(a,d,f,y){if(this.g)throw Error("[goog.net.XhrIo] Object is active with another request="+this.D+"; newUri="+a);d=d?d.toUpperCase():"GET",this.D=a,this.l="",this.o=0,this.A=!1,this.h=!0,this.g=this.L?this.L.g():Au.g(),this.g.onreadystatechange=g(h(this.Ca,this));try{this.B=!0,this.g.open(d,String(a),!0),this.B=!1}catch(R){Wu(this,R);return}if(a=f||"",f=new Map(this.headers),y)if(Object.getPrototypeOf(y)===Object.prototype)for(var k in y)f.set(k,y[k]);else if(typeof y.keys=="function"&&typeof y.get=="function")for(const R of y.keys())f.set(R,y.get(R));else throw Error("Unknown input type for opt_headers: "+String(y));y=Array.from(f.keys()).find(R=>R.toLowerCase()=="content-type"),k=s.FormData&&a instanceof s.FormData,!(Array.prototype.indexOf.call(Hm,d,void 0)>=0)||y||k||f.set("Content-Type","application/x-www-form-urlencoded;charset=utf-8");for(const[R,q]of f)this.g.setRequestHeader(R,q);this.F&&(this.g.responseType=this.F),"withCredentials"in this.g&&this.g.withCredentials!==this.H&&(this.g.withCredentials=this.H);try{this.m&&(clearTimeout(this.m),this.m=null),this.v=!0,this.g.send(a),this.v=!1}catch(R){Wu(this,R)}};function Wu(a,d){a.h=!1,a.g&&(a.j=!0,a.g.abort(),a.j=!1),a.l=d,a.o=5,Hu(a),ts(a)}function Hu(a){a.A||(a.A=!0,Ze(a,"complete"),Ze(a,"error"))}n.abort=function(a){this.g&&this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1,this.o=a||7,Ze(this,"complete"),Ze(this,"abort"),ts(this))},n.N=function(){this.g&&(this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1),ts(this,!0)),Te.Z.N.call(this)},n.Ca=function(){this.u||(this.B||this.v||this.j?Gu(this):this.Xa())},n.Xa=function(){Gu(this)};function Gu(a){if(a.h&&typeof o<"u"){if(a.v&&En(a)==4)setTimeout(a.Ca.bind(a),0);else if(Ze(a,"readystatechange"),En(a)==4){a.h=!1;try{const R=a.ca();e:switch(R){case 200:case 201:case 202:case 204:case 206:case 304:case 1223:var d=!0;break e;default:d=!1}var f;if(!(f=d)){var y;if(y=R===0){let q=String(a.D).match(Lu)[1]||null;!q&&s.self&&s.self.location&&(q=s.self.location.protocol.slice(0,-1)),y=!Wm.test(q?q.toLowerCase():"")}f=y}if(f)Ze(a,"complete"),Ze(a,"success");else{a.o=6;try{var k=En(a)>2?a.g.statusText:""}catch{k=""}a.l=k+" ["+a.ca()+"]",Hu(a)}}finally{ts(a)}}}}function ts(a,d){if(a.g){a.m&&(clearTimeout(a.m),a.m=null);const f=a.g;a.g=null,d||Ze(a,"ready");try{f.onreadystatechange=null}catch{}}}n.isActive=function(){return!!this.g};function En(a){return a.g?a.g.readyState:0}n.ca=function(){try{return En(this)>2?this.g.status:-1}catch{return-1}},n.la=function(){try{return this.g?this.g.responseText:""}catch{return""}},n.La=function(a){if(this.g){var d=this.g.responseText;return a&&d.indexOf(a)==0&&(d=d.substring(a.length)),Am(d)}};function Ku(a){try{if(!a.g)return null;if("response"in a.g)return a.g.response;switch(a.F){case"":case"text":return a.g.responseText;case"arraybuffer":if("mozResponseArrayBuffer"in a.g)return a.g.mozResponseArrayBuffer}return null}catch{return null}}function Gm(a){const d={};a=(a.g&&En(a)>=2&&a.g.getAllResponseHeaders()||"").split(`\r
`);for(let y=0;y<a.length;y++){if(_(a[y]))continue;var f=Rm(a[y]);const k=f[0];if(f=f[1],typeof f!="string")continue;f=f.trim();const R=d[k]||[];d[k]=R,R.push(f)}it(d,function(y){return y.join(", ")})}n.ya=function(){return this.o},n.Ha=function(){return typeof this.l=="string"?this.l:String(this.l)};function $i(a,d,f){return f&&f.internalChannelParams&&f.internalChannelParams[a]||d}function Yu(a){this.za=0,this.i=[],this.j=new Oi,this.ba=this.na=this.J=this.W=this.g=this.wa=this.G=this.H=this.u=this.U=this.o=null,this.Ya=this.V=0,this.Sa=$i("failFast",!1,a),this.F=this.C=this.v=this.m=this.l=null,this.X=!0,this.xa=this.K=-1,this.Y=this.A=this.D=0,this.Qa=$i("baseRetryDelayMs",5e3,a),this.Za=$i("retryDelaySeedMs",1e4,a),this.Ta=$i("forwardChannelMaxRetries",2,a),this.va=$i("forwardChannelRequestTimeoutMs",2e4,a),this.ma=a&&a.xmlHttpFactory||void 0,this.Ua=a&&a.Rb||void 0,this.Aa=a&&a.useFetchStreams||!1,this.O=void 0,this.L=a&&a.supportsCrossDomainXhr||!1,this.M="",this.h=new Ru(a&&a.concurrentRequestLimit),this.Ba=new zm,this.S=a&&a.fastHandshake||!1,this.R=a&&a.encodeInitMessageHeaders||!1,this.S&&this.R&&(this.R=!1),this.Ra=a&&a.Pb||!1,a&&a.ua&&this.j.ua(),a&&a.forceLongPolling&&(this.X=!1),this.aa=!this.S&&this.X&&a&&a.detectBufferingProxy||!1,this.ia=void 0,a&&a.longPollingTimeout&&a.longPollingTimeout>0&&(this.ia=a.longPollingTimeout),this.ta=void 0,this.T=0,this.P=!1,this.ja=this.B=null}n=Yu.prototype,n.ka=8,n.I=1,n.connect=function(a,d,f,y){et(0),this.W=a,this.H=d||{},f&&y!==void 0&&(this.H.OSID=f,this.H.OAID=y),this.F=this.X,this.J=ih(this,null,this.W),rs(this)};function za(a){if(Qu(a),a.I==3){var d=a.V++,f=Rt(a.J);if(ge(f,"SID",a.M),ge(f,"RID",d),ge(f,"TYPE","terminate"),ji(a,f),d=new wn(a,a.j,d),d.M=2,d.A=Zo(Rt(f)),f=!1,s.navigator&&s.navigator.sendBeacon)try{f=s.navigator.sendBeacon(d.A.toString(),"")}catch{}!f&&s.Image&&(new Image().src=d.A,f=!0),f||(d.g=oh(d.j,null),d.g.ea(d.A)),d.F=Date.now(),Jo(d)}rh(a)}function ns(a){a.g&&(Ha(a),a.g.cancel(),a.g=null)}function Qu(a){ns(a),a.v&&(s.clearTimeout(a.v),a.v=null),is(a),a.h.cancel(),a.m&&(typeof a.m=="number"&&s.clearTimeout(a.m),a.m=null)}function rs(a){if(!Ou(a.h)&&!a.m){a.m=!0;var d=a.Ea;z||v(),K||(z(),K=!0),T.add(d,a),a.D=0}}function Km(a,d){return Nu(a.h)>=a.h.j-(a.m?1:0)?!1:a.m?(a.i=d.G.concat(a.i),!0):a.I==1||a.I==2||a.D>=(a.Sa?0:a.Ta)?!1:(a.m=Ri(h(a.Ea,a,d),nh(a,a.D)),a.D++,!0)}n.Ea=function(a){if(this.m)if(this.m=null,this.I==1){if(!a){this.V=Math.floor(Math.random()*1e5),a=this.V++;const k=new wn(this,this.j,a);let R=this.o;if(this.U&&(R?(R=ue(R),ye(R,this.U)):R=this.U),this.u!==null||this.R||(k.J=R,R=null),this.S)e:{for(var d=0,f=0;f<this.i.length;f++){t:{var y=this.i[f];if("__data__"in y.map&&(y=y.map.__data__,typeof y=="string")){y=y.length;break t}y=void 0}if(y===void 0)break;if(d+=y,d>4096){d=f;break e}if(d===4096||f===this.i.length-1){d=f+1;break e}}d=1e3}else d=1e3;d=Ju(this,k,d),f=Rt(this.J),ge(f,"RID",a),ge(f,"CVER",22),this.G&&ge(f,"X-HTTP-Session-Id",this.G),ji(this,f),R&&(this.R?d="headers="+Ni(zu(R))+"&"+d:this.u&&ja(f,this.u,R)),qa(this.h,k),this.Ra&&ge(f,"TYPE","init"),this.S?(ge(f,"$req",d),ge(f,"SID","null"),k.U=!0,La(k,f,null)):La(k,f,d),this.I=2}}else this.I==3&&(a?Xu(this,a):this.i.length==0||Ou(this.h)||Xu(this))};function Xu(a,d){var f;d?f=d.l:f=a.V++;const y=Rt(a.J);ge(y,"SID",a.M),ge(y,"RID",f),ge(y,"AID",a.K),ji(a,y),a.u&&a.o&&ja(y,a.u,a.o),f=new wn(a,a.j,f,a.D+1),a.u===null&&(f.J=a.o),d&&(a.i=d.G.concat(a.i)),d=Ju(a,f,1e3),f.H=Math.round(a.va*.5)+Math.round(a.va*.5*Math.random()),qa(a.h,f),La(f,y,d)}function ji(a,d){a.H&&bt(a.H,function(f,y){ge(d,y,f)}),a.l&&bt({},function(f,y){ge(d,y,f)})}function Ju(a,d,f){f=Math.min(a.i.length,f);const y=a.l?h(a.l.Ka,a.l,a):null;e:{var k=a.i;let ee=-1;for(;;){const Ne=["count="+f];ee==-1?f>0?(ee=k[0].g,Ne.push("ofs="+ee)):ee=0:Ne.push("ofs="+ee);let fe=!0;for(let qe=0;qe<f;qe++){var R=k[qe].g;const Ot=k[qe].map;if(R-=ee,R<0)ee=Math.max(0,k[qe].g-100),fe=!1;else try{R="req"+R+"_"||"";try{var q=Ot instanceof Map?Ot:Object.entries(Ot);for(const[rr,In]of q){let An=In;l(In)&&(An=Ra(In)),Ne.push(R+rr+"="+encodeURIComponent(An))}}catch(rr){throw Ne.push(R+"type="+encodeURIComponent("_badmap")),rr}}catch{y&&y(Ot)}}if(fe){q=Ne.join("&");break e}}q=void 0}return a=a.i.splice(0,f),d.G=a,q}function Zu(a){if(!a.g&&!a.v){a.Y=1;var d=a.Da;z||v(),K||(z(),K=!0),T.add(d,a),a.A=0}}function Wa(a){return a.g||a.v||a.A>=3?!1:(a.Y++,a.v=Ri(h(a.Da,a),nh(a,a.A)),a.A++,!0)}n.Da=function(){if(this.v=null,eh(this),this.aa&&!(this.P||this.g==null||this.T<=0)){var a=4*this.T;this.j.info("BP detection timer enabled: "+a),this.B=Ri(h(this.Wa,this),a)}},n.Wa=function(){this.B&&(this.B=null,this.j.info("BP detection timeout reached."),this.j.info("Buffering proxy detected and switch to long-polling!"),this.F=!1,this.P=!0,et(10),ns(this),eh(this))};function Ha(a){a.B!=null&&(s.clearTimeout(a.B),a.B=null)}function eh(a){a.g=new wn(a,a.j,"rpc",a.Y),a.u===null&&(a.g.J=a.o),a.g.P=0;var d=Rt(a.na);ge(d,"RID","rpc"),ge(d,"SID",a.M),ge(d,"AID",a.K),ge(d,"CI",a.F?"0":"1"),!a.F&&a.ia&&ge(d,"TO",a.ia),ge(d,"TYPE","xmlhttp"),ji(a,d),a.u&&a.o&&ja(d,a.u,a.o),a.O&&(a.g.H=a.O);var f=a.g;a=a.ba,f.M=1,f.A=Zo(Rt(d)),f.u=null,f.R=!0,ku(f,a)}n.Va=function(){this.C!=null&&(this.C=null,ns(this),Wa(this),et(19))};function is(a){a.C!=null&&(s.clearTimeout(a.C),a.C=null)}function th(a,d){var f=null;if(a.g==d){is(a),Ha(a),a.g=null;var y=2}else if(Ua(a.h,d))f=d.G,Du(a.h,d),y=1;else return;if(a.I!=0){if(d.o)if(y==1){f=d.u?d.u.length:0,d=Date.now()-d.F;var k=a.D;y=Qo(),Ze(y,new Eu(y,f)),rs(a)}else Zu(a);else if(k=d.m,k==3||k==0&&d.X>0||!(y==1&&Km(a,d)||y==2&&Wa(a)))switch(f&&f.length>0&&(d=a.h,d.i=d.i.concat(f)),k){case 1:nr(a,5);break;case 4:nr(a,10);break;case 3:nr(a,6);break;default:nr(a,2)}}}function nh(a,d){let f=a.Qa+Math.floor(Math.random()*a.Za);return a.isActive()||(f*=2),f*d}function nr(a,d){if(a.j.info("Error code "+d),d==2){var f=h(a.bb,a),y=a.Ua;const k=!y;y=new bn(y||"//www.google.com/images/cleardot.gif"),s.location&&s.location.protocol=="http"||Mi(y,"https"),Zo(y),k?$m(y.toString(),f):jm(y.toString(),f)}else et(2);a.I=0,a.l&&a.l.pa(d),rh(a),Qu(a)}n.bb=function(a){a?(this.j.info("Successfully pinged google.com"),et(2)):(this.j.info("Failed to ping google.com"),et(1))};function rh(a){if(a.I=0,a.ja=[],a.l){const d=Mu(a.h);(d.length!=0||a.i.length!=0)&&(P(a.ja,d),P(a.ja,a.i),a.h.i.length=0,b(a.i),a.i.length=0),a.l.oa()}}function ih(a,d,f){var y=f instanceof bn?Rt(f):new bn(f);if(y.g!="")d&&(y.g=d+"."+y.g),Li(y,y.u);else{var k=s.location;y=k.protocol,d=d?d+"."+k.hostname:k.hostname,k=+k.port;const R=new bn(null);y&&Mi(R,y),d&&(R.g=d),k&&Li(R,k),f&&(R.h=f),y=R}return f=a.G,d=a.wa,f&&d&&ge(y,f,d),ge(y,"VER",a.ka),ji(a,y),y}function oh(a,d,f){if(d&&!a.L)throw Error("Can't create secondary domain capable XhrIo object.");return d=a.Aa&&!a.ma?new Te(new $a({ab:f})):new Te(a.ma),d.Fa(a.L),d}n.isActive=function(){return!!this.l&&this.l.isActive(this)};function sh(){}n=sh.prototype,n.ra=function(){},n.qa=function(){},n.pa=function(){},n.oa=function(){},n.isActive=function(){return!0},n.Ka=function(){};function os(){}os.prototype.g=function(a,d){return new ft(a,d)};function ft(a,d){Ge.call(this),this.g=new Yu(d),this.l=a,this.h=d&&d.messageUrlParams||null,a=d&&d.messageHeaders||null,d&&d.clientProtocolHeaderRequired&&(a?a["X-Client-Protocol"]="webchannel":a={"X-Client-Protocol":"webchannel"}),this.g.o=a,a=d&&d.initMessageHeaders||null,d&&d.messageContentType&&(a?a["X-WebChannel-Content-Type"]=d.messageContentType:a={"X-WebChannel-Content-Type":d.messageContentType}),d&&d.sa&&(a?a["X-WebChannel-Client-Profile"]=d.sa:a={"X-WebChannel-Client-Profile":d.sa}),this.g.U=a,(a=d&&d.Qb)&&!_(a)&&(this.g.u=a),this.A=d&&d.supportsCrossDomainXhr||!1,this.v=d&&d.sendRawJson||!1,(d=d&&d.httpSessionIdParam)&&!_(d)&&(this.g.G=d,a=this.h,a!==null&&d in a&&(a=this.h,d in a&&delete a[d])),this.j=new qr(this)}m(ft,Ge),ft.prototype.m=function(){this.g.l=this.j,this.A&&(this.g.L=!0),this.g.connect(this.l,this.h||void 0)},ft.prototype.close=function(){za(this.g)},ft.prototype.o=function(a){var d=this.g;if(typeof a=="string"){var f={};f.__data__=a,a=f}else this.v&&(f={},f.__data__=Ra(a),a=f);d.i.push(new Dm(d.Ya++,a)),d.I==3&&rs(d)},ft.prototype.N=function(){this.g.l=null,delete this.j,za(this.g),delete this.g,ft.Z.N.call(this)};function ah(a){Oa.call(this),a.__headers__&&(this.headers=a.__headers__,this.statusCode=a.__status__,delete a.__headers__,delete a.__status__);var d=a.__sm__;if(d){e:{for(const f in d){a=f;break e}a=void 0}(this.i=a)&&(a=this.i,d=d!==null&&a in d?d[a]:void 0),this.data=d}else this.data=a}m(ah,Oa);function lh(){Na.call(this),this.status=1}m(lh,Na);function qr(a){this.g=a}m(qr,sh),qr.prototype.ra=function(){Ze(this.g,"a")},qr.prototype.qa=function(a){Ze(this.g,new ah(a))},qr.prototype.pa=function(a){Ze(this.g,new lh)},qr.prototype.oa=function(){Ze(this.g,"b")},os.prototype.createWebChannel=os.prototype.g,ft.prototype.send=ft.prototype.o,ft.prototype.open=ft.prototype.m,ft.prototype.close=ft.prototype.close,ip=function(){return new os},rp=function(){return Qo()},np=Zn,El={jb:0,mb:1,nb:2,Hb:3,Mb:4,Jb:5,Kb:6,Ib:7,Gb:8,Lb:9,PROXY:10,NOPROXY:11,Eb:12,Ab:13,Bb:14,zb:15,Cb:16,Db:17,fb:18,eb:19,gb:20},Xo.NO_ERROR=0,Xo.TIMEOUT=8,Xo.HTTP_ERROR=6,As=Xo,Iu.COMPLETE="complete",tp=Iu,_u.EventType=Pi,Pi.OPEN="a",Pi.CLOSE="b",Pi.ERROR="c",Pi.MESSAGE="d",Ge.prototype.listen=Ge.prototype.J,Ji=_u,Te.prototype.listenOnce=Te.prototype.K,Te.prototype.getLastError=Te.prototype.Ha,Te.prototype.getLastErrorCode=Te.prototype.ya,Te.prototype.getStatus=Te.prototype.ca,Te.prototype.getResponseJson=Te.prototype.La,Te.prototype.getResponseText=Te.prototype.la,Te.prototype.send=Te.prototype.ea,Te.prototype.setWithCredentials=Te.prototype.Fa,ep=Te}).apply(typeof ls<"u"?ls:typeof self<"u"?self:typeof window<"u"?window:{});/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ye{constructor(e){this.uid=e}isAuthenticated(){return this.uid!=null}toKey(){return this.isAuthenticated()?"uid:"+this.uid:"anonymous-user"}isEqual(e){return e.uid===this.uid}}Ye.UNAUTHENTICATED=new Ye(null),Ye.GOOGLE_CREDENTIALS=new Ye("google-credentials-uid"),Ye.FIRST_PARTY=new Ye("first-party-uid"),Ye.MOCK_USER=new Ye("mock-user");/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Ti="12.12.0";function Ow(n){Ti=n}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const _r=new Ql("@firebase/firestore");function Br(){return _r.logLevel}function j(n,...e){if(_r.logLevel<=re.DEBUG){const t=e.map(lc);_r.debug(`Firestore (${Ti}): ${n}`,...t)}}function pn(n,...e){if(_r.logLevel<=re.ERROR){const t=e.map(lc);_r.error(`Firestore (${Ti}): ${n}`,...t)}}function wr(n,...e){if(_r.logLevel<=re.WARN){const t=e.map(lc);_r.warn(`Firestore (${Ti}): ${n}`,...t)}}function lc(n){if(typeof n=="string")return n;try{return function(t){return JSON.stringify(t)}(n)}catch{return n}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Y(n,e,t){let r="Unexpected state";typeof e=="string"?r=e:t=e,op(n,r,t)}function op(n,e,t){let r=`FIRESTORE (${Ti}) INTERNAL ASSERTION FAILED: ${e} (ID: ${n.toString(16)})`;if(t!==void 0)try{r+=" CONTEXT: "+JSON.stringify(t)}catch{r+=" CONTEXT: "+t}throw pn(r),new Error(r)}function he(n,e,t,r){let i="Unexpected state";typeof t=="string"?i=t:r=t,n||op(e,i,r)}function J(n,e){return n}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const D={OK:"ok",CANCELLED:"cancelled",UNKNOWN:"unknown",INVALID_ARGUMENT:"invalid-argument",DEADLINE_EXCEEDED:"deadline-exceeded",NOT_FOUND:"not-found",ALREADY_EXISTS:"already-exists",PERMISSION_DENIED:"permission-denied",UNAUTHENTICATED:"unauthenticated",RESOURCE_EXHAUSTED:"resource-exhausted",FAILED_PRECONDITION:"failed-precondition",ABORTED:"aborted",OUT_OF_RANGE:"out-of-range",UNIMPLEMENTED:"unimplemented",INTERNAL:"internal",UNAVAILABLE:"unavailable",DATA_LOSS:"data-loss"};class B extends yn{constructor(e,t){super(e,t),this.code=e,this.message=t,this.toString=()=>`${this.name}: [code=${this.code}]: ${this.message}`}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class an{constructor(){this.promise=new Promise((e,t)=>{this.resolve=e,this.reject=t})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class sp{constructor(e,t){this.user=t,this.type="OAuth",this.headers=new Map,this.headers.set("Authorization",`Bearer ${e}`)}}class Nw{getToken(){return Promise.resolve(null)}invalidateToken(){}start(e,t){e.enqueueRetryable(()=>t(Ye.UNAUTHENTICATED))}shutdown(){}}class Dw{constructor(e){this.token=e,this.changeListener=null}getToken(){return Promise.resolve(this.token)}invalidateToken(){}start(e,t){this.changeListener=t,e.enqueueRetryable(()=>t(this.token.user))}shutdown(){this.changeListener=null}}class Mw{constructor(e){this.t=e,this.currentUser=Ye.UNAUTHENTICATED,this.i=0,this.forceRefresh=!1,this.auth=null}start(e,t){he(this.o===void 0,42304);let r=this.i;const i=u=>this.i!==r?(r=this.i,t(u)):Promise.resolve();let o=new an;this.o=()=>{this.i++,this.currentUser=this.u(),o.resolve(),o=new an,e.enqueueRetryable(()=>i(this.currentUser))};const s=()=>{const u=o;e.enqueueRetryable(async()=>{await u.promise,await i(this.currentUser)})},l=u=>{j("FirebaseAuthCredentialsProvider","Auth detected"),this.auth=u,this.o&&(this.auth.addAuthTokenListener(this.o),s())};this.t.onInit(u=>l(u)),setTimeout(()=>{if(!this.auth){const u=this.t.getImmediate({optional:!0});u?l(u):(j("FirebaseAuthCredentialsProvider","Auth not yet detected"),o.resolve(),o=new an)}},0),s()}getToken(){const e=this.i,t=this.forceRefresh;return this.forceRefresh=!1,this.auth?this.auth.getToken(t).then(r=>this.i!==e?(j("FirebaseAuthCredentialsProvider","getToken aborted due to token change."),this.getToken()):r?(he(typeof r.accessToken=="string",31837,{l:r}),new sp(r.accessToken,this.currentUser)):null):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.auth&&this.o&&this.auth.removeAuthTokenListener(this.o),this.o=void 0}u(){const e=this.auth&&this.auth.getUid();return he(e===null||typeof e=="string",2055,{h:e}),new Ye(e)}}class Lw{constructor(e,t,r){this.P=e,this.T=t,this.I=r,this.type="FirstParty",this.user=Ye.FIRST_PARTY,this.R=new Map}A(){return this.I?this.I():null}get headers(){this.R.set("X-Goog-AuthUser",this.P);const e=this.A();return e&&this.R.set("Authorization",e),this.T&&this.R.set("X-Goog-Iam-Authorization-Token",this.T),this.R}}class Vw{constructor(e,t,r){this.P=e,this.T=t,this.I=r}getToken(){return Promise.resolve(new Lw(this.P,this.T,this.I))}start(e,t){e.enqueueRetryable(()=>t(Ye.FIRST_PARTY))}shutdown(){}invalidateToken(){}}class Vh{constructor(e){this.value=e,this.type="AppCheck",this.headers=new Map,e&&e.length>0&&this.headers.set("x-firebase-appcheck",this.value)}}class Fw{constructor(e,t){this.V=t,this.forceRefresh=!1,this.appCheck=null,this.m=null,this.p=null,Mt(e)&&e.settings.appCheckToken&&(this.p=e.settings.appCheckToken)}start(e,t){he(this.o===void 0,3512);const r=o=>{o.error!=null&&j("FirebaseAppCheckTokenProvider",`Error getting App Check token; using placeholder token instead. Error: ${o.error.message}`);const s=o.token!==this.m;return this.m=o.token,j("FirebaseAppCheckTokenProvider",`Received ${s?"new":"existing"} token.`),s?t(o.token):Promise.resolve()};this.o=o=>{e.enqueueRetryable(()=>r(o))};const i=o=>{j("FirebaseAppCheckTokenProvider","AppCheck detected"),this.appCheck=o,this.o&&this.appCheck.addTokenListener(this.o)};this.V.onInit(o=>i(o)),setTimeout(()=>{if(!this.appCheck){const o=this.V.getImmediate({optional:!0});o?i(o):j("FirebaseAppCheckTokenProvider","AppCheck not yet detected")}},0)}getToken(){if(this.p)return Promise.resolve(new Vh(this.p));const e=this.forceRefresh;return this.forceRefresh=!1,this.appCheck?this.appCheck.getToken(e).then(t=>t?(he(typeof t.token=="string",44558,{tokenResult:t}),this.m=t.token,new Vh(t.token)):null):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.appCheck&&this.o&&this.appCheck.removeTokenListener(this.o),this.o=void 0}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Uw(n){const e=typeof self<"u"&&(self.crypto||self.msCrypto),t=new Uint8Array(n);if(e&&typeof e.getRandomValues=="function")e.getRandomValues(t);else for(let r=0;r<n;r++)t[r]=Math.floor(256*Math.random());return t}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class cc{static newId(){const e="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",t=62*Math.floor(4.129032258064516);let r="";for(;r.length<20;){const i=Uw(40);for(let o=0;o<i.length;++o)r.length<20&&i[o]<t&&(r+=e.charAt(i[o]%62))}return r}}function ie(n,e){return n<e?-1:n>e?1:0}function Il(n,e){const t=Math.min(n.length,e.length);for(let r=0;r<t;r++){const i=n.charAt(r),o=e.charAt(r);if(i!==o)return tl(i)===tl(o)?ie(i,o):tl(i)?1:-1}return ie(n.length,e.length)}const qw=55296,Bw=57343;function tl(n){const e=n.charCodeAt(0);return e>=qw&&e<=Bw}function hi(n,e,t){return n.length===e.length&&n.every((r,i)=>t(r,e[i]))}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Fh="__name__";class Nt{constructor(e,t,r){t===void 0?t=0:t>e.length&&Y(637,{offset:t,range:e.length}),r===void 0?r=e.length-t:r>e.length-t&&Y(1746,{length:r,range:e.length-t}),this.segments=e,this.offset=t,this.len=r}get length(){return this.len}isEqual(e){return Nt.comparator(this,e)===0}child(e){const t=this.segments.slice(this.offset,this.limit());return e instanceof Nt?e.forEach(r=>{t.push(r)}):t.push(e),this.construct(t)}limit(){return this.offset+this.length}popFirst(e){return e=e===void 0?1:e,this.construct(this.segments,this.offset+e,this.length-e)}popLast(){return this.construct(this.segments,this.offset,this.length-1)}firstSegment(){return this.segments[this.offset]}lastSegment(){return this.get(this.length-1)}get(e){return this.segments[this.offset+e]}isEmpty(){return this.length===0}isPrefixOf(e){if(e.length<this.length)return!1;for(let t=0;t<this.length;t++)if(this.get(t)!==e.get(t))return!1;return!0}isImmediateParentOf(e){if(this.length+1!==e.length)return!1;for(let t=0;t<this.length;t++)if(this.get(t)!==e.get(t))return!1;return!0}forEach(e){for(let t=this.offset,r=this.limit();t<r;t++)e(this.segments[t])}toArray(){return this.segments.slice(this.offset,this.limit())}static comparator(e,t){const r=Math.min(e.length,t.length);for(let i=0;i<r;i++){const o=Nt.compareSegments(e.get(i),t.get(i));if(o!==0)return o}return ie(e.length,t.length)}static compareSegments(e,t){const r=Nt.isNumericId(e),i=Nt.isNumericId(t);return r&&!i?-1:!r&&i?1:r&&i?Nt.extractNumericId(e).compare(Nt.extractNumericId(t)):Il(e,t)}static isNumericId(e){return e.startsWith("__id")&&e.endsWith("__")}static extractNumericId(e){return Fn.fromString(e.substring(4,e.length-2))}}class pe extends Nt{construct(e,t,r){return new pe(e,t,r)}canonicalString(){return this.toArray().join("/")}toString(){return this.canonicalString()}toUriEncodedString(){return this.toArray().map(encodeURIComponent).join("/")}static fromString(...e){const t=[];for(const r of e){if(r.indexOf("//")>=0)throw new B(D.INVALID_ARGUMENT,`Invalid segment (${r}). Paths must not contain // in them.`);t.push(...r.split("/").filter(i=>i.length>0))}return new pe(t)}static emptyPath(){return new pe([])}}const $w=/^[_a-zA-Z][_a-zA-Z0-9]*$/;class ze extends Nt{construct(e,t,r){return new ze(e,t,r)}static isValidIdentifier(e){return $w.test(e)}canonicalString(){return this.toArray().map(e=>(e=e.replace(/\\/g,"\\\\").replace(/`/g,"\\`"),ze.isValidIdentifier(e)||(e="`"+e+"`"),e)).join(".")}toString(){return this.canonicalString()}isKeyField(){return this.length===1&&this.get(0)===Fh}static keyField(){return new ze([Fh])}static fromServerFormat(e){const t=[];let r="",i=0;const o=()=>{if(r.length===0)throw new B(D.INVALID_ARGUMENT,`Invalid field path (${e}). Paths must not be empty, begin with '.', end with '.', or contain '..'`);t.push(r),r=""};let s=!1;for(;i<e.length;){const l=e[i];if(l==="\\"){if(i+1===e.length)throw new B(D.INVALID_ARGUMENT,"Path has trailing escape character: "+e);const u=e[i+1];if(u!=="\\"&&u!=="."&&u!=="`")throw new B(D.INVALID_ARGUMENT,"Path has invalid escape sequence: "+e);r+=u,i+=2}else l==="`"?(s=!s,i++):l!=="."||s?(r+=l,i++):(o(),i++)}if(o(),s)throw new B(D.INVALID_ARGUMENT,"Unterminated ` in path: "+e);return new ze(t)}static emptyPath(){return new ze([])}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class G{constructor(e){this.path=e}static fromPath(e){return new G(pe.fromString(e))}static fromName(e){return new G(pe.fromString(e).popFirst(5))}static empty(){return new G(pe.emptyPath())}get collectionGroup(){return this.path.popLast().lastSegment()}hasCollectionId(e){return this.path.length>=2&&this.path.get(this.path.length-2)===e}getCollectionGroup(){return this.path.get(this.path.length-2)}getCollectionPath(){return this.path.popLast()}isEqual(e){return e!==null&&pe.comparator(this.path,e.path)===0}toString(){return this.path.toString()}static comparator(e,t){return pe.comparator(e.path,t.path)}static isDocumentKey(e){return e.length%2==0}static fromSegments(e){return new G(new pe(e.slice()))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ap(n,e,t){if(!t)throw new B(D.INVALID_ARGUMENT,`Function ${n}() cannot be called with an empty ${e}.`)}function jw(n,e,t,r){if(e===!0&&r===!0)throw new B(D.INVALID_ARGUMENT,`${n} and ${t} cannot be used together.`)}function Uh(n){if(!G.isDocumentKey(n))throw new B(D.INVALID_ARGUMENT,`Invalid document reference. Document references must have an even number of segments, but ${n} has ${n.length}.`)}function qh(n){if(G.isDocumentKey(n))throw new B(D.INVALID_ARGUMENT,`Invalid collection reference. Collection references must have an odd number of segments, but ${n} has ${n.length}.`)}function lp(n){return typeof n=="object"&&n!==null&&(Object.getPrototypeOf(n)===Object.prototype||Object.getPrototypeOf(n)===null)}function da(n){if(n===void 0)return"undefined";if(n===null)return"null";if(typeof n=="string")return n.length>20&&(n=`${n.substring(0,20)}...`),JSON.stringify(n);if(typeof n=="number"||typeof n=="boolean")return""+n;if(typeof n=="object"){if(n instanceof Array)return"an array";{const e=function(r){return r.constructor?r.constructor.name:null}(n);return e?`a custom ${e} object`:"an object"}}return typeof n=="function"?"a function":Y(12329,{type:typeof n})}function yt(n,e){if("_delegate"in n&&(n=n._delegate),!(n instanceof e)){if(e.name===n.constructor.name)throw new B(D.INVALID_ARGUMENT,"Type does not match the expected instance. Did you pass a reference from a different Firestore SDK?");{const t=da(n);throw new B(D.INVALID_ARGUMENT,`Expected type '${e.name}', but it was: ${t}`)}}return n}function zw(n,e){if(e<=0)throw new B(D.INVALID_ARGUMENT,`Function ${n}() requires a positive number, but it was: ${e}.`)}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Re(n,e){const t={typeString:n};return e&&(t.value=e),t}function Bo(n,e){if(!lp(n))throw new B(D.INVALID_ARGUMENT,"JSON must be an object");let t;for(const r in e)if(e[r]){const i=e[r].typeString,o="value"in e[r]?{value:e[r].value}:void 0;if(!(r in n)){t=`JSON missing required field: '${r}'`;break}const s=n[r];if(i&&typeof s!==i){t=`JSON field '${r}' must be a ${i}.`;break}if(o!==void 0&&s!==o.value){t=`Expected '${r}' field to equal '${o.value}'`;break}}if(t)throw new B(D.INVALID_ARGUMENT,t);return!0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Bh=-62135596800,$h=1e6;class me{static now(){return me.fromMillis(Date.now())}static fromDate(e){return me.fromMillis(e.getTime())}static fromMillis(e){const t=Math.floor(e/1e3),r=Math.floor((e-1e3*t)*$h);return new me(t,r)}constructor(e,t){if(this.seconds=e,this.nanoseconds=t,t<0)throw new B(D.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+t);if(t>=1e9)throw new B(D.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+t);if(e<Bh)throw new B(D.INVALID_ARGUMENT,"Timestamp seconds out of range: "+e);if(e>=253402300800)throw new B(D.INVALID_ARGUMENT,"Timestamp seconds out of range: "+e)}toDate(){return new Date(this.toMillis())}toMillis(){return 1e3*this.seconds+this.nanoseconds/$h}_compareTo(e){return this.seconds===e.seconds?ie(this.nanoseconds,e.nanoseconds):ie(this.seconds,e.seconds)}isEqual(e){return e.seconds===this.seconds&&e.nanoseconds===this.nanoseconds}toString(){return"Timestamp(seconds="+this.seconds+", nanoseconds="+this.nanoseconds+")"}toJSON(){return{type:me._jsonSchemaVersion,seconds:this.seconds,nanoseconds:this.nanoseconds}}static fromJSON(e){if(Bo(e,me._jsonSchema))return new me(e.seconds,e.nanoseconds)}valueOf(){const e=this.seconds-Bh;return String(e).padStart(12,"0")+"."+String(this.nanoseconds).padStart(9,"0")}}me._jsonSchemaVersion="firestore/timestamp/1.0",me._jsonSchema={type:Re("string",me._jsonSchemaVersion),seconds:Re("number"),nanoseconds:Re("number")};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class X{static fromTimestamp(e){return new X(e)}static min(){return new X(new me(0,0))}static max(){return new X(new me(253402300799,999999999))}constructor(e){this.timestamp=e}compareTo(e){return this.timestamp._compareTo(e.timestamp)}isEqual(e){return this.timestamp.isEqual(e.timestamp)}toMicroseconds(){return 1e6*this.timestamp.seconds+this.timestamp.nanoseconds/1e3}toString(){return"SnapshotVersion("+this.timestamp.toString()+")"}toTimestamp(){return this.timestamp}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const vo=-1;function Ww(n,e){const t=n.toTimestamp().seconds,r=n.toTimestamp().nanoseconds+1,i=X.fromTimestamp(r===1e9?new me(t+1,0):new me(t,r));return new $n(i,G.empty(),e)}function Hw(n){return new $n(n.readTime,n.key,vo)}class $n{constructor(e,t,r){this.readTime=e,this.documentKey=t,this.largestBatchId=r}static min(){return new $n(X.min(),G.empty(),vo)}static max(){return new $n(X.max(),G.empty(),vo)}}function Gw(n,e){let t=n.readTime.compareTo(e.readTime);return t!==0?t:(t=G.comparator(n.documentKey,e.documentKey),t!==0?t:ie(n.largestBatchId,e.largestBatchId))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Kw="The current tab is not in the required state to perform this operation. It might be necessary to refresh the browser tab.";class Yw{constructor(){this.onCommittedListeners=[]}addOnCommittedListener(e){this.onCommittedListeners.push(e)}raiseOnCommittedEvent(){this.onCommittedListeners.forEach(e=>e())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Ei(n){if(n.code!==D.FAILED_PRECONDITION||n.message!==Kw)throw n;j("LocalStore","Unexpectedly lost primary lease")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class M{constructor(e){this.nextCallback=null,this.catchCallback=null,this.result=void 0,this.error=void 0,this.isDone=!1,this.callbackAttached=!1,e(t=>{this.isDone=!0,this.result=t,this.nextCallback&&this.nextCallback(t)},t=>{this.isDone=!0,this.error=t,this.catchCallback&&this.catchCallback(t)})}catch(e){return this.next(void 0,e)}next(e,t){return this.callbackAttached&&Y(59440),this.callbackAttached=!0,this.isDone?this.error?this.wrapFailure(t,this.error):this.wrapSuccess(e,this.result):new M((r,i)=>{this.nextCallback=o=>{this.wrapSuccess(e,o).next(r,i)},this.catchCallback=o=>{this.wrapFailure(t,o).next(r,i)}})}toPromise(){return new Promise((e,t)=>{this.next(e,t)})}wrapUserFunction(e){try{const t=e();return t instanceof M?t:M.resolve(t)}catch(t){return M.reject(t)}}wrapSuccess(e,t){return e?this.wrapUserFunction(()=>e(t)):M.resolve(t)}wrapFailure(e,t){return e?this.wrapUserFunction(()=>e(t)):M.reject(t)}static resolve(e){return new M((t,r)=>{t(e)})}static reject(e){return new M((t,r)=>{r(e)})}static waitFor(e){return new M((t,r)=>{let i=0,o=0,s=!1;e.forEach(l=>{++i,l.next(()=>{++o,s&&o===i&&t()},u=>r(u))}),s=!0,o===i&&t()})}static or(e){let t=M.resolve(!1);for(const r of e)t=t.next(i=>i?M.resolve(i):r());return t}static forEach(e,t){const r=[];return e.forEach((i,o)=>{r.push(t.call(this,i,o))}),this.waitFor(r)}static mapArray(e,t){return new M((r,i)=>{const o=e.length,s=new Array(o);let l=0;for(let u=0;u<o;u++){const h=u;t(e[h]).next(p=>{s[h]=p,++l,l===o&&r(s)},p=>i(p))}})}static doWhile(e,t){return new M((r,i)=>{const o=()=>{e()===!0?t().next(()=>{o()},i):r()};o()})}}function Qw(n){const e=n.match(/Android ([\d.]+)/i),t=e?e[1].split(".").slice(0,2).join("."):"-1";return Number(t)}function Ii(n){return n.name==="IndexedDbTransactionError"}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fa{constructor(e,t){this.previousValue=e,t&&(t.sequenceNumberHandler=r=>this.ae(r),this.ue=r=>t.writeSequenceNumber(r))}ae(e){return this.previousValue=Math.max(e,this.previousValue),this.previousValue}next(){const e=++this.previousValue;return this.ue&&this.ue(e),e}}fa.ce=-1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const uc=-1;function pa(n){return n==null}function js(n){return n===0&&1/n==-1/0}function Xw(n){return typeof n=="number"&&Number.isInteger(n)&&!js(n)&&n<=Number.MAX_SAFE_INTEGER&&n>=Number.MIN_SAFE_INTEGER}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const cp="";function Jw(n){let e="";for(let t=0;t<n.length;t++)e.length>0&&(e=jh(e)),e=Zw(n.get(t),e);return jh(e)}function Zw(n,e){let t=e;const r=n.length;for(let i=0;i<r;i++){const o=n.charAt(i);switch(o){case"\0":t+="";break;case cp:t+="";break;default:t+=o}}return t}function jh(n){return n+cp+""}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function zh(n){let e=0;for(const t in n)Object.prototype.hasOwnProperty.call(n,t)&&e++;return e}function Yn(n,e){for(const t in n)Object.prototype.hasOwnProperty.call(n,t)&&e(t,n[t])}function up(n){for(const e in n)if(Object.prototype.hasOwnProperty.call(n,e))return!1;return!0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class be{constructor(e,t){this.comparator=e,this.root=t||je.EMPTY}insert(e,t){return new be(this.comparator,this.root.insert(e,t,this.comparator).copy(null,null,je.BLACK,null,null))}remove(e){return new be(this.comparator,this.root.remove(e,this.comparator).copy(null,null,je.BLACK,null,null))}get(e){let t=this.root;for(;!t.isEmpty();){const r=this.comparator(e,t.key);if(r===0)return t.value;r<0?t=t.left:r>0&&(t=t.right)}return null}indexOf(e){let t=0,r=this.root;for(;!r.isEmpty();){const i=this.comparator(e,r.key);if(i===0)return t+r.left.size;i<0?r=r.left:(t+=r.left.size+1,r=r.right)}return-1}isEmpty(){return this.root.isEmpty()}get size(){return this.root.size}minKey(){return this.root.minKey()}maxKey(){return this.root.maxKey()}inorderTraversal(e){return this.root.inorderTraversal(e)}forEach(e){this.inorderTraversal((t,r)=>(e(t,r),!1))}toString(){const e=[];return this.inorderTraversal((t,r)=>(e.push(`${t}:${r}`),!1)),`{${e.join(", ")}}`}reverseTraversal(e){return this.root.reverseTraversal(e)}getIterator(){return new cs(this.root,null,this.comparator,!1)}getIteratorFrom(e){return new cs(this.root,e,this.comparator,!1)}getReverseIterator(){return new cs(this.root,null,this.comparator,!0)}getReverseIteratorFrom(e){return new cs(this.root,e,this.comparator,!0)}}class cs{constructor(e,t,r,i){this.isReverse=i,this.nodeStack=[];let o=1;for(;!e.isEmpty();)if(o=t?r(e.key,t):1,t&&i&&(o*=-1),o<0)e=this.isReverse?e.left:e.right;else{if(o===0){this.nodeStack.push(e);break}this.nodeStack.push(e),e=this.isReverse?e.right:e.left}}getNext(){let e=this.nodeStack.pop();const t={key:e.key,value:e.value};if(this.isReverse)for(e=e.left;!e.isEmpty();)this.nodeStack.push(e),e=e.right;else for(e=e.right;!e.isEmpty();)this.nodeStack.push(e),e=e.left;return t}hasNext(){return this.nodeStack.length>0}peek(){if(this.nodeStack.length===0)return null;const e=this.nodeStack[this.nodeStack.length-1];return{key:e.key,value:e.value}}}class je{constructor(e,t,r,i,o){this.key=e,this.value=t,this.color=r??je.RED,this.left=i??je.EMPTY,this.right=o??je.EMPTY,this.size=this.left.size+1+this.right.size}copy(e,t,r,i,o){return new je(e??this.key,t??this.value,r??this.color,i??this.left,o??this.right)}isEmpty(){return!1}inorderTraversal(e){return this.left.inorderTraversal(e)||e(this.key,this.value)||this.right.inorderTraversal(e)}reverseTraversal(e){return this.right.reverseTraversal(e)||e(this.key,this.value)||this.left.reverseTraversal(e)}min(){return this.left.isEmpty()?this:this.left.min()}minKey(){return this.min().key}maxKey(){return this.right.isEmpty()?this.key:this.right.maxKey()}insert(e,t,r){let i=this;const o=r(e,i.key);return i=o<0?i.copy(null,null,null,i.left.insert(e,t,r),null):o===0?i.copy(null,t,null,null,null):i.copy(null,null,null,null,i.right.insert(e,t,r)),i.fixUp()}removeMin(){if(this.left.isEmpty())return je.EMPTY;let e=this;return e.left.isRed()||e.left.left.isRed()||(e=e.moveRedLeft()),e=e.copy(null,null,null,e.left.removeMin(),null),e.fixUp()}remove(e,t){let r,i=this;if(t(e,i.key)<0)i.left.isEmpty()||i.left.isRed()||i.left.left.isRed()||(i=i.moveRedLeft()),i=i.copy(null,null,null,i.left.remove(e,t),null);else{if(i.left.isRed()&&(i=i.rotateRight()),i.right.isEmpty()||i.right.isRed()||i.right.left.isRed()||(i=i.moveRedRight()),t(e,i.key)===0){if(i.right.isEmpty())return je.EMPTY;r=i.right.min(),i=i.copy(r.key,r.value,null,null,i.right.removeMin())}i=i.copy(null,null,null,null,i.right.remove(e,t))}return i.fixUp()}isRed(){return this.color}fixUp(){let e=this;return e.right.isRed()&&!e.left.isRed()&&(e=e.rotateLeft()),e.left.isRed()&&e.left.left.isRed()&&(e=e.rotateRight()),e.left.isRed()&&e.right.isRed()&&(e=e.colorFlip()),e}moveRedLeft(){let e=this.colorFlip();return e.right.left.isRed()&&(e=e.copy(null,null,null,null,e.right.rotateRight()),e=e.rotateLeft(),e=e.colorFlip()),e}moveRedRight(){let e=this.colorFlip();return e.left.left.isRed()&&(e=e.rotateRight(),e=e.colorFlip()),e}rotateLeft(){const e=this.copy(null,null,je.RED,null,this.right.left);return this.right.copy(null,null,this.color,e,null)}rotateRight(){const e=this.copy(null,null,je.RED,this.left.right,null);return this.left.copy(null,null,this.color,null,e)}colorFlip(){const e=this.left.copy(null,null,!this.left.color,null,null),t=this.right.copy(null,null,!this.right.color,null,null);return this.copy(null,null,!this.color,e,t)}checkMaxDepth(){const e=this.check();return Math.pow(2,e)<=this.size+1}check(){if(this.isRed()&&this.left.isRed())throw Y(43730,{key:this.key,value:this.value});if(this.right.isRed())throw Y(14113,{key:this.key,value:this.value});const e=this.left.check();if(e!==this.right.check())throw Y(27949);return e+(this.isRed()?0:1)}}je.EMPTY=null,je.RED=!0,je.BLACK=!1;je.EMPTY=new class{constructor(){this.size=0}get key(){throw Y(57766)}get value(){throw Y(16141)}get color(){throw Y(16727)}get left(){throw Y(29726)}get right(){throw Y(36894)}copy(e,t,r,i,o){return this}insert(e,t,r){return new je(e,t)}remove(e,t){return this}isEmpty(){return!0}inorderTraversal(e){return!1}reverseTraversal(e){return!1}minKey(){return null}maxKey(){return null}isRed(){return!1}checkMaxDepth(){return!0}check(){return 0}};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ue{constructor(e){this.comparator=e,this.data=new be(this.comparator)}has(e){return this.data.get(e)!==null}first(){return this.data.minKey()}last(){return this.data.maxKey()}get size(){return this.data.size}indexOf(e){return this.data.indexOf(e)}forEach(e){this.data.inorderTraversal((t,r)=>(e(t),!1))}forEachInRange(e,t){const r=this.data.getIteratorFrom(e[0]);for(;r.hasNext();){const i=r.getNext();if(this.comparator(i.key,e[1])>=0)return;t(i.key)}}forEachWhile(e,t){let r;for(r=t!==void 0?this.data.getIteratorFrom(t):this.data.getIterator();r.hasNext();)if(!e(r.getNext().key))return}firstAfterOrEqual(e){const t=this.data.getIteratorFrom(e);return t.hasNext()?t.getNext().key:null}getIterator(){return new Wh(this.data.getIterator())}getIteratorFrom(e){return new Wh(this.data.getIteratorFrom(e))}add(e){return this.copy(this.data.remove(e).insert(e,!0))}delete(e){return this.has(e)?this.copy(this.data.remove(e)):this}isEmpty(){return this.data.isEmpty()}unionWith(e){let t=this;return t.size<e.size&&(t=e,e=this),e.forEach(r=>{t=t.add(r)}),t}isEqual(e){if(!(e instanceof Ue)||this.size!==e.size)return!1;const t=this.data.getIterator(),r=e.data.getIterator();for(;t.hasNext();){const i=t.getNext().key,o=r.getNext().key;if(this.comparator(i,o)!==0)return!1}return!0}toArray(){const e=[];return this.forEach(t=>{e.push(t)}),e}toString(){const e=[];return this.forEach(t=>e.push(t)),"SortedSet("+e.toString()+")"}copy(e){const t=new Ue(this.comparator);return t.data=e,t}}class Wh{constructor(e){this.iter=e}getNext(){return this.iter.getNext().key}hasNext(){return this.iter.hasNext()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class mt{constructor(e){this.fields=e,e.sort(ze.comparator)}static empty(){return new mt([])}unionWith(e){let t=new Ue(ze.comparator);for(const r of this.fields)t=t.add(r);for(const r of e)t=t.add(r);return new mt(t.toArray())}covers(e){for(const t of this.fields)if(t.isPrefixOf(e))return!0;return!1}isEqual(e){return hi(this.fields,e.fields,(t,r)=>t.isEqual(r))}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class hp extends Error{constructor(){super(...arguments),this.name="Base64DecodeError"}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class He{constructor(e){this.binaryString=e}static fromBase64String(e){const t=function(i){try{return atob(i)}catch(o){throw typeof DOMException<"u"&&o instanceof DOMException?new hp("Invalid base64 string: "+o):o}}(e);return new He(t)}static fromUint8Array(e){const t=function(i){let o="";for(let s=0;s<i.length;++s)o+=String.fromCharCode(i[s]);return o}(e);return new He(t)}[Symbol.iterator](){let e=0;return{next:()=>e<this.binaryString.length?{value:this.binaryString.charCodeAt(e++),done:!1}:{value:void 0,done:!0}}}toBase64(){return function(t){return btoa(t)}(this.binaryString)}toUint8Array(){return function(t){const r=new Uint8Array(t.length);for(let i=0;i<t.length;i++)r[i]=t.charCodeAt(i);return r}(this.binaryString)}approximateByteSize(){return 2*this.binaryString.length}compareTo(e){return ie(this.binaryString,e.binaryString)}isEqual(e){return this.binaryString===e.binaryString}}He.EMPTY_BYTE_STRING=new He("");const eb=new RegExp(/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.(\d+))?Z$/);function jn(n){if(he(!!n,39018),typeof n=="string"){let e=0;const t=eb.exec(n);if(he(!!t,46558,{timestamp:n}),t[1]){let i=t[1];i=(i+"000000000").substr(0,9),e=Number(i)}const r=new Date(n);return{seconds:Math.floor(r.getTime()/1e3),nanos:e}}return{seconds:Ae(n.seconds),nanos:Ae(n.nanos)}}function Ae(n){return typeof n=="number"?n:typeof n=="string"?Number(n):0}function zn(n){return typeof n=="string"?He.fromBase64String(n):He.fromUint8Array(n)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const dp="server_timestamp",fp="__type__",pp="__previous_value__",gp="__local_write_time__";function hc(n){var t,r;return((r=(((t=n==null?void 0:n.mapValue)==null?void 0:t.fields)||{})[fp])==null?void 0:r.stringValue)===dp}function ga(n){const e=n.mapValue.fields[pp];return hc(e)?ga(e):e}function _o(n){const e=jn(n.mapValue.fields[gp].timestampValue);return new me(e.seconds,e.nanos)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class tb{constructor(e,t,r,i,o,s,l,u,h,p,m){this.databaseId=e,this.appId=t,this.persistenceKey=r,this.host=i,this.ssl=o,this.forceLongPolling=s,this.autoDetectLongPolling=l,this.longPollingOptions=u,this.useFetchStreams=h,this.isUsingEmulator=p,this.apiKey=m}}const zs="(default)";class wo{constructor(e,t){this.projectId=e,this.database=t||zs}static empty(){return new wo("","")}get isDefaultDatabase(){return this.database===zs}isEqual(e){return e instanceof wo&&e.projectId===this.projectId&&e.database===this.database}}function nb(n,e){if(!Object.prototype.hasOwnProperty.apply(n.options,["projectId"]))throw new B(D.INVALID_ARGUMENT,'"projectId" not provided in firebase.initializeApp.');return new wo(n.options.projectId,e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const mp="__type__",rb="__max__",us={mapValue:{}},yp="__vector__",Ws="value";function Wn(n){return"nullValue"in n?0:"booleanValue"in n?1:"integerValue"in n||"doubleValue"in n?2:"timestampValue"in n?3:"stringValue"in n?5:"bytesValue"in n?6:"referenceValue"in n?7:"geoPointValue"in n?8:"arrayValue"in n?9:"mapValue"in n?hc(n)?4:ob(n)?9007199254740991:ib(n)?10:11:Y(28295,{value:n})}function Ht(n,e){if(n===e)return!0;const t=Wn(n);if(t!==Wn(e))return!1;switch(t){case 0:case 9007199254740991:return!0;case 1:return n.booleanValue===e.booleanValue;case 4:return _o(n).isEqual(_o(e));case 3:return function(i,o){if(typeof i.timestampValue=="string"&&typeof o.timestampValue=="string"&&i.timestampValue.length===o.timestampValue.length)return i.timestampValue===o.timestampValue;const s=jn(i.timestampValue),l=jn(o.timestampValue);return s.seconds===l.seconds&&s.nanos===l.nanos}(n,e);case 5:return n.stringValue===e.stringValue;case 6:return function(i,o){return zn(i.bytesValue).isEqual(zn(o.bytesValue))}(n,e);case 7:return n.referenceValue===e.referenceValue;case 8:return function(i,o){return Ae(i.geoPointValue.latitude)===Ae(o.geoPointValue.latitude)&&Ae(i.geoPointValue.longitude)===Ae(o.geoPointValue.longitude)}(n,e);case 2:return function(i,o){if("integerValue"in i&&"integerValue"in o)return Ae(i.integerValue)===Ae(o.integerValue);if("doubleValue"in i&&"doubleValue"in o){const s=Ae(i.doubleValue),l=Ae(o.doubleValue);return s===l?js(s)===js(l):isNaN(s)&&isNaN(l)}return!1}(n,e);case 9:return hi(n.arrayValue.values||[],e.arrayValue.values||[],Ht);case 10:case 11:return function(i,o){const s=i.mapValue.fields||{},l=o.mapValue.fields||{};if(zh(s)!==zh(l))return!1;for(const u in s)if(s.hasOwnProperty(u)&&(l[u]===void 0||!Ht(s[u],l[u])))return!1;return!0}(n,e);default:return Y(52216,{left:n})}}function bo(n,e){return(n.values||[]).find(t=>Ht(t,e))!==void 0}function di(n,e){if(n===e)return 0;const t=Wn(n),r=Wn(e);if(t!==r)return ie(t,r);switch(t){case 0:case 9007199254740991:return 0;case 1:return ie(n.booleanValue,e.booleanValue);case 2:return function(o,s){const l=Ae(o.integerValue||o.doubleValue),u=Ae(s.integerValue||s.doubleValue);return l<u?-1:l>u?1:l===u?0:isNaN(l)?isNaN(u)?0:-1:1}(n,e);case 3:return Hh(n.timestampValue,e.timestampValue);case 4:return Hh(_o(n),_o(e));case 5:return Il(n.stringValue,e.stringValue);case 6:return function(o,s){const l=zn(o),u=zn(s);return l.compareTo(u)}(n.bytesValue,e.bytesValue);case 7:return function(o,s){const l=o.split("/"),u=s.split("/");for(let h=0;h<l.length&&h<u.length;h++){const p=ie(l[h],u[h]);if(p!==0)return p}return ie(l.length,u.length)}(n.referenceValue,e.referenceValue);case 8:return function(o,s){const l=ie(Ae(o.latitude),Ae(s.latitude));return l!==0?l:ie(Ae(o.longitude),Ae(s.longitude))}(n.geoPointValue,e.geoPointValue);case 9:return Gh(n.arrayValue,e.arrayValue);case 10:return function(o,s){var g,b,P,A;const l=o.fields||{},u=s.fields||{},h=(g=l[Ws])==null?void 0:g.arrayValue,p=(b=u[Ws])==null?void 0:b.arrayValue,m=ie(((P=h==null?void 0:h.values)==null?void 0:P.length)||0,((A=p==null?void 0:p.values)==null?void 0:A.length)||0);return m!==0?m:Gh(h,p)}(n.mapValue,e.mapValue);case 11:return function(o,s){if(o===us.mapValue&&s===us.mapValue)return 0;if(o===us.mapValue)return 1;if(s===us.mapValue)return-1;const l=o.fields||{},u=Object.keys(l),h=s.fields||{},p=Object.keys(h);u.sort(),p.sort();for(let m=0;m<u.length&&m<p.length;++m){const g=Il(u[m],p[m]);if(g!==0)return g;const b=di(l[u[m]],h[p[m]]);if(b!==0)return b}return ie(u.length,p.length)}(n.mapValue,e.mapValue);default:throw Y(23264,{he:t})}}function Hh(n,e){if(typeof n=="string"&&typeof e=="string"&&n.length===e.length)return ie(n,e);const t=jn(n),r=jn(e),i=ie(t.seconds,r.seconds);return i!==0?i:ie(t.nanos,r.nanos)}function Gh(n,e){const t=n.values||[],r=e.values||[];for(let i=0;i<t.length&&i<r.length;++i){const o=di(t[i],r[i]);if(o)return o}return ie(t.length,r.length)}function fi(n){return Al(n)}function Al(n){return"nullValue"in n?"null":"booleanValue"in n?""+n.booleanValue:"integerValue"in n?""+n.integerValue:"doubleValue"in n?""+n.doubleValue:"timestampValue"in n?function(t){const r=jn(t);return`time(${r.seconds},${r.nanos})`}(n.timestampValue):"stringValue"in n?n.stringValue:"bytesValue"in n?function(t){return zn(t).toBase64()}(n.bytesValue):"referenceValue"in n?function(t){return G.fromName(t).toString()}(n.referenceValue):"geoPointValue"in n?function(t){return`geo(${t.latitude},${t.longitude})`}(n.geoPointValue):"arrayValue"in n?function(t){let r="[",i=!0;for(const o of t.values||[])i?i=!1:r+=",",r+=Al(o);return r+"]"}(n.arrayValue):"mapValue"in n?function(t){const r=Object.keys(t.fields||{}).sort();let i="{",o=!0;for(const s of r)o?o=!1:i+=",",i+=`${s}:${Al(t.fields[s])}`;return i+"}"}(n.mapValue):Y(61005,{value:n})}function Ss(n){switch(Wn(n)){case 0:case 1:return 4;case 2:return 8;case 3:case 8:return 16;case 4:const e=ga(n);return e?16+Ss(e):16;case 5:return 2*n.stringValue.length;case 6:return zn(n.bytesValue).approximateByteSize();case 7:return n.referenceValue.length;case 9:return function(r){return(r.values||[]).reduce((i,o)=>i+Ss(o),0)}(n.arrayValue);case 10:case 11:return function(r){let i=0;return Yn(r.fields,(o,s)=>{i+=o.length+Ss(s)}),i}(n.mapValue);default:throw Y(13486,{value:n})}}function Kh(n,e){return{referenceValue:`projects/${n.projectId}/databases/${n.database}/documents/${e.path.canonicalString()}`}}function Sl(n){return!!n&&"integerValue"in n}function dc(n){return!!n&&"arrayValue"in n}function Yh(n){return!!n&&"nullValue"in n}function Qh(n){return!!n&&"doubleValue"in n&&isNaN(Number(n.doubleValue))}function xs(n){return!!n&&"mapValue"in n}function ib(n){var t,r;return((r=(((t=n==null?void 0:n.mapValue)==null?void 0:t.fields)||{})[mp])==null?void 0:r.stringValue)===yp}function so(n){if(n.geoPointValue)return{geoPointValue:{...n.geoPointValue}};if(n.timestampValue&&typeof n.timestampValue=="object")return{timestampValue:{...n.timestampValue}};if(n.mapValue){const e={mapValue:{fields:{}}};return Yn(n.mapValue.fields,(t,r)=>e.mapValue.fields[t]=so(r)),e}if(n.arrayValue){const e={arrayValue:{values:[]}};for(let t=0;t<(n.arrayValue.values||[]).length;++t)e.arrayValue.values[t]=so(n.arrayValue.values[t]);return e}return{...n}}function ob(n){return(((n.mapValue||{}).fields||{}).__type__||{}).stringValue===rb}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ut{constructor(e){this.value=e}static empty(){return new ut({mapValue:{}})}field(e){if(e.isEmpty())return this.value;{let t=this.value;for(let r=0;r<e.length-1;++r)if(t=(t.mapValue.fields||{})[e.get(r)],!xs(t))return null;return t=(t.mapValue.fields||{})[e.lastSegment()],t||null}}set(e,t){this.getFieldsMap(e.popLast())[e.lastSegment()]=so(t)}setAll(e){let t=ze.emptyPath(),r={},i=[];e.forEach((s,l)=>{if(!t.isImmediateParentOf(l)){const u=this.getFieldsMap(t);this.applyChanges(u,r,i),r={},i=[],t=l.popLast()}s?r[l.lastSegment()]=so(s):i.push(l.lastSegment())});const o=this.getFieldsMap(t);this.applyChanges(o,r,i)}delete(e){const t=this.field(e.popLast());xs(t)&&t.mapValue.fields&&delete t.mapValue.fields[e.lastSegment()]}isEqual(e){return Ht(this.value,e.value)}getFieldsMap(e){let t=this.value;t.mapValue.fields||(t.mapValue={fields:{}});for(let r=0;r<e.length;++r){let i=t.mapValue.fields[e.get(r)];xs(i)&&i.mapValue.fields||(i={mapValue:{fields:{}}},t.mapValue.fields[e.get(r)]=i),t=i}return t.mapValue.fields}applyChanges(e,t,r){Yn(t,(i,o)=>e[i]=o);for(const i of r)delete e[i]}clone(){return new ut(so(this.value))}}function vp(n){const e=[];return Yn(n.fields,(t,r)=>{const i=new ze([t]);if(xs(r)){const o=vp(r.mapValue).fields;if(o.length===0)e.push(i);else for(const s of o)e.push(i.child(s))}else e.push(i)}),new mt(e)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Qe{constructor(e,t,r,i,o,s,l){this.key=e,this.documentType=t,this.version=r,this.readTime=i,this.createTime=o,this.data=s,this.documentState=l}static newInvalidDocument(e){return new Qe(e,0,X.min(),X.min(),X.min(),ut.empty(),0)}static newFoundDocument(e,t,r,i){return new Qe(e,1,t,X.min(),r,i,0)}static newNoDocument(e,t){return new Qe(e,2,t,X.min(),X.min(),ut.empty(),0)}static newUnknownDocument(e,t){return new Qe(e,3,t,X.min(),X.min(),ut.empty(),2)}convertToFoundDocument(e,t){return!this.createTime.isEqual(X.min())||this.documentType!==2&&this.documentType!==0||(this.createTime=e),this.version=e,this.documentType=1,this.data=t,this.documentState=0,this}convertToNoDocument(e){return this.version=e,this.documentType=2,this.data=ut.empty(),this.documentState=0,this}convertToUnknownDocument(e){return this.version=e,this.documentType=3,this.data=ut.empty(),this.documentState=2,this}setHasCommittedMutations(){return this.documentState=2,this}setHasLocalMutations(){return this.documentState=1,this.version=X.min(),this}setReadTime(e){return this.readTime=e,this}get hasLocalMutations(){return this.documentState===1}get hasCommittedMutations(){return this.documentState===2}get hasPendingWrites(){return this.hasLocalMutations||this.hasCommittedMutations}isValidDocument(){return this.documentType!==0}isFoundDocument(){return this.documentType===1}isNoDocument(){return this.documentType===2}isUnknownDocument(){return this.documentType===3}isEqual(e){return e instanceof Qe&&this.key.isEqual(e.key)&&this.version.isEqual(e.version)&&this.documentType===e.documentType&&this.documentState===e.documentState&&this.data.isEqual(e.data)}mutableCopy(){return new Qe(this.key,this.documentType,this.version,this.readTime,this.createTime,this.data.clone(),this.documentState)}toString(){return`Document(${this.key}, ${this.version}, ${JSON.stringify(this.data.value)}, {createTime: ${this.createTime}}), {documentType: ${this.documentType}}), {documentState: ${this.documentState}})`}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Hs{constructor(e,t){this.position=e,this.inclusive=t}}function Xh(n,e,t){let r=0;for(let i=0;i<n.position.length;i++){const o=e[i],s=n.position[i];if(o.field.isKeyField()?r=G.comparator(G.fromName(s.referenceValue),t.key):r=di(s,t.data.field(o.field)),o.dir==="desc"&&(r*=-1),r!==0)break}return r}function Jh(n,e){if(n===null)return e===null;if(e===null||n.inclusive!==e.inclusive||n.position.length!==e.position.length)return!1;for(let t=0;t<n.position.length;t++)if(!Ht(n.position[t],e.position[t]))return!1;return!0}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class To{constructor(e,t="asc"){this.field=e,this.dir=t}}function sb(n,e){return n.dir===e.dir&&n.field.isEqual(e.field)}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _p{}class Ce extends _p{constructor(e,t,r){super(),this.field=e,this.op=t,this.value=r}static create(e,t,r){return e.isKeyField()?t==="in"||t==="not-in"?this.createKeyFieldInFilter(e,t,r):new lb(e,t,r):t==="array-contains"?new hb(e,r):t==="in"?new db(e,r):t==="not-in"?new fb(e,r):t==="array-contains-any"?new pb(e,r):new Ce(e,t,r)}static createKeyFieldInFilter(e,t,r){return t==="in"?new cb(e,r):new ub(e,r)}matches(e){const t=e.data.field(this.field);return this.op==="!="?t!==null&&t.nullValue===void 0&&this.matchesComparison(di(t,this.value)):t!==null&&Wn(this.value)===Wn(t)&&this.matchesComparison(di(t,this.value))}matchesComparison(e){switch(this.op){case"<":return e<0;case"<=":return e<=0;case"==":return e===0;case"!=":return e!==0;case">":return e>0;case">=":return e>=0;default:return Y(47266,{operator:this.op})}}isInequality(){return["<","<=",">",">=","!=","not-in"].indexOf(this.op)>=0}getFlattenedFilters(){return[this]}getFilters(){return[this]}}class Ct extends _p{constructor(e,t){super(),this.filters=e,this.op=t,this.Pe=null}static create(e,t){return new Ct(e,t)}matches(e){return wp(this)?this.filters.find(t=>!t.matches(e))===void 0:this.filters.find(t=>t.matches(e))!==void 0}getFlattenedFilters(){return this.Pe!==null||(this.Pe=this.filters.reduce((e,t)=>e.concat(t.getFlattenedFilters()),[])),this.Pe}getFilters(){return Object.assign([],this.filters)}}function wp(n){return n.op==="and"}function bp(n){return ab(n)&&wp(n)}function ab(n){for(const e of n.filters)if(e instanceof Ct)return!1;return!0}function xl(n){if(n instanceof Ce)return n.field.canonicalString()+n.op.toString()+fi(n.value);if(bp(n))return n.filters.map(e=>xl(e)).join(",");{const e=n.filters.map(t=>xl(t)).join(",");return`${n.op}(${e})`}}function Tp(n,e){return n instanceof Ce?function(r,i){return i instanceof Ce&&r.op===i.op&&r.field.isEqual(i.field)&&Ht(r.value,i.value)}(n,e):n instanceof Ct?function(r,i){return i instanceof Ct&&r.op===i.op&&r.filters.length===i.filters.length?r.filters.reduce((o,s,l)=>o&&Tp(s,i.filters[l]),!0):!1}(n,e):void Y(19439)}function Ep(n){return n instanceof Ce?function(t){return`${t.field.canonicalString()} ${t.op} ${fi(t.value)}`}(n):n instanceof Ct?function(t){return t.op.toString()+" {"+t.getFilters().map(Ep).join(" ,")+"}"}(n):"Filter"}class lb extends Ce{constructor(e,t,r){super(e,t,r),this.key=G.fromName(r.referenceValue)}matches(e){const t=G.comparator(e.key,this.key);return this.matchesComparison(t)}}class cb extends Ce{constructor(e,t){super(e,"in",t),this.keys=Ip("in",t)}matches(e){return this.keys.some(t=>t.isEqual(e.key))}}class ub extends Ce{constructor(e,t){super(e,"not-in",t),this.keys=Ip("not-in",t)}matches(e){return!this.keys.some(t=>t.isEqual(e.key))}}function Ip(n,e){var t;return(((t=e.arrayValue)==null?void 0:t.values)||[]).map(r=>G.fromName(r.referenceValue))}class hb extends Ce{constructor(e,t){super(e,"array-contains",t)}matches(e){const t=e.data.field(this.field);return dc(t)&&bo(t.arrayValue,this.value)}}class db extends Ce{constructor(e,t){super(e,"in",t)}matches(e){const t=e.data.field(this.field);return t!==null&&bo(this.value.arrayValue,t)}}class fb extends Ce{constructor(e,t){super(e,"not-in",t)}matches(e){if(bo(this.value.arrayValue,{nullValue:"NULL_VALUE"}))return!1;const t=e.data.field(this.field);return t!==null&&t.nullValue===void 0&&!bo(this.value.arrayValue,t)}}class pb extends Ce{constructor(e,t){super(e,"array-contains-any",t)}matches(e){const t=e.data.field(this.field);return!(!dc(t)||!t.arrayValue.values)&&t.arrayValue.values.some(r=>bo(this.value.arrayValue,r))}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class gb{constructor(e,t=null,r=[],i=[],o=null,s=null,l=null){this.path=e,this.collectionGroup=t,this.orderBy=r,this.filters=i,this.limit=o,this.startAt=s,this.endAt=l,this.Te=null}}function Zh(n,e=null,t=[],r=[],i=null,o=null,s=null){return new gb(n,e,t,r,i,o,s)}function fc(n){const e=J(n);if(e.Te===null){let t=e.path.canonicalString();e.collectionGroup!==null&&(t+="|cg:"+e.collectionGroup),t+="|f:",t+=e.filters.map(r=>xl(r)).join(","),t+="|ob:",t+=e.orderBy.map(r=>function(o){return o.field.canonicalString()+o.dir}(r)).join(","),pa(e.limit)||(t+="|l:",t+=e.limit),e.startAt&&(t+="|lb:",t+=e.startAt.inclusive?"b:":"a:",t+=e.startAt.position.map(r=>fi(r)).join(",")),e.endAt&&(t+="|ub:",t+=e.endAt.inclusive?"a:":"b:",t+=e.endAt.position.map(r=>fi(r)).join(",")),e.Te=t}return e.Te}function pc(n,e){if(n.limit!==e.limit||n.orderBy.length!==e.orderBy.length)return!1;for(let t=0;t<n.orderBy.length;t++)if(!sb(n.orderBy[t],e.orderBy[t]))return!1;if(n.filters.length!==e.filters.length)return!1;for(let t=0;t<n.filters.length;t++)if(!Tp(n.filters[t],e.filters[t]))return!1;return n.collectionGroup===e.collectionGroup&&!!n.path.isEqual(e.path)&&!!Jh(n.startAt,e.startAt)&&Jh(n.endAt,e.endAt)}function kl(n){return G.isDocumentKey(n.path)&&n.collectionGroup===null&&n.filters.length===0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ai{constructor(e,t=null,r=[],i=[],o=null,s="F",l=null,u=null){this.path=e,this.collectionGroup=t,this.explicitOrderBy=r,this.filters=i,this.limit=o,this.limitType=s,this.startAt=l,this.endAt=u,this.Ee=null,this.Ie=null,this.Re=null,this.startAt,this.endAt}}function mb(n,e,t,r,i,o,s,l){return new Ai(n,e,t,r,i,o,s,l)}function ma(n){return new Ai(n)}function ed(n){return n.filters.length===0&&n.limit===null&&n.startAt==null&&n.endAt==null&&(n.explicitOrderBy.length===0||n.explicitOrderBy.length===1&&n.explicitOrderBy[0].field.isKeyField())}function yb(n){return G.isDocumentKey(n.path)&&n.collectionGroup===null&&n.filters.length===0}function Ap(n){return n.collectionGroup!==null}function ao(n){const e=J(n);if(e.Ee===null){e.Ee=[];const t=new Set;for(const o of e.explicitOrderBy)e.Ee.push(o),t.add(o.field.canonicalString());const r=e.explicitOrderBy.length>0?e.explicitOrderBy[e.explicitOrderBy.length-1].dir:"asc";(function(s){let l=new Ue(ze.comparator);return s.filters.forEach(u=>{u.getFlattenedFilters().forEach(h=>{h.isInequality()&&(l=l.add(h.field))})}),l})(e).forEach(o=>{t.has(o.canonicalString())||o.isKeyField()||e.Ee.push(new To(o,r))}),t.has(ze.keyField().canonicalString())||e.Ee.push(new To(ze.keyField(),r))}return e.Ee}function $t(n){const e=J(n);return e.Ie||(e.Ie=vb(e,ao(n))),e.Ie}function vb(n,e){if(n.limitType==="F")return Zh(n.path,n.collectionGroup,e,n.filters,n.limit,n.startAt,n.endAt);{e=e.map(i=>{const o=i.dir==="desc"?"asc":"desc";return new To(i.field,o)});const t=n.endAt?new Hs(n.endAt.position,n.endAt.inclusive):null,r=n.startAt?new Hs(n.startAt.position,n.startAt.inclusive):null;return Zh(n.path,n.collectionGroup,e,n.filters,n.limit,t,r)}}function Pl(n,e){const t=n.filters.concat([e]);return new Ai(n.path,n.collectionGroup,n.explicitOrderBy.slice(),t,n.limit,n.limitType,n.startAt,n.endAt)}function _b(n,e){const t=n.explicitOrderBy.concat([e]);return new Ai(n.path,n.collectionGroup,t,n.filters.slice(),n.limit,n.limitType,n.startAt,n.endAt)}function Gs(n,e,t){return new Ai(n.path,n.collectionGroup,n.explicitOrderBy.slice(),n.filters.slice(),e,t,n.startAt,n.endAt)}function ya(n,e){return pc($t(n),$t(e))&&n.limitType===e.limitType}function Sp(n){return`${fc($t(n))}|lt:${n.limitType}`}function $r(n){return`Query(target=${function(t){let r=t.path.canonicalString();return t.collectionGroup!==null&&(r+=" collectionGroup="+t.collectionGroup),t.filters.length>0&&(r+=`, filters: [${t.filters.map(i=>Ep(i)).join(", ")}]`),pa(t.limit)||(r+=", limit: "+t.limit),t.orderBy.length>0&&(r+=`, orderBy: [${t.orderBy.map(i=>function(s){return`${s.field.canonicalString()} (${s.dir})`}(i)).join(", ")}]`),t.startAt&&(r+=", startAt: ",r+=t.startAt.inclusive?"b:":"a:",r+=t.startAt.position.map(i=>fi(i)).join(",")),t.endAt&&(r+=", endAt: ",r+=t.endAt.inclusive?"a:":"b:",r+=t.endAt.position.map(i=>fi(i)).join(",")),`Target(${r})`}($t(n))}; limitType=${n.limitType})`}function va(n,e){return e.isFoundDocument()&&function(r,i){const o=i.key.path;return r.collectionGroup!==null?i.key.hasCollectionId(r.collectionGroup)&&r.path.isPrefixOf(o):G.isDocumentKey(r.path)?r.path.isEqual(o):r.path.isImmediateParentOf(o)}(n,e)&&function(r,i){for(const o of ao(r))if(!o.field.isKeyField()&&i.data.field(o.field)===null)return!1;return!0}(n,e)&&function(r,i){for(const o of r.filters)if(!o.matches(i))return!1;return!0}(n,e)&&function(r,i){return!(r.startAt&&!function(s,l,u){const h=Xh(s,l,u);return s.inclusive?h<=0:h<0}(r.startAt,ao(r),i)||r.endAt&&!function(s,l,u){const h=Xh(s,l,u);return s.inclusive?h>=0:h>0}(r.endAt,ao(r),i))}(n,e)}function wb(n){return n.collectionGroup||(n.path.length%2==1?n.path.lastSegment():n.path.get(n.path.length-2))}function xp(n){return(e,t)=>{let r=!1;for(const i of ao(n)){const o=bb(i,e,t);if(o!==0)return o;r=r||i.field.isKeyField()}return 0}}function bb(n,e,t){const r=n.field.isKeyField()?G.comparator(e.key,t.key):function(o,s,l){const u=s.data.field(o),h=l.data.field(o);return u!==null&&h!==null?di(u,h):Y(42886)}(n.field,e,t);switch(n.dir){case"asc":return r;case"desc":return-1*r;default:return Y(19790,{direction:n.dir})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class kr{constructor(e,t){this.mapKeyFn=e,this.equalsFn=t,this.inner={},this.innerSize=0}get(e){const t=this.mapKeyFn(e),r=this.inner[t];if(r!==void 0){for(const[i,o]of r)if(this.equalsFn(i,e))return o}}has(e){return this.get(e)!==void 0}set(e,t){const r=this.mapKeyFn(e),i=this.inner[r];if(i===void 0)return this.inner[r]=[[e,t]],void this.innerSize++;for(let o=0;o<i.length;o++)if(this.equalsFn(i[o][0],e))return void(i[o]=[e,t]);i.push([e,t]),this.innerSize++}delete(e){const t=this.mapKeyFn(e),r=this.inner[t];if(r===void 0)return!1;for(let i=0;i<r.length;i++)if(this.equalsFn(r[i][0],e))return r.length===1?delete this.inner[t]:r.splice(i,1),this.innerSize--,!0;return!1}forEach(e){Yn(this.inner,(t,r)=>{for(const[i,o]of r)e(i,o)})}isEmpty(){return up(this.inner)}size(){return this.innerSize}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Tb=new be(G.comparator);function gn(){return Tb}const kp=new be(G.comparator);function Zi(...n){let e=kp;for(const t of n)e=e.insert(t.key,t);return e}function Pp(n){let e=kp;return n.forEach((t,r)=>e=e.insert(t,r.overlayedDocument)),e}function sr(){return lo()}function Cp(){return lo()}function lo(){return new kr(n=>n.toString(),(n,e)=>n.isEqual(e))}const Eb=new be(G.comparator),Ib=new Ue(G.comparator);function oe(...n){let e=Ib;for(const t of n)e=e.add(t);return e}const Ab=new Ue(ie);function Sb(){return Ab}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function gc(n,e){if(n.useProto3Json){if(isNaN(e))return{doubleValue:"NaN"};if(e===1/0)return{doubleValue:"Infinity"};if(e===-1/0)return{doubleValue:"-Infinity"}}return{doubleValue:js(e)?"-0":e}}function Rp(n){return{integerValue:""+n}}function Op(n,e){return Xw(e)?Rp(e):gc(n,e)}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _a{constructor(){this._=void 0}}function xb(n,e,t){return n instanceof Eo?function(i,o){const s={fields:{[fp]:{stringValue:dp},[gp]:{timestampValue:{seconds:i.seconds,nanos:i.nanoseconds}}}};return o&&hc(o)&&(o=ga(o)),o&&(s.fields[pp]=o),{mapValue:s}}(t,e):n instanceof Io?Dp(n,e):n instanceof Ao?Mp(n,e):function(i,o){const s=Np(i,o),l=td(s)+td(i.Ae);return Sl(s)&&Sl(i.Ae)?Rp(l):gc(i.serializer,l)}(n,e)}function kb(n,e,t){return n instanceof Io?Dp(n,e):n instanceof Ao?Mp(n,e):t}function Np(n,e){return n instanceof So?function(r){return Sl(r)||function(o){return!!o&&"doubleValue"in o}(r)}(e)?e:{integerValue:0}:null}class Eo extends _a{}class Io extends _a{constructor(e){super(),this.elements=e}}function Dp(n,e){const t=Lp(e);for(const r of n.elements)t.some(i=>Ht(i,r))||t.push(r);return{arrayValue:{values:t}}}class Ao extends _a{constructor(e){super(),this.elements=e}}function Mp(n,e){let t=Lp(e);for(const r of n.elements)t=t.filter(i=>!Ht(i,r));return{arrayValue:{values:t}}}class So extends _a{constructor(e,t){super(),this.serializer=e,this.Ae=t}}function td(n){return Ae(n.integerValue||n.doubleValue)}function Lp(n){return dc(n)&&n.arrayValue.values?n.arrayValue.values.slice():[]}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Vp{constructor(e,t){this.field=e,this.transform=t}}function Pb(n,e){return n.field.isEqual(e.field)&&function(r,i){return r instanceof Io&&i instanceof Io||r instanceof Ao&&i instanceof Ao?hi(r.elements,i.elements,Ht):r instanceof So&&i instanceof So?Ht(r.Ae,i.Ae):r instanceof Eo&&i instanceof Eo}(n.transform,e.transform)}class Cb{constructor(e,t){this.version=e,this.transformResults=t}}class At{constructor(e,t){this.updateTime=e,this.exists=t}static none(){return new At}static exists(e){return new At(void 0,e)}static updateTime(e){return new At(e)}get isNone(){return this.updateTime===void 0&&this.exists===void 0}isEqual(e){return this.exists===e.exists&&(this.updateTime?!!e.updateTime&&this.updateTime.isEqual(e.updateTime):!e.updateTime)}}function ks(n,e){return n.updateTime!==void 0?e.isFoundDocument()&&e.version.isEqual(n.updateTime):n.exists===void 0||n.exists===e.isFoundDocument()}class wa{}function Fp(n,e){if(!n.hasLocalMutations||e&&e.fields.length===0)return null;if(e===null)return n.isNoDocument()?new mc(n.key,At.none()):new $o(n.key,n.data,At.none());{const t=n.data,r=ut.empty();let i=new Ue(ze.comparator);for(let o of e.fields)if(!i.has(o)){let s=t.field(o);s===null&&o.length>1&&(o=o.popLast(),s=t.field(o)),s===null?r.delete(o):r.set(o,s),i=i.add(o)}return new Qn(n.key,r,new mt(i.toArray()),At.none())}}function Rb(n,e,t){n instanceof $o?function(i,o,s){const l=i.value.clone(),u=rd(i.fieldTransforms,o,s.transformResults);l.setAll(u),o.convertToFoundDocument(s.version,l).setHasCommittedMutations()}(n,e,t):n instanceof Qn?function(i,o,s){if(!ks(i.precondition,o))return void o.convertToUnknownDocument(s.version);const l=rd(i.fieldTransforms,o,s.transformResults),u=o.data;u.setAll(Up(i)),u.setAll(l),o.convertToFoundDocument(s.version,u).setHasCommittedMutations()}(n,e,t):function(i,o,s){o.convertToNoDocument(s.version).setHasCommittedMutations()}(0,e,t)}function co(n,e,t,r){return n instanceof $o?function(o,s,l,u){if(!ks(o.precondition,s))return l;const h=o.value.clone(),p=id(o.fieldTransforms,u,s);return h.setAll(p),s.convertToFoundDocument(s.version,h).setHasLocalMutations(),null}(n,e,t,r):n instanceof Qn?function(o,s,l,u){if(!ks(o.precondition,s))return l;const h=id(o.fieldTransforms,u,s),p=s.data;return p.setAll(Up(o)),p.setAll(h),s.convertToFoundDocument(s.version,p).setHasLocalMutations(),l===null?null:l.unionWith(o.fieldMask.fields).unionWith(o.fieldTransforms.map(m=>m.field))}(n,e,t,r):function(o,s,l){return ks(o.precondition,s)?(s.convertToNoDocument(s.version).setHasLocalMutations(),null):l}(n,e,t)}function Ob(n,e){let t=null;for(const r of n.fieldTransforms){const i=e.data.field(r.field),o=Np(r.transform,i||null);o!=null&&(t===null&&(t=ut.empty()),t.set(r.field,o))}return t||null}function nd(n,e){return n.type===e.type&&!!n.key.isEqual(e.key)&&!!n.precondition.isEqual(e.precondition)&&!!function(r,i){return r===void 0&&i===void 0||!(!r||!i)&&hi(r,i,(o,s)=>Pb(o,s))}(n.fieldTransforms,e.fieldTransforms)&&(n.type===0?n.value.isEqual(e.value):n.type!==1||n.data.isEqual(e.data)&&n.fieldMask.isEqual(e.fieldMask))}class $o extends wa{constructor(e,t,r,i=[]){super(),this.key=e,this.value=t,this.precondition=r,this.fieldTransforms=i,this.type=0}getFieldMask(){return null}}class Qn extends wa{constructor(e,t,r,i,o=[]){super(),this.key=e,this.data=t,this.fieldMask=r,this.precondition=i,this.fieldTransforms=o,this.type=1}getFieldMask(){return this.fieldMask}}function Up(n){const e=new Map;return n.fieldMask.fields.forEach(t=>{if(!t.isEmpty()){const r=n.data.field(t);e.set(t,r)}}),e}function rd(n,e,t){const r=new Map;he(n.length===t.length,32656,{Ve:t.length,de:n.length});for(let i=0;i<t.length;i++){const o=n[i],s=o.transform,l=e.data.field(o.field);r.set(o.field,kb(s,l,t[i]))}return r}function id(n,e,t){const r=new Map;for(const i of n){const o=i.transform,s=t.data.field(i.field);r.set(i.field,xb(o,s,e))}return r}class mc extends wa{constructor(e,t){super(),this.key=e,this.precondition=t,this.type=2,this.fieldTransforms=[]}getFieldMask(){return null}}class Nb extends wa{constructor(e,t){super(),this.key=e,this.precondition=t,this.type=3,this.fieldTransforms=[]}getFieldMask(){return null}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Db{constructor(e,t,r,i){this.batchId=e,this.localWriteTime=t,this.baseMutations=r,this.mutations=i}applyToRemoteDocument(e,t){const r=t.mutationResults;for(let i=0;i<this.mutations.length;i++){const o=this.mutations[i];o.key.isEqual(e.key)&&Rb(o,e,r[i])}}applyToLocalView(e,t){for(const r of this.baseMutations)r.key.isEqual(e.key)&&(t=co(r,e,t,this.localWriteTime));for(const r of this.mutations)r.key.isEqual(e.key)&&(t=co(r,e,t,this.localWriteTime));return t}applyToLocalDocumentSet(e,t){const r=Cp();return this.mutations.forEach(i=>{const o=e.get(i.key),s=o.overlayedDocument;let l=this.applyToLocalView(s,o.mutatedFields);l=t.has(i.key)?null:l;const u=Fp(s,l);u!==null&&r.set(i.key,u),s.isValidDocument()||s.convertToNoDocument(X.min())}),r}keys(){return this.mutations.reduce((e,t)=>e.add(t.key),oe())}isEqual(e){return this.batchId===e.batchId&&hi(this.mutations,e.mutations,(t,r)=>nd(t,r))&&hi(this.baseMutations,e.baseMutations,(t,r)=>nd(t,r))}}class yc{constructor(e,t,r,i){this.batch=e,this.commitVersion=t,this.mutationResults=r,this.docVersions=i}static from(e,t,r){he(e.mutations.length===r.length,58842,{me:e.mutations.length,fe:r.length});let i=function(){return Eb}();const o=e.mutations;for(let s=0;s<o.length;s++)i=i.insert(o[s].key,r[s].version);return new yc(e,t,r,i)}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Mb{constructor(e,t){this.largestBatchId=e,this.mutation=t}getKey(){return this.mutation.key}isEqual(e){return e!==null&&this.mutation===e.mutation}toString(){return`Overlay{
      largestBatchId: ${this.largestBatchId},
      mutation: ${this.mutation.toString()}
    }`}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Lb{constructor(e,t){this.count=e,this.unchangedNames=t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var Pe,se;function Vb(n){switch(n){case D.OK:return Y(64938);case D.CANCELLED:case D.UNKNOWN:case D.DEADLINE_EXCEEDED:case D.RESOURCE_EXHAUSTED:case D.INTERNAL:case D.UNAVAILABLE:case D.UNAUTHENTICATED:return!1;case D.INVALID_ARGUMENT:case D.NOT_FOUND:case D.ALREADY_EXISTS:case D.PERMISSION_DENIED:case D.FAILED_PRECONDITION:case D.ABORTED:case D.OUT_OF_RANGE:case D.UNIMPLEMENTED:case D.DATA_LOSS:return!0;default:return Y(15467,{code:n})}}function qp(n){if(n===void 0)return pn("GRPC error has no .code"),D.UNKNOWN;switch(n){case Pe.OK:return D.OK;case Pe.CANCELLED:return D.CANCELLED;case Pe.UNKNOWN:return D.UNKNOWN;case Pe.DEADLINE_EXCEEDED:return D.DEADLINE_EXCEEDED;case Pe.RESOURCE_EXHAUSTED:return D.RESOURCE_EXHAUSTED;case Pe.INTERNAL:return D.INTERNAL;case Pe.UNAVAILABLE:return D.UNAVAILABLE;case Pe.UNAUTHENTICATED:return D.UNAUTHENTICATED;case Pe.INVALID_ARGUMENT:return D.INVALID_ARGUMENT;case Pe.NOT_FOUND:return D.NOT_FOUND;case Pe.ALREADY_EXISTS:return D.ALREADY_EXISTS;case Pe.PERMISSION_DENIED:return D.PERMISSION_DENIED;case Pe.FAILED_PRECONDITION:return D.FAILED_PRECONDITION;case Pe.ABORTED:return D.ABORTED;case Pe.OUT_OF_RANGE:return D.OUT_OF_RANGE;case Pe.UNIMPLEMENTED:return D.UNIMPLEMENTED;case Pe.DATA_LOSS:return D.DATA_LOSS;default:return Y(39323,{code:n})}}(se=Pe||(Pe={}))[se.OK=0]="OK",se[se.CANCELLED=1]="CANCELLED",se[se.UNKNOWN=2]="UNKNOWN",se[se.INVALID_ARGUMENT=3]="INVALID_ARGUMENT",se[se.DEADLINE_EXCEEDED=4]="DEADLINE_EXCEEDED",se[se.NOT_FOUND=5]="NOT_FOUND",se[se.ALREADY_EXISTS=6]="ALREADY_EXISTS",se[se.PERMISSION_DENIED=7]="PERMISSION_DENIED",se[se.UNAUTHENTICATED=16]="UNAUTHENTICATED",se[se.RESOURCE_EXHAUSTED=8]="RESOURCE_EXHAUSTED",se[se.FAILED_PRECONDITION=9]="FAILED_PRECONDITION",se[se.ABORTED=10]="ABORTED",se[se.OUT_OF_RANGE=11]="OUT_OF_RANGE",se[se.UNIMPLEMENTED=12]="UNIMPLEMENTED",se[se.INTERNAL=13]="INTERNAL",se[se.UNAVAILABLE=14]="UNAVAILABLE",se[se.DATA_LOSS=15]="DATA_LOSS";/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Fb(){return new TextEncoder}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ub=new Fn([4294967295,4294967295],0);function od(n){const e=Fb().encode(n),t=new Zf;return t.update(e),new Uint8Array(t.digest())}function sd(n){const e=new DataView(n.buffer),t=e.getUint32(0,!0),r=e.getUint32(4,!0),i=e.getUint32(8,!0),o=e.getUint32(12,!0);return[new Fn([t,r],0),new Fn([i,o],0)]}class vc{constructor(e,t,r){if(this.bitmap=e,this.padding=t,this.hashCount=r,t<0||t>=8)throw new eo(`Invalid padding: ${t}`);if(r<0)throw new eo(`Invalid hash count: ${r}`);if(e.length>0&&this.hashCount===0)throw new eo(`Invalid hash count: ${r}`);if(e.length===0&&t!==0)throw new eo(`Invalid padding when bitmap length is 0: ${t}`);this.ge=8*e.length-t,this.pe=Fn.fromNumber(this.ge)}ye(e,t,r){let i=e.add(t.multiply(Fn.fromNumber(r)));return i.compare(Ub)===1&&(i=new Fn([i.getBits(0),i.getBits(1)],0)),i.modulo(this.pe).toNumber()}we(e){return!!(this.bitmap[Math.floor(e/8)]&1<<e%8)}mightContain(e){if(this.ge===0)return!1;const t=od(e),[r,i]=sd(t);for(let o=0;o<this.hashCount;o++){const s=this.ye(r,i,o);if(!this.we(s))return!1}return!0}static create(e,t,r){const i=e%8==0?0:8-e%8,o=new Uint8Array(Math.ceil(e/8)),s=new vc(o,i,t);return r.forEach(l=>s.insert(l)),s}insert(e){if(this.ge===0)return;const t=od(e),[r,i]=sd(t);for(let o=0;o<this.hashCount;o++){const s=this.ye(r,i,o);this.Se(s)}}Se(e){const t=Math.floor(e/8),r=e%8;this.bitmap[t]|=1<<r}}class eo extends Error{constructor(){super(...arguments),this.name="BloomFilterError"}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ba{constructor(e,t,r,i,o){this.snapshotVersion=e,this.targetChanges=t,this.targetMismatches=r,this.documentUpdates=i,this.resolvedLimboDocuments=o}static createSynthesizedRemoteEventForCurrentChange(e,t,r){const i=new Map;return i.set(e,jo.createSynthesizedTargetChangeForCurrentChange(e,t,r)),new ba(X.min(),i,new be(ie),gn(),oe())}}class jo{constructor(e,t,r,i,o){this.resumeToken=e,this.current=t,this.addedDocuments=r,this.modifiedDocuments=i,this.removedDocuments=o}static createSynthesizedTargetChangeForCurrentChange(e,t,r){return new jo(r,t,oe(),oe(),oe())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ps{constructor(e,t,r,i){this.be=e,this.removedTargetIds=t,this.key=r,this.De=i}}class Bp{constructor(e,t){this.targetId=e,this.Ce=t}}class $p{constructor(e,t,r=He.EMPTY_BYTE_STRING,i=null){this.state=e,this.targetIds=t,this.resumeToken=r,this.cause=i}}class ad{constructor(){this.ve=0,this.Fe=ld(),this.Me=He.EMPTY_BYTE_STRING,this.xe=!1,this.Oe=!0}get current(){return this.xe}get resumeToken(){return this.Me}get Ne(){return this.ve!==0}get Be(){return this.Oe}Le(e){e.approximateByteSize()>0&&(this.Oe=!0,this.Me=e)}ke(){let e=oe(),t=oe(),r=oe();return this.Fe.forEach((i,o)=>{switch(o){case 0:e=e.add(i);break;case 2:t=t.add(i);break;case 1:r=r.add(i);break;default:Y(38017,{changeType:o})}}),new jo(this.Me,this.xe,e,t,r)}qe(){this.Oe=!1,this.Fe=ld()}Ke(e,t){this.Oe=!0,this.Fe=this.Fe.insert(e,t)}Ue(e){this.Oe=!0,this.Fe=this.Fe.remove(e)}$e(){this.ve+=1}We(){this.ve-=1,he(this.ve>=0,3241,{ve:this.ve})}Qe(){this.Oe=!0,this.xe=!0}}class qb{constructor(e){this.Ge=e,this.ze=new Map,this.je=gn(),this.Je=hs(),this.He=hs(),this.Ze=new be(ie)}Xe(e){for(const t of e.be)e.De&&e.De.isFoundDocument()?this.Ye(t,e.De):this.et(t,e.key,e.De);for(const t of e.removedTargetIds)this.et(t,e.key,e.De)}tt(e){this.forEachTarget(e,t=>{const r=this.nt(t);switch(e.state){case 0:this.rt(t)&&r.Le(e.resumeToken);break;case 1:r.We(),r.Ne||r.qe(),r.Le(e.resumeToken);break;case 2:r.We(),r.Ne||this.removeTarget(t);break;case 3:this.rt(t)&&(r.Qe(),r.Le(e.resumeToken));break;case 4:this.rt(t)&&(this.it(t),r.Le(e.resumeToken));break;default:Y(56790,{state:e.state})}})}forEachTarget(e,t){e.targetIds.length>0?e.targetIds.forEach(t):this.ze.forEach((r,i)=>{this.rt(i)&&t(i)})}st(e){const t=e.targetId,r=e.Ce.count,i=this.ot(t);if(i){const o=i.target;if(kl(o))if(r===0){const s=new G(o.path);this.et(t,s,Qe.newNoDocument(s,X.min()))}else he(r===1,20013,{expectedCount:r});else{const s=this._t(t);if(s!==r){const l=this.ut(e),u=l?this.ct(l,e,s):1;if(u!==0){this.it(t);const h=u===2?"TargetPurposeExistenceFilterMismatchBloom":"TargetPurposeExistenceFilterMismatch";this.Ze=this.Ze.insert(t,h)}}}}}ut(e){const t=e.Ce.unchangedNames;if(!t||!t.bits)return null;const{bits:{bitmap:r="",padding:i=0},hashCount:o=0}=t;let s,l;try{s=zn(r).toUint8Array()}catch(u){if(u instanceof hp)return wr("Decoding the base64 bloom filter in existence filter failed ("+u.message+"); ignoring the bloom filter and falling back to full re-query."),null;throw u}try{l=new vc(s,i,o)}catch(u){return wr(u instanceof eo?"BloomFilter error: ":"Applying bloom filter failed: ",u),null}return l.ge===0?null:l}ct(e,t,r){return t.Ce.count===r-this.Pt(e,t.targetId)?0:2}Pt(e,t){const r=this.Ge.getRemoteKeysForTarget(t);let i=0;return r.forEach(o=>{const s=this.Ge.ht(),l=`projects/${s.projectId}/databases/${s.database}/documents/${o.path.canonicalString()}`;e.mightContain(l)||(this.et(t,o,null),i++)}),i}Tt(e){const t=new Map;this.ze.forEach((o,s)=>{const l=this.ot(s);if(l){if(o.current&&kl(l.target)){const u=new G(l.target.path);this.Et(u).has(s)||this.It(s,u)||this.et(s,u,Qe.newNoDocument(u,e))}o.Be&&(t.set(s,o.ke()),o.qe())}});let r=oe();this.He.forEach((o,s)=>{let l=!0;s.forEachWhile(u=>{const h=this.ot(u);return!h||h.purpose==="TargetPurposeLimboResolution"||(l=!1,!1)}),l&&(r=r.add(o))}),this.je.forEach((o,s)=>s.setReadTime(e));const i=new ba(e,t,this.Ze,this.je,r);return this.je=gn(),this.Je=hs(),this.He=hs(),this.Ze=new be(ie),i}Ye(e,t){if(!this.rt(e))return;const r=this.It(e,t.key)?2:0;this.nt(e).Ke(t.key,r),this.je=this.je.insert(t.key,t),this.Je=this.Je.insert(t.key,this.Et(t.key).add(e)),this.He=this.He.insert(t.key,this.Rt(t.key).add(e))}et(e,t,r){if(!this.rt(e))return;const i=this.nt(e);this.It(e,t)?i.Ke(t,1):i.Ue(t),this.He=this.He.insert(t,this.Rt(t).delete(e)),this.He=this.He.insert(t,this.Rt(t).add(e)),r&&(this.je=this.je.insert(t,r))}removeTarget(e){this.ze.delete(e)}_t(e){const t=this.nt(e).ke();return this.Ge.getRemoteKeysForTarget(e).size+t.addedDocuments.size-t.removedDocuments.size}$e(e){this.nt(e).$e()}nt(e){let t=this.ze.get(e);return t||(t=new ad,this.ze.set(e,t)),t}Rt(e){let t=this.He.get(e);return t||(t=new Ue(ie),this.He=this.He.insert(e,t)),t}Et(e){let t=this.Je.get(e);return t||(t=new Ue(ie),this.Je=this.Je.insert(e,t)),t}rt(e){const t=this.ot(e)!==null;return t||j("WatchChangeAggregator","Detected inactive target",e),t}ot(e){const t=this.ze.get(e);return t&&t.Ne?null:this.Ge.At(e)}it(e){this.ze.set(e,new ad),this.Ge.getRemoteKeysForTarget(e).forEach(t=>{this.et(e,t,null)})}It(e,t){return this.Ge.getRemoteKeysForTarget(e).has(t)}}function hs(){return new be(G.comparator)}function ld(){return new be(G.comparator)}const Bb={asc:"ASCENDING",desc:"DESCENDING"},$b={"<":"LESS_THAN","<=":"LESS_THAN_OR_EQUAL",">":"GREATER_THAN",">=":"GREATER_THAN_OR_EQUAL","==":"EQUAL","!=":"NOT_EQUAL","array-contains":"ARRAY_CONTAINS",in:"IN","not-in":"NOT_IN","array-contains-any":"ARRAY_CONTAINS_ANY"},jb={and:"AND",or:"OR"};class zb{constructor(e,t){this.databaseId=e,this.useProto3Json=t}}function Cl(n,e){return n.useProto3Json||pa(e)?e:{value:e}}function Ks(n,e){return n.useProto3Json?`${new Date(1e3*e.seconds).toISOString().replace(/\.\d*/,"").replace("Z","")}.${("000000000"+e.nanoseconds).slice(-9)}Z`:{seconds:""+e.seconds,nanos:e.nanoseconds}}function jp(n,e){return n.useProto3Json?e.toBase64():e.toUint8Array()}function Wb(n,e){return Ks(n,e.toTimestamp())}function jt(n){return he(!!n,49232),X.fromTimestamp(function(t){const r=jn(t);return new me(r.seconds,r.nanos)}(n))}function _c(n,e){return Rl(n,e).canonicalString()}function Rl(n,e){const t=function(i){return new pe(["projects",i.projectId,"databases",i.database])}(n).child("documents");return e===void 0?t:t.child(e)}function zp(n){const e=pe.fromString(n);return he(Yp(e),10190,{key:e.toString()}),e}function Ol(n,e){return _c(n.databaseId,e.path)}function nl(n,e){const t=zp(e);if(t.get(1)!==n.databaseId.projectId)throw new B(D.INVALID_ARGUMENT,"Tried to deserialize key from different project: "+t.get(1)+" vs "+n.databaseId.projectId);if(t.get(3)!==n.databaseId.database)throw new B(D.INVALID_ARGUMENT,"Tried to deserialize key from different database: "+t.get(3)+" vs "+n.databaseId.database);return new G(Hp(t))}function Wp(n,e){return _c(n.databaseId,e)}function Hb(n){const e=zp(n);return e.length===4?pe.emptyPath():Hp(e)}function Nl(n){return new pe(["projects",n.databaseId.projectId,"databases",n.databaseId.database]).canonicalString()}function Hp(n){return he(n.length>4&&n.get(4)==="documents",29091,{key:n.toString()}),n.popFirst(5)}function cd(n,e,t){return{name:Ol(n,e),fields:t.value.mapValue.fields}}function Gb(n,e){let t;if("targetChange"in e){e.targetChange;const r=function(h){return h==="NO_CHANGE"?0:h==="ADD"?1:h==="REMOVE"?2:h==="CURRENT"?3:h==="RESET"?4:Y(39313,{state:h})}(e.targetChange.targetChangeType||"NO_CHANGE"),i=e.targetChange.targetIds||[],o=function(h,p){return h.useProto3Json?(he(p===void 0||typeof p=="string",58123),He.fromBase64String(p||"")):(he(p===void 0||p instanceof Buffer||p instanceof Uint8Array,16193),He.fromUint8Array(p||new Uint8Array))}(n,e.targetChange.resumeToken),s=e.targetChange.cause,l=s&&function(h){const p=h.code===void 0?D.UNKNOWN:qp(h.code);return new B(p,h.message||"")}(s);t=new $p(r,i,o,l||null)}else if("documentChange"in e){e.documentChange;const r=e.documentChange;r.document,r.document.name,r.document.updateTime;const i=nl(n,r.document.name),o=jt(r.document.updateTime),s=r.document.createTime?jt(r.document.createTime):X.min(),l=new ut({mapValue:{fields:r.document.fields}}),u=Qe.newFoundDocument(i,o,s,l),h=r.targetIds||[],p=r.removedTargetIds||[];t=new Ps(h,p,u.key,u)}else if("documentDelete"in e){e.documentDelete;const r=e.documentDelete;r.document;const i=nl(n,r.document),o=r.readTime?jt(r.readTime):X.min(),s=Qe.newNoDocument(i,o),l=r.removedTargetIds||[];t=new Ps([],l,s.key,s)}else if("documentRemove"in e){e.documentRemove;const r=e.documentRemove;r.document;const i=nl(n,r.document),o=r.removedTargetIds||[];t=new Ps([],o,i,null)}else{if(!("filter"in e))return Y(11601,{Vt:e});{e.filter;const r=e.filter;r.targetId;const{count:i=0,unchangedNames:o}=r,s=new Lb(i,o),l=r.targetId;t=new Bp(l,s)}}return t}function Kb(n,e){let t;if(e instanceof $o)t={update:cd(n,e.key,e.value)};else if(e instanceof mc)t={delete:Ol(n,e.key)};else if(e instanceof Qn)t={update:cd(n,e.key,e.data),updateMask:rT(e.fieldMask)};else{if(!(e instanceof Nb))return Y(16599,{dt:e.type});t={verify:Ol(n,e.key)}}return e.fieldTransforms.length>0&&(t.updateTransforms=e.fieldTransforms.map(r=>function(o,s){const l=s.transform;if(l instanceof Eo)return{fieldPath:s.field.canonicalString(),setToServerValue:"REQUEST_TIME"};if(l instanceof Io)return{fieldPath:s.field.canonicalString(),appendMissingElements:{values:l.elements}};if(l instanceof Ao)return{fieldPath:s.field.canonicalString(),removeAllFromArray:{values:l.elements}};if(l instanceof So)return{fieldPath:s.field.canonicalString(),increment:l.Ae};throw Y(20930,{transform:s.transform})}(0,r))),e.precondition.isNone||(t.currentDocument=function(i,o){return o.updateTime!==void 0?{updateTime:Wb(i,o.updateTime)}:o.exists!==void 0?{exists:o.exists}:Y(27497)}(n,e.precondition)),t}function Yb(n,e){return n&&n.length>0?(he(e!==void 0,14353),n.map(t=>function(i,o){let s=i.updateTime?jt(i.updateTime):jt(o);return s.isEqual(X.min())&&(s=jt(o)),new Cb(s,i.transformResults||[])}(t,e))):[]}function Qb(n,e){return{documents:[Wp(n,e.path)]}}function Xb(n,e){const t={structuredQuery:{}},r=e.path;let i;e.collectionGroup!==null?(i=r,t.structuredQuery.from=[{collectionId:e.collectionGroup,allDescendants:!0}]):(i=r.popLast(),t.structuredQuery.from=[{collectionId:r.lastSegment()}]),t.parent=Wp(n,i);const o=function(h){if(h.length!==0)return Kp(Ct.create(h,"and"))}(e.filters);o&&(t.structuredQuery.where=o);const s=function(h){if(h.length!==0)return h.map(p=>function(g){return{field:jr(g.field),direction:eT(g.dir)}}(p))}(e.orderBy);s&&(t.structuredQuery.orderBy=s);const l=Cl(n,e.limit);return l!==null&&(t.structuredQuery.limit=l),e.startAt&&(t.structuredQuery.startAt=function(h){return{before:h.inclusive,values:h.position}}(e.startAt)),e.endAt&&(t.structuredQuery.endAt=function(h){return{before:!h.inclusive,values:h.position}}(e.endAt)),{ft:t,parent:i}}function Jb(n){let e=Hb(n.parent);const t=n.structuredQuery,r=t.from?t.from.length:0;let i=null;if(r>0){he(r===1,65062);const p=t.from[0];p.allDescendants?i=p.collectionId:e=e.child(p.collectionId)}let o=[];t.where&&(o=function(m){const g=Gp(m);return g instanceof Ct&&bp(g)?g.getFilters():[g]}(t.where));let s=[];t.orderBy&&(s=function(m){return m.map(g=>function(P){return new To(zr(P.field),function(O){switch(O){case"ASCENDING":return"asc";case"DESCENDING":return"desc";default:return}}(P.direction))}(g))}(t.orderBy));let l=null;t.limit&&(l=function(m){let g;return g=typeof m=="object"?m.value:m,pa(g)?null:g}(t.limit));let u=null;t.startAt&&(u=function(m){const g=!!m.before,b=m.values||[];return new Hs(b,g)}(t.startAt));let h=null;return t.endAt&&(h=function(m){const g=!m.before,b=m.values||[];return new Hs(b,g)}(t.endAt)),mb(e,i,s,o,l,"F",u,h)}function Zb(n,e){const t=function(i){switch(i){case"TargetPurposeListen":return null;case"TargetPurposeExistenceFilterMismatch":return"existence-filter-mismatch";case"TargetPurposeExistenceFilterMismatchBloom":return"existence-filter-mismatch-bloom";case"TargetPurposeLimboResolution":return"limbo-document";default:return Y(28987,{purpose:i})}}(e.purpose);return t==null?null:{"goog-listen-tags":t}}function Gp(n){return n.unaryFilter!==void 0?function(t){switch(t.unaryFilter.op){case"IS_NAN":const r=zr(t.unaryFilter.field);return Ce.create(r,"==",{doubleValue:NaN});case"IS_NULL":const i=zr(t.unaryFilter.field);return Ce.create(i,"==",{nullValue:"NULL_VALUE"});case"IS_NOT_NAN":const o=zr(t.unaryFilter.field);return Ce.create(o,"!=",{doubleValue:NaN});case"IS_NOT_NULL":const s=zr(t.unaryFilter.field);return Ce.create(s,"!=",{nullValue:"NULL_VALUE"});case"OPERATOR_UNSPECIFIED":return Y(61313);default:return Y(60726)}}(n):n.fieldFilter!==void 0?function(t){return Ce.create(zr(t.fieldFilter.field),function(i){switch(i){case"EQUAL":return"==";case"NOT_EQUAL":return"!=";case"GREATER_THAN":return">";case"GREATER_THAN_OR_EQUAL":return">=";case"LESS_THAN":return"<";case"LESS_THAN_OR_EQUAL":return"<=";case"ARRAY_CONTAINS":return"array-contains";case"IN":return"in";case"NOT_IN":return"not-in";case"ARRAY_CONTAINS_ANY":return"array-contains-any";case"OPERATOR_UNSPECIFIED":return Y(58110);default:return Y(50506)}}(t.fieldFilter.op),t.fieldFilter.value)}(n):n.compositeFilter!==void 0?function(t){return Ct.create(t.compositeFilter.filters.map(r=>Gp(r)),function(i){switch(i){case"AND":return"and";case"OR":return"or";default:return Y(1026)}}(t.compositeFilter.op))}(n):Y(30097,{filter:n})}function eT(n){return Bb[n]}function tT(n){return $b[n]}function nT(n){return jb[n]}function jr(n){return{fieldPath:n.canonicalString()}}function zr(n){return ze.fromServerFormat(n.fieldPath)}function Kp(n){return n instanceof Ce?function(t){if(t.op==="=="){if(Qh(t.value))return{unaryFilter:{field:jr(t.field),op:"IS_NAN"}};if(Yh(t.value))return{unaryFilter:{field:jr(t.field),op:"IS_NULL"}}}else if(t.op==="!="){if(Qh(t.value))return{unaryFilter:{field:jr(t.field),op:"IS_NOT_NAN"}};if(Yh(t.value))return{unaryFilter:{field:jr(t.field),op:"IS_NOT_NULL"}}}return{fieldFilter:{field:jr(t.field),op:tT(t.op),value:t.value}}}(n):n instanceof Ct?function(t){const r=t.getFilters().map(i=>Kp(i));return r.length===1?r[0]:{compositeFilter:{op:nT(t.op),filters:r}}}(n):Y(54877,{filter:n})}function rT(n){const e=[];return n.fields.forEach(t=>e.push(t.canonicalString())),{fieldPaths:e}}function Yp(n){return n.length>=4&&n.get(0)==="projects"&&n.get(2)==="databases"}function Qp(n){return!!n&&typeof n._toProto=="function"&&n._protoValueType==="ProtoValue"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class On{constructor(e,t,r,i,o=X.min(),s=X.min(),l=He.EMPTY_BYTE_STRING,u=null){this.target=e,this.targetId=t,this.purpose=r,this.sequenceNumber=i,this.snapshotVersion=o,this.lastLimboFreeSnapshotVersion=s,this.resumeToken=l,this.expectedCount=u}withSequenceNumber(e){return new On(this.target,this.targetId,this.purpose,e,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,this.expectedCount)}withResumeToken(e,t){return new On(this.target,this.targetId,this.purpose,this.sequenceNumber,t,this.lastLimboFreeSnapshotVersion,e,null)}withExpectedCount(e){return new On(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,e)}withLastLimboFreeSnapshotVersion(e){return new On(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,e,this.resumeToken,this.expectedCount)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class iT{constructor(e){this.yt=e}}function oT(n){const e=Jb({parent:n.parent,structuredQuery:n.structuredQuery});return n.limitType==="LAST"?Gs(e,e.limit,"L"):e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class sT{constructor(){this.bn=new aT}addToCollectionParentIndex(e,t){return this.bn.add(t),M.resolve()}getCollectionParents(e,t){return M.resolve(this.bn.getEntries(t))}addFieldIndex(e,t){return M.resolve()}deleteFieldIndex(e,t){return M.resolve()}deleteAllFieldIndexes(e){return M.resolve()}createTargetIndexes(e,t){return M.resolve()}getDocumentsMatchingTarget(e,t){return M.resolve(null)}getIndexType(e,t){return M.resolve(0)}getFieldIndexes(e,t){return M.resolve([])}getNextCollectionGroupToUpdate(e){return M.resolve(null)}getMinOffset(e,t){return M.resolve($n.min())}getMinOffsetFromCollectionGroup(e,t){return M.resolve($n.min())}updateCollectionGroup(e,t,r){return M.resolve()}updateIndexEntries(e,t){return M.resolve()}}class aT{constructor(){this.index={}}add(e){const t=e.lastSegment(),r=e.popLast(),i=this.index[t]||new Ue(pe.comparator),o=!i.has(r);return this.index[t]=i.add(r),o}has(e){const t=e.lastSegment(),r=e.popLast(),i=this.index[t];return i&&i.has(r)}getEntries(e){return(this.index[e]||new Ue(pe.comparator)).toArray()}}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ud={didRun:!1,sequenceNumbersCollected:0,targetsRemoved:0,documentsRemoved:0},Xp=41943040;class lt{static withCacheSize(e){return new lt(e,lt.DEFAULT_COLLECTION_PERCENTILE,lt.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT)}constructor(e,t,r){this.cacheSizeCollectionThreshold=e,this.percentileToCollect=t,this.maximumSequenceNumbersToCollect=r}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */lt.DEFAULT_COLLECTION_PERCENTILE=10,lt.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT=1e3,lt.DEFAULT=new lt(Xp,lt.DEFAULT_COLLECTION_PERCENTILE,lt.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT),lt.DISABLED=new lt(-1,0,0);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class pi{constructor(e){this.sr=e}next(){return this.sr+=2,this.sr}static _r(){return new pi(0)}static ar(){return new pi(-1)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const hd="LruGarbageCollector",lT=1048576;function dd([n,e],[t,r]){const i=ie(n,t);return i===0?ie(e,r):i}class cT{constructor(e){this.Pr=e,this.buffer=new Ue(dd),this.Tr=0}Er(){return++this.Tr}Ir(e){const t=[e,this.Er()];if(this.buffer.size<this.Pr)this.buffer=this.buffer.add(t);else{const r=this.buffer.last();dd(t,r)<0&&(this.buffer=this.buffer.delete(r).add(t))}}get maxValue(){return this.buffer.last()[0]}}class uT{constructor(e,t,r){this.garbageCollector=e,this.asyncQueue=t,this.localStore=r,this.Rr=null}start(){this.garbageCollector.params.cacheSizeCollectionThreshold!==-1&&this.Ar(6e4)}stop(){this.Rr&&(this.Rr.cancel(),this.Rr=null)}get started(){return this.Rr!==null}Ar(e){j(hd,`Garbage collection scheduled in ${e}ms`),this.Rr=this.asyncQueue.enqueueAfterDelay("lru_garbage_collection",e,async()=>{this.Rr=null;try{await this.localStore.collectGarbage(this.garbageCollector)}catch(t){Ii(t)?j(hd,"Ignoring IndexedDB error during garbage collection: ",t):await Ei(t)}await this.Ar(3e5)})}}class hT{constructor(e,t){this.Vr=e,this.params=t}calculateTargetCount(e,t){return this.Vr.dr(e).next(r=>Math.floor(t/100*r))}nthSequenceNumber(e,t){if(t===0)return M.resolve(fa.ce);const r=new cT(t);return this.Vr.forEachTarget(e,i=>r.Ir(i.sequenceNumber)).next(()=>this.Vr.mr(e,i=>r.Ir(i))).next(()=>r.maxValue)}removeTargets(e,t,r){return this.Vr.removeTargets(e,t,r)}removeOrphanedDocuments(e,t){return this.Vr.removeOrphanedDocuments(e,t)}collect(e,t){return this.params.cacheSizeCollectionThreshold===-1?(j("LruGarbageCollector","Garbage collection skipped; disabled"),M.resolve(ud)):this.getCacheSize(e).next(r=>r<this.params.cacheSizeCollectionThreshold?(j("LruGarbageCollector",`Garbage collection skipped; Cache size ${r} is lower than threshold ${this.params.cacheSizeCollectionThreshold}`),ud):this.gr(e,t))}getCacheSize(e){return this.Vr.getCacheSize(e)}gr(e,t){let r,i,o,s,l,u,h;const p=Date.now();return this.calculateTargetCount(e,this.params.percentileToCollect).next(m=>(m>this.params.maximumSequenceNumbersToCollect?(j("LruGarbageCollector",`Capping sequence numbers to collect down to the maximum of ${this.params.maximumSequenceNumbersToCollect} from ${m}`),i=this.params.maximumSequenceNumbersToCollect):i=m,s=Date.now(),this.nthSequenceNumber(e,i))).next(m=>(r=m,l=Date.now(),this.removeTargets(e,r,t))).next(m=>(o=m,u=Date.now(),this.removeOrphanedDocuments(e,r))).next(m=>(h=Date.now(),Br()<=re.DEBUG&&j("LruGarbageCollector",`LRU Garbage Collection
	Counted targets in ${s-p}ms
	Determined least recently used ${i} in `+(l-s)+`ms
	Removed ${o} targets in `+(u-l)+`ms
	Removed ${m} documents in `+(h-u)+`ms
Total Duration: ${h-p}ms`),M.resolve({didRun:!0,sequenceNumbersCollected:i,targetsRemoved:o,documentsRemoved:m})))}}function dT(n,e){return new hT(n,e)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fT{constructor(){this.changes=new kr(e=>e.toString(),(e,t)=>e.isEqual(t)),this.changesApplied=!1}addEntry(e){this.assertNotApplied(),this.changes.set(e.key,e)}removeEntry(e,t){this.assertNotApplied(),this.changes.set(e,Qe.newInvalidDocument(e).setReadTime(t))}getEntry(e,t){this.assertNotApplied();const r=this.changes.get(t);return r!==void 0?M.resolve(r):this.getFromCache(e,t)}getEntries(e,t){return this.getAllFromCache(e,t)}apply(e){return this.assertNotApplied(),this.changesApplied=!0,this.applyChanges(e)}assertNotApplied(){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class pT{constructor(e,t){this.overlayedDocument=e,this.mutatedFields=t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class gT{constructor(e,t,r,i){this.remoteDocumentCache=e,this.mutationQueue=t,this.documentOverlayCache=r,this.indexManager=i}getDocument(e,t){let r=null;return this.documentOverlayCache.getOverlay(e,t).next(i=>(r=i,this.remoteDocumentCache.getEntry(e,t))).next(i=>(r!==null&&co(r.mutation,i,mt.empty(),me.now()),i))}getDocuments(e,t){return this.remoteDocumentCache.getEntries(e,t).next(r=>this.getLocalViewOfDocuments(e,r,oe()).next(()=>r))}getLocalViewOfDocuments(e,t,r=oe()){const i=sr();return this.populateOverlays(e,i,t).next(()=>this.computeViews(e,t,i,r).next(o=>{let s=Zi();return o.forEach((l,u)=>{s=s.insert(l,u.overlayedDocument)}),s}))}getOverlayedDocuments(e,t){const r=sr();return this.populateOverlays(e,r,t).next(()=>this.computeViews(e,t,r,oe()))}populateOverlays(e,t,r){const i=[];return r.forEach(o=>{t.has(o)||i.push(o)}),this.documentOverlayCache.getOverlays(e,i).next(o=>{o.forEach((s,l)=>{t.set(s,l)})})}computeViews(e,t,r,i){let o=gn();const s=lo(),l=function(){return lo()}();return t.forEach((u,h)=>{const p=r.get(h.key);i.has(h.key)&&(p===void 0||p.mutation instanceof Qn)?o=o.insert(h.key,h):p!==void 0?(s.set(h.key,p.mutation.getFieldMask()),co(p.mutation,h,p.mutation.getFieldMask(),me.now())):s.set(h.key,mt.empty())}),this.recalculateAndSaveOverlays(e,o).next(u=>(u.forEach((h,p)=>s.set(h,p)),t.forEach((h,p)=>l.set(h,new pT(p,s.get(h)??null))),l))}recalculateAndSaveOverlays(e,t){const r=lo();let i=new be((s,l)=>s-l),o=oe();return this.mutationQueue.getAllMutationBatchesAffectingDocumentKeys(e,t).next(s=>{for(const l of s)l.keys().forEach(u=>{const h=t.get(u);if(h===null)return;let p=r.get(u)||mt.empty();p=l.applyToLocalView(h,p),r.set(u,p);const m=(i.get(l.batchId)||oe()).add(u);i=i.insert(l.batchId,m)})}).next(()=>{const s=[],l=i.getReverseIterator();for(;l.hasNext();){const u=l.getNext(),h=u.key,p=u.value,m=Cp();p.forEach(g=>{if(!o.has(g)){const b=Fp(t.get(g),r.get(g));b!==null&&m.set(g,b),o=o.add(g)}}),s.push(this.documentOverlayCache.saveOverlays(e,h,m))}return M.waitFor(s)}).next(()=>r)}recalculateAndSaveOverlaysForDocumentKeys(e,t){return this.remoteDocumentCache.getEntries(e,t).next(r=>this.recalculateAndSaveOverlays(e,r))}getDocumentsMatchingQuery(e,t,r,i){return yb(t)?this.getDocumentsMatchingDocumentQuery(e,t.path):Ap(t)?this.getDocumentsMatchingCollectionGroupQuery(e,t,r,i):this.getDocumentsMatchingCollectionQuery(e,t,r,i)}getNextDocuments(e,t,r,i){return this.remoteDocumentCache.getAllFromCollectionGroup(e,t,r,i).next(o=>{const s=i-o.size>0?this.documentOverlayCache.getOverlaysForCollectionGroup(e,t,r.largestBatchId,i-o.size):M.resolve(sr());let l=vo,u=o;return s.next(h=>M.forEach(h,(p,m)=>(l<m.largestBatchId&&(l=m.largestBatchId),o.get(p)?M.resolve():this.remoteDocumentCache.getEntry(e,p).next(g=>{u=u.insert(p,g)}))).next(()=>this.populateOverlays(e,h,o)).next(()=>this.computeViews(e,u,h,oe())).next(p=>({batchId:l,changes:Pp(p)})))})}getDocumentsMatchingDocumentQuery(e,t){return this.getDocument(e,new G(t)).next(r=>{let i=Zi();return r.isFoundDocument()&&(i=i.insert(r.key,r)),i})}getDocumentsMatchingCollectionGroupQuery(e,t,r,i){const o=t.collectionGroup;let s=Zi();return this.indexManager.getCollectionParents(e,o).next(l=>M.forEach(l,u=>{const h=function(m,g){return new Ai(g,null,m.explicitOrderBy.slice(),m.filters.slice(),m.limit,m.limitType,m.startAt,m.endAt)}(t,u.child(o));return this.getDocumentsMatchingCollectionQuery(e,h,r,i).next(p=>{p.forEach((m,g)=>{s=s.insert(m,g)})})}).next(()=>s))}getDocumentsMatchingCollectionQuery(e,t,r,i){let o;return this.documentOverlayCache.getOverlaysForCollection(e,t.path,r.largestBatchId).next(s=>(o=s,this.remoteDocumentCache.getDocumentsMatchingQuery(e,t,r,o,i))).next(s=>{o.forEach((u,h)=>{const p=h.getKey();s.get(p)===null&&(s=s.insert(p,Qe.newInvalidDocument(p)))});let l=Zi();return s.forEach((u,h)=>{const p=o.get(u);p!==void 0&&co(p.mutation,h,mt.empty(),me.now()),va(t,h)&&(l=l.insert(u,h))}),l})}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class mT{constructor(e){this.serializer=e,this.Nr=new Map,this.Br=new Map}getBundleMetadata(e,t){return M.resolve(this.Nr.get(t))}saveBundleMetadata(e,t){return this.Nr.set(t.id,function(i){return{id:i.id,version:i.version,createTime:jt(i.createTime)}}(t)),M.resolve()}getNamedQuery(e,t){return M.resolve(this.Br.get(t))}saveNamedQuery(e,t){return this.Br.set(t.name,function(i){return{name:i.name,query:oT(i.bundledQuery),readTime:jt(i.readTime)}}(t)),M.resolve()}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class yT{constructor(){this.overlays=new be(G.comparator),this.Lr=new Map}getOverlay(e,t){return M.resolve(this.overlays.get(t))}getOverlays(e,t){const r=sr();return M.forEach(t,i=>this.getOverlay(e,i).next(o=>{o!==null&&r.set(i,o)})).next(()=>r)}saveOverlays(e,t,r){return r.forEach((i,o)=>{this.St(e,t,o)}),M.resolve()}removeOverlaysForBatchId(e,t,r){const i=this.Lr.get(r);return i!==void 0&&(i.forEach(o=>this.overlays=this.overlays.remove(o)),this.Lr.delete(r)),M.resolve()}getOverlaysForCollection(e,t,r){const i=sr(),o=t.length+1,s=new G(t.child("")),l=this.overlays.getIteratorFrom(s);for(;l.hasNext();){const u=l.getNext().value,h=u.getKey();if(!t.isPrefixOf(h.path))break;h.path.length===o&&u.largestBatchId>r&&i.set(u.getKey(),u)}return M.resolve(i)}getOverlaysForCollectionGroup(e,t,r,i){let o=new be((h,p)=>h-p);const s=this.overlays.getIterator();for(;s.hasNext();){const h=s.getNext().value;if(h.getKey().getCollectionGroup()===t&&h.largestBatchId>r){let p=o.get(h.largestBatchId);p===null&&(p=sr(),o=o.insert(h.largestBatchId,p)),p.set(h.getKey(),h)}}const l=sr(),u=o.getIterator();for(;u.hasNext()&&(u.getNext().value.forEach((h,p)=>l.set(h,p)),!(l.size()>=i)););return M.resolve(l)}St(e,t,r){const i=this.overlays.get(r.key);if(i!==null){const s=this.Lr.get(i.largestBatchId).delete(r.key);this.Lr.set(i.largestBatchId,s)}this.overlays=this.overlays.insert(r.key,new Mb(t,r));let o=this.Lr.get(t);o===void 0&&(o=oe(),this.Lr.set(t,o)),this.Lr.set(t,o.add(r.key))}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class vT{constructor(){this.sessionToken=He.EMPTY_BYTE_STRING}getSessionToken(e){return M.resolve(this.sessionToken)}setSessionToken(e,t){return this.sessionToken=t,M.resolve()}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wc{constructor(){this.kr=new Ue(Be.qr),this.Kr=new Ue(Be.Ur)}isEmpty(){return this.kr.isEmpty()}addReference(e,t){const r=new Be(e,t);this.kr=this.kr.add(r),this.Kr=this.Kr.add(r)}$r(e,t){e.forEach(r=>this.addReference(r,t))}removeReference(e,t){this.Wr(new Be(e,t))}Qr(e,t){e.forEach(r=>this.removeReference(r,t))}Gr(e){const t=new G(new pe([])),r=new Be(t,e),i=new Be(t,e+1),o=[];return this.Kr.forEachInRange([r,i],s=>{this.Wr(s),o.push(s.key)}),o}zr(){this.kr.forEach(e=>this.Wr(e))}Wr(e){this.kr=this.kr.delete(e),this.Kr=this.Kr.delete(e)}jr(e){const t=new G(new pe([])),r=new Be(t,e),i=new Be(t,e+1);let o=oe();return this.Kr.forEachInRange([r,i],s=>{o=o.add(s.key)}),o}containsKey(e){const t=new Be(e,0),r=this.kr.firstAfterOrEqual(t);return r!==null&&e.isEqual(r.key)}}class Be{constructor(e,t){this.key=e,this.Jr=t}static qr(e,t){return G.comparator(e.key,t.key)||ie(e.Jr,t.Jr)}static Ur(e,t){return ie(e.Jr,t.Jr)||G.comparator(e.key,t.key)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _T{constructor(e,t){this.indexManager=e,this.referenceDelegate=t,this.mutationQueue=[],this.Yn=1,this.Hr=new Ue(Be.qr)}checkEmpty(e){return M.resolve(this.mutationQueue.length===0)}addMutationBatch(e,t,r,i){const o=this.Yn;this.Yn++,this.mutationQueue.length>0&&this.mutationQueue[this.mutationQueue.length-1];const s=new Db(o,t,r,i);this.mutationQueue.push(s);for(const l of i)this.Hr=this.Hr.add(new Be(l.key,o)),this.indexManager.addToCollectionParentIndex(e,l.key.path.popLast());return M.resolve(s)}lookupMutationBatch(e,t){return M.resolve(this.Zr(t))}getNextMutationBatchAfterBatchId(e,t){const r=t+1,i=this.Xr(r),o=i<0?0:i;return M.resolve(this.mutationQueue.length>o?this.mutationQueue[o]:null)}getHighestUnacknowledgedBatchId(){return M.resolve(this.mutationQueue.length===0?uc:this.Yn-1)}getAllMutationBatches(e){return M.resolve(this.mutationQueue.slice())}getAllMutationBatchesAffectingDocumentKey(e,t){const r=new Be(t,0),i=new Be(t,Number.POSITIVE_INFINITY),o=[];return this.Hr.forEachInRange([r,i],s=>{const l=this.Zr(s.Jr);o.push(l)}),M.resolve(o)}getAllMutationBatchesAffectingDocumentKeys(e,t){let r=new Ue(ie);return t.forEach(i=>{const o=new Be(i,0),s=new Be(i,Number.POSITIVE_INFINITY);this.Hr.forEachInRange([o,s],l=>{r=r.add(l.Jr)})}),M.resolve(this.Yr(r))}getAllMutationBatchesAffectingQuery(e,t){const r=t.path,i=r.length+1;let o=r;G.isDocumentKey(o)||(o=o.child(""));const s=new Be(new G(o),0);let l=new Ue(ie);return this.Hr.forEachWhile(u=>{const h=u.key.path;return!!r.isPrefixOf(h)&&(h.length===i&&(l=l.add(u.Jr)),!0)},s),M.resolve(this.Yr(l))}Yr(e){const t=[];return e.forEach(r=>{const i=this.Zr(r);i!==null&&t.push(i)}),t}removeMutationBatch(e,t){he(this.ei(t.batchId,"removed")===0,55003),this.mutationQueue.shift();let r=this.Hr;return M.forEach(t.mutations,i=>{const o=new Be(i.key,t.batchId);return r=r.delete(o),this.referenceDelegate.markPotentiallyOrphaned(e,i.key)}).next(()=>{this.Hr=r})}nr(e){}containsKey(e,t){const r=new Be(t,0),i=this.Hr.firstAfterOrEqual(r);return M.resolve(t.isEqual(i&&i.key))}performConsistencyCheck(e){return this.mutationQueue.length,M.resolve()}ei(e,t){return this.Xr(e)}Xr(e){return this.mutationQueue.length===0?0:e-this.mutationQueue[0].batchId}Zr(e){const t=this.Xr(e);return t<0||t>=this.mutationQueue.length?null:this.mutationQueue[t]}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wT{constructor(e){this.ti=e,this.docs=function(){return new be(G.comparator)}(),this.size=0}setIndexManager(e){this.indexManager=e}addEntry(e,t){const r=t.key,i=this.docs.get(r),o=i?i.size:0,s=this.ti(t);return this.docs=this.docs.insert(r,{document:t.mutableCopy(),size:s}),this.size+=s-o,this.indexManager.addToCollectionParentIndex(e,r.path.popLast())}removeEntry(e){const t=this.docs.get(e);t&&(this.docs=this.docs.remove(e),this.size-=t.size)}getEntry(e,t){const r=this.docs.get(t);return M.resolve(r?r.document.mutableCopy():Qe.newInvalidDocument(t))}getEntries(e,t){let r=gn();return t.forEach(i=>{const o=this.docs.get(i);r=r.insert(i,o?o.document.mutableCopy():Qe.newInvalidDocument(i))}),M.resolve(r)}getDocumentsMatchingQuery(e,t,r,i){let o=gn();const s=t.path,l=new G(s.child("__id-9223372036854775808__")),u=this.docs.getIteratorFrom(l);for(;u.hasNext();){const{key:h,value:{document:p}}=u.getNext();if(!s.isPrefixOf(h.path))break;h.path.length>s.length+1||Gw(Hw(p),r)<=0||(i.has(p.key)||va(t,p))&&(o=o.insert(p.key,p.mutableCopy()))}return M.resolve(o)}getAllFromCollectionGroup(e,t,r,i){Y(9500)}ni(e,t){return M.forEach(this.docs,r=>t(r))}newChangeBuffer(e){return new bT(this)}getSize(e){return M.resolve(this.size)}}class bT extends fT{constructor(e){super(),this.Mr=e}applyChanges(e){const t=[];return this.changes.forEach((r,i)=>{i.isValidDocument()?t.push(this.Mr.addEntry(e,i)):this.Mr.removeEntry(r)}),M.waitFor(t)}getFromCache(e,t){return this.Mr.getEntry(e,t)}getAllFromCache(e,t){return this.Mr.getEntries(e,t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class TT{constructor(e){this.persistence=e,this.ri=new kr(t=>fc(t),pc),this.lastRemoteSnapshotVersion=X.min(),this.highestTargetId=0,this.ii=0,this.si=new wc,this.targetCount=0,this.oi=pi._r()}forEachTarget(e,t){return this.ri.forEach((r,i)=>t(i)),M.resolve()}getLastRemoteSnapshotVersion(e){return M.resolve(this.lastRemoteSnapshotVersion)}getHighestSequenceNumber(e){return M.resolve(this.ii)}allocateTargetId(e){return this.highestTargetId=this.oi.next(),M.resolve(this.highestTargetId)}setTargetsMetadata(e,t,r){return r&&(this.lastRemoteSnapshotVersion=r),t>this.ii&&(this.ii=t),M.resolve()}lr(e){this.ri.set(e.target,e);const t=e.targetId;t>this.highestTargetId&&(this.oi=new pi(t),this.highestTargetId=t),e.sequenceNumber>this.ii&&(this.ii=e.sequenceNumber)}addTargetData(e,t){return this.lr(t),this.targetCount+=1,M.resolve()}updateTargetData(e,t){return this.lr(t),M.resolve()}removeTargetData(e,t){return this.ri.delete(t.target),this.si.Gr(t.targetId),this.targetCount-=1,M.resolve()}removeTargets(e,t,r){let i=0;const o=[];return this.ri.forEach((s,l)=>{l.sequenceNumber<=t&&r.get(l.targetId)===null&&(this.ri.delete(s),o.push(this.removeMatchingKeysForTargetId(e,l.targetId)),i++)}),M.waitFor(o).next(()=>i)}getTargetCount(e){return M.resolve(this.targetCount)}getTargetData(e,t){const r=this.ri.get(t)||null;return M.resolve(r)}addMatchingKeys(e,t,r){return this.si.$r(t,r),M.resolve()}removeMatchingKeys(e,t,r){this.si.Qr(t,r);const i=this.persistence.referenceDelegate,o=[];return i&&t.forEach(s=>{o.push(i.markPotentiallyOrphaned(e,s))}),M.waitFor(o)}removeMatchingKeysForTargetId(e,t){return this.si.Gr(t),M.resolve()}getMatchingKeysForTargetId(e,t){const r=this.si.jr(t);return M.resolve(r)}containsKey(e,t){return M.resolve(this.si.containsKey(t))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Jp{constructor(e,t){this._i={},this.overlays={},this.ai=new fa(0),this.ui=!1,this.ui=!0,this.ci=new vT,this.referenceDelegate=e(this),this.li=new TT(this),this.indexManager=new sT,this.remoteDocumentCache=function(i){return new wT(i)}(r=>this.referenceDelegate.hi(r)),this.serializer=new iT(t),this.Pi=new mT(this.serializer)}start(){return Promise.resolve()}shutdown(){return this.ui=!1,Promise.resolve()}get started(){return this.ui}setDatabaseDeletedListener(){}setNetworkEnabled(){}getIndexManager(e){return this.indexManager}getDocumentOverlayCache(e){let t=this.overlays[e.toKey()];return t||(t=new yT,this.overlays[e.toKey()]=t),t}getMutationQueue(e,t){let r=this._i[e.toKey()];return r||(r=new _T(t,this.referenceDelegate),this._i[e.toKey()]=r),r}getGlobalsCache(){return this.ci}getTargetCache(){return this.li}getRemoteDocumentCache(){return this.remoteDocumentCache}getBundleCache(){return this.Pi}runTransaction(e,t,r){j("MemoryPersistence","Starting transaction:",e);const i=new ET(this.ai.next());return this.referenceDelegate.Ti(),r(i).next(o=>this.referenceDelegate.Ei(i).next(()=>o)).toPromise().then(o=>(i.raiseOnCommittedEvent(),o))}Ii(e,t){return M.or(Object.values(this._i).map(r=>()=>r.containsKey(e,t)))}}class ET extends Yw{constructor(e){super(),this.currentSequenceNumber=e}}class bc{constructor(e){this.persistence=e,this.Ri=new wc,this.Ai=null}static Vi(e){return new bc(e)}get di(){if(this.Ai)return this.Ai;throw Y(60996)}addReference(e,t,r){return this.Ri.addReference(r,t),this.di.delete(r.toString()),M.resolve()}removeReference(e,t,r){return this.Ri.removeReference(r,t),this.di.add(r.toString()),M.resolve()}markPotentiallyOrphaned(e,t){return this.di.add(t.toString()),M.resolve()}removeTarget(e,t){this.Ri.Gr(t.targetId).forEach(i=>this.di.add(i.toString()));const r=this.persistence.getTargetCache();return r.getMatchingKeysForTargetId(e,t.targetId).next(i=>{i.forEach(o=>this.di.add(o.toString()))}).next(()=>r.removeTargetData(e,t))}Ti(){this.Ai=new Set}Ei(e){const t=this.persistence.getRemoteDocumentCache().newChangeBuffer();return M.forEach(this.di,r=>{const i=G.fromPath(r);return this.mi(e,i).next(o=>{o||t.removeEntry(i,X.min())})}).next(()=>(this.Ai=null,t.apply(e)))}updateLimboDocument(e,t){return this.mi(e,t).next(r=>{r?this.di.delete(t.toString()):this.di.add(t.toString())})}hi(e){return 0}mi(e,t){return M.or([()=>M.resolve(this.Ri.containsKey(t)),()=>this.persistence.getTargetCache().containsKey(e,t),()=>this.persistence.Ii(e,t)])}}class Ys{constructor(e,t){this.persistence=e,this.fi=new kr(r=>Jw(r.path),(r,i)=>r.isEqual(i)),this.garbageCollector=dT(this,t)}static Vi(e,t){return new Ys(e,t)}Ti(){}Ei(e){return M.resolve()}forEachTarget(e,t){return this.persistence.getTargetCache().forEachTarget(e,t)}dr(e){const t=this.pr(e);return this.persistence.getTargetCache().getTargetCount(e).next(r=>t.next(i=>r+i))}pr(e){let t=0;return this.mr(e,r=>{t++}).next(()=>t)}mr(e,t){return M.forEach(this.fi,(r,i)=>this.wr(e,r,i).next(o=>o?M.resolve():t(i)))}removeTargets(e,t,r){return this.persistence.getTargetCache().removeTargets(e,t,r)}removeOrphanedDocuments(e,t){let r=0;const i=this.persistence.getRemoteDocumentCache(),o=i.newChangeBuffer();return i.ni(e,s=>this.wr(e,s,t).next(l=>{l||(r++,o.removeEntry(s,X.min()))})).next(()=>o.apply(e)).next(()=>r)}markPotentiallyOrphaned(e,t){return this.fi.set(t,e.currentSequenceNumber),M.resolve()}removeTarget(e,t){const r=t.withSequenceNumber(e.currentSequenceNumber);return this.persistence.getTargetCache().updateTargetData(e,r)}addReference(e,t,r){return this.fi.set(r,e.currentSequenceNumber),M.resolve()}removeReference(e,t,r){return this.fi.set(r,e.currentSequenceNumber),M.resolve()}updateLimboDocument(e,t){return this.fi.set(t,e.currentSequenceNumber),M.resolve()}hi(e){let t=e.key.toString().length;return e.isFoundDocument()&&(t+=Ss(e.data.value)),t}wr(e,t,r){return M.or([()=>this.persistence.Ii(e,t),()=>this.persistence.getTargetCache().containsKey(e,t),()=>{const i=this.fi.get(t);return M.resolve(i!==void 0&&i>r)}])}getCacheSize(e){return this.persistence.getRemoteDocumentCache().getSize(e)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Tc{constructor(e,t,r,i){this.targetId=e,this.fromCache=t,this.Ts=r,this.Es=i}static Is(e,t){let r=oe(),i=oe();for(const o of t.docChanges)switch(o.type){case 0:r=r.add(o.doc.key);break;case 1:i=i.add(o.doc.key)}return new Tc(e,t.fromCache,r,i)}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class IT{constructor(){this._documentReadCount=0}get documentReadCount(){return this._documentReadCount}incrementDocumentReadCount(e){this._documentReadCount+=e}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class AT{constructor(){this.Rs=!1,this.As=!1,this.Vs=100,this.ds=function(){return dy()?8:Qw(Xe())>0?6:4}()}initialize(e,t){this.fs=e,this.indexManager=t,this.Rs=!0}getDocumentsMatchingQuery(e,t,r,i){const o={result:null};return this.gs(e,t).next(s=>{o.result=s}).next(()=>{if(!o.result)return this.ps(e,t,i,r).next(s=>{o.result=s})}).next(()=>{if(o.result)return;const s=new IT;return this.ys(e,t,s).next(l=>{if(o.result=l,this.As)return this.ws(e,t,s,l.size)})}).next(()=>o.result)}ws(e,t,r,i){return r.documentReadCount<this.Vs?(Br()<=re.DEBUG&&j("QueryEngine","SDK will not create cache indexes for query:",$r(t),"since it only creates cache indexes for collection contains","more than or equal to",this.Vs,"documents"),M.resolve()):(Br()<=re.DEBUG&&j("QueryEngine","Query:",$r(t),"scans",r.documentReadCount,"local documents and returns",i,"documents as results."),r.documentReadCount>this.ds*i?(Br()<=re.DEBUG&&j("QueryEngine","The SDK decides to create cache indexes for query:",$r(t),"as using cache indexes may help improve performance."),this.indexManager.createTargetIndexes(e,$t(t))):M.resolve())}gs(e,t){if(ed(t))return M.resolve(null);let r=$t(t);return this.indexManager.getIndexType(e,r).next(i=>i===0?null:(t.limit!==null&&i===1&&(t=Gs(t,null,"F"),r=$t(t)),this.indexManager.getDocumentsMatchingTarget(e,r).next(o=>{const s=oe(...o);return this.fs.getDocuments(e,s).next(l=>this.indexManager.getMinOffset(e,r).next(u=>{const h=this.Ss(t,l);return this.bs(t,h,s,u.readTime)?this.gs(e,Gs(t,null,"F")):this.Ds(e,h,t,u)}))})))}ps(e,t,r,i){return ed(t)||i.isEqual(X.min())?M.resolve(null):this.fs.getDocuments(e,r).next(o=>{const s=this.Ss(t,o);return this.bs(t,s,r,i)?M.resolve(null):(Br()<=re.DEBUG&&j("QueryEngine","Re-using previous result from %s to execute query: %s",i.toString(),$r(t)),this.Ds(e,s,t,Ww(i,vo)).next(l=>l))})}Ss(e,t){let r=new Ue(xp(e));return t.forEach((i,o)=>{va(e,o)&&(r=r.add(o))}),r}bs(e,t,r,i){if(e.limit===null)return!1;if(r.size!==t.size)return!0;const o=e.limitType==="F"?t.last():t.first();return!!o&&(o.hasPendingWrites||o.version.compareTo(i)>0)}ys(e,t,r){return Br()<=re.DEBUG&&j("QueryEngine","Using full collection scan to execute query:",$r(t)),this.fs.getDocumentsMatchingQuery(e,t,$n.min(),r)}Ds(e,t,r,i){return this.fs.getDocumentsMatchingQuery(e,r,i).next(o=>(t.forEach(s=>{o=o.insert(s.key,s)}),o))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ec="LocalStore",ST=3e8;class xT{constructor(e,t,r,i){this.persistence=e,this.Cs=t,this.serializer=i,this.vs=new be(ie),this.Fs=new kr(o=>fc(o),pc),this.Ms=new Map,this.xs=e.getRemoteDocumentCache(),this.li=e.getTargetCache(),this.Pi=e.getBundleCache(),this.Os(r)}Os(e){this.documentOverlayCache=this.persistence.getDocumentOverlayCache(e),this.indexManager=this.persistence.getIndexManager(e),this.mutationQueue=this.persistence.getMutationQueue(e,this.indexManager),this.localDocuments=new gT(this.xs,this.mutationQueue,this.documentOverlayCache,this.indexManager),this.xs.setIndexManager(this.indexManager),this.Cs.initialize(this.localDocuments,this.indexManager)}collectGarbage(e){return this.persistence.runTransaction("Collect garbage","readwrite-primary",t=>e.collect(t,this.vs))}}function kT(n,e,t,r){return new xT(n,e,t,r)}async function Zp(n,e){const t=J(n);return await t.persistence.runTransaction("Handle user change","readonly",r=>{let i;return t.mutationQueue.getAllMutationBatches(r).next(o=>(i=o,t.Os(e),t.mutationQueue.getAllMutationBatches(r))).next(o=>{const s=[],l=[];let u=oe();for(const h of i){s.push(h.batchId);for(const p of h.mutations)u=u.add(p.key)}for(const h of o){l.push(h.batchId);for(const p of h.mutations)u=u.add(p.key)}return t.localDocuments.getDocuments(r,u).next(h=>({Ns:h,removedBatchIds:s,addedBatchIds:l}))})})}function PT(n,e){const t=J(n);return t.persistence.runTransaction("Acknowledge batch","readwrite-primary",r=>{const i=e.batch.keys(),o=t.xs.newChangeBuffer({trackRemovals:!0});return function(l,u,h,p){const m=h.batch,g=m.keys();let b=M.resolve();return g.forEach(P=>{b=b.next(()=>p.getEntry(u,P)).next(A=>{const O=h.docVersions.get(P);he(O!==null,48541),A.version.compareTo(O)<0&&(m.applyToRemoteDocument(A,h),A.isValidDocument()&&(A.setReadTime(h.commitVersion),p.addEntry(A)))})}),b.next(()=>l.mutationQueue.removeMutationBatch(u,m))}(t,r,e,o).next(()=>o.apply(r)).next(()=>t.mutationQueue.performConsistencyCheck(r)).next(()=>t.documentOverlayCache.removeOverlaysForBatchId(r,i,e.batch.batchId)).next(()=>t.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(r,function(l){let u=oe();for(let h=0;h<l.mutationResults.length;++h)l.mutationResults[h].transformResults.length>0&&(u=u.add(l.batch.mutations[h].key));return u}(e))).next(()=>t.localDocuments.getDocuments(r,i))})}function eg(n){const e=J(n);return e.persistence.runTransaction("Get last remote snapshot version","readonly",t=>e.li.getLastRemoteSnapshotVersion(t))}function CT(n,e){const t=J(n),r=e.snapshotVersion;let i=t.vs;return t.persistence.runTransaction("Apply remote event","readwrite-primary",o=>{const s=t.xs.newChangeBuffer({trackRemovals:!0});i=t.vs;const l=[];e.targetChanges.forEach((p,m)=>{const g=i.get(m);if(!g)return;l.push(t.li.removeMatchingKeys(o,p.removedDocuments,m).next(()=>t.li.addMatchingKeys(o,p.addedDocuments,m)));let b=g.withSequenceNumber(o.currentSequenceNumber);e.targetMismatches.get(m)!==null?b=b.withResumeToken(He.EMPTY_BYTE_STRING,X.min()).withLastLimboFreeSnapshotVersion(X.min()):p.resumeToken.approximateByteSize()>0&&(b=b.withResumeToken(p.resumeToken,r)),i=i.insert(m,b),function(A,O,F){return A.resumeToken.approximateByteSize()===0||O.snapshotVersion.toMicroseconds()-A.snapshotVersion.toMicroseconds()>=ST?!0:F.addedDocuments.size+F.modifiedDocuments.size+F.removedDocuments.size>0}(g,b,p)&&l.push(t.li.updateTargetData(o,b))});let u=gn(),h=oe();if(e.documentUpdates.forEach(p=>{e.resolvedLimboDocuments.has(p)&&l.push(t.persistence.referenceDelegate.updateLimboDocument(o,p))}),l.push(RT(o,s,e.documentUpdates).next(p=>{u=p.Bs,h=p.Ls})),!r.isEqual(X.min())){const p=t.li.getLastRemoteSnapshotVersion(o).next(m=>t.li.setTargetsMetadata(o,o.currentSequenceNumber,r));l.push(p)}return M.waitFor(l).next(()=>s.apply(o)).next(()=>t.localDocuments.getLocalViewOfDocuments(o,u,h)).next(()=>u)}).then(o=>(t.vs=i,o))}function RT(n,e,t){let r=oe(),i=oe();return t.forEach(o=>r=r.add(o)),e.getEntries(n,r).next(o=>{let s=gn();return t.forEach((l,u)=>{const h=o.get(l);u.isFoundDocument()!==h.isFoundDocument()&&(i=i.add(l)),u.isNoDocument()&&u.version.isEqual(X.min())?(e.removeEntry(l,u.readTime),s=s.insert(l,u)):!h.isValidDocument()||u.version.compareTo(h.version)>0||u.version.compareTo(h.version)===0&&h.hasPendingWrites?(e.addEntry(u),s=s.insert(l,u)):j(Ec,"Ignoring outdated watch update for ",l,". Current version:",h.version," Watch version:",u.version)}),{Bs:s,Ls:i}})}function OT(n,e){const t=J(n);return t.persistence.runTransaction("Get next mutation batch","readonly",r=>(e===void 0&&(e=uc),t.mutationQueue.getNextMutationBatchAfterBatchId(r,e)))}function NT(n,e){const t=J(n);return t.persistence.runTransaction("Allocate target","readwrite",r=>{let i;return t.li.getTargetData(r,e).next(o=>o?(i=o,M.resolve(i)):t.li.allocateTargetId(r).next(s=>(i=new On(e,s,"TargetPurposeListen",r.currentSequenceNumber),t.li.addTargetData(r,i).next(()=>i))))}).then(r=>{const i=t.vs.get(r.targetId);return(i===null||r.snapshotVersion.compareTo(i.snapshotVersion)>0)&&(t.vs=t.vs.insert(r.targetId,r),t.Fs.set(e,r.targetId)),r})}async function Dl(n,e,t){const r=J(n),i=r.vs.get(e),o=t?"readwrite":"readwrite-primary";try{t||await r.persistence.runTransaction("Release target",o,s=>r.persistence.referenceDelegate.removeTarget(s,i))}catch(s){if(!Ii(s))throw s;j(Ec,`Failed to update sequence numbers for target ${e}: ${s}`)}r.vs=r.vs.remove(e),r.Fs.delete(i.target)}function fd(n,e,t){const r=J(n);let i=X.min(),o=oe();return r.persistence.runTransaction("Execute query","readwrite",s=>function(u,h,p){const m=J(u),g=m.Fs.get(p);return g!==void 0?M.resolve(m.vs.get(g)):m.li.getTargetData(h,p)}(r,s,$t(e)).next(l=>{if(l)return i=l.lastLimboFreeSnapshotVersion,r.li.getMatchingKeysForTargetId(s,l.targetId).next(u=>{o=u})}).next(()=>r.Cs.getDocumentsMatchingQuery(s,e,t?i:X.min(),t?o:oe())).next(l=>(DT(r,wb(e),l),{documents:l,ks:o})))}function DT(n,e,t){let r=n.Ms.get(e)||X.min();t.forEach((i,o)=>{o.readTime.compareTo(r)>0&&(r=o.readTime)}),n.Ms.set(e,r)}class pd{constructor(){this.activeTargetIds=Sb()}Qs(e){this.activeTargetIds=this.activeTargetIds.add(e)}Gs(e){this.activeTargetIds=this.activeTargetIds.delete(e)}Ws(){const e={activeTargetIds:this.activeTargetIds.toArray(),updateTimeMs:Date.now()};return JSON.stringify(e)}}class MT{constructor(){this.vo=new pd,this.Fo={},this.onlineStateHandler=null,this.sequenceNumberHandler=null}addPendingMutation(e){}updateMutationState(e,t,r){}addLocalQueryTarget(e,t=!0){return t&&this.vo.Qs(e),this.Fo[e]||"not-current"}updateQueryState(e,t,r){this.Fo[e]=t}removeLocalQueryTarget(e){this.vo.Gs(e)}isLocalQueryTarget(e){return this.vo.activeTargetIds.has(e)}clearQueryState(e){delete this.Fo[e]}getAllActiveQueryTargets(){return this.vo.activeTargetIds}isActiveQueryTarget(e){return this.vo.activeTargetIds.has(e)}start(){return this.vo=new pd,Promise.resolve()}handleUserChange(e,t,r){}setOnlineState(e){}shutdown(){}writeSequenceNumber(e){}notifyBundleLoaded(e){}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class LT{Mo(e){}shutdown(){}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const gd="ConnectivityMonitor";class md{constructor(){this.xo=()=>this.Oo(),this.No=()=>this.Bo(),this.Lo=[],this.ko()}Mo(e){this.Lo.push(e)}shutdown(){window.removeEventListener("online",this.xo),window.removeEventListener("offline",this.No)}ko(){window.addEventListener("online",this.xo),window.addEventListener("offline",this.No)}Oo(){j(gd,"Network connectivity changed: AVAILABLE");for(const e of this.Lo)e(0)}Bo(){j(gd,"Network connectivity changed: UNAVAILABLE");for(const e of this.Lo)e(1)}static v(){return typeof window<"u"&&window.addEventListener!==void 0&&window.removeEventListener!==void 0}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let ds=null;function Ml(){return ds===null?ds=function(){return 268435456+Math.round(2147483648*Math.random())}():ds++,"0x"+ds.toString(16)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const rl="RestConnection",VT={BatchGetDocuments:"batchGet",Commit:"commit",RunQuery:"runQuery",RunAggregationQuery:"runAggregationQuery",ExecutePipeline:"executePipeline"};class FT{get qo(){return!1}constructor(e){this.databaseInfo=e,this.databaseId=e.databaseId;const t=e.ssl?"https":"http",r=encodeURIComponent(this.databaseId.projectId),i=encodeURIComponent(this.databaseId.database);this.Ko=t+"://"+e.host,this.Uo=`projects/${r}/databases/${i}`,this.$o=this.databaseId.database===zs?`project_id=${r}`:`project_id=${r}&database_id=${i}`}Wo(e,t,r,i,o){const s=Ml(),l=this.Qo(e,t.toUriEncodedString());j(rl,`Sending RPC '${e}' ${s}:`,l,r);const u={"google-cloud-resource-prefix":this.Uo,"x-goog-request-params":this.$o};this.Go(u,i,o);const{host:h}=new URL(l),p=Vo(h);return this.zo(e,l,u,r,p).then(m=>(j(rl,`Received RPC '${e}' ${s}: `,m),m),m=>{throw wr(rl,`RPC '${e}' ${s} failed with error: `,m,"url: ",l,"request:",r),m})}jo(e,t,r,i,o,s){return this.Wo(e,t,r,i,o)}Go(e,t,r){e["X-Goog-Api-Client"]=function(){return"gl-js/ fire/"+Ti}(),e["Content-Type"]="text/plain",this.databaseInfo.appId&&(e["X-Firebase-GMPID"]=this.databaseInfo.appId),t&&t.headers.forEach((i,o)=>e[o]=i),r&&r.headers.forEach((i,o)=>e[o]=i)}Qo(e,t){const r=VT[e];let i=`${this.Ko}/v1/${t}:${r}`;return this.databaseInfo.apiKey&&(i=`${i}?key=${encodeURIComponent(this.databaseInfo.apiKey)}`),i}terminate(){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class UT{constructor(e){this.Jo=e.Jo,this.Ho=e.Ho}Zo(e){this.Xo=e}Yo(e){this.e_=e}t_(e){this.n_=e}onMessage(e){this.r_=e}close(){this.Ho()}send(e){this.Jo(e)}i_(){this.Xo()}s_(){this.e_()}o_(e){this.n_(e)}__(e){this.r_(e)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ke="WebChannelConnection",zi=(n,e,t)=>{n.listen(e,r=>{try{t(r)}catch(i){setTimeout(()=>{throw i},0)}})};class Jr extends FT{constructor(e){super(e),this.a_=[],this.forceLongPolling=e.forceLongPolling,this.autoDetectLongPolling=e.autoDetectLongPolling,this.useFetchStreams=e.useFetchStreams,this.longPollingOptions=e.longPollingOptions}static u_(){if(!Jr.c_){const e=rp();zi(e,np.STAT_EVENT,t=>{t.stat===El.PROXY?j(Ke,"STAT_EVENT: detected buffering proxy"):t.stat===El.NOPROXY&&j(Ke,"STAT_EVENT: detected no buffering proxy")}),Jr.c_=!0}}zo(e,t,r,i,o){const s=Ml();return new Promise((l,u)=>{const h=new ep;h.setWithCredentials(!0),h.listenOnce(tp.COMPLETE,()=>{try{switch(h.getLastErrorCode()){case As.NO_ERROR:const m=h.getResponseJson();j(Ke,`XHR for RPC '${e}' ${s} received:`,JSON.stringify(m)),l(m);break;case As.TIMEOUT:j(Ke,`RPC '${e}' ${s} timed out`),u(new B(D.DEADLINE_EXCEEDED,"Request time out"));break;case As.HTTP_ERROR:const g=h.getStatus();if(j(Ke,`RPC '${e}' ${s} failed with status:`,g,"response text:",h.getResponseText()),g>0){let b=h.getResponseJson();Array.isArray(b)&&(b=b[0]);const P=b==null?void 0:b.error;if(P&&P.status&&P.message){const A=function(F){const U=F.toLowerCase().replace(/_/g,"-");return Object.values(D).indexOf(U)>=0?U:D.UNKNOWN}(P.status);u(new B(A,P.message))}else u(new B(D.UNKNOWN,"Server responded with status "+h.getStatus()))}else u(new B(D.UNAVAILABLE,"Connection failed."));break;default:Y(9055,{l_:e,streamId:s,h_:h.getLastErrorCode(),P_:h.getLastError()})}}finally{j(Ke,`RPC '${e}' ${s} completed.`)}});const p=JSON.stringify(i);j(Ke,`RPC '${e}' ${s} sending request:`,i),h.send(t,"POST",p,r,15)})}T_(e,t,r){const i=Ml(),o=[this.Ko,"/","google.firestore.v1.Firestore","/",e,"/channel"],s=this.createWebChannelTransport(),l={httpSessionIdParam:"gsessionid",initMessageHeaders:{},messageUrlParams:{database:`projects/${this.databaseId.projectId}/databases/${this.databaseId.database}`},sendRawJson:!0,supportsCrossDomainXhr:!0,internalChannelParams:{forwardChannelRequestTimeoutMs:6e5},forceLongPolling:this.forceLongPolling,detectBufferingProxy:this.autoDetectLongPolling},u=this.longPollingOptions.timeoutSeconds;u!==void 0&&(l.longPollingTimeout=Math.round(1e3*u)),this.useFetchStreams&&(l.useFetchStreams=!0),this.Go(l.initMessageHeaders,t,r),l.encodeInitMessageHeaders=!0;const h=o.join("");j(Ke,`Creating RPC '${e}' stream ${i}: ${h}`,l);const p=s.createWebChannel(h,l);this.E_(p);let m=!1,g=!1;const b=new UT({Jo:P=>{g?j(Ke,`Not sending because RPC '${e}' stream ${i} is closed:`,P):(m||(j(Ke,`Opening RPC '${e}' stream ${i} transport.`),p.open(),m=!0),j(Ke,`RPC '${e}' stream ${i} sending:`,P),p.send(P))},Ho:()=>p.close()});return zi(p,Ji.EventType.OPEN,()=>{g||(j(Ke,`RPC '${e}' stream ${i} transport opened.`),b.i_())}),zi(p,Ji.EventType.CLOSE,()=>{g||(g=!0,j(Ke,`RPC '${e}' stream ${i} transport closed`),b.o_(),this.I_(p))}),zi(p,Ji.EventType.ERROR,P=>{g||(g=!0,wr(Ke,`RPC '${e}' stream ${i} transport errored. Name:`,P.name,"Message:",P.message),b.o_(new B(D.UNAVAILABLE,"The operation could not be completed")))}),zi(p,Ji.EventType.MESSAGE,P=>{var A;if(!g){const O=P.data[0];he(!!O,16349);const F=O,U=(F==null?void 0:F.error)||((A=F[0])==null?void 0:A.error);if(U){j(Ke,`RPC '${e}' stream ${i} received error:`,U);const V=U.status;let H=function(T){const v=Pe[T];if(v!==void 0)return qp(v)}(V),z=U.message;V==="NOT_FOUND"&&z.includes("database")&&z.includes("does not exist")&&z.includes(this.databaseId.database)&&wr(`Database '${this.databaseId.database}' not found. Please check your project configuration.`),H===void 0&&(H=D.INTERNAL,z="Unknown error status: "+V+" with message "+U.message),g=!0,b.o_(new B(H,z)),p.close()}else j(Ke,`RPC '${e}' stream ${i} received:`,O),b.__(O)}}),Jr.u_(),setTimeout(()=>{b.s_()},0),b}terminate(){this.a_.forEach(e=>e.close()),this.a_=[]}E_(e){this.a_.push(e)}I_(e){this.a_=this.a_.filter(t=>t===e)}Go(e,t,r){super.Go(e,t,r),this.databaseInfo.apiKey&&(e["x-goog-api-key"]=this.databaseInfo.apiKey)}createWebChannelTransport(){return ip()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function qT(n){return new Jr(n)}function il(){return typeof document<"u"?document:null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ta(n){return new zb(n,!0)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */Jr.c_=!1;class tg{constructor(e,t,r=1e3,i=1.5,o=6e4){this.Ci=e,this.timerId=t,this.R_=r,this.A_=i,this.V_=o,this.d_=0,this.m_=null,this.f_=Date.now(),this.reset()}reset(){this.d_=0}g_(){this.d_=this.V_}p_(e){this.cancel();const t=Math.floor(this.d_+this.y_()),r=Math.max(0,Date.now()-this.f_),i=Math.max(0,t-r);i>0&&j("ExponentialBackoff",`Backing off for ${i} ms (base delay: ${this.d_} ms, delay with jitter: ${t} ms, last attempt: ${r} ms ago)`),this.m_=this.Ci.enqueueAfterDelay(this.timerId,i,()=>(this.f_=Date.now(),e())),this.d_*=this.A_,this.d_<this.R_&&(this.d_=this.R_),this.d_>this.V_&&(this.d_=this.V_)}w_(){this.m_!==null&&(this.m_.skipDelay(),this.m_=null)}cancel(){this.m_!==null&&(this.m_.cancel(),this.m_=null)}y_(){return(Math.random()-.5)*this.d_}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const yd="PersistentStream";class ng{constructor(e,t,r,i,o,s,l,u){this.Ci=e,this.S_=r,this.b_=i,this.connection=o,this.authCredentialsProvider=s,this.appCheckCredentialsProvider=l,this.listener=u,this.state=0,this.D_=0,this.C_=null,this.v_=null,this.stream=null,this.F_=0,this.M_=new tg(e,t)}x_(){return this.state===1||this.state===5||this.O_()}O_(){return this.state===2||this.state===3}start(){this.F_=0,this.state!==4?this.auth():this.N_()}async stop(){this.x_()&&await this.close(0)}B_(){this.state=0,this.M_.reset()}L_(){this.O_()&&this.C_===null&&(this.C_=this.Ci.enqueueAfterDelay(this.S_,6e4,()=>this.k_()))}q_(e){this.K_(),this.stream.send(e)}async k_(){if(this.O_())return this.close(0)}K_(){this.C_&&(this.C_.cancel(),this.C_=null)}U_(){this.v_&&(this.v_.cancel(),this.v_=null)}async close(e,t){this.K_(),this.U_(),this.M_.cancel(),this.D_++,e!==4?this.M_.reset():t&&t.code===D.RESOURCE_EXHAUSTED?(pn(t.toString()),pn("Using maximum backoff delay to prevent overloading the backend."),this.M_.g_()):t&&t.code===D.UNAUTHENTICATED&&this.state!==3&&(this.authCredentialsProvider.invalidateToken(),this.appCheckCredentialsProvider.invalidateToken()),this.stream!==null&&(this.W_(),this.stream.close(),this.stream=null),this.state=e,await this.listener.t_(t)}W_(){}auth(){this.state=1;const e=this.Q_(this.D_),t=this.D_;Promise.all([this.authCredentialsProvider.getToken(),this.appCheckCredentialsProvider.getToken()]).then(([r,i])=>{this.D_===t&&this.G_(r,i)},r=>{e(()=>{const i=new B(D.UNKNOWN,"Fetching auth token failed: "+r.message);return this.z_(i)})})}G_(e,t){const r=this.Q_(this.D_);this.stream=this.j_(e,t),this.stream.Zo(()=>{r(()=>this.listener.Zo())}),this.stream.Yo(()=>{r(()=>(this.state=2,this.v_=this.Ci.enqueueAfterDelay(this.b_,1e4,()=>(this.O_()&&(this.state=3),Promise.resolve())),this.listener.Yo()))}),this.stream.t_(i=>{r(()=>this.z_(i))}),this.stream.onMessage(i=>{r(()=>++this.F_==1?this.J_(i):this.onNext(i))})}N_(){this.state=5,this.M_.p_(async()=>{this.state=0,this.start()})}z_(e){return j(yd,`close with error: ${e}`),this.stream=null,this.close(4,e)}Q_(e){return t=>{this.Ci.enqueueAndForget(()=>this.D_===e?t():(j(yd,"stream callback skipped by getCloseGuardedDispatcher."),Promise.resolve()))}}}class BT extends ng{constructor(e,t,r,i,o,s){super(e,"listen_stream_connection_backoff","listen_stream_idle","health_check_timeout",t,r,i,s),this.serializer=o}j_(e,t){return this.connection.T_("Listen",e,t)}J_(e){return this.onNext(e)}onNext(e){this.M_.reset();const t=Gb(this.serializer,e),r=function(o){if(!("targetChange"in o))return X.min();const s=o.targetChange;return s.targetIds&&s.targetIds.length?X.min():s.readTime?jt(s.readTime):X.min()}(e);return this.listener.H_(t,r)}Z_(e){const t={};t.database=Nl(this.serializer),t.addTarget=function(o,s){let l;const u=s.target;if(l=kl(u)?{documents:Qb(o,u)}:{query:Xb(o,u).ft},l.targetId=s.targetId,s.resumeToken.approximateByteSize()>0){l.resumeToken=jp(o,s.resumeToken);const h=Cl(o,s.expectedCount);h!==null&&(l.expectedCount=h)}else if(s.snapshotVersion.compareTo(X.min())>0){l.readTime=Ks(o,s.snapshotVersion.toTimestamp());const h=Cl(o,s.expectedCount);h!==null&&(l.expectedCount=h)}return l}(this.serializer,e);const r=Zb(this.serializer,e);r&&(t.labels=r),this.q_(t)}X_(e){const t={};t.database=Nl(this.serializer),t.removeTarget=e,this.q_(t)}}class $T extends ng{constructor(e,t,r,i,o,s){super(e,"write_stream_connection_backoff","write_stream_idle","health_check_timeout",t,r,i,s),this.serializer=o}get Y_(){return this.F_>0}start(){this.lastStreamToken=void 0,super.start()}W_(){this.Y_&&this.ea([])}j_(e,t){return this.connection.T_("Write",e,t)}J_(e){return he(!!e.streamToken,31322),this.lastStreamToken=e.streamToken,he(!e.writeResults||e.writeResults.length===0,55816),this.listener.ta()}onNext(e){he(!!e.streamToken,12678),this.lastStreamToken=e.streamToken,this.M_.reset();const t=Yb(e.writeResults,e.commitTime),r=jt(e.commitTime);return this.listener.na(r,t)}ra(){const e={};e.database=Nl(this.serializer),this.q_(e)}ea(e){const t={streamToken:this.lastStreamToken,writes:e.map(r=>Kb(this.serializer,r))};this.q_(t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class jT{}class zT extends jT{constructor(e,t,r,i){super(),this.authCredentials=e,this.appCheckCredentials=t,this.connection=r,this.serializer=i,this.ia=!1}sa(){if(this.ia)throw new B(D.FAILED_PRECONDITION,"The client has already been terminated.")}Wo(e,t,r,i){return this.sa(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then(([o,s])=>this.connection.Wo(e,Rl(t,r),i,o,s)).catch(o=>{throw o.name==="FirebaseError"?(o.code===D.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),o):new B(D.UNKNOWN,o.toString())})}jo(e,t,r,i,o){return this.sa(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then(([s,l])=>this.connection.jo(e,Rl(t,r),i,s,l,o)).catch(s=>{throw s.name==="FirebaseError"?(s.code===D.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),s):new B(D.UNKNOWN,s.toString())})}terminate(){this.ia=!0,this.connection.terminate()}}function WT(n,e,t,r){return new zT(n,e,t,r)}class HT{constructor(e,t){this.asyncQueue=e,this.onlineStateHandler=t,this.state="Unknown",this.oa=0,this._a=null,this.aa=!0}ua(){this.oa===0&&(this.ca("Unknown"),this._a=this.asyncQueue.enqueueAfterDelay("online_state_timeout",1e4,()=>(this._a=null,this.la("Backend didn't respond within 10 seconds."),this.ca("Offline"),Promise.resolve())))}ha(e){this.state==="Online"?this.ca("Unknown"):(this.oa++,this.oa>=1&&(this.Pa(),this.la(`Connection failed 1 times. Most recent error: ${e.toString()}`),this.ca("Offline")))}set(e){this.Pa(),this.oa=0,e==="Online"&&(this.aa=!1),this.ca(e)}ca(e){e!==this.state&&(this.state=e,this.onlineStateHandler(e))}la(e){const t=`Could not reach Cloud Firestore backend. ${e}
This typically indicates that your device does not have a healthy Internet connection at the moment. The client will operate in offline mode until it is able to successfully connect to the backend.`;this.aa?(pn(t),this.aa=!1):j("OnlineStateTracker",t)}Pa(){this._a!==null&&(this._a.cancel(),this._a=null)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const br="RemoteStore";class GT{constructor(e,t,r,i,o){this.localStore=e,this.datastore=t,this.asyncQueue=r,this.remoteSyncer={},this.Ta=[],this.Ea=new Map,this.Ia=new Set,this.Ra=[],this.Aa=o,this.Aa.Mo(s=>{r.enqueueAndForget(async()=>{Pr(this)&&(j(br,"Restarting streams for network reachability change."),await async function(u){const h=J(u);h.Ia.add(4),await zo(h),h.Va.set("Unknown"),h.Ia.delete(4),await Ea(h)}(this))})}),this.Va=new HT(r,i)}}async function Ea(n){if(Pr(n))for(const e of n.Ra)await e(!0)}async function zo(n){for(const e of n.Ra)await e(!1)}function rg(n,e){const t=J(n);t.Ea.has(e.targetId)||(t.Ea.set(e.targetId,e),xc(t)?Sc(t):Si(t).O_()&&Ac(t,e))}function Ic(n,e){const t=J(n),r=Si(t);t.Ea.delete(e),r.O_()&&ig(t,e),t.Ea.size===0&&(r.O_()?r.L_():Pr(t)&&t.Va.set("Unknown"))}function Ac(n,e){if(n.da.$e(e.targetId),e.resumeToken.approximateByteSize()>0||e.snapshotVersion.compareTo(X.min())>0){const t=n.remoteSyncer.getRemoteKeysForTarget(e.targetId).size;e=e.withExpectedCount(t)}Si(n).Z_(e)}function ig(n,e){n.da.$e(e),Si(n).X_(e)}function Sc(n){n.da=new qb({getRemoteKeysForTarget:e=>n.remoteSyncer.getRemoteKeysForTarget(e),At:e=>n.Ea.get(e)||null,ht:()=>n.datastore.serializer.databaseId}),Si(n).start(),n.Va.ua()}function xc(n){return Pr(n)&&!Si(n).x_()&&n.Ea.size>0}function Pr(n){return J(n).Ia.size===0}function og(n){n.da=void 0}async function KT(n){n.Va.set("Online")}async function YT(n){n.Ea.forEach((e,t)=>{Ac(n,e)})}async function QT(n,e){og(n),xc(n)?(n.Va.ha(e),Sc(n)):n.Va.set("Unknown")}async function XT(n,e,t){if(n.Va.set("Online"),e instanceof $p&&e.state===2&&e.cause)try{await async function(i,o){const s=o.cause;for(const l of o.targetIds)i.Ea.has(l)&&(await i.remoteSyncer.rejectListen(l,s),i.Ea.delete(l),i.da.removeTarget(l))}(n,e)}catch(r){j(br,"Failed to remove targets %s: %s ",e.targetIds.join(","),r),await Qs(n,r)}else if(e instanceof Ps?n.da.Xe(e):e instanceof Bp?n.da.st(e):n.da.tt(e),!t.isEqual(X.min()))try{const r=await eg(n.localStore);t.compareTo(r)>=0&&await function(o,s){const l=o.da.Tt(s);return l.targetChanges.forEach((u,h)=>{if(u.resumeToken.approximateByteSize()>0){const p=o.Ea.get(h);p&&o.Ea.set(h,p.withResumeToken(u.resumeToken,s))}}),l.targetMismatches.forEach((u,h)=>{const p=o.Ea.get(u);if(!p)return;o.Ea.set(u,p.withResumeToken(He.EMPTY_BYTE_STRING,p.snapshotVersion)),ig(o,u);const m=new On(p.target,u,h,p.sequenceNumber);Ac(o,m)}),o.remoteSyncer.applyRemoteEvent(l)}(n,t)}catch(r){j(br,"Failed to raise snapshot:",r),await Qs(n,r)}}async function Qs(n,e,t){if(!Ii(e))throw e;n.Ia.add(1),await zo(n),n.Va.set("Offline"),t||(t=()=>eg(n.localStore)),n.asyncQueue.enqueueRetryable(async()=>{j(br,"Retrying IndexedDB access"),await t(),n.Ia.delete(1),await Ea(n)})}function sg(n,e){return e().catch(t=>Qs(n,t,e))}async function Ia(n){const e=J(n),t=Hn(e);let r=e.Ta.length>0?e.Ta[e.Ta.length-1].batchId:uc;for(;JT(e);)try{const i=await OT(e.localStore,r);if(i===null){e.Ta.length===0&&t.L_();break}r=i.batchId,ZT(e,i)}catch(i){await Qs(e,i)}ag(e)&&lg(e)}function JT(n){return Pr(n)&&n.Ta.length<10}function ZT(n,e){n.Ta.push(e);const t=Hn(n);t.O_()&&t.Y_&&t.ea(e.mutations)}function ag(n){return Pr(n)&&!Hn(n).x_()&&n.Ta.length>0}function lg(n){Hn(n).start()}async function eE(n){Hn(n).ra()}async function tE(n){const e=Hn(n);for(const t of n.Ta)e.ea(t.mutations)}async function nE(n,e,t){const r=n.Ta.shift(),i=yc.from(r,e,t);await sg(n,()=>n.remoteSyncer.applySuccessfulWrite(i)),await Ia(n)}async function rE(n,e){e&&Hn(n).Y_&&await async function(r,i){if(function(s){return Vb(s)&&s!==D.ABORTED}(i.code)){const o=r.Ta.shift();Hn(r).B_(),await sg(r,()=>r.remoteSyncer.rejectFailedWrite(o.batchId,i)),await Ia(r)}}(n,e),ag(n)&&lg(n)}async function vd(n,e){const t=J(n);t.asyncQueue.verifyOperationInProgress(),j(br,"RemoteStore received new credentials");const r=Pr(t);t.Ia.add(3),await zo(t),r&&t.Va.set("Unknown"),await t.remoteSyncer.handleCredentialChange(e),t.Ia.delete(3),await Ea(t)}async function iE(n,e){const t=J(n);e?(t.Ia.delete(2),await Ea(t)):e||(t.Ia.add(2),await zo(t),t.Va.set("Unknown"))}function Si(n){return n.ma||(n.ma=function(t,r,i){const o=J(t);return o.sa(),new BT(r,o.connection,o.authCredentials,o.appCheckCredentials,o.serializer,i)}(n.datastore,n.asyncQueue,{Zo:KT.bind(null,n),Yo:YT.bind(null,n),t_:QT.bind(null,n),H_:XT.bind(null,n)}),n.Ra.push(async e=>{e?(n.ma.B_(),xc(n)?Sc(n):n.Va.set("Unknown")):(await n.ma.stop(),og(n))})),n.ma}function Hn(n){return n.fa||(n.fa=function(t,r,i){const o=J(t);return o.sa(),new $T(r,o.connection,o.authCredentials,o.appCheckCredentials,o.serializer,i)}(n.datastore,n.asyncQueue,{Zo:()=>Promise.resolve(),Yo:eE.bind(null,n),t_:rE.bind(null,n),ta:tE.bind(null,n),na:nE.bind(null,n)}),n.Ra.push(async e=>{e?(n.fa.B_(),await Ia(n)):(await n.fa.stop(),n.Ta.length>0&&(j(br,`Stopping write stream with ${n.Ta.length} pending writes`),n.Ta=[]))})),n.fa}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class kc{constructor(e,t,r,i,o){this.asyncQueue=e,this.timerId=t,this.targetTimeMs=r,this.op=i,this.removalCallback=o,this.deferred=new an,this.then=this.deferred.promise.then.bind(this.deferred.promise),this.deferred.promise.catch(s=>{})}get promise(){return this.deferred.promise}static createAndSchedule(e,t,r,i,o){const s=Date.now()+r,l=new kc(e,t,s,i,o);return l.start(r),l}start(e){this.timerHandle=setTimeout(()=>this.handleDelayElapsed(),e)}skipDelay(){return this.handleDelayElapsed()}cancel(e){this.timerHandle!==null&&(this.clearTimeout(),this.deferred.reject(new B(D.CANCELLED,"Operation cancelled"+(e?": "+e:""))))}handleDelayElapsed(){this.asyncQueue.enqueueAndForget(()=>this.timerHandle!==null?(this.clearTimeout(),this.op().then(e=>this.deferred.resolve(e))):Promise.resolve())}clearTimeout(){this.timerHandle!==null&&(this.removalCallback(this),clearTimeout(this.timerHandle),this.timerHandle=null)}}function Pc(n,e){if(pn("AsyncQueue",`${e}: ${n}`),Ii(n))return new B(D.UNAVAILABLE,`${e}: ${n}`);throw n}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Zr{static emptySet(e){return new Zr(e.comparator)}constructor(e){this.comparator=e?(t,r)=>e(t,r)||G.comparator(t.key,r.key):(t,r)=>G.comparator(t.key,r.key),this.keyedMap=Zi(),this.sortedSet=new be(this.comparator)}has(e){return this.keyedMap.get(e)!=null}get(e){return this.keyedMap.get(e)}first(){return this.sortedSet.minKey()}last(){return this.sortedSet.maxKey()}isEmpty(){return this.sortedSet.isEmpty()}indexOf(e){const t=this.keyedMap.get(e);return t?this.sortedSet.indexOf(t):-1}get size(){return this.sortedSet.size}forEach(e){this.sortedSet.inorderTraversal((t,r)=>(e(t),!1))}add(e){const t=this.delete(e.key);return t.copy(t.keyedMap.insert(e.key,e),t.sortedSet.insert(e,null))}delete(e){const t=this.get(e);return t?this.copy(this.keyedMap.remove(e),this.sortedSet.remove(t)):this}isEqual(e){if(!(e instanceof Zr)||this.size!==e.size)return!1;const t=this.sortedSet.getIterator(),r=e.sortedSet.getIterator();for(;t.hasNext();){const i=t.getNext().key,o=r.getNext().key;if(!i.isEqual(o))return!1}return!0}toString(){const e=[];return this.forEach(t=>{e.push(t.toString())}),e.length===0?"DocumentSet ()":`DocumentSet (
  `+e.join(`  
`)+`
)`}copy(e,t){const r=new Zr;return r.comparator=this.comparator,r.keyedMap=e,r.sortedSet=t,r}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _d{constructor(){this.ga=new be(G.comparator)}track(e){const t=e.doc.key,r=this.ga.get(t);r?e.type!==0&&r.type===3?this.ga=this.ga.insert(t,e):e.type===3&&r.type!==1?this.ga=this.ga.insert(t,{type:r.type,doc:e.doc}):e.type===2&&r.type===2?this.ga=this.ga.insert(t,{type:2,doc:e.doc}):e.type===2&&r.type===0?this.ga=this.ga.insert(t,{type:0,doc:e.doc}):e.type===1&&r.type===0?this.ga=this.ga.remove(t):e.type===1&&r.type===2?this.ga=this.ga.insert(t,{type:1,doc:r.doc}):e.type===0&&r.type===1?this.ga=this.ga.insert(t,{type:2,doc:e.doc}):Y(63341,{Vt:e,pa:r}):this.ga=this.ga.insert(t,e)}ya(){const e=[];return this.ga.inorderTraversal((t,r)=>{e.push(r)}),e}}class gi{constructor(e,t,r,i,o,s,l,u,h){this.query=e,this.docs=t,this.oldDocs=r,this.docChanges=i,this.mutatedKeys=o,this.fromCache=s,this.syncStateChanged=l,this.excludesMetadataChanges=u,this.hasCachedResults=h}static fromInitialDocuments(e,t,r,i,o){const s=[];return t.forEach(l=>{s.push({type:0,doc:l})}),new gi(e,t,Zr.emptySet(t),s,r,i,!0,!1,o)}get hasPendingWrites(){return!this.mutatedKeys.isEmpty()}isEqual(e){if(!(this.fromCache===e.fromCache&&this.hasCachedResults===e.hasCachedResults&&this.syncStateChanged===e.syncStateChanged&&this.mutatedKeys.isEqual(e.mutatedKeys)&&ya(this.query,e.query)&&this.docs.isEqual(e.docs)&&this.oldDocs.isEqual(e.oldDocs)))return!1;const t=this.docChanges,r=e.docChanges;if(t.length!==r.length)return!1;for(let i=0;i<t.length;i++)if(t[i].type!==r[i].type||!t[i].doc.isEqual(r[i].doc))return!1;return!0}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class oE{constructor(){this.wa=void 0,this.Sa=[]}ba(){return this.Sa.some(e=>e.Da())}}class sE{constructor(){this.queries=wd(),this.onlineState="Unknown",this.Ca=new Set}terminate(){(function(t,r){const i=J(t),o=i.queries;i.queries=wd(),o.forEach((s,l)=>{for(const u of l.Sa)u.onError(r)})})(this,new B(D.ABORTED,"Firestore shutting down"))}}function wd(){return new kr(n=>Sp(n),ya)}async function Cc(n,e){const t=J(n);let r=3;const i=e.query;let o=t.queries.get(i);o?!o.ba()&&e.Da()&&(r=2):(o=new oE,r=e.Da()?0:1);try{switch(r){case 0:o.wa=await t.onListen(i,!0);break;case 1:o.wa=await t.onListen(i,!1);break;case 2:await t.onFirstRemoteStoreListen(i)}}catch(s){const l=Pc(s,`Initialization of query '${$r(e.query)}' failed`);return void e.onError(l)}t.queries.set(i,o),o.Sa.push(e),e.va(t.onlineState),o.wa&&e.Fa(o.wa)&&Oc(t)}async function Rc(n,e){const t=J(n),r=e.query;let i=3;const o=t.queries.get(r);if(o){const s=o.Sa.indexOf(e);s>=0&&(o.Sa.splice(s,1),o.Sa.length===0?i=e.Da()?0:1:!o.ba()&&e.Da()&&(i=2))}switch(i){case 0:return t.queries.delete(r),t.onUnlisten(r,!0);case 1:return t.queries.delete(r),t.onUnlisten(r,!1);case 2:return t.onLastRemoteStoreUnlisten(r);default:return}}function aE(n,e){const t=J(n);let r=!1;for(const i of e){const o=i.query,s=t.queries.get(o);if(s){for(const l of s.Sa)l.Fa(i)&&(r=!0);s.wa=i}}r&&Oc(t)}function lE(n,e,t){const r=J(n),i=r.queries.get(e);if(i)for(const o of i.Sa)o.onError(t);r.queries.delete(e)}function Oc(n){n.Ca.forEach(e=>{e.next()})}var Ll,bd;(bd=Ll||(Ll={})).Ma="default",bd.Cache="cache";class Nc{constructor(e,t,r){this.query=e,this.xa=t,this.Oa=!1,this.Na=null,this.onlineState="Unknown",this.options=r||{}}Fa(e){if(!this.options.includeMetadataChanges){const r=[];for(const i of e.docChanges)i.type!==3&&r.push(i);e=new gi(e.query,e.docs,e.oldDocs,r,e.mutatedKeys,e.fromCache,e.syncStateChanged,!0,e.hasCachedResults)}let t=!1;return this.Oa?this.Ba(e)&&(this.xa.next(e),t=!0):this.La(e,this.onlineState)&&(this.ka(e),t=!0),this.Na=e,t}onError(e){this.xa.error(e)}va(e){this.onlineState=e;let t=!1;return this.Na&&!this.Oa&&this.La(this.Na,e)&&(this.ka(this.Na),t=!0),t}La(e,t){if(!e.fromCache||!this.Da())return!0;const r=t!=="Offline";return(!this.options.qa||!r)&&(!e.docs.isEmpty()||e.hasCachedResults||t==="Offline")}Ba(e){if(e.docChanges.length>0)return!0;const t=this.Na&&this.Na.hasPendingWrites!==e.hasPendingWrites;return!(!e.syncStateChanged&&!t)&&this.options.includeMetadataChanges===!0}ka(e){e=gi.fromInitialDocuments(e.query,e.docs,e.mutatedKeys,e.fromCache,e.hasCachedResults),this.Oa=!0,this.xa.next(e)}Da(){return this.options.source!==Ll.Cache}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class cg{constructor(e){this.key=e}}class ug{constructor(e){this.key=e}}class cE{constructor(e,t){this.query=e,this.Za=t,this.Xa=null,this.hasCachedResults=!1,this.current=!1,this.Ya=oe(),this.mutatedKeys=oe(),this.eu=xp(e),this.tu=new Zr(this.eu)}get nu(){return this.Za}ru(e,t){const r=t?t.iu:new _d,i=t?t.tu:this.tu;let o=t?t.mutatedKeys:this.mutatedKeys,s=i,l=!1;const u=this.query.limitType==="F"&&i.size===this.query.limit?i.last():null,h=this.query.limitType==="L"&&i.size===this.query.limit?i.first():null;if(e.inorderTraversal((p,m)=>{const g=i.get(p),b=va(this.query,m)?m:null,P=!!g&&this.mutatedKeys.has(g.key),A=!!b&&(b.hasLocalMutations||this.mutatedKeys.has(b.key)&&b.hasCommittedMutations);let O=!1;g&&b?g.data.isEqual(b.data)?P!==A&&(r.track({type:3,doc:b}),O=!0):this.su(g,b)||(r.track({type:2,doc:b}),O=!0,(u&&this.eu(b,u)>0||h&&this.eu(b,h)<0)&&(l=!0)):!g&&b?(r.track({type:0,doc:b}),O=!0):g&&!b&&(r.track({type:1,doc:g}),O=!0,(u||h)&&(l=!0)),O&&(b?(s=s.add(b),o=A?o.add(p):o.delete(p)):(s=s.delete(p),o=o.delete(p)))}),this.query.limit!==null)for(;s.size>this.query.limit;){const p=this.query.limitType==="F"?s.last():s.first();s=s.delete(p.key),o=o.delete(p.key),r.track({type:1,doc:p})}return{tu:s,iu:r,bs:l,mutatedKeys:o}}su(e,t){return e.hasLocalMutations&&t.hasCommittedMutations&&!t.hasLocalMutations}applyChanges(e,t,r,i){const o=this.tu;this.tu=e.tu,this.mutatedKeys=e.mutatedKeys;const s=e.iu.ya();s.sort((p,m)=>function(b,P){const A=O=>{switch(O){case 0:return 1;case 2:case 3:return 2;case 1:return 0;default:return Y(20277,{Vt:O})}};return A(b)-A(P)}(p.type,m.type)||this.eu(p.doc,m.doc)),this.ou(r),i=i??!1;const l=t&&!i?this._u():[],u=this.Ya.size===0&&this.current&&!i?1:0,h=u!==this.Xa;return this.Xa=u,s.length!==0||h?{snapshot:new gi(this.query,e.tu,o,s,e.mutatedKeys,u===0,h,!1,!!r&&r.resumeToken.approximateByteSize()>0),au:l}:{au:l}}va(e){return this.current&&e==="Offline"?(this.current=!1,this.applyChanges({tu:this.tu,iu:new _d,mutatedKeys:this.mutatedKeys,bs:!1},!1)):{au:[]}}uu(e){return!this.Za.has(e)&&!!this.tu.has(e)&&!this.tu.get(e).hasLocalMutations}ou(e){e&&(e.addedDocuments.forEach(t=>this.Za=this.Za.add(t)),e.modifiedDocuments.forEach(t=>{}),e.removedDocuments.forEach(t=>this.Za=this.Za.delete(t)),this.current=e.current)}_u(){if(!this.current)return[];const e=this.Ya;this.Ya=oe(),this.tu.forEach(r=>{this.uu(r.key)&&(this.Ya=this.Ya.add(r.key))});const t=[];return e.forEach(r=>{this.Ya.has(r)||t.push(new ug(r))}),this.Ya.forEach(r=>{e.has(r)||t.push(new cg(r))}),t}cu(e){this.Za=e.ks,this.Ya=oe();const t=this.ru(e.documents);return this.applyChanges(t,!0)}lu(){return gi.fromInitialDocuments(this.query,this.tu,this.mutatedKeys,this.Xa===0,this.hasCachedResults)}}const Dc="SyncEngine";class uE{constructor(e,t,r){this.query=e,this.targetId=t,this.view=r}}class hE{constructor(e){this.key=e,this.hu=!1}}class dE{constructor(e,t,r,i,o,s){this.localStore=e,this.remoteStore=t,this.eventManager=r,this.sharedClientState=i,this.currentUser=o,this.maxConcurrentLimboResolutions=s,this.Pu={},this.Tu=new kr(l=>Sp(l),ya),this.Eu=new Map,this.Iu=new Set,this.Ru=new be(G.comparator),this.Au=new Map,this.Vu=new wc,this.du={},this.mu=new Map,this.fu=pi.ar(),this.onlineState="Unknown",this.gu=void 0}get isPrimaryClient(){return this.gu===!0}}async function fE(n,e,t=!0){const r=mg(n);let i;const o=r.Tu.get(e);return o?(r.sharedClientState.addLocalQueryTarget(o.targetId),i=o.view.lu()):i=await hg(r,e,t,!0),i}async function pE(n,e){const t=mg(n);await hg(t,e,!0,!1)}async function hg(n,e,t,r){const i=await NT(n.localStore,$t(e)),o=i.targetId,s=n.sharedClientState.addLocalQueryTarget(o,t);let l;return r&&(l=await gE(n,e,o,s==="current",i.resumeToken)),n.isPrimaryClient&&t&&rg(n.remoteStore,i),l}async function gE(n,e,t,r,i){n.pu=(m,g,b)=>async function(A,O,F,U){let V=O.view.ru(F);V.bs&&(V=await fd(A.localStore,O.query,!1).then(({documents:T})=>O.view.ru(T,V)));const H=U&&U.targetChanges.get(O.targetId),z=U&&U.targetMismatches.get(O.targetId)!=null,K=O.view.applyChanges(V,A.isPrimaryClient,H,z);return Ed(A,O.targetId,K.au),K.snapshot}(n,m,g,b);const o=await fd(n.localStore,e,!0),s=new cE(e,o.ks),l=s.ru(o.documents),u=jo.createSynthesizedTargetChangeForCurrentChange(t,r&&n.onlineState!=="Offline",i),h=s.applyChanges(l,n.isPrimaryClient,u);Ed(n,t,h.au);const p=new uE(e,t,s);return n.Tu.set(e,p),n.Eu.has(t)?n.Eu.get(t).push(e):n.Eu.set(t,[e]),h.snapshot}async function mE(n,e,t){const r=J(n),i=r.Tu.get(e),o=r.Eu.get(i.targetId);if(o.length>1)return r.Eu.set(i.targetId,o.filter(s=>!ya(s,e))),void r.Tu.delete(e);r.isPrimaryClient?(r.sharedClientState.removeLocalQueryTarget(i.targetId),r.sharedClientState.isActiveQueryTarget(i.targetId)||await Dl(r.localStore,i.targetId,!1).then(()=>{r.sharedClientState.clearQueryState(i.targetId),t&&Ic(r.remoteStore,i.targetId),Vl(r,i.targetId)}).catch(Ei)):(Vl(r,i.targetId),await Dl(r.localStore,i.targetId,!0))}async function yE(n,e){const t=J(n),r=t.Tu.get(e),i=t.Eu.get(r.targetId);t.isPrimaryClient&&i.length===1&&(t.sharedClientState.removeLocalQueryTarget(r.targetId),Ic(t.remoteStore,r.targetId))}async function vE(n,e,t){const r=AE(n);try{const i=await function(s,l){const u=J(s),h=me.now(),p=l.reduce((b,P)=>b.add(P.key),oe());let m,g;return u.persistence.runTransaction("Locally write mutations","readwrite",b=>{let P=gn(),A=oe();return u.xs.getEntries(b,p).next(O=>{P=O,P.forEach((F,U)=>{U.isValidDocument()||(A=A.add(F))})}).next(()=>u.localDocuments.getOverlayedDocuments(b,P)).next(O=>{m=O;const F=[];for(const U of l){const V=Ob(U,m.get(U.key).overlayedDocument);V!=null&&F.push(new Qn(U.key,V,vp(V.value.mapValue),At.exists(!0)))}return u.mutationQueue.addMutationBatch(b,h,F,l)}).next(O=>{g=O;const F=O.applyToLocalDocumentSet(m,A);return u.documentOverlayCache.saveOverlays(b,O.batchId,F)})}).then(()=>({batchId:g.batchId,changes:Pp(m)}))}(r.localStore,e);r.sharedClientState.addPendingMutation(i.batchId),function(s,l,u){let h=s.du[s.currentUser.toKey()];h||(h=new be(ie)),h=h.insert(l,u),s.du[s.currentUser.toKey()]=h}(r,i.batchId,t),await Wo(r,i.changes),await Ia(r.remoteStore)}catch(i){const o=Pc(i,"Failed to persist write");t.reject(o)}}async function dg(n,e){const t=J(n);try{const r=await CT(t.localStore,e);e.targetChanges.forEach((i,o)=>{const s=t.Au.get(o);s&&(he(i.addedDocuments.size+i.modifiedDocuments.size+i.removedDocuments.size<=1,22616),i.addedDocuments.size>0?s.hu=!0:i.modifiedDocuments.size>0?he(s.hu,14607):i.removedDocuments.size>0&&(he(s.hu,42227),s.hu=!1))}),await Wo(t,r,e)}catch(r){await Ei(r)}}function Td(n,e,t){const r=J(n);if(r.isPrimaryClient&&t===0||!r.isPrimaryClient&&t===1){const i=[];r.Tu.forEach((o,s)=>{const l=s.view.va(e);l.snapshot&&i.push(l.snapshot)}),function(s,l){const u=J(s);u.onlineState=l;let h=!1;u.queries.forEach((p,m)=>{for(const g of m.Sa)g.va(l)&&(h=!0)}),h&&Oc(u)}(r.eventManager,e),i.length&&r.Pu.H_(i),r.onlineState=e,r.isPrimaryClient&&r.sharedClientState.setOnlineState(e)}}async function _E(n,e,t){const r=J(n);r.sharedClientState.updateQueryState(e,"rejected",t);const i=r.Au.get(e),o=i&&i.key;if(o){let s=new be(G.comparator);s=s.insert(o,Qe.newNoDocument(o,X.min()));const l=oe().add(o),u=new ba(X.min(),new Map,new be(ie),s,l);await dg(r,u),r.Ru=r.Ru.remove(o),r.Au.delete(e),Mc(r)}else await Dl(r.localStore,e,!1).then(()=>Vl(r,e,t)).catch(Ei)}async function wE(n,e){const t=J(n),r=e.batch.batchId;try{const i=await PT(t.localStore,e);pg(t,r,null),fg(t,r),t.sharedClientState.updateMutationState(r,"acknowledged"),await Wo(t,i)}catch(i){await Ei(i)}}async function bE(n,e,t){const r=J(n);try{const i=await function(s,l){const u=J(s);return u.persistence.runTransaction("Reject batch","readwrite-primary",h=>{let p;return u.mutationQueue.lookupMutationBatch(h,l).next(m=>(he(m!==null,37113),p=m.keys(),u.mutationQueue.removeMutationBatch(h,m))).next(()=>u.mutationQueue.performConsistencyCheck(h)).next(()=>u.documentOverlayCache.removeOverlaysForBatchId(h,p,l)).next(()=>u.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(h,p)).next(()=>u.localDocuments.getDocuments(h,p))})}(r.localStore,e);pg(r,e,t),fg(r,e),r.sharedClientState.updateMutationState(e,"rejected",t),await Wo(r,i)}catch(i){await Ei(i)}}function fg(n,e){(n.mu.get(e)||[]).forEach(t=>{t.resolve()}),n.mu.delete(e)}function pg(n,e,t){const r=J(n);let i=r.du[r.currentUser.toKey()];if(i){const o=i.get(e);o&&(t?o.reject(t):o.resolve(),i=i.remove(e)),r.du[r.currentUser.toKey()]=i}}function Vl(n,e,t=null){n.sharedClientState.removeLocalQueryTarget(e);for(const r of n.Eu.get(e))n.Tu.delete(r),t&&n.Pu.yu(r,t);n.Eu.delete(e),n.isPrimaryClient&&n.Vu.Gr(e).forEach(r=>{n.Vu.containsKey(r)||gg(n,r)})}function gg(n,e){n.Iu.delete(e.path.canonicalString());const t=n.Ru.get(e);t!==null&&(Ic(n.remoteStore,t),n.Ru=n.Ru.remove(e),n.Au.delete(t),Mc(n))}function Ed(n,e,t){for(const r of t)r instanceof cg?(n.Vu.addReference(r.key,e),TE(n,r)):r instanceof ug?(j(Dc,"Document no longer in limbo: "+r.key),n.Vu.removeReference(r.key,e),n.Vu.containsKey(r.key)||gg(n,r.key)):Y(19791,{wu:r})}function TE(n,e){const t=e.key,r=t.path.canonicalString();n.Ru.get(t)||n.Iu.has(r)||(j(Dc,"New document in limbo: "+t),n.Iu.add(r),Mc(n))}function Mc(n){for(;n.Iu.size>0&&n.Ru.size<n.maxConcurrentLimboResolutions;){const e=n.Iu.values().next().value;n.Iu.delete(e);const t=new G(pe.fromString(e)),r=n.fu.next();n.Au.set(r,new hE(t)),n.Ru=n.Ru.insert(t,r),rg(n.remoteStore,new On($t(ma(t.path)),r,"TargetPurposeLimboResolution",fa.ce))}}async function Wo(n,e,t){const r=J(n),i=[],o=[],s=[];r.Tu.isEmpty()||(r.Tu.forEach((l,u)=>{s.push(r.pu(u,e,t).then(h=>{var p;if((h||t)&&r.isPrimaryClient){const m=h?!h.fromCache:(p=t==null?void 0:t.targetChanges.get(u.targetId))==null?void 0:p.current;r.sharedClientState.updateQueryState(u.targetId,m?"current":"not-current")}if(h){i.push(h);const m=Tc.Is(u.targetId,h);o.push(m)}}))}),await Promise.all(s),r.Pu.H_(i),await async function(u,h){const p=J(u);try{await p.persistence.runTransaction("notifyLocalViewChanges","readwrite",m=>M.forEach(h,g=>M.forEach(g.Ts,b=>p.persistence.referenceDelegate.addReference(m,g.targetId,b)).next(()=>M.forEach(g.Es,b=>p.persistence.referenceDelegate.removeReference(m,g.targetId,b)))))}catch(m){if(!Ii(m))throw m;j(Ec,"Failed to update sequence numbers: "+m)}for(const m of h){const g=m.targetId;if(!m.fromCache){const b=p.vs.get(g),P=b.snapshotVersion,A=b.withLastLimboFreeSnapshotVersion(P);p.vs=p.vs.insert(g,A)}}}(r.localStore,o))}async function EE(n,e){const t=J(n);if(!t.currentUser.isEqual(e)){j(Dc,"User change. New user:",e.toKey());const r=await Zp(t.localStore,e);t.currentUser=e,function(o,s){o.mu.forEach(l=>{l.forEach(u=>{u.reject(new B(D.CANCELLED,s))})}),o.mu.clear()}(t,"'waitForPendingWrites' promise is rejected due to a user change."),t.sharedClientState.handleUserChange(e,r.removedBatchIds,r.addedBatchIds),await Wo(t,r.Ns)}}function IE(n,e){const t=J(n),r=t.Au.get(e);if(r&&r.hu)return oe().add(r.key);{let i=oe();const o=t.Eu.get(e);if(!o)return i;for(const s of o){const l=t.Tu.get(s);i=i.unionWith(l.view.nu)}return i}}function mg(n){const e=J(n);return e.remoteStore.remoteSyncer.applyRemoteEvent=dg.bind(null,e),e.remoteStore.remoteSyncer.getRemoteKeysForTarget=IE.bind(null,e),e.remoteStore.remoteSyncer.rejectListen=_E.bind(null,e),e.Pu.H_=aE.bind(null,e.eventManager),e.Pu.yu=lE.bind(null,e.eventManager),e}function AE(n){const e=J(n);return e.remoteStore.remoteSyncer.applySuccessfulWrite=wE.bind(null,e),e.remoteStore.remoteSyncer.rejectFailedWrite=bE.bind(null,e),e}class Xs{constructor(){this.kind="memory",this.synchronizeTabs=!1}async initialize(e){this.serializer=Ta(e.databaseInfo.databaseId),this.sharedClientState=this.Du(e),this.persistence=this.Cu(e),await this.persistence.start(),this.localStore=this.vu(e),this.gcScheduler=this.Fu(e,this.localStore),this.indexBackfillerScheduler=this.Mu(e,this.localStore)}Fu(e,t){return null}Mu(e,t){return null}vu(e){return kT(this.persistence,new AT,e.initialUser,this.serializer)}Cu(e){return new Jp(bc.Vi,this.serializer)}Du(e){return new MT}async terminate(){var e,t;(e=this.gcScheduler)==null||e.stop(),(t=this.indexBackfillerScheduler)==null||t.stop(),this.sharedClientState.shutdown(),await this.persistence.shutdown()}}Xs.provider={build:()=>new Xs};class SE extends Xs{constructor(e){super(),this.cacheSizeBytes=e}Fu(e,t){he(this.persistence.referenceDelegate instanceof Ys,46915);const r=this.persistence.referenceDelegate.garbageCollector;return new uT(r,e.asyncQueue,t)}Cu(e){const t=this.cacheSizeBytes!==void 0?lt.withCacheSize(this.cacheSizeBytes):lt.DEFAULT;return new Jp(r=>Ys.Vi(r,t),this.serializer)}}class Fl{async initialize(e,t){this.localStore||(this.localStore=e.localStore,this.sharedClientState=e.sharedClientState,this.datastore=this.createDatastore(t),this.remoteStore=this.createRemoteStore(t),this.eventManager=this.createEventManager(t),this.syncEngine=this.createSyncEngine(t,!e.synchronizeTabs),this.sharedClientState.onlineStateHandler=r=>Td(this.syncEngine,r,1),this.remoteStore.remoteSyncer.handleCredentialChange=EE.bind(null,this.syncEngine),await iE(this.remoteStore,this.syncEngine.isPrimaryClient))}createEventManager(e){return function(){return new sE}()}createDatastore(e){const t=Ta(e.databaseInfo.databaseId),r=qT(e.databaseInfo);return WT(e.authCredentials,e.appCheckCredentials,r,t)}createRemoteStore(e){return function(r,i,o,s,l){return new GT(r,i,o,s,l)}(this.localStore,this.datastore,e.asyncQueue,t=>Td(this.syncEngine,t,0),function(){return md.v()?new md:new LT}())}createSyncEngine(e,t){return function(i,o,s,l,u,h,p){const m=new dE(i,o,s,l,u,h);return p&&(m.gu=!0),m}(this.localStore,this.remoteStore,this.eventManager,this.sharedClientState,e.initialUser,e.maxConcurrentLimboResolutions,t)}async terminate(){var e,t;await async function(i){const o=J(i);j(br,"RemoteStore shutting down."),o.Ia.add(5),await zo(o),o.Aa.shutdown(),o.Va.set("Unknown")}(this.remoteStore),(e=this.datastore)==null||e.terminate(),(t=this.eventManager)==null||t.terminate()}}Fl.provider={build:()=>new Fl};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Lc{constructor(e){this.observer=e,this.muted=!1}next(e){this.muted||this.observer.next&&this.Ou(this.observer.next,e)}error(e){this.muted||(this.observer.error?this.Ou(this.observer.error,e):pn("Uncaught Error in snapshot listener:",e.toString()))}Nu(){this.muted=!0}Ou(e,t){setTimeout(()=>{this.muted||e(t)},0)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Gn="FirestoreClient";class xE{constructor(e,t,r,i,o){this.authCredentials=e,this.appCheckCredentials=t,this.asyncQueue=r,this._databaseInfo=i,this.user=Ye.UNAUTHENTICATED,this.clientId=cc.newId(),this.authCredentialListener=()=>Promise.resolve(),this.appCheckCredentialListener=()=>Promise.resolve(),this._uninitializedComponentsProvider=o,this.authCredentials.start(r,async s=>{j(Gn,"Received user=",s.uid),await this.authCredentialListener(s),this.user=s}),this.appCheckCredentials.start(r,s=>(j(Gn,"Received new app check token=",s),this.appCheckCredentialListener(s,this.user)))}get configuration(){return{asyncQueue:this.asyncQueue,databaseInfo:this._databaseInfo,clientId:this.clientId,authCredentials:this.authCredentials,appCheckCredentials:this.appCheckCredentials,initialUser:this.user,maxConcurrentLimboResolutions:100}}setCredentialChangeListener(e){this.authCredentialListener=e}setAppCheckTokenChangeListener(e){this.appCheckCredentialListener=e}terminate(){this.asyncQueue.enterRestrictedMode();const e=new an;return this.asyncQueue.enqueueAndForgetEvenWhileRestricted(async()=>{try{this._onlineComponents&&await this._onlineComponents.terminate(),this._offlineComponents&&await this._offlineComponents.terminate(),this.authCredentials.shutdown(),this.appCheckCredentials.shutdown(),e.resolve()}catch(t){const r=Pc(t,"Failed to shutdown persistence");e.reject(r)}}),e.promise}}async function ol(n,e){n.asyncQueue.verifyOperationInProgress(),j(Gn,"Initializing OfflineComponentProvider");const t=n.configuration;await e.initialize(t);let r=t.initialUser;n.setCredentialChangeListener(async i=>{r.isEqual(i)||(await Zp(e.localStore,i),r=i)}),e.persistence.setDatabaseDeletedListener(()=>n.terminate()),n._offlineComponents=e}async function Id(n,e){n.asyncQueue.verifyOperationInProgress();const t=await kE(n);j(Gn,"Initializing OnlineComponentProvider"),await e.initialize(t,n.configuration),n.setCredentialChangeListener(r=>vd(e.remoteStore,r)),n.setAppCheckTokenChangeListener((r,i)=>vd(e.remoteStore,i)),n._onlineComponents=e}async function kE(n){if(!n._offlineComponents)if(n._uninitializedComponentsProvider){j(Gn,"Using user provided OfflineComponentProvider");try{await ol(n,n._uninitializedComponentsProvider._offline)}catch(e){const t=e;if(!function(i){return i.name==="FirebaseError"?i.code===D.FAILED_PRECONDITION||i.code===D.UNIMPLEMENTED:!(typeof DOMException<"u"&&i instanceof DOMException)||i.code===22||i.code===20||i.code===11}(t))throw t;wr("Error using user provided cache. Falling back to memory cache: "+t),await ol(n,new Xs)}}else j(Gn,"Using default OfflineComponentProvider"),await ol(n,new SE(void 0));return n._offlineComponents}async function yg(n){return n._onlineComponents||(n._uninitializedComponentsProvider?(j(Gn,"Using user provided OnlineComponentProvider"),await Id(n,n._uninitializedComponentsProvider._online)):(j(Gn,"Using default OnlineComponentProvider"),await Id(n,new Fl))),n._onlineComponents}function PE(n){return yg(n).then(e=>e.syncEngine)}async function Js(n){const e=await yg(n),t=e.eventManager;return t.onListen=fE.bind(null,e.syncEngine),t.onUnlisten=mE.bind(null,e.syncEngine),t.onFirstRemoteStoreListen=pE.bind(null,e.syncEngine),t.onLastRemoteStoreUnlisten=yE.bind(null,e.syncEngine),t}function CE(n,e,t,r){const i=new Lc(r),o=new Nc(e,i,t);return n.asyncQueue.enqueueAndForget(async()=>Cc(await Js(n),o)),()=>{i.Nu(),n.asyncQueue.enqueueAndForget(async()=>Rc(await Js(n),o))}}function RE(n,e,t={}){const r=new an;return n.asyncQueue.enqueueAndForget(async()=>function(o,s,l,u,h){const p=new Lc({next:g=>{p.Nu(),s.enqueueAndForget(()=>Rc(o,m));const b=g.docs.has(l);!b&&g.fromCache?h.reject(new B(D.UNAVAILABLE,"Failed to get document because the client is offline.")):b&&g.fromCache&&u&&u.source==="server"?h.reject(new B(D.UNAVAILABLE,'Failed to get document from server. (However, this document does exist in the local cache. Run again without setting source to "server" to retrieve the cached document.)')):h.resolve(g)},error:g=>h.reject(g)}),m=new Nc(ma(l.path),p,{includeMetadataChanges:!0,qa:!0});return Cc(o,m)}(await Js(n),n.asyncQueue,e,t,r)),r.promise}function OE(n,e,t={}){const r=new an;return n.asyncQueue.enqueueAndForget(async()=>function(o,s,l,u,h){const p=new Lc({next:g=>{p.Nu(),s.enqueueAndForget(()=>Rc(o,m)),g.fromCache&&u.source==="server"?h.reject(new B(D.UNAVAILABLE,'Failed to get documents from server. (However, these documents may exist in the local cache. Run again without setting source to "server" to retrieve the cached documents.)')):h.resolve(g)},error:g=>h.reject(g)}),m=new Nc(l,p,{includeMetadataChanges:!0,qa:!0});return Cc(o,m)}(await Js(n),n.asyncQueue,e,t,r)),r.promise}function NE(n,e){const t=new an;return n.asyncQueue.enqueueAndForget(async()=>vE(await PE(n),e,t)),t.promise}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function vg(n){const e={};return n.timeoutSeconds!==void 0&&(e.timeoutSeconds=n.timeoutSeconds),e}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const DE="ComponentProvider",Ad=new Map;function ME(n,e,t,r,i){return new tb(n,e,t,i.host,i.ssl,i.experimentalForceLongPolling,i.experimentalAutoDetectLongPolling,vg(i.experimentalLongPollingOptions),i.useFetchStreams,i.isUsingEmulator,r)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const _g="firestore.googleapis.com",Sd=!0;class xd{constructor(e){if(e.host===void 0){if(e.ssl!==void 0)throw new B(D.INVALID_ARGUMENT,"Can't provide ssl option if host option is not set");this.host=_g,this.ssl=Sd}else this.host=e.host,this.ssl=e.ssl??Sd;if(this.isUsingEmulator=e.emulatorOptions!==void 0,this.credentials=e.credentials,this.ignoreUndefinedProperties=!!e.ignoreUndefinedProperties,this.localCache=e.localCache,e.cacheSizeBytes===void 0)this.cacheSizeBytes=Xp;else{if(e.cacheSizeBytes!==-1&&e.cacheSizeBytes<lT)throw new B(D.INVALID_ARGUMENT,"cacheSizeBytes must be at least 1048576");this.cacheSizeBytes=e.cacheSizeBytes}jw("experimentalForceLongPolling",e.experimentalForceLongPolling,"experimentalAutoDetectLongPolling",e.experimentalAutoDetectLongPolling),this.experimentalForceLongPolling=!!e.experimentalForceLongPolling,this.experimentalForceLongPolling?this.experimentalAutoDetectLongPolling=!1:e.experimentalAutoDetectLongPolling===void 0?this.experimentalAutoDetectLongPolling=!0:this.experimentalAutoDetectLongPolling=!!e.experimentalAutoDetectLongPolling,this.experimentalLongPollingOptions=vg(e.experimentalLongPollingOptions??{}),function(r){if(r.timeoutSeconds!==void 0){if(isNaN(r.timeoutSeconds))throw new B(D.INVALID_ARGUMENT,`invalid long polling timeout: ${r.timeoutSeconds} (must not be NaN)`);if(r.timeoutSeconds<5)throw new B(D.INVALID_ARGUMENT,`invalid long polling timeout: ${r.timeoutSeconds} (minimum allowed value is 5)`);if(r.timeoutSeconds>30)throw new B(D.INVALID_ARGUMENT,`invalid long polling timeout: ${r.timeoutSeconds} (maximum allowed value is 30)`)}}(this.experimentalLongPollingOptions),this.useFetchStreams=!!e.useFetchStreams}isEqual(e){return this.host===e.host&&this.ssl===e.ssl&&this.credentials===e.credentials&&this.cacheSizeBytes===e.cacheSizeBytes&&this.experimentalForceLongPolling===e.experimentalForceLongPolling&&this.experimentalAutoDetectLongPolling===e.experimentalAutoDetectLongPolling&&function(r,i){return r.timeoutSeconds===i.timeoutSeconds}(this.experimentalLongPollingOptions,e.experimentalLongPollingOptions)&&this.ignoreUndefinedProperties===e.ignoreUndefinedProperties&&this.useFetchStreams===e.useFetchStreams}}class Aa{constructor(e,t,r,i){this._authCredentials=e,this._appCheckCredentials=t,this._databaseId=r,this._app=i,this.type="firestore-lite",this._persistenceKey="(lite)",this._settings=new xd({}),this._settingsFrozen=!1,this._emulatorOptions={},this._terminateTask="notTerminated"}get app(){if(!this._app)throw new B(D.FAILED_PRECONDITION,"Firestore was not initialized using the Firebase SDK. 'app' is not available");return this._app}get _initialized(){return this._settingsFrozen}get _terminated(){return this._terminateTask!=="notTerminated"}_setSettings(e){if(this._settingsFrozen)throw new B(D.FAILED_PRECONDITION,"Firestore has already been started and its settings can no longer be changed. You can only modify settings before calling any other methods on a Firestore object.");this._settings=new xd(e),this._emulatorOptions=e.emulatorOptions||{},e.credentials!==void 0&&(this._authCredentials=function(r){if(!r)return new Nw;switch(r.type){case"firstParty":return new Vw(r.sessionIndex||"0",r.iamToken||null,r.authTokenFactory||null);case"provider":return r.client;default:throw new B(D.INVALID_ARGUMENT,"makeAuthCredentialsProvider failed due to invalid credential type")}}(e.credentials))}_getSettings(){return this._settings}_getEmulatorOptions(){return this._emulatorOptions}_freezeSettings(){return this._settingsFrozen=!0,this._settings}_delete(){return this._terminateTask==="notTerminated"&&(this._terminateTask=this._terminate()),this._terminateTask}async _restart(){this._terminateTask==="notTerminated"?await this._terminate():this._terminateTask="notTerminated"}toJSON(){return{app:this._app,databaseId:this._databaseId,settings:this._settings}}_terminate(){return function(t){const r=Ad.get(t);r&&(j(DE,"Removing Datastore"),Ad.delete(t),r.terminate())}(this),Promise.resolve()}}function LE(n,e,t,r={}){var h;n=yt(n,Aa);const i=Vo(e),o=n._getSettings(),s={...o,emulatorOptions:n._getEmulatorOptions()},l=`${e}:${t}`;i&&pf(`https://${l}`),o.host!==_g&&o.host!==l&&wr("Host has been set in both settings() and connectFirestoreEmulator(), emulator host will be used.");const u={...o,host:l,ssl:i,emulatorOptions:r};if(!mr(u,s)&&(n._setSettings(u),r.mockUserToken)){let p,m;if(typeof r.mockUserToken=="string")p=r.mockUserToken,m=Ye.MOCK_USER;else{p=oy(r.mockUserToken,(h=n._app)==null?void 0:h.options.projectId);const g=r.mockUserToken.sub||r.mockUserToken.user_id;if(!g)throw new B(D.INVALID_ARGUMENT,"mockUserToken must contain 'sub' or 'user_id' field!");m=new Ye(g)}n._authCredentials=new Dw(new sp(p,m))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class vn{constructor(e,t,r){this.converter=t,this._query=r,this.type="query",this.firestore=e}withConverter(e){return new vn(this.firestore,e,this._query)}}class Ee{constructor(e,t,r){this.converter=t,this._key=r,this.type="document",this.firestore=e}get _path(){return this._key.path}get id(){return this._key.path.lastSegment()}get path(){return this._key.path.canonicalString()}get parent(){return new Un(this.firestore,this.converter,this._key.path.popLast())}withConverter(e){return new Ee(this.firestore,e,this._key)}toJSON(){return{type:Ee._jsonSchemaVersion,referencePath:this._key.toString()}}static fromJSON(e,t,r){if(Bo(t,Ee._jsonSchema))return new Ee(e,r||null,new G(pe.fromString(t.referencePath)))}}Ee._jsonSchemaVersion="firestore/documentReference/1.0",Ee._jsonSchema={type:Re("string",Ee._jsonSchemaVersion),referencePath:Re("string")};class Un extends vn{constructor(e,t,r){super(e,t,ma(r)),this._path=r,this.type="collection"}get id(){return this._query.path.lastSegment()}get path(){return this._query.path.canonicalString()}get parent(){const e=this._path.popLast();return e.isEmpty()?null:new Ee(this.firestore,null,new G(e))}withConverter(e){return new Un(this.firestore,e,this._path)}}function Xn(n,e,...t){if(n=$e(n),ap("collection","path",e),n instanceof Aa){const r=pe.fromString(e,...t);return qh(r),new Un(n,null,r)}{if(!(n instanceof Ee||n instanceof Un))throw new B(D.INVALID_ARGUMENT,"Expected first argument to collection() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const r=n._path.child(pe.fromString(e,...t));return qh(r),new Un(n.firestore,null,r)}}function _e(n,e,...t){if(n=$e(n),arguments.length===1&&(e=cc.newId()),ap("doc","path",e),n instanceof Aa){const r=pe.fromString(e,...t);return Uh(r),new Ee(n,null,new G(r))}{if(!(n instanceof Ee||n instanceof Un))throw new B(D.INVALID_ARGUMENT,"Expected first argument to doc() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const r=n._path.child(pe.fromString(e,...t));return Uh(r),new Ee(n.firestore,n instanceof Un?n.converter:null,new G(r))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const kd="AsyncQueue";class Pd{constructor(e=Promise.resolve()){this.Yu=[],this.ec=!1,this.tc=[],this.nc=null,this.rc=!1,this.sc=!1,this.oc=[],this.M_=new tg(this,"async_queue_retry"),this._c=()=>{const r=il();r&&j(kd,"Visibility state changed to "+r.visibilityState),this.M_.w_()},this.ac=e;const t=il();t&&typeof t.addEventListener=="function"&&t.addEventListener("visibilitychange",this._c)}get isShuttingDown(){return this.ec}enqueueAndForget(e){this.enqueue(e)}enqueueAndForgetEvenWhileRestricted(e){this.uc(),this.cc(e)}enterRestrictedMode(e){if(!this.ec){this.ec=!0,this.sc=e||!1;const t=il();t&&typeof t.removeEventListener=="function"&&t.removeEventListener("visibilitychange",this._c)}}enqueue(e){if(this.uc(),this.ec)return new Promise(()=>{});const t=new an;return this.cc(()=>this.ec&&this.sc?Promise.resolve():(e().then(t.resolve,t.reject),t.promise)).then(()=>t.promise)}enqueueRetryable(e){this.enqueueAndForget(()=>(this.Yu.push(e),this.lc()))}async lc(){if(this.Yu.length!==0){try{await this.Yu[0](),this.Yu.shift(),this.M_.reset()}catch(e){if(!Ii(e))throw e;j(kd,"Operation failed with retryable error: "+e)}this.Yu.length>0&&this.M_.p_(()=>this.lc())}}cc(e){const t=this.ac.then(()=>(this.rc=!0,e().catch(r=>{throw this.nc=r,this.rc=!1,pn("INTERNAL UNHANDLED ERROR: ",Cd(r)),r}).then(r=>(this.rc=!1,r))));return this.ac=t,t}enqueueAfterDelay(e,t,r){this.uc(),this.oc.indexOf(e)>-1&&(t=0);const i=kc.createAndSchedule(this,e,t,r,o=>this.hc(o));return this.tc.push(i),i}uc(){this.nc&&Y(47125,{Pc:Cd(this.nc)})}verifyOperationInProgress(){}async Tc(){let e;do e=this.ac,await e;while(e!==this.ac)}Ec(e){for(const t of this.tc)if(t.timerId===e)return!0;return!1}Ic(e){return this.Tc().then(()=>{this.tc.sort((t,r)=>t.targetTimeMs-r.targetTimeMs);for(const t of this.tc)if(t.skipDelay(),e!=="all"&&t.timerId===e)break;return this.Tc()})}Rc(e){this.oc.push(e)}hc(e){const t=this.tc.indexOf(e);this.tc.splice(t,1)}}function Cd(n){let e=n.message||"";return n.stack&&(e=n.stack.includes(n.message)?n.stack:n.message+`
`+n.stack),e}class Kn extends Aa{constructor(e,t,r,i){super(e,t,r,i),this.type="firestore",this._queue=new Pd,this._persistenceKey=(i==null?void 0:i.name)||"[DEFAULT]"}async _terminate(){if(this._firestoreClient){const e=this._firestoreClient.terminate();this._queue=new Pd(e),this._firestoreClient=void 0,await e}}}function VE(n,e){const t=typeof n=="object"?n:yf(),r=typeof n=="string"?n:zs,i=Jl(t,"firestore").getImmediate({identifier:r});if(!i._initialized){const o=ry("firestore");o&&LE(i,...o)}return i}function Sa(n){if(n._terminated)throw new B(D.FAILED_PRECONDITION,"The client has already been terminated.");return n._firestoreClient||FE(n),n._firestoreClient}function FE(n){var r,i,o,s;const e=n._freezeSettings(),t=ME(n._databaseId,((r=n._app)==null?void 0:r.options.appId)||"",n._persistenceKey,(i=n._app)==null?void 0:i.options.apiKey,e);n._componentsProvider||(o=e.localCache)!=null&&o._offlineComponentProvider&&((s=e.localCache)!=null&&s._onlineComponentProvider)&&(n._componentsProvider={_offline:e.localCache._offlineComponentProvider,_online:e.localCache._onlineComponentProvider}),n._firestoreClient=new xE(n._authCredentials,n._appCheckCredentials,n._queue,t,n._componentsProvider&&function(u){const h=u==null?void 0:u._online.build();return{_offline:u==null?void 0:u._offline.build(h),_online:h}}(n._componentsProvider))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _t{constructor(e){this._byteString=e}static fromBase64String(e){try{return new _t(He.fromBase64String(e))}catch(t){throw new B(D.INVALID_ARGUMENT,"Failed to construct data from Base64 string: "+t)}}static fromUint8Array(e){return new _t(He.fromUint8Array(e))}toBase64(){return this._byteString.toBase64()}toUint8Array(){return this._byteString.toUint8Array()}toString(){return"Bytes(base64: "+this.toBase64()+")"}isEqual(e){return this._byteString.isEqual(e._byteString)}toJSON(){return{type:_t._jsonSchemaVersion,bytes:this.toBase64()}}static fromJSON(e){if(Bo(e,_t._jsonSchema))return _t.fromBase64String(e.bytes)}}_t._jsonSchemaVersion="firestore/bytes/1.0",_t._jsonSchema={type:Re("string",_t._jsonSchemaVersion),bytes:Re("string")};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Vc{constructor(...e){for(let t=0;t<e.length;++t)if(e[t].length===0)throw new B(D.INVALID_ARGUMENT,"Invalid field name at argument $(i + 1). Field names must not be empty.");this._internalPath=new ze(e)}isEqual(e){return this._internalPath.isEqual(e._internalPath)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ho{constructor(e){this._methodName=e}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class zt{constructor(e,t){if(!isFinite(e)||e<-90||e>90)throw new B(D.INVALID_ARGUMENT,"Latitude must be a number between -90 and 90, but was: "+e);if(!isFinite(t)||t<-180||t>180)throw new B(D.INVALID_ARGUMENT,"Longitude must be a number between -180 and 180, but was: "+t);this._lat=e,this._long=t}get latitude(){return this._lat}get longitude(){return this._long}isEqual(e){return this._lat===e._lat&&this._long===e._long}_compareTo(e){return ie(this._lat,e._lat)||ie(this._long,e._long)}toJSON(){return{latitude:this._lat,longitude:this._long,type:zt._jsonSchemaVersion}}static fromJSON(e){if(Bo(e,zt._jsonSchema))return new zt(e.latitude,e.longitude)}}zt._jsonSchemaVersion="firestore/geoPoint/1.0",zt._jsonSchema={type:Re("string",zt._jsonSchemaVersion),latitude:Re("number"),longitude:Re("number")};/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class St{constructor(e){this._values=(e||[]).map(t=>t)}toArray(){return this._values.map(e=>e)}isEqual(e){return function(r,i){if(r.length!==i.length)return!1;for(let o=0;o<r.length;++o)if(r[o]!==i[o])return!1;return!0}(this._values,e._values)}toJSON(){return{type:St._jsonSchemaVersion,vectorValues:this._values}}static fromJSON(e){if(Bo(e,St._jsonSchema)){if(Array.isArray(e.vectorValues)&&e.vectorValues.every(t=>typeof t=="number"))return new St(e.vectorValues);throw new B(D.INVALID_ARGUMENT,"Expected 'vectorValues' field to be a number array")}}}St._jsonSchemaVersion="firestore/vectorValue/1.0",St._jsonSchema={type:Re("string",St._jsonSchemaVersion),vectorValues:Re("object")};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const UE=/^__.*__$/;class qE{constructor(e,t,r){this.data=e,this.fieldMask=t,this.fieldTransforms=r}toMutation(e,t){return this.fieldMask!==null?new Qn(e,this.data,this.fieldMask,t,this.fieldTransforms):new $o(e,this.data,t,this.fieldTransforms)}}class wg{constructor(e,t,r){this.data=e,this.fieldMask=t,this.fieldTransforms=r}toMutation(e,t){return new Qn(e,this.data,this.fieldMask,t,this.fieldTransforms)}}function bg(n){switch(n){case 0:case 2:case 1:return!0;case 3:case 4:return!1;default:throw Y(40011,{dataSource:n})}}class Fc{constructor(e,t,r,i,o,s){this.settings=e,this.databaseId=t,this.serializer=r,this.ignoreUndefinedProperties=i,o===void 0&&this.Ac(),this.fieldTransforms=o||[],this.fieldMask=s||[]}get path(){return this.settings.path}get dataSource(){return this.settings.dataSource}i(e){return new Fc({...this.settings,...e},this.databaseId,this.serializer,this.ignoreUndefinedProperties,this.fieldTransforms,this.fieldMask)}dc(e){var i;const t=(i=this.path)==null?void 0:i.child(e),r=this.i({path:t,arrayElement:!1});return r.mc(e),r}fc(e){var i;const t=(i=this.path)==null?void 0:i.child(e),r=this.i({path:t,arrayElement:!1});return r.Ac(),r}gc(e){return this.i({path:void 0,arrayElement:!0})}yc(e){return Zs(e,this.settings.methodName,this.settings.hasConverter||!1,this.path,this.settings.targetDoc)}contains(e){return this.fieldMask.find(t=>e.isPrefixOf(t))!==void 0||this.fieldTransforms.find(t=>e.isPrefixOf(t.field))!==void 0}Ac(){if(this.path)for(let e=0;e<this.path.length;e++)this.mc(this.path.get(e))}mc(e){if(e.length===0)throw this.yc("Document fields must not be empty");if(bg(this.dataSource)&&UE.test(e))throw this.yc('Document fields cannot begin and end with "__"')}}class BE{constructor(e,t,r){this.databaseId=e,this.ignoreUndefinedProperties=t,this.serializer=r||Ta(e)}I(e,t,r,i=!1){return new Fc({dataSource:e,methodName:t,targetDoc:r,path:ze.emptyPath(),arrayElement:!1,hasConverter:i},this.databaseId,this.serializer,this.ignoreUndefinedProperties)}}function Uc(n){const e=n._freezeSettings(),t=Ta(n._databaseId);return new BE(n._databaseId,!!e.ignoreUndefinedProperties,t)}function $E(n,e,t,r,i,o={}){const s=n.I(o.merge||o.mergeFields?2:0,e,t,i);$c("Data must be an object, but it was:",s,r);const l=Tg(r,s);let u,h;if(o.merge)u=new mt(s.fieldMask),h=s.fieldTransforms;else if(o.mergeFields){const p=[];for(const m of o.mergeFields){const g=mi(e,m,t);if(!s.contains(g))throw new B(D.INVALID_ARGUMENT,`Field '${g}' is specified in your field mask but missing from your input data.`);Ag(p,g)||p.push(g)}u=new mt(p),h=s.fieldTransforms.filter(m=>u.covers(m.field))}else u=null,h=s.fieldTransforms;return new qE(new ut(l),u,h)}class xa extends Ho{_toFieldTransform(e){if(e.dataSource!==2)throw e.dataSource===1?e.yc(`${this._methodName}() can only appear at the top level of your update data`):e.yc(`${this._methodName}() cannot be used with set() unless you pass {merge:true}`);return e.fieldMask.push(e.path),null}isEqual(e){return e instanceof xa}}class qc extends Ho{_toFieldTransform(e){return new Vp(e.path,new Eo)}isEqual(e){return e instanceof qc}}class Bc extends Ho{constructor(e,t){super(e),this.bc=t}_toFieldTransform(e){const t=new So(e.serializer,Op(e.serializer,this.bc));return new Vp(e.path,t)}isEqual(e){return e instanceof Bc&&this.bc===e.bc}}function jE(n,e,t,r){const i=n.I(1,e,t);$c("Data must be an object, but it was:",i,r);const o=[],s=ut.empty();Yn(r,(u,h)=>{const p=Ig(e,u,t);h=$e(h);const m=i.fc(p);if(h instanceof xa)o.push(p);else{const g=Go(h,m);g!=null&&(o.push(p),s.set(p,g))}});const l=new mt(o);return new wg(s,l,i.fieldTransforms)}function zE(n,e,t,r,i,o){const s=n.I(1,e,t),l=[mi(e,r,t)],u=[i];if(o.length%2!=0)throw new B(D.INVALID_ARGUMENT,`Function ${e}() needs to be called with an even number of arguments that alternate between field names and values.`);for(let g=0;g<o.length;g+=2)l.push(mi(e,o[g])),u.push(o[g+1]);const h=[],p=ut.empty();for(let g=l.length-1;g>=0;--g)if(!Ag(h,l[g])){const b=l[g];let P=u[g];P=$e(P);const A=s.fc(b);if(P instanceof xa)h.push(b);else{const O=Go(P,A);O!=null&&(h.push(b),p.set(b,O))}}const m=new mt(h);return new wg(p,m,s.fieldTransforms)}function WE(n,e,t,r=!1){return Go(t,n.I(r?4:3,e))}function Go(n,e){if(Eg(n=$e(n)))return $c("Unsupported field value:",e,n),Tg(n,e);if(n instanceof Ho)return function(r,i){if(!bg(i.dataSource))throw i.yc(`${r._methodName}() can only be used with update() and set()`);if(!i.path)throw i.yc(`${r._methodName}() is not currently supported inside arrays`);const o=r._toFieldTransform(i);o&&i.fieldTransforms.push(o)}(n,e),null;if(n===void 0&&e.ignoreUndefinedProperties)return null;if(e.path&&e.fieldMask.push(e.path),n instanceof Array){if(e.settings.arrayElement&&e.dataSource!==4)throw e.yc("Nested arrays are not supported");return function(r,i){const o=[];let s=0;for(const l of r){let u=Go(l,i.gc(s));u==null&&(u={nullValue:"NULL_VALUE"}),o.push(u),s++}return{arrayValue:{values:o}}}(n,e)}return function(r,i){if((r=$e(r))===null)return{nullValue:"NULL_VALUE"};if(typeof r=="number")return Op(i.serializer,r);if(typeof r=="boolean")return{booleanValue:r};if(typeof r=="string")return{stringValue:r};if(r instanceof Date){const o=me.fromDate(r);return{timestampValue:Ks(i.serializer,o)}}if(r instanceof me){const o=new me(r.seconds,1e3*Math.floor(r.nanoseconds/1e3));return{timestampValue:Ks(i.serializer,o)}}if(r instanceof zt)return{geoPointValue:{latitude:r.latitude,longitude:r.longitude}};if(r instanceof _t)return{bytesValue:jp(i.serializer,r._byteString)};if(r instanceof Ee){const o=i.databaseId,s=r.firestore._databaseId;if(!s.isEqual(o))throw i.yc(`Document reference is for database ${s.projectId}/${s.database} but should be for database ${o.projectId}/${o.database}`);return{referenceValue:_c(r.firestore._databaseId||i.databaseId,r._key.path)}}if(r instanceof St)return function(s,l){const u=s instanceof St?s.toArray():s;return{mapValue:{fields:{[mp]:{stringValue:yp},[Ws]:{arrayValue:{values:u.map(p=>{if(typeof p!="number")throw l.yc("VectorValues must only contain numeric values.");return gc(l.serializer,p)})}}}}}}(r,i);if(Qp(r))return r._toProto(i.serializer);throw i.yc(`Unsupported field value: ${da(r)}`)}(n,e)}function Tg(n,e){const t={};return up(n)?e.path&&e.path.length>0&&e.fieldMask.push(e.path):Yn(n,(r,i)=>{const o=Go(i,e.dc(r));o!=null&&(t[r]=o)}),{mapValue:{fields:t}}}function Eg(n){return!(typeof n!="object"||n===null||n instanceof Array||n instanceof Date||n instanceof me||n instanceof zt||n instanceof _t||n instanceof Ee||n instanceof Ho||n instanceof St||Qp(n))}function $c(n,e,t){if(!Eg(t)||!lp(t)){const r=da(t);throw r==="an object"?e.yc(n+" a custom object"):e.yc(n+" "+r)}}function mi(n,e,t){if((e=$e(e))instanceof Vc)return e._internalPath;if(typeof e=="string")return Ig(n,e);throw Zs("Field path arguments must be of type string or ",n,!1,void 0,t)}const HE=new RegExp("[~\\*/\\[\\]]");function Ig(n,e,t){if(e.search(HE)>=0)throw Zs(`Invalid field path (${e}). Paths must not contain '~', '*', '/', '[', or ']'`,n,!1,void 0,t);try{return new Vc(...e.split("."))._internalPath}catch{throw Zs(`Invalid field path (${e}). Paths must not be empty, begin with '.', end with '.', or contain '..'`,n,!1,void 0,t)}}function Zs(n,e,t,r,i){const o=r&&!r.isEmpty(),s=i!==void 0;let l=`Function ${e}() called with invalid data`;t&&(l+=" (via `toFirestore()`)"),l+=". ";let u="";return(o||s)&&(u+=" (found",o&&(u+=` in field ${r}`),s&&(u+=` in document ${i}`),u+=")"),new B(D.INVALID_ARGUMENT,l+n+u)}function Ag(n,e){return n.some(t=>t.isEqual(e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class GE{convertValue(e,t="none"){switch(Wn(e)){case 0:return null;case 1:return e.booleanValue;case 2:return Ae(e.integerValue||e.doubleValue);case 3:return this.convertTimestamp(e.timestampValue);case 4:return this.convertServerTimestamp(e,t);case 5:return e.stringValue;case 6:return this.convertBytes(zn(e.bytesValue));case 7:return this.convertReference(e.referenceValue);case 8:return this.convertGeoPoint(e.geoPointValue);case 9:return this.convertArray(e.arrayValue,t);case 11:return this.convertObject(e.mapValue,t);case 10:return this.convertVectorValue(e.mapValue);default:throw Y(62114,{value:e})}}convertObject(e,t){return this.convertObjectMap(e.fields,t)}convertObjectMap(e,t="none"){const r={};return Yn(e,(i,o)=>{r[i]=this.convertValue(o,t)}),r}convertVectorValue(e){var r,i,o;const t=(o=(i=(r=e.fields)==null?void 0:r[Ws].arrayValue)==null?void 0:i.values)==null?void 0:o.map(s=>Ae(s.doubleValue));return new St(t)}convertGeoPoint(e){return new zt(Ae(e.latitude),Ae(e.longitude))}convertArray(e,t){return(e.values||[]).map(r=>this.convertValue(r,t))}convertServerTimestamp(e,t){switch(t){case"previous":const r=ga(e);return r==null?null:this.convertValue(r,t);case"estimate":return this.convertTimestamp(_o(e));default:return null}}convertTimestamp(e){const t=jn(e);return new me(t.seconds,t.nanos)}convertDocumentKey(e,t){const r=pe.fromString(e);he(Yp(r),9688,{name:e});const i=new wo(r.get(1),r.get(3)),o=new G(r.popFirst(5));return i.isEqual(t)||pn(`Document ${o} contains a document reference within a different database (${i.projectId}/${i.database}) which is not supported. It will be treated as a reference in the current database (${t.projectId}/${t.database}) instead.`),o}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class jc extends GE{constructor(e){super(),this.firestore=e}convertBytes(e){return new _t(e)}convertReference(e){const t=this.convertDocumentKey(e,this.firestore._databaseId);return new Ee(this.firestore,null,t)}}function Tr(){return new qc("serverTimestamp")}function ea(n){return new Bc("increment",n)}const Rd="@firebase/firestore",Od="4.14.0";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Nd(n){return function(t,r){if(typeof t!="object"||t===null)return!1;const i=t;for(const o of r)if(o in i&&typeof i[o]=="function")return!0;return!1}(n,["next","error","complete"])}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Sg{constructor(e,t,r,i,o){this._firestore=e,this._userDataWriter=t,this._key=r,this._document=i,this._converter=o}get id(){return this._key.path.lastSegment()}get ref(){return new Ee(this._firestore,this._converter,this._key)}exists(){return this._document!==null}data(){if(this._document){if(this._converter){const e=new KE(this._firestore,this._userDataWriter,this._key,this._document,null);return this._converter.fromFirestore(e)}return this._userDataWriter.convertValue(this._document.data.value)}}_fieldsProto(){var e;return((e=this._document)==null?void 0:e.data.clone().value.mapValue.fields)??void 0}get(e){if(this._document){const t=this._document.data.field(mi("DocumentSnapshot.get",e));if(t!==null)return this._userDataWriter.convertValue(t)}}}class KE extends Sg{data(){return super.data()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function xg(n){if(n.limitType==="L"&&n.explicitOrderBy.length===0)throw new B(D.UNIMPLEMENTED,"limitToLast() queries require specifying at least one orderBy() clause")}class zc{}class Wc extends zc{}function YE(n,e,...t){let r=[];e instanceof zc&&r.push(e),r=r.concat(t),function(o){const s=o.filter(u=>u instanceof Gc).length,l=o.filter(u=>u instanceof Hc).length;if(s>1||s>0&&l>0)throw new B(D.INVALID_ARGUMENT,"InvalidQuery. When using composite filters, you cannot use more than one filter at the top level. Consider nesting the multiple filters within an `and(...)` statement. For example: change `query(query, where(...), or(...))` to `query(query, and(where(...), or(...)))`.")}(r);for(const i of r)n=i._apply(n);return n}class Hc extends Wc{constructor(e,t,r){super(),this._field=e,this._op=t,this._value=r,this.type="where"}static _create(e,t,r){return new Hc(e,t,r)}_apply(e){const t=this._parse(e);return kg(e._query,t),new vn(e.firestore,e.converter,Pl(e._query,t))}_parse(e){const t=Uc(e.firestore);return function(o,s,l,u,h,p,m){let g;if(h.isKeyField()){if(p==="array-contains"||p==="array-contains-any")throw new B(D.INVALID_ARGUMENT,`Invalid Query. You can't perform '${p}' queries on documentId().`);if(p==="in"||p==="not-in"){Md(m,p);const P=[];for(const A of m)P.push(Dd(u,o,A));g={arrayValue:{values:P}}}else g=Dd(u,o,m)}else p!=="in"&&p!=="not-in"&&p!=="array-contains-any"||Md(m,p),g=WE(l,s,m,p==="in"||p==="not-in");return Ce.create(h,p,g)}(e._query,"where",t,e.firestore._databaseId,this._field,this._op,this._value)}}class Gc extends zc{constructor(e,t){super(),this.type=e,this._queryConstraints=t}static _create(e,t){return new Gc(e,t)}_parse(e){const t=this._queryConstraints.map(r=>r._parse(e)).filter(r=>r.getFilters().length>0);return t.length===1?t[0]:Ct.create(t,this._getOperator())}_apply(e){const t=this._parse(e);return t.getFilters().length===0?e:(function(i,o){let s=i;const l=o.getFlattenedFilters();for(const u of l)kg(s,u),s=Pl(s,u)}(e._query,t),new vn(e.firestore,e.converter,Pl(e._query,t)))}_getQueryConstraints(){return this._queryConstraints}_getOperator(){return this.type==="and"?"and":"or"}}class Kc extends Wc{constructor(e,t){super(),this._field=e,this._direction=t,this.type="orderBy"}static _create(e,t){return new Kc(e,t)}_apply(e){const t=function(i,o,s){if(i.startAt!==null)throw new B(D.INVALID_ARGUMENT,"Invalid query. You must not call startAt() or startAfter() before calling orderBy().");if(i.endAt!==null)throw new B(D.INVALID_ARGUMENT,"Invalid query. You must not call endAt() or endBefore() before calling orderBy().");return new To(o,s)}(e._query,this._field,this._direction);return new vn(e.firestore,e.converter,_b(e._query,t))}}function QE(n,e="asc"){const t=e,r=mi("orderBy",n);return Kc._create(r,t)}class Yc extends Wc{constructor(e,t,r){super(),this.type=e,this._limit=t,this._limitType=r}static _create(e,t,r){return new Yc(e,t,r)}_apply(e){return new vn(e.firestore,e.converter,Gs(e._query,this._limit,this._limitType))}}function XE(n){return zw("limit",n),Yc._create("limit",n,"F")}function Dd(n,e,t){if(typeof(t=$e(t))=="string"){if(t==="")throw new B(D.INVALID_ARGUMENT,"Invalid query. When querying with documentId(), you must provide a valid document ID, but it was an empty string.");if(!Ap(e)&&t.indexOf("/")!==-1)throw new B(D.INVALID_ARGUMENT,`Invalid query. When querying a collection by documentId(), you must provide a plain document ID, but '${t}' contains a '/' character.`);const r=e.path.child(pe.fromString(t));if(!G.isDocumentKey(r))throw new B(D.INVALID_ARGUMENT,`Invalid query. When querying a collection group by documentId(), the value provided must result in a valid document path, but '${r}' is not because it has an odd number of segments (${r.length}).`);return Kh(n,new G(r))}if(t instanceof Ee)return Kh(n,t._key);throw new B(D.INVALID_ARGUMENT,`Invalid query. When querying with documentId(), you must provide a valid string or a DocumentReference, but it was: ${da(t)}.`)}function Md(n,e){if(!Array.isArray(n)||n.length===0)throw new B(D.INVALID_ARGUMENT,`Invalid Query. A non-empty array is required for '${e.toString()}' filters.`)}function kg(n,e){const t=function(i,o){for(const s of i)for(const l of s.getFlattenedFilters())if(o.indexOf(l.op)>=0)return l.op;return null}(n.filters,function(i){switch(i){case"!=":return["!=","not-in"];case"array-contains-any":case"in":return["not-in"];case"not-in":return["array-contains-any","in","not-in","!="];default:return[]}}(e.op));if(t!==null)throw t===e.op?new B(D.INVALID_ARGUMENT,`Invalid query. You cannot use more than one '${e.op.toString()}' filter.`):new B(D.INVALID_ARGUMENT,`Invalid query. You cannot use '${e.op.toString()}' filters with '${t.toString()}' filters.`)}function JE(n,e,t){let r;return r=n?t&&(t.merge||t.mergeFields)?n.toFirestore(e,t):n.toFirestore(e):e,r}class to{constructor(e,t){this.hasPendingWrites=e,this.fromCache=t}isEqual(e){return this.hasPendingWrites===e.hasPendingWrites&&this.fromCache===e.fromCache}}class dr extends Sg{constructor(e,t,r,i,o,s){super(e,t,r,i,s),this._firestore=e,this._firestoreImpl=e,this.metadata=o}exists(){return super.exists()}data(e={}){if(this._document){if(this._converter){const t=new Cs(this._firestore,this._userDataWriter,this._key,this._document,this.metadata,null);return this._converter.fromFirestore(t,e)}return this._userDataWriter.convertValue(this._document.data.value,e.serverTimestamps)}}get(e,t={}){if(this._document){const r=this._document.data.field(mi("DocumentSnapshot.get",e));if(r!==null)return this._userDataWriter.convertValue(r,t.serverTimestamps)}}toJSON(){if(this.metadata.hasPendingWrites)throw new B(D.FAILED_PRECONDITION,"DocumentSnapshot.toJSON() attempted to serialize a document with pending writes. Await waitForPendingWrites() before invoking toJSON().");const e=this._document,t={};return t.type=dr._jsonSchemaVersion,t.bundle="",t.bundleSource="DocumentSnapshot",t.bundleName=this._key.toString(),!e||!e.isValidDocument()||!e.isFoundDocument()?t:(this._userDataWriter.convertObjectMap(e.data.value.mapValue.fields,"previous"),t.bundle=(this._firestore,this.ref.path,"NOT SUPPORTED"),t)}}dr._jsonSchemaVersion="firestore/documentSnapshot/1.0",dr._jsonSchema={type:Re("string",dr._jsonSchemaVersion),bundleSource:Re("string","DocumentSnapshot"),bundleName:Re("string"),bundle:Re("string")};class Cs extends dr{data(e={}){return super.data(e)}}class fr{constructor(e,t,r,i){this._firestore=e,this._userDataWriter=t,this._snapshot=i,this.metadata=new to(i.hasPendingWrites,i.fromCache),this.query=r}get docs(){const e=[];return this.forEach(t=>e.push(t)),e}get size(){return this._snapshot.docs.size}get empty(){return this.size===0}forEach(e,t){this._snapshot.docs.forEach(r=>{e.call(t,new Cs(this._firestore,this._userDataWriter,r.key,r,new to(this._snapshot.mutatedKeys.has(r.key),this._snapshot.fromCache),this.query.converter))})}docChanges(e={}){const t=!!e.includeMetadataChanges;if(t&&this._snapshot.excludesMetadataChanges)throw new B(D.INVALID_ARGUMENT,"To include metadata changes with your document changes, you must also pass { includeMetadataChanges:true } to onSnapshot().");return this._cachedChanges&&this._cachedChangesIncludeMetadataChanges===t||(this._cachedChanges=function(i,o){if(i._snapshot.oldDocs.isEmpty()){let s=0;return i._snapshot.docChanges.map(l=>{const u=new Cs(i._firestore,i._userDataWriter,l.doc.key,l.doc,new to(i._snapshot.mutatedKeys.has(l.doc.key),i._snapshot.fromCache),i.query.converter);return l.doc,{type:"added",doc:u,oldIndex:-1,newIndex:s++}})}{let s=i._snapshot.oldDocs;return i._snapshot.docChanges.filter(l=>o||l.type!==3).map(l=>{const u=new Cs(i._firestore,i._userDataWriter,l.doc.key,l.doc,new to(i._snapshot.mutatedKeys.has(l.doc.key),i._snapshot.fromCache),i.query.converter);let h=-1,p=-1;return l.type!==0&&(h=s.indexOf(l.doc.key),s=s.delete(l.doc.key)),l.type!==1&&(s=s.add(l.doc),p=s.indexOf(l.doc.key)),{type:ZE(l.type),doc:u,oldIndex:h,newIndex:p}})}}(this,t),this._cachedChangesIncludeMetadataChanges=t),this._cachedChanges}toJSON(){if(this.metadata.hasPendingWrites)throw new B(D.FAILED_PRECONDITION,"QuerySnapshot.toJSON() attempted to serialize a document with pending writes. Await waitForPendingWrites() before invoking toJSON().");const e={};e.type=fr._jsonSchemaVersion,e.bundleSource="QuerySnapshot",e.bundleName=cc.newId(),this._firestore._databaseId.database,this._firestore._databaseId.projectId;const t=[],r=[],i=[];return this.docs.forEach(o=>{o._document!==null&&(t.push(o._document),r.push(this._userDataWriter.convertObjectMap(o._document.data.value.mapValue.fields,"previous")),i.push(o.ref.path))}),e.bundle=(this._firestore,this.query._query,e.bundleName,"NOT SUPPORTED"),e}}function ZE(n){switch(n){case 0:return"added";case 2:case 3:return"modified";case 1:return"removed";default:return Y(61501,{type:n})}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */fr._jsonSchemaVersion="firestore/querySnapshot/1.0",fr._jsonSchema={type:Re("string",fr._jsonSchemaVersion),bundleSource:Re("string","QuerySnapshot"),bundleName:Re("string"),bundle:Re("string")};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Cr(n){n=yt(n,Ee);const e=yt(n.firestore,Kn),t=Sa(e);return RE(t,n._key).then(r=>Pg(e,n,r))}function Qc(n){n=yt(n,vn);const e=yt(n.firestore,Kn),t=Sa(e),r=new jc(e);return xg(n._query),OE(t,n._query).then(i=>new fr(e,r,n,i))}function Gt(n,e,t){n=yt(n,Ee);const r=yt(n.firestore,Kn),i=JE(n.converter,e,t),o=Uc(r);return Xc(r,[$E(o,"setDoc",n._key,i,n.converter!==null,t).toMutation(n._key,At.none())])}function Er(n,e,t,...r){n=yt(n,Ee);const i=yt(n.firestore,Kn),o=Uc(i);let s;return s=typeof(e=$e(e))=="string"||e instanceof Vc?zE(o,"updateDoc",n._key,e,t,r):jE(o,"updateDoc",n._key,e),Xc(i,[s.toMutation(n._key,At.exists(!0))])}function xo(n){return Xc(yt(n.firestore,Kn),[new mc(n._key,At.none())])}function Ko(n,...e){var h,p,m;n=$e(n);let t={includeMetadataChanges:!1,source:"default"},r=0;typeof e[r]!="object"||Nd(e[r])||(t=e[r++]);const i={includeMetadataChanges:t.includeMetadataChanges,source:t.source};if(Nd(e[r])){const g=e[r];e[r]=(h=g.next)==null?void 0:h.bind(g),e[r+1]=(p=g.error)==null?void 0:p.bind(g),e[r+2]=(m=g.complete)==null?void 0:m.bind(g)}let o,s,l;if(n instanceof Ee)s=yt(n.firestore,Kn),l=ma(n._key.path),o={next:g=>{e[r]&&e[r](Pg(s,n,g))},error:e[r+1],complete:e[r+2]};else{const g=yt(n,vn);s=yt(g.firestore,Kn),l=g._query;const b=new jc(s);o={next:P=>{e[r]&&e[r](new fr(s,b,g,P))},error:e[r+1],complete:e[r+2]},xg(n._query)}const u=Sa(s);return CE(u,l,i,o)}function Xc(n,e){const t=Sa(n);return NE(t,e)}function Pg(n,e,t){const r=t.docs.get(e._key),i=new jc(n);return new dr(n,i,e._key,r,new to(t.hasPendingWrites,t.fromCache),e.converter)}(function(e,t=!0){Ow(wi),ci(new yr("firestore",(r,{instanceIdentifier:i,options:o})=>{const s=r.getProvider("app").getImmediate(),l=new Kn(new Mw(r.getProvider("auth-internal")),new Fw(s,r.getProvider("app-check-internal")),nb(s,i),s);return o={useFetchStreams:t,...o},l._setSettings(o),l},"PUBLIC").setMultipleInstances(!0)),Vn(Rd,Od,e),Vn(Rd,Od,"esm2020")})();let W=null;function eI(){let n;Ls().length===0?n=Zl(Jf):n=Ls()[0],W=VE(n),console.log("[OpenOverlay] Firestore initialized")}async function tI(n){if(!W){console.error("[OpenOverlay] Firestore not initialized");return}const e=_e(W,"users",n.uid);(await Cr(e)).exists()?(await Er(e,{displayName:n.displayName||"Anonymous",photoURL:n.photoURL||"",email:n.email||""}),console.log("[OpenOverlay] User profile updated")):(await Gt(e,{uid:n.uid,displayName:n.displayName||"Anonymous",email:n.email||"",photoURL:n.photoURL||"",bio:"",createdAt:Tr(),followersCount:0,followingCount:0}),console.log("[OpenOverlay] User profile created"))}async function Cg(n){if(!W)return null;const e=_e(W,"users",n),t=await Cr(e);return t.exists()?t.data():null}async function nI(n){const e=ce();if(!W||!e||e.uid===n)return;const t=_e(W,"users",e.uid,"following",n);await Gt(t,{followedAt:Tr()});const r=_e(W,"users",n,"followers",e.uid);await Gt(r,{followedAt:Tr()});const i=_e(W,"users",e.uid),o=_e(W,"users",n);await Er(i,{followingCount:ea(1)}),await Er(o,{followersCount:ea(1)}),console.log("[OpenOverlay] Followed user:",n)}async function rI(n){const e=ce();if(!W||!e||e.uid===n)return;const t=_e(W,"users",e.uid,"following",n);await xo(t);const r=_e(W,"users",n,"followers",e.uid);await xo(r);const i=_e(W,"users",e.uid),o=_e(W,"users",n);await Er(i,{followingCount:ea(-1)}),await Er(o,{followersCount:ea(-1)}),console.log("[OpenOverlay] Unfollowed user:",n)}async function iI(n){const e=ce();if(!W||!e)return!1;const t=_e(W,"users",e.uid,"following",n);return(await Cr(t)).exists()}async function oI(n,e=50){if(!W)return[];const t=Xn(W,"users",n,"following"),r=YE(t,QE("followedAt","desc"),XE(e)),i=await Qc(r),o=[];for(const s of i.docs){const l=await Cg(s.id);l&&o.push(l)}return o}async function Rg(n,e,t){const r=ce();if(!W||!r)return console.log("[OpenOverlay] Not logged in, skipping cloud save"),!1;try{const i=_e(W,"pageDrawings",n,"contributors",r.uid);return await Gt(i,{userId:r.uid,userDisplayName:r.displayName||"Anonymous",userPhotoURL:r.photoURL||"",pageUrl:e,items:JSON.stringify(t),updatedAt:Tr()}),console.log("[OpenOverlay] Drawing saved to cloud (public)"),!0}catch(i){return console.error("[OpenOverlay] Failed to save drawing to cloud:",i),!1}}async function sI(n){if(!W)return null;const e=ce();try{const t=Xn(W,"pageDrawings",n,"contributors"),r=await Qc(t),i=[],o=[],s=[];return r.docs.forEach(l=>{const u=l.data(),h=JSON.parse(u.items||"[]");s.push({userId:u.userId,displayName:u.userDisplayName,photoURL:u.userPhotoURL}),e&&u.userId===e.uid?i.push(...h):h.forEach(p=>{o.push({...p,_ownerId:u.userId,_ownerName:u.userDisplayName,_readOnly:!0})})}),console.log("[OpenOverlay] Loaded drawings:",i.length,"mine,",o.length,"from others"),{myItems:i,otherItems:o,contributors:s}}catch(t){return console.error("[OpenOverlay] Failed to load drawings from cloud:",t),null}}async function aI(n){const e=ce();if(!W||!e)return!1;try{const t=_e(W,"pageDrawings",n,"contributors",e.uid);return await xo(t),console.log("[OpenOverlay] Drawing deleted from cloud"),!0}catch(t){return console.error("[OpenOverlay] Failed to delete drawing from cloud:",t),!1}}let fs=null;function lI(n,e){if(!W)return console.log("[OpenOverlay] Cannot subscribe to drawings: Firestore not initialized"),null;fs&&fs();const t=ce(),r=Xn(W,"pageDrawings",n,"contributors");return fs=Ko(r,i=>{const o=[],s=[],l=[];i.docs.forEach(u=>{const h=u.data(),p=JSON.parse(h.items||"[]");l.push({userId:h.userId,displayName:h.userDisplayName,photoURL:h.userPhotoURL}),t&&h.userId===t.uid?o.push(...p):p.forEach(m=>{s.push({...m,_ownerId:h.userId,_ownerName:h.userDisplayName,_readOnly:!0})})}),console.log("[OpenOverlay] Real-time drawing update:",o.length,"mine,",s.length,"from others"),e({myItems:o,otherItems:s,contributors:l})},i=>{console.error("[OpenOverlay] Drawing subscription error:",i)}),console.log("[OpenOverlay] Subscribed to drawings on page:",n),fs}function Rr(){return W!==null}function ta(){return ce()!==null}let ps=null;async function cI(n,e){if(!W)return console.log("[OpenOverlay] Cannot save annotation: Firestore not initialized"),!1;try{const t=_e(W,"pageAnnotations",n,"annotations",e.id),r={...e,reactions:e.reactions||[],replies:e.replies||[],updatedAt:Tr()};return console.log("[OpenOverlay] Saving to Firestore:",t.path),await Gt(t,r,{merge:!0}),console.log("[OpenOverlay] Annotation saved to cloud successfully"),!0}catch(t){return console.error("[OpenOverlay] Failed to save annotation:",(t==null?void 0:t.message)||t),(t==null?void 0:t.code)==="permission-denied"&&console.error("[OpenOverlay] Firestore security rules may need to be updated"),!1}}async function uI(n,e){if(!W)return!1;try{const t=_e(W,"pageAnnotations",n,"annotations",e);return await xo(t),console.log("[OpenOverlay] Annotation deleted from cloud"),!0}catch(t){return console.error("[OpenOverlay] Failed to delete annotation:",t),!1}}async function Og(n){if(!W)return[];try{const e=Xn(W,"pageAnnotations",n,"annotations"),t=await Qc(e),r=[];return t.forEach(i=>{r.push({id:i.id,...i.data()})}),r.sort((i,o)=>(o.createdAt||0)-(i.createdAt||0)),console.log("[OpenOverlay] Fetched",r.length,"annotations from cloud"),r}catch(e){return console.error("[OpenOverlay] Failed to fetch annotations:",e),[]}}function hI(n,e){if(!W)return console.log("[OpenOverlay] Cannot subscribe to annotations: Firestore not initialized"),null;ps&&ps();const t=Xn(W,"pageAnnotations",n,"annotations");return ps=Ko(t,r=>{const i=[];r.forEach(o=>{i.push({id:o.id,...o.data()})}),i.sort((o,s)=>(s.createdAt||0)-(o.createdAt||0)),console.log("[OpenOverlay] Real-time update:",i.length,"annotations"),e(i)},r=>{console.error("[OpenOverlay] Annotation subscription error:",r),Og(n).then(e)}),ps}async function dI(n,e,t){if(!W)return!1;try{const r=_e(W,"pageAnnotations",n,"annotations",e),i=await Cr(r);if(!i.exists())return!1;const s=i.data().replies||[];return s.push(t),await Er(r,{replies:s}),console.log("[OpenOverlay] Reply added"),!0}catch(r){return console.error("[OpenOverlay] Failed to add reply:",r),!1}}async function fI(n,e,t,r){if(!W)return!1;try{const i=_e(W,"pageAnnotations",n,"annotations",e),o=await Cr(i);if(!o.exists())return!1;let l=o.data().reactions||[];const u=l.find(h=>h.emoji===t);return u?u.users.includes(r)?(u.users=u.users.filter(h=>h!==r),u.count=u.users.length,u.count===0&&(l=l.filter(h=>h.emoji!==t))):(u.users.push(r),u.count=u.users.length):l.push({emoji:t,count:1,users:[r]}),await Er(i,{reactions:l}),!0}catch(i){return console.error("[OpenOverlay] Failed to toggle reaction:",i),!1}}let ar=null,Ld=0;async function pI(n,e){const t=ce();if(!W||!t){console.log("[OpenOverlay] Cannot sync position: db=",!!W,"user=",!!t);return}try{const r=_e(W,"pageGames",n,"players",t.uid);await Gt(r,{...e,odlPlayerId:t.uid,displayName:e.displayName||t.displayName||"Player",updatedAt:Date.now()},{merge:!0})}catch(r){const i=Date.now();i-Ld>1e4&&(Ld=i,console.error("[OpenOverlay] Position sync error:",(r==null?void 0:r.message)||r))}}function gI(n,e){if(!W)return console.log("[OpenOverlay] Cannot subscribe to players: Firestore not initialized"),null;const t=ce();console.log("[OpenOverlay] Subscribing to players for page:",n,"currentUser:",t==null?void 0:t.uid),ar&&ar();const r=Xn(W,"pageGames",n,"players");return ar=Ko(r,i=>{const o=new Map,s=Date.now(),l=3e4;i.forEach(u=>{const h=u.data(),p=s-h.updatedAt;t&&u.id===t.uid||p>l||o.set(u.id,h)}),o.size>0&&console.log("[OpenOverlay] Got",o.size,"other players from snapshot"),e(o)},i=>{console.error("[OpenOverlay] Player subscription error:",i)}),console.log("[OpenOverlay] Subscribed to players on page:",n),ar}async function Ng(n){const e=ce();if(!(!W||!e))try{const t=_e(W,"pageGames",n,"players",e.uid);await xo(t),console.log("[OpenOverlay] Player removed from page")}catch(t){console.error("[OpenOverlay] Failed to remove player:",t)}}function Dg(){ar&&(ar(),ar=null)}let lr=null;function mI(n,e){if(!W)return console.log("[OpenOverlay] Cannot subscribe to tag game: Firestore not initialized"),null;lr&&lr();const t=_e(W,"pageGames",n,"gameState","tag");return lr=Ko(t,r=>{r.exists()?e(r.data()):e(null)},r=>{console.error("[OpenOverlay] Tag game subscription error:",r),e(null)}),console.log("[OpenOverlay] Subscribed to tag game"),lr}function yI(){lr&&(lr(),lr=null)}async function vI(n){const e=ce();if(!W||!e)return!1;try{const t=_e(W,"pageGames",n,"gameState","tag"),r=await Cr(t);if(r.exists()){const i=r.data();return console.log("[OpenOverlay] Joined existing tag game, IT is:",i.itPlayerId),i.itPlayerId===e.uid}return await Gt(t,{itPlayerId:e.uid,lastTagTime:Date.now(),gameActive:!0}),console.log("[OpenOverlay] Started new tag game - you are IT!"),!0}catch(t){return console.error("[OpenOverlay] Failed to start tag game:",t),!1}}async function _I(n,e){const t=ce();if(!W||!t)return!1;try{const r=_e(W,"pageGames",n,"gameState","tag"),i=await Cr(r);return i.exists()?i.data().itPlayerId!==t.uid?(console.log("[OpenOverlay] Cannot tag - you are not IT"),!1):(await Gt(r,{itPlayerId:e,lastTagTime:Date.now(),gameActive:!0}),console.log("[OpenOverlay] Tagged player:",e),!0):!1}catch(r){return console.error("[OpenOverlay] Failed to tag player:",r),!1}}async function wI(n,e){if(!W)return console.error("[OpenOverlay] Cannot submit feedback: Firestore not initialized"),!1;const t=ce();try{const r=Xn(W,"feedback"),i=_e(r);return await Gt(i,{type:n,message:e,userId:(t==null?void 0:t.uid)||null,userEmail:(t==null?void 0:t.email)||null,userName:(t==null?void 0:t.displayName)||null,pageUrl:window.location.href,userAgent:navigator.userAgent,timestamp:Tr()}),console.log("[OpenOverlay] Feedback submitted successfully"),!0}catch(r){return console.error("[OpenOverlay] Failed to submit feedback:",r),!1}}let gs=null;async function bI(n,e){const t=ce();if(!W||!t)return console.log("[OpenOverlay] Not logged in, skipping course cloud save"),!1;try{const r=_e(W,"pageCourses",n,"courses",t.uid);return await Gt(r,{...e,authorId:t.uid,authorName:t.displayName||"Anonymous",updatedAt:Tr()}),console.log("[OpenOverlay] Course saved to cloud"),!0}catch(r){return console.error("[OpenOverlay] Failed to save course to cloud:",r),!1}}function TI(n,e){if(!W)return console.log("[OpenOverlay] Cannot subscribe to courses: Firestore not initialized"),null;gs&&gs();const t=ce(),r=Xn(W,"pageCourses",n,"courses");return gs=Ko(r,i=>{let o=null;const s=[];i.forEach(l=>{const u=l.data();t&&l.id===t.uid?o=u:s.push(u)}),console.log("[OpenOverlay] Course update: mine=",!!o,"others=",s.length),e({myCourse:o,otherCourses:s})},i=>{console.error("[OpenOverlay] Course subscription error:",i)}),console.log("[OpenOverlay] Subscribed to courses on page:",n),gs}let sl=null,yi=null,Jc=null;const Rs=[];function EI(){Ls().length===0?sl=Zl(Jf):sl=Ls()[0],yi=Cw(sl),v_(yi,async n=>{Jc=n,console.log("[OpenOverlay] Auth state changed:",(n==null?void 0:n.displayName)||"signed out"),n&&await tI(n),Rs.forEach(e=>e(n))}),console.log("[OpenOverlay] Auth initialized")}async function II(){if(!yi)return console.error("[OpenOverlay] Auth not initialized"),null;const n=await new Promise(e=>{chrome.runtime.sendMessage({type:"GOOGLE_SIGN_IN"},e)});if(!n.success||!n.token)throw new Error(n.error||"Failed to get auth token");try{const e=en.credential(null,n.token),t=await g_(yi,e);return console.log("[OpenOverlay] Signed in as:",t.user.displayName),t.user}catch(e){throw console.error("[OpenOverlay] Sign in error:",e),(e==null?void 0:e.code)==="auth/invalid-credential"&&await new Promise(t=>{chrome.runtime.sendMessage({type:"GOOGLE_SIGN_OUT"},()=>t())}),e}}async function AI(){yi&&(await new Promise(n=>{chrome.runtime.sendMessage({type:"GOOGLE_SIGN_OUT"},()=>n())}),await __(yi),console.log("[OpenOverlay] Signed out"))}function ce(){return Jc}function Mg(n){return Rs.push(n),n(Jc),()=>{const e=Rs.indexOf(n);e>-1&&Rs.splice(e,1)}}let We=[],no=null,Wi=null,dt=null,cr=null,qn=new Set;const al=["#ffeb3b","#ff9800","#4caf50","#2196f3","#e91e63"],Zc=["👍","❤️","😂","😮","😢","😡","🔥","👀","💯","🎉"],SI=`
  .oo-annotate-btn {
    position: absolute;
    background: #22c55e;
    color: white;
    border: none;
    padding: 6px 12px;
    border-radius: 6px;
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
    box-shadow: 0 2px 8px rgba(0,0,0,0.2);
    z-index: 2147483646;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    transition: transform 0.1s;
  }

  .oo-annotate-btn:hover {
    transform: scale(1.05);
  }

  .oo-annotation-form {
    position: absolute;
    background: #1a1a1a;
    border-radius: 12px;
    padding: 16px;
    box-shadow: 0 8px 32px rgba(0,0,0,0.3);
    z-index: 2147483646;
    width: 300px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  }

  .oo-annotation-form textarea {
    width: 100%;
    height: 80px;
    background: #2a2a2a;
    border: 1px solid #333;
    border-radius: 8px;
    color: #fff;
    padding: 10px;
    font-size: 14px;
    resize: none;
    font-family: inherit;
  }

  .oo-annotation-form textarea:focus {
    outline: none;
    border-color: #22c55e;
  }

  .oo-annotation-form .colors {
    display: flex;
    gap: 6px;
    margin: 12px 0;
  }

  .oo-annotation-form .color-btn {
    width: 24px;
    height: 24px;
    border-radius: 50%;
    border: 2px solid transparent;
    cursor: pointer;
    transition: transform 0.1s;
  }

  .oo-annotation-form .color-btn:hover {
    transform: scale(1.2);
  }

  .oo-annotation-form .color-btn.active {
    border-color: #fff;
  }

  .oo-annotation-form .actions {
    display: flex;
    justify-content: flex-end;
    gap: 8px;
    margin-top: 12px;
  }

  .oo-annotation-form button {
    padding: 8px 16px;
    border: none;
    border-radius: 6px;
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
    font-family: inherit;
  }

  .oo-annotation-form .cancel-btn {
    background: #333;
    color: #fff;
  }

  .oo-annotation-form .save-btn {
    background: #22c55e;
    color: #fff;
  }

  .oo-popup {
    position: absolute;
    background: #1a1a1a;
    border-radius: 12px;
    box-shadow: 0 8px 32px rgba(0,0,0,0.4);
    z-index: 2147483646;
    max-width: 320px;
    min-width: 200px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    pointer-events: auto;
    padding: 14px;
  }

  .oo-popup .popup-quote {
    font-size: 18px;
    font-weight: 700;
    color: #fff;
    line-height: 1.3;
    margin-bottom: 8px;
  }

  .oo-popup .popup-author {
    text-align: right;
    color: #888;
    font-size: 12px;
    margin-bottom: 10px;
  }

  .oo-popup .popup-footer {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
  }

  .oo-popup .popup-reactions {
    display: flex;
    gap: 4px;
    flex-wrap: wrap;
    flex: 1;
  }

  .oo-popup .reaction {
    background: #222;
    border: 1px solid #333;
    border-radius: 12px;
    padding: 2px 6px;
    font-size: 12px;
    cursor: pointer;
    transition: background 0.1s;
    display: flex;
    align-items: center;
    gap: 2px;
  }

  .oo-popup .reaction:hover {
    background: #333;
  }

  .oo-popup .reaction .count {
    color: #888;
    font-size: 11px;
  }

  .oo-popup .reaction.active {
    background: #22c55e33;
    border-color: #22c55e;
  }

  .oo-popup .popup-actions {
    display: flex;
    gap: 6px;
    align-items: center;
  }

  .oo-popup .comment-btn {
    background: #222;
    border: 1px solid #333;
    border-radius: 12px;
    padding: 2px 8px;
    font-size: 12px;
    cursor: pointer;
    color: #888;
    display: flex;
    align-items: center;
    gap: 4px;
  }

  .oo-popup .comment-btn:hover {
    background: #333;
    color: #fff;
  }

  .oo-popup .add-reaction {
    background: #222;
    border: 1px solid #333;
    border-radius: 12px;
    padding: 2px 6px;
    font-size: 14px;
    cursor: pointer;
    color: #888;
  }

  .oo-popup .add-reaction:hover {
    background: #333;
    border-color: #22c55e;
    color: #22c55e;
  }

  .oo-popup .maximize-btn {
    background: none;
    border: none;
    color: #666;
    font-size: 14px;
    cursor: pointer;
    padding: 2px 4px;
  }

  .oo-popup .maximize-btn:hover {
    color: #fff;
  }

  .oo-popup .bookmark-btn {
    background: transparent;
    border: none;
    padding: 2px 4px;
    cursor: pointer;
    font-size: 14px;
    color: #888;
    transition: color 0.15s;
  }

  .oo-popup .bookmark-btn:hover {
    color: #fff;
  }

  .oo-popup .bookmark-btn.active {
    color: #f59e0b;
  }

  .oo-popup .delete-btn {
    background: transparent;
    border: none;
    padding: 2px 4px;
    cursor: pointer;
    font-size: 14px;
    color: #666;
    transition: color 0.15s;
  }

  .oo-popup .delete-btn:hover {
    color: #ef4444;
  }

  .oo-comment-panel .delete-btn {
    background: #ef4444;
    color: white;
    border: none;
    padding: 8px 16px;
    border-radius: 6px;
    cursor: pointer;
    font-size: 13px;
    margin-top: 12px;
  }

  .oo-comment-panel .delete-btn:hover {
    background: #dc2626;
  }

  .oo-popup .popup-reply-section {
    margin-top: 10px;
    padding-top: 10px;
    border-top: 1px solid #333;
    display: none;
  }

  .oo-popup .popup-reply-section.open {
    display: block;
  }

  .oo-popup .popup-reply-input {
    display: flex;
    gap: 6px;
  }

  .oo-popup .popup-reply-input input {
    flex: 1;
    background: #222;
    border: 1px solid #333;
    border-radius: 14px;
    padding: 6px 10px;
    color: #fff;
    font-size: 12px;
  }

  .oo-popup .popup-reply-input input:focus {
    outline: none;
    border-color: #22c55e;
  }

  .oo-popup .popup-reply-input button {
    background: #22c55e;
    border: none;
    border-radius: 50%;
    width: 26px;
    height: 26px;
    color: white;
    font-size: 12px;
    cursor: pointer;
  }

  .oo-popup .quick-emojis {
    display: flex;
    gap: 2px;
    margin-top: 8px;
  }

  .oo-popup .quick-emoji {
    background: none;
    border: none;
    font-size: 16px;
    cursor: pointer;
    padding: 2px;
    border-radius: 4px;
    opacity: 0.6;
    transition: opacity 0.1s, transform 0.1s;
  }

  .oo-popup .quick-emoji:hover {
    opacity: 1;
    transform: scale(1.2);
  }

  .oo-popup-emoji-picker {
    position: absolute;
    background: #222;
    border-radius: 10px;
    padding: 6px;
    box-shadow: 0 4px 16px rgba(0,0,0,0.4);
    display: flex;
    flex-wrap: wrap;
    gap: 2px;
    width: 180px;
    bottom: 100%;
    left: 0;
    margin-bottom: 4px;
  }

  .oo-popup-emoji-picker .emoji-btn {
    width: 28px;
    height: 28px;
    border: none;
    background: transparent;
    border-radius: 4px;
    font-size: 16px;
    cursor: pointer;
  }

  .oo-popup-emoji-picker .emoji-btn:hover {
    background: #333;
  }

  .oo-comment-panel {
    position: fixed;
    right: 0;
    top: 0;
    width: 360px;
    height: 100vh;
    background: #111;
    box-shadow: -4px 0 24px rgba(0,0,0,0.3);
    z-index: 2147483646;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    display: flex;
    flex-direction: column;
    transform: translateX(100%);
    transition: transform 0.2s ease-out;
  }

  .oo-comment-panel.open {
    transform: translateX(0);
  }

  .oo-comment-panel .header {
    padding: 16px;
    border-bottom: 1px solid #222;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .oo-comment-panel .header h3 {
    margin: 0;
    color: #fff;
    font-size: 16px;
  }

  .oo-comment-panel .close-btn {
    background: none;
    border: none;
    color: #888;
    font-size: 24px;
    cursor: pointer;
    padding: 0;
    line-height: 1;
  }

  .oo-comment-panel .highlighted-text {
    padding: 16px;
    background: #1a1a1a;
    border-bottom: 1px solid #222;
  }

  .oo-comment-panel .highlighted-text blockquote {
    margin: 0;
    padding-left: 12px;
    border-left: 3px solid #22c55e;
    color: #aaa;
    font-style: italic;
  }

  .oo-comment-panel .main-comment {
    padding: 16px;
    border-bottom: 1px solid #222;
  }

  .oo-comment-panel .author-info {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 8px;
  }

  .oo-comment-panel .avatar {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    background: #333;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #888;
    font-size: 14px;
  }

  .oo-comment-panel .author-name {
    color: #fff;
    font-weight: 600;
    font-size: 14px;
  }

  .oo-comment-panel .timestamp {
    color: #666;
    font-size: 12px;
  }

  .oo-comment-panel .comment-text {
    color: #ddd;
    font-size: 14px;
    line-height: 1.5;
  }

  .oo-comment-panel .reactions {
    display: flex;
    gap: 8px;
    margin-top: 12px;
    flex-wrap: wrap;
  }

  .oo-comment-panel .reaction {
    background: #222;
    border: 1px solid #333;
    border-radius: 16px;
    padding: 4px 10px;
    font-size: 13px;
    cursor: pointer;
    transition: background 0.1s;
  }

  .oo-comment-panel .reaction:hover {
    background: #333;
  }

  .oo-comment-panel .reaction .emoji {
    margin-right: 4px;
  }

  .oo-comment-panel .reaction .count {
    color: #888;
  }

  .oo-comment-panel .add-reaction {
    background: #1a1a1a;
    border: 1px dashed #444;
    color: #888;
    font-size: 16px;
    min-width: 36px;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .oo-comment-panel .add-reaction:hover {
    border-color: #22c55e;
    color: #22c55e;
  }

  .oo-comment-panel .reaction.active {
    background: #22c55e33;
    border-color: #22c55e;
  }

  .oo-emoji-picker {
    position: absolute;
    background: #222;
    border-radius: 12px;
    padding: 8px;
    box-shadow: 0 4px 16px rgba(0,0,0,0.4);
    display: flex;
    flex-wrap: wrap;
    gap: 4px;
    width: 200px;
    z-index: 10;
  }

  .oo-emoji-picker .emoji-btn {
    width: 32px;
    height: 32px;
    border: none;
    background: transparent;
    border-radius: 6px;
    font-size: 18px;
    cursor: pointer;
    transition: background 0.1s, transform 0.1s;
  }

  .oo-emoji-picker .emoji-btn:hover {
    background: #333;
    transform: scale(1.2);
  }

  .oo-comment-panel .replies-section {
    flex: 1;
    overflow-y: auto;
    padding: 16px;
  }

  .oo-comment-panel .reply {
    margin-bottom: 16px;
    padding-bottom: 16px;
    border-bottom: 1px solid #222;
  }

  .oo-comment-panel .reply:last-child {
    border-bottom: none;
  }

  .oo-comment-panel .reply-input {
    padding: 16px;
    border-top: 1px solid #222;
    display: flex;
    gap: 8px;
  }

  .oo-comment-panel .reply-input input {
    flex: 1;
    background: #222;
    border: 1px solid #333;
    border-radius: 20px;
    padding: 10px 16px;
    color: #fff;
    font-size: 14px;
  }

  .oo-comment-panel .reply-input input:focus {
    outline: none;
    border-color: #22c55e;
  }

  .oo-comment-panel .reply-input button {
    background: #22c55e;
    border: none;
    border-radius: 50%;
    width: 40px;
    height: 40px;
    color: white;
    font-size: 18px;
    cursor: pointer;
  }
`;function xI(){console.log("[OpenOverlay] initAnnotations starting..."),Wi=document.createElement("div"),Wi.id="openoverlay-annotations",Wi.style.cssText=`
    position: fixed;
    top: 0;
    left: 0;
    width: 0;
    height: 0;
    z-index: 2147483646;
    pointer-events: none;
  `,dt=Wi.attachShadow({mode:"open"});const n=document.createElement("style");n.textContent=SI,dt.appendChild(n),document.body.appendChild(Wi),document.addEventListener("mouseup",PI),document.addEventListener("selectionchange",kI),UI(),WI(),ka(),console.log("[OpenOverlay] Annotations initialized")}let ll=null;function kI(){ll&&clearTimeout(ll),ll=window.setTimeout(()=>{Lg()},100)}function PI(n){var e,t;(e=n.target)!=null&&e.closest("#openoverlay-annotations")||(t=n.target)!=null&&t.closest("#openoverlay-ui")||setTimeout(Lg,10)}function Lg(){const n=window.getSelection();if(!n||n.isCollapsed||!n.toString().trim()){na();return}if(n.toString().trim().length<3){na();return}const r=n.getRangeAt(0).getBoundingClientRect();CI(r,n)}function CI(n,e){if(na(),!dt)return;const t=document.createElement("button");t.className="oo-annotate-btn",t.textContent="+ Annotate",t.style.pointerEvents="auto";const r=Math.max(10,Math.min(n.left+n.width/2-50,window.innerWidth-110)),i=n.bottom+2,o=i+32>window.innerHeight?n.top-34:i;t.style.left=`${r}px`,t.style.top=`${o}px`,t.onclick=s=>{s.preventDefault(),s.stopPropagation(),RI(n,e)},dt.appendChild(t),no=t}function na(){no&&(dt!=null&&dt.contains(no))&&no.remove(),no=null}function RI(n,e){var g,b;if(na(),!dt)return;const t=e.toString().trim(),r=e.getRangeAt(0),i=e.anchorNode,o=e.focusNode,s=document.createElement("div");s.className="oo-annotation-form",s.style.pointerEvents="auto";const l=Math.max(10,Math.min(n.left,window.innerWidth-320)),u=n.bottom+4,h=180,p=u+h>window.innerHeight?Math.max(10,n.top-h-4):u;s.style.left=`${l}px`,s.style.top=`${p}px`;let m=al[0];s.innerHTML=`
    <textarea placeholder="Add your annotation..." autofocus></textarea>
    <div class="colors">
      ${al.map((P,A)=>`
        <div class="color-btn ${A===0?"active":""}"
             data-color="${P}"
             style="background: ${P}"></div>
      `).join("")}
    </div>
    <div class="actions">
      <button class="cancel-btn">Cancel</button>
      <button class="save-btn">Save</button>
    </div>
  `,s.querySelectorAll(".color-btn").forEach(P=>{P.addEventListener("click",()=>{s.querySelectorAll(".color-btn").forEach(A=>A.classList.remove("active")),P.classList.add("active"),m=P.dataset.color||al[0]})}),(g=s.querySelector(".cancel-btn"))==null||g.addEventListener("click",()=>{var P;s.remove(),(P=window.getSelection())==null||P.removeAllRanges()}),(b=s.querySelector(".save-btn"))==null||b.addEventListener("click",()=>{var V;const P=s.querySelector("textarea"),A=P.value.trim();if(!A){P.focus();return}const{contextBefore:O,contextAfter:F}=NI(r,t),U={id:OI(),text:t,contextBefore:O,contextAfter:F,anchorSelector:Vd(i),anchorOffset:e.anchorOffset,focusSelector:Vd(o),focusOffset:e.focusOffset,comment:A,color:m,authorId:"local-user",authorName:"You",createdAt:Date.now(),reactions:[],replies:[]};We.push(U),xt(),ka(),FI(U),s.remove(),(V=window.getSelection())==null||V.removeAllRanges(),console.log("[OpenOverlay] Annotation created:",U.id)}),dt.appendChild(s),setTimeout(()=>{var P;(P=s.querySelector("textarea"))==null||P.focus()},10)}function Vd(n){if(!n)return"body";const e=n.nodeType===Node.TEXT_NODE?n.parentElement:n;if(!e)return"body";const t=[];let r=e;for(;r&&r!==document.body&&r!==document.documentElement;){let i=r.tagName.toLowerCase();if(r.id){t.unshift(`#${CSS.escape(r.id)}`);break}const o=r.parentElement;if(o){const l=Array.from(o.children).indexOf(r)+1;i+=`:nth-child(${l})`}t.unshift(i),r=r.parentElement}return t.join(" > ")||"body"}function OI(){return Math.random().toString(36).substr(2,9)}function NI(n,e){var r;try{const i=n.commonAncestorContainer,o=i.nodeType===Node.TEXT_NODE?i.parentElement:i;if(!o)return{contextBefore:"",contextAfter:""};const s=o.textContent||"",l=((r=n.startContainer.textContent)==null?void 0:r.substring(0,n.startOffset))||"";let u="";const h=document.createTreeWalker(o,NodeFilter.SHOW_TEXT,null);let p;for(;p=h.nextNode();){if(p===n.startContainer){u+=l;break}u+=p.textContent||""}const m=u.slice(-30),g=u.length+e.length,b=s.substring(g,g+30);return{contextBefore:m,contextAfter:b}}catch(i){return console.warn("[OpenOverlay] Failed to get selection context:",i),{contextBefore:"",contextAfter:""}}}function eu(){document.querySelectorAll(".oo-highlight").forEach(n=>{const e=n.parentNode;e&&(e.replaceChild(document.createTextNode(n.textContent||""),n),e.normalize())})}function ka(){eu();for(const n of We)try{DI(n)}catch(e){console.warn("[OpenOverlay] Failed to highlight annotation:",n.id,e)}}function DI(n){(n.contextBefore||"")+n.text+(n.contextAfter||"");const e=n.text,t=[],r=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,null);let i="",o;for(;o=r.nextNode();){const h=o.textContent||"";t.push({node:o,start:i.length,end:i.length+h.length}),i+=h}let s=-1;if(n.contextBefore||n.contextAfter){const h=n.contextBefore||"",p=n.contextAfter||"";let m=0;for(;m<i.length;){const g=i.indexOf(e,m);if(g===-1)break;const b=h===""||i.substring(Math.max(0,g-h.length),g).endsWith(h),P=p===""||i.substring(g+e.length,g+e.length+p.length).startsWith(p);if(b&&P){s=g;break}m=g+1}}if(s===-1&&(s=i.indexOf(e)),s===-1)return;let l=null,u=0;for(const h of t)if(s>=h.start&&s<h.end){l=h.node,u=s-h.start;break}if(l)try{const h=document.createRange();h.setStart(l,u),h.setEnd(l,u+e.length);const p=document.createElement("span");p.className="oo-highlight",p.dataset.annotationId=n.id,p.style.cssText=`
      background: ${n.color}40;
      border-bottom: 2px solid ${n.color};
      cursor: pointer;
      transition: background 0.15s;
    `,p.addEventListener("mouseenter",m=>{p.style.background=`${n.color}60`,Ul(n,m,p)}),p.addEventListener("mouseleave",m=>{p.style.background=`${n.color}40`,Vg()}),h.surroundContents(p)}catch(h){console.warn("[OpenOverlay] Failed to highlight annotation:",n.id,h)}}let pr=null,Lt=null,ei=null,ti=!1;function Vg(){ti||(ei&&clearTimeout(ei),ei=window.setTimeout(()=>{Cn()},150))}function ro(){ei&&(clearTimeout(ei),ei=null)}function Ul(n,e,t){var A,O,F,U;if(Wt)return;if(pr&&(Lt==null?void 0:Lt.id)===n.id){ro();return}if(ro(),Cn(),ti=!1,!dt)return;Lt=n;const r=document.createElement("div");r.className="oo-popup";let i,o;if(t){const V=t.getBoundingClientRect();i=V.left,o=V.bottom+4}else i=e.clientX-100,o=e.clientY+10;i<10&&(i=10),i+320>window.innerWidth&&(i=window.innerWidth-330),o+200>window.innerHeight&&(o=t?t.getBoundingClientRect().top-200:e.clientY-200),r.style.left=`${i}px`,r.style.top=`${o}px`;const s=n.reactions.filter(V=>V.count>0),l=n.replies.length,u=ce(),h=u?n.authorId===u.uid:n.authorId==="local-user";r.innerHTML=`
    <div class="popup-quote">"${Tt(n.comment)}"</div>
    <div class="popup-author">— ${Tt(n.authorName)}</div>
    <div class="popup-footer">
      <div class="popup-reactions" id="popup-reactions">
        ${s.map(V=>`
          <div class="reaction ${V.userReacted?"active":""}" data-emoji="${V.emoji}">
            <span class="emoji">${V.emoji}</span>
            <span class="count">${V.count}</span>
          </div>
        `).join("")}
      </div>
      <div class="popup-actions">
        <button class="comment-btn" id="popup-comment-btn" title="Comments">
          💬 ${l>0?l:""}
        </button>
        <button class="add-reaction" id="popup-add-reaction" title="React">+</button>
        <button class="bookmark-btn ${qn.has(n.id)?"active":""}" id="popup-bookmark-btn" title="Bookmark">🔖</button>
        <button class="maximize-btn" title="Open in sidebar">⛶</button>
        ${h?'<button class="delete-btn" id="popup-delete-btn" title="Delete annotation">🗑️</button>':""}
      </div>
    </div>
    <div class="popup-reply-section" id="popup-reply-section">
      <div class="popup-reply-input">
        <input type="text" placeholder="Add a comment..." />
        <button>➤</button>
      </div>
      <div class="quick-emojis">
        ${Zc.slice(0,6).map(V=>`
          <button class="quick-emoji" data-emoji="${V}">${V}</button>
        `).join("")}
      </div>
    </div>
  `,r.addEventListener("mouseenter",()=>{ro()}),r.addEventListener("mouseleave",()=>{Vg()}),r.addEventListener("click",V=>{V.stopPropagation(),ti=!0,ro()}),(A=r.querySelector(".maximize-btn"))==null||A.addEventListener("click",V=>{V.stopPropagation(),ti=!1,Cn(),VI(n)}),(O=r.querySelector("#popup-bookmark-btn"))==null||O.addEventListener("click",V=>{V.stopPropagation(),jI(n.id);const H=r.querySelector("#popup-bookmark-btn");H==null||H.classList.toggle("active",qn.has(n.id))}),(F=r.querySelector("#popup-delete-btn"))==null||F.addEventListener("click",V=>{V.stopPropagation(),confirm("Delete this annotation and all its comments?")&&(Hg(n.id),Cn())});const p=r.querySelector("#popup-comment-btn"),m=r.querySelector("#popup-reply-section");p==null||p.addEventListener("click",V=>{if(V.stopPropagation(),m==null||m.classList.toggle("open"),m!=null&&m.classList.contains("open")){const H=r.querySelector(".popup-reply-input input");H==null||H.focus()}}),r.querySelectorAll(".reaction").forEach(V=>{V.addEventListener("click",H=>{H.stopPropagation();const z=V.dataset.emoji;if(!z)return;const K=n.reactions.find(T=>T.emoji===z);K&&(K.userReacted?(K.count--,K.userReacted=!1,K.count<=0&&(n.reactions=n.reactions.filter(T=>T.emoji!==z))):(K.count++,K.userReacted=!0),xt(),Ir(n,z),Cn(),Ul(n,H))})}),(U=r.querySelector("#popup-add-reaction"))==null||U.addEventListener("click",V=>{V.stopPropagation();const H=r.querySelector("#popup-reactions");Ug(r,n,H)}),r.querySelectorAll(".quick-emoji").forEach(V=>{V.addEventListener("click",H=>{H.stopPropagation();const z=V.dataset.emoji;if(!z)return;let K=n.reactions.find(T=>T.emoji===z);K?K.userReacted||(K.count++,K.userReacted=!0):n.reactions.push({emoji:z,count:1,userReacted:!0}),xt(),Ir(n,z),Cn(),Ul(n,H)})});const g=r.querySelector(".popup-reply-input input"),b=r.querySelector(".popup-reply-input button"),P=()=>{const V=g.value.trim();if(!V)return;const H=ce(),z={authorName:(H==null?void 0:H.displayName)||"You",text:V,createdAt:Date.now()};n.replies.push(z),xt(),Wg(n,z),g.value="";const K=r.querySelector("#popup-comment-btn");K&&(K.innerHTML=`💬 ${n.replies.length}`)};b==null||b.addEventListener("click",V=>{V.stopPropagation(),P()}),g==null||g.addEventListener("keypress",V=>{V.key==="Enter"&&(V.stopPropagation(),P())}),dt.appendChild(r),pr=r,setTimeout(()=>{document.addEventListener("click",Bg)},10)}function MI(n){return`
    ${n.reactions.map(e=>`
      <div class="reaction ${e.userReacted?"active":""}" data-emoji="${e.emoji}">
        <span class="emoji">${e.emoji}</span>
        <span class="count">${e.count}</span>
      </div>
    `).join("")}
    <div class="reaction add-reaction" id="popup-add-reaction">😀+</div>
  `}function LI(n,e){var r;const t=n.querySelector("#popup-reactions");t&&(t.querySelectorAll(".reaction:not(.add-reaction)").forEach(i=>{i.addEventListener("click",o=>{o.stopPropagation();const s=i.dataset.emoji;if(!s)return;const l=e.reactions.find(u=>u.emoji===s);l&&(l.userReacted?(l.count--,l.userReacted=!1,l.count<=0&&(e.reactions=e.reactions.filter(u=>u.emoji!==s))):(l.count++,l.userReacted=!0),xt(),Ir(e,s),Fg(n,e))})}),(r=t.querySelector("#popup-add-reaction"))==null||r.addEventListener("click",i=>{i.stopPropagation(),Ug(n,e,t)}))}function Fg(n,e){const t=n.querySelector("#popup-reactions");t&&(t.innerHTML=MI(e),LI(n,e))}let ni=null;function Ug(n,e,t){ra();const r=document.createElement("div");r.className="oo-popup-emoji-picker",r.innerHTML=Zc.map(i=>`
    <button class="emoji-btn" data-emoji="${i}">${i}</button>
  `).join(""),r.querySelectorAll(".emoji-btn").forEach(i=>{i.addEventListener("click",o=>{o.stopPropagation();const s=i.dataset.emoji;if(!s)return;let l=e.reactions.find(u=>u.emoji===s);l?l.userReacted||(l.count++,l.userReacted=!0):e.reactions.push({emoji:s,count:1,userReacted:!0}),xt(),Ir(e,s),Fg(n,e),ra()})}),t.appendChild(r),ni=r,setTimeout(()=>{document.addEventListener("click",qg)},10)}function qg(n){ni&&!ni.contains(n.target)&&ra()}function ra(){document.removeEventListener("click",qg),ni&&(ni.remove(),ni=null)}function Bg(n){ti&&pr&&!pr.contains(n.target)&&Cn()}function Cn(){ro(),document.removeEventListener("click",Bg),ra(),pr&&(pr.remove(),pr=null),Lt=null,ti=!1}let Wt=null;function VI(n){var h,p,m;if(Cn(),Os(),!dt)return;const e=document.createElement("div");e.className="oo-comment-panel open",e.style.pointerEvents="auto";const t=Bl(n.createdAt),r=ce(),i=r?n.authorId===r.uid:n.authorId==="local-user";e.innerHTML=`
    <div class="header">
      <h3>Annotation</h3>
      <button class="close-btn">&times;</button>
    </div>
    <div class="highlighted-text">
      <blockquote>"${Tt(n.text)}"</blockquote>
    </div>
    <div class="main-comment">
      <div class="author-info">
        <div class="avatar">${n.authorName.charAt(0).toUpperCase()}</div>
        <div>
          <div class="author-name">${Tt(n.authorName)}</div>
          <div class="timestamp">${t}</div>
        </div>
      </div>
      <div class="comment-text">${Tt(n.comment)}</div>
      <div class="reactions" id="reactions-container">
        ${n.reactions.map(g=>`
          <div class="reaction ${g.userReacted?"active":""}" data-emoji="${g.emoji}">
            <span class="emoji">${g.emoji}</span>
            <span class="count">${g.count}</span>
          </div>
        `).join("")}
        <div class="reaction add-reaction" id="add-reaction-btn">😀+</div>
      </div>
      ${i?'<button class="delete-btn" id="panel-delete-btn">🗑️ Delete Annotation</button>':""}
    </div>
    <div class="replies-section">
      ${n.replies.map(g=>`
        <div class="reply">
          <div class="author-info">
            <div class="avatar">${g.authorName.charAt(0).toUpperCase()}</div>
            <div>
              <div class="author-name">${Tt(g.authorName)}</div>
              <div class="timestamp">${Bl(g.createdAt)}</div>
            </div>
          </div>
          <div class="comment-text">${Tt(g.text)}</div>
        </div>
      `).join("")}
    </div>
    <div class="reply-input">
      <input type="text" placeholder="Add a reply..." />
      <button>➤</button>
    </div>
  `,e.addEventListener("click",g=>{g.stopPropagation()}),(h=e.querySelector(".close-btn"))==null||h.addEventListener("click",g=>{g.stopPropagation(),Os()}),(p=e.querySelector("#panel-delete-btn"))==null||p.addEventListener("click",g=>{g.stopPropagation(),confirm("Delete this annotation and all its comments?")&&(Hg(n.id),Os())});const o=e.querySelector(".reply-input input"),s=e.querySelector(".reply-input button"),l=()=>{const g=o.value.trim();if(!g)return;const b=ce(),P=(b==null?void 0:b.displayName)||"You",A={authorName:P,text:g,createdAt:Date.now()};n.replies.push(A),xt(),Wg(n,A);const O=e.querySelector(".replies-section");if(O){const F=`
        <div class="reply">
          <div class="author-info">
            <div class="avatar">${P.charAt(0).toUpperCase()}</div>
            <div>
              <div class="author-name">${Tt(P)}</div>
              <div class="timestamp">just now</div>
            </div>
          </div>
          <div class="comment-text">${Tt(g)}</div>
        </div>
      `;O.insertAdjacentHTML("beforeend",F)}o.value="",o.focus()};s==null||s.addEventListener("click",g=>{g.stopPropagation(),l()}),o==null||o.addEventListener("keypress",g=>{g.key==="Enter"&&(g.stopPropagation(),l())});const u=e.querySelector("#reactions-container");e.querySelectorAll(".reaction:not(.add-reaction)").forEach(g=>{g.addEventListener("click",b=>{b.stopPropagation();const P=g.dataset.emoji;if(!P)return;const A=n.reactions.find(O=>O.emoji===P);A&&(A.userReacted?(A.count--,A.userReacted=!1,A.count<=0&&(n.reactions=n.reactions.filter(O=>O.emoji!==P))):(A.count++,A.userReacted=!0),xt(),Ir(n,P),tu(n,u))})}),(m=e.querySelector("#add-reaction-btn"))==null||m.addEventListener("click",g=>{g.stopPropagation(),$g(n,g.target,u)}),dt.appendChild(e),Wt=e,cr=n,setTimeout(()=>o==null?void 0:o.focus(),100),setTimeout(()=>{document.addEventListener("click",zg)},50)}let ri=null;function $g(n,e,t){ql();const r=document.createElement("div");r.className="oo-emoji-picker",e.getBoundingClientRect(),r.style.bottom="40px",r.style.left="0",r.innerHTML=Zc.map(i=>`
    <button class="emoji-btn" data-emoji="${i}">${i}</button>
  `).join(""),r.querySelectorAll(".emoji-btn").forEach(i=>{i.addEventListener("click",o=>{o.stopPropagation();const s=i.dataset.emoji;if(!s)return;let l=n.reactions.find(u=>u.emoji===s);l?l.userReacted||(l.count++,l.userReacted=!0):n.reactions.push({emoji:s,count:1,userReacted:!0}),xt(),Ir(n,s),tu(n,t),ql()})}),t.style.position="relative",t.appendChild(r),ri=r,setTimeout(()=>{document.addEventListener("click",jg)},10)}function jg(n){ri&&!ri.contains(n.target)&&ql()}function ql(){document.removeEventListener("click",jg),ri&&(ri.remove(),ri=null)}function tu(n,e){var t;e&&(e.innerHTML=`
    ${n.reactions.map(r=>`
      <div class="reaction ${r.userReacted?"active":""}" data-emoji="${r.emoji}">
        <span class="emoji">${r.emoji}</span>
        <span class="count">${r.count}</span>
      </div>
    `).join("")}
    <div class="reaction add-reaction" id="add-reaction-btn">😀+</div>
  `,e.querySelectorAll(".reaction:not(.add-reaction)").forEach(r=>{r.addEventListener("click",i=>{i.stopPropagation();const o=r.dataset.emoji;if(!o)return;const s=n.reactions.find(l=>l.emoji===o);s&&(s.userReacted?(s.count--,s.userReacted=!1,s.count<=0&&(n.reactions=n.reactions.filter(l=>l.emoji!==o))):(s.count++,s.userReacted=!0),xt(),Ir(n,o),tu(n,e))})}),(t=e.querySelector("#add-reaction-btn"))==null||t.addEventListener("click",r=>{r.stopPropagation(),$g(n,r.target,e)}))}function zg(n){Wt&&!Wt.contains(n.target)&&Os()}function Os(){document.removeEventListener("click",zg),Wt&&(Wt.remove(),Wt=null),cr=null}function Tt(n){const e=document.createElement("div");return e.textContent=n,e.innerHTML}function Bl(n){const e=Math.floor((Date.now()-n)/1e3);return e<60?"just now":e<3600?`${Math.floor(e/60)}m ago`:e<86400?`${Math.floor(e/3600)}h ago`:e<604800?`${Math.floor(e/86400)}d ago`:new Date(n).toLocaleDateString()}function xt(){const n=Jn();localStorage.setItem(`oo_annotations_${n}`,JSON.stringify(We)),console.log("[OpenOverlay] Saved",We.length,"annotations locally")}async function FI(n){if(!Rr()){console.log("[OpenOverlay] Firestore not available, skipping cloud save");return}const e=ce(),t=Jn();console.log("[OpenOverlay] Saving annotation to cloud:",n.id,"pageKey:",t);const r={id:n.id,pageKey:t,text:n.text,contextBefore:n.contextBefore||"",contextAfter:n.contextAfter||"",anchorSelector:n.anchorSelector,anchorOffset:n.anchorOffset,focusSelector:n.focusSelector,focusOffset:n.focusOffset,comment:n.comment,color:n.color,authorId:(e==null?void 0:e.uid)||n.authorId,authorName:(e==null?void 0:e.displayName)||n.authorName,createdAt:n.createdAt,reactions:n.reactions.map(i=>({emoji:i.emoji,count:i.count,users:i.userReacted&&e?[e.uid]:[]})),replies:n.replies.map(i=>({authorId:"",authorName:i.authorName,text:i.text,createdAt:i.createdAt}))};await cI(t,r)}async function Ir(n,e){if(!Rr())return;const t=ce();if(!t)return;const r=Jn();await fI(r,n.id,e,t.uid)}async function Wg(n,e){if(!Rr())return;const t=ce(),r=Jn();await dI(r,n.id,{authorId:(t==null?void 0:t.uid)||"",authorName:(t==null?void 0:t.displayName)||e.authorName,text:e.text,createdAt:e.createdAt})}function UI(){const n=Jn(),e=localStorage.getItem(`oo_annotations_${n}`);if(e)try{We=JSON.parse(e),console.log("[OpenOverlay] Loaded",We.length,"annotations from localStorage")}catch{console.warn("[OpenOverlay] Failed to load annotations"),We=[]}qI()}async function qI(){if(!Rr()){console.log("[OpenOverlay] Firestore not available, skipping real-time sync");return}const n=Jn();if(console.log("[OpenOverlay] Setting up real-time sync for page:",n),!hI(n,t=>{Fd(t)})){console.log("[OpenOverlay] Real-time subscription failed, trying one-time fetch");const t=await Og(n);Fd(t)}}function Fd(n){const e=ce();if(console.log("[OpenOverlay] Processing",n.length,"cloud annotations"),n.length===0){console.log("[OpenOverlay] No cloud annotations found");return}const t=new Map;for(const i of We)t.set(i.id,i);for(const i of n){const o=t.get(i.id),s={id:i.id,text:i.text,contextBefore:i.contextBefore||"",contextAfter:i.contextAfter||"",anchorSelector:i.anchorSelector,anchorOffset:i.anchorOffset,focusSelector:i.focusSelector,focusOffset:i.focusOffset,comment:i.comment,color:i.color,authorId:i.authorId,authorName:i.authorName,createdAt:i.createdAt,reactions:(i.reactions||[]).map(l=>({emoji:l.emoji,count:l.count,userReacted:e?l.users.includes(e.uid):!1})),replies:(i.replies||[]).map(l=>({authorName:l.authorName,text:l.text,createdAt:l.createdAt}))};(!o||i.createdAt>=o.createdAt)&&t.set(i.id,s)}We=Array.from(t.values()),console.log("[OpenOverlay] Merged to",We.length,"total annotations");const r=Jn();localStorage.setItem(`oo_annotations_${r}`,JSON.stringify(We)),eu(),ka(),BI()}function BI(){if(Lt){const n=We.find(e=>e.id===(Lt==null?void 0:Lt.id));n&&(Lt=n)}if(Wt&&cr){const n=We.find(e=>e.id===(cr==null?void 0:cr.id));n&&$I(n)}}function $I(n){if(!Wt||!dt)return;const e=Wt.querySelector(".replies-section");e&&(e.innerHTML=n.replies.map(t=>`
    <div class="reply">
      <div class="author-info">
        <div class="avatar">${t.authorName.charAt(0).toUpperCase()}</div>
        <div>
          <div class="author-name">${Tt(t.authorName)}</div>
          <div class="timestamp">${Bl(t.createdAt)}</div>
        </div>
      </div>
      <div class="comment-text">${Tt(t.text)}</div>
    </div>
  `).join(""),cr=n,console.log("[OpenOverlay] Comment panel refreshed with",n.replies.length,"replies"))}async function Hg(n){const e=We.find(i=>i.id===n);if(!e)return;const t=ce();if(!(t?e.authorId===t.uid:e.authorId==="local-user")){console.warn("[OpenOverlay] Cannot delete: not the author");return}if(We=We.filter(i=>i.id!==n),xt(),Rr()){const i=Jn();await uI(i,n)}qn.has(n)&&(qn.delete(n),Gg(n)),eu(),ka(),console.log("[OpenOverlay] Annotation deleted:",n)}function jI(n){if(qn.has(n))qn.delete(n),Gg(n),console.log("[OpenOverlay] Removed bookmark");else{qn.add(n);const e=We.find(t=>t.id===n);e&&(zI(e),console.log("[OpenOverlay] Added bookmark"))}}function zI(n){const e=Pa();e.some(t=>t.id===n.id)||(e.push({id:n.id,pageUrl:window.location.href,pageTitle:document.title,text:n.text,comment:n.comment,authorName:n.authorName,bookmarkedAt:Date.now()}),localStorage.setItem("oo_bookmarks",JSON.stringify(e)))}function Gg(n){const e=Pa().filter(t=>t.id!==n);localStorage.setItem("oo_bookmarks",JSON.stringify(e))}function Pa(){try{return JSON.parse(localStorage.getItem("oo_bookmarks")||"[]")}catch{return[]}}function WI(){const n=Pa();qn=new Set(n.map(e=>e.id))}function Jn(){return btoa(window.location.href).slice(0,32)}let Hi=null,C=null,ms=!1,tn="none",Kg="solid",Yg="normal",Qg="none",io=!1,ii=!1,De="normal",ko="",uo="play",Ud="spawn",$l=!1,Ut=!1;const HI=["#ff3366","#ff6b35","#f59e0b","#22c55e","#06b6d4","#3b82f6","#8b5cf6","#ec4899","#ef4444","#000000","#ffffff","#6b7280"],GI=[{id:"solid",label:"━",title:"Solid"},{id:"spray",label:"░",title:"Spray"},{id:"dots",label:"•••",title:"Dots"},{id:"square",label:"▬",title:"Square"},{id:"rainbow",label:"🌈",title:"Rainbow"},{id:"glow",label:"✦",title:"Glow"}],KI=[{id:"normal",label:"A",title:"Normal"},{id:"rainbow",label:"🌈",title:"Rainbow"},{id:"aged",label:"🏚️",title:"Aged"}],YI=[{id:"none",label:"✏️",title:"Freehand"},{id:"line",label:"╱",title:"Line"},{id:"rectangle",label:"▢",title:"Rectangle"},{id:"circle",label:"○",title:"Circle"},{id:"triangle",label:"△",title:"Triangle"},{id:"star",label:"☆",title:"Star"}],QI=`
  * {
    box-sizing: border-box;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  }

  .fab-container {
    all: initial;
    position: fixed !important;
    right: 18px !important;
    bottom: 18px !important;
    z-index: 2147483647 !important;
    display: flex !important;
    flex-direction: column-reverse !important;
    align-items: center !important;
    gap: 8px !important;
    pointer-events: auto !important;
    touch-action: none !important;
    visibility: visible !important;
    opacity: 1 !important;
    transform: none !important;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif !important;
  }

  .fab-container.dragging {
    opacity: 0.8;
  }

  .fab-container.dragging .fab {
    cursor: grabbing;
  }

  .fab {
    all: initial;
    width: 56px !important;
    height: 56px !important;
    min-width: 56px !important;
    min-height: 56px !important;
    border-radius: 50% !important;
    border: none !important;
    background: rgba(255, 255, 255, 0.95) !important;
    color: #222 !important;
    font-size: 20px !important;
    cursor: pointer !important;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15) !important;
    transition: transform 0.15s, background 0.15s !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    visibility: visible !important;
    opacity: 1 !important;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif !important;
  }

  .fab:hover {
    transform: scale(1.05);
  }

  .fab.open {
    background: #22c55e;
    color: white;
  }

  .mini {
    width: 44px;
    height: 44px;
    border-radius: 50%;
    border: none;
    background: #fff;
    color: #222;
    font-size: 18px;
    cursor: pointer;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.12);
    transition: transform 0.15s, opacity 0.15s;
    opacity: 0;
    transform: scale(0.5);
    pointer-events: none;
  }

  .mini.show {
    opacity: 1;
    transform: scale(1);
    pointer-events: auto;
  }

  .mini:hover {
    transform: scale(1.1);
  }

  .mini.active {
    background: #22c55e;
    color: white;
  }

  .toolbar {
    position: fixed;
    right: 90px;
    bottom: 18px;
    background: #111;
    color: #fff;
    padding: 10px;
    border-radius: 10px;
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.3);
    display: none;
    flex-direction: column;
    gap: 8px;
    align-items: stretch;
    pointer-events: auto;
    z-index: 2147483647;
    max-width: 320px;
  }

  .toolbar.game-mode {
    flex-direction: column;
    align-items: stretch;
  }

  .toolbar-drag-handle {
    cursor: grab;
    padding: 2px 8px;
    color: #666;
    font-size: 12px;
    user-select: none;
    text-align: center;
  }

  .toolbar-drag-handle:hover {
    color: #999;
  }

  .toolbar-drag-handle:active {
    cursor: grabbing;
  }

  .toolbar.game-mode .toolbar-drag-handle {
    align-self: center;
    margin-bottom: -4px;
  }

  .toolbar.show {
    display: flex;
  }

  .toolbar-row {
    display: flex;
    align-items: center;
    gap: 6px;
    flex-wrap: wrap;
  }

  .toolbar-section {
    display: flex;
    align-items: center;
    gap: 4px;
  }

  .toolbar-divider {
    display: none;
  }

  .toolbar label {
    font-size: 11px;
    color: #888;
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }

  .toolbar input[type="color"] {
    width: 24px;
    height: 24px;
    border: 2px solid #333;
    border-radius: 50%;
    cursor: pointer;
    padding: 0;
    background: none;
    flex-shrink: 0;
  }

  .toolbar input[type="color"]::-webkit-color-swatch-wrapper {
    padding: 0;
  }

  .toolbar input[type="color"]::-webkit-color-swatch {
    border: none;
    border-radius: 50%;
  }

  .toolbar input[type="range"] {
    height: 6px;
    -webkit-appearance: none;
    background: #333;
    border-radius: 3px;
  }

  .toolbar input[type="range"]::-webkit-slider-thumb {
    -webkit-appearance: none;
    width: 18px;
    height: 18px;
    background: #fff;
    border-radius: 50%;
    cursor: pointer;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
  }

  .quick-colors {
    display: grid;
    grid-template-columns: repeat(4, 14px);
    gap: 2px;
  }

  .quick-color {
    width: 14px;
    height: 14px;
    border-radius: 50%;
    border: 2px solid transparent;
    cursor: pointer;
    transition: transform 0.1s;
  }

  .quick-color:hover {
    transform: scale(1.15);
  }

  .quick-color.active {
    border-color: #fff;
    box-shadow: 0 0 0 1px #000;
  }

  .quick-color[data-color="#ffffff"] {
    border-color: #ccc;
  }

  .quick-color[data-color="#000000"] {
    border-color: #333;
  }

  .toolbar.game-mode .quick-colors {
    grid-template-columns: repeat(4, 14px);
  }

  .brush-styles {
    display: flex;
    gap: 2px;
  }

  .brush-btn {
    width: 28px;
    height: 28px;
    border: none;
    background: #222;
    color: #aaa;
    border-radius: 6px;
    cursor: pointer;
    font-size: 14px;
    transition: background 0.1s;
  }

  .brush-btn:hover {
    background: #333;
  }

  .brush-btn.active {
    background: #22c55e;
    color: white;
  }

  .tool-btn {
    width: 32px;
    height: 32px;
    border: none;
    background: #222;
    color: #aaa;
    border-radius: 8px;
    cursor: pointer;
    font-size: 16px;
    transition: background 0.1s;
  }

  .tool-btn:hover {
    background: #333;
  }

  .tool-btn.active {
    background: #ef4444;
    color: white;
  }

  .shape-tools {
    display: flex;
    gap: 2px;
  }

  .shape-btn {
    width: 28px;
    height: 28px;
    border: none;
    background: #222;
    color: #aaa;
    border-radius: 6px;
    cursor: pointer;
    font-size: 14px;
    transition: background 0.1s;
  }

  .shape-btn:hover {
    background: #333;
  }

  .shape-btn.active {
    background: #8b5cf6;
    color: white;
  }

  .fill-btn {
    width: 28px;
    height: 28px;
    border: none;
    background: #222;
    color: #aaa;
    border-radius: 6px;
    cursor: pointer;
    font-size: 16px;
    margin-left: 4px;
  }

  .fill-btn:hover {
    background: #333;
  }

  .fill-btn.active {
    background: #f59e0b;
    color: white;
  }

  .toolbar button.action-btn {
    padding: 5px 10px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 11px;
    font-weight: 600;
    transition: background 0.1s;
  }

  .btn-undo {
    background: #333;
    color: #fff;
  }

  .btn-undo:hover {
    background: #444;
  }

  .btn-clear {
    background: #333;
    color: #fff;
  }

  .btn-clear:hover {
    background: #444;
  }

  .btn-save {
    background: #22c55e;
    color: white;
  }

  .btn-save:hover {
    background: #16a34a;
  }

  .btn-cancel {
    background: #333;
    color: white;
  }

  .btn-cancel:hover {
    background: #444;
  }

  .size-display {
    font-size: 11px;
    color: #888;
    min-width: 20px;
    text-align: center;
  }

  .opacity-display {
    font-size: 11px;
    color: #888;
    min-width: 28px;
    text-align: center;
  }

  .draw-controls, .text-controls {
    display: none;
    flex-direction: column;
    gap: 6px;
  }

  .draw-controls.active, .text-controls.active {
    display: flex;
  }

  .text-input {
    background: #222;
    border: 1px solid #333;
    border-radius: 6px;
    color: #fff;
    padding: 6px 10px;
    font-size: 13px;
    flex: 1;
    min-width: 100px;
    font-family: inherit;
  }

  .text-input:focus {
    outline: none;
    border-color: #22c55e;
  }

  .text-input::placeholder {
    color: #666;
  }

  .text-styles {
    display: flex;
    gap: 2px;
  }

  .text-style-btn {
    width: 32px;
    height: 32px;
    border: none;
    background: #222;
    color: #aaa;
    border-radius: 6px;
    cursor: pointer;
    font-size: 14px;
    transition: background 0.1s;
  }

  .text-style-btn:hover {
    background: #333;
  }

  .text-style-btn.active {
    background: #22c55e;
    color: white;
  }

  .place-hint {
    font-size: 11px;
    color: #666;
    font-style: italic;
  }

  .game-controls {
    display: none;
    flex-direction: column;
    gap: 8px;
  }

  .game-controls.active {
    display: flex;
  }

  .game-row {
    display: flex;
    align-items: center;
    gap: 6px;
    justify-content: center;
  }

  .game-actions {
    display: flex;
    gap: 4px;
    margin-left: auto;
  }

  .game-colors {
    display: flex;
    gap: 3px;
  }

  .toolbar.game-mode .drawing-only {
    display: none !important;
  }

  .toolbar.game-mode > .toolbar-row,
  .toolbar.game-mode > .toolbar-section,
  .toolbar.game-mode > .toolbar-divider {
    display: none !important;
  }

  .toolbar.game-mode > .toolbar-drag-handle,
  .toolbar.game-mode > .game-controls {
    display: flex !important;
  }

  .char-style-toggle {
    display: flex;
    background: #222;
    border-radius: 4px;
    padding: 2px;
  }

  .char-style-btn {
    padding: 3px 6px;
    border: none;
    background: transparent;
    border-radius: 3px;
    cursor: pointer;
    font-size: 14px;
    transition: background 0.1s;
  }

  .char-style-btn:hover {
    background: #333;
  }

  .char-style-btn.active {
    background: #22c55e;
  }

  .char-customize-select {
    background: #222;
    color: #fff;
    border: 1px solid #333;
    border-radius: 4px;
    padding: 3px 4px;
    font-size: 14px;
    cursor: pointer;
    min-width: 36px;
    text-align: center;
  }

  .char-customize-select:hover {
    border-color: #555;
  }

  .char-customize-select:focus {
    outline: none;
    border-color: #22c55e;
  }

  .screen-name-section {
    margin: 16px 0;
    padding: 12px;
    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
    border-radius: 10px;
    border: 2px solid #0f3460;
  }

  .screen-name-label {
    display: block;
    font-size: 13px;
    color: #e94560;
    margin-bottom: 8px;
    text-transform: uppercase;
    letter-spacing: 1px;
    font-weight: bold;
    text-align: center;
  }

  .screen-name-input {
    width: 100%;
    background: #0a0a15;
    color: #fff;
    border: 2px solid #e94560;
    border-radius: 8px;
    padding: 10px 14px;
    font-size: 18px;
    font-family: "Comic Sans MS", "Chalkboard SE", cursive;
    text-align: center;
    box-sizing: border-box;
  }

  .screen-name-input::placeholder {
    color: #666;
    font-style: italic;
  }

  .screen-name-input:focus {
    outline: none;
    border-color: #22c55e;
    background: #111;
    box-shadow: 0 0 10px rgba(233, 69, 96, 0.3);
  }

  .game-mode-toggle {
    display: flex;
    background: #222;
    border-radius: 6px;
    padding: 2px;
  }

  .game-mode-btn {
    padding: 4px 8px;
    border: none;
    background: transparent;
    color: #888;
    border-radius: 4px;
    cursor: pointer;
    font-size: 14px;
    transition: background 0.1s, color 0.1s;
  }

  .game-mode-btn:hover {
    color: #fff;
  }

  .game-mode-btn.active {
    background: #22c55e;
    color: white;
  }

  .build-tools-section {
    display: flex;
    align-items: center;
  }

  .game-tools {
    display: flex;
    gap: 2px;
  }

  .game-tool-btn {
    width: 28px;
    height: 28px;
    padding: 0;
    border: none;
    background: #222;
    color: #aaa;
    border-radius: 4px;
    cursor: pointer;
    font-size: 13px;
    transition: background 0.1s;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .game-tool-btn:hover {
    background: #333;
  }

  .game-tool-btn.active {
    background: #3b82f6;
    color: white;
  }

  .multiplayer-btn {
    padding: 4px 8px;
    border: none;
    background: #7c3aed;
    color: #fff;
    border-radius: 4px;
    cursor: pointer;
    font-size: 11px;
    font-weight: 600;
    transition: background 0.1s;
  }

  .multiplayer-btn:hover {
    background: #6d28d9;
  }

  .multiplayer-btn.active {
    background: #22c55e;
  }

  .mini.game-btn {
    background: #8b5cf6;
    color: white;
  }

  .mini.game-btn.active {
    background: #22c55e;
  }

  /* Profile button */
  .mini.profile-btn {
    padding: 0;
    overflow: hidden;
  }

  .mini.profile-btn img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    border-radius: 50%;
  }

  /* Profile modal */
  .profile-modal {
    position: fixed;
    bottom: 80px;
    right: 20px;
    width: 320px;
    max-height: calc(100vh - 100px);
    background: #111;
    border-radius: 16px;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
    display: none;
    flex-direction: column;
    overflow-y: auto;
    z-index: 2147483647;
    pointer-events: auto;
  }

  .profile-modal.show {
    display: flex;
  }

  .profile-close {
    position: absolute;
    top: 10px;
    right: 10px;
    width: 28px;
    height: 28px;
    border: none;
    background: #333;
    color: #fff;
    border-radius: 50%;
    font-size: 18px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 10;
  }

  .profile-close:hover {
    background: #444;
  }

  .profile-header {
    padding: 20px;
    display: flex;
    align-items: center;
    gap: 16px;
    border-bottom: 1px solid #333;
  }

  .profile-avatar {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    object-fit: cover;
    border: 2px solid #3b82f6;
  }

  .profile-info {
    flex: 1;
  }

  .profile-name {
    font-size: 18px;
    font-weight: bold;
    color: #fff;
    margin: 0 0 4px 0;
  }

  .profile-email {
    font-size: 12px;
    color: #888;
    margin: 0;
  }

  .profile-stats {
    display: flex;
    gap: 20px;
    padding: 16px 20px;
    border-bottom: 1px solid #333;
  }

  .profile-stat {
    text-align: center;
    cursor: pointer;
  }

  .profile-stat:hover {
    opacity: 0.8;
  }

  .profile-stat-value {
    font-size: 20px;
    font-weight: bold;
    color: #fff;
  }

  .profile-stat-label {
    font-size: 11px;
    color: #888;
    text-transform: uppercase;
  }

  .profile-bio {
    padding: 16px 20px;
    color: #ccc;
    font-size: 14px;
    border-bottom: 1px solid #333;
  }

  .profile-bio-empty {
    color: #666;
    font-style: italic;
  }

  .profile-actions {
    padding: 16px 20px;
    display: flex;
    gap: 10px;
  }

  .feedback-section {
    padding: 12px 20px;
    border-bottom: 1px solid #333;
    background: linear-gradient(135deg, rgba(34, 197, 94, 0.1) 0%, rgba(59, 130, 246, 0.1) 100%);
  }

  .feedback-header {
    color: #fff;
    font-size: 13px;
    font-weight: 600;
    margin-bottom: 10px;
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .beta-badge {
    background: linear-gradient(135deg, #22c55e, #3b82f6);
    color: white;
    font-size: 9px;
    font-weight: 700;
    padding: 2px 6px;
    border-radius: 4px;
    letter-spacing: 0.5px;
  }

  .feedback-form {
    display: flex;
    flex-direction: column;
    gap: 8px;
  }

  .feedback-select {
    background: #222;
    border: 1px solid #333;
    border-radius: 6px;
    color: #fff;
    padding: 8px 10px;
    font-size: 13px;
    cursor: pointer;
  }

  .feedback-select:focus {
    outline: none;
    border-color: #22c55e;
  }

  .feedback-textarea {
    background: #222;
    border: 1px solid #333;
    border-radius: 6px;
    color: #fff;
    padding: 8px 10px;
    font-size: 13px;
    resize: none;
    font-family: inherit;
  }

  .feedback-textarea:focus {
    outline: none;
    border-color: #22c55e;
  }

  .feedback-textarea::placeholder {
    color: #666;
  }

  .feedback-submit {
    background: #22c55e;
    color: white;
    border: none;
    border-radius: 6px;
    padding: 8px 16px;
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
    transition: background 0.2s;
  }

  .feedback-submit:hover {
    background: #16a34a;
  }

  .feedback-submit:disabled {
    background: #333;
    color: #666;
    cursor: not-allowed;
  }

  .feedback-success {
    color: #22c55e;
    font-size: 13px;
    text-align: center;
    padding: 10px;
  }

  .profile-settings {
    padding: 12px 20px;
    border-bottom: 1px solid #333;
  }

  .profile-settings-header {
    color: #888;
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 8px;
  }

  .profile-setting-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 8px 0;
  }

  .profile-setting-label {
    color: #ccc;
    font-size: 14px;
  }

  .profile-contributors {
    margin-top: 16px;
    padding-top: 12px;
    border-top: 1px solid #333;
  }

  .profile-contributors-header {
    color: #888;
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 8px;
  }

  .contributors-list {
    max-height: 150px;
    overflow-y: auto;
  }

  .no-contributors {
    color: #666;
    font-size: 13px;
    font-style: italic;
    padding: 8px 0;
  }

  .contributor-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 6px 0;
    gap: 10px;
  }

  .contributor-info {
    display: flex;
    align-items: center;
    gap: 8px;
    flex: 1;
    min-width: 0;
  }

  .contributor-avatar {
    width: 24px;
    height: 24px;
    border-radius: 50%;
    background: #333;
    object-fit: cover;
    flex-shrink: 0;
  }

  .contributor-name {
    color: #ddd;
    font-size: 13px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .contributor-toggle {
    flex-shrink: 0;
  }

  .contributor-actions {
    display: flex;
    align-items: center;
    gap: 8px;
    flex-shrink: 0;
  }

  .follow-btn {
    padding: 4px 10px;
    border-radius: 12px;
    border: none;
    font-size: 11px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s;
  }

  .follow-btn.follow {
    background: #3b82f6;
    color: white;
  }

  .follow-btn.follow:hover {
    background: #2563eb;
  }

  .follow-btn.following {
    background: #333;
    color: #aaa;
  }

  .follow-btn.following:hover {
    background: #ef4444;
    color: white;
  }

  .toggle-switch {
    position: relative;
    width: 44px;
    height: 24px;
    background: #333;
    border-radius: 12px;
    cursor: pointer;
    transition: background 0.2s;
  }

  .toggle-switch.active {
    background: #22c55e;
  }

  .toggle-switch::after {
    content: '';
    position: absolute;
    top: 2px;
    left: 2px;
    width: 20px;
    height: 20px;
    background: #fff;
    border-radius: 50%;
    transition: transform 0.2s;
  }

  .toggle-switch.active::after {
    transform: translateX(20px);
  }

  .toggle-switch.small {
    width: 32px;
    height: 18px;
    border-radius: 9px;
  }

  .toggle-switch.small::after {
    width: 14px;
    height: 14px;
  }

  .toggle-switch.small.active::after {
    transform: translateX(14px);
  }

  .profile-bookmarks {
    padding: 12px 20px;
    border-bottom: 1px solid #333;
    max-height: 200px;
    overflow-y: auto;
  }

  .profile-bookmarks-header {
    color: #888;
    font-size: 12px;
    text-transform: uppercase;
    margin-bottom: 10px;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .profile-bookmarks-count {
    background: #333;
    padding: 2px 8px;
    border-radius: 10px;
    font-size: 11px;
  }

  .bookmark-item {
    background: #222;
    border-radius: 8px;
    padding: 10px;
    margin-bottom: 8px;
    cursor: pointer;
    transition: background 0.15s;
  }

  .bookmark-item:hover {
    background: #333;
  }

  .bookmark-quote {
    color: #fff;
    font-size: 13px;
    margin-bottom: 4px;
    font-style: italic;
  }

  .bookmark-meta {
    color: #888;
    font-size: 11px;
  }

  .no-bookmarks {
    color: #666;
    font-size: 13px;
    font-style: italic;
    text-align: center;
    padding: 20px;
  }

  .profile-btn {
    flex: 1;
    padding: 10px 16px;
    border: none;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    transition: background 0.15s;
  }

  .profile-btn.primary {
    background: #3b82f6;
    color: white;
  }

  .profile-btn.primary:hover {
    background: #2563eb;
  }

  .profile-btn.secondary {
    background: #333;
    color: #fff;
  }

  .profile-btn.secondary:hover {
    background: #444;
  }

  .profile-btn.danger {
    background: #ef4444;
    color: white;
  }

  .profile-btn.danger:hover {
    background: #dc2626;
  }

  .login-prompt {
    padding: 40px 20px;
    text-align: center;
  }

  .login-prompt p {
    color: #888;
    margin: 0 0 20px 0;
  }

  .login-btn {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    padding: 12px 24px;
    background: #fff;
    color: #333;
    border: none;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
  }

  .login-btn:hover {
    background: #f0f0f0;
  }

  .login-btn img {
    width: 20px;
    height: 20px;
  }
`;function XI(){if(console.log("[OpenOverlay] initUI starting..."),!document.body){console.error("[OpenOverlay] No document.body!");return}Hi=document.createElement("div"),Hi.id="openoverlay-ui",Hi.style.cssText=`
    all: initial;
    position: fixed !important;
    top: 0 !important;
    left: 0 !important;
    right: 0 !important;
    bottom: 0 !important;
    width: 100vw !important;
    height: 100vh !important;
    z-index: 2147483647 !important;
    pointer-events: none !important;
    overflow: visible !important;
    display: block !important;
    visibility: visible !important;
    opacity: 1 !important;
    transform: none !important;
    margin: 0 !important;
    padding: 0 !important;
    border: none !important;
    box-sizing: border-box !important;
  `,C=Hi.attachShadow({mode:"open"});const n=document.createElement("style");n.textContent=QI,C.appendChild(n);const e=document.createElement("div");e.className="fab-container";const t=document.createElement("button");t.className="fab",t.textContent="•••",t.title="OpenOverlay",t.onclick=()=>{var A;Ut&&(Ut=!1,(A=C==null?void 0:C.querySelector("#oo-profile-modal"))==null||A.classList.remove("show")),o0()},e.appendChild(t);const r=document.createElement("button");r.className="mini",r.textContent="✏️",r.title="Draw",r.onclick=()=>cl("draw"),e.appendChild(r);const i=document.createElement("button");i.className="mini",i.textContent="T",i.title="Text",i.onclick=()=>cl("text"),e.appendChild(i);const o=document.createElement("button");o.className="mini game-btn",o.textContent="🎮",o.title="Game",o.onclick=()=>cl("game"),e.appendChild(o);const s=document.createElement("button");s.className="mini profile-btn",s.id="oo-profile-btn",s.textContent="⚙️",s.title="Settings & Profile",s.onclick=r0,e.appendChild(s),C.appendChild(e);let l=!1,u=0,h=0,p=18,m=18;const g=localStorage.getItem("oo_fab_position");if(g)try{const A=JSON.parse(g);e.style.right=A.right+"px",e.style.bottom=A.bottom+"px",p=A.right,m=A.bottom}catch{}t.addEventListener("pointerdown",A=>{if(A.shiftKey){A.preventDefault(),l=!0,u=A.clientX,h=A.clientY;const O=getComputedStyle(e);p=parseInt(O.right)||18,m=parseInt(O.bottom)||18,e.classList.add("dragging"),t.setPointerCapture(A.pointerId)}}),t.addEventListener("pointermove",A=>{if(!l)return;A.preventDefault();const O=u-A.clientX,F=h-A.clientY,U=Math.max(10,Math.min(window.innerWidth-70,p+O)),V=Math.max(10,Math.min(window.innerHeight-70,m+F));e.style.right=U+"px",e.style.bottom=V+"px"}),t.addEventListener("pointerup",A=>{if(l){l=!1,e.classList.remove("dragging"),t.releasePointerCapture(A.pointerId);const O=getComputedStyle(e);localStorage.setItem("oo_fab_position",JSON.stringify({right:parseInt(O.right)||18,bottom:parseInt(O.bottom)||18}))}});const b=document.createElement("div");b.className="profile-modal",b.id="oo-profile-modal",b.innerHTML=`
    <button class="profile-close" id="profile-close-btn">&times;</button>
    <div class="login-prompt" id="login-prompt">
      <p>Sign in to save your drawings and follow other users</p>
      <button class="login-btn" id="google-login-btn">
        <svg width="20" height="20" viewBox="0 0 24 24">
          <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
          <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
          <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
          <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
        </svg>
        Sign in with Google
      </button>
    </div>
    <div class="profile-content" id="profile-content" style="display: none;">
      <div class="profile-header">
        <img class="profile-avatar" id="profile-avatar" src="" alt="Profile">
        <div class="profile-info">
          <h3 class="profile-name" id="profile-name">User Name</h3>
          <p class="profile-email" id="profile-email">email@example.com</p>
        </div>
      </div>
      <div class="screen-name-section">
        <label class="screen-name-label">Your Game Name</label>
        <input type="text" class="screen-name-input" id="oo-screen-name" placeholder="Pick a nickname!" maxlength="12">
      </div>
      <div class="profile-stats">
        <div class="profile-stat" id="followers-stat">
          <div class="profile-stat-value" id="followers-count">0</div>
          <div class="profile-stat-label">Followers</div>
        </div>
        <div class="profile-stat" id="following-stat">
          <div class="profile-stat-value" id="following-count">0</div>
          <div class="profile-stat-label">Following</div>
        </div>
      </div>
      <div class="profile-bio" id="profile-bio">
        <span class="profile-bio-empty">No bio yet</span>
      </div>
      <div class="profile-settings">
        <div class="profile-settings-header">Drawing Visibility</div>
        <div class="profile-setting-row">
          <span class="profile-setting-label">Show all drawings</span>
          <div class="toggle-switch active" id="toggle-all-drawings" title="Master toggle - hide all drawings"></div>
        </div>
        <div class="profile-setting-row">
          <span class="profile-setting-label">My drawings</span>
          <div class="toggle-switch active" id="toggle-my-drawings" title="Show or hide your own drawings"></div>
        </div>
        <div class="profile-setting-row">
          <span class="profile-setting-label">Only people I follow</span>
          <div class="toggle-switch" id="toggle-following-only" title="Show only drawings from users you follow"></div>
        </div>
        <div class="profile-contributors" id="contributors-section">
          <div class="profile-contributors-header">Contributors on this page</div>
          <div id="contributors-list" class="contributors-list">
            <div class="no-contributors">No other contributors yet</div>
          </div>
        </div>
      </div>
      <div class="profile-bookmarks" id="profile-bookmarks">
        <div class="profile-bookmarks-header">
          Bookmarks <span class="profile-bookmarks-count" id="bookmarks-count">0</span>
        </div>
        <div id="bookmarks-list"></div>
      </div>
      <div class="feedback-section">
        <div class="feedback-header">
          <span class="beta-badge">BETA</span>
          Send Feedback
        </div>
        <div class="feedback-form" id="feedback-form">
          <select id="feedback-type" class="feedback-select">
            <option value="bug">🐛 Bug Report</option>
            <option value="feature">💡 Feature Request</option>
            <option value="other">💬 Other Feedback</option>
          </select>
          <textarea id="feedback-text" class="feedback-textarea" placeholder="Describe the issue or suggestion..." rows="3"></textarea>
          <button class="feedback-submit" id="feedback-submit">Send Feedback</button>
        </div>
        <div class="feedback-success" id="feedback-success" style="display:none;">
          ✓ Thanks for your feedback!
        </div>
      </div>
      <div class="profile-actions">
        <button class="profile-btn danger" id="signout-btn">Sign Out</button>
      </div>
    </div>
  `,C.appendChild(b);const P=document.createElement("div");P.className="toolbar",P.id="oo-toolbar",P.innerHTML=`
    <!-- DRAG HANDLE -->
    <div class="toolbar-drag-handle" id="oo-drag-handle" title="Drag to move">⠿</div>

    <!-- DRAW MODE CONTROLS -->
    <div class="draw-controls active" id="draw-controls">
      <!-- Row 1: Brushes + Tools -->
      <div class="toolbar-row">
        <div class="brush-styles" id="oo-brushes">
          ${GI.map(A=>`
            <button class="brush-btn ${A.id==="solid"?"active":""}"
                    data-brush="${A.id}" title="${A.title}">${A.label}</button>
          `).join("")}
        </div>
        <button class="tool-btn" id="oo-eraser" title="Eraser">🧹</button>
        <button class="tool-btn" id="oo-layer-bg" title="Background">⬇️</button>
        <button class="tool-btn" id="oo-layer-fg" title="Foreground">⬆️</button>
      </div>
      <!-- Row 2: Shapes -->
      <div class="toolbar-row">
        <div class="shape-tools" id="oo-shapes">
          ${YI.map(A=>`
            <button class="shape-btn ${A.id==="none"?"active":""}"
                    data-shape="${A.id}" title="${A.title}">${A.label}</button>
          `).join("")}
        </div>
        <button class="fill-btn" id="oo-fill-toggle" title="Toggle fill">◧</button>
      </div>
    </div>

    <!-- TEXT MODE CONTROLS -->
    <div class="text-controls" id="text-controls">
      <div class="toolbar-row">
        <input type="text" class="text-input" id="oo-text-input" placeholder="Type text...">
        <div class="text-styles" id="oo-text-styles">
          ${KI.map(A=>`
            <button class="text-style-btn ${A.id==="normal"?"active":""}"
                    data-style="${A.id}" title="${A.title}">${A.label}</button>
          `).join("")}
        </div>
        <button class="tool-btn" id="oo-text-layer-bg" title="Background (behind character)">⬇️</button>
        <button class="tool-btn" id="oo-text-layer-fg" title="Foreground (in front of character)">⬆️</button>
      </div>
      <span class="place-hint">Click page to place (default: regular layer)</span>
    </div>

    <!-- GAME MODE CONTROLS -->
    <div class="game-controls" id="game-controls">
      <!-- Row 1: Mode + Character + Multiplayer -->
      <div class="game-row">
        <div class="game-mode-toggle">
          <button class="game-mode-btn active" data-mode="play" data-playmode="explore" title="Explore">🚶</button>
          <button class="game-mode-btn" data-mode="play" data-playmode="race" title="Race">🏃</button>
          <button class="game-mode-btn" data-mode="build" title="Build">🔨</button>
        </div>
        <button class="multiplayer-btn" id="oo-multiplayer-setup" title="Setup for multiplayer (resize window)">👥 MP</button>
        <button class="multiplayer-btn" id="oo-tag-game" title="Start or join tag game">🏷️ Tag</button>
        <div class="char-style-toggle">
          <button class="char-style-btn active" id="oo-char-boy" title="Boy">👦</button>
          <button class="char-style-btn" id="oo-char-girl" title="Girl">👧</button>
        </div>
        <select class="char-customize-select" id="oo-hat-select" title="Hat">
          <option value="none">🎩</option>
          <option value="cap">🧢</option>
          <option value="tophat">🎩</option>
          <option value="crown">👑</option>
          <option value="beanie">🧶</option>
          <option value="party">🎉</option>
        </select>
        <select class="char-customize-select" id="oo-accessory-select" title="Face">
          <option value="none">😊</option>
          <option value="glasses">👓</option>
          <option value="sunglasses">🕶️</option>
          <option value="mustache">🥸</option>
          <option value="beard">🧔</option>
          <option value="mask">🦸</option>
        </select>
      </div>

      <!-- Row 2: Build Tools (hidden by default, shown when build mode selected) -->
      <div class="game-row build-tools-section" style="display: none;">
        <div class="game-tools" id="game-tools">
          <button class="game-tool-btn" data-tool="select" title="Select">✋</button>
          <button class="game-tool-btn active" data-tool="spawn" title="Spawn">👤</button>
          <button class="game-tool-btn" data-tool="start" title="Start">🏁</button>
          <button class="game-tool-btn" data-tool="finish" title="Finish">🏆</button>
          <button class="game-tool-btn" data-tool="checkpoint" title="Checkpoint">🚩</button>
          <button class="game-tool-btn" data-tool="trampoline" title="Bounce">🔶</button>
          <button class="game-tool-btn" data-tool="speedBoost" title="Speed">💨</button>
          <button class="game-tool-btn" data-tool="highJump" title="Jump">🦘</button>
          <button class="game-tool-btn" data-tool="spike" title="Spike">🔺</button>
        </div>
      </div>

      <!-- Row 3: Colors + Actions -->
      <div class="game-row">
        <input type="color" id="oo-game-color" value="#ff3366" title="Color">
        <div class="quick-colors game-colors" id="oo-game-quick-colors"></div>
        <div class="game-actions">
          <button class="action-btn btn-undo" id="oo-game-undo" title="Undo">↩</button>
          <button class="action-btn btn-clear" id="oo-game-clear" title="Clear">🗑</button>
          <button class="action-btn btn-cancel" id="oo-game-cancel">✕</button>
          <button class="action-btn btn-save" id="oo-game-save">✓</button>
        </div>
      </div>
    </div>

    <!-- SHARED CONTROLS -->
    <!-- Color Row -->
    <div class="toolbar-row">
      <input type="color" id="oo-color" value="#ff3366" title="Color">
      <div class="quick-colors" id="oo-quick-colors">
        ${HI.map((A,O)=>`
          <div class="quick-color ${O===0?"active":""}"
               data-color="${A}"
               style="background: ${A}"
               title="${A}"></div>
        `).join("")}
      </div>
    </div>

    <!-- Size/Opacity Row (hidden in game mode) -->
    <div class="toolbar-row drawing-only">
      <label>Size</label>
      <input type="range" id="oo-size" min="1" max="150" value="24" style="width: 80px;">
      <span class="size-display" id="oo-size-display">24</span>
      <label style="margin-left: 8px;">Op</label>
      <input type="range" id="oo-opacity" min="10" max="100" value="100" style="width: 60px;">
      <span class="opacity-display" id="oo-opacity-display">100%</span>
    </div>

    <!-- Actions Row -->
    <div class="toolbar-row">
      <button class="action-btn btn-undo" id="oo-undo" title="Undo">↩</button>
      <button class="action-btn btn-clear" id="oo-clear" title="Clear All">🗑</button>
      <div style="flex: 1;"></div>
      <button class="action-btn btn-cancel" id="oo-cancel">Cancel</button>
      <button class="action-btn btn-save" id="oo-save">Save</button>
    </div>
  `,C.appendChild(P),JI(P),document.body.appendChild(Hi),document.addEventListener("oo:hidetoolbar",()=>{const A=C==null?void 0:C.querySelector(".toolbar");A==null||A.classList.remove("show"),tn="none",uo="play";const O=C==null?void 0:C.querySelectorAll(".mini");O==null||O.forEach(F=>F.classList.remove("active"))}),console.log("[OpenOverlay] UI initialized")}function JI(n){var xe,rt,Or,_n,vt,bt,it,ue,ke,ye,Je,Kt,Nr,Dr;n.querySelectorAll(".brush-btn").forEach(N=>{N.addEventListener("click",()=>{Kg=N.dataset.brush||"solid",n.querySelectorAll(".brush-btn").forEach(te=>te.classList.remove("active")),N.classList.add("active"),st()})}),n.querySelectorAll(".text-style-btn").forEach(N=>{N.addEventListener("click",()=>{Yg=N.dataset.style||"normal",n.querySelectorAll(".text-style-btn").forEach(te=>te.classList.remove("active")),N.classList.add("active"),st()})}),n.querySelectorAll(".shape-btn").forEach(N=>{N.addEventListener("click",()=>{Qg=N.dataset.shape||"none",n.querySelectorAll(".shape-btn").forEach(te=>te.classList.remove("active")),N.classList.add("active"),st()})});const e=n.querySelector("#oo-fill-toggle");e==null||e.addEventListener("click",()=>{io=!io,e.classList.toggle("active",io),e.textContent=io?"◼":"◧",st()});const t=n.querySelector("#oo-text-input");let r=null;t==null||t.addEventListener("input",()=>{const N=t.value;ko=N,console.log("[OpenOverlay] Text input:",N,"liveTextId:",r),N.trim()&&!r?(console.log("[OpenOverlay] Creating text in center"),document.dispatchEvent(new CustomEvent("oo:textcreate",{detail:{text:N}}))):N.trim()&&r?document.dispatchEvent(new CustomEvent("oo:textupdate",{detail:{text:N}})):!N.trim()&&r&&(document.dispatchEvent(new CustomEvent("oo:textdelete",{detail:{id:r}})),r=null),st()}),document.addEventListener("oo:textcreated",N=>{console.log("[OpenOverlay] Text created with id:",N.detail.id),r=N.detail.id}),document.addEventListener("oo:textsaved",()=>{console.log("[OpenOverlay] Text saved, resetting"),r=null,t&&(t.value=""),ko=""}),n.querySelectorAll(".quick-color").forEach(N=>{N.addEventListener("click",()=>{const $=N.dataset.color||"#ff3366",te=n.querySelector("#oo-color");te&&(te.value=$),n.querySelectorAll(".quick-color").forEach(ot=>ot.classList.remove("active")),N.classList.add("active"),st(),tn==="game"&&document.dispatchEvent(new CustomEvent("oo:playercolor",{detail:{color:$}}))})}),(xe=n.querySelector("#oo-color"))==null||xe.addEventListener("input",()=>{const N=n.querySelector("#oo-color");n.querySelectorAll(".quick-color").forEach($=>$.classList.remove("active")),st(),tn==="game"&&N&&document.dispatchEvent(new CustomEvent("oo:playercolor",{detail:{color:N.value}}))});const i=n.querySelector("#oo-size"),o=n.querySelector("#oo-size-display");i==null||i.addEventListener("input",()=>{o&&(o.textContent=i.value),st()});const s=n.querySelector("#oo-opacity"),l=n.querySelector("#oo-opacity-display");s==null||s.addEventListener("input",()=>{l&&(l.textContent=s.value+"%"),st()}),(rt=n.querySelector("#oo-eraser"))==null||rt.addEventListener("click",()=>{var N;ii=!ii,(N=n.querySelector("#oo-eraser"))==null||N.classList.toggle("active",ii),st()}),(Or=n.querySelector("#oo-layer-bg"))==null||Or.addEventListener("click",()=>{var N,$;De==="background"?De="normal":De="background",(N=n.querySelector("#oo-layer-bg"))==null||N.classList.toggle("active",De==="background"),($=n.querySelector("#oo-layer-fg"))==null||$.classList.remove("active"),st()}),(_n=n.querySelector("#oo-layer-fg"))==null||_n.addEventListener("click",()=>{var N,$;De==="foreground"?De="normal":De="foreground",(N=n.querySelector("#oo-layer-fg"))==null||N.classList.toggle("active",De==="foreground"),($=n.querySelector("#oo-layer-bg"))==null||$.classList.remove("active"),st()}),(vt=n.querySelector("#oo-text-layer-bg"))==null||vt.addEventListener("click",()=>{var N,$;De==="background"?De="normal":De="background",(N=n.querySelector("#oo-text-layer-bg"))==null||N.classList.toggle("active",De==="background"),($=n.querySelector("#oo-text-layer-fg"))==null||$.classList.remove("active"),st()}),(bt=n.querySelector("#oo-text-layer-fg"))==null||bt.addEventListener("click",()=>{var N,$;De==="foreground"?De="normal":De="foreground",(N=n.querySelector("#oo-text-layer-fg"))==null||N.classList.toggle("active",De==="foreground"),($=n.querySelector("#oo-text-layer-bg"))==null||$.classList.remove("active"),st()}),(it=n.querySelector("#oo-undo"))==null||it.addEventListener("click",()=>{document.dispatchEvent(new CustomEvent("oo:undo"))}),(ue=n.querySelector("#oo-clear"))==null||ue.addEventListener("click",()=>{document.dispatchEvent(new CustomEvent("oo:clear"))}),(ke=n.querySelector("#oo-cancel"))==null||ke.addEventListener("click",()=>{ho("none"),document.dispatchEvent(new CustomEvent("oo:cancel"))}),(ye=n.querySelector("#oo-save"))==null||ye.addEventListener("click",()=>{ho("none"),document.dispatchEvent(new CustomEvent("oo:save"))}),n.querySelectorAll(".game-mode-btn").forEach(N=>{N.addEventListener("click",()=>{const $=N.dataset.mode,te=N.dataset.playmode;uo=$,n.querySelectorAll(".game-mode-btn").forEach(Mr=>Mr.classList.remove("active")),N.classList.add("active");const ot=n.querySelector(".build-tools-section");ot&&(ot.style.display=$==="build"?"flex":"none"),document.dispatchEvent(new CustomEvent("oo:gamemode",{detail:{mode:$,tool:Ud,playmode:te||"explore"}}))})}),n.querySelectorAll(".game-tool-btn[data-tool]").forEach(N=>{N.addEventListener("click",()=>{const $=N.dataset.tool||"platform";Ud=$,n.querySelectorAll(".game-tool-btn[data-tool]").forEach(te=>te.classList.remove("active")),N.classList.add("active"),document.dispatchEvent(new CustomEvent("oo:gamemode",{detail:{mode:uo,tool:$}}))})});const u=n.querySelector("#oo-char-boy"),h=n.querySelector("#oo-char-girl");u==null||u.addEventListener("click",()=>{u.classList.add("active"),h==null||h.classList.remove("active"),document.dispatchEvent(new CustomEvent("oo:playerstyle",{detail:{isGirl:!1}})),localStorage.setItem("oo_player_girl","false")}),h==null||h.addEventListener("click",()=>{h.classList.add("active"),u==null||u.classList.remove("active"),document.dispatchEvent(new CustomEvent("oo:playerstyle",{detail:{isGirl:!0}})),localStorage.setItem("oo_player_girl","true")}),localStorage.getItem("oo_player_girl")==="true"&&(u==null||u.classList.remove("active"),h==null||h.classList.add("active"));const p=n.querySelector("#oo-hat-select");p==null||p.addEventListener("change",()=>{const N=p.value;document.dispatchEvent(new CustomEvent("oo:playerhat",{detail:{hat:N}}))});const m=localStorage.getItem("oo_player_hat");m&&p&&(p.value=m);const g=n.querySelector("#oo-accessory-select");g==null||g.addEventListener("change",()=>{const N=g.value;document.dispatchEvent(new CustomEvent("oo:playeraccessory",{detail:{accessory:N}}))});const b=localStorage.getItem("oo_player_accessory");b&&g&&(g.value=b);const P=n.querySelector("#oo-game-color");P==null||P.addEventListener("input",()=>{document.dispatchEvent(new CustomEvent("oo:playercolor",{detail:{color:P.value}}))});const A=n.querySelector("#oo-game-quick-colors");if(A){const N=["#ff3366","#22c55e","#3b82f6","#f59e0b","#8b5cf6","#fff","#000"];A.innerHTML=N.map(($,te)=>`
      <div class="quick-color ${te===0?"active":""}" data-color="${$}" style="background: ${$}" title="${$}"></div>
    `).join(""),A.querySelectorAll(".quick-color").forEach($=>{$.addEventListener("click",()=>{const te=$.dataset.color||"#ff3366";P&&(P.value=te),A.querySelectorAll(".quick-color").forEach(ot=>ot.classList.remove("active")),$.classList.add("active"),document.dispatchEvent(new CustomEvent("oo:playercolor",{detail:{color:te}}))})})}(Je=n.querySelector("#oo-game-undo"))==null||Je.addEventListener("click",()=>{document.dispatchEvent(new CustomEvent("oo:undo"))}),(Kt=n.querySelector("#oo-game-clear"))==null||Kt.addEventListener("click",()=>{document.dispatchEvent(new CustomEvent("oo:clear"))}),(Nr=n.querySelector("#oo-game-cancel"))==null||Nr.addEventListener("click",()=>{ho("none"),document.dispatchEvent(new CustomEvent("oo:cancel"))}),(Dr=n.querySelector("#oo-game-save"))==null||Dr.addEventListener("click",()=>{document.dispatchEvent(new CustomEvent("oo:save")),document.dispatchEvent(new CustomEvent("oo:gamemode",{detail:{mode:"play",playmode:"explore"}})),n.classList.remove("show"),tn="none"}),document.addEventListener("click",N=>{if($l){$l=!1;return}if(tn!=="game"||!n.classList.contains("show")||uo==="build")return;const $=N.composedPath(),te=C==null?void 0:C.host;te&&$.includes(te)||(document.dispatchEvent(new CustomEvent("oo:save")),document.dispatchEvent(new CustomEvent("oo:gamemode",{detail:{mode:"play",playmode:"explore"}})),n.classList.remove("show"),tn="none")}),document.addEventListener("click",N=>{var ot;if(!Ut)return;const $=N.composedPath(),te=C==null?void 0:C.host;te&&$.includes(te)||(Ut=!1,(ot=C==null?void 0:C.querySelector("#oo-profile-modal"))==null||ot.classList.remove("show"))});const O=n.querySelector("#oo-multiplayer-setup");O==null||O.addEventListener("click",async()=>{const N=O;N.textContent="⏳",N.disabled=!0;try{const $=await chrome.runtime.sendMessage({type:"SETUP_MULTIPLAYER"});$!=null&&$.success?(N.textContent="✓ Ready",N.classList.add("active"),setTimeout(()=>{N.textContent="👥 MP",N.disabled=!1},2e3)):(N.textContent="❌ Error",setTimeout(()=>{N.textContent="👥 MP",N.disabled=!1,N.classList.remove("active")},2e3))}catch($){console.error("[OpenOverlay] Multiplayer setup error:",$),N.textContent="👥 MP",N.disabled=!1}});const F=n.querySelector("#oo-tag-game");let U=!1;F==null||F.addEventListener("click",async()=>{if(U){document.dispatchEvent(new CustomEvent("oo:toggletag"));return}F.textContent="⏳",F.disabled=!0;try{const N=await chrome.runtime.sendMessage({type:"SETUP_MULTIPLAYER"});N!=null&&N.success?(console.log("[OpenOverlay UI] Multiplayer setup complete, starting tag game"),document.dispatchEvent(new CustomEvent("oo:toggletag"))):(console.error("[OpenOverlay UI] Multiplayer setup failed:",N==null?void 0:N.error),F.textContent="❌",setTimeout(()=>{F.textContent="🏷️ Tag",F.disabled=!1},1500))}catch(N){console.error("[OpenOverlay UI] Error setting up multiplayer:",N),F.textContent="❌",setTimeout(()=>{F.textContent="🏷️ Tag",F.disabled=!1},1500)}}),document.addEventListener("oo:tagstatechange",N=>{const{isTagMode:$,isIt:te}=N.detail;U=$,F.disabled=!1,$?te?(F.textContent="🏷️ IT!",F.classList.add("active")):(F.textContent="🏷️ Run!",F.classList.add("active")):(F.textContent="🏷️ Tag",F.classList.remove("active"))});const V=n.querySelector("#oo-drag-handle");let H=!1,z=0,K=0,T=0,v=0;V==null||V.addEventListener("pointerdown",N=>{const $=N;H=!0,z=$.clientX,K=$.clientY;const te=n.getBoundingClientRect();T=te.left,v=te.top,n.style.right="auto",n.style.bottom="auto",n.style.left=`${te.left}px`,n.style.top=`${te.top}px`,V.style.cursor="grabbing",$.preventDefault()}),document.addEventListener("pointermove",N=>{if(!H)return;const $=N.clientX-z,te=N.clientY-K;n.style.left=`${T+$}px`,n.style.top=`${v+te}px`}),document.addEventListener("pointerup",()=>{H&&(H=!1,V&&(V.style.cursor="grab"))});const w=C.querySelector("#google-login-btn"),I=C.querySelector("#signout-btn"),E=C.querySelector("#profile-close-btn");E==null||E.addEventListener("click",()=>{Ut=!1;const N=C==null?void 0:C.querySelector("#oo-profile-modal");N==null||N.classList.remove("show")}),w==null||w.addEventListener("click",async()=>{try{await II()}catch(N){console.error("[OpenOverlay] Login failed:",N)}}),I==null||I.addEventListener("click",async()=>{try{await AI(),Ut=!1;const N=C==null?void 0:C.querySelector("#oo-profile-modal");N==null||N.classList.remove("show")}catch(N){console.error("[OpenOverlay] Sign out failed:",N)}});const S=C.querySelector("#oo-screen-name");if(S){const N=localStorage.getItem("oo_screen_name");N&&(S.value=N),S.addEventListener("change",()=>{const $=S.value.trim();localStorage.setItem("oo_screen_name",$),document.dispatchEvent(new CustomEvent("oo:screenname",{detail:{name:$}}))}),S.addEventListener("keydown",$=>{$.stopPropagation(),$.key==="Enter"&&S.blur()})}const _=C.querySelector("#feedback-submit");_==null||_.addEventListener("click",async()=>{var Vr;const N=C==null?void 0:C.querySelector("#feedback-type"),$=C==null?void 0:C.querySelector("#feedback-text"),te=C==null?void 0:C.querySelector("#feedback-form"),ot=C==null?void 0:C.querySelector("#feedback-success"),Mr=N==null?void 0:N.value,Lr=(Vr=$==null?void 0:$.value)==null?void 0:Vr.trim();if(!Lr){$==null||$.focus();return}const Yt=_;Yt.disabled=!0,Yt.textContent="Sending...",await wI(Mr,Lr)?(te.style.display="none",ot.style.display="block",setTimeout(()=>{$.value="",N.selectedIndex=0,te.style.display="block",ot.style.display="none",Yt.disabled=!1,Yt.textContent="Send Feedback"},3e3)):(Yt.disabled=!1,Yt.textContent="Send Feedback",alert("Failed to send feedback. Please try again."))}),ZI(C),document.addEventListener("oo:contributors",N=>{t0(C,N.detail.contributors)}),Mg(N=>{n0(N)})}let Me={showAll:!0,showMine:!0,showFollowing:!1,hiddenUsers:new Set};function ZI(n){e0();const e=n.querySelector("#toggle-all-drawings"),t=n.querySelector("#toggle-my-drawings"),r=n.querySelector("#toggle-following-only");e==null||e.classList.toggle("active",Me.showAll),t==null||t.classList.toggle("active",Me.showMine),r==null||r.classList.toggle("active",Me.showFollowing),e==null||e.addEventListener("click",()=>{Me.showAll=!Me.showAll,e.classList.toggle("active",Me.showAll),document.dispatchEvent(new CustomEvent("oo:visibility:all",{detail:{show:Me.showAll}}))}),t==null||t.addEventListener("click",()=>{Me.showMine=!Me.showMine,t.classList.toggle("active",Me.showMine),document.dispatchEvent(new CustomEvent("oo:visibility:mine",{detail:{show:Me.showMine}}))}),r==null||r.addEventListener("click",()=>{Me.showFollowing=!Me.showFollowing,r.classList.toggle("active",Me.showFollowing),document.dispatchEvent(new CustomEvent("oo:visibility:following",{detail:{show:Me.showFollowing}}))})}function e0(){try{const n=localStorage.getItem("oo_visibility_prefs");if(n){const e=JSON.parse(n);Me={showAll:e.showAll??!0,showMine:e.showMine??!0,showFollowing:e.showFollowing??!1,hiddenUsers:new Set(e.hiddenUsers??[])}}}catch{}}async function t0(n,e){const t=n.querySelector("#contributors-list");if(!t)return;const r=ce(),i=e.filter(s=>s.userId!==(r==null?void 0:r.uid));if(i.length===0){t.innerHTML='<div class="no-contributors">No other contributors yet</div>';return}const o=new Map;r&&await Promise.all(i.map(async s=>{const l=await iI(r.uid,s.userId);o.set(s.userId,l)})),t.innerHTML=i.map(s=>{var m;const l=!Me.hiddenUsers.has(s.userId),u=s.photoURL||"",h=((m=s.displayName)==null?void 0:m.charAt(0).toUpperCase())||"?",p=o.get(s.userId)||!1;return`
      <div class="contributor-row" data-user-id="${s.userId}">
        <div class="contributor-info">
          ${u?`<img src="${u}" class="contributor-avatar" alt="${s.displayName}">`:`<div class="contributor-avatar" style="display:flex;align-items:center;justify-content:center;color:#888;font-size:12px;">${h}</div>`}
          <span class="contributor-name">${Gr(s.displayName)}</span>
        </div>
        <div class="contributor-actions">
          ${r?`
            <button class="follow-btn ${p?"following":"follow"}"
                    data-follow-user="${s.userId}"
                    data-user-name="${Gr(s.displayName)}"
                    data-user-photo="${u}">
              ${p?"Following":"Follow"}
            </button>
          `:""}
          <div class="toggle-switch small ${l?"active":""}" data-toggle-user="${s.userId}" title="Show/hide this user's drawings"></div>
        </div>
      </div>
    `}).join(""),t.querySelectorAll("[data-toggle-user]").forEach(s=>{s.addEventListener("click",()=>{const l=s.getAttribute("data-toggle-user");if(!l)return;const u=s.classList.toggle("active");u?Me.hiddenUsers.delete(l):Me.hiddenUsers.add(l),document.dispatchEvent(new CustomEvent("oo:visibility:user",{detail:{userId:l,show:u}}))})}),t.querySelectorAll("[data-follow-user]").forEach(s=>{s.addEventListener("click",async()=>{const l=s.getAttribute("data-follow-user"),u=s.getAttribute("data-user-name")||"",h=s.getAttribute("data-user-photo")||"";if(!l||!r)return;const p=s,m=p.classList.contains("following");p.disabled=!0;try{m?(await rI(r.uid,l),p.classList.remove("following"),p.classList.add("follow"),p.textContent="Follow"):(await nI(r.uid,l,u,h),p.classList.remove("follow"),p.classList.add("following"),p.textContent="Following")}catch(g){console.error("[OpenOverlay] Follow action failed:",g),m?(p.classList.add("following"),p.classList.remove("follow"),p.textContent="Following"):(p.classList.add("follow"),p.classList.remove("following"),p.textContent="Follow")}finally{p.disabled=!1}})})}function n0(n){var i;const e=C==null?void 0:C.querySelector("#oo-profile-btn"),t=C==null?void 0:C.querySelector("#login-prompt"),r=C==null?void 0:C.querySelector("#profile-content");if(!(!e||!t||!r))if(n){n.photoURL?e.innerHTML=`<img src="${n.photoURL}" alt="Profile">`:e.textContent=((i=n.displayName)==null?void 0:i.charAt(0).toUpperCase())||"👤",t.style.display="none",r.style.display="block";const o=C==null?void 0:C.querySelector("#profile-avatar"),s=C==null?void 0:C.querySelector("#profile-name"),l=C==null?void 0:C.querySelector("#profile-email");o&&(o.src=n.photoURL||""),s&&(s.textContent=n.displayName||"Anonymous"),l&&(l.textContent=n.email||""),Cg(n.uid).then(u=>{if(u){const h=C==null?void 0:C.querySelector("#followers-count"),p=C==null?void 0:C.querySelector("#following-count"),m=C==null?void 0:C.querySelector("#profile-bio");h&&(h.textContent=String(u.followersCount||0)),p&&(p.textContent=String(u.followingCount||0)),m&&(m.innerHTML=u.bio?u.bio:'<span class="profile-bio-empty">No bio yet</span>')}})}else e.textContent="👤",t.style.display="block",r.style.display="none"}function r0(){Ut=!Ut;const n=C==null?void 0:C.querySelector("#oo-profile-modal");n==null||n.classList.toggle("show",Ut),Ut&&i0()}function i0(){const n=C==null?void 0:C.querySelector("#bookmarks-list"),e=C==null?void 0:C.querySelector("#bookmarks-count");if(!n)return;const t=Pa();if(e&&(e.textContent=String(t.length)),t.length===0){n.innerHTML='<div class="no-bookmarks">No bookmarks yet</div>';return}n.innerHTML=t.slice(0,10).map(r=>`
    <div class="bookmark-item" data-url="${Gr(r.pageUrl)}">
      <div class="bookmark-quote">"${Gr(qd(r.comment,50))}"</div>
      <div class="bookmark-meta">${Gr(qd(r.pageTitle,30))} • ${Gr(r.authorName)}</div>
    </div>
  `).join(""),n.querySelectorAll(".bookmark-item").forEach(r=>{r.addEventListener("click",()=>{const i=r.dataset.url;i&&window.open(i,"_blank")})})}function Gr(n){const e=document.createElement("div");return e.textContent=n,e.innerHTML}function qd(n,e){return n.length<=e?n:n.slice(0,e)+"..."}function st(){document.dispatchEvent(new CustomEvent("oo:settings",{detail:{color:Ar(),size:Sr(),opacity:xr(),brush:nu(),textStyle:ru(),eraser:ii,layer:De}}))}function o0(){ms=!ms;const n=C==null?void 0:C.querySelector(".fab"),e=C==null?void 0:C.querySelectorAll(".mini");n==null||n.classList.toggle("open",ms),e==null||e.forEach(t=>t.classList.toggle("show",ms))}function cl(n){ho(tn===n?"none":n)}function ho(n){var h,p,m,g,b;const e=tn;tn=n;const t=C==null?void 0:C.querySelectorAll(".mini");t==null||t.forEach((P,A)=>{A===0&&P.classList.toggle("active",n==="draw"),A===1&&P.classList.toggle("active",n==="text"),A===2&&P.classList.toggle("active",n==="game")});const r=C==null?void 0:C.querySelector(".toolbar");r==null||r.classList.toggle("show",n!=="none"),r==null||r.classList.toggle("game-mode",n==="game");const i=C==null?void 0:C.querySelector("#draw-controls"),o=C==null?void 0:C.querySelector("#text-controls"),s=C==null?void 0:C.querySelector("#game-controls");i==null||i.classList.toggle("active",n==="draw"),o==null||o.classList.toggle("active",n==="text"),s==null||s.classList.toggle("active",n==="game");const l=C==null?void 0:C.querySelector("#oo-size"),u=C==null?void 0:C.querySelector("#oo-size-display");if(l&&u&&(n==="text"?(l.value="32",l.max="200",u.textContent="32"):n==="draw"&&(l.value="4",l.max="150",u.textContent="4")),n!=="none"&&(ii=!1,(h=C==null?void 0:C.querySelector("#oo-eraser"))==null||h.classList.remove("active"),De="normal",(p=C==null?void 0:C.querySelector("#oo-layer-bg"))==null||p.classList.remove("active"),(m=C==null?void 0:C.querySelector("#oo-layer-fg"))==null||m.classList.remove("active"),(g=C==null?void 0:C.querySelector("#oo-text-layer-bg"))==null||g.classList.remove("active"),(b=C==null?void 0:C.querySelector("#oo-text-layer-fg"))==null||b.classList.remove("active")),n!=="text"){ko="";const P=C==null?void 0:C.querySelector("#oo-text-input");P&&(P.value="")}if(document.dispatchEvent(new CustomEvent("oo:mode",{detail:{mode:n}})),n==="game"){$l=!0,uo="play";const P=C==null?void 0:C.querySelectorAll(".game-mode-btn");P==null||P.forEach(O=>{const F=O.dataset.mode,U=O.dataset.playmode;O.classList.toggle("active",F==="play"&&U==="explore")});const A=C==null?void 0:C.querySelector(".build-tools-section");A&&(A.style.display="none"),document.dispatchEvent(new CustomEvent("oo:gamemode",{detail:{mode:"play",playmode:"explore"}}))}else e==="game"&&document.dispatchEvent(new CustomEvent("oo:gamemode",{detail:{mode:"none"}}));console.log("[OpenOverlay] Mode:",n)}function Ar(){const n=C==null?void 0:C.querySelector("#oo-color");return(n==null?void 0:n.value)||"#ff3366"}function Sr(){const n=C==null?void 0:C.querySelector("#oo-size");return parseInt((n==null?void 0:n.value)||"4",10)}function xr(){const n=C==null?void 0:C.querySelector("#oo-opacity");return parseInt((n==null?void 0:n.value)||"100",10)/100}function nu(){return Kg}function Xg(){return ii}function ia(){return De}function ru(){return Yg}function s0(){return Qg}function Jg(){return io}function a0(){return ko}function Bd(){ko="";const n=C==null?void 0:C.querySelector("#oo-text-input");n&&(n.value="")}let ae=null,L=null,Le=null,ct=null,pt=null,ur=null,vi=!1,tt="none",iu=!1,ne=[],Wr=[],Ve={showAll:!0,showMine:!0,showFollowing:!1,hiddenUsers:new Set},Nn=null,ys=[],oi=[],Qt=null,si="none",on=null,sn=null,Zg=!1,ul=0,Fe=null,jl={x:0,y:0},Vt="none",Ns={x:0,y:0,size:0};const vs=10,em=30;function ou(n){if(n===document.body||n===document.documentElement)return"body";if(n.id)return`#${CSS.escape(n.id)}`;const e=[];let t=n;for(;t&&t!==document.body&&t!==document.documentElement;){let r=t.tagName.toLowerCase();if(t.className&&typeof t.className=="string"){const o=t.className.trim().split(/\s+/).slice(0,2);o.length>0&&o[0]&&(r+="."+o.map(s=>CSS.escape(s)).join("."))}const i=t.parentElement;if(i){const o=Array.from(i.children).filter(s=>s.tagName===t.tagName);if(o.length>1){const s=o.indexOf(t)+1;r+=`:nth-of-type(${s})`}}if(e.unshift(r),e.length>=4)break;t=t.parentElement}return e.join(" > ")||"body"}function su(n,e){ae&&(ae.style.pointerEvents="none");const t=document.elementsFromPoint(n,e);ae&&(ae.style.pointerEvents=tt==="draw"?"auto":"none");for(const r of t){if(r.id==="oo-canvas"||r.id==="openoverlay-ui"||r===document.body||r===document.documentElement)continue;const i=r.getBoundingClientRect();if(!(i.width<20||i.height<20))return r}return document.body}function l0(){console.log("[OpenOverlay] initCanvas starting..."),ae=document.createElement("canvas"),ae.id="oo-canvas",ae.style.cssText=`
    position: absolute;
    top: 0;
    left: 0;
    z-index: 2147483640;
    pointer-events: none;
  `,document.body.appendChild(ae),L=ae.getContext("2d"),Le=document.createElement("canvas"),ct=Le.getContext("2d"),pt=document.createElement("canvas"),pt.id="oo-background-canvas",pt.style.cssText=`
    position: absolute;
    top: 0;
    left: 0;
    z-index: 2147483635;
    pointer-events: none;
  `,document.body.appendChild(pt),ur=pt.getContext("2d"),Gi(),window.addEventListener("resize",Gi);const n=/yahoo|facebook|twitter|instagram|tiktok|reddit/i.test(window.location.hostname),e=n?500:150;let t=null;window.addEventListener("scroll",()=>{t&&clearTimeout(t),t=window.setTimeout(()=>{vi||de()},e)},{passive:!0});let r=null;new ResizeObserver(()=>{n?(r&&clearTimeout(r),r=window.setTimeout(Gi,500)):Gi()}).observe(document.documentElement);const o=n?2e3:500;let s=null,l=!1;new MutationObserver(()=>{l||(l=!0,s&&clearTimeout(s),s=window.setTimeout(()=>{l=!1,vi||(Gi(),de())},o))}).observe(document.body,{childList:!0,subtree:!1}),n&&console.log("[OpenOverlay] Heavy site detected, using longer debounce"),document.addEventListener("oo:mode",h=>{tt=h.detail.mode,ae&&(ae.style.pointerEvents=tt==="draw"||tt==="text"?"auto":"none",ae.style.cursor=tt==="draw"?"crosshair":tt==="text"?"text":"default")}),document.addEventListener("oo:save",S0),document.addEventListener("oo:cancel",x0),document.addEventListener("oo:undo",I0),document.addEventListener("oo:clear",A0),document.addEventListener("oo:visibility:all",h=>{Ve.showAll=h.detail.show,Ki(),de(),console.log("[OpenOverlay] Visibility - show all:",h.detail.show)}),document.addEventListener("oo:visibility:mine",h=>{Ve.showMine=h.detail.show,Ki(),de(),console.log("[OpenOverlay] Visibility - show mine:",h.detail.show)}),document.addEventListener("oo:visibility:following",h=>{Ve.showFollowing=h.detail.show,Ki(),de(),console.log("[OpenOverlay] Visibility - following only:",h.detail.show)}),document.addEventListener("oo:visibility:user",h=>{const{userId:p,show:m}=h.detail;m?Ve.hiddenUsers.delete(p):Ve.hiddenUsers.add(p),Ki(),de(),console.log("[OpenOverlay] Visibility - user",p,":",m?"shown":"hidden")}),document.addEventListener("oo:toggleothers",h=>{Ve.showAll=h.detail.show,Ki(),de()}),v0(),document.addEventListener("oo:gamemode",h=>{iu=h.detail.mode==="build"||h.detail.mode==="play",(h.detail.mode==="play"||h.detail.mode==="build")&&de()}),document.addEventListener("oo:settings",h=>{if(Fe&&tt==="text"){const p=ne.find(m=>m.type==="text"&&m.id===Fe);p&&(p.size=h.detail.size,p.color=h.detail.color,p.opacity=h.detail.opacity,p.style=h.detail.textStyle,de())}}),document.addEventListener("oo:textcreate",h=>{if(console.log("[OpenOverlay] oo:textcreate received, currentMode:",tt),tt!=="text")return;const p=window.innerWidth/2,m=window.innerHeight/2,g=su(p,m);if(!g){console.log("[OpenOverlay] No anchor found at center");return}const b=g.getBoundingClientRect(),P=window.scrollX,A=window.scrollY,O=b.left+P,F=b.top+A,U=(p+P-O)/b.width,V=(m+A-F)/b.height,H=im(),z={type:"text",id:H,anchorSelector:ou(g),x:U,y:V,anchorBounds:{x:O,y:F,width:b.width,height:b.height},text:h.detail.text,color:Ar(),size:Sr(),opacity:xr(),style:ru(),rotation:0,layer:ia()};ne.push(z),Fe=z.id,console.log("[OpenOverlay] Text created:",H),document.dispatchEvent(new CustomEvent("oo:textcreated",{detail:{id:H}})),de()}),document.addEventListener("oo:textupdate",h=>{if(!Fe)return;const p=ne.find(m=>m.type==="text"&&m.id===Fe);p&&(p.text=h.detail.text,de())}),document.addEventListener("oo:textdelete",h=>{const p=h.detail.id,m=ne.findIndex(g=>g.id===p);m!==-1&&(ne.splice(m,1),Fe===p&&(Fe=null),de())}),ae.addEventListener("pointerdown",c0),ae.addEventListener("pointermove",d0),ae.addEventListener("pointerup",zd),ae.addEventListener("pointerleave",zd),au(),k0(),console.log("[OpenOverlay] Canvas initialized")}let $d=0,jd=0;function Gi(){if(!ae||!L)return;const n=Math.max(document.body.scrollWidth||0,document.body.offsetWidth||0,document.documentElement.scrollWidth||0,document.documentElement.offsetWidth||0,window.innerWidth||0),e=Math.max(document.body.scrollHeight||0,document.body.offsetHeight||0,document.documentElement.scrollHeight||0,document.documentElement.offsetHeight||0,window.innerHeight||0);if(n===$d&&e===jd)return;$d=n,jd=e;const t=window.devicePixelRatio||1;ae.style.width=`${n}px`,ae.style.height=`${e}px`,ae.width=n*t,ae.height=e*t,L.scale(t,t),Le&&ct&&(Le.width=n*t,Le.height=e*t,ct.setTransform(1,0,0,1,0,0),ct.scale(t,t)),pt&&ur&&(pt.style.width=`${n}px`,pt.style.height=`${e}px`,pt.width=n*t,pt.height=e*t,ur.scale(t,t)),de()}function c0(n){if(tt==="text"){h0(n);return}if(tt!=="draw")return;vi=!0;const e=su(n.clientX,n.clientY);if(e){const r=e.getBoundingClientRect();Qt={element:e,selector:ou(e),bounds:r}}const t=s0();t!=="none"?(si=t,on={x:n.pageX,y:n.pageY},sn={x:n.pageX,y:n.pageY},Zg=Jg()):oi=[{x:n.pageX,y:n.pageY}]}function oa(n){if(!L)return null;const e=nm(n);if(!e)return null;L.font=`bold ${n.size||32}px Impact, Arial, sans-serif`;const r=L.measureText(n.text).width,i=n.size;return{x:e.x,y:e.y,width:r,height:i,centerX:e.x+r/2,centerY:e.y+i/2}}function tm(n,e,t){const r=oa(t);if(!r)return"none";const i=8,o=t.rotation||0,s=[{x:r.x+r.width+i,y:r.y+r.height+i,mode:"resize"}],l=r.centerX,u=r.y-i-em,h=Math.cos(o),p=Math.sin(o),m=l-r.centerX,g=u-r.centerY,b=r.centerX+m*h-g*p,P=r.centerY+m*p+g*h;if(Math.abs(n-b)<vs&&Math.abs(e-P)<vs)return"rotate";const A=s[0].x-r.centerX,O=s[0].y-r.centerY,F=r.centerX+A*h-O*p,U=r.centerY+A*p+O*h;return Math.abs(n-F)<vs&&Math.abs(e-U)<vs?"resize":"none"}function u0(n){if(!ae||tt!=="text")return;if(Fe){const t=ne.find(r=>r.type==="text"&&r.id===Fe);if(t){const r=tm(n.pageX,n.pageY,t);if(r==="resize"){ae.style.cursor="nwse-resize";return}else if(r==="rotate"){ae.style.cursor="crosshair";return}}}rm(n.pageX,n.pageY)?ae.style.cursor="grab":ae.style.cursor="default"}function h0(n){if(Fe){const r=ne.find(i=>i.type==="text"&&i.id===Fe);if(r){const i=tm(n.pageX,n.pageY,r);if(i!=="none"){Vt=i,oa(r)&&(Ns={x:n.pageX,y:n.pageY,size:r.size,rotation:r.rotation||0});return}}}const e=rm(n.pageX,n.pageY);if(e){Fe=e.id,Vt="move";const r=nm(e);r&&(jl={x:n.pageX-r.x,y:n.pageY-r.y}),ae&&(ae.style.cursor="grabbing"),de();return}if(Fe){Fe=null,Vt="none",Bd(),document.dispatchEvent(new CustomEvent("oo:textsaved")),de();return}const t=a0();if(t&&t.trim()){const r=su(n.clientX,n.clientY);if(!r)return;const i=r.getBoundingClientRect(),o=window.scrollX,s=window.scrollY,l=i.left+o,u=i.top+s,h=(n.pageX-l)/i.width,p=(n.pageY-u)/i.height,m={type:"text",id:im(),anchorSelector:ou(r),x:h,y:p,anchorBounds:{x:l,y:u,width:i.width,height:i.height},text:t,color:Ar(),size:Sr(),opacity:xr(),style:ru(),rotation:0,layer:ia()};ne.push(m),Fe=m.id,Bd(),document.dispatchEvent(new CustomEvent("oo:textsaved")),de()}}function nm(n){let e=null;try{e=document.querySelector(n.anchorSelector)}catch{}if(!e)return null;const t=e.getBoundingClientRect(),r=window.scrollX,i=window.scrollY;return{x:t.left+r+n.x*t.width,y:t.top+i+n.y*t.height}}function d0(n){if(tt==="text"&&Vt==="none"&&u0(n),Fe&&tt==="text"&&Vt!=="none"){const e=ne.find(t=>t.type==="text"&&t.id===Fe);if(!e)return;if(Vt==="move"){let t=null;try{t=document.querySelector(e.anchorSelector)}catch{}if(t){const r=t.getBoundingClientRect(),i=window.scrollX,o=window.scrollY,s=n.pageX-jl.x,l=n.pageY-jl.y;e.x=(s-r.left-i)/r.width,e.y=(l-r.top-o)/r.height,de()}}else if(Vt==="resize"){if(oa(e)){const r=n.pageX-Ns.x,i=n.pageY-Ns.y,o=(r+i)/2,s=Math.max(12,Math.min(200,Ns.size+o));e.size=s,de()}}else if(Vt==="rotate"){const t=oa(e);if(t){const r=Math.atan2(n.pageY-t.centerY,n.pageX-t.centerX);e.rotation=r+Math.PI/2,de()}}return}if(!(!vi||!L)){if(si!=="none"&&on){sn={x:n.pageX,y:n.pageY},de(),p0();return}oi.push({x:n.pageX,y:n.pageY}),de(),f0(oi,Ar(),Sr(),xr(),nu(),Xg())}}function zd(){if(Vt!=="none"){Vt="none",ae&&(ae.style.cursor="grab");return}if(vi){if(vi=!1,si!=="none"&&on&&sn&&Qt){const n=Qt.element.getBoundingClientRect(),e=window.scrollX,t=window.scrollY,r=n.left+e,i=n.top+t,o=(on.x-r)/n.width,s=(on.y-i)/n.height,l=(sn.x-r)/n.width,u=(sn.y-i)/n.height;ne.push({type:"shape",id:"shape_"+Date.now(),anchorSelector:Qt.selector,x1:o,y1:s,x2:l,y2:u,anchorBounds:{x:r,y:i,width:n.width,height:n.height},shape:si,color:Ar(),width:Sr(),opacity:xr(),filled:Zg,layer:ia()}),on=null,sn=null,si="none",Qt=null,de();return}if(oi.length>1&&Qt){const n=Qt.element.getBoundingClientRect(),e=window.scrollX,t=window.scrollY,r=n.left+e,i=n.top+t,o=oi.map(s=>({x:(s.x-r)/n.width,y:(s.y-i)/n.height}));ne.push({type:"stroke",anchorSelector:Qt.selector,points:o,anchorBounds:{x:r,y:i,width:n.width,height:n.height},color:Ar(),width:Sr(),opacity:xr(),brush:nu(),eraser:Xg(),layer:ia()})}oi=[],Qt=null,de()}}function rm(n,e){const t=window.scrollX,r=window.scrollY;for(let i=ne.length-1;i>=0;i--){const o=ne[i];if(o.type!=="text")continue;let s=null;try{s=document.querySelector(o.anchorSelector)}catch{}if(!s)continue;const l=s.getBoundingClientRect(),u={x:l.left+t,y:l.top+r,width:l.width,height:l.height},h=u.x+o.x*u.width,p=u.y+o.y*u.height,m=o.text.length*o.size*.6,g=o.size,b=10;if(n>=h-b&&n<=h+m+b&&e>=p-b&&e<=p+g+b)return o}return null}function im(){return Math.random().toString(36).substr(2,9)}function f0(n,e,t,r,i,o){if(!(!L||n.length<2)){switch(L.save(),L.globalAlpha=r,o&&(L.globalCompositeOperation="destination-out",L.globalAlpha=1),i){case"spray":am(L,n,e,t);break;case"dots":lm(L,n,e,t);break;case"square":cm(L,n,e,t);break;case"rainbow":g0(L,n,t);break;case"glow":um(L,n,e,t);break;default:sm(L,n,e,t)}L.restore()}}function Wd(n,e){if(!L||n.points.length<2)return;const t=n.points.map(r=>({x:e.x+r.x*e.width,y:e.y+r.y*e.height}));switch(L.save(),L.globalAlpha=n.opacity,n.eraser&&(L.globalCompositeOperation="destination-out",L.globalAlpha=1),n.brush){case"spray":am(L,t,n.color,n.width);break;case"dots":lm(L,t,n.color,n.width);break;case"square":cm(L,t,n.color,n.width);break;case"rainbow":m0(L,t,n.width);break;case"glow":um(L,t,n.color,n.width);break;default:sm(L,t,n.color,n.width)}L.restore()}function p0(){if(!L||!on||!sn)return;const n=Ar(),e=Sr(),t=xr(),r=Jg();L.save(),L.globalAlpha=t,L.strokeStyle=n,L.fillStyle=n,L.lineWidth=e,L.lineCap="round",L.lineJoin="round";const i=on.x,o=on.y,s=sn.x,l=sn.y;om(L,si,i,o,s,l,r),L.restore()}function Hd(n,e){if(!L)return;const t=e.x+n.x1*e.width,r=e.y+n.y1*e.height,i=e.x+n.x2*e.width,o=e.y+n.y2*e.height;L.save(),L.globalAlpha=n.opacity,L.strokeStyle=n.color,L.fillStyle=n.color,L.lineWidth=n.width,L.lineCap="round",L.lineJoin="round",om(L,n.shape,t,r,i,o,n.filled),L.restore()}function om(n,e,t,r,i,o,s){const l=Math.min(t,i),u=Math.min(r,o),h=Math.abs(i-t),p=Math.abs(o-r),m=(t+i)/2,g=(r+o)/2;switch(n.beginPath(),e){case"line":n.moveTo(t,r),n.lineTo(i,o),n.stroke();break;case"rectangle":s&&n.fillRect(l,u,h,p),n.strokeRect(l,u,h,p);break;case"circle":const b=Math.sqrt(h*h+p*p)/2;n.arc(m,g,b,0,Math.PI*2),s&&n.fill(),n.stroke();break;case"triangle":n.moveTo(m,u),n.lineTo(l,u+p),n.lineTo(l+h,u+p),n.closePath(),s&&n.fill(),n.stroke();break;case"star":const P=Math.min(h,p)/2,A=P*.4,O=5;for(let F=0;F<O*2;F++){const U=F%2===0?P:A,V=Math.PI/O*F-Math.PI/2,H=m+U*Math.cos(V),z=g+U*Math.sin(V);F===0?n.moveTo(H,z):n.lineTo(H,z)}n.closePath(),s&&n.fill(),n.stroke();break}}function sm(n,e,t,r){n.beginPath(),n.strokeStyle=t,n.lineWidth=r,n.lineCap="round",n.lineJoin="round",n.moveTo(e[0].x,e[0].y);for(let i=1;i<e.length;i++)n.lineTo(e[i].x,e[i].y);n.stroke()}function am(n,e,t,r){n.fillStyle=t;const i=Math.max(10,r*2);for(const o of e)for(let s=0;s<i;s++){const l=Math.random()*Math.PI*2,u=Math.random()*r,h=o.x+Math.cos(l)*u,p=o.y+Math.sin(l)*u;n.beginPath(),n.arc(h,p,.5,0,Math.PI*2),n.fill()}}function lm(n,e,t,r){n.fillStyle=t;const i=Math.max(r*.8,4);let o=0;for(let s=0;s<e.length;s++){if(s===0){n.beginPath(),n.arc(e[0].x,e[0].y,r/2,0,Math.PI*2),n.fill();continue}const l=e[s].x-e[s-1].x,u=e[s].y-e[s-1].y,h=Math.sqrt(l*l+u*u);o+=h,o>=i&&(n.beginPath(),n.arc(e[s].x,e[s].y,r/2,0,Math.PI*2),n.fill(),o=0)}}function cm(n,e,t,r){n.beginPath(),n.strokeStyle=t,n.lineWidth=r,n.lineCap="square",n.lineJoin="bevel",n.moveTo(e[0].x,e[0].y);for(let i=1;i<e.length;i++)n.lineTo(e[i].x,e[i].y);n.stroke()}function g0(n,e,t){n.lineWidth=t,n.lineCap="round",n.lineJoin="round";for(let r=1;r<e.length;r++){const i=`hsl(${ul}, 100%, 50%)`;n.beginPath(),n.strokeStyle=i,n.shadowColor=i,n.shadowBlur=t*.8,n.moveTo(e[r-1].x,e[r-1].y),n.lineTo(e[r].x,e[r].y),n.stroke(),ul=(ul+2)%360}n.shadowBlur=0}function m0(n,e,t){n.lineWidth=t,n.lineCap="round",n.lineJoin="round";let r=0;for(let i=1;i<e.length;i++){const o=`hsl(${r}, 100%, 50%)`;n.beginPath(),n.strokeStyle=o,n.shadowColor=o,n.shadowBlur=t*.8,n.moveTo(e[i-1].x,e[i-1].y),n.lineTo(e[i].x,e[i].y),n.stroke(),r=(r+2)%360}n.shadowBlur=0}function um(n,e,t,r){const i=r*3;let o=1/0,s=1/0,l=-1/0,u=-1/0;for(const A of e)o=Math.min(o,A.x),s=Math.min(s,A.y),l=Math.max(l,A.x),u=Math.max(u,A.y);const h=Math.ceil(l-o+i*2),p=Math.ceil(u-s+i*2),m=document.createElement("canvas");m.width=h,m.height=p;const g=m.getContext("2d");if(!g)return;const b=o-i,P=s-i;g.strokeStyle=t,g.lineWidth=r,g.lineCap="round",g.lineJoin="round",g.shadowColor=t,g.shadowBlur=r*2.5,g.beginPath(),g.moveTo(e[0].x-b,e[0].y-P);for(let A=1;A<e.length;A++)g.lineTo(e[A].x-b,e[A].y-P);g.stroke(),g.shadowBlur=r,g.stroke(),n.drawImage(m,b,P)}function y0(){const{showAll:n,showMine:e,showFollowing:t,hiddenUsers:r}=Ve;if(!n)return[];const i=[];e&&i.push(...ne.map(o=>({item:o,isOtherUser:!1})));for(const o of Wr){const s=o._ownerId;s&&(r.has(s)||t&&!((Nn==null?void 0:Nn.has(s))??!1)||i.push({item:o,isOtherUser:!0}))}return i}function Ki(){const n={showAll:Ve.showAll,showMine:Ve.showMine,showFollowing:Ve.showFollowing,hiddenUsers:Array.from(Ve.hiddenUsers)};localStorage.setItem("oo_visibility_prefs",JSON.stringify(n))}function v0(){try{const n=localStorage.getItem("oo_visibility_prefs");if(n){const e=JSON.parse(n);Ve={showAll:e.showAll!==!1,showMine:e.showMine!==!1,showFollowing:e.showFollowing===!0,hiddenUsers:new Set(Array.isArray(e.hiddenUsers)?e.hiddenUsers:[])},console.log("[OpenOverlay] Loaded visibility prefs:",{showAll:Ve.showAll,showMine:Ve.showMine,showFollowing:Ve.showFollowing,hiddenUsers:Ve.hiddenUsers.size}),(!Ve.showAll||!Ve.showMine)&&(console.warn("[OpenOverlay] Visibility prefs seem corrupted, resetting to defaults"),Ve={showAll:!0,showMine:!0,showFollowing:!1,hiddenUsers:new Set},localStorage.removeItem("oo_visibility_prefs"))}}catch(n){console.warn("[OpenOverlay] Failed to load visibility prefs, using defaults:",n),localStorage.removeItem("oo_visibility_prefs")}}async function _0(){const n=ce();if(!n){Nn=new Set;return}try{const e=await oI(n.uid);Nn=new Set(e.map(t=>t.uid)),console.log("[OpenOverlay] Loaded following cache:",Nn.size,"users")}catch(e){console.warn("[OpenOverlay] Failed to load following cache:",e),Nn=new Set}}function de(){if(!L||!ae)return;L.clearRect(0,0,ae.width,ae.height),Le&&ct&&ct.clearRect(0,0,Le.width,Le.height),pt&&ur&&ur.clearRect(0,0,pt.width,pt.height);const n=window.scrollX,e=window.scrollY,t=(u,h,p=!1)=>{let m=null;try{m=document.querySelector(h.anchorSelector)}catch{}if(!m)return;const g=m.getBoundingClientRect();if(g.width===0||g.height===0)return;const b={x:g.left+n,y:g.top+e,width:g.width,height:g.height},P=L;L=u,h.type==="text"?(Gd(h,b),!p&&h.id===Fe&&u===P&&w0(h,b)):h.type==="shape"?Hd(h,b):Wd(h,b),L=P},r=u=>{if(!ct)return;let h=null;try{h=document.querySelector(u.anchorSelector)}catch{return}if(!h)return;const p=h.getBoundingClientRect();if(p.width===0||p.height===0)return;const m={x:p.left+n,y:p.top+e,width:p.width,height:p.height},g=L;L=ct,u.type==="text"?Gd(u,m):u.type==="shape"?Hd(u,m):(u.type==="stroke"||!u.type)&&Wd(u,m),L=g},i=y0(),o=i.filter(({item:u})=>u.layer==="background"),s=i.filter(({item:u})=>{const h=u.layer;return!h||h==="normal"}),l=i.filter(({item:u})=>u.layer==="foreground");if(ur)for(const{item:u,isOtherUser:h}of o)t(ur,u,h);for(const{item:u,isOtherUser:h}of s)t(L,u,h),r(u);for(const{item:u,isOtherUser:h}of l)t(L,u,h)}function w0(n,e){if(!L)return;const t=e.x+n.x*e.width,r=e.y+n.y*e.height;L.font=`bold ${n.size||32}px Impact, Arial, sans-serif`;const o=L.measureText(n.text).width,s=n.size,l=8,u=t+o/2,h=r+s/2,p=n.rotation||0;L.save(),L.translate(u,h),L.rotate(p),L.translate(-u,-h),L.strokeStyle="#22c55e",L.lineWidth=2,L.setLineDash([5,3]),L.strokeRect(t-l,r-l,o+l*2,s+l*2),L.setLineDash([]),L.fillStyle="#22c55e";const m=8;L.fillRect(t+o+l-m/2,r+s+l-m/2,m,m);const g=r-l-em;L.beginPath(),L.arc(u,g,6,0,Math.PI*2),L.fill(),L.beginPath(),L.strokeStyle="#22c55e",L.setLineDash([]),L.lineWidth=2,L.moveTo(u,r-l),L.lineTo(u,g+6),L.stroke(),L.restore()}function Gd(n,e){if(!L)return;const t=e.x+n.x*e.width,r=e.y+n.y*e.height;L.save(),L.globalAlpha=n.opacity||1,L.font=`bold ${n.size||32}px Impact, Arial, sans-serif`,L.textBaseline="top";const i=n.rotation||0;if(i!==0){const o=L.measureText(n.text),s=t+o.width/2,l=r+n.size/2;L.translate(s,l),L.rotate(i),L.translate(-s,-l)}switch(n.style){case"rainbow":T0(L,n.text,t,r,n.size);break;case"aged":E0(L,n.text,t,r,n.size,n.color);break;default:b0(L,n.text,t,r,n.color)}L.restore()}function b0(n,e,t,r,i){n.strokeStyle="#000",n.lineWidth=3,n.strokeText(e,t,r),n.fillStyle=i,n.fillText(e,t,r)}function T0(n,e,t,r,i){const o=n.measureText(e).width,s=n.createLinearGradient(t,r,t+o,r);s.addColorStop(0,"hsl(0, 100%, 50%)"),s.addColorStop(.17,"hsl(60, 100%, 50%)"),s.addColorStop(.33,"hsl(120, 100%, 50%)"),s.addColorStop(.5,"hsl(180, 100%, 50%)"),s.addColorStop(.67,"hsl(240, 100%, 50%)"),s.addColorStop(.83,"hsl(300, 100%, 50%)"),s.addColorStop(1,"hsl(360, 100%, 50%)");let l=0;for(let u=0;u<e.length;u++){const h=e[u],p=n.measureText(h).width,g=(l+p/2)/o*360;n.shadowColor=`hsl(${g}, 100%, 50%)`,n.shadowBlur=i*.2,n.shadowOffsetX=0,n.shadowOffsetY=0,n.fillStyle=s,n.fillText(h,t+l,r),l+=p}n.shadowBlur=0,n.strokeStyle="#000",n.lineWidth=3,n.strokeText(e,t,r),n.fillStyle=s,n.fillText(e,t,r)}function E0(n,e,t,r,i,o){n.shadowColor="rgba(0,0,0,0.5)",n.shadowBlur=4,n.shadowOffsetX=2,n.shadowOffsetY=2,n.strokeStyle="#222",n.lineWidth=4,n.strokeText(e,t,r),n.shadowBlur=0,n.shadowOffsetX=0,n.shadowOffsetY=0;const s=n.createLinearGradient(t,r,t,r+i);s.addColorStop(0,Kd(o,20)),s.addColorStop(.5,o),s.addColorStop(1,Kd(o,-30)),n.fillStyle=s,n.fillText(e,t,r),n.globalAlpha=.3,n.strokeStyle="#000",n.lineWidth=1;const l=n.measureText(e).width;for(let u=0;u<5;u++){const h=t+Math.random()*l,p=r+Math.random()*i;n.beginPath(),n.moveTo(h,p),n.lineTo(h+Math.random()*10-5,p+Math.random()*10),n.stroke()}}function Kd(n,e){const t=n.replace("#",""),r=Math.max(0,Math.min(255,parseInt(t.substr(0,2),16)+e)),i=Math.max(0,Math.min(255,parseInt(t.substr(2,2),16)+e)),o=Math.max(0,Math.min(255,parseInt(t.substr(4,2),16)+e));return`rgb(${r},${i},${o})`}function I0(){iu||ne.length>0&&(ne.pop(),de(),console.log("[OpenOverlay] Undo - items remaining:",ne.length))}async function A0(){if(iu)return;tt==="text"?(ne=ne.filter(e=>e.type!=="text"),console.log("[OpenOverlay] Cleared text stamps (drawings preserved)")):(ne=ne.filter(e=>e.type==="text"),console.log("[OpenOverlay] Cleared drawings (text stamps preserved)"));const n=lu();ne.length>0?(localStorage.setItem(`oo_drawing_${n}`,JSON.stringify(ne)),ta()&&await Rg(n,window.location.href,ne)):(localStorage.removeItem(`oo_drawing_${n}`),ta()&&await aI(n)),de()}async function S0(){console.log("[OpenOverlay] Saving",ne.length,"items"),Fe=null,document.dispatchEvent(new CustomEvent("oo:textsaved"));const n=lu(),e=JSON.stringify(ne);localStorage.setItem(`oo_drawing_${n}`,e),ta()&&await Rg(n,window.location.href,ne),de(),console.log("[OpenOverlay] Drawing saved")}function x0(){console.log("[OpenOverlay] Canceling drawing"),au()}async function au(){const n=lu();if(Rr()){if(lI(n,i=>{ne=i.myItems,Wr=i.otherItems,ys=i.contributors,localStorage.setItem(`oo_drawing_${n}`,JSON.stringify(ne)),console.log("[OpenOverlay] Real-time update:",ne.length,"mine,",Wr.length,"from others"),i.contributors.length>0&&console.log("[OpenOverlay] Contributors:",i.contributors.map(o=>o.displayName).join(", ")),document.dispatchEvent(new CustomEvent("oo:contributors",{detail:{contributors:ys}})),de()})){console.log("[OpenOverlay] Subscribed to real-time drawing updates");return}console.log("[OpenOverlay] Real-time subscription failed, trying one-time fetch");const r=await sI(n);if(r!==null){ne=r.myItems,Wr=r.otherItems,ys=r.contributors,localStorage.setItem(`oo_drawing_${n}`,JSON.stringify(ne)),console.log("[OpenOverlay] Loaded from cloud:",ne.length,"mine,",Wr.length,"from others"),document.dispatchEvent(new CustomEvent("oo:contributors",{detail:{contributors:ys}})),de();return}}Wr=[];const e=localStorage.getItem(`oo_drawing_${n}`);if(e)try{ne=JSON.parse(e),console.log("[OpenOverlay] Loaded",ne.length,"items from localStorage"),de()}catch{console.warn("[OpenOverlay] Failed to load drawings"),ne=[]}else ne=[]}function lu(){return btoa(window.location.href).slice(0,32)}function k0(){Mg(n=>{n?(console.log("[OpenOverlay] User logged in, reloading drawings from cloud"),_0()):(console.log("[OpenOverlay] User logged out, reloading public drawings"),Nn=null),au()})}function Yi(n,e,t,r,i){if(!Le||!ct)return{floor:!1,floorY:0,ceiling:!1,ceilingY:0,leftWall:!1,leftWallX:0,rightWall:!1,rightWallX:0,slopeAngle:0,slopeAheadY:0};const o=window.devicePixelRatio||1;let s=!1,l=0,u=!1,h=0,p=!1,m=0,g=!1,b=0,P=0,A=0;const O=Math.max(1,Math.floor(t*.5*o)),F=Math.floor((n+t/2)*o),U=Math.max(0,F-Math.floor(O/2));try{const V=e+r,H=Math.floor((V-5)*o),z=Math.floor(20*o);if(U>=0&&H>=0&&U+O<=Le.width&&H+z<=Le.height){const it=ct.getImageData(U,H,O,z);for(let ue=0;ue<z;ue++){let ke=!1;for(let ye=0;ye<O;ye++){const Je=(ue*O+ye)*4;if(it.data[Je+3]>30){ke=!0;break}}if(ke){const ye=H/o+ue/o;ye>=V-8&&(s=!0,l=ye);break}}}const K=e,T=Math.max(0,Math.floor((K-15)*o)),v=Math.floor(15*o);if(U>=0&&T>=0&&U+O<=Le.width&&T+v<=Le.height){const it=ct.getImageData(U,T,O,v);for(let ue=v-1;ue>=0;ue--){let ke=!1;for(let ye=0;ye<O;ye++){const Je=(ue*O+ye)*4;if(it.data[Je+3]>30){ke=!0;break}}if(ke){const ye=T/o+(ue+1)/o;ye<=K+5&&(u=!0,h=ye);break}}}const w=Math.floor(e*o),I=Math.floor(r*.85*o),E=Math.floor(10*o),S=Math.max(0,Math.floor(n*o)-E);if(S>=0&&w>=0&&S+E<=Le.width&&w+I<=Le.height){const it=ct.getImageData(S,w,E,I);e:for(let ue=E-1;ue>=0;ue--)for(let ke=0;ke<I;ke++){const ye=(ke*E+ue)*4;if(it.data[ye+3]>30){p=!0,m=(S+ue+1)/o;break e}}}const _=Math.floor((n+t)*o);if(_>=0&&w>=0&&_+E<=Le.width&&w+I<=Le.height){const it=ct.getImageData(_,w,E,I);e:for(let ue=0;ue<E;ue++)for(let ke=0;ke<I;ke++){const ye=(ke*E+ue)*4;if(it.data[ye+3]>30){g=!0,b=(_+ue)/o;break e}}}const xe=e+r,rt=20,Or=i!==!1?n+t+rt:n-rt,_n=Math.floor(Or*o),vt=Math.floor((xe-30)*o),bt=Math.floor(50*o);if(_n>=0&&_n<Le.width&&vt>=0&&vt+bt<=Le.height){const it=ct.getImageData(_n,vt,1,bt);for(let ue=0;ue<bt;ue++)if(it.data[ue*4+3]>30){A=vt/o+ue/o;const Je=(s?l:xe)-A;P=Math.atan2(Je,rt)*(180/Math.PI);break}}}catch{}return{floor:s,floorY:l,ceiling:u,ceilingY:h,leftWall:p,leftWallX:m,rightWall:g,rightWallX:b,slopeAngle:P,slopeAheadY:A}}let ve=null,c=null,gt=null,Z=null,Se="none",Po="spawn",x={x:100,y:100,vx:0,vy:0,width:23,height:38,onGround:!1,facingRight:!0,animFrame:0,jumpsRemaining:2,maxJumps:2},hl=!1,Qi=0,_s=0,Xt=!1,Ds=0,Yd=0;const P0=12e4,C0=2e3;let Dt=localStorage.getItem("oo_player_color")||"#ffffff",Co=localStorage.getItem("oo_player_hat")||"none",Ro=localStorage.getItem("oo_player_accessory")||"none",zl=localStorage.getItem("oo_screen_name")||"",cu=localStorage.getItem("oo_player_girl")==="true",fo=[],It=new Map,Rn=new Map,dl=0,Qd=0,Xd=0;const R0=80;let Oe=!1,wt=null,ln=0,we=!1,Jt=null,Dn=null,gr=0;const sa=3e3,hm=5e3,dm=3e3;let Wl=0;const O0=5e3;function Oo(){const n=ce();return n?wt!=null&&wt.gameActive?wt.itPlayerId===n.uid:we:!1}let le={id:wm(),name:"New Course",checkpoints:[],authorId:"local-user",authorName:"You",createdAt:Date.now()},No=[];const N0=.6,Jd=-12,Zd=3,D0=.7,ef=14,fl=6,Zt={};let Kr=null,Hl=0,ht=!1,Gl=0,xi=0,or=0,Bn=3,uu=3,cn=!1,Kl=0;const tf=2e3,M0=2e3;let hu=0,aa=!1,kt="explore",un=!1,du=0;const fm=2e3;let Ie=null,at=null,ai=!1,Ft=0,po=localStorage.getItem("oo_player_name")||"";function L0(){console.log("[OpenOverlay] initGame starting..."),ve=document.createElement("canvas"),ve.id="oo-game-canvas",ve.style.cssText=`
    position: absolute;
    top: 0;
    left: 0;
    z-index: 2147483638;
    pointer-events: none;
  `,document.body.appendChild(ve),c=ve.getContext("2d"),gt=document.createElement("canvas"),gt.id="oo-overlay-canvas",gt.style.cssText=`
    position: absolute;
    top: 0;
    left: 0;
    z-index: 2147483646;
    pointer-events: none;
  `,document.body.appendChild(gt),Z=gt.getContext("2d"),pl(),window.addEventListener("resize",pl),new ResizeObserver(pl).observe(document.body),document.addEventListener("keydown",tA),document.addEventListener("keyup",nA),document.addEventListener("oo:gamemode",t=>{nf(t.detail.mode,t.detail.tool,t.detail.playmode)}),document.addEventListener("oo:undo",()=>{Se==="build"&&le.checkpoints.length>0&&(le.checkpoints.pop(),_i(),nt())}),document.addEventListener("oo:clear",()=>{Se==="build"&&(le.checkpoints=[],_i(),nt())}),document.addEventListener("oo:playercolor",t=>{Dt=t.detail.color,localStorage.setItem("oo_player_color",Dt),nt()}),document.addEventListener("oo:playerstyle",t=>{cu=t.detail.isGirl,nt()}),document.addEventListener("oo:playerhat",t=>{Co=t.detail.hat,localStorage.setItem("oo_player_hat",Co),nt()}),document.addEventListener("oo:playeraccessory",t=>{Ro=t.detail.accessory,localStorage.setItem("oo_player_accessory",Ro),nt()}),document.addEventListener("oo:screenname",t=>{zl=t.detail.name,localStorage.setItem("oo_screen_name",zl),Do()}),document.addEventListener("oo:toggletag",()=>{console.log("[OpenOverlay] Tag toggle requested, gameMode:",Se),Se!=="play"&&(console.log("[OpenOverlay] Auto-switching to play mode for tag"),nf("play","explore")),uA()}),ve.addEventListener("pointerdown",iA),ve.addEventListener("pointermove",oA),ve.addEventListener("pointerup",sA),ve.addEventListener("contextmenu",t=>{Se==="build"&&t.preventDefault()}),aA(),nt();const e=()=>{Se==="play"&&(Dg(),Ng(mn()))};window.addEventListener("beforeunload",e),window.addEventListener("pagehide",e),document.addEventListener("visibilitychange",()=>{document.hidden&&Se==="play"&&Do()}),console.log("[OpenOverlay] Game initialized")}function pl(){if(!ve||!c)return;const n=Math.max(document.body.scrollWidth,document.body.offsetWidth,document.documentElement.scrollWidth,document.documentElement.offsetWidth),e=Math.max(document.body.scrollHeight,document.body.offsetHeight,document.documentElement.scrollHeight,document.documentElement.offsetHeight),t=window.devicePixelRatio||1;ve.style.width=`${n}px`,ve.style.height=`${e}px`,ve.width=n*t,ve.height=e*t,c.scale(t,t),gt&&Z&&(gt.style.width=`${n}px`,gt.style.height=`${e}px`,gt.width=n*t,gt.height=e*t,Z.scale(t,t)),nt()}function nf(n,e,t){if(Se=n,e&&(Po=e),t&&(kt=t),ve&&(ve.style.pointerEvents=n==="build"?"auto":"none",ve.style.cursor=n==="build"?"crosshair":"default"),n==="play"){ht=!1,xi=0,or=0,le.checkpoints.forEach(i=>i.reached=!1),Bn=uu,cn=!1,un=!1,Ie=null,ai=!1;const r=mn();console.log("[OpenOverlay] Subscribing to players on page:",r),gI(r,i=>{if(It=i,i.size>0&&(console.log("[OpenOverlay] Received",i.size,"other players"),i.forEach((o,s)=>{console.log("[OpenOverlay] Player",s,"at",o.x,o.y)}),Oe)){const o=ce(),s=Date.now();let l=null;for(const[p,m]of i)m.taggedPlayerId===(o==null?void 0:o.uid)&&m.taggedAt&&s-m.taggedAt<hm&&!we&&s>ln&&(console.log("[OpenOverlay] EXPLICITLY TAGGED by:",p,"via taggedPlayerId"),we=!0,Jt=p,ln=s+sa,Pt("You're IT!","Tag someone!",2e3),Yl(),document.dispatchEvent(new CustomEvent("oo:tagstatechange",{detail:{isTagMode:!0,isIt:!0,gameActive:!0}})));for(const[p,m]of i){if(console.log("[OpenOverlay] Checking player",p,"isIt:",m.isIt),m.isIt){l=p,console.log("[OpenOverlay] Found IT player in sync:",m.displayName,"id:",p);break}p===Jt&&!m.isIt&&(console.log("[OpenOverlay] Clearing lastTaggedByPlayerId - sync caught up"),Jt=null)}const u=s<ln,h=l===Jt;l&&we&&o&&!u&&!h?l<o.uid?(console.log("[OpenOverlay] Tiebreaker: other player wins (lower ID), giving up IT"),we=!1,Jt=null,document.dispatchEvent(new CustomEvent("oo:tagstatechange",{detail:{isTagMode:!0,isIt:!1,gameActive:!0}}))):console.log("[OpenOverlay] Tiebreaker: we win (lower ID), keeping IT"):l&&we&&u?console.log("[OpenOverlay] Skipping tiebreaker - in tag cooldown"):l&&we&&h?console.log("[OpenOverlay] Skipping tiebreaker - was tagged by this player (stale sync)"):l&&!we&&console.log("[OpenOverlay] Other player is IT, we are not")}}),mI(r,i=>{const o=wt;wt=i,console.log("[OpenOverlay] Tag game state changed:",i);const s=ce(),l=(i==null?void 0:i.itPlayerId)===(s==null?void 0:s.uid);document.dispatchEvent(new CustomEvent("oo:tagstatechange",{detail:{isTagMode:Oe,isIt:l,gameActive:(i==null?void 0:i.gameActive)??!1}})),i!=null&&i.gameActive&&(console.log('[OpenOverlay] Tag game active, "it" is:',i.itPlayerId),(o==null?void 0:o.itPlayerId)!==i.itPlayerId&&(l?Pt("You're IT!","Tag someone!",2e3):(o==null?void 0:o.itPlayerId)===(s==null?void 0:s.uid)&&Pt("You're not IT!","Run away!",2e3)))}),mm(),kt==="race"&&document.dispatchEvent(new CustomEvent("oo:hidetoolbar")),V0()}else n==="build"?(ai=!1,un=!1,Ie=null,Oe=!1,we=!1,Jt=null,Dn=null,gr=0,wt=null):(ai=!1,un=!1,Ie=null,Dg(),yI(),Ng(mn()),It.clear(),Rn.clear(),Oe=!1,we=!1,Jt=null,Dn=null,gr=0,wt=null);nt()}function V0(){Kr&&(cancelAnimationFrame(Kr),Kr=null),Hl=performance.now(),Kr=requestAnimationFrame(pm)}function pm(n){const e=Math.min((n-Hl)/16.67,3);Hl=n,U0(e),nt(),Se==="play"||Se==="build"?Kr=requestAnimationFrame(pm):Kr=null}function gm(){const n=le.checkpoints.find(r=>r.type==="spawn"),e=le.checkpoints.find(r=>r.type==="start"),t=n||e;t?(x.x=t.x-x.width/2,x.y=t.y-x.height-10):(x.x=window.scrollX+window.innerWidth/2-x.width/2,x.y=window.scrollY+100),x.vx=0,x.vy=0,x.onGround=!1,x.jumpsRemaining=x.maxJumps}function mm(){if(gm(),kt==="explore"){un=!1,ht=!1,Pt("Explore!","No timer, unlimited respawns",2e3),setTimeout(()=>{},150);return}un=!0,du=performance.now(),Pt("Get Ready!","2")}function Pt(n,e,t=1e3){Ie={text:n,subtext:e,endTime:performance.now()+t}}function Yl(){Wl=performance.now()+dm}function ym(n){at&&Xi();const{top10:e}=cA();at=document.createElement("div"),at.id="oo-game-popup",at.style.cssText=`
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background: rgba(0,0,0,0.7);
    z-index: 2147483647;
    display: flex;
    align-items: center;
    justify-content: center;
    font-family: system-ui, -apple-system, sans-serif;
  `;const t=n==="finish",r=t?"🏆 RACE COMPLETE!":"💀 GAME OVER",i=t?"#22c55e":"#ef4444",o=(xi/1e3).toFixed(2),s=t&&Ft===le.bestTime;let l="";e.length>0&&(l=`
      <div style="margin-top: 15px; max-height: 200px; overflow-y: auto;">
        <div style="color: #fbbf24; font-weight: bold; margin-bottom: 8px;">🏆 Today's Best</div>
        ${e.slice(0,5).map((g,b)=>`
          <div style="display: flex; justify-content: space-between; color: ${b<3?["#fbbf24","#c0c0c0","#cd7f32"][b]:"#888"}; font-size: 13px; padding: 2px 0;">
            <span>${b+1}. ${g.name.slice(0,10)}</span>
            <span>${(g.time/1e3).toFixed(2)}s</span>
          </div>
        `).join("")}
      </div>
    `);const u=document.createElement("div");u.style.cssText=`
    background: #111;
    border: 3px solid ${i};
    border-radius: 12px;
    padding: 25px 35px;
    text-align: center;
    min-width: 300px;
    max-width: 400px;
    box-shadow: 0 10px 40px rgba(0,0,0,0.8);
  `,u.innerHTML=`
    <div style="color: ${i}; font-size: 24px; font-weight: bold; margin-bottom: 15px;">${r}</div>
    <div style="color: #fff; font-size: 40px; font-weight: bold; font-family: monospace;">${o}s</div>
    ${s?'<div style="color: #fbbf24; font-size: 14px; margin-top: 5px;">⭐ NEW PERSONAL BEST!</div>':""}
    ${t?`
      <div style="margin-top: 15px;">
        <input type="text" id="oo-popup-name" placeholder="Enter name..." value="${po}"
          style="padding: 8px 12px; border-radius: 6px; border: 2px solid #333; background: #222; color: #fff; font-size: 14px; width: 180px; text-align: center;">
      </div>
    `:""}
    ${l}
    <div style="display: flex; gap: 10px; justify-content: center; margin-top: 20px;">
      <button id="oo-popup-retry" style="padding: 10px 25px; background: ${i}; color: white; border: none; border-radius: 8px; font-size: 14px; font-weight: bold; cursor: pointer;">
        🔄 Retry
      </button>
      <button id="oo-popup-close" style="padding: 10px 25px; background: #333; color: white; border: none; border-radius: 8px; font-size: 14px; font-weight: bold; cursor: pointer;">
        ✕ Close
      </button>
    </div>
  `,at.appendChild(u),document.body.appendChild(at);const h=at.querySelector("#oo-popup-retry"),p=at.querySelector("#oo-popup-close"),m=at.querySelector("#oo-popup-name");h==null||h.addEventListener("click",()=>{t&&m&&m.value.trim()&&ws(m.value.trim(),Ft),Xi(),rf()}),p==null||p.addEventListener("click",()=>{t&&m&&m.value.trim()&&ws(m.value.trim(),Ft),Xi(),of()}),at.addEventListener("click",g=>{g.target===at&&(t&&m&&m.value.trim()&&ws(m.value.trim(),Ft),Xi(),of())}),m==null||m.focus(),m==null||m.addEventListener("keydown",g=>{g.key==="Enter"&&m.value.trim()&&(ws(m.value.trim(),Ft),Xi(),rf())})}function Xi(){at&&(at.remove(),at=null)}function rf(){ht=!1,xi=0,or=0,le.checkpoints.forEach(n=>n.reached=!1),Bn=uu,cn=!1,ai=!1,fo=[],mm()}function of(){document.dispatchEvent(new CustomEvent("oo:gamemode",{detail:{mode:"build"}})),ht=!1,ai=!1}function vm(){cn||(cn=!0,Kl=performance.now(),kt==="race"&&ht&&(Bn--,console.log("[OpenOverlay] Died! Lives remaining:",Bn)))}let sf=!1;function F0(){const n=performance.now();for(const[t,r]of It){let i=Rn.get(t);if(!i){i={x:r.x,y:r.y,vx:r.vx,vy:r.vy,lastSyncTime:n,targetX:r.x,targetY:r.y},Rn.set(t,i);continue}const o=Math.abs(r.x-i.targetX)>.1||Math.abs(r.y-i.targetY)>.1,s=Math.abs(r.vx-i.vx)>.1||Math.abs(r.vy-i.vy)>.1;if(o||s){i.vx=r.vx,i.vy=r.vy,i.lastSyncTime=n;const m=5;i.targetX=r.x+r.vx*m,i.targetY=r.y+r.vy*m}i.x+=i.vx*.5,i.y+=i.vy*.5;const l=.12,u=i.targetX-i.x,h=i.targetY-i.y;(Math.abs(u)>1||Math.abs(h)>1)&&(i.x+=u*l,i.y+=h*l),Math.sqrt(u*u+h*h)>150&&(i.x=r.x,i.y=r.y)}for(const t of Rn.keys())It.has(t)||Rn.delete(t);const e=Date.now();for(const[t,r]of It)r.updatedAt&&e-r.updatedAt>O0&&(console.log("[OpenOverlay] Removing stale player:",t),It.delete(t),Rn.delete(t))}function U0(n){if(Se!=="play")return;if(F0(),un){const U=performance.now()-du,V=fm-U;V>1e3?Ie={text:"Get Ready!",subtext:"2",endTime:performance.now()+100}:V>0?Ie={text:"Get Ready!",subtext:"1",endTime:performance.now()+100}:(un=!1,Ie={text:"GO!",endTime:performance.now()+500},kt==="race"&&(ht=!0,Gl=performance.now()));return}if(cn){const U=tf-(performance.now()-Kl);if(U>0&&(Ie={text:"You fell!",subtext:`Respawning in ${Math.ceil(U/1e3)}...`,endTime:performance.now()+100}),performance.now()-Kl>=tf){if(kt==="race"&&Bn<=0){ht=!1,cn=!1,ym("gameover");return}cn=!1,gm(),Ie=null,setTimeout(()=>{},100)}return}Ie&&performance.now()>Ie.endTime&&(Ie=null);const t=performance.now()<hu?Zd*2:Zd;if(Zt.ArrowLeft||Zt.KeyA)x.vx=-t,x.facingRight=!1,_s=performance.now(),Xt=!1;else if(Zt.ArrowRight||Zt.KeyD)x.vx=t,x.facingRight=!0,_s=performance.now(),Xt=!1;else{const U=Qi>0?.92:D0;x.vx*=U,Math.abs(x.vx)<.1&&(x.vx=0)}Qi>0&&Qi--,x.onGround&&Math.abs(x.vx)<.1?(performance.now()-_s>P0&&!Xt&&(Xt=!0,Yd=performance.now(),Ds=0),Xt&&(performance.now()-Yd<C0?Ds+=.15:(Xt=!1,_s=performance.now()))):(Xt=!1,Ds=0);const r=Zt.ArrowUp||Zt.KeyW||Zt.Space;if(r&&!sf&&x.jumpsRemaining>0){const U=aa?Jd*1.5:Jd;x.vy=U,x.onGround=!1,x.jumpsRemaining--,aa=!1}sf=r,x.vy+=N0*n,x.vy>ef&&(x.vy=ef);const i=50,o=x.vx>=0;x.onGround=!1;const s=x.vx*n,l=x.vy*n,u=Math.sqrt(s*s+l*l),h=Math.max(1,Math.ceil(u/fl)),p=s/h,m=l/h;for(let U=0;U<h;U++){const V=x.x+p,H=x.y+m,z=Yi(V,x.y,x.width,x.height,o);let K=!0;x.vx<0&&z.leftWall&&(x.x=z.leftWallX,x.vx=0,K=!1),x.vx>0&&z.rightWall&&(x.x=z.rightWallX-x.width,x.vx=0,K=!1),K&&Math.abs(x.vx)>.5&&z.slopeAheadY>0&&z.slopeAngle>i&&(x.vx=0,K=!1);let T=!0;if(x.vy<0){const v=Yi(x.x,H,x.width,x.height,o);v.ceiling&&(x.y=v.ceilingY,x.vy=1,T=!1)}if(K&&(x.x+=p),T&&(x.y+=m),x.vy>=0){const v=Yi(x.x,x.y,x.width,x.height,o);if(v.floor){const w=v.floorY-x.height,I=x.y-w,S=x.vy>5?2:8;if(I<=S&&I>=-fl){!hl&&Math.abs(x.vx)>.5&&(Qi=8),x.y=w,x.vy=0,x.onGround=!0,x.jumpsRemaining=x.maxJumps;break}}}}const g=Yi(x.x,x.y,x.width,x.height,o);x.vy<0&&g.ceiling&&(x.y=g.ceilingY,x.vy=1);const b=g.leftWall&&x.x<g.leftWallX,P=g.rightWall&&x.x+x.width>g.rightWallX;if(b&&P){const U=g.leftWallX-x.x,V=x.x+x.width-g.rightWallX;U<V?x.x=g.leftWallX:x.x=g.rightWallX-x.width,x.vx=0}else b?(x.x=g.leftWallX,x.vx=0):P&&(x.x=g.rightWallX-x.width,x.vx=0);if(x.vy>0&&!x.onGround&&g.floor){const U=g.floorY-x.height,V=x.y-U;V<=8&&V>=-fl&&(!hl&&Math.abs(x.vx)>.5&&(Qi=8),x.y=U,x.vy=0,x.onGround=!0,x.jumpsRemaining=x.maxJumps)}if(x.onGround&&Math.abs(x.vx)>.5){const U=Math.abs(x.vx),V=Math.min(3,Math.ceil(U*.3));for(let H=1;H<=V;H++){const z=x.y-H,K=Yi(x.x,z,x.width,x.height,o);if(K.floor&&!K.leftWall&&!K.rightWall){const T=K.floorY-x.height,v=x.y-T;if(v>0&&v<=V){x.y=T;break}}}}hl=x.onGround;const A=Math.max(document.body.scrollHeight,window.innerHeight),O=Math.max(document.body.scrollWidth,window.innerWidth);(x.y>A+M0||x.x<-100||x.x>O+100)&&vm(),Math.abs(x.vx)>.5?x.animFrame=(x.animFrame+.15*n)%4:x.animFrame=0,q0(),B0(),Oe&&$0(),ht&&kt==="race"&&(xi=performance.now()-Gl);const F=performance.now();if(Se==="play"&&F-dl>R0){const U=Math.abs(x.x-Qd)>5||Math.abs(x.y-Xd)>5,V=F-dl>5e3;(U||V)&&(dl=F,Qd=x.x,Xd=x.y,Do())}}function Do(){const n=mn(),e=ce(),t=Oe&&Oo();Oe&&console.log("[OpenOverlay] Syncing player with isIt:",t,"isTagMode:",Oe,"localIsIt:",we);const r=Date.now();Dn&&r-gr>hm&&(Dn=null,gr=0);const i={x:x.x,y:x.y+x.height,vx:x.vx,vy:x.vy,facingRight:x.facingRight,animFrame:x.animFrame,onGround:x.onGround,isDead:cn,playerColor:Dt,playerHat:Co,playerAccessory:Ro,isGirlMode:cu,displayName:zl||(e==null?void 0:e.displayName)||"",updatedAt:r,isIt:Oe&&Oo(),tagCooldownUntil:ln};Dn&&(i.taggedPlayerId=Dn,i.taggedAt=gr),pI(n,i)}function q0(){if(kt!=="race")return;const n=[...le.checkpoints,...No.flatMap(t=>t.checkpoints)],e=n.filter(t=>t.type==="checkpoint").length;for(const t of n){if(t.reached)continue;const r=x.x+x.width/2,i=x.y+x.height/2;if(Math.hypot(r-t.x,i-t.y)<50)if(t.type==="start"&&!ht)ht=!0,Gl=performance.now(),t.reached=!0,console.log("[OpenOverlay] Race started!");else if(t.type==="checkpoint"&&ht){const s=or+1;t.order===s&&(t.reached=!0,or++,console.log("[OpenOverlay] Checkpoint",or,"of",e,"reached!"),Pt(`Flag ${or}/${e}`,"",1500))}else t.type==="finish"&&ht&&or>=e&&(t.reached=!0,ht=!1,Ft=xi,console.log("[OpenOverlay] Race finished! Time:",(Ft/1e3).toFixed(2)+"s"),(!le.bestTime||Ft<le.bestTime)&&(le.bestTime=Ft,_i()),ym("finish"),document.dispatchEvent(new CustomEvent("oo:racefinish",{detail:{time:Ft,bestTime:le.bestTime}})))}}function B0(){const n=[...le.checkpoints,...No.flatMap(e=>e.checkpoints)];for(const e of n){if(!["trampoline","speedBoost","highJump","spike"].includes(e.type))continue;const t=e.width||60,r=e.height||20,i=e.x-t/2,o=e.x+t/2,s=e.y-r,l=e.y,u=x.x,h=x.x+x.width,p=x.y,m=x.y+x.height;if(h>i&&u<o&&m>s&&p<l)switch(e.type){case"trampoline":x.vy>0&&(x.vy=-20,x.onGround=!1,x.jumpsRemaining=x.maxJumps);break;case"speedBoost":hu=performance.now()+3e3;break;case"highJump":aa=!0;break;case"spike":cn||(fo.push({x:x.x+x.width/2,y:x.y+x.height,createdAt:performance.now()}),vm());break}}}function $0(){if(!Oe||!ce())return;const e=Date.now(),t=mn(),r=x.x+x.width/2,i=x.y+x.height,o=Oo();for(const[s,l]of It){const u=Rn.get(s),h=u?u.x:l.x,p=u?u.y:l.y,m=r-h,g=i-p;if(Math.sqrt(m*m+g*g)<40){const P=e>ln,A=!l.tagCooldownUntil||e>l.tagCooldownUntil;o&&P&&A&&(console.log("[OpenOverlay] TAGGING player:",s),we=!1,Dn=s,gr=e,_I(t,s).catch(()=>{console.log("[OpenOverlay] Firebase tag update failed, using local state")}),ln=e+sa,Pt("Tagged!",l.displayName||"Player",1500),Yl(),document.dispatchEvent(new CustomEvent("oo:tagstatechange",{detail:{isTagMode:!0,isIt:!1,gameActive:!0}})),Do());const O=!l.tagCooldownUntil||e>l.tagCooldownUntil;!o&&l.isIt&&P&&O&&(console.log("[OpenOverlay] GOT TAGGED by:",s),we=!0,ln=e+sa,Jt=s,Pt("You're IT!","Tag someone!",2e3),Yl(),document.dispatchEvent(new CustomEvent("oo:tagstatechange",{detail:{isTagMode:!0,isIt:!0,gameActive:!0}})))}}}function nt(){if(!(!c||!ve)){c.clearRect(0,0,ve.width,ve.height),Z&&gt&&Z.clearRect(0,0,gt.width,gt.height),j0();for(const n of le.checkpoints)af(n);for(const n of No)for(const e of n.checkpoints)af(e,n.authorName);(Se==="play"||Se==="build")&&(z0(),G0(),Se==="play"&&X0()),Se==="build"&&eA()}}function j0(){if(!c)return;const n=performance.now(),e=5e3;fo=fo.filter(t=>n-t.createdAt<e);for(const t of fo){const r=n-t.createdAt,i=Math.max(0,1-r/e);c.save(),c.globalAlpha=i,c.fillStyle="#dc2626",c.beginPath(),c.arc(t.x,t.y,12,0,Math.PI*2),c.fill(),c.fillStyle="#b91c1c";for(let o=0;o<5;o++){const s=o/5*Math.PI*2+Math.random()*.5,l=15+Math.random()*10,u=Math.cos(s)*l,h=Math.sin(s)*l*.5;c.beginPath(),c.arc(t.x+u,t.y+h,4+Math.random()*3,0,Math.PI*2),c.fill()}c.restore()}}function af(n,e){if(!c)return;const t=n.x,r=n.y;if(c.save(),e&&(n.type==="start"||n.type==="finish")&&(c.font="10px Arial",c.fillStyle="rgba(255,255,255,0.7)",c.textAlign="center",c.fillText(`by ${e}`,t,r+15)),n.type==="start"){const i=n.reached?"#86efac":"#22c55e",o=80,s=70;c.strokeStyle="#444",c.lineWidth=6,c.beginPath(),c.moveTo(t-o/2,r),c.lineTo(t-o/2,r-s),c.stroke(),c.beginPath(),c.moveTo(t+o/2,r),c.lineTo(t+o/2,r-s),c.stroke(),c.fillStyle=i,c.fillRect(t-o/2-3,r-s-15,o+6,20),c.strokeStyle="#166534",c.lineWidth=2,c.strokeRect(t-o/2-3,r-s-15,o+6,20),c.fillStyle="#fff",c.font="bold 14px sans-serif",c.textAlign="center",c.fillText("START",t,r-s-1)}else if(n.type==="finish"){c.strokeStyle="#444",c.lineWidth=6,c.beginPath(),c.moveTo(t-80/2,r),c.lineTo(t-80/2,r-70),c.stroke(),c.beginPath(),c.moveTo(t+80/2,r),c.lineTo(t+80/2,r-70),c.stroke();const s=r-70-15,l=20,u=8;c.fillStyle=n.reached?"#fbbf24":"#111",c.fillRect(t-80/2-3,s,86,l);for(let h=0;h<Math.ceil(86/u);h++)for(let p=0;p<Math.ceil(l/u);p++)(h+p)%2===0&&(c.fillStyle="#fff",c.fillRect(t-80/2-3+h*u,s+p*u,u,Math.min(u,l-p*u)));c.strokeStyle="#444",c.lineWidth=2,c.strokeRect(t-80/2-3,s,86,l),c.fillStyle="#fff",c.font="bold 11px sans-serif",c.textAlign="center",c.fillText("FINISH",t,r+15)}else if(n.type==="spawn"){if(Se!=="build"){c.restore();return}const i="#a855f7";c.fillStyle=i,c.beginPath(),c.moveTo(t,r-20),c.lineTo(t-10,r-35),c.lineTo(t+10,r-35),c.closePath(),c.fill(),c.strokeStyle=i,c.lineWidth=2,c.beginPath(),c.arc(t,r-55,8,0,Math.PI*2),c.stroke(),c.beginPath(),c.moveTo(t,r-47),c.lineTo(t,r-30),c.stroke(),c.beginPath(),c.moveTo(t-10,r-42),c.lineTo(t+10,r-42),c.stroke(),c.beginPath(),c.moveTo(t,r-30),c.lineTo(t-8,r-15),c.moveTo(t,r-30),c.lineTo(t+8,r-15),c.stroke(),c.fillStyle="#fff",c.font="bold 10px sans-serif",c.textAlign="center",c.fillText("SPAWN",t,r+5)}else if(n.type==="trampoline"){const i=n.width||60,o=n.height||20;c.fillStyle="#f97316",c.fillRect(t-i/2,r-o,i,o),c.strokeStyle="#c2410c",c.lineWidth=2,c.strokeRect(t-i/2,r-o,i,o),c.strokeStyle="#c2410c",c.lineWidth=2;const s=3,l=i/s;for(let u=0;u<s;u++){const h=t-i/2+l/2+u*l;c.beginPath(),c.moveTo(h,r),c.lineTo(h-4,r-o/3),c.lineTo(h+4,r-o*2/3),c.lineTo(h,r-o),c.stroke()}}else if(n.type==="speedBoost"){const i=n.width||60,o=n.height||20,s=performance.now()<hu;c.fillStyle=s?"#60a5fa":"#3b82f6",c.fillRect(t-i/2,r-o,i,o),c.strokeStyle="#1d4ed8",c.lineWidth=2,c.strokeRect(t-i/2,r-o,i,o),c.fillStyle="#fff",c.font="bold 14px sans-serif",c.textAlign="center",c.textBaseline="middle",c.fillText(">>",t,r-o/2)}else if(n.type==="highJump"){const i=n.width||60,o=n.height||20,s=aa;c.fillStyle=s?"#86efac":"#22c55e",c.fillRect(t-i/2,r-o,i,o),c.strokeStyle="#15803d",c.lineWidth=2,c.strokeRect(t-i/2,r-o,i,o),c.fillStyle="#fff",c.font="bold 16px sans-serif",c.textAlign="center",c.textBaseline="middle",c.fillText("^",t,r-o/2)}else if(n.type==="spike"){const i=n.width||60,o=n.height||30,s=4,l=i/s;c.fillStyle="#ef4444";for(let u=0;u<s;u++){const h=t-i/2+u*l;c.beginPath(),c.moveTo(h,r),c.lineTo(h+l/2,r-o),c.lineTo(h+l,r),c.closePath(),c.fill()}c.strokeStyle="#991b1b",c.lineWidth=1;for(let u=0;u<s;u++){const h=t-i/2+u*l;c.beginPath(),c.moveTo(h,r),c.lineTo(h+l/2,r-o),c.lineTo(h+l,r),c.closePath(),c.stroke()}}else if(n.type==="checkpoint"){const i=n.reached?"#fbbf24":"#3b82f6";c.strokeStyle="#444",c.lineWidth=4,c.beginPath(),c.moveTo(t,r),c.lineTo(t,r-50),c.stroke(),c.fillStyle=i,c.beginPath(),c.moveTo(t,r-50),c.lineTo(t+35,r-40),c.lineTo(t,r-30),c.closePath(),c.fill(),c.fillStyle="#fff",c.font="bold 12px sans-serif",c.textAlign="center",c.textBaseline="middle",c.fillText(String(n.order),t+15,r-40)}c.restore()}function z0(){if(c)for(const[n,e]of It){const t=`logged_${n}`;window[t]||(window[t]=!0,console.log("[OpenOverlay] Remote player data:",n,JSON.stringify({isGirlMode:e.isGirlMode,playerHat:e.playerHat,playerColor:e.playerColor,displayName:e.displayName,playerAccessory:e.playerAccessory,isIt:e.isIt}))),W0(n,e)}}function W0(n,e){if(!c||e.isDead)return;const t=Rn.get(n),r=t?t.x:e.x,i=t?t.y:e.y,o=30,s=50,l=r,u=i-s;c.save(),c.globalAlpha=.85,e.facingRight||(c.translate(l+o/2,0),c.scale(-1,1),c.translate(-(l+o/2),0));const h=7,p=13,m=11,g=l+o/2,b=u+h+3,P=b+h,A=P+p,O=e.playerColor||"#ffffff";c.strokeStyle=O,c.lineWidth=3,c.lineCap="round",c.lineJoin="round",c.shadowColor="rgba(0,0,0,0.3)",c.shadowBlur=4,c.shadowOffsetX=2,c.shadowOffsetY=2;const F=Math.abs(e.vx)>.5,U=e.animFrame||0;if(e.isGirlMode){c.fillStyle=O,c.beginPath(),c.moveTo(g-h-2,b+8),c.lineTo(g-h-1,b-2),c.quadraticCurveTo(g-h+2,b-h-4,g,b-h-3),c.quadraticCurveTo(g+h-2,b-h-4,g+h+1,b-2),c.lineTo(g+h+2,b+8),c.quadraticCurveTo(g+h,b+10,g+h-2,b+10),c.lineTo(g-h+2,b+10),c.quadraticCurveTo(g-h,b+10,g-h-2,b+8),c.closePath(),c.fill(),c.fillStyle="#fff",c.beginPath(),c.arc(g,b,h-1,0,Math.PI*2),c.fill(),c.fillStyle=O,c.beginPath(),c.moveTo(g-h+2,b-2),c.quadraticCurveTo(g-2,b-h-2,g,b-h+1),c.quadraticCurveTo(g+2,b-h-2,g+h-2,b-2),c.quadraticCurveTo(g,b-1,g-h+2,b-2),c.closePath(),c.fill(),c.fillStyle=O,F?(c.beginPath(),c.arc(g+2,b,1.5,0,Math.PI*2),c.fill(),c.lineWidth=2,c.beginPath(),c.moveTo(g,b+4),c.lineTo(g+4,b+4),c.stroke(),c.lineWidth=3):(c.beginPath(),c.arc(g-3,b,1.5,0,Math.PI*2),c.fill(),c.beginPath(),c.arc(g+3,b,1.5,0,Math.PI*2),c.fill(),c.lineWidth=1.5,c.beginPath(),c.arc(g,b+3,2.5,.2*Math.PI,.8*Math.PI),c.stroke(),c.lineWidth=3),c.fillStyle=O,c.beginPath(),c.moveTo(g,P),c.lineTo(g-8,A+1),c.lineTo(g+8,A+1),c.closePath(),c.fill(),c.strokeStyle="#fff",c.lineWidth=2;const z=F?Math.sin(U*Math.PI)*6:0;c.beginPath(),c.moveTo(g-3,A),c.lineTo(g-5+z,A+m),c.moveTo(g+3,A),c.lineTo(g+5-z,A+m),c.stroke(),c.lineWidth=3,c.strokeStyle=O}else{c.beginPath(),c.arc(g,b,h,0,Math.PI*2),c.stroke(),c.fillStyle=O,c.beginPath(),c.moveTo(g-6,b-h+1),c.lineTo(g-3,b-h-4),c.lineTo(g+8,b-h+3),c.quadraticCurveTo(g,b-h-1,g-6,b-h+1),c.closePath(),c.fill(),c.stroke(),c.fillStyle=O,F?(c.beginPath(),c.arc(g+3,b-1,2,0,Math.PI*2),c.fill(),c.beginPath(),c.moveTo(g+1,b+4),c.lineTo(g+5,b+4),c.stroke()):(c.beginPath(),c.arc(g-3,b-1,1.5,0,Math.PI*2),c.fill(),c.beginPath(),c.arc(g+3,b-1,1.5,0,Math.PI*2),c.fill(),c.lineWidth=1.5,c.beginPath(),c.arc(g,b+3,3,.2*Math.PI,.8*Math.PI),c.stroke(),c.lineWidth=3),c.beginPath(),c.moveTo(g,P),c.lineTo(g,A),c.stroke();const z=P+3,K=F?Math.sin(U*Math.PI)*6:0;c.beginPath(),c.moveTo(g,z),c.lineTo(g-m,z+6+K),c.moveTo(g,z),c.lineTo(g+m,z+6-K),c.stroke();const T=F?Math.sin(U*Math.PI)*8:0;c.beginPath(),c.moveTo(g,A),c.lineTo(g-6+T,A+m),c.moveTo(g,A),c.lineTo(g+6-T,A+m),c.stroke()}if(e.playerHat&&e.playerHat!=="none"&&H0(g,b,h,e.playerHat,O),c.restore(),c.save(),c.globalAlpha=.9,e.displayName){c.shadowColor="transparent",c.fillStyle="rgba(0,0,0,0.7)",c.font='bold 11px "Comic Sans MS", "Chalkboard SE", cursive';const z=c.measureText(e.displayName).width;c.fillRect(g-z/2-5,b-h-22,z+10,16),c.fillStyle=e.playerColor||"#fff",c.textAlign="center",c.textBaseline="middle",c.fillText(e.displayName,g,b-h-14)}c.restore(),Oe&&e.isIt&&(c.save(),c.shadowColor="#ff0000",c.shadowBlur=15,c.fillStyle="#ff0000",c.font="bold 16px sans-serif",c.textAlign="center",c.textBaseline="middle",c.fillText("IT",g,b-h-25),c.restore());const H=Date.now();Oe&&e.tagCooldownUntil&&e.tagCooldownUntil>H&&_m(g,u+s/2,e.tagCooldownUntil,H)}function H0(n,e,t,r,i){if(!c)return;const o=e-t;switch(r){case"cap":c.fillStyle="#ef4444",c.beginPath(),c.ellipse(n,o-2,t+2,5,0,0,Math.PI*2),c.fill(),c.fillRect(n-2,o-4,t+8,4);break;case"tophat":c.fillStyle="#1a1a1a",c.fillRect(n-12,o-2,24,4),c.fillRect(n-8,o-18,16,16),c.fillStyle=i,c.fillRect(n-8,o-6,16,3);break;case"crown":c.fillStyle="#fbbf24",c.beginPath(),c.moveTo(n-10,o),c.lineTo(n-10,o-8),c.lineTo(n-6,o-4),c.lineTo(n-3,o-12),c.lineTo(n,o-6),c.lineTo(n+3,o-12),c.lineTo(n+6,o-4),c.lineTo(n+10,o-8),c.lineTo(n+10,o),c.closePath(),c.fill(),c.fillStyle="#dc2626",c.beginPath(),c.arc(n,o-5,2,0,Math.PI*2),c.fill();break;case"beanie":c.fillStyle="#3b82f6",c.beginPath(),c.arc(n,o,t+1,Math.PI,0),c.fill(),c.fillStyle="#fff",c.beginPath(),c.arc(n,o-t-3,4,0,Math.PI*2),c.fill();break;case"party":c.fillStyle="#ec4899",c.beginPath(),c.moveTo(n,o-20),c.lineTo(n-10,o),c.lineTo(n+10,o),c.closePath(),c.fill(),c.strokeStyle="#fbbf24",c.lineWidth=2,c.beginPath(),c.moveTo(n-8,o-4),c.lineTo(n+8,o-4),c.moveTo(n-5,o-10),c.lineTo(n+5,o-10),c.stroke(),c.lineWidth=3;break}}function G0(){if(!c)return;const n=x.x,e=x.y,t=x.width;c.save(),x.facingRight||(c.translate(n+t/2,0),c.scale(-1,1),c.translate(-(n+t/2),0));const r=7,i=13,o=11,s=n+t/2,l=e+r+3,u=l+r,h=u+i;c.strokeStyle=Dt,c.lineWidth=3,c.lineCap="round",c.lineJoin="round",c.shadowColor="rgba(0,0,0,0.3)",c.shadowBlur=4,c.shadowOffsetX=2,c.shadowOffsetY=2;const p=Math.abs(x.vx)>.5;cu?(c.fillStyle=Dt,c.beginPath(),c.moveTo(s-r-2,l+8),c.lineTo(s-r-1,l-2),c.quadraticCurveTo(s-r+2,l-r-4,s,l-r-3),c.quadraticCurveTo(s+r-2,l-r-4,s+r+1,l-2),c.lineTo(s+r+2,l+8),c.quadraticCurveTo(s+r,l+10,s+r-2,l+10),c.lineTo(s-r+2,l+10),c.quadraticCurveTo(s-r,l+10,s-r-2,l+8),c.closePath(),c.fill(),c.fillStyle="#fff",c.beginPath(),c.arc(s,l,r-1,0,Math.PI*2),c.fill(),c.fillStyle=Dt,c.beginPath(),c.moveTo(s-r+2,l-2),c.quadraticCurveTo(s-2,l-r-2,s,l-r+1),c.quadraticCurveTo(s+2,l-r-2,s+r-2,l-2),c.quadraticCurveTo(s,l-1,s-r+2,l-2),c.closePath(),c.fill(),c.fillStyle=Dt,p?(c.beginPath(),c.arc(s+2,l,1.5,0,Math.PI*2),c.fill(),c.lineWidth=2,c.beginPath(),c.moveTo(s,l+4),c.lineTo(s+4,l+4),c.stroke(),c.lineWidth=3):(c.beginPath(),c.arc(s-3,l,1.5,0,Math.PI*2),c.fill(),c.beginPath(),c.arc(s+3,l,1.5,0,Math.PI*2),c.fill(),c.lineWidth=1.5,c.beginPath(),c.arc(s,l+3,2.5,.2*Math.PI,.8*Math.PI),c.stroke(),c.lineWidth=3),c.fillStyle=Dt,c.beginPath(),c.moveTo(s,u),c.lineTo(s-8,h+1),c.lineTo(s+8,h+1),c.closePath(),c.fill()):(c.beginPath(),c.arc(s,l,r,0,Math.PI*2),c.stroke(),c.fillStyle=Dt,c.beginPath(),c.moveTo(s-6,l-r+1),c.lineTo(s-3,l-r-4),c.lineTo(s+8,l-r+3),c.quadraticCurveTo(s,l-r-1,s-6,l-r+1),c.closePath(),c.fill(),c.stroke(),c.fillStyle=Dt,p?(c.beginPath(),c.arc(s+3,l-1,2,0,Math.PI*2),c.fill(),c.beginPath(),c.moveTo(s+1,l+4),c.lineTo(s+5,l+4),c.stroke()):(c.beginPath(),c.arc(s-3,l-1,1.5,0,Math.PI*2),c.fill(),c.beginPath(),c.arc(s+3,l-1,1.5,0,Math.PI*2),c.fill(),c.beginPath(),c.arc(s,l+3,3,.1*Math.PI,.9*Math.PI),c.stroke()),c.beginPath(),c.moveTo(s,u),c.lineTo(s,h),c.stroke());const m=Math.sin(x.animFrame*Math.PI),g=m*.5,b=m*.6,P=Xt?Math.sin(Ds*3)*.5:0;if(c.beginPath(),c.moveTo(s,u+4),Xt){const O=s-o*Math.cos(-.8+P),F=u+4+o*Math.sin(-.8+P);c.lineTo(O,F)}else c.lineTo(s-o*Math.cos(.6+g),u+4+o*Math.sin(.6+g));if(c.stroke(),c.beginPath(),c.moveTo(s,u+4),c.lineTo(s+o*Math.cos(.6-g),u+4+o*Math.sin(.6-g)),c.stroke(),!x.onGround&&x.vy<0)c.beginPath(),c.moveTo(s,h),c.lineTo(s-5,h+o*.7),c.stroke(),c.beginPath(),c.moveTo(s,h),c.lineTo(s+5,h+o*.7),c.stroke();else if(!x.onGround)c.beginPath(),c.moveTo(s,h),c.lineTo(s-8,h+o),c.stroke(),c.beginPath(),c.moveTo(s,h),c.lineTo(s+8,h+o),c.stroke();else{const O=Math.abs(x.vx)>.5;c.beginPath(),c.moveTo(s,h),c.lineTo(s-o*(O?Math.sin(b)*.8:.3),h+o*(O?Math.cos(b*.5):.95)),c.stroke(),c.beginPath(),c.moveTo(s,h),c.lineTo(s+o*(O?Math.sin(b)*.8:.3),h+o*(O?Math.cos(b*.5):.95)),c.stroke()}K0(s,l,r),c.restore(),Oe&&Oo()&&(c.save(),c.shadowColor="#ff0000",c.shadowBlur=15,c.fillStyle="#ff0000",c.font="bold 16px sans-serif",c.textAlign="center",c.textBaseline="middle",c.fillText("IT",s,l-r-20),c.restore());const A=Date.now();Oe&&ln>A&&_m(s,x.y+x.height/2,ln,A)}function _m(n,e,t,r){if(!c)return;const i=t-r;if(i<=0)return;const o=6,s=sa/o,l=Math.ceil(i/s),u=35,h=Math.PI*2/o;c.save();for(let p=0;p<l;p++){const m=-Math.PI/2+p*h,g=m+h-.05;c.fillStyle="rgba(0, 200, 255, 0.3)",c.strokeStyle="rgba(0, 200, 255, 0.7)",c.lineWidth=2,c.beginPath(),c.moveTo(n,e),c.arc(n,e,u,m,g),c.closePath(),c.fill(),c.stroke()}c.strokeStyle="rgba(0, 200, 255, 0.5)",c.lineWidth=3,c.beginPath(),c.arc(n,e,u,0,Math.PI*2),c.stroke(),c.restore()}function K0(n,e,t){c&&(c.shadowBlur=0,Co!=="none"&&Y0(n,e,t),Ro!=="none"&&Q0(n,e,t))}function Y0(n,e,t){if(!c)return;const r=e-t;switch(Co){case"cap":c.fillStyle="#ef4444",c.beginPath(),c.ellipse(n,r-2,t+2,5,0,0,Math.PI*2),c.fill(),c.fillRect(n-2,r-4,t+8,4);break;case"tophat":c.fillStyle="#1a1a1a",c.fillRect(n-7,r-18,14,16),c.fillRect(n-12,r-2,24,4);break;case"crown":c.fillStyle="#fbbf24",c.beginPath(),c.moveTo(n-10,r),c.lineTo(n-10,r-8),c.lineTo(n-6,r-4),c.lineTo(n-3,r-12),c.lineTo(n,r-6),c.lineTo(n+3,r-12),c.lineTo(n+6,r-4),c.lineTo(n+10,r-8),c.lineTo(n+10,r),c.closePath(),c.fill(),c.fillStyle="#dc2626",c.beginPath(),c.arc(n,r-5,2,0,Math.PI*2),c.fill();break;case"beanie":c.fillStyle="#3b82f6",c.beginPath(),c.arc(n,r,t+1,Math.PI,0),c.fill(),c.fillStyle="#fff",c.beginPath(),c.arc(n,r-t-3,4,0,Math.PI*2),c.fill();break;case"party":c.fillStyle="#ec4899",c.beginPath(),c.moveTo(n,r-20),c.lineTo(n-10,r),c.lineTo(n+10,r),c.closePath(),c.fill(),c.strokeStyle="#fbbf24",c.lineWidth=2,c.beginPath(),c.moveTo(n-8,r-4),c.lineTo(n+8,r-4),c.moveTo(n-5,r-10),c.lineTo(n+5,r-10),c.stroke(),c.lineWidth=3;break}}function Q0(n,e,t){if(c)switch(Ro){case"glasses":c.strokeStyle="#333",c.lineWidth=1.5,c.beginPath(),c.arc(n-4,e-1,4,0,Math.PI*2),c.arc(n+4,e-1,4,0,Math.PI*2),c.stroke(),c.beginPath(),c.moveTo(n-1,e-1),c.lineTo(n+1,e-1),c.stroke(),c.lineWidth=3;break;case"sunglasses":c.fillStyle="#1a1a1a",c.fillRect(n-9,e-3,7,5),c.fillRect(n+2,e-3,7,5),c.fillRect(n-2,e-2,4,2);break;case"mustache":c.fillStyle="#4a3728",c.beginPath(),c.moveTo(n-8,e+3),c.quadraticCurveTo(n-4,e+6,n,e+4),c.quadraticCurveTo(n+4,e+6,n+8,e+3),c.quadraticCurveTo(n+4,e+4,n,e+3),c.quadraticCurveTo(n-4,e+4,n-8,e+3),c.fill();break;case"beard":c.fillStyle="#4a3728",c.beginPath(),c.moveTo(n-t+2,e+2),c.quadraticCurveTo(n-t,e+10,n,e+14),c.quadraticCurveTo(n+t,e+10,n+t-2,e+2),c.quadraticCurveTo(n,e+6,n-t+2,e+2),c.fill();break;case"mask":c.fillStyle="#1a1a1a",c.beginPath(),c.ellipse(n,e-1,t-1,4,0,0,Math.PI*2),c.fill(),c.fillStyle="#fff",c.beginPath(),c.ellipse(n-4,e-1,2.5,2,0,0,Math.PI*2),c.ellipse(n+4,e-1,2.5,2,0,0,Math.PI*2),c.fill();break}}function X0(){if(!c)return;const n=window.scrollX,e=window.scrollY;c.save();const t=kt==="race"?260:180;c.fillStyle="rgba(0,0,0,0.8)",c.fillRect(n+10,e+10,t,70);let r="EXPLORE MODE",i="#22c55e";if(Oe?(r="TAG MODE",i="#f97316"):kt==="race"&&(r="RACE MODE",i="#ef4444"),c.fillStyle=i,c.font="bold 11px sans-serif",c.fillText(r,n+20,e+25),kt==="race"){const o=(xi/1e3).toFixed(2);c.fillStyle="#fff",c.font="bold 20px monospace";const s=un?"Ready...":ht?`${o}s`:Bn<=0?"GAME OVER":`${o}s`;c.fillText(s,n+20,e+48),c.font="14px sans-serif",c.fillStyle="#888",c.fillText("Lives:",n+155,e+48);for(let l=0;l<uu;l++){const u=n+200+l*20,h=e+40;l<Bn?(c.strokeStyle="#22c55e",c.lineWidth=2,c.beginPath(),c.arc(u,h-6,4,0,Math.PI*2),c.stroke(),c.beginPath(),c.moveTo(u,h-2),c.lineTo(u,h+6),c.stroke(),c.beginPath(),c.moveTo(u-4,h+1),c.lineTo(u+4,h+1),c.stroke(),c.beginPath(),c.moveTo(u,h+6),c.lineTo(u-3,h+12),c.moveTo(u,h+6),c.lineTo(u+3,h+12),c.stroke()):(c.strokeStyle="#ef4444",c.lineWidth=2,c.beginPath(),c.moveTo(u-5,h-8),c.lineTo(u+5,h+8),c.moveTo(u+5,h-8),c.lineTo(u-5,h+8),c.stroke())}le.bestTime&&(c.fillStyle="#fbbf24",c.font="12px monospace",c.fillText(`Best: ${(le.bestTime/1e3).toFixed(2)}s`,n+20,e+66)),Bn<=0&&(c.fillStyle="#ef4444",c.font="bold 14px sans-serif",c.fillText("GAME OVER - Press Play to retry",n+20,e+100))}else if(Oe){if(Oo())c.fillStyle="#ff4444",c.font="bold 16px sans-serif",c.fillText("You're IT! Tag someone!",n+20,e+48);else{let s="",l=!1;if(wt!=null&&wt.itPlayerId){l=!0;for(const[u,h]of It)if(u===wt.itPlayerId){s=h.displayName||"Another player";break}}if(!s){for(const[,u]of It)if(u.isIt){s=u.displayName||"Another player",l=!0;break}}!l&&we&&(l=!0),s?(c.fillStyle="#22c55e",c.font="bold 16px sans-serif",c.fillText("Run! "+s+" is IT!",n+20,e+48)):l?(c.fillStyle="#22c55e",c.font="bold 16px sans-serif",c.fillText("Run! Someone is IT!",n+20,e+48)):(c.fillStyle="#fff",c.font="16px sans-serif",c.fillText("Waiting for IT player...",n+20,e+48))}c.fillStyle="#888",c.font="12px sans-serif",c.fillText("Touch another player to tag them",n+20,e+66)}else c.fillStyle="#fff",c.font="16px sans-serif",c.fillText("Explore freely!",n+20,e+48),c.fillStyle="#888",c.font="12px sans-serif",c.fillText("No timer, unlimited respawns",n+20,e+66);if(c.fillStyle="#666",c.font="11px sans-serif",c.fillText("WASD/Arrows, Space=jump, L=leaderboard",n+10,e+95),J0(),Z0(),un&&Z){const o=performance.now()-du,l=fm-o>1e3?"2":"1";Z.fillStyle="rgba(0, 0, 0, 0.5)",Z.fillRect(n,e,window.innerWidth,window.innerHeight),Z.fillStyle="#fff",Z.font="bold 120px sans-serif",Z.textAlign="center",Z.textBaseline="middle",Z.fillText(l,n+window.innerWidth/2,e+window.innerHeight/2),Z.textBaseline="alphabetic",Z.textAlign="left"}c.restore()}function J0(){if(!Z||!Ie)return;const n=window.scrollX,e=window.scrollY,t=200,r=Ie.subtext?60:40,i=n+20,o=e+window.innerHeight-r-20;Z.fillStyle="rgba(0, 0, 0, 0.9)",Z.fillRect(i,o,t,r),Z.strokeStyle=Ie.text==="GO!"?"#22c55e":Ie.text==="GAME OVER"?"#ef4444":Ie.text==="You fell!"?"#f59e0b":"#3b82f6",Z.lineWidth=2,Z.strokeRect(i,o,t,r),Z.fillStyle="#fff",Z.font="bold 16px sans-serif",Z.textAlign="center";const s=Ie.subtext?o+22:o+26;Z.fillText(Ie.text,i+t/2,s),Ie.subtext&&(Z.fillStyle="#888",Z.font="13px sans-serif",Z.fillText(Ie.subtext,i+t/2,o+44)),Z.textAlign="left"}function Z0(){if(!Z||performance.now()>Wl)return;const n=window.scrollX,e=window.scrollY,t=window.innerWidth,r=window.innerHeight,o=(Wl-performance.now())/dm,s=Math.min(.7,o*.9);Z.save(),Z.fillStyle=`rgba(220, 38, 38, ${s*.3})`,Z.fillRect(n,e,t,r);const l=Math.min(1,o*1.5);Z.font="bold 72px sans-serif",Z.textAlign="center",Z.textBaseline="middle",Z.shadowColor="#ff0000",Z.shadowBlur=30,Z.fillStyle=`rgba(255, 255, 255, ${l})`,Z.fillText("NO TAG BACKS",n+t/2,e+r/2),Z.shadowBlur=15,Z.fillText("NO TAG BACKS",n+t/2,e+r/2),Z.restore()}function eA(){if(!c)return;const n=window.scrollX,e=window.scrollY;c.save(),c.fillStyle="rgba(0,0,0,0.8)",c.fillRect(n+10,e+10,200,35),c.fillStyle="#22c55e",c.font="bold 14px sans-serif",c.fillText("BUILD MODE",n+20,e+32),c.fillStyle="#888",c.font="12px sans-serif";const t=Po.charAt(0).toUpperCase()+Po.slice(1);c.fillText(`Tool: ${t}`,n+115,e+32),c.restore()}function tA(n){var r;if(Se!=="play"||ai)return;let e=document.activeElement;for(;(r=e==null?void 0:e.shadowRoot)!=null&&r.activeElement;)e=e.shadowRoot.activeElement;if(!(e&&(e.tagName==="INPUT"||e.tagName==="TEXTAREA"||e.isContentEditable))){if(Zt[n.code]=!0,n.code==="Tab"||n.code==="KeyL"){n.preventDefault(),nt();return}["ArrowUp","ArrowDown","ArrowLeft","ArrowRight","Space"].includes(n.code)&&n.preventDefault()}}function nA(n){Zt[n.code]=!1}let li=null;function rA(n,e){for(const t of le.checkpoints)if(t.width&&t.height){const r=t.x-t.width/2,i=t.x+t.width/2,o=t.y-t.height,s=t.y;if(n>=r&&n<=i&&e>=o&&e<=s)return t}else if(Math.hypot(n-t.x,e-t.y)<40)return t;return null}function iA(n){if(Se!=="build")return;const e=n.pageX,t=n.pageY,r=rA(e,t);if(r){if(n.button===2||n.shiftKey){le.checkpoints=le.checkpoints.filter(l=>l.id!==r.id),_i(),nt();return}li=r,ve&&(ve.style.cursor="grabbing");return}if(Po==="select")return;const i=Po;(i==="start"||i==="finish"||i==="spawn")&&(le.checkpoints=le.checkpoints.filter(l=>l.type!==i));const o=i==="start"?0:i==="finish"?999:i==="spawn"?-1:i==="checkpoint"?le.checkpoints.filter(l=>l.type==="checkpoint").length+1:0,s={id:wm(),type:i,x:e,y:t,order:o,reached:!1};i==="trampoline"||i==="speedBoost"||i==="highJump"?(s.width=60,s.height=20):i==="spike"&&(s.width=60,s.height=30),le.checkpoints.push(s),_i(),nt()}function oA(n){Se==="build"&&li&&(li.x=n.pageX,li.y=n.pageY,nt())}function sA(n){li&&(_i(),li=null,ve&&(ve.style.cursor="crosshair"))}function wm(){return Math.random().toString(36).substr(2,9)}async function _i(){const n=mn();localStorage.setItem(`oo_course_${n}`,JSON.stringify(le)),ta()&&await bI(n,le),console.log("[OpenOverlay] Course saved")}function aA(){const n=mn();Rr()&&TI(n,t=>{t.myCourse&&(le=t.myCourse,le.checkpoints.forEach(r=>r.reached=!1),localStorage.setItem(`oo_course_${n}`,JSON.stringify(le))),No=t.otherCourses.map(r=>({...r,checkpoints:(r.checkpoints||[]).map(i=>({...i,reached:!1}))})),console.log("[OpenOverlay] Course sync: mine=",le.checkpoints.length,"elements, others=",No.length,"courses"),Se!=="none"&&nt()});const e=localStorage.getItem(`oo_course_${n}`);if(e)try{le=JSON.parse(e),le.checkpoints.forEach(t=>t.reached=!1),console.log("[OpenOverlay] Course loaded from localStorage:",le.checkpoints.length,"checkpoints")}catch{console.warn("[OpenOverlay] Failed to load course")}}function mn(){return btoa(window.location.href).slice(0,32)}function bm(){return`oo_scores_${mn()}`}function lA(){const n=new Date;return new Date(n.getFullYear(),n.getMonth(),n.getDate()).getTime()}function Tm(){const n=localStorage.getItem(bm());if(!n)return[];try{const e=JSON.parse(n),t=lA();return e.filter(r=>r.timestamp>=t)}catch{return[]}}function ws(n,e){const t=Tm();t.push({name:n,time:e,timestamp:Date.now()}),t.sort((r,i)=>r.time-i.time),localStorage.setItem(bm(),JSON.stringify(t)),localStorage.setItem("oo_player_name",n),po=n}function cA(){const n=Tm(),e=n.slice(0,10);let t=null,r=-1;if(po){const i=n.filter(o=>o.name===po);i.length>0&&(t=i[0],r=n.findIndex(o=>o.name===po&&o.time===t.time)+1)}return{top10:e,playerBest:t,playerRank:r}}function uA(){if(console.log("[OpenOverlay] toggleTagMode called, current isTagMode:",Oe),Oe)Oe=!1,we=!1,Jt=null,Dn=null,gr=0,console.log("[OpenOverlay] Left tag mode"),document.dispatchEvent(new CustomEvent("oo:tagstatechange",{detail:{isTagMode:!1,isIt:!1,gameActive:!1}})),Pt("Left tag game","",1500);else{Oe=!0;const n=mn();console.log("[OpenOverlay] Starting/joining tag game on page:",n);let e=!1;for(const[,t]of It)if(t.isIt){e=!0;break}we=!e,console.log("[OpenOverlay] localIsIt:",we,"someoneElseIsIt:",e),document.dispatchEvent(new CustomEvent("oo:tagstatechange",{detail:{isTagMode:!0,isIt:we,gameActive:!0}})),Do(),console.log("[OpenOverlay] Forced sync with isIt:",we),we?Pt("You're IT!","Tag another player!",2e3):Pt("Tag Mode!","Avoid being tagged!",2e3),vI(n).then(t=>{console.log("[OpenOverlay] startTagGame returned:",t),t&&!we&&(we=!0,document.dispatchEvent(new CustomEvent("oo:tagstatechange",{detail:{isTagMode:!0,isIt:!0,gameActive:!0}})))}).catch(t=>{console.log("[OpenOverlay] Firebase unavailable, using local tag state:",we)})}}if(window.__OPENOVERLAY_V2__)console.log("[OpenOverlay] Already injected, skipping");else{let n=function(){console.log("[OpenOverlay] init() called"),console.log("[OpenOverlay] document.body exists:",!!document.body);try{eI(),EI()}catch(e){console.warn("[OpenOverlay] Firebase init failed (may be incognito):",e)}try{XI(),l0(),xI(),L0(),console.log("[OpenOverlay] Ready!")}catch(e){console.error("[OpenOverlay] UI init error:",e)}};window.__OPENOVERLAY_V2__=!0,console.log("[OpenOverlay] v2.0.0 starting..."),document.body?n():document.readyState==="loading"?document.addEventListener("DOMContentLoaded",n):setTimeout(n,100)}
})()
