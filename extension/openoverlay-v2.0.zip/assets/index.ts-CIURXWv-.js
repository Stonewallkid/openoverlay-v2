(function(){const gv=()=>{};var vh={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Sp=function(n){const e=[];let t=0;for(let o=0;o<n.length;o++){let r=n.charCodeAt(o);r<128?e[t++]=r:r<2048?(e[t++]=r>>6|192,e[t++]=r&63|128):(r&64512)===55296&&o+1<n.length&&(n.charCodeAt(o+1)&64512)===56320?(r=65536+((r&1023)<<10)+(n.charCodeAt(++o)&1023),e[t++]=r>>18|240,e[t++]=r>>12&63|128,e[t++]=r>>6&63|128,e[t++]=r&63|128):(e[t++]=r>>12|224,e[t++]=r>>6&63|128,e[t++]=r&63|128)}return e},mv=function(n){const e=[];let t=0,o=0;for(;t<n.length;){const r=n[t++];if(r<128)e[o++]=String.fromCharCode(r);else if(r>191&&r<224){const i=n[t++];e[o++]=String.fromCharCode((r&31)<<6|i&63)}else if(r>239&&r<365){const i=n[t++],s=n[t++],c=n[t++],d=((r&7)<<18|(i&63)<<12|(s&63)<<6|c&63)-65536;e[o++]=String.fromCharCode(55296+(d>>10)),e[o++]=String.fromCharCode(56320+(d&1023))}else{const i=n[t++],s=n[t++];e[o++]=String.fromCharCode((r&15)<<12|(i&63)<<6|s&63)}}return e.join("")},Ap={byteToCharMap_:null,charToByteMap_:null,byteToCharMapWebSafe_:null,charToByteMapWebSafe_:null,ENCODED_VALS_BASE:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",get ENCODED_VALS(){return this.ENCODED_VALS_BASE+"+/="},get ENCODED_VALS_WEBSAFE(){return this.ENCODED_VALS_BASE+"-_."},HAS_NATIVE_SUPPORT:typeof atob=="function",encodeByteArray(n,e){if(!Array.isArray(n))throw Error("encodeByteArray takes an array as a parameter");this.init_();const t=e?this.byteToCharMapWebSafe_:this.byteToCharMap_,o=[];for(let r=0;r<n.length;r+=3){const i=n[r],s=r+1<n.length,c=s?n[r+1]:0,d=r+2<n.length,u=d?n[r+2]:0,f=i>>2,g=(i&3)<<4|c>>4;let m=(c&15)<<2|u>>6,v=u&63;d||(v=64,s||(m=64)),o.push(t[f],t[g],t[m],t[v])}return o.join("")},encodeString(n,e){return this.HAS_NATIVE_SUPPORT&&!e?btoa(n):this.encodeByteArray(Sp(n),e)},decodeString(n,e){return this.HAS_NATIVE_SUPPORT&&!e?atob(n):mv(this.decodeStringToByteArray(n,e))},decodeStringToByteArray(n,e){this.init_();const t=e?this.charToByteMapWebSafe_:this.charToByteMap_,o=[];for(let r=0;r<n.length;){const i=t[n.charAt(r++)],c=r<n.length?t[n.charAt(r)]:0;++r;const u=r<n.length?t[n.charAt(r)]:64;++r;const g=r<n.length?t[n.charAt(r)]:64;if(++r,i==null||c==null||u==null||g==null)throw new yv;const m=i<<2|c>>4;if(o.push(m),u!==64){const v=c<<4&240|u>>2;if(o.push(v),g!==64){const O=u<<6&192|g;o.push(O)}}}return o},init_(){if(!this.byteToCharMap_){this.byteToCharMap_={},this.charToByteMap_={},this.byteToCharMapWebSafe_={},this.charToByteMapWebSafe_={};for(let n=0;n<this.ENCODED_VALS.length;n++)this.byteToCharMap_[n]=this.ENCODED_VALS.charAt(n),this.charToByteMap_[this.byteToCharMap_[n]]=n,this.byteToCharMapWebSafe_[n]=this.ENCODED_VALS_WEBSAFE.charAt(n),this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[n]]=n,n>=this.ENCODED_VALS_BASE.length&&(this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(n)]=n,this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(n)]=n)}}};class yv extends Error{constructor(){super(...arguments),this.name="DecodeBase64StringError"}}const vv=function(n){const e=Sp(n);return Ap.encodeByteArray(e,!0)},Ia=function(n){return vv(n).replace(/\./g,"")},kp=function(n){try{return Ap.decodeString(n,!0)}catch(e){console.error("base64Decode failed: ",e)}return null};/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function bv(){if(typeof self<"u")return self;if(typeof window<"u")return window;if(typeof global<"u")return global;throw new Error("Unable to locate global object.")}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const wv=()=>bv().__FIREBASE_DEFAULTS__,_v=()=>{if(typeof process>"u"||typeof vh>"u")return;const n=vh.__FIREBASE_DEFAULTS__;if(n)return JSON.parse(n)},Tv=()=>{if(typeof document>"u")return;let n;try{n=document.cookie.match(/__FIREBASE_DEFAULTS__=([^;]+)/)}catch{return}const e=n&&kp(n[1]);return e&&JSON.parse(e)},tl=()=>{try{return gv()||wv()||_v()||Tv()}catch(n){console.info(`Unable to get __FIREBASE_DEFAULTS__ due to: ${n}`);return}},Cp=n=>{var e,t;return(t=(e=tl())==null?void 0:e.emulatorHosts)==null?void 0:t[n]},Ev=n=>{const e=Cp(n);if(!e)return;const t=e.lastIndexOf(":");if(t<=0||t+1===e.length)throw new Error(`Invalid host ${e} with no separate hostname and port!`);const o=parseInt(e.substring(t+1),10);return e[0]==="["?[e.substring(1,t-1),o]:[e.substring(0,t),o]},Pp=()=>{var n;return(n=tl())==null?void 0:n.config},Rp=n=>{var e;return(e=tl())==null?void 0:e[`_${n}`]};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Iv{constructor(){this.reject=()=>{},this.resolve=()=>{},this.promise=new Promise((e,t)=>{this.resolve=e,this.reject=t})}wrapCallback(e){return(t,o)=>{t?this.reject(t):this.resolve(o),typeof e=="function"&&(this.promise.catch(()=>{}),e.length===1?e(t):e(t,o))}}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function xv(n,e){if(n.uid)throw new Error('The "uid" field is no longer supported by mockUserToken. Please use "sub" instead for Firebase Auth User ID.');const t={alg:"none",type:"JWT"},o=e||"demo-project",r=n.iat||0,i=n.sub||n.user_id;if(!i)throw new Error("mockUserToken must contain 'sub' or 'user_id' field!");const s={iss:`https://securetoken.google.com/${o}`,aud:o,iat:r,exp:r+3600,auth_time:r,sub:i,user_id:i,firebase:{sign_in_provider:"custom",identities:{}},...n};return[Ia(JSON.stringify(t)),Ia(JSON.stringify(s)),""].join(".")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ft(){return typeof navigator<"u"&&typeof navigator.userAgent=="string"?navigator.userAgent:""}function Sv(){return typeof window<"u"&&!!(window.cordova||window.phonegap||window.PhoneGap)&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i.test(ft())}function Av(){var e;const n=(e=tl())==null?void 0:e.forceEnvironment;if(n==="node")return!0;if(n==="browser")return!1;try{return Object.prototype.toString.call(global.process)==="[object process]"}catch{return!1}}function kv(){return typeof navigator<"u"&&navigator.userAgent==="Cloudflare-Workers"}function Cv(){const n=typeof chrome=="object"?chrome.runtime:typeof browser=="object"?browser.runtime:void 0;return typeof n=="object"&&n.id!==void 0}function Pv(){return typeof navigator=="object"&&navigator.product==="ReactNative"}function Rv(){const n=ft();return n.indexOf("MSIE ")>=0||n.indexOf("Trident/")>=0}function Ov(){return!Av()&&!!navigator.userAgent&&navigator.userAgent.includes("Safari")&&!navigator.userAgent.includes("Chrome")}function Mv(){try{return typeof indexedDB=="object"}catch{return!1}}function Nv(){return new Promise((n,e)=>{try{let t=!0;const o="validate-browser-context-for-indexeddb-analytics-module",r=self.indexedDB.open(o);r.onsuccess=()=>{r.result.close(),t||self.indexedDB.deleteDatabase(o),n(!0)},r.onupgradeneeded=()=>{t=!1},r.onerror=()=>{var i;e(((i=r.error)==null?void 0:i.message)||"")}}catch(t){e(t)}})}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Lv="FirebaseError";class Un extends Error{constructor(e,t,o){super(t),this.code=e,this.customData=o,this.name=Lv,Object.setPrototypeOf(this,Un.prototype),Error.captureStackTrace&&Error.captureStackTrace(this,bs.prototype.create)}}class bs{constructor(e,t,o){this.service=e,this.serviceName=t,this.errors=o}create(e,...t){const o=t[0]||{},r=`${this.service}/${e}`,i=this.errors[e],s=i?Dv(i,o):"Error",c=`${this.serviceName}: ${s} (${r}).`;return new Un(r,c,o)}}function Dv(n,e){return n.replace(Vv,(t,o)=>{const r=e[o];return r!=null?String(r):`<${o}?>`})}const Vv=/\{\$([^}]+)}/g;function Fv(n){for(const e in n)if(Object.prototype.hasOwnProperty.call(n,e))return!1;return!0}function jo(n,e){if(n===e)return!0;const t=Object.keys(n),o=Object.keys(e);for(const r of t){if(!o.includes(r))return!1;const i=n[r],s=e[r];if(bh(i)&&bh(s)){if(!jo(i,s))return!1}else if(i!==s)return!1}for(const r of o)if(!t.includes(r))return!1;return!0}function bh(n){return n!==null&&typeof n=="object"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ws(n){const e=[];for(const[t,o]of Object.entries(n))Array.isArray(o)?o.forEach(r=>{e.push(encodeURIComponent(t)+"="+encodeURIComponent(r))}):e.push(encodeURIComponent(t)+"="+encodeURIComponent(o));return e.length?"&"+e.join("&"):""}function Uv(n,e){const t=new qv(n,e);return t.subscribe.bind(t)}class qv{constructor(e,t){this.observers=[],this.unsubscribes=[],this.observerCount=0,this.task=Promise.resolve(),this.finalized=!1,this.onNoObservers=t,this.task.then(()=>{e(this)}).catch(o=>{this.error(o)})}next(e){this.forEachObserver(t=>{t.next(e)})}error(e){this.forEachObserver(t=>{t.error(e)}),this.close(e)}complete(){this.forEachObserver(e=>{e.complete()}),this.close()}subscribe(e,t,o){let r;if(e===void 0&&t===void 0&&o===void 0)throw new Error("Missing Observer.");zv(e,["next","error","complete"])?r=e:r={next:e,error:t,complete:o},r.next===void 0&&(r.next=zl),r.error===void 0&&(r.error=zl),r.complete===void 0&&(r.complete=zl);const i=this.unsubscribeOne.bind(this,this.observers.length);return this.finalized&&this.task.then(()=>{try{this.finalError?r.error(this.finalError):r.complete()}catch{}}),this.observers.push(r),i}unsubscribeOne(e){this.observers===void 0||this.observers[e]===void 0||(delete this.observers[e],this.observerCount-=1,this.observerCount===0&&this.onNoObservers!==void 0&&this.onNoObservers(this))}forEachObserver(e){if(!this.finalized)for(let t=0;t<this.observers.length;t++)this.sendOne(t,e)}sendOne(e,t){this.task.then(()=>{if(this.observers!==void 0&&this.observers[e]!==void 0)try{t(this.observers[e])}catch(o){typeof console<"u"&&console.error&&console.error(o)}})}close(e){this.finalized||(this.finalized=!0,e!==void 0&&(this.finalError=e),this.task.then(()=>{this.observers=void 0,this.onNoObservers=void 0}))}}function zv(n,e){if(typeof n!="object"||n===null)return!1;for(const t of e)if(t in n&&typeof n[t]=="function")return!0;return!1}function zl(){}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function rt(n){return n&&n._delegate?n._delegate:n}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function _s(n){try{return(n.startsWith("http://")||n.startsWith("https://")?new URL(n).hostname:n).endsWith(".cloudworkstations.dev")}catch{return!1}}async function Op(n){return(await fetch(n,{credentials:"include"})).ok}class Wo{constructor(e,t,o){this.name=e,this.instanceFactory=t,this.type=o,this.multipleInstances=!1,this.serviceProps={},this.instantiationMode="LAZY",this.onInstanceCreated=null}setInstantiationMode(e){return this.instantiationMode=e,this}setMultipleInstances(e){return this.multipleInstances=e,this}setServiceProps(e){return this.serviceProps=e,this}setInstanceCreatedCallback(e){return this.onInstanceCreated=e,this}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Co="[DEFAULT]";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Bv{constructor(e,t){this.name=e,this.container=t,this.component=null,this.instances=new Map,this.instancesDeferred=new Map,this.instancesOptions=new Map,this.onInitCallbacks=new Map}get(e){const t=this.normalizeInstanceIdentifier(e);if(!this.instancesDeferred.has(t)){const o=new Iv;if(this.instancesDeferred.set(t,o),this.isInitialized(t)||this.shouldAutoInitialize())try{const r=this.getOrInitializeService({instanceIdentifier:t});r&&o.resolve(r)}catch{}}return this.instancesDeferred.get(t).promise}getImmediate(e){const t=this.normalizeInstanceIdentifier(e==null?void 0:e.identifier),o=(e==null?void 0:e.optional)??!1;if(this.isInitialized(t)||this.shouldAutoInitialize())try{return this.getOrInitializeService({instanceIdentifier:t})}catch(r){if(o)return null;throw r}else{if(o)return null;throw Error(`Service ${this.name} is not available`)}}getComponent(){return this.component}setComponent(e){if(e.name!==this.name)throw Error(`Mismatching Component ${e.name} for Provider ${this.name}.`);if(this.component)throw Error(`Component for ${this.name} has already been provided`);if(this.component=e,!!this.shouldAutoInitialize()){if(jv(e))try{this.getOrInitializeService({instanceIdentifier:Co})}catch{}for(const[t,o]of this.instancesDeferred.entries()){const r=this.normalizeInstanceIdentifier(t);try{const i=this.getOrInitializeService({instanceIdentifier:r});o.resolve(i)}catch{}}}}clearInstance(e=Co){this.instancesDeferred.delete(e),this.instancesOptions.delete(e),this.instances.delete(e)}async delete(){const e=Array.from(this.instances.values());await Promise.all([...e.filter(t=>"INTERNAL"in t).map(t=>t.INTERNAL.delete()),...e.filter(t=>"_delete"in t).map(t=>t._delete())])}isComponentSet(){return this.component!=null}isInitialized(e=Co){return this.instances.has(e)}getOptions(e=Co){return this.instancesOptions.get(e)||{}}initialize(e={}){const{options:t={}}=e,o=this.normalizeInstanceIdentifier(e.instanceIdentifier);if(this.isInitialized(o))throw Error(`${this.name}(${o}) has already been initialized`);if(!this.isComponentSet())throw Error(`Component ${this.name} has not been registered yet`);const r=this.getOrInitializeService({instanceIdentifier:o,options:t});for(const[i,s]of this.instancesDeferred.entries()){const c=this.normalizeInstanceIdentifier(i);o===c&&s.resolve(r)}return r}onInit(e,t){const o=this.normalizeInstanceIdentifier(t),r=this.onInitCallbacks.get(o)??new Set;r.add(e),this.onInitCallbacks.set(o,r);const i=this.instances.get(o);return i&&e(i,o),()=>{r.delete(e)}}invokeOnInitCallbacks(e,t){const o=this.onInitCallbacks.get(t);if(o)for(const r of o)try{r(e,t)}catch{}}getOrInitializeService({instanceIdentifier:e,options:t={}}){let o=this.instances.get(e);if(!o&&this.component&&(o=this.component.instanceFactory(this.container,{instanceIdentifier:$v(e),options:t}),this.instances.set(e,o),this.instancesOptions.set(e,t),this.invokeOnInitCallbacks(o,e),this.component.onInstanceCreated))try{this.component.onInstanceCreated(this.container,e,o)}catch{}return o||null}normalizeInstanceIdentifier(e=Co){return this.component?this.component.multipleInstances?e:Co:e}shouldAutoInitialize(){return!!this.component&&this.component.instantiationMode!=="EXPLICIT"}}function $v(n){return n===Co?void 0:n}function jv(n){return n.instantiationMode==="EAGER"}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Wv{constructor(e){this.name=e,this.providers=new Map}addComponent(e){const t=this.getProvider(e.name);if(t.isComponentSet())throw new Error(`Component ${e.name} has already been registered with ${this.name}`);t.setComponent(e)}addOrOverwriteComponent(e){this.getProvider(e.name).isComponentSet()&&this.providers.delete(e.name),this.addComponent(e)}getProvider(e){if(this.providers.has(e))return this.providers.get(e);const t=new Bv(e,this);return this.providers.set(e,t),t}getProviders(){return Array.from(this.providers.values())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var de;(function(n){n[n.DEBUG=0]="DEBUG",n[n.VERBOSE=1]="VERBOSE",n[n.INFO=2]="INFO",n[n.WARN=3]="WARN",n[n.ERROR=4]="ERROR",n[n.SILENT=5]="SILENT"})(de||(de={}));const Hv={debug:de.DEBUG,verbose:de.VERBOSE,info:de.INFO,warn:de.WARN,error:de.ERROR,silent:de.SILENT},Gv=de.INFO,Yv={[de.DEBUG]:"log",[de.VERBOSE]:"log",[de.INFO]:"info",[de.WARN]:"warn",[de.ERROR]:"error"},Kv=(n,e,...t)=>{if(e<n.logLevel)return;const o=new Date().toISOString(),r=Yv[e];if(r)console[r](`[${o}]  ${n.name}:`,...t);else throw new Error(`Attempted to log a message with an invalid logType (value: ${e})`)};class au{constructor(e){this.name=e,this._logLevel=Gv,this._logHandler=Kv,this._userLogHandler=null}get logLevel(){return this._logLevel}set logLevel(e){if(!(e in de))throw new TypeError(`Invalid value "${e}" assigned to \`logLevel\``);this._logLevel=e}setLogLevel(e){this._logLevel=typeof e=="string"?Hv[e]:e}get logHandler(){return this._logHandler}set logHandler(e){if(typeof e!="function")throw new TypeError("Value assigned to `logHandler` must be a function");this._logHandler=e}get userLogHandler(){return this._userLogHandler}set userLogHandler(e){this._userLogHandler=e}debug(...e){this._userLogHandler&&this._userLogHandler(this,de.DEBUG,...e),this._logHandler(this,de.DEBUG,...e)}log(...e){this._userLogHandler&&this._userLogHandler(this,de.VERBOSE,...e),this._logHandler(this,de.VERBOSE,...e)}info(...e){this._userLogHandler&&this._userLogHandler(this,de.INFO,...e),this._logHandler(this,de.INFO,...e)}warn(...e){this._userLogHandler&&this._userLogHandler(this,de.WARN,...e),this._logHandler(this,de.WARN,...e)}error(...e){this._userLogHandler&&this._userLogHandler(this,de.ERROR,...e),this._logHandler(this,de.ERROR,...e)}}const Xv=(n,e)=>e.some(t=>n instanceof t);let wh,_h;function Qv(){return wh||(wh=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction])}function Jv(){return _h||(_h=[IDBCursor.prototype.advance,IDBCursor.prototype.continue,IDBCursor.prototype.continuePrimaryKey])}const Mp=new WeakMap,uc=new WeakMap,Np=new WeakMap,Bl=new WeakMap,lu=new WeakMap;function Zv(n){const e=new Promise((t,o)=>{const r=()=>{n.removeEventListener("success",i),n.removeEventListener("error",s)},i=()=>{t(oo(n.result)),r()},s=()=>{o(n.error),r()};n.addEventListener("success",i),n.addEventListener("error",s)});return e.then(t=>{t instanceof IDBCursor&&Mp.set(t,n)}).catch(()=>{}),lu.set(e,n),e}function eb(n){if(uc.has(n))return;const e=new Promise((t,o)=>{const r=()=>{n.removeEventListener("complete",i),n.removeEventListener("error",s),n.removeEventListener("abort",s)},i=()=>{t(),r()},s=()=>{o(n.error||new DOMException("AbortError","AbortError")),r()};n.addEventListener("complete",i),n.addEventListener("error",s),n.addEventListener("abort",s)});uc.set(n,e)}let dc={get(n,e,t){if(n instanceof IDBTransaction){if(e==="done")return uc.get(n);if(e==="objectStoreNames")return n.objectStoreNames||Np.get(n);if(e==="store")return t.objectStoreNames[1]?void 0:t.objectStore(t.objectStoreNames[0])}return oo(n[e])},set(n,e,t){return n[e]=t,!0},has(n,e){return n instanceof IDBTransaction&&(e==="done"||e==="store")?!0:e in n}};function tb(n){dc=n(dc)}function nb(n){return n===IDBDatabase.prototype.transaction&&!("objectStoreNames"in IDBTransaction.prototype)?function(e,...t){const o=n.call($l(this),e,...t);return Np.set(o,e.sort?e.sort():[e]),oo(o)}:Jv().includes(n)?function(...e){return n.apply($l(this),e),oo(Mp.get(this))}:function(...e){return oo(n.apply($l(this),e))}}function ob(n){return typeof n=="function"?nb(n):(n instanceof IDBTransaction&&eb(n),Xv(n,Qv())?new Proxy(n,dc):n)}function oo(n){if(n instanceof IDBRequest)return Zv(n);if(Bl.has(n))return Bl.get(n);const e=ob(n);return e!==n&&(Bl.set(n,e),lu.set(e,n)),e}const $l=n=>lu.get(n);function rb(n,e,{blocked:t,upgrade:o,blocking:r,terminated:i}={}){const s=indexedDB.open(n,e),c=oo(s);return o&&s.addEventListener("upgradeneeded",d=>{o(oo(s.result),d.oldVersion,d.newVersion,oo(s.transaction),d)}),t&&s.addEventListener("blocked",d=>t(d.oldVersion,d.newVersion,d)),c.then(d=>{i&&d.addEventListener("close",()=>i()),r&&d.addEventListener("versionchange",u=>r(u.oldVersion,u.newVersion,u))}).catch(()=>{}),c}const ib=["get","getKey","getAll","getAllKeys","count"],sb=["put","add","delete","clear"],jl=new Map;function Th(n,e){if(!(n instanceof IDBDatabase&&!(e in n)&&typeof e=="string"))return;if(jl.get(e))return jl.get(e);const t=e.replace(/FromIndex$/,""),o=e!==t,r=sb.includes(t);if(!(t in(o?IDBIndex:IDBObjectStore).prototype)||!(r||ib.includes(t)))return;const i=async function(s,...c){const d=this.transaction(s,r?"readwrite":"readonly");let u=d.store;return o&&(u=u.index(c.shift())),(await Promise.all([u[t](...c),r&&d.done]))[0]};return jl.set(e,i),i}tb(n=>({...n,get:(e,t,o)=>Th(e,t)||n.get(e,t,o),has:(e,t)=>!!Th(e,t)||n.has(e,t)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ab{constructor(e){this.container=e}getPlatformInfoString(){return this.container.getProviders().map(t=>{if(lb(t)){const o=t.getImmediate();return`${o.library}/${o.version}`}else return null}).filter(t=>t).join(" ")}}function lb(n){const e=n.getComponent();return(e==null?void 0:e.type)==="VERSION"}const hc="@firebase/app",Eh="0.14.11";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Mn=new au("@firebase/app"),cb="@firebase/app-compat",ub="@firebase/analytics-compat",db="@firebase/analytics",hb="@firebase/app-check-compat",fb="@firebase/app-check",pb="@firebase/auth",gb="@firebase/auth-compat",mb="@firebase/database",yb="@firebase/data-connect",vb="@firebase/database-compat",bb="@firebase/functions",wb="@firebase/functions-compat",_b="@firebase/installations",Tb="@firebase/installations-compat",Eb="@firebase/messaging",Ib="@firebase/messaging-compat",xb="@firebase/performance",Sb="@firebase/performance-compat",Ab="@firebase/remote-config",kb="@firebase/remote-config-compat",Cb="@firebase/storage",Pb="@firebase/storage-compat",Rb="@firebase/firestore",Ob="@firebase/ai",Mb="@firebase/firestore-compat",Nb="firebase",Lb="12.12.0";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const fc="[DEFAULT]",Db={[hc]:"fire-core",[cb]:"fire-core-compat",[db]:"fire-analytics",[ub]:"fire-analytics-compat",[fb]:"fire-app-check",[hb]:"fire-app-check-compat",[pb]:"fire-auth",[gb]:"fire-auth-compat",[mb]:"fire-rtdb",[yb]:"fire-data-connect",[vb]:"fire-rtdb-compat",[bb]:"fire-fn",[wb]:"fire-fn-compat",[_b]:"fire-iid",[Tb]:"fire-iid-compat",[Eb]:"fire-fcm",[Ib]:"fire-fcm-compat",[xb]:"fire-perf",[Sb]:"fire-perf-compat",[Ab]:"fire-rc",[kb]:"fire-rc-compat",[Cb]:"fire-gcs",[Pb]:"fire-gcs-compat",[Rb]:"fire-fst",[Mb]:"fire-fst-compat",[Ob]:"fire-vertex","fire-js":"fire-js",[Nb]:"fire-js-all"};/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Zi=new Map,Vb=new Map,pc=new Map;function Ih(n,e){try{n.container.addComponent(e)}catch(t){Mn.debug(`Component ${e.name} failed to register with FirebaseApp ${n.name}`,t)}}function Nr(n){const e=n.name;if(pc.has(e))return Mn.debug(`There were multiple attempts to register component ${e}.`),!1;pc.set(e,n);for(const t of Zi.values())Ih(t,n);for(const t of Vb.values())Ih(t,n);return!0}function cu(n,e){const t=n.container.getProvider("heartbeat").getImmediate({optional:!0});return t&&t.triggerHeartbeat(),n.container.getProvider(e)}function en(n){return n==null?!1:n.settings!==void 0}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Fb={"no-app":"No Firebase App '{$appName}' has been created - call initializeApp() first","bad-app-name":"Illegal App name: '{$appName}'","duplicate-app":"Firebase App named '{$appName}' already exists with different options or config","app-deleted":"Firebase App named '{$appName}' already deleted","server-app-deleted":"Firebase Server App has been deleted","no-options":"Need to provide options, when not being deployed to hosting via source.","invalid-app-argument":"firebase.{$appName}() takes either no argument or a Firebase App instance.","invalid-log-argument":"First argument to `onLog` must be null or a function.","idb-open":"Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.","idb-get":"Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.","idb-set":"Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.","idb-delete":"Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}.","finalization-registry-not-supported":"FirebaseServerApp deleteOnDeref field defined but the JS runtime does not support FinalizationRegistry.","invalid-server-app-environment":"FirebaseServerApp is not for use in browser environments."},ro=new bs("app","Firebase",Fb);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ub{constructor(e,t,o){this._isDeleted=!1,this._options={...e},this._config={...t},this._name=t.name,this._automaticDataCollectionEnabled=t.automaticDataCollectionEnabled,this._container=o,this.container.addComponent(new Wo("app",()=>this,"PUBLIC"))}get automaticDataCollectionEnabled(){return this.checkDestroyed(),this._automaticDataCollectionEnabled}set automaticDataCollectionEnabled(e){this.checkDestroyed(),this._automaticDataCollectionEnabled=e}get name(){return this.checkDestroyed(),this._name}get options(){return this.checkDestroyed(),this._options}get config(){return this.checkDestroyed(),this._config}get container(){return this._container}get isDeleted(){return this._isDeleted}set isDeleted(e){this._isDeleted=e}checkDestroyed(){if(this.isDeleted)throw ro.create("app-deleted",{appName:this._name})}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Gr=Lb;function uu(n,e={}){let t=n;typeof e!="object"&&(e={name:e});const o={name:fc,automaticDataCollectionEnabled:!0,...e},r=o.name;if(typeof r!="string"||!r)throw ro.create("bad-app-name",{appName:String(r)});if(t||(t=Pp()),!t)throw ro.create("no-options");const i=Zi.get(r);if(i){if(jo(t,i.options)&&jo(o,i.config))return i;throw ro.create("duplicate-app",{appName:r})}const s=new Wv(r);for(const d of pc.values())s.addComponent(d);const c=new Ub(t,o,s);return Zi.set(r,c),c}function Lp(n=fc){const e=Zi.get(n);if(!e&&n===fc&&Pp())return uu();if(!e)throw ro.create("no-app",{appName:n});return e}function xa(){return Array.from(Zi.values())}function io(n,e,t){let o=Db[n]??n;t&&(o+=`-${t}`);const r=o.match(/\s|\//),i=e.match(/\s|\//);if(r||i){const s=[`Unable to register library "${o}" with version "${e}":`];r&&s.push(`library name "${o}" contains illegal characters (whitespace or "/")`),r&&i&&s.push("and"),i&&s.push(`version name "${e}" contains illegal characters (whitespace or "/")`),Mn.warn(s.join(" "));return}Nr(new Wo(`${o}-version`,()=>({library:o,version:e}),"VERSION"))}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const qb="firebase-heartbeat-database",zb=1,es="firebase-heartbeat-store";let Wl=null;function Dp(){return Wl||(Wl=rb(qb,zb,{upgrade:(n,e)=>{switch(e){case 0:try{n.createObjectStore(es)}catch(t){console.warn(t)}}}}).catch(n=>{throw ro.create("idb-open",{originalErrorMessage:n.message})})),Wl}async function Bb(n){try{const t=(await Dp()).transaction(es),o=await t.objectStore(es).get(Vp(n));return await t.done,o}catch(e){if(e instanceof Un)Mn.warn(e.message);else{const t=ro.create("idb-get",{originalErrorMessage:e==null?void 0:e.message});Mn.warn(t.message)}}}async function xh(n,e){try{const o=(await Dp()).transaction(es,"readwrite");await o.objectStore(es).put(e,Vp(n)),await o.done}catch(t){if(t instanceof Un)Mn.warn(t.message);else{const o=ro.create("idb-set",{originalErrorMessage:t==null?void 0:t.message});Mn.warn(o.message)}}}function Vp(n){return`${n.name}!${n.options.appId}`}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const $b=1024,jb=30;class Wb{constructor(e){this.container=e,this._heartbeatsCache=null;const t=this.container.getProvider("app").getImmediate();this._storage=new Gb(t),this._heartbeatsCachePromise=this._storage.read().then(o=>(this._heartbeatsCache=o,o))}async triggerHeartbeat(){var e,t;try{const r=this.container.getProvider("platform-logger").getImmediate().getPlatformInfoString(),i=Sh();if(((e=this._heartbeatsCache)==null?void 0:e.heartbeats)==null&&(this._heartbeatsCache=await this._heartbeatsCachePromise,((t=this._heartbeatsCache)==null?void 0:t.heartbeats)==null)||this._heartbeatsCache.lastSentHeartbeatDate===i||this._heartbeatsCache.heartbeats.some(s=>s.date===i))return;if(this._heartbeatsCache.heartbeats.push({date:i,agent:r}),this._heartbeatsCache.heartbeats.length>jb){const s=Yb(this._heartbeatsCache.heartbeats);this._heartbeatsCache.heartbeats.splice(s,1)}return this._storage.overwrite(this._heartbeatsCache)}catch(o){Mn.warn(o)}}async getHeartbeatsHeader(){var e;try{if(this._heartbeatsCache===null&&await this._heartbeatsCachePromise,((e=this._heartbeatsCache)==null?void 0:e.heartbeats)==null||this._heartbeatsCache.heartbeats.length===0)return"";const t=Sh(),{heartbeatsToSend:o,unsentEntries:r}=Hb(this._heartbeatsCache.heartbeats),i=Ia(JSON.stringify({version:2,heartbeats:o}));return this._heartbeatsCache.lastSentHeartbeatDate=t,r.length>0?(this._heartbeatsCache.heartbeats=r,await this._storage.overwrite(this._heartbeatsCache)):(this._heartbeatsCache.heartbeats=[],this._storage.overwrite(this._heartbeatsCache)),i}catch(t){return Mn.warn(t),""}}}function Sh(){return new Date().toISOString().substring(0,10)}function Hb(n,e=$b){const t=[];let o=n.slice();for(const r of n){const i=t.find(s=>s.agent===r.agent);if(i){if(i.dates.push(r.date),Ah(t)>e){i.dates.pop();break}}else if(t.push({agent:r.agent,dates:[r.date]}),Ah(t)>e){t.pop();break}o=o.slice(1)}return{heartbeatsToSend:t,unsentEntries:o}}class Gb{constructor(e){this.app=e,this._canUseIndexedDBPromise=this.runIndexedDBEnvironmentCheck()}async runIndexedDBEnvironmentCheck(){return Mv()?Nv().then(()=>!0).catch(()=>!1):!1}async read(){if(await this._canUseIndexedDBPromise){const t=await Bb(this.app);return t!=null&&t.heartbeats?t:{heartbeats:[]}}else return{heartbeats:[]}}async overwrite(e){if(await this._canUseIndexedDBPromise){const o=await this.read();return xh(this.app,{lastSentHeartbeatDate:e.lastSentHeartbeatDate??o.lastSentHeartbeatDate,heartbeats:e.heartbeats})}else return}async add(e){if(await this._canUseIndexedDBPromise){const o=await this.read();return xh(this.app,{lastSentHeartbeatDate:e.lastSentHeartbeatDate??o.lastSentHeartbeatDate,heartbeats:[...o.heartbeats,...e.heartbeats]})}else return}}function Ah(n){return Ia(JSON.stringify({version:2,heartbeats:n})).length}function Yb(n){if(n.length===0)return-1;let e=0,t=n[0].date;for(let o=1;o<n.length;o++)n[o].date<t&&(t=n[o].date,e=o);return e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Kb(n){Nr(new Wo("platform-logger",e=>new ab(e),"PRIVATE")),Nr(new Wo("heartbeat",e=>new Wb(e),"PRIVATE")),io(hc,Eh,n),io(hc,Eh,"esm2020"),io("fire-js","")}Kb("");var Xb="firebase",Qb="12.12.1";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */io(Xb,Qb,"app");function Fp(){return{"dependent-sdk-initialized-before-auth":"Another Firebase SDK was initialized and is trying to use Auth before Auth is initialized. Please be sure to call `initializeAuth` or `getAuth` before starting any other Firebase SDK."}}const Jb=Fp,Up=new bs("auth","Firebase",Fp());/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Sa=new au("@firebase/auth");function Zb(n,...e){Sa.logLevel<=de.WARN&&Sa.warn(`Auth (${Gr}): ${n}`,...e)}function ua(n,...e){Sa.logLevel<=de.ERROR&&Sa.error(`Auth (${Gr}): ${n}`,...e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Nn(n,...e){throw du(n,...e)}function ln(n,...e){return du(n,...e)}function qp(n,e,t){const o={...Jb(),[e]:t};return new bs("auth","Firebase",o).create(e,{appName:n.name})}function Uo(n){return qp(n,"operation-not-supported-in-this-environment","Operations that alter the current user are not supported in conjunction with FirebaseServerApp")}function du(n,...e){if(typeof n!="string"){const t=e[0],o=[...e.slice(1)];return o[0]&&(o[0].appName=n.name),n._errorFactory.create(t,...o)}return Up.create(n,...e)}function te(n,e,...t){if(!n)throw du(e,...t)}function Sn(n){const e="INTERNAL ASSERTION FAILED: "+n;throw ua(e),new Error(e)}function Ln(n,e){n||Sn(e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function gc(){var n;return typeof self<"u"&&((n=self.location)==null?void 0:n.href)||""}function ew(){return kh()==="http:"||kh()==="https:"}function kh(){var n;return typeof self<"u"&&((n=self.location)==null?void 0:n.protocol)||null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function tw(){return typeof navigator<"u"&&navigator&&"onLine"in navigator&&typeof navigator.onLine=="boolean"&&(ew()||Cv()||"connection"in navigator)?navigator.onLine:!0}function nw(){if(typeof navigator>"u")return null;const n=navigator;return n.languages&&n.languages[0]||n.language||null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ts{constructor(e,t){this.shortDelay=e,this.longDelay=t,Ln(t>e,"Short delay should be less than long delay!"),this.isMobile=Sv()||Pv()}get(){return tw()?this.isMobile?this.longDelay:this.shortDelay:Math.min(5e3,this.shortDelay)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function hu(n,e){Ln(n.emulator,"Emulator should always be set here");const{url:t}=n.emulator;return e?`${t}${e.startsWith("/")?e.slice(1):e}`:t}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class zp{static initialize(e,t,o){this.fetchImpl=e,t&&(this.headersImpl=t),o&&(this.responseImpl=o)}static fetch(){if(this.fetchImpl)return this.fetchImpl;if(typeof self<"u"&&"fetch"in self)return self.fetch;if(typeof globalThis<"u"&&globalThis.fetch)return globalThis.fetch;if(typeof fetch<"u")return fetch;Sn("Could not find fetch implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static headers(){if(this.headersImpl)return this.headersImpl;if(typeof self<"u"&&"Headers"in self)return self.Headers;if(typeof globalThis<"u"&&globalThis.Headers)return globalThis.Headers;if(typeof Headers<"u")return Headers;Sn("Could not find Headers implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static response(){if(this.responseImpl)return this.responseImpl;if(typeof self<"u"&&"Response"in self)return self.Response;if(typeof globalThis<"u"&&globalThis.Response)return globalThis.Response;if(typeof Response<"u")return Response;Sn("Could not find Response implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ow={CREDENTIAL_MISMATCH:"custom-token-mismatch",MISSING_CUSTOM_TOKEN:"internal-error",INVALID_IDENTIFIER:"invalid-email",MISSING_CONTINUE_URI:"internal-error",INVALID_PASSWORD:"wrong-password",MISSING_PASSWORD:"missing-password",INVALID_LOGIN_CREDENTIALS:"invalid-credential",EMAIL_EXISTS:"email-already-in-use",PASSWORD_LOGIN_DISABLED:"operation-not-allowed",INVALID_IDP_RESPONSE:"invalid-credential",INVALID_PENDING_TOKEN:"invalid-credential",FEDERATED_USER_ID_ALREADY_LINKED:"credential-already-in-use",MISSING_REQ_TYPE:"internal-error",EMAIL_NOT_FOUND:"user-not-found",RESET_PASSWORD_EXCEED_LIMIT:"too-many-requests",EXPIRED_OOB_CODE:"expired-action-code",INVALID_OOB_CODE:"invalid-action-code",MISSING_OOB_CODE:"internal-error",CREDENTIAL_TOO_OLD_LOGIN_AGAIN:"requires-recent-login",INVALID_ID_TOKEN:"invalid-user-token",TOKEN_EXPIRED:"user-token-expired",USER_NOT_FOUND:"user-token-expired",TOO_MANY_ATTEMPTS_TRY_LATER:"too-many-requests",PASSWORD_DOES_NOT_MEET_REQUIREMENTS:"password-does-not-meet-requirements",INVALID_CODE:"invalid-verification-code",INVALID_SESSION_INFO:"invalid-verification-id",INVALID_TEMPORARY_PROOF:"invalid-credential",MISSING_SESSION_INFO:"missing-verification-id",SESSION_EXPIRED:"code-expired",MISSING_ANDROID_PACKAGE_NAME:"missing-android-pkg-name",UNAUTHORIZED_DOMAIN:"unauthorized-continue-uri",INVALID_OAUTH_CLIENT_ID:"invalid-oauth-client-id",ADMIN_ONLY_OPERATION:"admin-restricted-operation",INVALID_MFA_PENDING_CREDENTIAL:"invalid-multi-factor-session",MFA_ENROLLMENT_NOT_FOUND:"multi-factor-info-not-found",MISSING_MFA_ENROLLMENT_ID:"missing-multi-factor-info",MISSING_MFA_PENDING_CREDENTIAL:"missing-multi-factor-session",SECOND_FACTOR_EXISTS:"second-factor-already-in-use",SECOND_FACTOR_LIMIT_EXCEEDED:"maximum-second-factor-count-exceeded",BLOCKING_FUNCTION_ERROR_RESPONSE:"internal-error",RECAPTCHA_NOT_ENABLED:"recaptcha-not-enabled",MISSING_RECAPTCHA_TOKEN:"missing-recaptcha-token",INVALID_RECAPTCHA_TOKEN:"invalid-recaptcha-token",INVALID_RECAPTCHA_ACTION:"invalid-recaptcha-action",MISSING_CLIENT_TYPE:"missing-client-type",MISSING_RECAPTCHA_VERSION:"missing-recaptcha-version",INVALID_RECAPTCHA_VERSION:"invalid-recaptcha-version",INVALID_REQ_TYPE:"invalid-req-type"};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const rw=["/v1/accounts:signInWithCustomToken","/v1/accounts:signInWithEmailLink","/v1/accounts:signInWithIdp","/v1/accounts:signInWithPassword","/v1/accounts:signInWithPhoneNumber","/v1/token"],iw=new Ts(3e4,6e4);function fu(n,e){return n.tenantId&&!e.tenantId?{...e,tenantId:n.tenantId}:e}async function Yr(n,e,t,o,r={}){return Bp(n,r,async()=>{let i={},s={};o&&(e==="GET"?s=o:i={body:JSON.stringify(o)});const c=ws({key:n.config.apiKey,...s}).slice(1),d=await n._getAdditionalHeaders();d["Content-Type"]="application/json",n.languageCode&&(d["X-Firebase-Locale"]=n.languageCode);const u={method:e,headers:d,...i};return kv()||(u.referrerPolicy="no-referrer"),n.emulatorConfig&&_s(n.emulatorConfig.host)&&(u.credentials="include"),zp.fetch()(await $p(n,n.config.apiHost,t,c),u)})}async function Bp(n,e,t){n._canInitEmulator=!1;const o={...ow,...e};try{const r=new aw(n),i=await Promise.race([t(),r.promise]);r.clearNetworkTimeout();const s=await i.json();if("needConfirmation"in s)throw Gs(n,"account-exists-with-different-credential",s);if(i.ok&&!("errorMessage"in s))return s;{const c=i.ok?s.errorMessage:s.error.message,[d,u]=c.split(" : ");if(d==="FEDERATED_USER_ID_ALREADY_LINKED")throw Gs(n,"credential-already-in-use",s);if(d==="EMAIL_EXISTS")throw Gs(n,"email-already-in-use",s);if(d==="USER_DISABLED")throw Gs(n,"user-disabled",s);const f=o[d]||d.toLowerCase().replace(/[_\s]+/g,"-");if(u)throw qp(n,f,u);Nn(n,f)}}catch(r){if(r instanceof Un)throw r;Nn(n,"network-request-failed",{message:String(r)})}}async function sw(n,e,t,o,r={}){const i=await Yr(n,e,t,o,r);return"mfaPendingCredential"in i&&Nn(n,"multi-factor-auth-required",{_serverResponse:i}),i}async function $p(n,e,t,o){const r=`${e}${t}?${o}`,i=n,s=i.config.emulator?hu(n.config,r):`${n.config.apiScheme}://${r}`;return rw.includes(t)&&(await i._persistenceManagerAvailable,i._getPersistenceType()==="COOKIE")?i._getPersistence()._getFinalTarget(s).toString():s}class aw{clearNetworkTimeout(){clearTimeout(this.timer)}constructor(e){this.auth=e,this.timer=null,this.promise=new Promise((t,o)=>{this.timer=setTimeout(()=>o(ln(this.auth,"network-request-failed")),iw.get())})}}function Gs(n,e,t){const o={appName:n.name};t.email&&(o.email=t.email),t.phoneNumber&&(o.phoneNumber=t.phoneNumber);const r=ln(n,e,o);return r.customData._tokenResponse=t,r}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function lw(n,e){return Yr(n,"POST","/v1/accounts:delete",e)}async function Aa(n,e){return Yr(n,"POST","/v1/accounts:lookup",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ji(n){if(n)try{const e=new Date(Number(n));if(!isNaN(e.getTime()))return e.toUTCString()}catch{}}async function cw(n,e=!1){const t=rt(n),o=await t.getIdToken(e),r=pu(o);te(r&&r.exp&&r.auth_time&&r.iat,t.auth,"internal-error");const i=typeof r.firebase=="object"?r.firebase:void 0,s=i==null?void 0:i.sign_in_provider;return{claims:r,token:o,authTime:ji(Hl(r.auth_time)),issuedAtTime:ji(Hl(r.iat)),expirationTime:ji(Hl(r.exp)),signInProvider:s||null,signInSecondFactor:(i==null?void 0:i.sign_in_second_factor)||null}}function Hl(n){return Number(n)*1e3}function pu(n){const[e,t,o]=n.split(".");if(e===void 0||t===void 0||o===void 0)return ua("JWT malformed, contained fewer than 3 sections"),null;try{const r=kp(t);return r?JSON.parse(r):(ua("Failed to decode base64 JWT payload"),null)}catch(r){return ua("Caught error parsing JWT payload as JSON",r==null?void 0:r.toString()),null}}function Ch(n){const e=pu(n);return te(e,"internal-error"),te(typeof e.exp<"u","internal-error"),te(typeof e.iat<"u","internal-error"),Number(e.exp)-Number(e.iat)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function ts(n,e,t=!1){if(t)return e;try{return await e}catch(o){throw o instanceof Un&&uw(o)&&n.auth.currentUser===n&&await n.auth.signOut(),o}}function uw({code:n}){return n==="auth/user-disabled"||n==="auth/user-token-expired"}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class dw{constructor(e){this.user=e,this.isRunning=!1,this.timerId=null,this.errorBackoff=3e4}_start(){this.isRunning||(this.isRunning=!0,this.schedule())}_stop(){this.isRunning&&(this.isRunning=!1,this.timerId!==null&&clearTimeout(this.timerId))}getInterval(e){if(e){const t=this.errorBackoff;return this.errorBackoff=Math.min(this.errorBackoff*2,96e4),t}else{this.errorBackoff=3e4;const o=(this.user.stsTokenManager.expirationTime??0)-Date.now()-3e5;return Math.max(0,o)}}schedule(e=!1){if(!this.isRunning)return;const t=this.getInterval(e);this.timerId=setTimeout(async()=>{await this.iteration()},t)}async iteration(){try{await this.user.getIdToken(!0)}catch(e){(e==null?void 0:e.code)==="auth/network-request-failed"&&this.schedule(!0);return}this.schedule()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class mc{constructor(e,t){this.createdAt=e,this.lastLoginAt=t,this._initializeTime()}_initializeTime(){this.lastSignInTime=ji(this.lastLoginAt),this.creationTime=ji(this.createdAt)}_copy(e){this.createdAt=e.createdAt,this.lastLoginAt=e.lastLoginAt,this._initializeTime()}toJSON(){return{createdAt:this.createdAt,lastLoginAt:this.lastLoginAt}}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function ka(n){var g;const e=n.auth,t=await n.getIdToken(),o=await ts(n,Aa(e,{idToken:t}));te(o==null?void 0:o.users.length,e,"internal-error");const r=o.users[0];n._notifyReloadListener(r);const i=(g=r.providerUserInfo)!=null&&g.length?jp(r.providerUserInfo):[],s=fw(n.providerData,i),c=n.isAnonymous,d=!(n.email&&r.passwordHash)&&!(s!=null&&s.length),u=c?d:!1,f={uid:r.localId,displayName:r.displayName||null,photoURL:r.photoUrl||null,email:r.email||null,emailVerified:r.emailVerified||!1,phoneNumber:r.phoneNumber||null,tenantId:r.tenantId||null,providerData:s,metadata:new mc(r.createdAt,r.lastLoginAt),isAnonymous:u};Object.assign(n,f)}async function hw(n){const e=rt(n);await ka(e),await e.auth._persistUserIfCurrent(e),e.auth._notifyListenersIfCurrent(e)}function fw(n,e){return[...n.filter(o=>!e.some(r=>r.providerId===o.providerId)),...e]}function jp(n){return n.map(({providerId:e,...t})=>({providerId:e,uid:t.rawId||"",displayName:t.displayName||null,email:t.email||null,phoneNumber:t.phoneNumber||null,photoURL:t.photoUrl||null}))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function pw(n,e){const t=await Bp(n,{},async()=>{const o=ws({grant_type:"refresh_token",refresh_token:e}).slice(1),{tokenApiHost:r,apiKey:i}=n.config,s=await $p(n,r,"/v1/token",`key=${i}`),c=await n._getAdditionalHeaders();c["Content-Type"]="application/x-www-form-urlencoded";const d={method:"POST",headers:c,body:o};return n.emulatorConfig&&_s(n.emulatorConfig.host)&&(d.credentials="include"),zp.fetch()(s,d)});return{accessToken:t.access_token,expiresIn:t.expires_in,refreshToken:t.refresh_token}}async function gw(n,e){return Yr(n,"POST","/v2/accounts:revokeToken",fu(n,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class br{constructor(){this.refreshToken=null,this.accessToken=null,this.expirationTime=null}get isExpired(){return!this.expirationTime||Date.now()>this.expirationTime-3e4}updateFromServerResponse(e){te(e.idToken,"internal-error"),te(typeof e.idToken<"u","internal-error"),te(typeof e.refreshToken<"u","internal-error");const t="expiresIn"in e&&typeof e.expiresIn<"u"?Number(e.expiresIn):Ch(e.idToken);this.updateTokensAndExpiration(e.idToken,e.refreshToken,t)}updateFromIdToken(e){te(e.length!==0,"internal-error");const t=Ch(e);this.updateTokensAndExpiration(e,null,t)}async getToken(e,t=!1){return!t&&this.accessToken&&!this.isExpired?this.accessToken:(te(this.refreshToken,e,"user-token-expired"),this.refreshToken?(await this.refresh(e,this.refreshToken),this.accessToken):null)}clearRefreshToken(){this.refreshToken=null}async refresh(e,t){const{accessToken:o,refreshToken:r,expiresIn:i}=await pw(e,t);this.updateTokensAndExpiration(o,r,Number(i))}updateTokensAndExpiration(e,t,o){this.refreshToken=t||null,this.accessToken=e||null,this.expirationTime=Date.now()+o*1e3}static fromJSON(e,t){const{refreshToken:o,accessToken:r,expirationTime:i}=t,s=new br;return o&&(te(typeof o=="string","internal-error",{appName:e}),s.refreshToken=o),r&&(te(typeof r=="string","internal-error",{appName:e}),s.accessToken=r),i&&(te(typeof i=="number","internal-error",{appName:e}),s.expirationTime=i),s}toJSON(){return{refreshToken:this.refreshToken,accessToken:this.accessToken,expirationTime:this.expirationTime}}_assign(e){this.accessToken=e.accessToken,this.refreshToken=e.refreshToken,this.expirationTime=e.expirationTime}_clone(){return Object.assign(new br,this.toJSON())}_performRefresh(){return Sn("not implemented")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Yn(n,e){te(typeof n=="string"||typeof n>"u","internal-error",{appName:e})}class zt{constructor({uid:e,auth:t,stsTokenManager:o,...r}){this.providerId="firebase",this.proactiveRefresh=new dw(this),this.reloadUserInfo=null,this.reloadListener=null,this.uid=e,this.auth=t,this.stsTokenManager=o,this.accessToken=o.accessToken,this.displayName=r.displayName||null,this.email=r.email||null,this.emailVerified=r.emailVerified||!1,this.phoneNumber=r.phoneNumber||null,this.photoURL=r.photoURL||null,this.isAnonymous=r.isAnonymous||!1,this.tenantId=r.tenantId||null,this.providerData=r.providerData?[...r.providerData]:[],this.metadata=new mc(r.createdAt||void 0,r.lastLoginAt||void 0)}async getIdToken(e){const t=await ts(this,this.stsTokenManager.getToken(this.auth,e));return te(t,this.auth,"internal-error"),this.accessToken!==t&&(this.accessToken=t,await this.auth._persistUserIfCurrent(this),this.auth._notifyListenersIfCurrent(this)),t}getIdTokenResult(e){return cw(this,e)}reload(){return hw(this)}_assign(e){this!==e&&(te(this.uid===e.uid,this.auth,"internal-error"),this.displayName=e.displayName,this.photoURL=e.photoURL,this.email=e.email,this.emailVerified=e.emailVerified,this.phoneNumber=e.phoneNumber,this.isAnonymous=e.isAnonymous,this.tenantId=e.tenantId,this.providerData=e.providerData.map(t=>({...t})),this.metadata._copy(e.metadata),this.stsTokenManager._assign(e.stsTokenManager))}_clone(e){const t=new zt({...this,auth:e,stsTokenManager:this.stsTokenManager._clone()});return t.metadata._copy(this.metadata),t}_onReload(e){te(!this.reloadListener,this.auth,"internal-error"),this.reloadListener=e,this.reloadUserInfo&&(this._notifyReloadListener(this.reloadUserInfo),this.reloadUserInfo=null)}_notifyReloadListener(e){this.reloadListener?this.reloadListener(e):this.reloadUserInfo=e}_startProactiveRefresh(){this.proactiveRefresh._start()}_stopProactiveRefresh(){this.proactiveRefresh._stop()}async _updateTokensIfNecessary(e,t=!1){let o=!1;e.idToken&&e.idToken!==this.stsTokenManager.accessToken&&(this.stsTokenManager.updateFromServerResponse(e),o=!0),t&&await ka(this),await this.auth._persistUserIfCurrent(this),o&&this.auth._notifyListenersIfCurrent(this)}async delete(){if(en(this.auth.app))return Promise.reject(Uo(this.auth));const e=await this.getIdToken();return await ts(this,lw(this.auth,{idToken:e})),this.stsTokenManager.clearRefreshToken(),this.auth.signOut()}toJSON(){return{uid:this.uid,email:this.email||void 0,emailVerified:this.emailVerified,displayName:this.displayName||void 0,isAnonymous:this.isAnonymous,photoURL:this.photoURL||void 0,phoneNumber:this.phoneNumber||void 0,tenantId:this.tenantId||void 0,providerData:this.providerData.map(e=>({...e})),stsTokenManager:this.stsTokenManager.toJSON(),_redirectEventId:this._redirectEventId,...this.metadata.toJSON(),apiKey:this.auth.config.apiKey,appName:this.auth.name}}get refreshToken(){return this.stsTokenManager.refreshToken||""}static _fromJSON(e,t){const o=t.displayName??void 0,r=t.email??void 0,i=t.phoneNumber??void 0,s=t.photoURL??void 0,c=t.tenantId??void 0,d=t._redirectEventId??void 0,u=t.createdAt??void 0,f=t.lastLoginAt??void 0,{uid:g,emailVerified:m,isAnonymous:v,providerData:O,stsTokenManager:C}=t;te(g&&C,e,"internal-error");const L=br.fromJSON(this.name,C);te(typeof g=="string",e,"internal-error"),Yn(o,e.name),Yn(r,e.name),te(typeof m=="boolean",e,"internal-error"),te(typeof v=="boolean",e,"internal-error"),Yn(i,e.name),Yn(s,e.name),Yn(c,e.name),Yn(d,e.name),Yn(u,e.name),Yn(f,e.name);const H=new zt({uid:g,auth:e,email:r,emailVerified:m,displayName:o,isAnonymous:v,photoURL:s,phoneNumber:i,tenantId:c,stsTokenManager:L,createdAt:u,lastLoginAt:f});return O&&Array.isArray(O)&&(H.providerData=O.map(z=>({...z}))),d&&(H._redirectEventId=d),H}static async _fromIdTokenResponse(e,t,o=!1){const r=new br;r.updateFromServerResponse(t);const i=new zt({uid:t.localId,auth:e,stsTokenManager:r,isAnonymous:o});return await ka(i),i}static async _fromGetAccountInfoResponse(e,t,o){const r=t.users[0];te(r.localId!==void 0,"internal-error");const i=r.providerUserInfo!==void 0?jp(r.providerUserInfo):[],s=!(r.email&&r.passwordHash)&&!(i!=null&&i.length),c=new br;c.updateFromIdToken(o);const d=new zt({uid:r.localId,auth:e,stsTokenManager:c,isAnonymous:s}),u={uid:r.localId,displayName:r.displayName||null,photoURL:r.photoUrl||null,email:r.email||null,emailVerified:r.emailVerified||!1,phoneNumber:r.phoneNumber||null,tenantId:r.tenantId||null,providerData:i,metadata:new mc(r.createdAt,r.lastLoginAt),isAnonymous:!(r.email&&r.passwordHash)&&!(i!=null&&i.length)};return Object.assign(d,u),d}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ph=new Map;function An(n){Ln(n instanceof Function,"Expected a class definition");let e=Ph.get(n);return e?(Ln(e instanceof n,"Instance stored in cache mismatched with class"),e):(e=new n,Ph.set(n,e),e)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Wp{constructor(){this.type="NONE",this.storage={}}async _isAvailable(){return!0}async _set(e,t){this.storage[e]=t}async _get(e){const t=this.storage[e];return t===void 0?null:t}async _remove(e){delete this.storage[e]}_addListener(e,t){}_removeListener(e,t){}}Wp.type="NONE";const Rh=Wp;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function da(n,e,t){return`firebase:${n}:${e}:${t}`}class wr{constructor(e,t,o){this.persistence=e,this.auth=t,this.userKey=o;const{config:r,name:i}=this.auth;this.fullUserKey=da(this.userKey,r.apiKey,i),this.fullPersistenceKey=da("persistence",r.apiKey,i),this.boundEventHandler=t._onStorageEvent.bind(t),this.persistence._addListener(this.fullUserKey,this.boundEventHandler)}setCurrentUser(e){return this.persistence._set(this.fullUserKey,e.toJSON())}async getCurrentUser(){const e=await this.persistence._get(this.fullUserKey);if(!e)return null;if(typeof e=="string"){const t=await Aa(this.auth,{idToken:e}).catch(()=>{});return t?zt._fromGetAccountInfoResponse(this.auth,t,e):null}return zt._fromJSON(this.auth,e)}removeCurrentUser(){return this.persistence._remove(this.fullUserKey)}savePersistenceForRedirect(){return this.persistence._set(this.fullPersistenceKey,this.persistence.type)}async setPersistence(e){if(this.persistence===e)return;const t=await this.getCurrentUser();if(await this.removeCurrentUser(),this.persistence=e,t)return this.setCurrentUser(t)}delete(){this.persistence._removeListener(this.fullUserKey,this.boundEventHandler)}static async create(e,t,o="authUser"){if(!t.length)return new wr(An(Rh),e,o);const r=(await Promise.all(t.map(async u=>{if(await u._isAvailable())return u}))).filter(u=>u);let i=r[0]||An(Rh);const s=da(o,e.config.apiKey,e.name);let c=null;for(const u of t)try{const f=await u._get(s);if(f){let g;if(typeof f=="string"){const m=await Aa(e,{idToken:f}).catch(()=>{});if(!m)break;g=await zt._fromGetAccountInfoResponse(e,m,f)}else g=zt._fromJSON(e,f);u!==i&&(c=g),i=u;break}}catch{}const d=r.filter(u=>u._shouldAllowMigration);return!i._shouldAllowMigration||!d.length?new wr(i,e,o):(i=d[0],c&&await i._set(s,c.toJSON()),await Promise.all(t.map(async u=>{if(u!==i)try{await u._remove(s)}catch{}})),new wr(i,e,o))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Oh(n){const e=n.toLowerCase();if(e.includes("opera/")||e.includes("opr/")||e.includes("opios/"))return"Opera";if(Kp(e))return"IEMobile";if(e.includes("msie")||e.includes("trident/"))return"IE";if(e.includes("edge/"))return"Edge";if(Hp(e))return"Firefox";if(e.includes("silk/"))return"Silk";if(Qp(e))return"Blackberry";if(Jp(e))return"Webos";if(Gp(e))return"Safari";if((e.includes("chrome/")||Yp(e))&&!e.includes("edge/"))return"Chrome";if(Xp(e))return"Android";{const t=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,o=n.match(t);if((o==null?void 0:o.length)===2)return o[1]}return"Other"}function Hp(n=ft()){return/firefox\//i.test(n)}function Gp(n=ft()){const e=n.toLowerCase();return e.includes("safari/")&&!e.includes("chrome/")&&!e.includes("crios/")&&!e.includes("android")}function Yp(n=ft()){return/crios\//i.test(n)}function Kp(n=ft()){return/iemobile/i.test(n)}function Xp(n=ft()){return/android/i.test(n)}function Qp(n=ft()){return/blackberry/i.test(n)}function Jp(n=ft()){return/webos/i.test(n)}function gu(n=ft()){return/iphone|ipad|ipod/i.test(n)||/macintosh/i.test(n)&&/mobile/i.test(n)}function mw(n=ft()){var e;return gu(n)&&!!((e=window.navigator)!=null&&e.standalone)}function yw(){return Rv()&&document.documentMode===10}function Zp(n=ft()){return gu(n)||Xp(n)||Jp(n)||Qp(n)||/windows phone/i.test(n)||Kp(n)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function eg(n,e=[]){let t;switch(n){case"Browser":t=Oh(ft());break;case"Worker":t=`${Oh(ft())}-${n}`;break;default:t=n}const o=e.length?e.join(","):"FirebaseCore-web";return`${t}/JsCore/${Gr}/${o}`}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class vw{constructor(e){this.auth=e,this.queue=[]}pushCallback(e,t){const o=i=>new Promise((s,c)=>{try{const d=e(i);s(d)}catch(d){c(d)}});o.onAbort=t,this.queue.push(o);const r=this.queue.length-1;return()=>{this.queue[r]=()=>Promise.resolve()}}async runMiddleware(e){if(this.auth.currentUser===e)return;const t=[];try{for(const o of this.queue)await o(e),o.onAbort&&t.push(o.onAbort)}catch(o){t.reverse();for(const r of t)try{r()}catch{}throw this.auth._errorFactory.create("login-blocked",{originalMessage:o==null?void 0:o.message})}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function bw(n,e={}){return Yr(n,"GET","/v2/passwordPolicy",fu(n,e))}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ww=6;class _w{constructor(e){var o;const t=e.customStrengthOptions;this.customStrengthOptions={},this.customStrengthOptions.minPasswordLength=t.minPasswordLength??ww,t.maxPasswordLength&&(this.customStrengthOptions.maxPasswordLength=t.maxPasswordLength),t.containsLowercaseCharacter!==void 0&&(this.customStrengthOptions.containsLowercaseLetter=t.containsLowercaseCharacter),t.containsUppercaseCharacter!==void 0&&(this.customStrengthOptions.containsUppercaseLetter=t.containsUppercaseCharacter),t.containsNumericCharacter!==void 0&&(this.customStrengthOptions.containsNumericCharacter=t.containsNumericCharacter),t.containsNonAlphanumericCharacter!==void 0&&(this.customStrengthOptions.containsNonAlphanumericCharacter=t.containsNonAlphanumericCharacter),this.enforcementState=e.enforcementState,this.enforcementState==="ENFORCEMENT_STATE_UNSPECIFIED"&&(this.enforcementState="OFF"),this.allowedNonAlphanumericCharacters=((o=e.allowedNonAlphanumericCharacters)==null?void 0:o.join(""))??"",this.forceUpgradeOnSignin=e.forceUpgradeOnSignin??!1,this.schemaVersion=e.schemaVersion}validatePassword(e){const t={isValid:!0,passwordPolicy:this};return this.validatePasswordLengthOptions(e,t),this.validatePasswordCharacterOptions(e,t),t.isValid&&(t.isValid=t.meetsMinPasswordLength??!0),t.isValid&&(t.isValid=t.meetsMaxPasswordLength??!0),t.isValid&&(t.isValid=t.containsLowercaseLetter??!0),t.isValid&&(t.isValid=t.containsUppercaseLetter??!0),t.isValid&&(t.isValid=t.containsNumericCharacter??!0),t.isValid&&(t.isValid=t.containsNonAlphanumericCharacter??!0),t}validatePasswordLengthOptions(e,t){const o=this.customStrengthOptions.minPasswordLength,r=this.customStrengthOptions.maxPasswordLength;o&&(t.meetsMinPasswordLength=e.length>=o),r&&(t.meetsMaxPasswordLength=e.length<=r)}validatePasswordCharacterOptions(e,t){this.updatePasswordCharacterOptionsStatuses(t,!1,!1,!1,!1);let o;for(let r=0;r<e.length;r++)o=e.charAt(r),this.updatePasswordCharacterOptionsStatuses(t,o>="a"&&o<="z",o>="A"&&o<="Z",o>="0"&&o<="9",this.allowedNonAlphanumericCharacters.includes(o))}updatePasswordCharacterOptionsStatuses(e,t,o,r,i){this.customStrengthOptions.containsLowercaseLetter&&(e.containsLowercaseLetter||(e.containsLowercaseLetter=t)),this.customStrengthOptions.containsUppercaseLetter&&(e.containsUppercaseLetter||(e.containsUppercaseLetter=o)),this.customStrengthOptions.containsNumericCharacter&&(e.containsNumericCharacter||(e.containsNumericCharacter=r)),this.customStrengthOptions.containsNonAlphanumericCharacter&&(e.containsNonAlphanumericCharacter||(e.containsNonAlphanumericCharacter=i))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Tw{constructor(e,t,o,r){this.app=e,this.heartbeatServiceProvider=t,this.appCheckServiceProvider=o,this.config=r,this.currentUser=null,this.emulatorConfig=null,this.operations=Promise.resolve(),this.authStateSubscription=new Mh(this),this.idTokenSubscription=new Mh(this),this.beforeStateQueue=new vw(this),this.redirectUser=null,this.isProactiveRefreshEnabled=!1,this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION=1,this._canInitEmulator=!0,this._isInitialized=!1,this._deleted=!1,this._initializationPromise=null,this._popupRedirectResolver=null,this._errorFactory=Up,this._agentRecaptchaConfig=null,this._tenantRecaptchaConfigs={},this._projectPasswordPolicy=null,this._tenantPasswordPolicies={},this._resolvePersistenceManagerAvailable=void 0,this.lastNotifiedUid=void 0,this.languageCode=null,this.tenantId=null,this.settings={appVerificationDisabledForTesting:!1},this.frameworks=[],this.name=e.name,this.clientVersion=r.sdkClientVersion,this._persistenceManagerAvailable=new Promise(i=>this._resolvePersistenceManagerAvailable=i)}_initializeWithPersistence(e,t){return t&&(this._popupRedirectResolver=An(t)),this._initializationPromise=this.queue(async()=>{var o,r,i;if(!this._deleted&&(this.persistenceManager=await wr.create(this,e),(o=this._resolvePersistenceManagerAvailable)==null||o.call(this),!this._deleted)){if((r=this._popupRedirectResolver)!=null&&r._shouldInitProactively)try{await this._popupRedirectResolver._initialize(this)}catch{}await this.initializeCurrentUser(t),this.lastNotifiedUid=((i=this.currentUser)==null?void 0:i.uid)||null,!this._deleted&&(this._isInitialized=!0)}}),this._initializationPromise}async _onStorageEvent(){if(this._deleted)return;const e=await this.assertedPersistence.getCurrentUser();if(!(!this.currentUser&&!e)){if(this.currentUser&&e&&this.currentUser.uid===e.uid){this._currentUser._assign(e),await this.currentUser.getIdToken();return}await this._updateCurrentUser(e,!0)}}async initializeCurrentUserFromIdToken(e){try{const t=await Aa(this,{idToken:e}),o=await zt._fromGetAccountInfoResponse(this,t,e);await this.directlySetCurrentUser(o)}catch(t){console.warn("FirebaseServerApp could not login user with provided authIdToken: ",t),await this.directlySetCurrentUser(null)}}async initializeCurrentUser(e){var i;if(en(this.app)){const s=this.app.settings.authIdToken;return s?new Promise(c=>{setTimeout(()=>this.initializeCurrentUserFromIdToken(s).then(c,c))}):this.directlySetCurrentUser(null)}const t=await this.assertedPersistence.getCurrentUser();let o=t,r=!1;if(e&&this.config.authDomain){await this.getOrInitRedirectPersistenceManager();const s=(i=this.redirectUser)==null?void 0:i._redirectEventId,c=o==null?void 0:o._redirectEventId,d=await this.tryRedirectSignIn(e);(!s||s===c)&&(d!=null&&d.user)&&(o=d.user,r=!0)}if(!o)return this.directlySetCurrentUser(null);if(!o._redirectEventId){if(r)try{await this.beforeStateQueue.runMiddleware(o)}catch(s){o=t,this._popupRedirectResolver._overrideRedirectResult(this,()=>Promise.reject(s))}return o?this.reloadAndSetCurrentUserOrClear(o):this.directlySetCurrentUser(null)}return te(this._popupRedirectResolver,this,"argument-error"),await this.getOrInitRedirectPersistenceManager(),this.redirectUser&&this.redirectUser._redirectEventId===o._redirectEventId?this.directlySetCurrentUser(o):this.reloadAndSetCurrentUserOrClear(o)}async tryRedirectSignIn(e){let t=null;try{t=await this._popupRedirectResolver._completeRedirectFn(this,e,!0)}catch{await this._setRedirectUser(null)}return t}async reloadAndSetCurrentUserOrClear(e){try{await ka(e)}catch(t){if((t==null?void 0:t.code)!=="auth/network-request-failed")return this.directlySetCurrentUser(null)}return this.directlySetCurrentUser(e)}useDeviceLanguage(){this.languageCode=nw()}async _delete(){this._deleted=!0}async updateCurrentUser(e){if(en(this.app))return Promise.reject(Uo(this));const t=e?rt(e):null;return t&&te(t.auth.config.apiKey===this.config.apiKey,this,"invalid-user-token"),this._updateCurrentUser(t&&t._clone(this))}async _updateCurrentUser(e,t=!1){if(!this._deleted)return e&&te(this.tenantId===e.tenantId,this,"tenant-id-mismatch"),t||await this.beforeStateQueue.runMiddleware(e),this.queue(async()=>{await this.directlySetCurrentUser(e),this.notifyAuthListeners()})}async signOut(){return en(this.app)?Promise.reject(Uo(this)):(await this.beforeStateQueue.runMiddleware(null),(this.redirectPersistenceManager||this._popupRedirectResolver)&&await this._setRedirectUser(null),this._updateCurrentUser(null,!0))}setPersistence(e){return en(this.app)?Promise.reject(Uo(this)):this.queue(async()=>{await this.assertedPersistence.setPersistence(An(e))})}_getRecaptchaConfig(){return this.tenantId==null?this._agentRecaptchaConfig:this._tenantRecaptchaConfigs[this.tenantId]}async validatePassword(e){this._getPasswordPolicyInternal()||await this._updatePasswordPolicy();const t=this._getPasswordPolicyInternal();return t.schemaVersion!==this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION?Promise.reject(this._errorFactory.create("unsupported-password-policy-schema-version",{})):t.validatePassword(e)}_getPasswordPolicyInternal(){return this.tenantId===null?this._projectPasswordPolicy:this._tenantPasswordPolicies[this.tenantId]}async _updatePasswordPolicy(){const e=await bw(this),t=new _w(e);this.tenantId===null?this._projectPasswordPolicy=t:this._tenantPasswordPolicies[this.tenantId]=t}_getPersistenceType(){return this.assertedPersistence.persistence.type}_getPersistence(){return this.assertedPersistence.persistence}_updateErrorMap(e){this._errorFactory=new bs("auth","Firebase",e())}onAuthStateChanged(e,t,o){return this.registerStateListener(this.authStateSubscription,e,t,o)}beforeAuthStateChanged(e,t){return this.beforeStateQueue.pushCallback(e,t)}onIdTokenChanged(e,t,o){return this.registerStateListener(this.idTokenSubscription,e,t,o)}authStateReady(){return new Promise((e,t)=>{if(this.currentUser)e();else{const o=this.onAuthStateChanged(()=>{o(),e()},t)}})}async revokeAccessToken(e){if(this.currentUser){const t=await this.currentUser.getIdToken(),o={providerId:"apple.com",tokenType:"ACCESS_TOKEN",token:e,idToken:t};this.tenantId!=null&&(o.tenantId=this.tenantId),await gw(this,o)}}toJSON(){var e;return{apiKey:this.config.apiKey,authDomain:this.config.authDomain,appName:this.name,currentUser:(e=this._currentUser)==null?void 0:e.toJSON()}}async _setRedirectUser(e,t){const o=await this.getOrInitRedirectPersistenceManager(t);return e===null?o.removeCurrentUser():o.setCurrentUser(e)}async getOrInitRedirectPersistenceManager(e){if(!this.redirectPersistenceManager){const t=e&&An(e)||this._popupRedirectResolver;te(t,this,"argument-error"),this.redirectPersistenceManager=await wr.create(this,[An(t._redirectPersistence)],"redirectUser"),this.redirectUser=await this.redirectPersistenceManager.getCurrentUser()}return this.redirectPersistenceManager}async _redirectUserForId(e){var t,o;return this._isInitialized&&await this.queue(async()=>{}),((t=this._currentUser)==null?void 0:t._redirectEventId)===e?this._currentUser:((o=this.redirectUser)==null?void 0:o._redirectEventId)===e?this.redirectUser:null}async _persistUserIfCurrent(e){if(e===this.currentUser)return this.queue(async()=>this.directlySetCurrentUser(e))}_notifyListenersIfCurrent(e){e===this.currentUser&&this.notifyAuthListeners()}_key(){return`${this.config.authDomain}:${this.config.apiKey}:${this.name}`}_startProactiveRefresh(){this.isProactiveRefreshEnabled=!0,this.currentUser&&this._currentUser._startProactiveRefresh()}_stopProactiveRefresh(){this.isProactiveRefreshEnabled=!1,this.currentUser&&this._currentUser._stopProactiveRefresh()}get _currentUser(){return this.currentUser}notifyAuthListeners(){var t;if(!this._isInitialized)return;this.idTokenSubscription.next(this.currentUser);const e=((t=this.currentUser)==null?void 0:t.uid)??null;this.lastNotifiedUid!==e&&(this.lastNotifiedUid=e,this.authStateSubscription.next(this.currentUser))}registerStateListener(e,t,o,r){if(this._deleted)return()=>{};const i=typeof t=="function"?t:t.next.bind(t);let s=!1;const c=this._isInitialized?Promise.resolve():this._initializationPromise;if(te(c,this,"internal-error"),c.then(()=>{s||i(this.currentUser)}),typeof t=="function"){const d=e.addObserver(t,o,r);return()=>{s=!0,d()}}else{const d=e.addObserver(t);return()=>{s=!0,d()}}}async directlySetCurrentUser(e){this.currentUser&&this.currentUser!==e&&this._currentUser._stopProactiveRefresh(),e&&this.isProactiveRefreshEnabled&&e._startProactiveRefresh(),this.currentUser=e,e?await this.assertedPersistence.setCurrentUser(e):await this.assertedPersistence.removeCurrentUser()}queue(e){return this.operations=this.operations.then(e,e),this.operations}get assertedPersistence(){return te(this.persistenceManager,this,"internal-error"),this.persistenceManager}_logFramework(e){!e||this.frameworks.includes(e)||(this.frameworks.push(e),this.frameworks.sort(),this.clientVersion=eg(this.config.clientPlatform,this._getFrameworks()))}_getFrameworks(){return this.frameworks}async _getAdditionalHeaders(){var r;const e={"X-Client-Version":this.clientVersion};this.app.options.appId&&(e["X-Firebase-gmpid"]=this.app.options.appId);const t=await((r=this.heartbeatServiceProvider.getImmediate({optional:!0}))==null?void 0:r.getHeartbeatsHeader());t&&(e["X-Firebase-Client"]=t);const o=await this._getAppCheckToken();return o&&(e["X-Firebase-AppCheck"]=o),e}async _getAppCheckToken(){var t;if(en(this.app)&&this.app.settings.appCheckToken)return this.app.settings.appCheckToken;const e=await((t=this.appCheckServiceProvider.getImmediate({optional:!0}))==null?void 0:t.getToken());return e!=null&&e.error&&Zb(`Error while retrieving App Check token: ${e.error}`),e==null?void 0:e.token}}function nl(n){return rt(n)}class Mh{constructor(e){this.auth=e,this.observer=null,this.addObserver=Uv(t=>this.observer=t)}get next(){return te(this.observer,this.auth,"internal-error"),this.observer.next.bind(this.observer)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let mu={async loadJS(){throw new Error("Unable to load external scripts")},recaptchaV2Script:"",recaptchaEnterpriseScript:"",gapiScript:""};function Ew(n){mu=n}function Iw(n){return mu.loadJS(n)}function xw(){return mu.gapiScript}function Sw(n){return`__${n}${Math.floor(Math.random()*1e6)}`}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Aw(n,e){const t=cu(n,"auth");if(t.isInitialized()){const r=t.getImmediate(),i=t.getOptions();if(jo(i,e??{}))return r;Nn(r,"already-initialized")}return t.initialize({options:e})}function kw(n,e){const t=(e==null?void 0:e.persistence)||[],o=(Array.isArray(t)?t:[t]).map(An);e!=null&&e.errorMap&&n._updateErrorMap(e.errorMap),n._initializeWithPersistence(o,e==null?void 0:e.popupRedirectResolver)}function Cw(n,e,t){const o=nl(n);te(/^https?:\/\//.test(e),o,"invalid-emulator-scheme");const r=!1,i=tg(e),{host:s,port:c}=Pw(e),d=c===null?"":`:${c}`,u={url:`${i}//${s}${d}/`},f=Object.freeze({host:s,port:c,protocol:i.replace(":",""),options:Object.freeze({disableWarnings:r})});if(!o._canInitEmulator){te(o.config.emulator&&o.emulatorConfig,o,"emulator-config-failed"),te(jo(u,o.config.emulator)&&jo(f,o.emulatorConfig),o,"emulator-config-failed");return}o.config.emulator=u,o.emulatorConfig=f,o.settings.appVerificationDisabledForTesting=!0,_s(s)?Op(`${i}//${s}${d}`):Rw()}function tg(n){const e=n.indexOf(":");return e<0?"":n.substr(0,e+1)}function Pw(n){const e=tg(n),t=/(\/\/)?([^?#/]+)/.exec(n.substr(e.length));if(!t)return{host:"",port:null};const o=t[2].split("@").pop()||"",r=/^(\[[^\]]+\])(:|$)/.exec(o);if(r){const i=r[1];return{host:i,port:Nh(o.substr(i.length+1))}}else{const[i,s]=o.split(":");return{host:i,port:Nh(s)}}}function Nh(n){if(!n)return null;const e=Number(n);return isNaN(e)?null:e}function Rw(){function n(){const e=document.createElement("p"),t=e.style;e.innerText="Running in emulator mode. Do not use with production credentials.",t.position="fixed",t.width="100%",t.backgroundColor="#ffffff",t.border=".1em solid #000000",t.color="#b50000",t.bottom="0px",t.left="0px",t.margin="0px",t.zIndex="10000",t.textAlign="center",e.classList.add("firebase-emulator-warning"),document.body.appendChild(e)}typeof console<"u"&&typeof console.info=="function"&&console.info("WARNING: You are using the Auth Emulator, which is intended for local testing only.  Do not use with production credentials."),typeof window<"u"&&typeof document<"u"&&(document.readyState==="loading"?window.addEventListener("DOMContentLoaded",n):n())}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ng{constructor(e,t){this.providerId=e,this.signInMethod=t}toJSON(){return Sn("not implemented")}_getIdTokenResponse(e){return Sn("not implemented")}_linkToIdToken(e,t){return Sn("not implemented")}_getReauthenticationResolver(e){return Sn("not implemented")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function _r(n,e){return sw(n,"POST","/v1/accounts:signInWithIdp",fu(n,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ow="http://localhost";class Ho extends ng{constructor(){super(...arguments),this.pendingToken=null}static _fromParams(e){const t=new Ho(e.providerId,e.signInMethod);return e.idToken||e.accessToken?(e.idToken&&(t.idToken=e.idToken),e.accessToken&&(t.accessToken=e.accessToken),e.nonce&&!e.pendingToken&&(t.nonce=e.nonce),e.pendingToken&&(t.pendingToken=e.pendingToken)):e.oauthToken&&e.oauthTokenSecret?(t.accessToken=e.oauthToken,t.secret=e.oauthTokenSecret):Nn("argument-error"),t}toJSON(){return{idToken:this.idToken,accessToken:this.accessToken,secret:this.secret,nonce:this.nonce,pendingToken:this.pendingToken,providerId:this.providerId,signInMethod:this.signInMethod}}static fromJSON(e){const t=typeof e=="string"?JSON.parse(e):e,{providerId:o,signInMethod:r,...i}=t;if(!o||!r)return null;const s=new Ho(o,r);return s.idToken=i.idToken||void 0,s.accessToken=i.accessToken||void 0,s.secret=i.secret,s.nonce=i.nonce,s.pendingToken=i.pendingToken||null,s}_getIdTokenResponse(e){const t=this.buildRequest();return _r(e,t)}_linkToIdToken(e,t){const o=this.buildRequest();return o.idToken=t,_r(e,o)}_getReauthenticationResolver(e){const t=this.buildRequest();return t.autoCreate=!1,_r(e,t)}buildRequest(){const e={requestUri:Ow,returnSecureToken:!0};if(this.pendingToken)e.pendingToken=this.pendingToken;else{const t={};this.idToken&&(t.id_token=this.idToken),this.accessToken&&(t.access_token=this.accessToken),this.secret&&(t.oauth_token_secret=this.secret),t.providerId=this.providerId,this.nonce&&!this.pendingToken&&(t.nonce=this.nonce),e.postBody=ws(t)}return e}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class og{constructor(e){this.providerId=e,this.defaultLanguageCode=null,this.customParameters={}}setDefaultLanguage(e){this.defaultLanguageCode=e}setCustomParameters(e){return this.customParameters=e,this}getCustomParameters(){return this.customParameters}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Es extends og{constructor(){super(...arguments),this.scopes=[]}addScope(e){return this.scopes.includes(e)||this.scopes.push(e),this}getScopes(){return[...this.scopes]}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Xn extends Es{constructor(){super("facebook.com")}static credential(e){return Ho._fromParams({providerId:Xn.PROVIDER_ID,signInMethod:Xn.FACEBOOK_SIGN_IN_METHOD,accessToken:e})}static credentialFromResult(e){return Xn.credentialFromTaggedObject(e)}static credentialFromError(e){return Xn.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e||!("oauthAccessToken"in e)||!e.oauthAccessToken)return null;try{return Xn.credential(e.oauthAccessToken)}catch{return null}}}Xn.FACEBOOK_SIGN_IN_METHOD="facebook.com";Xn.PROVIDER_ID="facebook.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class In extends Es{constructor(){super("google.com"),this.addScope("profile")}static credential(e,t){return Ho._fromParams({providerId:In.PROVIDER_ID,signInMethod:In.GOOGLE_SIGN_IN_METHOD,idToken:e,accessToken:t})}static credentialFromResult(e){return In.credentialFromTaggedObject(e)}static credentialFromError(e){return In.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e)return null;const{oauthIdToken:t,oauthAccessToken:o}=e;if(!t&&!o)return null;try{return In.credential(t,o)}catch{return null}}}In.GOOGLE_SIGN_IN_METHOD="google.com";In.PROVIDER_ID="google.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Qn extends Es{constructor(){super("github.com")}static credential(e){return Ho._fromParams({providerId:Qn.PROVIDER_ID,signInMethod:Qn.GITHUB_SIGN_IN_METHOD,accessToken:e})}static credentialFromResult(e){return Qn.credentialFromTaggedObject(e)}static credentialFromError(e){return Qn.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e||!("oauthAccessToken"in e)||!e.oauthAccessToken)return null;try{return Qn.credential(e.oauthAccessToken)}catch{return null}}}Qn.GITHUB_SIGN_IN_METHOD="github.com";Qn.PROVIDER_ID="github.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Jn extends Es{constructor(){super("twitter.com")}static credential(e,t){return Ho._fromParams({providerId:Jn.PROVIDER_ID,signInMethod:Jn.TWITTER_SIGN_IN_METHOD,oauthToken:e,oauthTokenSecret:t})}static credentialFromResult(e){return Jn.credentialFromTaggedObject(e)}static credentialFromError(e){return Jn.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e)return null;const{oauthAccessToken:t,oauthTokenSecret:o}=e;if(!t||!o)return null;try{return Jn.credential(t,o)}catch{return null}}}Jn.TWITTER_SIGN_IN_METHOD="twitter.com";Jn.PROVIDER_ID="twitter.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Lr{constructor(e){this.user=e.user,this.providerId=e.providerId,this._tokenResponse=e._tokenResponse,this.operationType=e.operationType}static async _fromIdTokenResponse(e,t,o,r=!1){const i=await zt._fromIdTokenResponse(e,o,r),s=Lh(o);return new Lr({user:i,providerId:s,_tokenResponse:o,operationType:t})}static async _forOperation(e,t,o){await e._updateTokensIfNecessary(o,!0);const r=Lh(o);return new Lr({user:e,providerId:r,_tokenResponse:o,operationType:t})}}function Lh(n){return n.providerId?n.providerId:"phoneNumber"in n?"phone":null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ca extends Un{constructor(e,t,o,r){super(t.code,t.message),this.operationType=o,this.user=r,Object.setPrototypeOf(this,Ca.prototype),this.customData={appName:e.name,tenantId:e.tenantId??void 0,_serverResponse:t.customData._serverResponse,operationType:o}}static _fromErrorAndOperation(e,t,o,r){return new Ca(e,t,o,r)}}function rg(n,e,t,o){return(e==="reauthenticate"?t._getReauthenticationResolver(n):t._getIdTokenResponse(n)).catch(i=>{throw i.code==="auth/multi-factor-auth-required"?Ca._fromErrorAndOperation(n,i,e,o):i})}async function Mw(n,e,t=!1){const o=await ts(n,e._linkToIdToken(n.auth,await n.getIdToken()),t);return Lr._forOperation(n,"link",o)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Nw(n,e,t=!1){const{auth:o}=n;if(en(o.app))return Promise.reject(Uo(o));const r="reauthenticate";try{const i=await ts(n,rg(o,r,e,n),t);te(i.idToken,o,"internal-error");const s=pu(i.idToken);te(s,o,"internal-error");const{sub:c}=s;return te(n.uid===c,o,"user-mismatch"),Lr._forOperation(n,r,i)}catch(i){throw(i==null?void 0:i.code)==="auth/user-not-found"&&Nn(o,"user-mismatch"),i}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function ig(n,e,t=!1){if(en(n.app))return Promise.reject(Uo(n));const o="signIn",r=await rg(n,o,e),i=await Lr._fromIdTokenResponse(n,o,r);return t||await n._updateCurrentUser(i.user),i}async function Lw(n,e){return ig(nl(n),e)}function Dw(n,e,t,o){return rt(n).onIdTokenChanged(e,t,o)}function Vw(n,e,t){return rt(n).beforeAuthStateChanged(e,t)}function Fw(n,e,t,o){return rt(n).onAuthStateChanged(e,t,o)}function Uw(n){return rt(n).signOut()}const Pa="__sak";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class sg{constructor(e,t){this.storageRetriever=e,this.type=t}_isAvailable(){try{return this.storage?(this.storage.setItem(Pa,"1"),this.storage.removeItem(Pa),Promise.resolve(!0)):Promise.resolve(!1)}catch{return Promise.resolve(!1)}}_set(e,t){return this.storage.setItem(e,JSON.stringify(t)),Promise.resolve()}_get(e){const t=this.storage.getItem(e);return Promise.resolve(t?JSON.parse(t):null)}_remove(e){return this.storage.removeItem(e),Promise.resolve()}get storage(){return this.storageRetriever()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const qw=1e3,zw=10;class ag extends sg{constructor(){super(()=>window.localStorage,"LOCAL"),this.boundEventHandler=(e,t)=>this.onStorageEvent(e,t),this.listeners={},this.localCache={},this.pollTimer=null,this.fallbackToPolling=Zp(),this._shouldAllowMigration=!0}forAllChangedKeys(e){for(const t of Object.keys(this.listeners)){const o=this.storage.getItem(t),r=this.localCache[t];o!==r&&e(t,r,o)}}onStorageEvent(e,t=!1){if(!e.key){this.forAllChangedKeys((s,c,d)=>{this.notifyListeners(s,d)});return}const o=e.key;t?this.detachListener():this.stopPolling();const r=()=>{const s=this.storage.getItem(o);!t&&this.localCache[o]===s||this.notifyListeners(o,s)},i=this.storage.getItem(o);yw()&&i!==e.newValue&&e.newValue!==e.oldValue?setTimeout(r,zw):r()}notifyListeners(e,t){this.localCache[e]=t;const o=this.listeners[e];if(o)for(const r of Array.from(o))r(t&&JSON.parse(t))}startPolling(){this.stopPolling(),this.pollTimer=setInterval(()=>{this.forAllChangedKeys((e,t,o)=>{this.onStorageEvent(new StorageEvent("storage",{key:e,oldValue:t,newValue:o}),!0)})},qw)}stopPolling(){this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}attachListener(){window.addEventListener("storage",this.boundEventHandler)}detachListener(){window.removeEventListener("storage",this.boundEventHandler)}_addListener(e,t){Object.keys(this.listeners).length===0&&(this.fallbackToPolling?this.startPolling():this.attachListener()),this.listeners[e]||(this.listeners[e]=new Set,this.localCache[e]=this.storage.getItem(e)),this.listeners[e].add(t)}_removeListener(e,t){this.listeners[e]&&(this.listeners[e].delete(t),this.listeners[e].size===0&&delete this.listeners[e]),Object.keys(this.listeners).length===0&&(this.detachListener(),this.stopPolling())}async _set(e,t){await super._set(e,t),this.localCache[e]=JSON.stringify(t)}async _get(e){const t=await super._get(e);return this.localCache[e]=JSON.stringify(t),t}async _remove(e){await super._remove(e),delete this.localCache[e]}}ag.type="LOCAL";const Bw=ag;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class lg extends sg{constructor(){super(()=>window.sessionStorage,"SESSION")}_addListener(e,t){}_removeListener(e,t){}}lg.type="SESSION";const cg=lg;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function $w(n){return Promise.all(n.map(async e=>{try{return{fulfilled:!0,value:await e}}catch(t){return{fulfilled:!1,reason:t}}}))}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ol{constructor(e){this.eventTarget=e,this.handlersMap={},this.boundEventHandler=this.handleEvent.bind(this)}static _getInstance(e){const t=this.receivers.find(r=>r.isListeningto(e));if(t)return t;const o=new ol(e);return this.receivers.push(o),o}isListeningto(e){return this.eventTarget===e}async handleEvent(e){const t=e,{eventId:o,eventType:r,data:i}=t.data,s=this.handlersMap[r];if(!(s!=null&&s.size))return;t.ports[0].postMessage({status:"ack",eventId:o,eventType:r});const c=Array.from(s).map(async u=>u(t.origin,i)),d=await $w(c);t.ports[0].postMessage({status:"done",eventId:o,eventType:r,response:d})}_subscribe(e,t){Object.keys(this.handlersMap).length===0&&this.eventTarget.addEventListener("message",this.boundEventHandler),this.handlersMap[e]||(this.handlersMap[e]=new Set),this.handlersMap[e].add(t)}_unsubscribe(e,t){this.handlersMap[e]&&t&&this.handlersMap[e].delete(t),(!t||this.handlersMap[e].size===0)&&delete this.handlersMap[e],Object.keys(this.handlersMap).length===0&&this.eventTarget.removeEventListener("message",this.boundEventHandler)}}ol.receivers=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function yu(n="",e=10){let t="";for(let o=0;o<e;o++)t+=Math.floor(Math.random()*10);return n+t}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class jw{constructor(e){this.target=e,this.handlers=new Set}removeMessageHandler(e){e.messageChannel&&(e.messageChannel.port1.removeEventListener("message",e.onMessage),e.messageChannel.port1.close()),this.handlers.delete(e)}async _send(e,t,o=50){const r=typeof MessageChannel<"u"?new MessageChannel:null;if(!r)throw new Error("connection_unavailable");let i,s;return new Promise((c,d)=>{const u=yu("",20);r.port1.start();const f=setTimeout(()=>{d(new Error("unsupported_event"))},o);s={messageChannel:r,onMessage(g){const m=g;if(m.data.eventId===u)switch(m.data.status){case"ack":clearTimeout(f),i=setTimeout(()=>{d(new Error("timeout"))},3e3);break;case"done":clearTimeout(i),c(m.data.response);break;default:clearTimeout(f),clearTimeout(i),d(new Error("invalid_response"));break}}},this.handlers.add(s),r.port1.addEventListener("message",s.onMessage),this.target.postMessage({eventType:e,eventId:u,data:t},[r.port2])}).finally(()=>{s&&this.removeMessageHandler(s)})}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function cn(){return window}function Ww(n){cn().location.href=n}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ug(){return typeof cn().WorkerGlobalScope<"u"&&typeof cn().importScripts=="function"}async function Hw(){if(!(navigator!=null&&navigator.serviceWorker))return null;try{return(await navigator.serviceWorker.ready).active}catch{return null}}function Gw(){var n;return((n=navigator==null?void 0:navigator.serviceWorker)==null?void 0:n.controller)||null}function Yw(){return ug()?self:null}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const dg="firebaseLocalStorageDb",Kw=1,Ra="firebaseLocalStorage",hg="fbase_key";class Is{constructor(e){this.request=e}toPromise(){return new Promise((e,t)=>{this.request.addEventListener("success",()=>{e(this.request.result)}),this.request.addEventListener("error",()=>{t(this.request.error)})})}}function rl(n,e){return n.transaction([Ra],e?"readwrite":"readonly").objectStore(Ra)}function Xw(){const n=indexedDB.deleteDatabase(dg);return new Is(n).toPromise()}function yc(){const n=indexedDB.open(dg,Kw);return new Promise((e,t)=>{n.addEventListener("error",()=>{t(n.error)}),n.addEventListener("upgradeneeded",()=>{const o=n.result;try{o.createObjectStore(Ra,{keyPath:hg})}catch(r){t(r)}}),n.addEventListener("success",async()=>{const o=n.result;o.objectStoreNames.contains(Ra)?e(o):(o.close(),await Xw(),e(await yc()))})})}async function Dh(n,e,t){const o=rl(n,!0).put({[hg]:e,value:t});return new Is(o).toPromise()}async function Qw(n,e){const t=rl(n,!1).get(e),o=await new Is(t).toPromise();return o===void 0?null:o.value}function Vh(n,e){const t=rl(n,!0).delete(e);return new Is(t).toPromise()}const Jw=800,Zw=3;class fg{constructor(){this.type="LOCAL",this._shouldAllowMigration=!0,this.listeners={},this.localCache={},this.pollTimer=null,this.pendingWrites=0,this.receiver=null,this.sender=null,this.serviceWorkerReceiverAvailable=!1,this.activeServiceWorker=null,this._workerInitializationPromise=this.initializeServiceWorkerMessaging().then(()=>{},()=>{})}async _openDb(){return this.db?this.db:(this.db=await yc(),this.db)}async _withRetries(e){let t=0;for(;;)try{const o=await this._openDb();return await e(o)}catch(o){if(t++>Zw)throw o;this.db&&(this.db.close(),this.db=void 0)}}async initializeServiceWorkerMessaging(){return ug()?this.initializeReceiver():this.initializeSender()}async initializeReceiver(){this.receiver=ol._getInstance(Yw()),this.receiver._subscribe("keyChanged",async(e,t)=>({keyProcessed:(await this._poll()).includes(t.key)})),this.receiver._subscribe("ping",async(e,t)=>["keyChanged"])}async initializeSender(){var t,o;if(this.activeServiceWorker=await Hw(),!this.activeServiceWorker)return;this.sender=new jw(this.activeServiceWorker);const e=await this.sender._send("ping",{},800);e&&(t=e[0])!=null&&t.fulfilled&&(o=e[0])!=null&&o.value.includes("keyChanged")&&(this.serviceWorkerReceiverAvailable=!0)}async notifyServiceWorker(e){if(!(!this.sender||!this.activeServiceWorker||Gw()!==this.activeServiceWorker))try{await this.sender._send("keyChanged",{key:e},this.serviceWorkerReceiverAvailable?800:50)}catch{}}async _isAvailable(){try{if(!indexedDB)return!1;const e=await yc();return await Dh(e,Pa,"1"),await Vh(e,Pa),!0}catch{}return!1}async _withPendingWrite(e){this.pendingWrites++;try{await e()}finally{this.pendingWrites--}}async _set(e,t){return this._withPendingWrite(async()=>(await this._withRetries(o=>Dh(o,e,t)),this.localCache[e]=t,this.notifyServiceWorker(e)))}async _get(e){const t=await this._withRetries(o=>Qw(o,e));return this.localCache[e]=t,t}async _remove(e){return this._withPendingWrite(async()=>(await this._withRetries(t=>Vh(t,e)),delete this.localCache[e],this.notifyServiceWorker(e)))}async _poll(){const e=await this._withRetries(r=>{const i=rl(r,!1).getAll();return new Is(i).toPromise()});if(!e)return[];if(this.pendingWrites!==0)return[];const t=[],o=new Set;if(e.length!==0)for(const{fbase_key:r,value:i}of e)o.add(r),JSON.stringify(this.localCache[r])!==JSON.stringify(i)&&(this.notifyListeners(r,i),t.push(r));for(const r of Object.keys(this.localCache))this.localCache[r]&&!o.has(r)&&(this.notifyListeners(r,null),t.push(r));return t}notifyListeners(e,t){this.localCache[e]=t;const o=this.listeners[e];if(o)for(const r of Array.from(o))r(t)}startPolling(){this.stopPolling(),this.pollTimer=setInterval(async()=>this._poll(),Jw)}stopPolling(){this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}_addListener(e,t){Object.keys(this.listeners).length===0&&this.startPolling(),this.listeners[e]||(this.listeners[e]=new Set,this._get(e)),this.listeners[e].add(t)}_removeListener(e,t){this.listeners[e]&&(this.listeners[e].delete(t),this.listeners[e].size===0&&delete this.listeners[e]),Object.keys(this.listeners).length===0&&this.stopPolling()}}fg.type="LOCAL";const e_=fg;new Ts(3e4,6e4);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function t_(n,e){return e?An(e):(te(n._popupRedirectResolver,n,"argument-error"),n._popupRedirectResolver)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class vu extends ng{constructor(e){super("custom","custom"),this.params=e}_getIdTokenResponse(e){return _r(e,this._buildIdpRequest())}_linkToIdToken(e,t){return _r(e,this._buildIdpRequest(t))}_getReauthenticationResolver(e){return _r(e,this._buildIdpRequest())}_buildIdpRequest(e){const t={requestUri:this.params.requestUri,sessionId:this.params.sessionId,postBody:this.params.postBody,tenantId:this.params.tenantId,pendingToken:this.params.pendingToken,returnSecureToken:!0,returnIdpCredential:!0};return e&&(t.idToken=e),t}}function n_(n){return ig(n.auth,new vu(n),n.bypassAuthState)}function o_(n){const{auth:e,user:t}=n;return te(t,e,"internal-error"),Nw(t,new vu(n),n.bypassAuthState)}async function r_(n){const{auth:e,user:t}=n;return te(t,e,"internal-error"),Mw(t,new vu(n),n.bypassAuthState)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class pg{constructor(e,t,o,r,i=!1){this.auth=e,this.resolver=o,this.user=r,this.bypassAuthState=i,this.pendingPromise=null,this.eventManager=null,this.filter=Array.isArray(t)?t:[t]}execute(){return new Promise(async(e,t)=>{this.pendingPromise={resolve:e,reject:t};try{this.eventManager=await this.resolver._initialize(this.auth),await this.onExecution(),this.eventManager.registerConsumer(this)}catch(o){this.reject(o)}})}async onAuthEvent(e){const{urlResponse:t,sessionId:o,postBody:r,tenantId:i,error:s,type:c}=e;if(s){this.reject(s);return}const d={auth:this.auth,requestUri:t,sessionId:o,tenantId:i||void 0,postBody:r||void 0,user:this.user,bypassAuthState:this.bypassAuthState};try{this.resolve(await this.getIdpTask(c)(d))}catch(u){this.reject(u)}}onError(e){this.reject(e)}getIdpTask(e){switch(e){case"signInViaPopup":case"signInViaRedirect":return n_;case"linkViaPopup":case"linkViaRedirect":return r_;case"reauthViaPopup":case"reauthViaRedirect":return o_;default:Nn(this.auth,"internal-error")}}resolve(e){Ln(this.pendingPromise,"Pending promise was never set"),this.pendingPromise.resolve(e),this.unregisterAndCleanUp()}reject(e){Ln(this.pendingPromise,"Pending promise was never set"),this.pendingPromise.reject(e),this.unregisterAndCleanUp()}unregisterAndCleanUp(){this.eventManager&&this.eventManager.unregisterConsumer(this),this.pendingPromise=null,this.cleanUp()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const i_=new Ts(2e3,1e4);class mr extends pg{constructor(e,t,o,r,i){super(e,t,r,i),this.provider=o,this.authWindow=null,this.pollId=null,mr.currentPopupAction&&mr.currentPopupAction.cancel(),mr.currentPopupAction=this}async executeNotNull(){const e=await this.execute();return te(e,this.auth,"internal-error"),e}async onExecution(){Ln(this.filter.length===1,"Popup operations only handle one event");const e=yu();this.authWindow=await this.resolver._openPopup(this.auth,this.provider,this.filter[0],e),this.authWindow.associatedEvent=e,this.resolver._originValidation(this.auth).catch(t=>{this.reject(t)}),this.resolver._isIframeWebStorageSupported(this.auth,t=>{t||this.reject(ln(this.auth,"web-storage-unsupported"))}),this.pollUserCancellation()}get eventId(){var e;return((e=this.authWindow)==null?void 0:e.associatedEvent)||null}cancel(){this.reject(ln(this.auth,"cancelled-popup-request"))}cleanUp(){this.authWindow&&this.authWindow.close(),this.pollId&&window.clearTimeout(this.pollId),this.authWindow=null,this.pollId=null,mr.currentPopupAction=null}pollUserCancellation(){const e=()=>{var t,o;if((o=(t=this.authWindow)==null?void 0:t.window)!=null&&o.closed){this.pollId=window.setTimeout(()=>{this.pollId=null,this.reject(ln(this.auth,"popup-closed-by-user"))},8e3);return}this.pollId=window.setTimeout(e,i_.get())};e()}}mr.currentPopupAction=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const s_="pendingRedirect",ha=new Map;class a_ extends pg{constructor(e,t,o=!1){super(e,["signInViaRedirect","linkViaRedirect","reauthViaRedirect","unknown"],t,void 0,o),this.eventId=null}async execute(){let e=ha.get(this.auth._key());if(!e){try{const o=await l_(this.resolver,this.auth)?await super.execute():null;e=()=>Promise.resolve(o)}catch(t){e=()=>Promise.reject(t)}ha.set(this.auth._key(),e)}return this.bypassAuthState||ha.set(this.auth._key(),()=>Promise.resolve(null)),e()}async onAuthEvent(e){if(e.type==="signInViaRedirect")return super.onAuthEvent(e);if(e.type==="unknown"){this.resolve(null);return}if(e.eventId){const t=await this.auth._redirectUserForId(e.eventId);if(t)return this.user=t,super.onAuthEvent(e);this.resolve(null)}}async onExecution(){}cleanUp(){}}async function l_(n,e){const t=d_(e),o=u_(n);if(!await o._isAvailable())return!1;const r=await o._get(t)==="true";return await o._remove(t),r}function c_(n,e){ha.set(n._key(),e)}function u_(n){return An(n._redirectPersistence)}function d_(n){return da(s_,n.config.apiKey,n.name)}async function h_(n,e,t=!1){if(en(n.app))return Promise.reject(Uo(n));const o=nl(n),r=t_(o,e),s=await new a_(o,r,t).execute();return s&&!t&&(delete s.user._redirectEventId,await o._persistUserIfCurrent(s.user),await o._setRedirectUser(null,e)),s}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const f_=10*60*1e3;class p_{constructor(e){this.auth=e,this.cachedEventUids=new Set,this.consumers=new Set,this.queuedRedirectEvent=null,this.hasHandledPotentialRedirect=!1,this.lastProcessedEventTime=Date.now()}registerConsumer(e){this.consumers.add(e),this.queuedRedirectEvent&&this.isEventForConsumer(this.queuedRedirectEvent,e)&&(this.sendToConsumer(this.queuedRedirectEvent,e),this.saveEventToCache(this.queuedRedirectEvent),this.queuedRedirectEvent=null)}unregisterConsumer(e){this.consumers.delete(e)}onEvent(e){if(this.hasEventBeenHandled(e))return!1;let t=!1;return this.consumers.forEach(o=>{this.isEventForConsumer(e,o)&&(t=!0,this.sendToConsumer(e,o),this.saveEventToCache(e))}),this.hasHandledPotentialRedirect||!g_(e)||(this.hasHandledPotentialRedirect=!0,t||(this.queuedRedirectEvent=e,t=!0)),t}sendToConsumer(e,t){var o;if(e.error&&!gg(e)){const r=((o=e.error.code)==null?void 0:o.split("auth/")[1])||"internal-error";t.onError(ln(this.auth,r))}else t.onAuthEvent(e)}isEventForConsumer(e,t){const o=t.eventId===null||!!e.eventId&&e.eventId===t.eventId;return t.filter.includes(e.type)&&o}hasEventBeenHandled(e){return Date.now()-this.lastProcessedEventTime>=f_&&this.cachedEventUids.clear(),this.cachedEventUids.has(Fh(e))}saveEventToCache(e){this.cachedEventUids.add(Fh(e)),this.lastProcessedEventTime=Date.now()}}function Fh(n){return[n.type,n.eventId,n.sessionId,n.tenantId].filter(e=>e).join("-")}function gg({type:n,error:e}){return n==="unknown"&&(e==null?void 0:e.code)==="auth/no-auth-event"}function g_(n){switch(n.type){case"signInViaRedirect":case"linkViaRedirect":case"reauthViaRedirect":return!0;case"unknown":return gg(n);default:return!1}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function m_(n,e={}){return Yr(n,"GET","/v1/projects",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const y_=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,v_=/^https?/;async function b_(n){if(n.config.emulator)return;const{authorizedDomains:e}=await m_(n);for(const t of e)try{if(w_(t))return}catch{}Nn(n,"unauthorized-domain")}function w_(n){const e=gc(),{protocol:t,hostname:o}=new URL(e);if(n.startsWith("chrome-extension://")){const s=new URL(n);return s.hostname===""&&o===""?t==="chrome-extension:"&&n.replace("chrome-extension://","")===e.replace("chrome-extension://",""):t==="chrome-extension:"&&s.hostname===o}if(!v_.test(t))return!1;if(y_.test(n))return o===n;const r=n.replace(/\./g,"\\.");return new RegExp("^(.+\\."+r+"|"+r+")$","i").test(o)}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const __=new Ts(3e4,6e4);function Uh(){const n=cn().___jsl;if(n!=null&&n.H){for(const e of Object.keys(n.H))if(n.H[e].r=n.H[e].r||[],n.H[e].L=n.H[e].L||[],n.H[e].r=[...n.H[e].L],n.CP)for(let t=0;t<n.CP.length;t++)n.CP[t]=null}}function T_(n){return new Promise((e,t)=>{var r,i,s;function o(){Uh(),gapi.load("gapi.iframes",{callback:()=>{e(gapi.iframes.getContext())},ontimeout:()=>{Uh(),t(ln(n,"network-request-failed"))},timeout:__.get()})}if((i=(r=cn().gapi)==null?void 0:r.iframes)!=null&&i.Iframe)e(gapi.iframes.getContext());else if((s=cn().gapi)!=null&&s.load)o();else{const c=Sw("iframefcb");return cn()[c]=()=>{gapi.load?o():t(ln(n,"network-request-failed"))},Iw(`${xw()}?onload=${c}`).catch(d=>t(d))}}).catch(e=>{throw fa=null,e})}let fa=null;function E_(n){return fa=fa||T_(n),fa}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const I_=new Ts(5e3,15e3),x_="__/auth/iframe",S_="emulator/auth/iframe",A_={style:{position:"absolute",top:"-100px",width:"1px",height:"1px"},"aria-hidden":"true",tabindex:"-1"},k_=new Map([["identitytoolkit.googleapis.com","p"],["staging-identitytoolkit.sandbox.googleapis.com","s"],["test-identitytoolkit.sandbox.googleapis.com","t"]]);function C_(n){const e=n.config;te(e.authDomain,n,"auth-domain-config-required");const t=e.emulator?hu(e,S_):`https://${n.config.authDomain}/${x_}`,o={apiKey:e.apiKey,appName:n.name,v:Gr},r=k_.get(n.config.apiHost);r&&(o.eid=r);const i=n._getFrameworks();return i.length&&(o.fw=i.join(",")),`${t}?${ws(o).slice(1)}`}async function P_(n){const e=await E_(n),t=cn().gapi;return te(t,n,"internal-error"),e.open({where:document.body,url:C_(n),messageHandlersFilter:t.iframes.CROSS_ORIGIN_IFRAMES_FILTER,attributes:A_,dontclear:!0},o=>new Promise(async(r,i)=>{await o.restyle({setHideOnLeave:!1});const s=ln(n,"network-request-failed"),c=cn().setTimeout(()=>{i(s)},I_.get());function d(){cn().clearTimeout(c),r(o)}o.ping(d).then(d,()=>{i(s)})}))}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const R_={location:"yes",resizable:"yes",statusbar:"yes",toolbar:"no"},O_=500,M_=600,N_="_blank",L_="http://localhost";class qh{constructor(e){this.window=e,this.associatedEvent=null}close(){if(this.window)try{this.window.close()}catch{}}}function D_(n,e,t,o=O_,r=M_){const i=Math.max((window.screen.availHeight-r)/2,0).toString(),s=Math.max((window.screen.availWidth-o)/2,0).toString();let c="";const d={...R_,width:o.toString(),height:r.toString(),top:i,left:s},u=ft().toLowerCase();t&&(c=Yp(u)?N_:t),Hp(u)&&(e=e||L_,d.scrollbars="yes");const f=Object.entries(d).reduce((m,[v,O])=>`${m}${v}=${O},`,"");if(mw(u)&&c!=="_self")return V_(e||"",c),new qh(null);const g=window.open(e||"",c,f);te(g,n,"popup-blocked");try{g.focus()}catch{}return new qh(g)}function V_(n,e){const t=document.createElement("a");t.href=n,t.target=e;const o=document.createEvent("MouseEvent");o.initMouseEvent("click",!0,!0,window,1,0,0,0,0,!1,!1,!1,!1,1,null),t.dispatchEvent(o)}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const F_="__/auth/handler",U_="emulator/auth/handler",q_=encodeURIComponent("fac");async function zh(n,e,t,o,r,i){te(n.config.authDomain,n,"auth-domain-config-required"),te(n.config.apiKey,n,"invalid-api-key");const s={apiKey:n.config.apiKey,appName:n.name,authType:t,redirectUrl:o,v:Gr,eventId:r};if(e instanceof og){e.setDefaultLanguage(n.languageCode),s.providerId=e.providerId||"",Fv(e.getCustomParameters())||(s.customParameters=JSON.stringify(e.getCustomParameters()));for(const[f,g]of Object.entries({}))s[f]=g}if(e instanceof Es){const f=e.getScopes().filter(g=>g!=="");f.length>0&&(s.scopes=f.join(","))}n.tenantId&&(s.tid=n.tenantId);const c=s;for(const f of Object.keys(c))c[f]===void 0&&delete c[f];const d=await n._getAppCheckToken(),u=d?`#${q_}=${encodeURIComponent(d)}`:"";return`${z_(n)}?${ws(c).slice(1)}${u}`}function z_({config:n}){return n.emulator?hu(n,U_):`https://${n.authDomain}/${F_}`}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Gl="webStorageSupport";class B_{constructor(){this.eventManagers={},this.iframes={},this.originValidationPromises={},this._redirectPersistence=cg,this._completeRedirectFn=h_,this._overrideRedirectResult=c_}async _openPopup(e,t,o,r){var s;Ln((s=this.eventManagers[e._key()])==null?void 0:s.manager,"_initialize() not called before _openPopup()");const i=await zh(e,t,o,gc(),r);return D_(e,i,yu())}async _openRedirect(e,t,o,r){await this._originValidation(e);const i=await zh(e,t,o,gc(),r);return Ww(i),new Promise(()=>{})}_initialize(e){const t=e._key();if(this.eventManagers[t]){const{manager:r,promise:i}=this.eventManagers[t];return r?Promise.resolve(r):(Ln(i,"If manager is not set, promise should be"),i)}const o=this.initAndGetManager(e);return this.eventManagers[t]={promise:o},o.catch(()=>{delete this.eventManagers[t]}),o}async initAndGetManager(e){const t=await P_(e),o=new p_(e);return t.register("authEvent",r=>(te(r==null?void 0:r.authEvent,e,"invalid-auth-event"),{status:o.onEvent(r.authEvent)?"ACK":"ERROR"}),gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER),this.eventManagers[e._key()]={manager:o},this.iframes[e._key()]=t,o}_isIframeWebStorageSupported(e,t){this.iframes[e._key()].send(Gl,{type:Gl},r=>{var s;const i=(s=r==null?void 0:r[0])==null?void 0:s[Gl];i!==void 0&&t(!!i),Nn(e,"internal-error")},gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER)}_originValidation(e){const t=e._key();return this.originValidationPromises[t]||(this.originValidationPromises[t]=b_(e)),this.originValidationPromises[t]}get _shouldInitProactively(){return Zp()||Gp()||gu()}}const $_=B_;var Bh="@firebase/auth",$h="1.13.0";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class j_{constructor(e){this.auth=e,this.internalListeners=new Map}getUid(){var e;return this.assertAuthConfigured(),((e=this.auth.currentUser)==null?void 0:e.uid)||null}async getToken(e){return this.assertAuthConfigured(),await this.auth._initializationPromise,this.auth.currentUser?{accessToken:await this.auth.currentUser.getIdToken(e)}:null}addAuthTokenListener(e){if(this.assertAuthConfigured(),this.internalListeners.has(e))return;const t=this.auth.onIdTokenChanged(o=>{e((o==null?void 0:o.stsTokenManager.accessToken)||null)});this.internalListeners.set(e,t),this.updateProactiveRefresh()}removeAuthTokenListener(e){this.assertAuthConfigured();const t=this.internalListeners.get(e);t&&(this.internalListeners.delete(e),t(),this.updateProactiveRefresh())}assertAuthConfigured(){te(this.auth._initializationPromise,"dependent-sdk-initialized-before-auth")}updateProactiveRefresh(){this.internalListeners.size>0?this.auth._startProactiveRefresh():this.auth._stopProactiveRefresh()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function W_(n){switch(n){case"Node":return"node";case"ReactNative":return"rn";case"Worker":return"webworker";case"Cordova":return"cordova";case"WebExtension":return"web-extension";default:return}}function H_(n){Nr(new Wo("auth",(e,{options:t})=>{const o=e.getProvider("app").getImmediate(),r=e.getProvider("heartbeat"),i=e.getProvider("app-check-internal"),{apiKey:s,authDomain:c}=o.options;te(s&&!s.includes(":"),"invalid-api-key",{appName:o.name});const d={apiKey:s,authDomain:c,clientPlatform:n,apiHost:"identitytoolkit.googleapis.com",tokenApiHost:"securetoken.googleapis.com",apiScheme:"https",sdkClientVersion:eg(n)},u=new Tw(o,r,i,d);return kw(u,t),u},"PUBLIC").setInstantiationMode("EXPLICIT").setInstanceCreatedCallback((e,t,o)=>{e.getProvider("auth-internal").initialize()})),Nr(new Wo("auth-internal",e=>{const t=nl(e.getProvider("auth").getImmediate());return(o=>new j_(o))(t)},"PRIVATE").setInstantiationMode("EXPLICIT")),io(Bh,$h,W_(n)),io(Bh,$h,"esm2020")}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const G_=5*60,Y_=Rp("authIdTokenMaxAge")||G_;let jh=null;const K_=n=>async e=>{const t=e&&await e.getIdTokenResult(),o=t&&(new Date().getTime()-Date.parse(t.issuedAtTime))/1e3;if(o&&o>Y_)return;const r=t==null?void 0:t.token;jh!==r&&(jh=r,await fetch(n,{method:r?"POST":"DELETE",headers:r?{Authorization:`Bearer ${r}`}:{}}))};function X_(n=Lp()){const e=cu(n,"auth");if(e.isInitialized())return e.getImmediate();const t=Aw(n,{popupRedirectResolver:$_,persistence:[e_,Bw,cg]}),o=Rp("authTokenSyncURL");if(o&&typeof isSecureContext=="boolean"&&isSecureContext){const i=new URL(o,location.origin);if(location.origin===i.origin){const s=K_(i.toString());Vw(t,s,()=>s(t.currentUser)),Dw(t,c=>s(c))}}const r=Cp("auth");return r&&Cw(t,`http://${r}`),t}function Q_(){var n;return((n=document.getElementsByTagName("head"))==null?void 0:n[0])??document}Ew({loadJS(n){return new Promise((e,t)=>{const o=document.createElement("script");o.setAttribute("src",n),o.onload=e,o.onerror=r=>{const i=ln("internal-error");i.customData=r,t(i)},o.type="text/javascript",o.charset="UTF-8",Q_().appendChild(o)})},gapiScript:"https://apis.google.com/js/api.js",recaptchaV2Script:"https://www.google.com/recaptcha/api.js",recaptchaEnterpriseScript:"https://www.google.com/recaptcha/enterprise.js?render="});H_("Browser");const mg={apiKey:"AIzaSyDgeMII4vDFmjXVKnrBYV8ane76eSzyUN8",authDomain:"overlay-runner.firebaseapp.com",databaseURL:"https://overlay-runner-default-rtdb.firebaseio.com",projectId:"overlay-runner",storageBucket:"overlay-runner.firebasestorage.app",messagingSenderId:"951272023115",appId:"1:951272023115:web:0f75edb7fb291a118119ce"};var Wh=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/var so,yg;(function(){var n;/** @license

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/function e(E,w){function b(){}b.prototype=w.prototype,E.F=w.prototype,E.prototype=new b,E.prototype.constructor=E,E.D=function(I,_,x){for(var T=Array(arguments.length-2),Z=2;Z<arguments.length;Z++)T[Z-2]=arguments[Z];return w.prototype[_].apply(I,T)}}function t(){this.blockSize=-1}function o(){this.blockSize=-1,this.blockSize=64,this.g=Array(4),this.C=Array(this.blockSize),this.o=this.h=0,this.u()}e(o,t),o.prototype.u=function(){this.g[0]=1732584193,this.g[1]=4023233417,this.g[2]=2562383102,this.g[3]=271733878,this.o=this.h=0};function r(E,w,b){b||(b=0);const I=Array(16);if(typeof w=="string")for(var _=0;_<16;++_)I[_]=w.charCodeAt(b++)|w.charCodeAt(b++)<<8|w.charCodeAt(b++)<<16|w.charCodeAt(b++)<<24;else for(_=0;_<16;++_)I[_]=w[b++]|w[b++]<<8|w[b++]<<16|w[b++]<<24;w=E.g[0],b=E.g[1],_=E.g[2];let x=E.g[3],T;T=w+(x^b&(_^x))+I[0]+3614090360&4294967295,w=b+(T<<7&4294967295|T>>>25),T=x+(_^w&(b^_))+I[1]+3905402710&4294967295,x=w+(T<<12&4294967295|T>>>20),T=_+(b^x&(w^b))+I[2]+606105819&4294967295,_=x+(T<<17&4294967295|T>>>15),T=b+(w^_&(x^w))+I[3]+3250441966&4294967295,b=_+(T<<22&4294967295|T>>>10),T=w+(x^b&(_^x))+I[4]+4118548399&4294967295,w=b+(T<<7&4294967295|T>>>25),T=x+(_^w&(b^_))+I[5]+1200080426&4294967295,x=w+(T<<12&4294967295|T>>>20),T=_+(b^x&(w^b))+I[6]+2821735955&4294967295,_=x+(T<<17&4294967295|T>>>15),T=b+(w^_&(x^w))+I[7]+4249261313&4294967295,b=_+(T<<22&4294967295|T>>>10),T=w+(x^b&(_^x))+I[8]+1770035416&4294967295,w=b+(T<<7&4294967295|T>>>25),T=x+(_^w&(b^_))+I[9]+2336552879&4294967295,x=w+(T<<12&4294967295|T>>>20),T=_+(b^x&(w^b))+I[10]+4294925233&4294967295,_=x+(T<<17&4294967295|T>>>15),T=b+(w^_&(x^w))+I[11]+2304563134&4294967295,b=_+(T<<22&4294967295|T>>>10),T=w+(x^b&(_^x))+I[12]+1804603682&4294967295,w=b+(T<<7&4294967295|T>>>25),T=x+(_^w&(b^_))+I[13]+4254626195&4294967295,x=w+(T<<12&4294967295|T>>>20),T=_+(b^x&(w^b))+I[14]+2792965006&4294967295,_=x+(T<<17&4294967295|T>>>15),T=b+(w^_&(x^w))+I[15]+1236535329&4294967295,b=_+(T<<22&4294967295|T>>>10),T=w+(_^x&(b^_))+I[1]+4129170786&4294967295,w=b+(T<<5&4294967295|T>>>27),T=x+(b^_&(w^b))+I[6]+3225465664&4294967295,x=w+(T<<9&4294967295|T>>>23),T=_+(w^b&(x^w))+I[11]+643717713&4294967295,_=x+(T<<14&4294967295|T>>>18),T=b+(x^w&(_^x))+I[0]+3921069994&4294967295,b=_+(T<<20&4294967295|T>>>12),T=w+(_^x&(b^_))+I[5]+3593408605&4294967295,w=b+(T<<5&4294967295|T>>>27),T=x+(b^_&(w^b))+I[10]+38016083&4294967295,x=w+(T<<9&4294967295|T>>>23),T=_+(w^b&(x^w))+I[15]+3634488961&4294967295,_=x+(T<<14&4294967295|T>>>18),T=b+(x^w&(_^x))+I[4]+3889429448&4294967295,b=_+(T<<20&4294967295|T>>>12),T=w+(_^x&(b^_))+I[9]+568446438&4294967295,w=b+(T<<5&4294967295|T>>>27),T=x+(b^_&(w^b))+I[14]+3275163606&4294967295,x=w+(T<<9&4294967295|T>>>23),T=_+(w^b&(x^w))+I[3]+4107603335&4294967295,_=x+(T<<14&4294967295|T>>>18),T=b+(x^w&(_^x))+I[8]+1163531501&4294967295,b=_+(T<<20&4294967295|T>>>12),T=w+(_^x&(b^_))+I[13]+2850285829&4294967295,w=b+(T<<5&4294967295|T>>>27),T=x+(b^_&(w^b))+I[2]+4243563512&4294967295,x=w+(T<<9&4294967295|T>>>23),T=_+(w^b&(x^w))+I[7]+1735328473&4294967295,_=x+(T<<14&4294967295|T>>>18),T=b+(x^w&(_^x))+I[12]+2368359562&4294967295,b=_+(T<<20&4294967295|T>>>12),T=w+(b^_^x)+I[5]+4294588738&4294967295,w=b+(T<<4&4294967295|T>>>28),T=x+(w^b^_)+I[8]+2272392833&4294967295,x=w+(T<<11&4294967295|T>>>21),T=_+(x^w^b)+I[11]+1839030562&4294967295,_=x+(T<<16&4294967295|T>>>16),T=b+(_^x^w)+I[14]+4259657740&4294967295,b=_+(T<<23&4294967295|T>>>9),T=w+(b^_^x)+I[1]+2763975236&4294967295,w=b+(T<<4&4294967295|T>>>28),T=x+(w^b^_)+I[4]+1272893353&4294967295,x=w+(T<<11&4294967295|T>>>21),T=_+(x^w^b)+I[7]+4139469664&4294967295,_=x+(T<<16&4294967295|T>>>16),T=b+(_^x^w)+I[10]+3200236656&4294967295,b=_+(T<<23&4294967295|T>>>9),T=w+(b^_^x)+I[13]+681279174&4294967295,w=b+(T<<4&4294967295|T>>>28),T=x+(w^b^_)+I[0]+3936430074&4294967295,x=w+(T<<11&4294967295|T>>>21),T=_+(x^w^b)+I[3]+3572445317&4294967295,_=x+(T<<16&4294967295|T>>>16),T=b+(_^x^w)+I[6]+76029189&4294967295,b=_+(T<<23&4294967295|T>>>9),T=w+(b^_^x)+I[9]+3654602809&4294967295,w=b+(T<<4&4294967295|T>>>28),T=x+(w^b^_)+I[12]+3873151461&4294967295,x=w+(T<<11&4294967295|T>>>21),T=_+(x^w^b)+I[15]+530742520&4294967295,_=x+(T<<16&4294967295|T>>>16),T=b+(_^x^w)+I[2]+3299628645&4294967295,b=_+(T<<23&4294967295|T>>>9),T=w+(_^(b|~x))+I[0]+4096336452&4294967295,w=b+(T<<6&4294967295|T>>>26),T=x+(b^(w|~_))+I[7]+1126891415&4294967295,x=w+(T<<10&4294967295|T>>>22),T=_+(w^(x|~b))+I[14]+2878612391&4294967295,_=x+(T<<15&4294967295|T>>>17),T=b+(x^(_|~w))+I[5]+4237533241&4294967295,b=_+(T<<21&4294967295|T>>>11),T=w+(_^(b|~x))+I[12]+1700485571&4294967295,w=b+(T<<6&4294967295|T>>>26),T=x+(b^(w|~_))+I[3]+2399980690&4294967295,x=w+(T<<10&4294967295|T>>>22),T=_+(w^(x|~b))+I[10]+4293915773&4294967295,_=x+(T<<15&4294967295|T>>>17),T=b+(x^(_|~w))+I[1]+2240044497&4294967295,b=_+(T<<21&4294967295|T>>>11),T=w+(_^(b|~x))+I[8]+1873313359&4294967295,w=b+(T<<6&4294967295|T>>>26),T=x+(b^(w|~_))+I[15]+4264355552&4294967295,x=w+(T<<10&4294967295|T>>>22),T=_+(w^(x|~b))+I[6]+2734768916&4294967295,_=x+(T<<15&4294967295|T>>>17),T=b+(x^(_|~w))+I[13]+1309151649&4294967295,b=_+(T<<21&4294967295|T>>>11),T=w+(_^(b|~x))+I[4]+4149444226&4294967295,w=b+(T<<6&4294967295|T>>>26),T=x+(b^(w|~_))+I[11]+3174756917&4294967295,x=w+(T<<10&4294967295|T>>>22),T=_+(w^(x|~b))+I[2]+718787259&4294967295,_=x+(T<<15&4294967295|T>>>17),T=b+(x^(_|~w))+I[9]+3951481745&4294967295,E.g[0]=E.g[0]+w&4294967295,E.g[1]=E.g[1]+(_+(T<<21&4294967295|T>>>11))&4294967295,E.g[2]=E.g[2]+_&4294967295,E.g[3]=E.g[3]+x&4294967295}o.prototype.v=function(E,w){w===void 0&&(w=E.length);const b=w-this.blockSize,I=this.C;let _=this.h,x=0;for(;x<w;){if(_==0)for(;x<=b;)r(this,E,x),x+=this.blockSize;if(typeof E=="string"){for(;x<w;)if(I[_++]=E.charCodeAt(x++),_==this.blockSize){r(this,I),_=0;break}}else for(;x<w;)if(I[_++]=E[x++],_==this.blockSize){r(this,I),_=0;break}}this.h=_,this.o+=w},o.prototype.A=function(){var E=Array((this.h<56?this.blockSize:this.blockSize*2)-this.h);E[0]=128;for(var w=1;w<E.length-8;++w)E[w]=0;w=this.o*8;for(var b=E.length-8;b<E.length;++b)E[b]=w&255,w/=256;for(this.v(E),E=Array(16),w=0,b=0;b<4;++b)for(let I=0;I<32;I+=8)E[w++]=this.g[b]>>>I&255;return E};function i(E,w){var b=c;return Object.prototype.hasOwnProperty.call(b,E)?b[E]:b[E]=w(E)}function s(E,w){this.h=w;const b=[];let I=!0;for(let _=E.length-1;_>=0;_--){const x=E[_]|0;I&&x==w||(b[_]=x,I=!1)}this.g=b}var c={};function d(E){return-128<=E&&E<128?i(E,function(w){return new s([w|0],w<0?-1:0)}):new s([E|0],E<0?-1:0)}function u(E){if(isNaN(E)||!isFinite(E))return g;if(E<0)return L(u(-E));const w=[];let b=1;for(let I=0;E>=b;I++)w[I]=E/b|0,b*=4294967296;return new s(w,0)}function f(E,w){if(E.length==0)throw Error("number format error: empty string");if(w=w||10,w<2||36<w)throw Error("radix out of range: "+w);if(E.charAt(0)=="-")return L(f(E.substring(1),w));if(E.indexOf("-")>=0)throw Error('number format error: interior "-" character');const b=u(Math.pow(w,8));let I=g;for(let x=0;x<E.length;x+=8){var _=Math.min(8,E.length-x);const T=parseInt(E.substring(x,x+_),w);_<8?(_=u(Math.pow(w,_)),I=I.j(_).add(u(T))):(I=I.j(b),I=I.add(u(T)))}return I}var g=d(0),m=d(1),v=d(16777216);n=s.prototype,n.m=function(){if(C(this))return-L(this).m();let E=0,w=1;for(let b=0;b<this.g.length;b++){const I=this.i(b);E+=(I>=0?I:4294967296+I)*w,w*=4294967296}return E},n.toString=function(E){if(E=E||10,E<2||36<E)throw Error("radix out of range: "+E);if(O(this))return"0";if(C(this))return"-"+L(this).toString(E);const w=u(Math.pow(E,6));var b=this;let I="";for(;;){const _=$(b,w).g;b=H(b,_.j(w));let x=((b.g.length>0?b.g[0]:b.h)>>>0).toString(E);if(b=_,O(b))return x+I;for(;x.length<6;)x="0"+x;I=x+I}},n.i=function(E){return E<0?0:E<this.g.length?this.g[E]:this.h};function O(E){if(E.h!=0)return!1;for(let w=0;w<E.g.length;w++)if(E.g[w]!=0)return!1;return!0}function C(E){return E.h==-1}n.l=function(E){return E=H(this,E),C(E)?-1:O(E)?0:1};function L(E){const w=E.g.length,b=[];for(let I=0;I<w;I++)b[I]=~E.g[I];return new s(b,~E.h).add(m)}n.abs=function(){return C(this)?L(this):this},n.add=function(E){const w=Math.max(this.g.length,E.g.length),b=[];let I=0;for(let _=0;_<=w;_++){let x=I+(this.i(_)&65535)+(E.i(_)&65535),T=(x>>>16)+(this.i(_)>>>16)+(E.i(_)>>>16);I=T>>>16,x&=65535,T&=65535,b[_]=T<<16|x}return new s(b,b[b.length-1]&-2147483648?-1:0)};function H(E,w){return E.add(L(w))}n.j=function(E){if(O(this)||O(E))return g;if(C(this))return C(E)?L(this).j(L(E)):L(L(this).j(E));if(C(E))return L(this.j(L(E)));if(this.l(v)<0&&E.l(v)<0)return u(this.m()*E.m());const w=this.g.length+E.g.length,b=[];for(var I=0;I<2*w;I++)b[I]=0;for(I=0;I<this.g.length;I++)for(let _=0;_<E.g.length;_++){const x=this.i(I)>>>16,T=this.i(I)&65535,Z=E.i(_)>>>16,ue=E.i(_)&65535;b[2*I+2*_]+=T*ue,z(b,2*I+2*_),b[2*I+2*_+1]+=x*ue,z(b,2*I+2*_+1),b[2*I+2*_+1]+=T*Z,z(b,2*I+2*_+1),b[2*I+2*_+2]+=x*Z,z(b,2*I+2*_+2)}for(E=0;E<w;E++)b[E]=b[2*E+1]<<16|b[2*E];for(E=w;E<2*w;E++)b[E]=0;return new s(b,0)};function z(E,w){for(;(E[w]&65535)!=E[w];)E[w+1]+=E[w]>>>16,E[w]&=65535,w++}function N(E,w){this.g=E,this.h=w}function $(E,w){if(O(w))throw Error("division by zero");if(O(E))return new N(g,g);if(C(E))return w=$(L(E),w),new N(L(w.g),L(w.h));if(C(w))return w=$(E,L(w)),new N(L(w.g),w.h);if(E.g.length>30){if(C(E)||C(w))throw Error("slowDivide_ only works with positive integers.");for(var b=m,I=w;I.l(E)<=0;)b=j(b),I=j(I);var _=D(b,1),x=D(I,1);for(I=D(I,2),b=D(b,2);!O(I);){var T=x.add(I);T.l(E)<=0&&(_=_.add(b),x=T),I=D(I,1),b=D(b,1)}return w=H(E,_.j(w)),new N(_,w)}for(_=g;E.l(w)>=0;){for(b=Math.max(1,Math.floor(E.m()/w.m())),I=Math.ceil(Math.log(b)/Math.LN2),I=I<=48?1:Math.pow(2,I-48),x=u(b),T=x.j(w);C(T)||T.l(E)>0;)b-=I,x=u(b),T=x.j(w);O(x)&&(x=m),_=_.add(x),E=H(E,T)}return new N(_,E)}n.B=function(E){return $(this,E).h},n.and=function(E){const w=Math.max(this.g.length,E.g.length),b=[];for(let I=0;I<w;I++)b[I]=this.i(I)&E.i(I);return new s(b,this.h&E.h)},n.or=function(E){const w=Math.max(this.g.length,E.g.length),b=[];for(let I=0;I<w;I++)b[I]=this.i(I)|E.i(I);return new s(b,this.h|E.h)},n.xor=function(E){const w=Math.max(this.g.length,E.g.length),b=[];for(let I=0;I<w;I++)b[I]=this.i(I)^E.i(I);return new s(b,this.h^E.h)};function j(E){const w=E.g.length+1,b=[];for(let I=0;I<w;I++)b[I]=E.i(I)<<1|E.i(I-1)>>>31;return new s(b,E.h)}function D(E,w){const b=w>>5;w%=32;const I=E.g.length-b,_=[];for(let x=0;x<I;x++)_[x]=w>0?E.i(x+b)>>>w|E.i(x+b+1)<<32-w:E.i(x+b);return new s(_,E.h)}o.prototype.digest=o.prototype.A,o.prototype.reset=o.prototype.u,o.prototype.update=o.prototype.v,yg=o,s.prototype.add=s.prototype.add,s.prototype.multiply=s.prototype.j,s.prototype.modulo=s.prototype.B,s.prototype.compare=s.prototype.l,s.prototype.toNumber=s.prototype.m,s.prototype.toString=s.prototype.toString,s.prototype.getBits=s.prototype.i,s.fromNumber=u,s.fromString=f,so=s}).apply(typeof Wh<"u"?Wh:typeof self<"u"?self:typeof window<"u"?window:{});var Ys=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/var vg,Mi,bg,pa,vc,wg,_g,Tg;(function(){var n,e=Object.defineProperty;function t(a){a=[typeof globalThis=="object"&&globalThis,a,typeof window=="object"&&window,typeof self=="object"&&self,typeof Ys=="object"&&Ys];for(var h=0;h<a.length;++h){var p=a[h];if(p&&p.Math==Math)return p}throw Error("Cannot find global object")}var o=t(this);function r(a,h){if(h)e:{var p=o;a=a.split(".");for(var y=0;y<a.length-1;y++){var k=a[y];if(!(k in p))break e;p=p[k]}a=a[a.length-1],y=p[a],h=h(y),h!=y&&h!=null&&e(p,a,{configurable:!0,writable:!0,value:h})}}r("Symbol.dispose",function(a){return a||Symbol("Symbol.dispose")}),r("Array.prototype.values",function(a){return a||function(){return this[Symbol.iterator]()}}),r("Object.entries",function(a){return a||function(h){var p=[],y;for(y in h)Object.prototype.hasOwnProperty.call(h,y)&&p.push([y,h[y]]);return p}});/** @license

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/var i=i||{},s=this||self;function c(a){var h=typeof a;return h=="object"&&a!=null||h=="function"}function d(a,h,p){return a.call.apply(a.bind,arguments)}function u(a,h,p){return u=d,u.apply(null,arguments)}function f(a,h){var p=Array.prototype.slice.call(arguments,1);return function(){var y=p.slice();return y.push.apply(y,arguments),a.apply(this,y)}}function g(a,h){function p(){}p.prototype=h.prototype,a.Z=h.prototype,a.prototype=new p,a.prototype.constructor=a,a.Ob=function(y,k,M){for(var W=Array(arguments.length-2),se=2;se<arguments.length;se++)W[se-2]=arguments[se];return h.prototype[k].apply(y,W)}}var m=typeof AsyncContext<"u"&&typeof AsyncContext.Snapshot=="function"?a=>a&&AsyncContext.Snapshot.wrap(a):a=>a;function v(a){const h=a.length;if(h>0){const p=Array(h);for(let y=0;y<h;y++)p[y]=a[y];return p}return[]}function O(a,h){for(let y=1;y<arguments.length;y++){const k=arguments[y];var p=typeof k;if(p=p!="object"?p:k?Array.isArray(k)?"array":p:"null",p=="array"||p=="object"&&typeof k.length=="number"){p=a.length||0;const M=k.length||0;a.length=p+M;for(let W=0;W<M;W++)a[p+W]=k[W]}else a.push(k)}}class C{constructor(h,p){this.i=h,this.j=p,this.h=0,this.g=null}get(){let h;return this.h>0?(this.h--,h=this.g,this.g=h.next,h.next=null):h=this.i(),h}}function L(a){s.setTimeout(()=>{throw a},0)}function H(){var a=E;let h=null;return a.g&&(h=a.g,a.g=a.g.next,a.g||(a.h=null),h.next=null),h}class z{constructor(){this.h=this.g=null}add(h,p){const y=N.get();y.set(h,p),this.h?this.h.next=y:this.g=y,this.h=y}}var N=new C(()=>new $,a=>a.reset());class ${constructor(){this.next=this.g=this.h=null}set(h,p){this.h=h,this.g=p,this.next=null}reset(){this.next=this.g=this.h=null}}let j,D=!1,E=new z,w=()=>{const a=Promise.resolve(void 0);j=()=>{a.then(b)}};function b(){for(var a;a=H();){try{a.h.call(a.g)}catch(p){L(p)}var h=N;h.j(a),h.h<100&&(h.h++,a.next=h.g,h.g=a)}D=!1}function I(){this.u=this.u,this.C=this.C}I.prototype.u=!1,I.prototype.dispose=function(){this.u||(this.u=!0,this.N())},I.prototype[Symbol.dispose]=function(){this.dispose()},I.prototype.N=function(){if(this.C)for(;this.C.length;)this.C.shift()()};function _(a,h){this.type=a,this.g=this.target=h,this.defaultPrevented=!1}_.prototype.h=function(){this.defaultPrevented=!0};var x=function(){if(!s.addEventListener||!Object.defineProperty)return!1;var a=!1,h=Object.defineProperty({},"passive",{get:function(){a=!0}});try{const p=()=>{};s.addEventListener("test",p,h),s.removeEventListener("test",p,h)}catch{}return a}();function T(a){return/^[\s\xa0]*$/.test(a)}function Z(a,h){_.call(this,a?a.type:""),this.relatedTarget=this.g=this.target=null,this.button=this.screenY=this.screenX=this.clientY=this.clientX=0,this.key="",this.metaKey=this.shiftKey=this.altKey=this.ctrlKey=!1,this.state=null,this.pointerId=0,this.pointerType="",this.i=null,a&&this.init(a,h)}g(Z,_),Z.prototype.init=function(a,h){const p=this.type=a.type,y=a.changedTouches&&a.changedTouches.length?a.changedTouches[0]:null;this.target=a.target||a.srcElement,this.g=h,h=a.relatedTarget,h||(p=="mouseover"?h=a.fromElement:p=="mouseout"&&(h=a.toElement)),this.relatedTarget=h,y?(this.clientX=y.clientX!==void 0?y.clientX:y.pageX,this.clientY=y.clientY!==void 0?y.clientY:y.pageY,this.screenX=y.screenX||0,this.screenY=y.screenY||0):(this.clientX=a.clientX!==void 0?a.clientX:a.pageX,this.clientY=a.clientY!==void 0?a.clientY:a.pageY,this.screenX=a.screenX||0,this.screenY=a.screenY||0),this.button=a.button,this.key=a.key||"",this.ctrlKey=a.ctrlKey,this.altKey=a.altKey,this.shiftKey=a.shiftKey,this.metaKey=a.metaKey,this.pointerId=a.pointerId||0,this.pointerType=a.pointerType,this.state=a.state,this.i=a,a.defaultPrevented&&Z.Z.h.call(this)},Z.prototype.h=function(){Z.Z.h.call(this);const a=this.i;a.preventDefault?a.preventDefault():a.returnValue=!1};var ue="closure_listenable_"+(Math.random()*1e6|0),me=0;function Re(a,h,p,y,k){this.listener=a,this.proxy=null,this.src=h,this.type=p,this.capture=!!y,this.ha=k,this.key=++me,this.da=this.fa=!1}function Se(a){a.da=!0,a.listener=null,a.proxy=null,a.src=null,a.ha=null}function _e(a,h,p){for(const y in a)h.call(p,a[y],y,a)}function Ee(a,h){for(const p in a)h.call(void 0,a[p],p,a)}function ae(a){const h={};for(const p in a)h[p]=a[p];return h}const Te="constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");function le(a,h){let p,y;for(let k=1;k<arguments.length;k++){y=arguments[k];for(p in y)a[p]=y[p];for(let M=0;M<Te.length;M++)p=Te[M],Object.prototype.hasOwnProperty.call(y,p)&&(a[p]=y[p])}}function we(a){this.src=a,this.g={},this.h=0}we.prototype.add=function(a,h,p,y,k){const M=a.toString();a=this.g[M],a||(a=this.g[M]=[],this.h++);const W=Nt(a,h,y,k);return W>-1?(h=a[W],p||(h.fa=!1)):(h=new Re(h,this.src,M,!!y,k),h.fa=p,a.push(h)),h};function It(a,h){const p=h.type;if(p in a.g){var y=a.g[p],k=Array.prototype.indexOf.call(y,h,void 0),M;(M=k>=0)&&Array.prototype.splice.call(y,k,1),M&&(Se(h),a.g[p].length==0&&(delete a.g[p],a.h--))}}function Nt(a,h,p,y){for(let k=0;k<a.length;++k){const M=a[k];if(!M.da&&M.listener==h&&M.capture==!!p&&M.ha==y)return k}return-1}var rr="closure_lm_"+(Math.random()*1e6|0),Yt={};function oi(a,h,p,y,k){if(Array.isArray(h)){for(let M=0;M<h.length;M++)oi(a,h[M],p,y,k);return null}return p=ii(p),a&&a[ue]?a.J(h,p,c(y)?!!y.capture:!1,k):Pd(a,h,p,!1,y,k)}function Pd(a,h,p,y,k,M){if(!h)throw Error("Invalid event type");const W=c(k)?!!k.capture:!!k;let se=sr(a);if(se||(a[rr]=se=new we(a)),p=se.add(h,p,y,W,M),p.proxy)return p;if(y=yn(),p.proxy=y,y.src=a,y.listener=p,a.addEventListener)x||(k=W),k===void 0&&(k=!1),a.addEventListener(h.toString(),y,k);else if(a.attachEvent)a.attachEvent(ri(h.toString()),y);else if(a.addListener&&a.removeListener)a.addListener(y);else throw Error("addEventListener and attachEvent are unavailable.");return p}function yn(){function a(p){return h.call(a.src,a.listener,p)}const h=Sl;return a}function ir(a,h,p,y,k){if(Array.isArray(h))for(var M=0;M<h.length;M++)ir(a,h[M],p,y,k);else y=c(y)?!!y.capture:!!y,p=ii(p),a&&a[ue]?(a=a.i,M=String(h).toString(),M in a.g&&(h=a.g[M],p=Nt(h,p,y,k),p>-1&&(Se(h[p]),Array.prototype.splice.call(h,p,1),h.length==0&&(delete a.g[M],a.h--)))):a&&(a=sr(a))&&(h=a.g[h.toString()],a=-1,h&&(a=Nt(h,p,y,k)),(p=a>-1?h[a]:null)&&Kt(p))}function Kt(a){if(typeof a!="number"&&a&&!a.da){var h=a.src;if(h&&h[ue])It(h.i,a);else{var p=a.type,y=a.proxy;h.removeEventListener?h.removeEventListener(p,y,a.capture):h.detachEvent?h.detachEvent(ri(p),y):h.addListener&&h.removeListener&&h.removeListener(y),(p=sr(h))?(It(p,a),p.h==0&&(p.src=null,h[rr]=null)):Se(a)}}}function ri(a){return a in Yt?Yt[a]:Yt[a]="on"+a}function Sl(a,h){if(a.da)a=!0;else{h=new Z(h,this);const p=a.listener,y=a.ha||a.src;a.fa&&Kt(a),a=p.call(y,h)}return a}function sr(a){return a=a[rr],a instanceof we?a:null}var xt="__closure_events_fn_"+(Math.random()*1e9>>>0);function ii(a){return typeof a=="function"?a:(a[xt]||(a[xt]=function(h){return a.handleEvent(h)}),a[xt])}function Ge(){I.call(this),this.i=new we(this),this.M=this,this.G=null}g(Ge,I),Ge.prototype[ue]=!0,Ge.prototype.removeEventListener=function(a,h,p,y){ir(this,a,h,p,y)};function et(a,h){var p,y=a.G;if(y)for(p=[];y;y=y.G)p.push(y);if(a=a.M,y=h.type||h,typeof h=="string")h=new _(h,a);else if(h instanceof _)h.target=h.target||a;else{var k=h;h=new _(y,a),le(h,k)}k=!0;let M,W;if(p)for(W=p.length-1;W>=0;W--)M=h.g=p[W],k=Eo(M,y,!0,h)&&k;if(M=h.g=a,k=Eo(M,y,!0,h)&&k,k=Eo(M,y,!1,h)&&k,p)for(W=0;W<p.length;W++)M=h.g=p[W],k=Eo(M,y,!1,h)&&k}Ge.prototype.N=function(){if(Ge.Z.N.call(this),this.i){var a=this.i;for(const h in a.g){const p=a.g[h];for(let y=0;y<p.length;y++)Se(p[y]);delete a.g[h],a.h--}}this.G=null},Ge.prototype.J=function(a,h,p,y){return this.i.add(String(a),h,!1,p,y)},Ge.prototype.K=function(a,h,p,y){return this.i.add(String(a),h,!0,p,y)};function Eo(a,h,p,y){if(h=a.i.g[String(h)],!h)return!0;h=h.concat();let k=!0;for(let M=0;M<h.length;++M){const W=h[M];if(W&&!W.da&&W.capture==p){const se=W.listener,Xe=W.ha||W.src;W.fa&&It(a.i,W),k=se.call(Xe,y)!==!1&&k}}return k&&!y.defaultPrevented}function Ms(a,h){if(typeof a!="function")if(a&&typeof a.handleEvent=="function")a=u(a.handleEvent,a);else throw Error("Invalid listener argument");return Number(h)>2147483647?-1:s.setTimeout(a,h||0)}function si(a){a.g=Ms(()=>{a.g=null,a.i&&(a.i=!1,si(a))},a.l);const h=a.h;a.h=null,a.m.apply(null,h)}class Ns extends I{constructor(h,p){super(),this.m=h,this.l=p,this.h=null,this.i=!1,this.g=null}j(h){this.h=arguments,this.g?this.i=!0:si(this)}N(){super.N(),this.g&&(s.clearTimeout(this.g),this.g=null,this.i=!1,this.h=null)}}function zn(a){I.call(this),this.h=a,this.g={}}g(zn,I);var ai=[];function li(a){_e(a.g,function(h,p){this.g.hasOwnProperty(p)&&Kt(h)},a),a.g={}}zn.prototype.N=function(){zn.Z.N.call(this),li(this)},zn.prototype.handleEvent=function(){throw Error("EventHandler.handleEvent not implemented")};var ar=s.JSON.stringify,Ls=s.JSON.parse,Ds=class{stringify(a){return s.JSON.stringify(a,void 0)}parse(a){return s.JSON.parse(a,void 0)}};function P(){}function B(){}var K={OPEN:"a",hb:"b",ERROR:"c",tb:"d"};function re(){_.call(this,"d")}g(re,_);function Ye(){_.call(this,"c")}g(Ye,_);var Ae={},Ke=null;function Io(){return Ke=Ke||new Ge}Ae.Ia="serverreachability";function ci(a){_.call(this,Ae.Ia,a)}g(ci,_);function ui(a){const h=Io();et(h,new ci(h))}Ae.STAT_EVENT="statevent";function Rd(a,h){_.call(this,Ae.STAT_EVENT,a),this.stat=h}g(Rd,_);function pt(a){const h=Io();et(h,new Rd(h,a))}Ae.Ja="timingevent";function Od(a,h){_.call(this,Ae.Ja,a),this.size=h}g(Od,_);function di(a,h){if(typeof a!="function")throw Error("Fn must not be null and must be a function");return s.setTimeout(function(){a()},h)}function hi(){this.g=!0}hi.prototype.ua=function(){this.g=!1};function Gy(a,h,p,y,k,M){a.info(function(){if(a.g)if(M){var W="",se=M.split("&");for(let Ie=0;Ie<se.length;Ie++){var Xe=se[Ie].split("=");if(Xe.length>1){const tt=Xe[0];Xe=Xe[1];const Qt=tt.split("_");W=Qt.length>=2&&Qt[1]=="type"?W+(tt+"="+Xe+"&"):W+(tt+"=redacted&")}}}else W=null;else W=M;return"XMLHTTP REQ ("+y+") [attempt "+k+"]: "+h+`
`+p+`
`+W})}function Yy(a,h,p,y,k,M,W){a.info(function(){return"XMLHTTP RESP ("+y+") [ attempt "+k+"]: "+h+`
`+p+`
`+M+" "+W})}function lr(a,h,p,y){a.info(function(){return"XMLHTTP TEXT ("+h+"): "+Xy(a,p)+(y?" "+y:"")})}function Ky(a,h){a.info(function(){return"TIMEOUT: "+h})}hi.prototype.info=function(){};function Xy(a,h){if(!a.g)return h;if(!h)return null;try{const M=JSON.parse(h);if(M){for(a=0;a<M.length;a++)if(Array.isArray(M[a])){var p=M[a];if(!(p.length<2)){var y=p[1];if(Array.isArray(y)&&!(y.length<1)){var k=y[0];if(k!="noop"&&k!="stop"&&k!="close")for(let W=1;W<y.length;W++)y[W]=""}}}}return ar(M)}catch{return h}}var Vs={NO_ERROR:0,cb:1,qb:2,pb:3,kb:4,ob:5,rb:6,Ga:7,TIMEOUT:8,ub:9},Md={ib:"complete",Fb:"success",ERROR:"error",Ga:"abort",xb:"ready",yb:"readystatechange",TIMEOUT:"timeout",sb:"incrementaldata",wb:"progress",lb:"downloadprogress",Nb:"uploadprogress"},Nd;function Al(){}g(Al,P),Al.prototype.g=function(){return new XMLHttpRequest},Nd=new Al;function fi(a){return encodeURIComponent(String(a))}function Qy(a){var h=1;a=a.split(":");const p=[];for(;h>0&&a.length;)p.push(a.shift()),h--;return a.length&&p.push(a.join(":")),p}function Bn(a,h,p,y){this.j=a,this.i=h,this.l=p,this.S=y||1,this.V=new zn(this),this.H=45e3,this.J=null,this.o=!1,this.u=this.B=this.A=this.M=this.F=this.T=this.D=null,this.G=[],this.g=null,this.C=0,this.m=this.v=null,this.X=-1,this.K=!1,this.P=0,this.O=null,this.W=this.L=this.U=this.R=!1,this.h=new Ld}function Ld(){this.i=null,this.g="",this.h=!1}var Dd={},kl={};function Cl(a,h,p){a.M=1,a.A=Us(Xt(h)),a.u=p,a.R=!0,Vd(a,null)}function Vd(a,h){a.F=Date.now(),Fs(a),a.B=Xt(a.A);var p=a.B,y=a.S;Array.isArray(y)||(y=[String(y)]),Xd(p.i,"t",y),a.C=0,p=a.j.L,a.h=new Ld,a.g=ph(a.j,p?h:null,!a.u),a.P>0&&(a.O=new Ns(u(a.Y,a,a.g),a.P)),h=a.V,p=a.g,y=a.ba;var k="readystatechange";Array.isArray(k)||(k&&(ai[0]=k.toString()),k=ai);for(let M=0;M<k.length;M++){const W=oi(p,k[M],y||h.handleEvent,!1,h.h||h);if(!W)break;h.g[W.key]=W}h=a.J?ae(a.J):{},a.u?(a.v||(a.v="POST"),h["Content-Type"]="application/x-www-form-urlencoded",a.g.ea(a.B,a.v,a.u,h)):(a.v="GET",a.g.ea(a.B,a.v,null,h)),ui(),Gy(a.i,a.v,a.B,a.l,a.S,a.u)}Bn.prototype.ba=function(a){a=a.target;const h=this.O;h&&Wn(a)==3?h.j():this.Y(a)},Bn.prototype.Y=function(a){try{if(a==this.g)e:{const se=Wn(this.g),Xe=this.g.ya(),Ie=this.g.ca();if(!(se<3)&&(se!=3||this.g&&(this.h.h||this.g.la()||oh(this.g)))){this.K||se!=4||Xe==7||(Xe==8||Ie<=0?ui(3):ui(2)),Pl(this);var h=this.g.ca();this.X=h;var p=Jy(this);if(this.o=h==200,Yy(this.i,this.v,this.B,this.l,this.S,se,h),this.o){if(this.U&&!this.L){t:{if(this.g){var y,k=this.g;if((y=k.g?k.g.getResponseHeader("X-HTTP-Initial-Response"):null)&&!T(y)){var M=y;break t}}M=null}if(a=M)lr(this.i,this.l,a,"Initial handshake response via X-HTTP-Initial-Response"),this.L=!0,Rl(this,a);else{this.o=!1,this.m=3,pt(12),xo(this),pi(this);break e}}if(this.R){a=!0;let tt;for(;!this.K&&this.C<p.length;)if(tt=Zy(this,p),tt==kl){se==4&&(this.m=4,pt(14),a=!1),lr(this.i,this.l,null,"[Incomplete Response]");break}else if(tt==Dd){this.m=4,pt(15),lr(this.i,this.l,p,"[Invalid Chunk]"),a=!1;break}else lr(this.i,this.l,tt,null),Rl(this,tt);if(Fd(this)&&this.C!=0&&(this.h.g=this.h.g.slice(this.C),this.C=0),se!=4||p.length!=0||this.h.h||(this.m=1,pt(16),a=!1),this.o=this.o&&a,!a)lr(this.i,this.l,p,"[Invalid Chunked Response]"),xo(this),pi(this);else if(p.length>0&&!this.W){this.W=!0;var W=this.j;W.g==this&&W.aa&&!W.P&&(W.j.info("Great, no buffering proxy detected. Bytes received: "+p.length),Ul(W),W.P=!0,pt(11))}}else lr(this.i,this.l,p,null),Rl(this,p);se==4&&xo(this),this.o&&!this.K&&(se==4?uh(this.j,this):(this.o=!1,Fs(this)))}else fv(this.g),h==400&&p.indexOf("Unknown SID")>0?(this.m=3,pt(12)):(this.m=0,pt(13)),xo(this),pi(this)}}}catch{}finally{}};function Jy(a){if(!Fd(a))return a.g.la();const h=oh(a.g);if(h==="")return"";let p="";const y=h.length,k=Wn(a.g)==4;if(!a.h.i){if(typeof TextDecoder>"u")return xo(a),pi(a),"";a.h.i=new s.TextDecoder}for(let M=0;M<y;M++)a.h.h=!0,p+=a.h.i.decode(h[M],{stream:!(k&&M==y-1)});return h.length=0,a.h.g+=p,a.C=0,a.h.g}function Fd(a){return a.g?a.v=="GET"&&a.M!=2&&a.j.Aa:!1}function Zy(a,h){var p=a.C,y=h.indexOf(`
`,p);return y==-1?kl:(p=Number(h.substring(p,y)),isNaN(p)?Dd:(y+=1,y+p>h.length?kl:(h=h.slice(y,y+p),a.C=y+p,h)))}Bn.prototype.cancel=function(){this.K=!0,xo(this)};function Fs(a){a.T=Date.now()+a.H,Ud(a,a.H)}function Ud(a,h){if(a.D!=null)throw Error("WatchDog timer not null");a.D=di(u(a.aa,a),h)}function Pl(a){a.D&&(s.clearTimeout(a.D),a.D=null)}Bn.prototype.aa=function(){this.D=null;const a=Date.now();a-this.T>=0?(Ky(this.i,this.B),this.M!=2&&(ui(),pt(17)),xo(this),this.m=2,pi(this)):Ud(this,this.T-a)};function pi(a){a.j.I==0||a.K||uh(a.j,a)}function xo(a){Pl(a);var h=a.O;h&&typeof h.dispose=="function"&&h.dispose(),a.O=null,li(a.V),a.g&&(h=a.g,a.g=null,h.abort(),h.dispose())}function Rl(a,h){try{var p=a.j;if(p.I!=0&&(p.g==a||Ol(p.h,a))){if(!a.L&&Ol(p.h,a)&&p.I==3){try{var y=p.Ba.g.parse(h)}catch{y=null}if(Array.isArray(y)&&y.length==3){var k=y;if(k[0]==0){e:if(!p.v){if(p.g)if(p.g.F+3e3<a.F)js(p),Bs(p);else break e;Fl(p),pt(18)}}else p.xa=k[1],0<p.xa-p.K&&k[2]<37500&&p.F&&p.A==0&&!p.C&&(p.C=di(u(p.Va,p),6e3));Bd(p.h)<=1&&p.ta&&(p.ta=void 0)}else Ao(p,11)}else if((a.L||p.g==a)&&js(p),!T(h))for(k=p.Ba.g.parse(h),h=0;h<k.length;h++){let Ie=k[h];const tt=Ie[0];if(!(tt<=p.K))if(p.K=tt,Ie=Ie[1],p.I==2)if(Ie[0]=="c"){p.M=Ie[1],p.ba=Ie[2];const Qt=Ie[3];Qt!=null&&(p.ka=Qt,p.j.info("VER="+p.ka));const ko=Ie[4];ko!=null&&(p.za=ko,p.j.info("SVER="+p.za));const Hn=Ie[5];Hn!=null&&typeof Hn=="number"&&Hn>0&&(y=1.5*Hn,p.O=y,p.j.info("backChannelRequestTimeoutMs_="+y)),y=p;const Gn=a.g;if(Gn){const Hs=Gn.g?Gn.g.getResponseHeader("X-Client-Wire-Protocol"):null;if(Hs){var M=y.h;M.g||Hs.indexOf("spdy")==-1&&Hs.indexOf("quic")==-1&&Hs.indexOf("h2")==-1||(M.j=M.l,M.g=new Set,M.h&&(Ml(M,M.h),M.h=null))}if(y.G){const ql=Gn.g?Gn.g.getResponseHeader("X-HTTP-Session-Id"):null;ql&&(y.wa=ql,ke(y.J,y.G,ql))}}p.I=3,p.l&&p.l.ra(),p.aa&&(p.T=Date.now()-a.F,p.j.info("Handshake RTT: "+p.T+"ms")),y=p;var W=a;if(y.na=fh(y,y.L?y.ba:null,y.W),W.L){$d(y.h,W);var se=W,Xe=y.O;Xe&&(se.H=Xe),se.D&&(Pl(se),Fs(se)),y.g=W}else lh(y);p.i.length>0&&$s(p)}else Ie[0]!="stop"&&Ie[0]!="close"||Ao(p,7);else p.I==3&&(Ie[0]=="stop"||Ie[0]=="close"?Ie[0]=="stop"?Ao(p,7):Vl(p):Ie[0]!="noop"&&p.l&&p.l.qa(Ie),p.A=0)}}ui(4)}catch{}}var ev=class{constructor(a,h){this.g=a,this.map=h}};function qd(a){this.l=a||10,s.PerformanceNavigationTiming?(a=s.performance.getEntriesByType("navigation"),a=a.length>0&&(a[0].nextHopProtocol=="hq"||a[0].nextHopProtocol=="h2")):a=!!(s.chrome&&s.chrome.loadTimes&&s.chrome.loadTimes()&&s.chrome.loadTimes().wasFetchedViaSpdy),this.j=a?this.l:1,this.g=null,this.j>1&&(this.g=new Set),this.h=null,this.i=[]}function zd(a){return a.h?!0:a.g?a.g.size>=a.j:!1}function Bd(a){return a.h?1:a.g?a.g.size:0}function Ol(a,h){return a.h?a.h==h:a.g?a.g.has(h):!1}function Ml(a,h){a.g?a.g.add(h):a.h=h}function $d(a,h){a.h&&a.h==h?a.h=null:a.g&&a.g.has(h)&&a.g.delete(h)}qd.prototype.cancel=function(){if(this.i=jd(this),this.h)this.h.cancel(),this.h=null;else if(this.g&&this.g.size!==0){for(const a of this.g.values())a.cancel();this.g.clear()}};function jd(a){if(a.h!=null)return a.i.concat(a.h.G);if(a.g!=null&&a.g.size!==0){let h=a.i;for(const p of a.g.values())h=h.concat(p.G);return h}return v(a.i)}var Wd=RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");function tv(a,h){if(a){a=a.split("&");for(let p=0;p<a.length;p++){const y=a[p].indexOf("=");let k,M=null;y>=0?(k=a[p].substring(0,y),M=a[p].substring(y+1)):k=a[p],h(k,M?decodeURIComponent(M.replace(/\+/g," ")):"")}}}function $n(a){this.g=this.o=this.j="",this.u=null,this.m=this.h="",this.l=!1;let h;a instanceof $n?(this.l=a.l,gi(this,a.j),this.o=a.o,this.g=a.g,mi(this,a.u),this.h=a.h,Nl(this,Qd(a.i)),this.m=a.m):a&&(h=String(a).match(Wd))?(this.l=!1,gi(this,h[1]||"",!0),this.o=yi(h[2]||""),this.g=yi(h[3]||"",!0),mi(this,h[4]),this.h=yi(h[5]||"",!0),Nl(this,h[6]||"",!0),this.m=yi(h[7]||"")):(this.l=!1,this.i=new bi(null,this.l))}$n.prototype.toString=function(){const a=[];var h=this.j;h&&a.push(vi(h,Hd,!0),":");var p=this.g;return(p||h=="file")&&(a.push("//"),(h=this.o)&&a.push(vi(h,Hd,!0),"@"),a.push(fi(p).replace(/%25([0-9a-fA-F]{2})/g,"%$1")),p=this.u,p!=null&&a.push(":",String(p))),(p=this.h)&&(this.g&&p.charAt(0)!="/"&&a.push("/"),a.push(vi(p,p.charAt(0)=="/"?rv:ov,!0))),(p=this.i.toString())&&a.push("?",p),(p=this.m)&&a.push("#",vi(p,sv)),a.join("")},$n.prototype.resolve=function(a){const h=Xt(this);let p=!!a.j;p?gi(h,a.j):p=!!a.o,p?h.o=a.o:p=!!a.g,p?h.g=a.g:p=a.u!=null;var y=a.h;if(p)mi(h,a.u);else if(p=!!a.h){if(y.charAt(0)!="/")if(this.g&&!this.h)y="/"+y;else{var k=h.h.lastIndexOf("/");k!=-1&&(y=h.h.slice(0,k+1)+y)}if(k=y,k==".."||k==".")y="";else if(k.indexOf("./")!=-1||k.indexOf("/.")!=-1){y=k.lastIndexOf("/",0)==0,k=k.split("/");const M=[];for(let W=0;W<k.length;){const se=k[W++];se=="."?y&&W==k.length&&M.push(""):se==".."?((M.length>1||M.length==1&&M[0]!="")&&M.pop(),y&&W==k.length&&M.push("")):(M.push(se),y=!0)}y=M.join("/")}else y=k}return p?h.h=y:p=a.i.toString()!=="",p?Nl(h,Qd(a.i)):p=!!a.m,p&&(h.m=a.m),h};function Xt(a){return new $n(a)}function gi(a,h,p){a.j=p?yi(h,!0):h,a.j&&(a.j=a.j.replace(/:$/,""))}function mi(a,h){if(h){if(h=Number(h),isNaN(h)||h<0)throw Error("Bad port number "+h);a.u=h}else a.u=null}function Nl(a,h,p){h instanceof bi?(a.i=h,av(a.i,a.l)):(p||(h=vi(h,iv)),a.i=new bi(h,a.l))}function ke(a,h,p){a.i.set(h,p)}function Us(a){return ke(a,"zx",Math.floor(Math.random()*2147483648).toString(36)+Math.abs(Math.floor(Math.random()*2147483648)^Date.now()).toString(36)),a}function yi(a,h){return a?h?decodeURI(a.replace(/%25/g,"%2525")):decodeURIComponent(a):""}function vi(a,h,p){return typeof a=="string"?(a=encodeURI(a).replace(h,nv),p&&(a=a.replace(/%25([0-9a-fA-F]{2})/g,"%$1")),a):null}function nv(a){return a=a.charCodeAt(0),"%"+(a>>4&15).toString(16)+(a&15).toString(16)}var Hd=/[#\/\?@]/g,ov=/[#\?:]/g,rv=/[#\?]/g,iv=/[#\?@]/g,sv=/#/g;function bi(a,h){this.h=this.g=null,this.i=a||null,this.j=!!h}function So(a){a.g||(a.g=new Map,a.h=0,a.i&&tv(a.i,function(h,p){a.add(decodeURIComponent(h.replace(/\+/g," ")),p)}))}n=bi.prototype,n.add=function(a,h){So(this),this.i=null,a=cr(this,a);let p=this.g.get(a);return p||this.g.set(a,p=[]),p.push(h),this.h+=1,this};function Gd(a,h){So(a),h=cr(a,h),a.g.has(h)&&(a.i=null,a.h-=a.g.get(h).length,a.g.delete(h))}function Yd(a,h){return So(a),h=cr(a,h),a.g.has(h)}n.forEach=function(a,h){So(this),this.g.forEach(function(p,y){p.forEach(function(k){a.call(h,k,y,this)},this)},this)};function Kd(a,h){So(a);let p=[];if(typeof h=="string")Yd(a,h)&&(p=p.concat(a.g.get(cr(a,h))));else for(a=Array.from(a.g.values()),h=0;h<a.length;h++)p=p.concat(a[h]);return p}n.set=function(a,h){return So(this),this.i=null,a=cr(this,a),Yd(this,a)&&(this.h-=this.g.get(a).length),this.g.set(a,[h]),this.h+=1,this},n.get=function(a,h){return a?(a=Kd(this,a),a.length>0?String(a[0]):h):h};function Xd(a,h,p){Gd(a,h),p.length>0&&(a.i=null,a.g.set(cr(a,h),v(p)),a.h+=p.length)}n.toString=function(){if(this.i)return this.i;if(!this.g)return"";const a=[],h=Array.from(this.g.keys());for(let y=0;y<h.length;y++){var p=h[y];const k=fi(p);p=Kd(this,p);for(let M=0;M<p.length;M++){let W=k;p[M]!==""&&(W+="="+fi(p[M])),a.push(W)}}return this.i=a.join("&")};function Qd(a){const h=new bi;return h.i=a.i,a.g&&(h.g=new Map(a.g),h.h=a.h),h}function cr(a,h){return h=String(h),a.j&&(h=h.toLowerCase()),h}function av(a,h){h&&!a.j&&(So(a),a.i=null,a.g.forEach(function(p,y){const k=y.toLowerCase();y!=k&&(Gd(this,y),Xd(this,k,p))},a)),a.j=h}function lv(a,h){const p=new hi;if(s.Image){const y=new Image;y.onload=f(jn,p,"TestLoadImage: loaded",!0,h,y),y.onerror=f(jn,p,"TestLoadImage: error",!1,h,y),y.onabort=f(jn,p,"TestLoadImage: abort",!1,h,y),y.ontimeout=f(jn,p,"TestLoadImage: timeout",!1,h,y),s.setTimeout(function(){y.ontimeout&&y.ontimeout()},1e4),y.src=a}else h(!1)}function cv(a,h){const p=new hi,y=new AbortController,k=setTimeout(()=>{y.abort(),jn(p,"TestPingServer: timeout",!1,h)},1e4);fetch(a,{signal:y.signal}).then(M=>{clearTimeout(k),M.ok?jn(p,"TestPingServer: ok",!0,h):jn(p,"TestPingServer: server error",!1,h)}).catch(()=>{clearTimeout(k),jn(p,"TestPingServer: error",!1,h)})}function jn(a,h,p,y,k){try{k&&(k.onload=null,k.onerror=null,k.onabort=null,k.ontimeout=null),y(p)}catch{}}function uv(){this.g=new Ds}function Ll(a){this.i=a.Sb||null,this.h=a.ab||!1}g(Ll,P),Ll.prototype.g=function(){return new qs(this.i,this.h)};function qs(a,h){Ge.call(this),this.H=a,this.o=h,this.m=void 0,this.status=this.readyState=0,this.responseType=this.responseText=this.response=this.statusText="",this.onreadystatechange=null,this.A=new Headers,this.h=null,this.F="GET",this.D="",this.g=!1,this.B=this.j=this.l=null,this.v=new AbortController}g(qs,Ge),n=qs.prototype,n.open=function(a,h){if(this.readyState!=0)throw this.abort(),Error("Error reopening a connection");this.F=a,this.D=h,this.readyState=1,_i(this)},n.send=function(a){if(this.readyState!=1)throw this.abort(),Error("need to call open() first. ");if(this.v.signal.aborted)throw this.abort(),Error("Request was aborted.");this.g=!0;const h={headers:this.A,method:this.F,credentials:this.m,cache:void 0,signal:this.v.signal};a&&(h.body=a),(this.H||s).fetch(new Request(this.D,h)).then(this.Pa.bind(this),this.ga.bind(this))},n.abort=function(){this.response=this.responseText="",this.A=new Headers,this.status=0,this.v.abort(),this.j&&this.j.cancel("Request was aborted.").catch(()=>{}),this.readyState>=1&&this.g&&this.readyState!=4&&(this.g=!1,wi(this)),this.readyState=0},n.Pa=function(a){if(this.g&&(this.l=a,this.h||(this.status=this.l.status,this.statusText=this.l.statusText,this.h=a.headers,this.readyState=2,_i(this)),this.g&&(this.readyState=3,_i(this),this.g)))if(this.responseType==="arraybuffer")a.arrayBuffer().then(this.Na.bind(this),this.ga.bind(this));else if(typeof s.ReadableStream<"u"&&"body"in a){if(this.j=a.body.getReader(),this.o){if(this.responseType)throw Error('responseType must be empty for "streamBinaryChunks" mode responses.');this.response=[]}else this.response=this.responseText="",this.B=new TextDecoder;Jd(this)}else a.text().then(this.Oa.bind(this),this.ga.bind(this))};function Jd(a){a.j.read().then(a.Ma.bind(a)).catch(a.ga.bind(a))}n.Ma=function(a){if(this.g){if(this.o&&a.value)this.response.push(a.value);else if(!this.o){var h=a.value?a.value:new Uint8Array(0);(h=this.B.decode(h,{stream:!a.done}))&&(this.response=this.responseText+=h)}a.done?wi(this):_i(this),this.readyState==3&&Jd(this)}},n.Oa=function(a){this.g&&(this.response=this.responseText=a,wi(this))},n.Na=function(a){this.g&&(this.response=a,wi(this))},n.ga=function(){this.g&&wi(this)};function wi(a){a.readyState=4,a.l=null,a.j=null,a.B=null,_i(a)}n.setRequestHeader=function(a,h){this.A.append(a,h)},n.getResponseHeader=function(a){return this.h&&this.h.get(a.toLowerCase())||""},n.getAllResponseHeaders=function(){if(!this.h)return"";const a=[],h=this.h.entries();for(var p=h.next();!p.done;)p=p.value,a.push(p[0]+": "+p[1]),p=h.next();return a.join(`\r
`)};function _i(a){a.onreadystatechange&&a.onreadystatechange.call(a)}Object.defineProperty(qs.prototype,"withCredentials",{get:function(){return this.m==="include"},set:function(a){this.m=a?"include":"same-origin"}});function Zd(a){let h="";return _e(a,function(p,y){h+=y,h+=":",h+=p,h+=`\r
`}),h}function Dl(a,h,p){e:{for(y in p){var y=!1;break e}y=!0}y||(p=Zd(p),typeof a=="string"?p!=null&&fi(p):ke(a,h,p))}function Le(a){Ge.call(this),this.headers=new Map,this.L=a||null,this.h=!1,this.g=null,this.D="",this.o=0,this.l="",this.j=this.B=this.v=this.A=!1,this.m=null,this.F="",this.H=!1}g(Le,Ge);var dv=/^https?$/i,hv=["POST","PUT"];n=Le.prototype,n.Fa=function(a){this.H=a},n.ea=function(a,h,p,y){if(this.g)throw Error("[goog.net.XhrIo] Object is active with another request="+this.D+"; newUri="+a);h=h?h.toUpperCase():"GET",this.D=a,this.l="",this.o=0,this.A=!1,this.h=!0,this.g=this.L?this.L.g():Nd.g(),this.g.onreadystatechange=m(u(this.Ca,this));try{this.B=!0,this.g.open(h,String(a),!0),this.B=!1}catch(M){eh(this,M);return}if(a=p||"",p=new Map(this.headers),y)if(Object.getPrototypeOf(y)===Object.prototype)for(var k in y)p.set(k,y[k]);else if(typeof y.keys=="function"&&typeof y.get=="function")for(const M of y.keys())p.set(M,y.get(M));else throw Error("Unknown input type for opt_headers: "+String(y));y=Array.from(p.keys()).find(M=>M.toLowerCase()=="content-type"),k=s.FormData&&a instanceof s.FormData,!(Array.prototype.indexOf.call(hv,h,void 0)>=0)||y||k||p.set("Content-Type","application/x-www-form-urlencoded;charset=utf-8");for(const[M,W]of p)this.g.setRequestHeader(M,W);this.F&&(this.g.responseType=this.F),"withCredentials"in this.g&&this.g.withCredentials!==this.H&&(this.g.withCredentials=this.H);try{this.m&&(clearTimeout(this.m),this.m=null),this.v=!0,this.g.send(a),this.v=!1}catch(M){eh(this,M)}};function eh(a,h){a.h=!1,a.g&&(a.j=!0,a.g.abort(),a.j=!1),a.l=h,a.o=5,th(a),zs(a)}function th(a){a.A||(a.A=!0,et(a,"complete"),et(a,"error"))}n.abort=function(a){this.g&&this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1,this.o=a||7,et(this,"complete"),et(this,"abort"),zs(this))},n.N=function(){this.g&&(this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1),zs(this,!0)),Le.Z.N.call(this)},n.Ca=function(){this.u||(this.B||this.v||this.j?nh(this):this.Xa())},n.Xa=function(){nh(this)};function nh(a){if(a.h&&typeof i<"u"){if(a.v&&Wn(a)==4)setTimeout(a.Ca.bind(a),0);else if(et(a,"readystatechange"),Wn(a)==4){a.h=!1;try{const M=a.ca();e:switch(M){case 200:case 201:case 202:case 204:case 206:case 304:case 1223:var h=!0;break e;default:h=!1}var p;if(!(p=h)){var y;if(y=M===0){let W=String(a.D).match(Wd)[1]||null;!W&&s.self&&s.self.location&&(W=s.self.location.protocol.slice(0,-1)),y=!dv.test(W?W.toLowerCase():"")}p=y}if(p)et(a,"complete"),et(a,"success");else{a.o=6;try{var k=Wn(a)>2?a.g.statusText:""}catch{k=""}a.l=k+" ["+a.ca()+"]",th(a)}}finally{zs(a)}}}}function zs(a,h){if(a.g){a.m&&(clearTimeout(a.m),a.m=null);const p=a.g;a.g=null,h||et(a,"ready");try{p.onreadystatechange=null}catch{}}}n.isActive=function(){return!!this.g};function Wn(a){return a.g?a.g.readyState:0}n.ca=function(){try{return Wn(this)>2?this.g.status:-1}catch{return-1}},n.la=function(){try{return this.g?this.g.responseText:""}catch{return""}},n.La=function(a){if(this.g){var h=this.g.responseText;return a&&h.indexOf(a)==0&&(h=h.substring(a.length)),Ls(h)}};function oh(a){try{if(!a.g)return null;if("response"in a.g)return a.g.response;switch(a.F){case"":case"text":return a.g.responseText;case"arraybuffer":if("mozResponseArrayBuffer"in a.g)return a.g.mozResponseArrayBuffer}return null}catch{return null}}function fv(a){const h={};a=(a.g&&Wn(a)>=2&&a.g.getAllResponseHeaders()||"").split(`\r
`);for(let y=0;y<a.length;y++){if(T(a[y]))continue;var p=Qy(a[y]);const k=p[0];if(p=p[1],typeof p!="string")continue;p=p.trim();const M=h[k]||[];h[k]=M,M.push(p)}Ee(h,function(y){return y.join(", ")})}n.ya=function(){return this.o},n.Ha=function(){return typeof this.l=="string"?this.l:String(this.l)};function Ti(a,h,p){return p&&p.internalChannelParams&&p.internalChannelParams[a]||h}function rh(a){this.za=0,this.i=[],this.j=new hi,this.ba=this.na=this.J=this.W=this.g=this.wa=this.G=this.H=this.u=this.U=this.o=null,this.Ya=this.V=0,this.Sa=Ti("failFast",!1,a),this.F=this.C=this.v=this.m=this.l=null,this.X=!0,this.xa=this.K=-1,this.Y=this.A=this.D=0,this.Qa=Ti("baseRetryDelayMs",5e3,a),this.Za=Ti("retryDelaySeedMs",1e4,a),this.Ta=Ti("forwardChannelMaxRetries",2,a),this.va=Ti("forwardChannelRequestTimeoutMs",2e4,a),this.ma=a&&a.xmlHttpFactory||void 0,this.Ua=a&&a.Rb||void 0,this.Aa=a&&a.useFetchStreams||!1,this.O=void 0,this.L=a&&a.supportsCrossDomainXhr||!1,this.M="",this.h=new qd(a&&a.concurrentRequestLimit),this.Ba=new uv,this.S=a&&a.fastHandshake||!1,this.R=a&&a.encodeInitMessageHeaders||!1,this.S&&this.R&&(this.R=!1),this.Ra=a&&a.Pb||!1,a&&a.ua&&this.j.ua(),a&&a.forceLongPolling&&(this.X=!1),this.aa=!this.S&&this.X&&a&&a.detectBufferingProxy||!1,this.ia=void 0,a&&a.longPollingTimeout&&a.longPollingTimeout>0&&(this.ia=a.longPollingTimeout),this.ta=void 0,this.T=0,this.P=!1,this.ja=this.B=null}n=rh.prototype,n.ka=8,n.I=1,n.connect=function(a,h,p,y){pt(0),this.W=a,this.H=h||{},p&&y!==void 0&&(this.H.OSID=p,this.H.OAID=y),this.F=this.X,this.J=fh(this,null,this.W),$s(this)};function Vl(a){if(ih(a),a.I==3){var h=a.V++,p=Xt(a.J);if(ke(p,"SID",a.M),ke(p,"RID",h),ke(p,"TYPE","terminate"),Ei(a,p),h=new Bn(a,a.j,h),h.M=2,h.A=Us(Xt(p)),p=!1,s.navigator&&s.navigator.sendBeacon)try{p=s.navigator.sendBeacon(h.A.toString(),"")}catch{}!p&&s.Image&&(new Image().src=h.A,p=!0),p||(h.g=ph(h.j,null),h.g.ea(h.A)),h.F=Date.now(),Fs(h)}hh(a)}function Bs(a){a.g&&(Ul(a),a.g.cancel(),a.g=null)}function ih(a){Bs(a),a.v&&(s.clearTimeout(a.v),a.v=null),js(a),a.h.cancel(),a.m&&(typeof a.m=="number"&&s.clearTimeout(a.m),a.m=null)}function $s(a){if(!zd(a.h)&&!a.m){a.m=!0;var h=a.Ea;j||w(),D||(j(),D=!0),E.add(h,a),a.D=0}}function pv(a,h){return Bd(a.h)>=a.h.j-(a.m?1:0)?!1:a.m?(a.i=h.G.concat(a.i),!0):a.I==1||a.I==2||a.D>=(a.Sa?0:a.Ta)?!1:(a.m=di(u(a.Ea,a,h),dh(a,a.D)),a.D++,!0)}n.Ea=function(a){if(this.m)if(this.m=null,this.I==1){if(!a){this.V=Math.floor(Math.random()*1e5),a=this.V++;const k=new Bn(this,this.j,a);let M=this.o;if(this.U&&(M?(M=ae(M),le(M,this.U)):M=this.U),this.u!==null||this.R||(k.J=M,M=null),this.S)e:{for(var h=0,p=0;p<this.i.length;p++){t:{var y=this.i[p];if("__data__"in y.map&&(y=y.map.__data__,typeof y=="string")){y=y.length;break t}y=void 0}if(y===void 0)break;if(h+=y,h>4096){h=p;break e}if(h===4096||p===this.i.length-1){h=p+1;break e}}h=1e3}else h=1e3;h=ah(this,k,h),p=Xt(this.J),ke(p,"RID",a),ke(p,"CVER",22),this.G&&ke(p,"X-HTTP-Session-Id",this.G),Ei(this,p),M&&(this.R?h="headers="+fi(Zd(M))+"&"+h:this.u&&Dl(p,this.u,M)),Ml(this.h,k),this.Ra&&ke(p,"TYPE","init"),this.S?(ke(p,"$req",h),ke(p,"SID","null"),k.U=!0,Cl(k,p,null)):Cl(k,p,h),this.I=2}}else this.I==3&&(a?sh(this,a):this.i.length==0||zd(this.h)||sh(this))};function sh(a,h){var p;h?p=h.l:p=a.V++;const y=Xt(a.J);ke(y,"SID",a.M),ke(y,"RID",p),ke(y,"AID",a.K),Ei(a,y),a.u&&a.o&&Dl(y,a.u,a.o),p=new Bn(a,a.j,p,a.D+1),a.u===null&&(p.J=a.o),h&&(a.i=h.G.concat(a.i)),h=ah(a,p,1e3),p.H=Math.round(a.va*.5)+Math.round(a.va*.5*Math.random()),Ml(a.h,p),Cl(p,y,h)}function Ei(a,h){a.H&&_e(a.H,function(p,y){ke(h,y,p)}),a.l&&_e({},function(p,y){ke(h,y,p)})}function ah(a,h,p){p=Math.min(a.i.length,p);const y=a.l?u(a.l.Ka,a.l,a):null;e:{var k=a.i;let se=-1;for(;;){const Xe=["count="+p];se==-1?p>0?(se=k[0].g,Xe.push("ofs="+se)):se=0:Xe.push("ofs="+se);let Ie=!0;for(let tt=0;tt<p;tt++){var M=k[tt].g;const Qt=k[tt].map;if(M-=se,M<0)se=Math.max(0,k[tt].g-100),Ie=!1;else try{M="req"+M+"_"||"";try{var W=Qt instanceof Map?Qt:Object.entries(Qt);for(const[ko,Hn]of W){let Gn=Hn;c(Hn)&&(Gn=ar(Hn)),Xe.push(M+ko+"="+encodeURIComponent(Gn))}}catch(ko){throw Xe.push(M+"type="+encodeURIComponent("_badmap")),ko}}catch{y&&y(Qt)}}if(Ie){W=Xe.join("&");break e}}W=void 0}return a=a.i.splice(0,p),h.G=a,W}function lh(a){if(!a.g&&!a.v){a.Y=1;var h=a.Da;j||w(),D||(j(),D=!0),E.add(h,a),a.A=0}}function Fl(a){return a.g||a.v||a.A>=3?!1:(a.Y++,a.v=di(u(a.Da,a),dh(a,a.A)),a.A++,!0)}n.Da=function(){if(this.v=null,ch(this),this.aa&&!(this.P||this.g==null||this.T<=0)){var a=4*this.T;this.j.info("BP detection timer enabled: "+a),this.B=di(u(this.Wa,this),a)}},n.Wa=function(){this.B&&(this.B=null,this.j.info("BP detection timeout reached."),this.j.info("Buffering proxy detected and switch to long-polling!"),this.F=!1,this.P=!0,pt(10),Bs(this),ch(this))};function Ul(a){a.B!=null&&(s.clearTimeout(a.B),a.B=null)}function ch(a){a.g=new Bn(a,a.j,"rpc",a.Y),a.u===null&&(a.g.J=a.o),a.g.P=0;var h=Xt(a.na);ke(h,"RID","rpc"),ke(h,"SID",a.M),ke(h,"AID",a.K),ke(h,"CI",a.F?"0":"1"),!a.F&&a.ia&&ke(h,"TO",a.ia),ke(h,"TYPE","xmlhttp"),Ei(a,h),a.u&&a.o&&Dl(h,a.u,a.o),a.O&&(a.g.H=a.O);var p=a.g;a=a.ba,p.M=1,p.A=Us(Xt(h)),p.u=null,p.R=!0,Vd(p,a)}n.Va=function(){this.C!=null&&(this.C=null,Bs(this),Fl(this),pt(19))};function js(a){a.C!=null&&(s.clearTimeout(a.C),a.C=null)}function uh(a,h){var p=null;if(a.g==h){js(a),Ul(a),a.g=null;var y=2}else if(Ol(a.h,h))p=h.G,$d(a.h,h),y=1;else return;if(a.I!=0){if(h.o)if(y==1){p=h.u?h.u.length:0,h=Date.now()-h.F;var k=a.D;y=Io(),et(y,new Od(y,p)),$s(a)}else lh(a);else if(k=h.m,k==3||k==0&&h.X>0||!(y==1&&pv(a,h)||y==2&&Fl(a)))switch(p&&p.length>0&&(h=a.h,h.i=h.i.concat(p)),k){case 1:Ao(a,5);break;case 4:Ao(a,10);break;case 3:Ao(a,6);break;default:Ao(a,2)}}}function dh(a,h){let p=a.Qa+Math.floor(Math.random()*a.Za);return a.isActive()||(p*=2),p*h}function Ao(a,h){if(a.j.info("Error code "+h),h==2){var p=u(a.bb,a),y=a.Ua;const k=!y;y=new $n(y||"//www.google.com/images/cleardot.gif"),s.location&&s.location.protocol=="http"||gi(y,"https"),Us(y),k?lv(y.toString(),p):cv(y.toString(),p)}else pt(2);a.I=0,a.l&&a.l.pa(h),hh(a),ih(a)}n.bb=function(a){a?(this.j.info("Successfully pinged google.com"),pt(2)):(this.j.info("Failed to ping google.com"),pt(1))};function hh(a){if(a.I=0,a.ja=[],a.l){const h=jd(a.h);(h.length!=0||a.i.length!=0)&&(O(a.ja,h),O(a.ja,a.i),a.h.i.length=0,v(a.i),a.i.length=0),a.l.oa()}}function fh(a,h,p){var y=p instanceof $n?Xt(p):new $n(p);if(y.g!="")h&&(y.g=h+"."+y.g),mi(y,y.u);else{var k=s.location;y=k.protocol,h=h?h+"."+k.hostname:k.hostname,k=+k.port;const M=new $n(null);y&&gi(M,y),h&&(M.g=h),k&&mi(M,k),p&&(M.h=p),y=M}return p=a.G,h=a.wa,p&&h&&ke(y,p,h),ke(y,"VER",a.ka),Ei(a,y),y}function ph(a,h,p){if(h&&!a.L)throw Error("Can't create secondary domain capable XhrIo object.");return h=a.Aa&&!a.ma?new Le(new Ll({ab:p})):new Le(a.ma),h.Fa(a.L),h}n.isActive=function(){return!!this.l&&this.l.isActive(this)};function gh(){}n=gh.prototype,n.ra=function(){},n.qa=function(){},n.pa=function(){},n.oa=function(){},n.isActive=function(){return!0},n.Ka=function(){};function Ws(){}Ws.prototype.g=function(a,h){return new St(a,h)};function St(a,h){Ge.call(this),this.g=new rh(h),this.l=a,this.h=h&&h.messageUrlParams||null,a=h&&h.messageHeaders||null,h&&h.clientProtocolHeaderRequired&&(a?a["X-Client-Protocol"]="webchannel":a={"X-Client-Protocol":"webchannel"}),this.g.o=a,a=h&&h.initMessageHeaders||null,h&&h.messageContentType&&(a?a["X-WebChannel-Content-Type"]=h.messageContentType:a={"X-WebChannel-Content-Type":h.messageContentType}),h&&h.sa&&(a?a["X-WebChannel-Client-Profile"]=h.sa:a={"X-WebChannel-Client-Profile":h.sa}),this.g.U=a,(a=h&&h.Qb)&&!T(a)&&(this.g.u=a),this.A=h&&h.supportsCrossDomainXhr||!1,this.v=h&&h.sendRawJson||!1,(h=h&&h.httpSessionIdParam)&&!T(h)&&(this.g.G=h,a=this.h,a!==null&&h in a&&(a=this.h,h in a&&delete a[h])),this.j=new ur(this)}g(St,Ge),St.prototype.m=function(){this.g.l=this.j,this.A&&(this.g.L=!0),this.g.connect(this.l,this.h||void 0)},St.prototype.close=function(){Vl(this.g)},St.prototype.o=function(a){var h=this.g;if(typeof a=="string"){var p={};p.__data__=a,a=p}else this.v&&(p={},p.__data__=ar(a),a=p);h.i.push(new ev(h.Ya++,a)),h.I==3&&$s(h)},St.prototype.N=function(){this.g.l=null,delete this.j,Vl(this.g),delete this.g,St.Z.N.call(this)};function mh(a){re.call(this),a.__headers__&&(this.headers=a.__headers__,this.statusCode=a.__status__,delete a.__headers__,delete a.__status__);var h=a.__sm__;if(h){e:{for(const p in h){a=p;break e}a=void 0}(this.i=a)&&(a=this.i,h=h!==null&&a in h?h[a]:void 0),this.data=h}else this.data=a}g(mh,re);function yh(){Ye.call(this),this.status=1}g(yh,Ye);function ur(a){this.g=a}g(ur,gh),ur.prototype.ra=function(){et(this.g,"a")},ur.prototype.qa=function(a){et(this.g,new mh(a))},ur.prototype.pa=function(a){et(this.g,new yh)},ur.prototype.oa=function(){et(this.g,"b")},Ws.prototype.createWebChannel=Ws.prototype.g,St.prototype.send=St.prototype.o,St.prototype.open=St.prototype.m,St.prototype.close=St.prototype.close,Tg=function(){return new Ws},_g=function(){return Io()},wg=Ae,vc={jb:0,mb:1,nb:2,Hb:3,Mb:4,Jb:5,Kb:6,Ib:7,Gb:8,Lb:9,PROXY:10,NOPROXY:11,Eb:12,Ab:13,Bb:14,zb:15,Cb:16,Db:17,fb:18,eb:19,gb:20},Vs.NO_ERROR=0,Vs.TIMEOUT=8,Vs.HTTP_ERROR=6,pa=Vs,Md.COMPLETE="complete",bg=Md,B.EventType=K,K.OPEN="a",K.CLOSE="b",K.ERROR="c",K.MESSAGE="d",Ge.prototype.listen=Ge.prototype.J,Mi=B,Le.prototype.listenOnce=Le.prototype.K,Le.prototype.getLastError=Le.prototype.Ha,Le.prototype.getLastErrorCode=Le.prototype.ya,Le.prototype.getStatus=Le.prototype.ca,Le.prototype.getResponseJson=Le.prototype.La,Le.prototype.getResponseText=Le.prototype.la,Le.prototype.send=Le.prototype.ea,Le.prototype.setWithCredentials=Le.prototype.Fa,vg=Le}).apply(typeof Ys<"u"?Ys:typeof self<"u"?self:typeof window<"u"?window:{});/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ut{constructor(e){this.uid=e}isAuthenticated(){return this.uid!=null}toKey(){return this.isAuthenticated()?"uid:"+this.uid:"anonymous-user"}isEqual(e){return e.uid===this.uid}}ut.UNAUTHENTICATED=new ut(null),ut.GOOGLE_CREDENTIALS=new ut("google-credentials-uid"),ut.FIRST_PARTY=new ut("first-party-uid"),ut.MOCK_USER=new ut("mock-user");/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Kr="12.12.0";function J_(n){Kr=n}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Go=new au("@firebase/firestore");function dr(){return Go.logLevel}function Y(n,...e){if(Go.logLevel<=de.DEBUG){const t=e.map(bu);Go.debug(`Firestore (${Kr}): ${n}`,...t)}}function Dn(n,...e){if(Go.logLevel<=de.ERROR){const t=e.map(bu);Go.error(`Firestore (${Kr}): ${n}`,...t)}}function Yo(n,...e){if(Go.logLevel<=de.WARN){const t=e.map(bu);Go.warn(`Firestore (${Kr}): ${n}`,...t)}}function bu(n){if(typeof n=="string")return n;try{return function(t){return JSON.stringify(t)}(n)}catch{return n}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ee(n,e,t){let o="Unexpected state";typeof e=="string"?o=e:t=e,Eg(n,o,t)}function Eg(n,e,t){let o=`FIRESTORE (${Kr}) INTERNAL ASSERTION FAILED: ${e} (ID: ${n.toString(16)})`;if(t!==void 0)try{o+=" CONTEXT: "+JSON.stringify(t)}catch{o+=" CONTEXT: "+t}throw Dn(o),new Error(o)}function be(n,e,t,o){let r="Unexpected state";typeof t=="string"?r=t:o=t,n||Eg(e,r,o)}function oe(n,e){return n}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const F={OK:"ok",CANCELLED:"cancelled",UNKNOWN:"unknown",INVALID_ARGUMENT:"invalid-argument",DEADLINE_EXCEEDED:"deadline-exceeded",NOT_FOUND:"not-found",ALREADY_EXISTS:"already-exists",PERMISSION_DENIED:"permission-denied",UNAUTHENTICATED:"unauthenticated",RESOURCE_EXHAUSTED:"resource-exhausted",FAILED_PRECONDITION:"failed-precondition",ABORTED:"aborted",OUT_OF_RANGE:"out-of-range",UNIMPLEMENTED:"unimplemented",INTERNAL:"internal",UNAVAILABLE:"unavailable",DATA_LOSS:"data-loss"};class G extends Un{constructor(e,t){super(e,t),this.code=e,this.message=t,this.toString=()=>`${this.name}: [code=${this.code}]: ${this.message}`}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Pn{constructor(){this.promise=new Promise((e,t)=>{this.resolve=e,this.reject=t})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ig{constructor(e,t){this.user=t,this.type="OAuth",this.headers=new Map,this.headers.set("Authorization",`Bearer ${e}`)}}class Z_{getToken(){return Promise.resolve(null)}invalidateToken(){}start(e,t){e.enqueueRetryable(()=>t(ut.UNAUTHENTICATED))}shutdown(){}}class e0{constructor(e){this.token=e,this.changeListener=null}getToken(){return Promise.resolve(this.token)}invalidateToken(){}start(e,t){this.changeListener=t,e.enqueueRetryable(()=>t(this.token.user))}shutdown(){this.changeListener=null}}class t0{constructor(e){this.t=e,this.currentUser=ut.UNAUTHENTICATED,this.i=0,this.forceRefresh=!1,this.auth=null}start(e,t){be(this.o===void 0,42304);let o=this.i;const r=d=>this.i!==o?(o=this.i,t(d)):Promise.resolve();let i=new Pn;this.o=()=>{this.i++,this.currentUser=this.u(),i.resolve(),i=new Pn,e.enqueueRetryable(()=>r(this.currentUser))};const s=()=>{const d=i;e.enqueueRetryable(async()=>{await d.promise,await r(this.currentUser)})},c=d=>{Y("FirebaseAuthCredentialsProvider","Auth detected"),this.auth=d,this.o&&(this.auth.addAuthTokenListener(this.o),s())};this.t.onInit(d=>c(d)),setTimeout(()=>{if(!this.auth){const d=this.t.getImmediate({optional:!0});d?c(d):(Y("FirebaseAuthCredentialsProvider","Auth not yet detected"),i.resolve(),i=new Pn)}},0),s()}getToken(){const e=this.i,t=this.forceRefresh;return this.forceRefresh=!1,this.auth?this.auth.getToken(t).then(o=>this.i!==e?(Y("FirebaseAuthCredentialsProvider","getToken aborted due to token change."),this.getToken()):o?(be(typeof o.accessToken=="string",31837,{l:o}),new Ig(o.accessToken,this.currentUser)):null):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.auth&&this.o&&this.auth.removeAuthTokenListener(this.o),this.o=void 0}u(){const e=this.auth&&this.auth.getUid();return be(e===null||typeof e=="string",2055,{h:e}),new ut(e)}}class n0{constructor(e,t,o){this.P=e,this.T=t,this.I=o,this.type="FirstParty",this.user=ut.FIRST_PARTY,this.R=new Map}A(){return this.I?this.I():null}get headers(){this.R.set("X-Goog-AuthUser",this.P);const e=this.A();return e&&this.R.set("Authorization",e),this.T&&this.R.set("X-Goog-Iam-Authorization-Token",this.T),this.R}}class o0{constructor(e,t,o){this.P=e,this.T=t,this.I=o}getToken(){return Promise.resolve(new n0(this.P,this.T,this.I))}start(e,t){e.enqueueRetryable(()=>t(ut.FIRST_PARTY))}shutdown(){}invalidateToken(){}}class Hh{constructor(e){this.value=e,this.type="AppCheck",this.headers=new Map,e&&e.length>0&&this.headers.set("x-firebase-appcheck",this.value)}}class r0{constructor(e,t){this.V=t,this.forceRefresh=!1,this.appCheck=null,this.m=null,this.p=null,en(e)&&e.settings.appCheckToken&&(this.p=e.settings.appCheckToken)}start(e,t){be(this.o===void 0,3512);const o=i=>{i.error!=null&&Y("FirebaseAppCheckTokenProvider",`Error getting App Check token; using placeholder token instead. Error: ${i.error.message}`);const s=i.token!==this.m;return this.m=i.token,Y("FirebaseAppCheckTokenProvider",`Received ${s?"new":"existing"} token.`),s?t(i.token):Promise.resolve()};this.o=i=>{e.enqueueRetryable(()=>o(i))};const r=i=>{Y("FirebaseAppCheckTokenProvider","AppCheck detected"),this.appCheck=i,this.o&&this.appCheck.addTokenListener(this.o)};this.V.onInit(i=>r(i)),setTimeout(()=>{if(!this.appCheck){const i=this.V.getImmediate({optional:!0});i?r(i):Y("FirebaseAppCheckTokenProvider","AppCheck not yet detected")}},0)}getToken(){if(this.p)return Promise.resolve(new Hh(this.p));const e=this.forceRefresh;return this.forceRefresh=!1,this.appCheck?this.appCheck.getToken(e).then(t=>t?(be(typeof t.token=="string",44558,{tokenResult:t}),this.m=t.token,new Hh(t.token)):null):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.appCheck&&this.o&&this.appCheck.removeTokenListener(this.o),this.o=void 0}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function i0(n){const e=typeof self<"u"&&(self.crypto||self.msCrypto),t=new Uint8Array(n);if(e&&typeof e.getRandomValues=="function")e.getRandomValues(t);else for(let o=0;o<n;o++)t[o]=Math.floor(256*Math.random());return t}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wu{static newId(){const e="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",t=62*Math.floor(4.129032258064516);let o="";for(;o.length<20;){const r=i0(40);for(let i=0;i<r.length;++i)o.length<20&&r[i]<t&&(o+=e.charAt(r[i]%62))}return o}}function he(n,e){return n<e?-1:n>e?1:0}function bc(n,e){const t=Math.min(n.length,e.length);for(let o=0;o<t;o++){const r=n.charAt(o),i=e.charAt(o);if(r!==i)return Yl(r)===Yl(i)?he(r,i):Yl(r)?1:-1}return he(n.length,e.length)}const s0=55296,a0=57343;function Yl(n){const e=n.charCodeAt(0);return e>=s0&&e<=a0}function Dr(n,e,t){return n.length===e.length&&n.every((o,r)=>t(o,e[r]))}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Gh="__name__";class Zt{constructor(e,t,o){t===void 0?t=0:t>e.length&&ee(637,{offset:t,range:e.length}),o===void 0?o=e.length-t:o>e.length-t&&ee(1746,{length:o,range:e.length-t}),this.segments=e,this.offset=t,this.len=o}get length(){return this.len}isEqual(e){return Zt.comparator(this,e)===0}child(e){const t=this.segments.slice(this.offset,this.limit());return e instanceof Zt?e.forEach(o=>{t.push(o)}):t.push(e),this.construct(t)}limit(){return this.offset+this.length}popFirst(e){return e=e===void 0?1:e,this.construct(this.segments,this.offset+e,this.length-e)}popLast(){return this.construct(this.segments,this.offset,this.length-1)}firstSegment(){return this.segments[this.offset]}lastSegment(){return this.get(this.length-1)}get(e){return this.segments[this.offset+e]}isEmpty(){return this.length===0}isPrefixOf(e){if(e.length<this.length)return!1;for(let t=0;t<this.length;t++)if(this.get(t)!==e.get(t))return!1;return!0}isImmediateParentOf(e){if(this.length+1!==e.length)return!1;for(let t=0;t<this.length;t++)if(this.get(t)!==e.get(t))return!1;return!0}forEach(e){for(let t=this.offset,o=this.limit();t<o;t++)e(this.segments[t])}toArray(){return this.segments.slice(this.offset,this.limit())}static comparator(e,t){const o=Math.min(e.length,t.length);for(let r=0;r<o;r++){const i=Zt.compareSegments(e.get(r),t.get(r));if(i!==0)return i}return he(e.length,t.length)}static compareSegments(e,t){const o=Zt.isNumericId(e),r=Zt.isNumericId(t);return o&&!r?-1:!o&&r?1:o&&r?Zt.extractNumericId(e).compare(Zt.extractNumericId(t)):bc(e,t)}static isNumericId(e){return e.startsWith("__id")&&e.endsWith("__")}static extractNumericId(e){return so.fromString(e.substring(4,e.length-2))}}class xe extends Zt{construct(e,t,o){return new xe(e,t,o)}canonicalString(){return this.toArray().join("/")}toString(){return this.canonicalString()}toUriEncodedString(){return this.toArray().map(encodeURIComponent).join("/")}static fromString(...e){const t=[];for(const o of e){if(o.indexOf("//")>=0)throw new G(F.INVALID_ARGUMENT,`Invalid segment (${o}). Paths must not contain // in them.`);t.push(...o.split("/").filter(r=>r.length>0))}return new xe(t)}static emptyPath(){return new xe([])}}const l0=/^[_a-zA-Z][_a-zA-Z0-9]*$/;class st extends Zt{construct(e,t,o){return new st(e,t,o)}static isValidIdentifier(e){return l0.test(e)}canonicalString(){return this.toArray().map(e=>(e=e.replace(/\\/g,"\\\\").replace(/`/g,"\\`"),st.isValidIdentifier(e)||(e="`"+e+"`"),e)).join(".")}toString(){return this.canonicalString()}isKeyField(){return this.length===1&&this.get(0)===Gh}static keyField(){return new st([Gh])}static fromServerFormat(e){const t=[];let o="",r=0;const i=()=>{if(o.length===0)throw new G(F.INVALID_ARGUMENT,`Invalid field path (${e}). Paths must not be empty, begin with '.', end with '.', or contain '..'`);t.push(o),o=""};let s=!1;for(;r<e.length;){const c=e[r];if(c==="\\"){if(r+1===e.length)throw new G(F.INVALID_ARGUMENT,"Path has trailing escape character: "+e);const d=e[r+1];if(d!=="\\"&&d!=="."&&d!=="`")throw new G(F.INVALID_ARGUMENT,"Path has invalid escape sequence: "+e);o+=d,r+=2}else c==="`"?(s=!s,r++):c!=="."||s?(o+=c,r++):(i(),r++)}if(i(),s)throw new G(F.INVALID_ARGUMENT,"Unterminated ` in path: "+e);return new st(t)}static emptyPath(){return new st([])}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Q{constructor(e){this.path=e}static fromPath(e){return new Q(xe.fromString(e))}static fromName(e){return new Q(xe.fromString(e).popFirst(5))}static empty(){return new Q(xe.emptyPath())}get collectionGroup(){return this.path.popLast().lastSegment()}hasCollectionId(e){return this.path.length>=2&&this.path.get(this.path.length-2)===e}getCollectionGroup(){return this.path.get(this.path.length-2)}getCollectionPath(){return this.path.popLast()}isEqual(e){return e!==null&&xe.comparator(this.path,e.path)===0}toString(){return this.path.toString()}static comparator(e,t){return xe.comparator(e.path,t.path)}static isDocumentKey(e){return e.length%2==0}static fromSegments(e){return new Q(new xe(e.slice()))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function xg(n,e,t){if(!t)throw new G(F.INVALID_ARGUMENT,`Function ${n}() cannot be called with an empty ${e}.`)}function c0(n,e,t,o){if(e===!0&&o===!0)throw new G(F.INVALID_ARGUMENT,`${n} and ${t} cannot be used together.`)}function Yh(n){if(!Q.isDocumentKey(n))throw new G(F.INVALID_ARGUMENT,`Invalid document reference. Document references must have an even number of segments, but ${n} has ${n.length}.`)}function Kh(n){if(Q.isDocumentKey(n))throw new G(F.INVALID_ARGUMENT,`Invalid collection reference. Collection references must have an odd number of segments, but ${n} has ${n.length}.`)}function Sg(n){return typeof n=="object"&&n!==null&&(Object.getPrototypeOf(n)===Object.prototype||Object.getPrototypeOf(n)===null)}function il(n){if(n===void 0)return"undefined";if(n===null)return"null";if(typeof n=="string")return n.length>20&&(n=`${n.substring(0,20)}...`),JSON.stringify(n);if(typeof n=="number"||typeof n=="boolean")return""+n;if(typeof n=="object"){if(n instanceof Array)return"an array";{const e=function(o){return o.constructor?o.constructor.name:null}(n);return e?`a custom ${e} object`:"an object"}}return typeof n=="function"?"a function":ee(12329,{type:typeof n})}function Mt(n,e){if("_delegate"in n&&(n=n._delegate),!(n instanceof e)){if(e.name===n.constructor.name)throw new G(F.INVALID_ARGUMENT,"Type does not match the expected instance. Did you pass a reference from a different Firestore SDK?");{const t=il(n);throw new G(F.INVALID_ARGUMENT,`Expected type '${e.name}', but it was: ${t}`)}}return n}function u0(n,e){if(e<=0)throw new G(F.INVALID_ARGUMENT,`Function ${n}() requires a positive number, but it was: ${e}.`)}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function We(n,e){const t={typeString:n};return e&&(t.value=e),t}function xs(n,e){if(!Sg(n))throw new G(F.INVALID_ARGUMENT,"JSON must be an object");let t;for(const o in e)if(e[o]){const r=e[o].typeString,i="value"in e[o]?{value:e[o].value}:void 0;if(!(o in n)){t=`JSON missing required field: '${o}'`;break}const s=n[o];if(r&&typeof s!==r){t=`JSON field '${o}' must be a ${r}.`;break}if(i!==void 0&&s!==i.value){t=`Expected '${o}' field to equal '${i.value}'`;break}}if(t)throw new G(F.INVALID_ARGUMENT,t);return!0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Xh=-62135596800,Qh=1e6;class Ce{static now(){return Ce.fromMillis(Date.now())}static fromDate(e){return Ce.fromMillis(e.getTime())}static fromMillis(e){const t=Math.floor(e/1e3),o=Math.floor((e-1e3*t)*Qh);return new Ce(t,o)}constructor(e,t){if(this.seconds=e,this.nanoseconds=t,t<0)throw new G(F.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+t);if(t>=1e9)throw new G(F.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+t);if(e<Xh)throw new G(F.INVALID_ARGUMENT,"Timestamp seconds out of range: "+e);if(e>=253402300800)throw new G(F.INVALID_ARGUMENT,"Timestamp seconds out of range: "+e)}toDate(){return new Date(this.toMillis())}toMillis(){return 1e3*this.seconds+this.nanoseconds/Qh}_compareTo(e){return this.seconds===e.seconds?he(this.nanoseconds,e.nanoseconds):he(this.seconds,e.seconds)}isEqual(e){return e.seconds===this.seconds&&e.nanoseconds===this.nanoseconds}toString(){return"Timestamp(seconds="+this.seconds+", nanoseconds="+this.nanoseconds+")"}toJSON(){return{type:Ce._jsonSchemaVersion,seconds:this.seconds,nanoseconds:this.nanoseconds}}static fromJSON(e){if(xs(e,Ce._jsonSchema))return new Ce(e.seconds,e.nanoseconds)}valueOf(){const e=this.seconds-Xh;return String(e).padStart(12,"0")+"."+String(this.nanoseconds).padStart(9,"0")}}Ce._jsonSchemaVersion="firestore/timestamp/1.0",Ce._jsonSchema={type:We("string",Ce._jsonSchemaVersion),seconds:We("number"),nanoseconds:We("number")};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ne{static fromTimestamp(e){return new ne(e)}static min(){return new ne(new Ce(0,0))}static max(){return new ne(new Ce(253402300799,999999999))}constructor(e){this.timestamp=e}compareTo(e){return this.timestamp._compareTo(e.timestamp)}isEqual(e){return this.timestamp.isEqual(e.timestamp)}toMicroseconds(){return 1e6*this.timestamp.seconds+this.timestamp.nanoseconds/1e3}toString(){return"SnapshotVersion("+this.timestamp.toString()+")"}toTimestamp(){return this.timestamp}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ns=-1;function d0(n,e){const t=n.toTimestamp().seconds,o=n.toTimestamp().nanoseconds+1,r=ne.fromTimestamp(o===1e9?new Ce(t+1,0):new Ce(t,o));return new ho(r,Q.empty(),e)}function h0(n){return new ho(n.readTime,n.key,ns)}class ho{constructor(e,t,o){this.readTime=e,this.documentKey=t,this.largestBatchId=o}static min(){return new ho(ne.min(),Q.empty(),ns)}static max(){return new ho(ne.max(),Q.empty(),ns)}}function f0(n,e){let t=n.readTime.compareTo(e.readTime);return t!==0?t:(t=Q.comparator(n.documentKey,e.documentKey),t!==0?t:he(n.largestBatchId,e.largestBatchId))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const p0="The current tab is not in the required state to perform this operation. It might be necessary to refresh the browser tab.";class g0{constructor(){this.onCommittedListeners=[]}addOnCommittedListener(e){this.onCommittedListeners.push(e)}raiseOnCommittedEvent(){this.onCommittedListeners.forEach(e=>e())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Xr(n){if(n.code!==F.FAILED_PRECONDITION||n.message!==p0)throw n;Y("LocalStore","Unexpectedly lost primary lease")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class U{constructor(e){this.nextCallback=null,this.catchCallback=null,this.result=void 0,this.error=void 0,this.isDone=!1,this.callbackAttached=!1,e(t=>{this.isDone=!0,this.result=t,this.nextCallback&&this.nextCallback(t)},t=>{this.isDone=!0,this.error=t,this.catchCallback&&this.catchCallback(t)})}catch(e){return this.next(void 0,e)}next(e,t){return this.callbackAttached&&ee(59440),this.callbackAttached=!0,this.isDone?this.error?this.wrapFailure(t,this.error):this.wrapSuccess(e,this.result):new U((o,r)=>{this.nextCallback=i=>{this.wrapSuccess(e,i).next(o,r)},this.catchCallback=i=>{this.wrapFailure(t,i).next(o,r)}})}toPromise(){return new Promise((e,t)=>{this.next(e,t)})}wrapUserFunction(e){try{const t=e();return t instanceof U?t:U.resolve(t)}catch(t){return U.reject(t)}}wrapSuccess(e,t){return e?this.wrapUserFunction(()=>e(t)):U.resolve(t)}wrapFailure(e,t){return e?this.wrapUserFunction(()=>e(t)):U.reject(t)}static resolve(e){return new U((t,o)=>{t(e)})}static reject(e){return new U((t,o)=>{o(e)})}static waitFor(e){return new U((t,o)=>{let r=0,i=0,s=!1;e.forEach(c=>{++r,c.next(()=>{++i,s&&i===r&&t()},d=>o(d))}),s=!0,i===r&&t()})}static or(e){let t=U.resolve(!1);for(const o of e)t=t.next(r=>r?U.resolve(r):o());return t}static forEach(e,t){const o=[];return e.forEach((r,i)=>{o.push(t.call(this,r,i))}),this.waitFor(o)}static mapArray(e,t){return new U((o,r)=>{const i=e.length,s=new Array(i);let c=0;for(let d=0;d<i;d++){const u=d;t(e[u]).next(f=>{s[u]=f,++c,c===i&&o(s)},f=>r(f))}})}static doWhile(e,t){return new U((o,r)=>{const i=()=>{e()===!0?t().next(()=>{i()},r):o()};i()})}}function m0(n){const e=n.match(/Android ([\d.]+)/i),t=e?e[1].split(".").slice(0,2).join("."):"-1";return Number(t)}function Qr(n){return n.name==="IndexedDbTransactionError"}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class sl{constructor(e,t){this.previousValue=e,t&&(t.sequenceNumberHandler=o=>this.ae(o),this.ue=o=>t.writeSequenceNumber(o))}ae(e){return this.previousValue=Math.max(e,this.previousValue),this.previousValue}next(){const e=++this.previousValue;return this.ue&&this.ue(e),e}}sl.ce=-1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const _u=-1;function al(n){return n==null}function Oa(n){return n===0&&1/n==-1/0}function y0(n){return typeof n=="number"&&Number.isInteger(n)&&!Oa(n)&&n<=Number.MAX_SAFE_INTEGER&&n>=Number.MIN_SAFE_INTEGER}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ag="";function v0(n){let e="";for(let t=0;t<n.length;t++)e.length>0&&(e=Jh(e)),e=b0(n.get(t),e);return Jh(e)}function b0(n,e){let t=e;const o=n.length;for(let r=0;r<o;r++){const i=n.charAt(r);switch(i){case"\0":t+="";break;case Ag:t+="";break;default:t+=i}}return t}function Jh(n){return n+Ag+""}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Zh(n){let e=0;for(const t in n)Object.prototype.hasOwnProperty.call(n,t)&&e++;return e}function wo(n,e){for(const t in n)Object.prototype.hasOwnProperty.call(n,t)&&e(t,n[t])}function kg(n){for(const e in n)if(Object.prototype.hasOwnProperty.call(n,e))return!1;return!0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ne{constructor(e,t){this.comparator=e,this.root=t||it.EMPTY}insert(e,t){return new Ne(this.comparator,this.root.insert(e,t,this.comparator).copy(null,null,it.BLACK,null,null))}remove(e){return new Ne(this.comparator,this.root.remove(e,this.comparator).copy(null,null,it.BLACK,null,null))}get(e){let t=this.root;for(;!t.isEmpty();){const o=this.comparator(e,t.key);if(o===0)return t.value;o<0?t=t.left:o>0&&(t=t.right)}return null}indexOf(e){let t=0,o=this.root;for(;!o.isEmpty();){const r=this.comparator(e,o.key);if(r===0)return t+o.left.size;r<0?o=o.left:(t+=o.left.size+1,o=o.right)}return-1}isEmpty(){return this.root.isEmpty()}get size(){return this.root.size}minKey(){return this.root.minKey()}maxKey(){return this.root.maxKey()}inorderTraversal(e){return this.root.inorderTraversal(e)}forEach(e){this.inorderTraversal((t,o)=>(e(t,o),!1))}toString(){const e=[];return this.inorderTraversal((t,o)=>(e.push(`${t}:${o}`),!1)),`{${e.join(", ")}}`}reverseTraversal(e){return this.root.reverseTraversal(e)}getIterator(){return new Ks(this.root,null,this.comparator,!1)}getIteratorFrom(e){return new Ks(this.root,e,this.comparator,!1)}getReverseIterator(){return new Ks(this.root,null,this.comparator,!0)}getReverseIteratorFrom(e){return new Ks(this.root,e,this.comparator,!0)}}class Ks{constructor(e,t,o,r){this.isReverse=r,this.nodeStack=[];let i=1;for(;!e.isEmpty();)if(i=t?o(e.key,t):1,t&&r&&(i*=-1),i<0)e=this.isReverse?e.left:e.right;else{if(i===0){this.nodeStack.push(e);break}this.nodeStack.push(e),e=this.isReverse?e.right:e.left}}getNext(){let e=this.nodeStack.pop();const t={key:e.key,value:e.value};if(this.isReverse)for(e=e.left;!e.isEmpty();)this.nodeStack.push(e),e=e.right;else for(e=e.right;!e.isEmpty();)this.nodeStack.push(e),e=e.left;return t}hasNext(){return this.nodeStack.length>0}peek(){if(this.nodeStack.length===0)return null;const e=this.nodeStack[this.nodeStack.length-1];return{key:e.key,value:e.value}}}class it{constructor(e,t,o,r,i){this.key=e,this.value=t,this.color=o??it.RED,this.left=r??it.EMPTY,this.right=i??it.EMPTY,this.size=this.left.size+1+this.right.size}copy(e,t,o,r,i){return new it(e??this.key,t??this.value,o??this.color,r??this.left,i??this.right)}isEmpty(){return!1}inorderTraversal(e){return this.left.inorderTraversal(e)||e(this.key,this.value)||this.right.inorderTraversal(e)}reverseTraversal(e){return this.right.reverseTraversal(e)||e(this.key,this.value)||this.left.reverseTraversal(e)}min(){return this.left.isEmpty()?this:this.left.min()}minKey(){return this.min().key}maxKey(){return this.right.isEmpty()?this.key:this.right.maxKey()}insert(e,t,o){let r=this;const i=o(e,r.key);return r=i<0?r.copy(null,null,null,r.left.insert(e,t,o),null):i===0?r.copy(null,t,null,null,null):r.copy(null,null,null,null,r.right.insert(e,t,o)),r.fixUp()}removeMin(){if(this.left.isEmpty())return it.EMPTY;let e=this;return e.left.isRed()||e.left.left.isRed()||(e=e.moveRedLeft()),e=e.copy(null,null,null,e.left.removeMin(),null),e.fixUp()}remove(e,t){let o,r=this;if(t(e,r.key)<0)r.left.isEmpty()||r.left.isRed()||r.left.left.isRed()||(r=r.moveRedLeft()),r=r.copy(null,null,null,r.left.remove(e,t),null);else{if(r.left.isRed()&&(r=r.rotateRight()),r.right.isEmpty()||r.right.isRed()||r.right.left.isRed()||(r=r.moveRedRight()),t(e,r.key)===0){if(r.right.isEmpty())return it.EMPTY;o=r.right.min(),r=r.copy(o.key,o.value,null,null,r.right.removeMin())}r=r.copy(null,null,null,null,r.right.remove(e,t))}return r.fixUp()}isRed(){return this.color}fixUp(){let e=this;return e.right.isRed()&&!e.left.isRed()&&(e=e.rotateLeft()),e.left.isRed()&&e.left.left.isRed()&&(e=e.rotateRight()),e.left.isRed()&&e.right.isRed()&&(e=e.colorFlip()),e}moveRedLeft(){let e=this.colorFlip();return e.right.left.isRed()&&(e=e.copy(null,null,null,null,e.right.rotateRight()),e=e.rotateLeft(),e=e.colorFlip()),e}moveRedRight(){let e=this.colorFlip();return e.left.left.isRed()&&(e=e.rotateRight(),e=e.colorFlip()),e}rotateLeft(){const e=this.copy(null,null,it.RED,null,this.right.left);return this.right.copy(null,null,this.color,e,null)}rotateRight(){const e=this.copy(null,null,it.RED,this.left.right,null);return this.left.copy(null,null,this.color,null,e)}colorFlip(){const e=this.left.copy(null,null,!this.left.color,null,null),t=this.right.copy(null,null,!this.right.color,null,null);return this.copy(null,null,!this.color,e,t)}checkMaxDepth(){const e=this.check();return Math.pow(2,e)<=this.size+1}check(){if(this.isRed()&&this.left.isRed())throw ee(43730,{key:this.key,value:this.value});if(this.right.isRed())throw ee(14113,{key:this.key,value:this.value});const e=this.left.check();if(e!==this.right.check())throw ee(27949);return e+(this.isRed()?0:1)}}it.EMPTY=null,it.RED=!0,it.BLACK=!1;it.EMPTY=new class{constructor(){this.size=0}get key(){throw ee(57766)}get value(){throw ee(16141)}get color(){throw ee(16727)}get left(){throw ee(29726)}get right(){throw ee(36894)}copy(e,t,o,r,i){return this}insert(e,t,o){return new it(e,t)}remove(e,t){return this}isEmpty(){return!0}inorderTraversal(e){return!1}reverseTraversal(e){return!1}minKey(){return null}maxKey(){return null}isRed(){return!1}checkMaxDepth(){return!0}check(){return 0}};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ze{constructor(e){this.comparator=e,this.data=new Ne(this.comparator)}has(e){return this.data.get(e)!==null}first(){return this.data.minKey()}last(){return this.data.maxKey()}get size(){return this.data.size}indexOf(e){return this.data.indexOf(e)}forEach(e){this.data.inorderTraversal((t,o)=>(e(t),!1))}forEachInRange(e,t){const o=this.data.getIteratorFrom(e[0]);for(;o.hasNext();){const r=o.getNext();if(this.comparator(r.key,e[1])>=0)return;t(r.key)}}forEachWhile(e,t){let o;for(o=t!==void 0?this.data.getIteratorFrom(t):this.data.getIterator();o.hasNext();)if(!e(o.getNext().key))return}firstAfterOrEqual(e){const t=this.data.getIteratorFrom(e);return t.hasNext()?t.getNext().key:null}getIterator(){return new ef(this.data.getIterator())}getIteratorFrom(e){return new ef(this.data.getIteratorFrom(e))}add(e){return this.copy(this.data.remove(e).insert(e,!0))}delete(e){return this.has(e)?this.copy(this.data.remove(e)):this}isEmpty(){return this.data.isEmpty()}unionWith(e){let t=this;return t.size<e.size&&(t=e,e=this),e.forEach(o=>{t=t.add(o)}),t}isEqual(e){if(!(e instanceof Ze)||this.size!==e.size)return!1;const t=this.data.getIterator(),o=e.data.getIterator();for(;t.hasNext();){const r=t.getNext().key,i=o.getNext().key;if(this.comparator(r,i)!==0)return!1}return!0}toArray(){const e=[];return this.forEach(t=>{e.push(t)}),e}toString(){const e=[];return this.forEach(t=>e.push(t)),"SortedSet("+e.toString()+")"}copy(e){const t=new Ze(this.comparator);return t.data=e,t}}class ef{constructor(e){this.iter=e}getNext(){return this.iter.getNext().key}hasNext(){return this.iter.hasNext()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ot{constructor(e){this.fields=e,e.sort(st.comparator)}static empty(){return new Ot([])}unionWith(e){let t=new Ze(st.comparator);for(const o of this.fields)t=t.add(o);for(const o of e)t=t.add(o);return new Ot(t.toArray())}covers(e){for(const t of this.fields)if(t.isPrefixOf(e))return!0;return!1}isEqual(e){return Dr(this.fields,e.fields,(t,o)=>t.isEqual(o))}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Cg extends Error{constructor(){super(...arguments),this.name="Base64DecodeError"}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class lt{constructor(e){this.binaryString=e}static fromBase64String(e){const t=function(r){try{return atob(r)}catch(i){throw typeof DOMException<"u"&&i instanceof DOMException?new Cg("Invalid base64 string: "+i):i}}(e);return new lt(t)}static fromUint8Array(e){const t=function(r){let i="";for(let s=0;s<r.length;++s)i+=String.fromCharCode(r[s]);return i}(e);return new lt(t)}[Symbol.iterator](){let e=0;return{next:()=>e<this.binaryString.length?{value:this.binaryString.charCodeAt(e++),done:!1}:{value:void 0,done:!0}}}toBase64(){return function(t){return btoa(t)}(this.binaryString)}toUint8Array(){return function(t){const o=new Uint8Array(t.length);for(let r=0;r<t.length;r++)o[r]=t.charCodeAt(r);return o}(this.binaryString)}approximateByteSize(){return 2*this.binaryString.length}compareTo(e){return he(this.binaryString,e.binaryString)}isEqual(e){return this.binaryString===e.binaryString}}lt.EMPTY_BYTE_STRING=new lt("");const w0=new RegExp(/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.(\d+))?Z$/);function fo(n){if(be(!!n,39018),typeof n=="string"){let e=0;const t=w0.exec(n);if(be(!!t,46558,{timestamp:n}),t[1]){let r=t[1];r=(r+"000000000").substr(0,9),e=Number(r)}const o=new Date(n);return{seconds:Math.floor(o.getTime()/1e3),nanos:e}}return{seconds:Fe(n.seconds),nanos:Fe(n.nanos)}}function Fe(n){return typeof n=="number"?n:typeof n=="string"?Number(n):0}function po(n){return typeof n=="string"?lt.fromBase64String(n):lt.fromUint8Array(n)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Pg="server_timestamp",Rg="__type__",Og="__previous_value__",Mg="__local_write_time__";function Tu(n){var t,o;return((o=(((t=n==null?void 0:n.mapValue)==null?void 0:t.fields)||{})[Rg])==null?void 0:o.stringValue)===Pg}function ll(n){const e=n.mapValue.fields[Og];return Tu(e)?ll(e):e}function os(n){const e=fo(n.mapValue.fields[Mg].timestampValue);return new Ce(e.seconds,e.nanos)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _0{constructor(e,t,o,r,i,s,c,d,u,f,g){this.databaseId=e,this.appId=t,this.persistenceKey=o,this.host=r,this.ssl=i,this.forceLongPolling=s,this.autoDetectLongPolling=c,this.longPollingOptions=d,this.useFetchStreams=u,this.isUsingEmulator=f,this.apiKey=g}}const Ma="(default)";class rs{constructor(e,t){this.projectId=e,this.database=t||Ma}static empty(){return new rs("","")}get isDefaultDatabase(){return this.database===Ma}isEqual(e){return e instanceof rs&&e.projectId===this.projectId&&e.database===this.database}}function T0(n,e){if(!Object.prototype.hasOwnProperty.apply(n.options,["projectId"]))throw new G(F.INVALID_ARGUMENT,'"projectId" not provided in firebase.initializeApp.');return new rs(n.options.projectId,e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ng="__type__",E0="__max__",Xs={mapValue:{}},Lg="__vector__",Na="value";function go(n){return"nullValue"in n?0:"booleanValue"in n?1:"integerValue"in n||"doubleValue"in n?2:"timestampValue"in n?3:"stringValue"in n?5:"bytesValue"in n?6:"referenceValue"in n?7:"geoPointValue"in n?8:"arrayValue"in n?9:"mapValue"in n?Tu(n)?4:x0(n)?9007199254740991:I0(n)?10:11:ee(28295,{value:n})}function pn(n,e){if(n===e)return!0;const t=go(n);if(t!==go(e))return!1;switch(t){case 0:case 9007199254740991:return!0;case 1:return n.booleanValue===e.booleanValue;case 4:return os(n).isEqual(os(e));case 3:return function(r,i){if(typeof r.timestampValue=="string"&&typeof i.timestampValue=="string"&&r.timestampValue.length===i.timestampValue.length)return r.timestampValue===i.timestampValue;const s=fo(r.timestampValue),c=fo(i.timestampValue);return s.seconds===c.seconds&&s.nanos===c.nanos}(n,e);case 5:return n.stringValue===e.stringValue;case 6:return function(r,i){return po(r.bytesValue).isEqual(po(i.bytesValue))}(n,e);case 7:return n.referenceValue===e.referenceValue;case 8:return function(r,i){return Fe(r.geoPointValue.latitude)===Fe(i.geoPointValue.latitude)&&Fe(r.geoPointValue.longitude)===Fe(i.geoPointValue.longitude)}(n,e);case 2:return function(r,i){if("integerValue"in r&&"integerValue"in i)return Fe(r.integerValue)===Fe(i.integerValue);if("doubleValue"in r&&"doubleValue"in i){const s=Fe(r.doubleValue),c=Fe(i.doubleValue);return s===c?Oa(s)===Oa(c):isNaN(s)&&isNaN(c)}return!1}(n,e);case 9:return Dr(n.arrayValue.values||[],e.arrayValue.values||[],pn);case 10:case 11:return function(r,i){const s=r.mapValue.fields||{},c=i.mapValue.fields||{};if(Zh(s)!==Zh(c))return!1;for(const d in s)if(s.hasOwnProperty(d)&&(c[d]===void 0||!pn(s[d],c[d])))return!1;return!0}(n,e);default:return ee(52216,{left:n})}}function is(n,e){return(n.values||[]).find(t=>pn(t,e))!==void 0}function Vr(n,e){if(n===e)return 0;const t=go(n),o=go(e);if(t!==o)return he(t,o);switch(t){case 0:case 9007199254740991:return 0;case 1:return he(n.booleanValue,e.booleanValue);case 2:return function(i,s){const c=Fe(i.integerValue||i.doubleValue),d=Fe(s.integerValue||s.doubleValue);return c<d?-1:c>d?1:c===d?0:isNaN(c)?isNaN(d)?0:-1:1}(n,e);case 3:return tf(n.timestampValue,e.timestampValue);case 4:return tf(os(n),os(e));case 5:return bc(n.stringValue,e.stringValue);case 6:return function(i,s){const c=po(i),d=po(s);return c.compareTo(d)}(n.bytesValue,e.bytesValue);case 7:return function(i,s){const c=i.split("/"),d=s.split("/");for(let u=0;u<c.length&&u<d.length;u++){const f=he(c[u],d[u]);if(f!==0)return f}return he(c.length,d.length)}(n.referenceValue,e.referenceValue);case 8:return function(i,s){const c=he(Fe(i.latitude),Fe(s.latitude));return c!==0?c:he(Fe(i.longitude),Fe(s.longitude))}(n.geoPointValue,e.geoPointValue);case 9:return nf(n.arrayValue,e.arrayValue);case 10:return function(i,s){var m,v,O,C;const c=i.fields||{},d=s.fields||{},u=(m=c[Na])==null?void 0:m.arrayValue,f=(v=d[Na])==null?void 0:v.arrayValue,g=he(((O=u==null?void 0:u.values)==null?void 0:O.length)||0,((C=f==null?void 0:f.values)==null?void 0:C.length)||0);return g!==0?g:nf(u,f)}(n.mapValue,e.mapValue);case 11:return function(i,s){if(i===Xs.mapValue&&s===Xs.mapValue)return 0;if(i===Xs.mapValue)return 1;if(s===Xs.mapValue)return-1;const c=i.fields||{},d=Object.keys(c),u=s.fields||{},f=Object.keys(u);d.sort(),f.sort();for(let g=0;g<d.length&&g<f.length;++g){const m=bc(d[g],f[g]);if(m!==0)return m;const v=Vr(c[d[g]],u[f[g]]);if(v!==0)return v}return he(d.length,f.length)}(n.mapValue,e.mapValue);default:throw ee(23264,{he:t})}}function tf(n,e){if(typeof n=="string"&&typeof e=="string"&&n.length===e.length)return he(n,e);const t=fo(n),o=fo(e),r=he(t.seconds,o.seconds);return r!==0?r:he(t.nanos,o.nanos)}function nf(n,e){const t=n.values||[],o=e.values||[];for(let r=0;r<t.length&&r<o.length;++r){const i=Vr(t[r],o[r]);if(i)return i}return he(t.length,o.length)}function Fr(n){return wc(n)}function wc(n){return"nullValue"in n?"null":"booleanValue"in n?""+n.booleanValue:"integerValue"in n?""+n.integerValue:"doubleValue"in n?""+n.doubleValue:"timestampValue"in n?function(t){const o=fo(t);return`time(${o.seconds},${o.nanos})`}(n.timestampValue):"stringValue"in n?n.stringValue:"bytesValue"in n?function(t){return po(t).toBase64()}(n.bytesValue):"referenceValue"in n?function(t){return Q.fromName(t).toString()}(n.referenceValue):"geoPointValue"in n?function(t){return`geo(${t.latitude},${t.longitude})`}(n.geoPointValue):"arrayValue"in n?function(t){let o="[",r=!0;for(const i of t.values||[])r?r=!1:o+=",",o+=wc(i);return o+"]"}(n.arrayValue):"mapValue"in n?function(t){const o=Object.keys(t.fields||{}).sort();let r="{",i=!0;for(const s of o)i?i=!1:r+=",",r+=`${s}:${wc(t.fields[s])}`;return r+"}"}(n.mapValue):ee(61005,{value:n})}function ga(n){switch(go(n)){case 0:case 1:return 4;case 2:return 8;case 3:case 8:return 16;case 4:const e=ll(n);return e?16+ga(e):16;case 5:return 2*n.stringValue.length;case 6:return po(n.bytesValue).approximateByteSize();case 7:return n.referenceValue.length;case 9:return function(o){return(o.values||[]).reduce((r,i)=>r+ga(i),0)}(n.arrayValue);case 10:case 11:return function(o){let r=0;return wo(o.fields,(i,s)=>{r+=i.length+ga(s)}),r}(n.mapValue);default:throw ee(13486,{value:n})}}function of(n,e){return{referenceValue:`projects/${n.projectId}/databases/${n.database}/documents/${e.path.canonicalString()}`}}function _c(n){return!!n&&"integerValue"in n}function Eu(n){return!!n&&"arrayValue"in n}function rf(n){return!!n&&"nullValue"in n}function sf(n){return!!n&&"doubleValue"in n&&isNaN(Number(n.doubleValue))}function ma(n){return!!n&&"mapValue"in n}function I0(n){var t,o;return((o=(((t=n==null?void 0:n.mapValue)==null?void 0:t.fields)||{})[Ng])==null?void 0:o.stringValue)===Lg}function Wi(n){if(n.geoPointValue)return{geoPointValue:{...n.geoPointValue}};if(n.timestampValue&&typeof n.timestampValue=="object")return{timestampValue:{...n.timestampValue}};if(n.mapValue){const e={mapValue:{fields:{}}};return wo(n.mapValue.fields,(t,o)=>e.mapValue.fields[t]=Wi(o)),e}if(n.arrayValue){const e={arrayValue:{values:[]}};for(let t=0;t<(n.arrayValue.values||[]).length;++t)e.arrayValue.values[t]=Wi(n.arrayValue.values[t]);return e}return{...n}}function x0(n){return(((n.mapValue||{}).fields||{}).__type__||{}).stringValue===E0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wt{constructor(e){this.value=e}static empty(){return new wt({mapValue:{}})}field(e){if(e.isEmpty())return this.value;{let t=this.value;for(let o=0;o<e.length-1;++o)if(t=(t.mapValue.fields||{})[e.get(o)],!ma(t))return null;return t=(t.mapValue.fields||{})[e.lastSegment()],t||null}}set(e,t){this.getFieldsMap(e.popLast())[e.lastSegment()]=Wi(t)}setAll(e){let t=st.emptyPath(),o={},r=[];e.forEach((s,c)=>{if(!t.isImmediateParentOf(c)){const d=this.getFieldsMap(t);this.applyChanges(d,o,r),o={},r=[],t=c.popLast()}s?o[c.lastSegment()]=Wi(s):r.push(c.lastSegment())});const i=this.getFieldsMap(t);this.applyChanges(i,o,r)}delete(e){const t=this.field(e.popLast());ma(t)&&t.mapValue.fields&&delete t.mapValue.fields[e.lastSegment()]}isEqual(e){return pn(this.value,e.value)}getFieldsMap(e){let t=this.value;t.mapValue.fields||(t.mapValue={fields:{}});for(let o=0;o<e.length;++o){let r=t.mapValue.fields[e.get(o)];ma(r)&&r.mapValue.fields||(r={mapValue:{fields:{}}},t.mapValue.fields[e.get(o)]=r),t=r}return t.mapValue.fields}applyChanges(e,t,o){wo(t,(r,i)=>e[r]=i);for(const r of o)delete e[r]}clone(){return new wt(Wi(this.value))}}function Dg(n){const e=[];return wo(n.fields,(t,o)=>{const r=new st([t]);if(ma(o)){const i=Dg(o.mapValue).fields;if(i.length===0)e.push(r);else for(const s of i)e.push(r.child(s))}else e.push(r)}),new Ot(e)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ht{constructor(e,t,o,r,i,s,c){this.key=e,this.documentType=t,this.version=o,this.readTime=r,this.createTime=i,this.data=s,this.documentState=c}static newInvalidDocument(e){return new ht(e,0,ne.min(),ne.min(),ne.min(),wt.empty(),0)}static newFoundDocument(e,t,o,r){return new ht(e,1,t,ne.min(),o,r,0)}static newNoDocument(e,t){return new ht(e,2,t,ne.min(),ne.min(),wt.empty(),0)}static newUnknownDocument(e,t){return new ht(e,3,t,ne.min(),ne.min(),wt.empty(),2)}convertToFoundDocument(e,t){return!this.createTime.isEqual(ne.min())||this.documentType!==2&&this.documentType!==0||(this.createTime=e),this.version=e,this.documentType=1,this.data=t,this.documentState=0,this}convertToNoDocument(e){return this.version=e,this.documentType=2,this.data=wt.empty(),this.documentState=0,this}convertToUnknownDocument(e){return this.version=e,this.documentType=3,this.data=wt.empty(),this.documentState=2,this}setHasCommittedMutations(){return this.documentState=2,this}setHasLocalMutations(){return this.documentState=1,this.version=ne.min(),this}setReadTime(e){return this.readTime=e,this}get hasLocalMutations(){return this.documentState===1}get hasCommittedMutations(){return this.documentState===2}get hasPendingWrites(){return this.hasLocalMutations||this.hasCommittedMutations}isValidDocument(){return this.documentType!==0}isFoundDocument(){return this.documentType===1}isNoDocument(){return this.documentType===2}isUnknownDocument(){return this.documentType===3}isEqual(e){return e instanceof ht&&this.key.isEqual(e.key)&&this.version.isEqual(e.version)&&this.documentType===e.documentType&&this.documentState===e.documentState&&this.data.isEqual(e.data)}mutableCopy(){return new ht(this.key,this.documentType,this.version,this.readTime,this.createTime,this.data.clone(),this.documentState)}toString(){return`Document(${this.key}, ${this.version}, ${JSON.stringify(this.data.value)}, {createTime: ${this.createTime}}), {documentType: ${this.documentType}}), {documentState: ${this.documentState}})`}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class La{constructor(e,t){this.position=e,this.inclusive=t}}function af(n,e,t){let o=0;for(let r=0;r<n.position.length;r++){const i=e[r],s=n.position[r];if(i.field.isKeyField()?o=Q.comparator(Q.fromName(s.referenceValue),t.key):o=Vr(s,t.data.field(i.field)),i.dir==="desc"&&(o*=-1),o!==0)break}return o}function lf(n,e){if(n===null)return e===null;if(e===null||n.inclusive!==e.inclusive||n.position.length!==e.position.length)return!1;for(let t=0;t<n.position.length;t++)if(!pn(n.position[t],e.position[t]))return!1;return!0}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ss{constructor(e,t="asc"){this.field=e,this.dir=t}}function S0(n,e){return n.dir===e.dir&&n.field.isEqual(e.field)}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Vg{}class je extends Vg{constructor(e,t,o){super(),this.field=e,this.op=t,this.value=o}static create(e,t,o){return e.isKeyField()?t==="in"||t==="not-in"?this.createKeyFieldInFilter(e,t,o):new k0(e,t,o):t==="array-contains"?new R0(e,o):t==="in"?new O0(e,o):t==="not-in"?new M0(e,o):t==="array-contains-any"?new N0(e,o):new je(e,t,o)}static createKeyFieldInFilter(e,t,o){return t==="in"?new C0(e,o):new P0(e,o)}matches(e){const t=e.data.field(this.field);return this.op==="!="?t!==null&&t.nullValue===void 0&&this.matchesComparison(Vr(t,this.value)):t!==null&&go(this.value)===go(t)&&this.matchesComparison(Vr(t,this.value))}matchesComparison(e){switch(this.op){case"<":return e<0;case"<=":return e<=0;case"==":return e===0;case"!=":return e!==0;case">":return e>0;case">=":return e>=0;default:return ee(47266,{operator:this.op})}}isInequality(){return["<","<=",">",">=","!=","not-in"].indexOf(this.op)>=0}getFlattenedFilters(){return[this]}getFilters(){return[this]}}class Gt extends Vg{constructor(e,t){super(),this.filters=e,this.op=t,this.Pe=null}static create(e,t){return new Gt(e,t)}matches(e){return Fg(this)?this.filters.find(t=>!t.matches(e))===void 0:this.filters.find(t=>t.matches(e))!==void 0}getFlattenedFilters(){return this.Pe!==null||(this.Pe=this.filters.reduce((e,t)=>e.concat(t.getFlattenedFilters()),[])),this.Pe}getFilters(){return Object.assign([],this.filters)}}function Fg(n){return n.op==="and"}function Ug(n){return A0(n)&&Fg(n)}function A0(n){for(const e of n.filters)if(e instanceof Gt)return!1;return!0}function Tc(n){if(n instanceof je)return n.field.canonicalString()+n.op.toString()+Fr(n.value);if(Ug(n))return n.filters.map(e=>Tc(e)).join(",");{const e=n.filters.map(t=>Tc(t)).join(",");return`${n.op}(${e})`}}function qg(n,e){return n instanceof je?function(o,r){return r instanceof je&&o.op===r.op&&o.field.isEqual(r.field)&&pn(o.value,r.value)}(n,e):n instanceof Gt?function(o,r){return r instanceof Gt&&o.op===r.op&&o.filters.length===r.filters.length?o.filters.reduce((i,s,c)=>i&&qg(s,r.filters[c]),!0):!1}(n,e):void ee(19439)}function zg(n){return n instanceof je?function(t){return`${t.field.canonicalString()} ${t.op} ${Fr(t.value)}`}(n):n instanceof Gt?function(t){return t.op.toString()+" {"+t.getFilters().map(zg).join(" ,")+"}"}(n):"Filter"}class k0 extends je{constructor(e,t,o){super(e,t,o),this.key=Q.fromName(o.referenceValue)}matches(e){const t=Q.comparator(e.key,this.key);return this.matchesComparison(t)}}class C0 extends je{constructor(e,t){super(e,"in",t),this.keys=Bg("in",t)}matches(e){return this.keys.some(t=>t.isEqual(e.key))}}class P0 extends je{constructor(e,t){super(e,"not-in",t),this.keys=Bg("not-in",t)}matches(e){return!this.keys.some(t=>t.isEqual(e.key))}}function Bg(n,e){var t;return(((t=e.arrayValue)==null?void 0:t.values)||[]).map(o=>Q.fromName(o.referenceValue))}class R0 extends je{constructor(e,t){super(e,"array-contains",t)}matches(e){const t=e.data.field(this.field);return Eu(t)&&is(t.arrayValue,this.value)}}class O0 extends je{constructor(e,t){super(e,"in",t)}matches(e){const t=e.data.field(this.field);return t!==null&&is(this.value.arrayValue,t)}}class M0 extends je{constructor(e,t){super(e,"not-in",t)}matches(e){if(is(this.value.arrayValue,{nullValue:"NULL_VALUE"}))return!1;const t=e.data.field(this.field);return t!==null&&t.nullValue===void 0&&!is(this.value.arrayValue,t)}}class N0 extends je{constructor(e,t){super(e,"array-contains-any",t)}matches(e){const t=e.data.field(this.field);return!(!Eu(t)||!t.arrayValue.values)&&t.arrayValue.values.some(o=>is(this.value.arrayValue,o))}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class L0{constructor(e,t=null,o=[],r=[],i=null,s=null,c=null){this.path=e,this.collectionGroup=t,this.orderBy=o,this.filters=r,this.limit=i,this.startAt=s,this.endAt=c,this.Te=null}}function cf(n,e=null,t=[],o=[],r=null,i=null,s=null){return new L0(n,e,t,o,r,i,s)}function Iu(n){const e=oe(n);if(e.Te===null){let t=e.path.canonicalString();e.collectionGroup!==null&&(t+="|cg:"+e.collectionGroup),t+="|f:",t+=e.filters.map(o=>Tc(o)).join(","),t+="|ob:",t+=e.orderBy.map(o=>function(i){return i.field.canonicalString()+i.dir}(o)).join(","),al(e.limit)||(t+="|l:",t+=e.limit),e.startAt&&(t+="|lb:",t+=e.startAt.inclusive?"b:":"a:",t+=e.startAt.position.map(o=>Fr(o)).join(",")),e.endAt&&(t+="|ub:",t+=e.endAt.inclusive?"a:":"b:",t+=e.endAt.position.map(o=>Fr(o)).join(",")),e.Te=t}return e.Te}function xu(n,e){if(n.limit!==e.limit||n.orderBy.length!==e.orderBy.length)return!1;for(let t=0;t<n.orderBy.length;t++)if(!S0(n.orderBy[t],e.orderBy[t]))return!1;if(n.filters.length!==e.filters.length)return!1;for(let t=0;t<n.filters.length;t++)if(!qg(n.filters[t],e.filters[t]))return!1;return n.collectionGroup===e.collectionGroup&&!!n.path.isEqual(e.path)&&!!lf(n.startAt,e.startAt)&&lf(n.endAt,e.endAt)}function Ec(n){return Q.isDocumentKey(n.path)&&n.collectionGroup===null&&n.filters.length===0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Jr{constructor(e,t=null,o=[],r=[],i=null,s="F",c=null,d=null){this.path=e,this.collectionGroup=t,this.explicitOrderBy=o,this.filters=r,this.limit=i,this.limitType=s,this.startAt=c,this.endAt=d,this.Ee=null,this.Ie=null,this.Re=null,this.startAt,this.endAt}}function D0(n,e,t,o,r,i,s,c){return new Jr(n,e,t,o,r,i,s,c)}function cl(n){return new Jr(n)}function uf(n){return n.filters.length===0&&n.limit===null&&n.startAt==null&&n.endAt==null&&(n.explicitOrderBy.length===0||n.explicitOrderBy.length===1&&n.explicitOrderBy[0].field.isKeyField())}function V0(n){return Q.isDocumentKey(n.path)&&n.collectionGroup===null&&n.filters.length===0}function $g(n){return n.collectionGroup!==null}function Hi(n){const e=oe(n);if(e.Ee===null){e.Ee=[];const t=new Set;for(const i of e.explicitOrderBy)e.Ee.push(i),t.add(i.field.canonicalString());const o=e.explicitOrderBy.length>0?e.explicitOrderBy[e.explicitOrderBy.length-1].dir:"asc";(function(s){let c=new Ze(st.comparator);return s.filters.forEach(d=>{d.getFlattenedFilters().forEach(u=>{u.isInequality()&&(c=c.add(u.field))})}),c})(e).forEach(i=>{t.has(i.canonicalString())||i.isKeyField()||e.Ee.push(new ss(i,o))}),t.has(st.keyField().canonicalString())||e.Ee.push(new ss(st.keyField(),o))}return e.Ee}function un(n){const e=oe(n);return e.Ie||(e.Ie=F0(e,Hi(n))),e.Ie}function F0(n,e){if(n.limitType==="F")return cf(n.path,n.collectionGroup,e,n.filters,n.limit,n.startAt,n.endAt);{e=e.map(r=>{const i=r.dir==="desc"?"asc":"desc";return new ss(r.field,i)});const t=n.endAt?new La(n.endAt.position,n.endAt.inclusive):null,o=n.startAt?new La(n.startAt.position,n.startAt.inclusive):null;return cf(n.path,n.collectionGroup,e,n.filters,n.limit,t,o)}}function Ic(n,e){const t=n.filters.concat([e]);return new Jr(n.path,n.collectionGroup,n.explicitOrderBy.slice(),t,n.limit,n.limitType,n.startAt,n.endAt)}function U0(n,e){const t=n.explicitOrderBy.concat([e]);return new Jr(n.path,n.collectionGroup,t,n.filters.slice(),n.limit,n.limitType,n.startAt,n.endAt)}function Da(n,e,t){return new Jr(n.path,n.collectionGroup,n.explicitOrderBy.slice(),n.filters.slice(),e,t,n.startAt,n.endAt)}function ul(n,e){return xu(un(n),un(e))&&n.limitType===e.limitType}function jg(n){return`${Iu(un(n))}|lt:${n.limitType}`}function hr(n){return`Query(target=${function(t){let o=t.path.canonicalString();return t.collectionGroup!==null&&(o+=" collectionGroup="+t.collectionGroup),t.filters.length>0&&(o+=`, filters: [${t.filters.map(r=>zg(r)).join(", ")}]`),al(t.limit)||(o+=", limit: "+t.limit),t.orderBy.length>0&&(o+=`, orderBy: [${t.orderBy.map(r=>function(s){return`${s.field.canonicalString()} (${s.dir})`}(r)).join(", ")}]`),t.startAt&&(o+=", startAt: ",o+=t.startAt.inclusive?"b:":"a:",o+=t.startAt.position.map(r=>Fr(r)).join(",")),t.endAt&&(o+=", endAt: ",o+=t.endAt.inclusive?"a:":"b:",o+=t.endAt.position.map(r=>Fr(r)).join(",")),`Target(${o})`}(un(n))}; limitType=${n.limitType})`}function dl(n,e){return e.isFoundDocument()&&function(o,r){const i=r.key.path;return o.collectionGroup!==null?r.key.hasCollectionId(o.collectionGroup)&&o.path.isPrefixOf(i):Q.isDocumentKey(o.path)?o.path.isEqual(i):o.path.isImmediateParentOf(i)}(n,e)&&function(o,r){for(const i of Hi(o))if(!i.field.isKeyField()&&r.data.field(i.field)===null)return!1;return!0}(n,e)&&function(o,r){for(const i of o.filters)if(!i.matches(r))return!1;return!0}(n,e)&&function(o,r){return!(o.startAt&&!function(s,c,d){const u=af(s,c,d);return s.inclusive?u<=0:u<0}(o.startAt,Hi(o),r)||o.endAt&&!function(s,c,d){const u=af(s,c,d);return s.inclusive?u>=0:u>0}(o.endAt,Hi(o),r))}(n,e)}function q0(n){return n.collectionGroup||(n.path.length%2==1?n.path.lastSegment():n.path.get(n.path.length-2))}function Wg(n){return(e,t)=>{let o=!1;for(const r of Hi(n)){const i=z0(r,e,t);if(i!==0)return i;o=o||r.field.isKeyField()}return 0}}function z0(n,e,t){const o=n.field.isKeyField()?Q.comparator(e.key,t.key):function(i,s,c){const d=s.data.field(i),u=c.data.field(i);return d!==null&&u!==null?Vr(d,u):ee(42886)}(n.field,e,t);switch(n.dir){case"asc":return o;case"desc":return-1*o;default:return ee(19790,{direction:n.dir})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class tr{constructor(e,t){this.mapKeyFn=e,this.equalsFn=t,this.inner={},this.innerSize=0}get(e){const t=this.mapKeyFn(e),o=this.inner[t];if(o!==void 0){for(const[r,i]of o)if(this.equalsFn(r,e))return i}}has(e){return this.get(e)!==void 0}set(e,t){const o=this.mapKeyFn(e),r=this.inner[o];if(r===void 0)return this.inner[o]=[[e,t]],void this.innerSize++;for(let i=0;i<r.length;i++)if(this.equalsFn(r[i][0],e))return void(r[i]=[e,t]);r.push([e,t]),this.innerSize++}delete(e){const t=this.mapKeyFn(e),o=this.inner[t];if(o===void 0)return!1;for(let r=0;r<o.length;r++)if(this.equalsFn(o[r][0],e))return o.length===1?delete this.inner[t]:o.splice(r,1),this.innerSize--,!0;return!1}forEach(e){wo(this.inner,(t,o)=>{for(const[r,i]of o)e(r,i)})}isEmpty(){return kg(this.inner)}size(){return this.innerSize}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const B0=new Ne(Q.comparator);function Vn(){return B0}const Hg=new Ne(Q.comparator);function Ni(...n){let e=Hg;for(const t of n)e=e.insert(t.key,t);return e}function Gg(n){let e=Hg;return n.forEach((t,o)=>e=e.insert(t,o.overlayedDocument)),e}function Mo(){return Gi()}function Yg(){return Gi()}function Gi(){return new tr(n=>n.toString(),(n,e)=>n.isEqual(e))}const $0=new Ne(Q.comparator),j0=new Ze(Q.comparator);function fe(...n){let e=j0;for(const t of n)e=e.add(t);return e}const W0=new Ze(he);function H0(){return W0}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Su(n,e){if(n.useProto3Json){if(isNaN(e))return{doubleValue:"NaN"};if(e===1/0)return{doubleValue:"Infinity"};if(e===-1/0)return{doubleValue:"-Infinity"}}return{doubleValue:Oa(e)?"-0":e}}function Kg(n){return{integerValue:""+n}}function Xg(n,e){return y0(e)?Kg(e):Su(n,e)}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class hl{constructor(){this._=void 0}}function G0(n,e,t){return n instanceof as?function(r,i){const s={fields:{[Rg]:{stringValue:Pg},[Mg]:{timestampValue:{seconds:r.seconds,nanos:r.nanoseconds}}}};return i&&Tu(i)&&(i=ll(i)),i&&(s.fields[Og]=i),{mapValue:s}}(t,e):n instanceof ls?Jg(n,e):n instanceof cs?Zg(n,e):function(r,i){const s=Qg(r,i),c=df(s)+df(r.Ae);return _c(s)&&_c(r.Ae)?Kg(c):Su(r.serializer,c)}(n,e)}function Y0(n,e,t){return n instanceof ls?Jg(n,e):n instanceof cs?Zg(n,e):t}function Qg(n,e){return n instanceof us?function(o){return _c(o)||function(i){return!!i&&"doubleValue"in i}(o)}(e)?e:{integerValue:0}:null}class as extends hl{}class ls extends hl{constructor(e){super(),this.elements=e}}function Jg(n,e){const t=em(e);for(const o of n.elements)t.some(r=>pn(r,o))||t.push(o);return{arrayValue:{values:t}}}class cs extends hl{constructor(e){super(),this.elements=e}}function Zg(n,e){let t=em(e);for(const o of n.elements)t=t.filter(r=>!pn(r,o));return{arrayValue:{values:t}}}class us extends hl{constructor(e,t){super(),this.serializer=e,this.Ae=t}}function df(n){return Fe(n.integerValue||n.doubleValue)}function em(n){return Eu(n)&&n.arrayValue.values?n.arrayValue.values.slice():[]}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class tm{constructor(e,t){this.field=e,this.transform=t}}function K0(n,e){return n.field.isEqual(e.field)&&function(o,r){return o instanceof ls&&r instanceof ls||o instanceof cs&&r instanceof cs?Dr(o.elements,r.elements,pn):o instanceof us&&r instanceof us?pn(o.Ae,r.Ae):o instanceof as&&r instanceof as}(n.transform,e.transform)}class X0{constructor(e,t){this.version=e,this.transformResults=t}}class $t{constructor(e,t){this.updateTime=e,this.exists=t}static none(){return new $t}static exists(e){return new $t(void 0,e)}static updateTime(e){return new $t(e)}get isNone(){return this.updateTime===void 0&&this.exists===void 0}isEqual(e){return this.exists===e.exists&&(this.updateTime?!!e.updateTime&&this.updateTime.isEqual(e.updateTime):!e.updateTime)}}function ya(n,e){return n.updateTime!==void 0?e.isFoundDocument()&&e.version.isEqual(n.updateTime):n.exists===void 0||n.exists===e.isFoundDocument()}class fl{}function nm(n,e){if(!n.hasLocalMutations||e&&e.fields.length===0)return null;if(e===null)return n.isNoDocument()?new Au(n.key,$t.none()):new Ss(n.key,n.data,$t.none());{const t=n.data,o=wt.empty();let r=new Ze(st.comparator);for(let i of e.fields)if(!r.has(i)){let s=t.field(i);s===null&&i.length>1&&(i=i.popLast(),s=t.field(i)),s===null?o.delete(i):o.set(i,s),r=r.add(i)}return new _o(n.key,o,new Ot(r.toArray()),$t.none())}}function Q0(n,e,t){n instanceof Ss?function(r,i,s){const c=r.value.clone(),d=ff(r.fieldTransforms,i,s.transformResults);c.setAll(d),i.convertToFoundDocument(s.version,c).setHasCommittedMutations()}(n,e,t):n instanceof _o?function(r,i,s){if(!ya(r.precondition,i))return void i.convertToUnknownDocument(s.version);const c=ff(r.fieldTransforms,i,s.transformResults),d=i.data;d.setAll(om(r)),d.setAll(c),i.convertToFoundDocument(s.version,d).setHasCommittedMutations()}(n,e,t):function(r,i,s){i.convertToNoDocument(s.version).setHasCommittedMutations()}(0,e,t)}function Yi(n,e,t,o){return n instanceof Ss?function(i,s,c,d){if(!ya(i.precondition,s))return c;const u=i.value.clone(),f=pf(i.fieldTransforms,d,s);return u.setAll(f),s.convertToFoundDocument(s.version,u).setHasLocalMutations(),null}(n,e,t,o):n instanceof _o?function(i,s,c,d){if(!ya(i.precondition,s))return c;const u=pf(i.fieldTransforms,d,s),f=s.data;return f.setAll(om(i)),f.setAll(u),s.convertToFoundDocument(s.version,f).setHasLocalMutations(),c===null?null:c.unionWith(i.fieldMask.fields).unionWith(i.fieldTransforms.map(g=>g.field))}(n,e,t,o):function(i,s,c){return ya(i.precondition,s)?(s.convertToNoDocument(s.version).setHasLocalMutations(),null):c}(n,e,t)}function J0(n,e){let t=null;for(const o of n.fieldTransforms){const r=e.data.field(o.field),i=Qg(o.transform,r||null);i!=null&&(t===null&&(t=wt.empty()),t.set(o.field,i))}return t||null}function hf(n,e){return n.type===e.type&&!!n.key.isEqual(e.key)&&!!n.precondition.isEqual(e.precondition)&&!!function(o,r){return o===void 0&&r===void 0||!(!o||!r)&&Dr(o,r,(i,s)=>K0(i,s))}(n.fieldTransforms,e.fieldTransforms)&&(n.type===0?n.value.isEqual(e.value):n.type!==1||n.data.isEqual(e.data)&&n.fieldMask.isEqual(e.fieldMask))}class Ss extends fl{constructor(e,t,o,r=[]){super(),this.key=e,this.value=t,this.precondition=o,this.fieldTransforms=r,this.type=0}getFieldMask(){return null}}class _o extends fl{constructor(e,t,o,r,i=[]){super(),this.key=e,this.data=t,this.fieldMask=o,this.precondition=r,this.fieldTransforms=i,this.type=1}getFieldMask(){return this.fieldMask}}function om(n){const e=new Map;return n.fieldMask.fields.forEach(t=>{if(!t.isEmpty()){const o=n.data.field(t);e.set(t,o)}}),e}function ff(n,e,t){const o=new Map;be(n.length===t.length,32656,{Ve:t.length,de:n.length});for(let r=0;r<t.length;r++){const i=n[r],s=i.transform,c=e.data.field(i.field);o.set(i.field,Y0(s,c,t[r]))}return o}function pf(n,e,t){const o=new Map;for(const r of n){const i=r.transform,s=t.data.field(r.field);o.set(r.field,G0(i,s,e))}return o}class Au extends fl{constructor(e,t){super(),this.key=e,this.precondition=t,this.type=2,this.fieldTransforms=[]}getFieldMask(){return null}}class Z0 extends fl{constructor(e,t){super(),this.key=e,this.precondition=t,this.type=3,this.fieldTransforms=[]}getFieldMask(){return null}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class eT{constructor(e,t,o,r){this.batchId=e,this.localWriteTime=t,this.baseMutations=o,this.mutations=r}applyToRemoteDocument(e,t){const o=t.mutationResults;for(let r=0;r<this.mutations.length;r++){const i=this.mutations[r];i.key.isEqual(e.key)&&Q0(i,e,o[r])}}applyToLocalView(e,t){for(const o of this.baseMutations)o.key.isEqual(e.key)&&(t=Yi(o,e,t,this.localWriteTime));for(const o of this.mutations)o.key.isEqual(e.key)&&(t=Yi(o,e,t,this.localWriteTime));return t}applyToLocalDocumentSet(e,t){const o=Yg();return this.mutations.forEach(r=>{const i=e.get(r.key),s=i.overlayedDocument;let c=this.applyToLocalView(s,i.mutatedFields);c=t.has(r.key)?null:c;const d=nm(s,c);d!==null&&o.set(r.key,d),s.isValidDocument()||s.convertToNoDocument(ne.min())}),o}keys(){return this.mutations.reduce((e,t)=>e.add(t.key),fe())}isEqual(e){return this.batchId===e.batchId&&Dr(this.mutations,e.mutations,(t,o)=>hf(t,o))&&Dr(this.baseMutations,e.baseMutations,(t,o)=>hf(t,o))}}class ku{constructor(e,t,o,r){this.batch=e,this.commitVersion=t,this.mutationResults=o,this.docVersions=r}static from(e,t,o){be(e.mutations.length===o.length,58842,{me:e.mutations.length,fe:o.length});let r=function(){return $0}();const i=e.mutations;for(let s=0;s<i.length;s++)r=r.insert(i[s].key,o[s].version);return new ku(e,t,o,r)}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class tT{constructor(e,t){this.largestBatchId=e,this.mutation=t}getKey(){return this.mutation.key}isEqual(e){return e!==null&&this.mutation===e.mutation}toString(){return`Overlay{
      largestBatchId: ${this.largestBatchId},
      mutation: ${this.mutation.toString()}
    }`}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class nT{constructor(e,t){this.count=e,this.unchangedNames=t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var qe,pe;function oT(n){switch(n){case F.OK:return ee(64938);case F.CANCELLED:case F.UNKNOWN:case F.DEADLINE_EXCEEDED:case F.RESOURCE_EXHAUSTED:case F.INTERNAL:case F.UNAVAILABLE:case F.UNAUTHENTICATED:return!1;case F.INVALID_ARGUMENT:case F.NOT_FOUND:case F.ALREADY_EXISTS:case F.PERMISSION_DENIED:case F.FAILED_PRECONDITION:case F.ABORTED:case F.OUT_OF_RANGE:case F.UNIMPLEMENTED:case F.DATA_LOSS:return!0;default:return ee(15467,{code:n})}}function rm(n){if(n===void 0)return Dn("GRPC error has no .code"),F.UNKNOWN;switch(n){case qe.OK:return F.OK;case qe.CANCELLED:return F.CANCELLED;case qe.UNKNOWN:return F.UNKNOWN;case qe.DEADLINE_EXCEEDED:return F.DEADLINE_EXCEEDED;case qe.RESOURCE_EXHAUSTED:return F.RESOURCE_EXHAUSTED;case qe.INTERNAL:return F.INTERNAL;case qe.UNAVAILABLE:return F.UNAVAILABLE;case qe.UNAUTHENTICATED:return F.UNAUTHENTICATED;case qe.INVALID_ARGUMENT:return F.INVALID_ARGUMENT;case qe.NOT_FOUND:return F.NOT_FOUND;case qe.ALREADY_EXISTS:return F.ALREADY_EXISTS;case qe.PERMISSION_DENIED:return F.PERMISSION_DENIED;case qe.FAILED_PRECONDITION:return F.FAILED_PRECONDITION;case qe.ABORTED:return F.ABORTED;case qe.OUT_OF_RANGE:return F.OUT_OF_RANGE;case qe.UNIMPLEMENTED:return F.UNIMPLEMENTED;case qe.DATA_LOSS:return F.DATA_LOSS;default:return ee(39323,{code:n})}}(pe=qe||(qe={}))[pe.OK=0]="OK",pe[pe.CANCELLED=1]="CANCELLED",pe[pe.UNKNOWN=2]="UNKNOWN",pe[pe.INVALID_ARGUMENT=3]="INVALID_ARGUMENT",pe[pe.DEADLINE_EXCEEDED=4]="DEADLINE_EXCEEDED",pe[pe.NOT_FOUND=5]="NOT_FOUND",pe[pe.ALREADY_EXISTS=6]="ALREADY_EXISTS",pe[pe.PERMISSION_DENIED=7]="PERMISSION_DENIED",pe[pe.UNAUTHENTICATED=16]="UNAUTHENTICATED",pe[pe.RESOURCE_EXHAUSTED=8]="RESOURCE_EXHAUSTED",pe[pe.FAILED_PRECONDITION=9]="FAILED_PRECONDITION",pe[pe.ABORTED=10]="ABORTED",pe[pe.OUT_OF_RANGE=11]="OUT_OF_RANGE",pe[pe.UNIMPLEMENTED=12]="UNIMPLEMENTED",pe[pe.INTERNAL=13]="INTERNAL",pe[pe.UNAVAILABLE=14]="UNAVAILABLE",pe[pe.DATA_LOSS=15]="DATA_LOSS";/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function rT(){return new TextEncoder}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const iT=new so([4294967295,4294967295],0);function gf(n){const e=rT().encode(n),t=new yg;return t.update(e),new Uint8Array(t.digest())}function mf(n){const e=new DataView(n.buffer),t=e.getUint32(0,!0),o=e.getUint32(4,!0),r=e.getUint32(8,!0),i=e.getUint32(12,!0);return[new so([t,o],0),new so([r,i],0)]}class Cu{constructor(e,t,o){if(this.bitmap=e,this.padding=t,this.hashCount=o,t<0||t>=8)throw new Li(`Invalid padding: ${t}`);if(o<0)throw new Li(`Invalid hash count: ${o}`);if(e.length>0&&this.hashCount===0)throw new Li(`Invalid hash count: ${o}`);if(e.length===0&&t!==0)throw new Li(`Invalid padding when bitmap length is 0: ${t}`);this.ge=8*e.length-t,this.pe=so.fromNumber(this.ge)}ye(e,t,o){let r=e.add(t.multiply(so.fromNumber(o)));return r.compare(iT)===1&&(r=new so([r.getBits(0),r.getBits(1)],0)),r.modulo(this.pe).toNumber()}we(e){return!!(this.bitmap[Math.floor(e/8)]&1<<e%8)}mightContain(e){if(this.ge===0)return!1;const t=gf(e),[o,r]=mf(t);for(let i=0;i<this.hashCount;i++){const s=this.ye(o,r,i);if(!this.we(s))return!1}return!0}static create(e,t,o){const r=e%8==0?0:8-e%8,i=new Uint8Array(Math.ceil(e/8)),s=new Cu(i,r,t);return o.forEach(c=>s.insert(c)),s}insert(e){if(this.ge===0)return;const t=gf(e),[o,r]=mf(t);for(let i=0;i<this.hashCount;i++){const s=this.ye(o,r,i);this.Se(s)}}Se(e){const t=Math.floor(e/8),o=e%8;this.bitmap[t]|=1<<o}}class Li extends Error{constructor(){super(...arguments),this.name="BloomFilterError"}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class pl{constructor(e,t,o,r,i){this.snapshotVersion=e,this.targetChanges=t,this.targetMismatches=o,this.documentUpdates=r,this.resolvedLimboDocuments=i}static createSynthesizedRemoteEventForCurrentChange(e,t,o){const r=new Map;return r.set(e,As.createSynthesizedTargetChangeForCurrentChange(e,t,o)),new pl(ne.min(),r,new Ne(he),Vn(),fe())}}class As{constructor(e,t,o,r,i){this.resumeToken=e,this.current=t,this.addedDocuments=o,this.modifiedDocuments=r,this.removedDocuments=i}static createSynthesizedTargetChangeForCurrentChange(e,t,o){return new As(o,t,fe(),fe(),fe())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class va{constructor(e,t,o,r){this.be=e,this.removedTargetIds=t,this.key=o,this.De=r}}class im{constructor(e,t){this.targetId=e,this.Ce=t}}class sm{constructor(e,t,o=lt.EMPTY_BYTE_STRING,r=null){this.state=e,this.targetIds=t,this.resumeToken=o,this.cause=r}}class yf{constructor(){this.ve=0,this.Fe=vf(),this.Me=lt.EMPTY_BYTE_STRING,this.xe=!1,this.Oe=!0}get current(){return this.xe}get resumeToken(){return this.Me}get Ne(){return this.ve!==0}get Be(){return this.Oe}Le(e){e.approximateByteSize()>0&&(this.Oe=!0,this.Me=e)}ke(){let e=fe(),t=fe(),o=fe();return this.Fe.forEach((r,i)=>{switch(i){case 0:e=e.add(r);break;case 2:t=t.add(r);break;case 1:o=o.add(r);break;default:ee(38017,{changeType:i})}}),new As(this.Me,this.xe,e,t,o)}qe(){this.Oe=!1,this.Fe=vf()}Ke(e,t){this.Oe=!0,this.Fe=this.Fe.insert(e,t)}Ue(e){this.Oe=!0,this.Fe=this.Fe.remove(e)}$e(){this.ve+=1}We(){this.ve-=1,be(this.ve>=0,3241,{ve:this.ve})}Qe(){this.Oe=!0,this.xe=!0}}class sT{constructor(e){this.Ge=e,this.ze=new Map,this.je=Vn(),this.Je=Qs(),this.He=Qs(),this.Ze=new Ne(he)}Xe(e){for(const t of e.be)e.De&&e.De.isFoundDocument()?this.Ye(t,e.De):this.et(t,e.key,e.De);for(const t of e.removedTargetIds)this.et(t,e.key,e.De)}tt(e){this.forEachTarget(e,t=>{const o=this.nt(t);switch(e.state){case 0:this.rt(t)&&o.Le(e.resumeToken);break;case 1:o.We(),o.Ne||o.qe(),o.Le(e.resumeToken);break;case 2:o.We(),o.Ne||this.removeTarget(t);break;case 3:this.rt(t)&&(o.Qe(),o.Le(e.resumeToken));break;case 4:this.rt(t)&&(this.it(t),o.Le(e.resumeToken));break;default:ee(56790,{state:e.state})}})}forEachTarget(e,t){e.targetIds.length>0?e.targetIds.forEach(t):this.ze.forEach((o,r)=>{this.rt(r)&&t(r)})}st(e){const t=e.targetId,o=e.Ce.count,r=this.ot(t);if(r){const i=r.target;if(Ec(i))if(o===0){const s=new Q(i.path);this.et(t,s,ht.newNoDocument(s,ne.min()))}else be(o===1,20013,{expectedCount:o});else{const s=this._t(t);if(s!==o){const c=this.ut(e),d=c?this.ct(c,e,s):1;if(d!==0){this.it(t);const u=d===2?"TargetPurposeExistenceFilterMismatchBloom":"TargetPurposeExistenceFilterMismatch";this.Ze=this.Ze.insert(t,u)}}}}}ut(e){const t=e.Ce.unchangedNames;if(!t||!t.bits)return null;const{bits:{bitmap:o="",padding:r=0},hashCount:i=0}=t;let s,c;try{s=po(o).toUint8Array()}catch(d){if(d instanceof Cg)return Yo("Decoding the base64 bloom filter in existence filter failed ("+d.message+"); ignoring the bloom filter and falling back to full re-query."),null;throw d}try{c=new Cu(s,r,i)}catch(d){return Yo(d instanceof Li?"BloomFilter error: ":"Applying bloom filter failed: ",d),null}return c.ge===0?null:c}ct(e,t,o){return t.Ce.count===o-this.Pt(e,t.targetId)?0:2}Pt(e,t){const o=this.Ge.getRemoteKeysForTarget(t);let r=0;return o.forEach(i=>{const s=this.Ge.ht(),c=`projects/${s.projectId}/databases/${s.database}/documents/${i.path.canonicalString()}`;e.mightContain(c)||(this.et(t,i,null),r++)}),r}Tt(e){const t=new Map;this.ze.forEach((i,s)=>{const c=this.ot(s);if(c){if(i.current&&Ec(c.target)){const d=new Q(c.target.path);this.Et(d).has(s)||this.It(s,d)||this.et(s,d,ht.newNoDocument(d,e))}i.Be&&(t.set(s,i.ke()),i.qe())}});let o=fe();this.He.forEach((i,s)=>{let c=!0;s.forEachWhile(d=>{const u=this.ot(d);return!u||u.purpose==="TargetPurposeLimboResolution"||(c=!1,!1)}),c&&(o=o.add(i))}),this.je.forEach((i,s)=>s.setReadTime(e));const r=new pl(e,t,this.Ze,this.je,o);return this.je=Vn(),this.Je=Qs(),this.He=Qs(),this.Ze=new Ne(he),r}Ye(e,t){if(!this.rt(e))return;const o=this.It(e,t.key)?2:0;this.nt(e).Ke(t.key,o),this.je=this.je.insert(t.key,t),this.Je=this.Je.insert(t.key,this.Et(t.key).add(e)),this.He=this.He.insert(t.key,this.Rt(t.key).add(e))}et(e,t,o){if(!this.rt(e))return;const r=this.nt(e);this.It(e,t)?r.Ke(t,1):r.Ue(t),this.He=this.He.insert(t,this.Rt(t).delete(e)),this.He=this.He.insert(t,this.Rt(t).add(e)),o&&(this.je=this.je.insert(t,o))}removeTarget(e){this.ze.delete(e)}_t(e){const t=this.nt(e).ke();return this.Ge.getRemoteKeysForTarget(e).size+t.addedDocuments.size-t.removedDocuments.size}$e(e){this.nt(e).$e()}nt(e){let t=this.ze.get(e);return t||(t=new yf,this.ze.set(e,t)),t}Rt(e){let t=this.He.get(e);return t||(t=new Ze(he),this.He=this.He.insert(e,t)),t}Et(e){let t=this.Je.get(e);return t||(t=new Ze(he),this.Je=this.Je.insert(e,t)),t}rt(e){const t=this.ot(e)!==null;return t||Y("WatchChangeAggregator","Detected inactive target",e),t}ot(e){const t=this.ze.get(e);return t&&t.Ne?null:this.Ge.At(e)}it(e){this.ze.set(e,new yf),this.Ge.getRemoteKeysForTarget(e).forEach(t=>{this.et(e,t,null)})}It(e,t){return this.Ge.getRemoteKeysForTarget(e).has(t)}}function Qs(){return new Ne(Q.comparator)}function vf(){return new Ne(Q.comparator)}const aT={asc:"ASCENDING",desc:"DESCENDING"},lT={"<":"LESS_THAN","<=":"LESS_THAN_OR_EQUAL",">":"GREATER_THAN",">=":"GREATER_THAN_OR_EQUAL","==":"EQUAL","!=":"NOT_EQUAL","array-contains":"ARRAY_CONTAINS",in:"IN","not-in":"NOT_IN","array-contains-any":"ARRAY_CONTAINS_ANY"},cT={and:"AND",or:"OR"};class uT{constructor(e,t){this.databaseId=e,this.useProto3Json=t}}function xc(n,e){return n.useProto3Json||al(e)?e:{value:e}}function Va(n,e){return n.useProto3Json?`${new Date(1e3*e.seconds).toISOString().replace(/\.\d*/,"").replace("Z","")}.${("000000000"+e.nanoseconds).slice(-9)}Z`:{seconds:""+e.seconds,nanos:e.nanoseconds}}function am(n,e){return n.useProto3Json?e.toBase64():e.toUint8Array()}function dT(n,e){return Va(n,e.toTimestamp())}function dn(n){return be(!!n,49232),ne.fromTimestamp(function(t){const o=fo(t);return new Ce(o.seconds,o.nanos)}(n))}function Pu(n,e){return Sc(n,e).canonicalString()}function Sc(n,e){const t=function(r){return new xe(["projects",r.projectId,"databases",r.database])}(n).child("documents");return e===void 0?t:t.child(e)}function lm(n){const e=xe.fromString(n);return be(fm(e),10190,{key:e.toString()}),e}function Ac(n,e){return Pu(n.databaseId,e.path)}function Kl(n,e){const t=lm(e);if(t.get(1)!==n.databaseId.projectId)throw new G(F.INVALID_ARGUMENT,"Tried to deserialize key from different project: "+t.get(1)+" vs "+n.databaseId.projectId);if(t.get(3)!==n.databaseId.database)throw new G(F.INVALID_ARGUMENT,"Tried to deserialize key from different database: "+t.get(3)+" vs "+n.databaseId.database);return new Q(um(t))}function cm(n,e){return Pu(n.databaseId,e)}function hT(n){const e=lm(n);return e.length===4?xe.emptyPath():um(e)}function kc(n){return new xe(["projects",n.databaseId.projectId,"databases",n.databaseId.database]).canonicalString()}function um(n){return be(n.length>4&&n.get(4)==="documents",29091,{key:n.toString()}),n.popFirst(5)}function bf(n,e,t){return{name:Ac(n,e),fields:t.value.mapValue.fields}}function fT(n,e){let t;if("targetChange"in e){e.targetChange;const o=function(u){return u==="NO_CHANGE"?0:u==="ADD"?1:u==="REMOVE"?2:u==="CURRENT"?3:u==="RESET"?4:ee(39313,{state:u})}(e.targetChange.targetChangeType||"NO_CHANGE"),r=e.targetChange.targetIds||[],i=function(u,f){return u.useProto3Json?(be(f===void 0||typeof f=="string",58123),lt.fromBase64String(f||"")):(be(f===void 0||f instanceof Buffer||f instanceof Uint8Array,16193),lt.fromUint8Array(f||new Uint8Array))}(n,e.targetChange.resumeToken),s=e.targetChange.cause,c=s&&function(u){const f=u.code===void 0?F.UNKNOWN:rm(u.code);return new G(f,u.message||"")}(s);t=new sm(o,r,i,c||null)}else if("documentChange"in e){e.documentChange;const o=e.documentChange;o.document,o.document.name,o.document.updateTime;const r=Kl(n,o.document.name),i=dn(o.document.updateTime),s=o.document.createTime?dn(o.document.createTime):ne.min(),c=new wt({mapValue:{fields:o.document.fields}}),d=ht.newFoundDocument(r,i,s,c),u=o.targetIds||[],f=o.removedTargetIds||[];t=new va(u,f,d.key,d)}else if("documentDelete"in e){e.documentDelete;const o=e.documentDelete;o.document;const r=Kl(n,o.document),i=o.readTime?dn(o.readTime):ne.min(),s=ht.newNoDocument(r,i),c=o.removedTargetIds||[];t=new va([],c,s.key,s)}else if("documentRemove"in e){e.documentRemove;const o=e.documentRemove;o.document;const r=Kl(n,o.document),i=o.removedTargetIds||[];t=new va([],i,r,null)}else{if(!("filter"in e))return ee(11601,{Vt:e});{e.filter;const o=e.filter;o.targetId;const{count:r=0,unchangedNames:i}=o,s=new nT(r,i),c=o.targetId;t=new im(c,s)}}return t}function pT(n,e){let t;if(e instanceof Ss)t={update:bf(n,e.key,e.value)};else if(e instanceof Au)t={delete:Ac(n,e.key)};else if(e instanceof _o)t={update:bf(n,e.key,e.data),updateMask:ET(e.fieldMask)};else{if(!(e instanceof Z0))return ee(16599,{dt:e.type});t={verify:Ac(n,e.key)}}return e.fieldTransforms.length>0&&(t.updateTransforms=e.fieldTransforms.map(o=>function(i,s){const c=s.transform;if(c instanceof as)return{fieldPath:s.field.canonicalString(),setToServerValue:"REQUEST_TIME"};if(c instanceof ls)return{fieldPath:s.field.canonicalString(),appendMissingElements:{values:c.elements}};if(c instanceof cs)return{fieldPath:s.field.canonicalString(),removeAllFromArray:{values:c.elements}};if(c instanceof us)return{fieldPath:s.field.canonicalString(),increment:c.Ae};throw ee(20930,{transform:s.transform})}(0,o))),e.precondition.isNone||(t.currentDocument=function(r,i){return i.updateTime!==void 0?{updateTime:dT(r,i.updateTime)}:i.exists!==void 0?{exists:i.exists}:ee(27497)}(n,e.precondition)),t}function gT(n,e){return n&&n.length>0?(be(e!==void 0,14353),n.map(t=>function(r,i){let s=r.updateTime?dn(r.updateTime):dn(i);return s.isEqual(ne.min())&&(s=dn(i)),new X0(s,r.transformResults||[])}(t,e))):[]}function mT(n,e){return{documents:[cm(n,e.path)]}}function yT(n,e){const t={structuredQuery:{}},o=e.path;let r;e.collectionGroup!==null?(r=o,t.structuredQuery.from=[{collectionId:e.collectionGroup,allDescendants:!0}]):(r=o.popLast(),t.structuredQuery.from=[{collectionId:o.lastSegment()}]),t.parent=cm(n,r);const i=function(u){if(u.length!==0)return hm(Gt.create(u,"and"))}(e.filters);i&&(t.structuredQuery.where=i);const s=function(u){if(u.length!==0)return u.map(f=>function(m){return{field:fr(m.field),direction:wT(m.dir)}}(f))}(e.orderBy);s&&(t.structuredQuery.orderBy=s);const c=xc(n,e.limit);return c!==null&&(t.structuredQuery.limit=c),e.startAt&&(t.structuredQuery.startAt=function(u){return{before:u.inclusive,values:u.position}}(e.startAt)),e.endAt&&(t.structuredQuery.endAt=function(u){return{before:!u.inclusive,values:u.position}}(e.endAt)),{ft:t,parent:r}}function vT(n){let e=hT(n.parent);const t=n.structuredQuery,o=t.from?t.from.length:0;let r=null;if(o>0){be(o===1,65062);const f=t.from[0];f.allDescendants?r=f.collectionId:e=e.child(f.collectionId)}let i=[];t.where&&(i=function(g){const m=dm(g);return m instanceof Gt&&Ug(m)?m.getFilters():[m]}(t.where));let s=[];t.orderBy&&(s=function(g){return g.map(m=>function(O){return new ss(pr(O.field),function(L){switch(L){case"ASCENDING":return"asc";case"DESCENDING":return"desc";default:return}}(O.direction))}(m))}(t.orderBy));let c=null;t.limit&&(c=function(g){let m;return m=typeof g=="object"?g.value:g,al(m)?null:m}(t.limit));let d=null;t.startAt&&(d=function(g){const m=!!g.before,v=g.values||[];return new La(v,m)}(t.startAt));let u=null;return t.endAt&&(u=function(g){const m=!g.before,v=g.values||[];return new La(v,m)}(t.endAt)),D0(e,r,s,i,c,"F",d,u)}function bT(n,e){const t=function(r){switch(r){case"TargetPurposeListen":return null;case"TargetPurposeExistenceFilterMismatch":return"existence-filter-mismatch";case"TargetPurposeExistenceFilterMismatchBloom":return"existence-filter-mismatch-bloom";case"TargetPurposeLimboResolution":return"limbo-document";default:return ee(28987,{purpose:r})}}(e.purpose);return t==null?null:{"goog-listen-tags":t}}function dm(n){return n.unaryFilter!==void 0?function(t){switch(t.unaryFilter.op){case"IS_NAN":const o=pr(t.unaryFilter.field);return je.create(o,"==",{doubleValue:NaN});case"IS_NULL":const r=pr(t.unaryFilter.field);return je.create(r,"==",{nullValue:"NULL_VALUE"});case"IS_NOT_NAN":const i=pr(t.unaryFilter.field);return je.create(i,"!=",{doubleValue:NaN});case"IS_NOT_NULL":const s=pr(t.unaryFilter.field);return je.create(s,"!=",{nullValue:"NULL_VALUE"});case"OPERATOR_UNSPECIFIED":return ee(61313);default:return ee(60726)}}(n):n.fieldFilter!==void 0?function(t){return je.create(pr(t.fieldFilter.field),function(r){switch(r){case"EQUAL":return"==";case"NOT_EQUAL":return"!=";case"GREATER_THAN":return">";case"GREATER_THAN_OR_EQUAL":return">=";case"LESS_THAN":return"<";case"LESS_THAN_OR_EQUAL":return"<=";case"ARRAY_CONTAINS":return"array-contains";case"IN":return"in";case"NOT_IN":return"not-in";case"ARRAY_CONTAINS_ANY":return"array-contains-any";case"OPERATOR_UNSPECIFIED":return ee(58110);default:return ee(50506)}}(t.fieldFilter.op),t.fieldFilter.value)}(n):n.compositeFilter!==void 0?function(t){return Gt.create(t.compositeFilter.filters.map(o=>dm(o)),function(r){switch(r){case"AND":return"and";case"OR":return"or";default:return ee(1026)}}(t.compositeFilter.op))}(n):ee(30097,{filter:n})}function wT(n){return aT[n]}function _T(n){return lT[n]}function TT(n){return cT[n]}function fr(n){return{fieldPath:n.canonicalString()}}function pr(n){return st.fromServerFormat(n.fieldPath)}function hm(n){return n instanceof je?function(t){if(t.op==="=="){if(sf(t.value))return{unaryFilter:{field:fr(t.field),op:"IS_NAN"}};if(rf(t.value))return{unaryFilter:{field:fr(t.field),op:"IS_NULL"}}}else if(t.op==="!="){if(sf(t.value))return{unaryFilter:{field:fr(t.field),op:"IS_NOT_NAN"}};if(rf(t.value))return{unaryFilter:{field:fr(t.field),op:"IS_NOT_NULL"}}}return{fieldFilter:{field:fr(t.field),op:_T(t.op),value:t.value}}}(n):n instanceof Gt?function(t){const o=t.getFilters().map(r=>hm(r));return o.length===1?o[0]:{compositeFilter:{op:TT(t.op),filters:o}}}(n):ee(54877,{filter:n})}function ET(n){const e=[];return n.fields.forEach(t=>e.push(t.canonicalString())),{fieldPaths:e}}function fm(n){return n.length>=4&&n.get(0)==="projects"&&n.get(2)==="databases"}function pm(n){return!!n&&typeof n._toProto=="function"&&n._protoValueType==="ProtoValue"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class to{constructor(e,t,o,r,i=ne.min(),s=ne.min(),c=lt.EMPTY_BYTE_STRING,d=null){this.target=e,this.targetId=t,this.purpose=o,this.sequenceNumber=r,this.snapshotVersion=i,this.lastLimboFreeSnapshotVersion=s,this.resumeToken=c,this.expectedCount=d}withSequenceNumber(e){return new to(this.target,this.targetId,this.purpose,e,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,this.expectedCount)}withResumeToken(e,t){return new to(this.target,this.targetId,this.purpose,this.sequenceNumber,t,this.lastLimboFreeSnapshotVersion,e,null)}withExpectedCount(e){return new to(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,e)}withLastLimboFreeSnapshotVersion(e){return new to(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,e,this.resumeToken,this.expectedCount)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class IT{constructor(e){this.yt=e}}function xT(n){const e=vT({parent:n.parent,structuredQuery:n.structuredQuery});return n.limitType==="LAST"?Da(e,e.limit,"L"):e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ST{constructor(){this.bn=new AT}addToCollectionParentIndex(e,t){return this.bn.add(t),U.resolve()}getCollectionParents(e,t){return U.resolve(this.bn.getEntries(t))}addFieldIndex(e,t){return U.resolve()}deleteFieldIndex(e,t){return U.resolve()}deleteAllFieldIndexes(e){return U.resolve()}createTargetIndexes(e,t){return U.resolve()}getDocumentsMatchingTarget(e,t){return U.resolve(null)}getIndexType(e,t){return U.resolve(0)}getFieldIndexes(e,t){return U.resolve([])}getNextCollectionGroupToUpdate(e){return U.resolve(null)}getMinOffset(e,t){return U.resolve(ho.min())}getMinOffsetFromCollectionGroup(e,t){return U.resolve(ho.min())}updateCollectionGroup(e,t,o){return U.resolve()}updateIndexEntries(e,t){return U.resolve()}}class AT{constructor(){this.index={}}add(e){const t=e.lastSegment(),o=e.popLast(),r=this.index[t]||new Ze(xe.comparator),i=!r.has(o);return this.index[t]=r.add(o),i}has(e){const t=e.lastSegment(),o=e.popLast(),r=this.index[t];return r&&r.has(o)}getEntries(e){return(this.index[e]||new Ze(xe.comparator)).toArray()}}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const wf={didRun:!1,sequenceNumbersCollected:0,targetsRemoved:0,documentsRemoved:0},gm=41943040;class vt{static withCacheSize(e){return new vt(e,vt.DEFAULT_COLLECTION_PERCENTILE,vt.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT)}constructor(e,t,o){this.cacheSizeCollectionThreshold=e,this.percentileToCollect=t,this.maximumSequenceNumbersToCollect=o}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */vt.DEFAULT_COLLECTION_PERCENTILE=10,vt.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT=1e3,vt.DEFAULT=new vt(gm,vt.DEFAULT_COLLECTION_PERCENTILE,vt.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT),vt.DISABLED=new vt(-1,0,0);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ur{constructor(e){this.sr=e}next(){return this.sr+=2,this.sr}static _r(){return new Ur(0)}static ar(){return new Ur(-1)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const _f="LruGarbageCollector",kT=1048576;function Tf([n,e],[t,o]){const r=he(n,t);return r===0?he(e,o):r}class CT{constructor(e){this.Pr=e,this.buffer=new Ze(Tf),this.Tr=0}Er(){return++this.Tr}Ir(e){const t=[e,this.Er()];if(this.buffer.size<this.Pr)this.buffer=this.buffer.add(t);else{const o=this.buffer.last();Tf(t,o)<0&&(this.buffer=this.buffer.delete(o).add(t))}}get maxValue(){return this.buffer.last()[0]}}class PT{constructor(e,t,o){this.garbageCollector=e,this.asyncQueue=t,this.localStore=o,this.Rr=null}start(){this.garbageCollector.params.cacheSizeCollectionThreshold!==-1&&this.Ar(6e4)}stop(){this.Rr&&(this.Rr.cancel(),this.Rr=null)}get started(){return this.Rr!==null}Ar(e){Y(_f,`Garbage collection scheduled in ${e}ms`),this.Rr=this.asyncQueue.enqueueAfterDelay("lru_garbage_collection",e,async()=>{this.Rr=null;try{await this.localStore.collectGarbage(this.garbageCollector)}catch(t){Qr(t)?Y(_f,"Ignoring IndexedDB error during garbage collection: ",t):await Xr(t)}await this.Ar(3e5)})}}class RT{constructor(e,t){this.Vr=e,this.params=t}calculateTargetCount(e,t){return this.Vr.dr(e).next(o=>Math.floor(t/100*o))}nthSequenceNumber(e,t){if(t===0)return U.resolve(sl.ce);const o=new CT(t);return this.Vr.forEachTarget(e,r=>o.Ir(r.sequenceNumber)).next(()=>this.Vr.mr(e,r=>o.Ir(r))).next(()=>o.maxValue)}removeTargets(e,t,o){return this.Vr.removeTargets(e,t,o)}removeOrphanedDocuments(e,t){return this.Vr.removeOrphanedDocuments(e,t)}collect(e,t){return this.params.cacheSizeCollectionThreshold===-1?(Y("LruGarbageCollector","Garbage collection skipped; disabled"),U.resolve(wf)):this.getCacheSize(e).next(o=>o<this.params.cacheSizeCollectionThreshold?(Y("LruGarbageCollector",`Garbage collection skipped; Cache size ${o} is lower than threshold ${this.params.cacheSizeCollectionThreshold}`),wf):this.gr(e,t))}getCacheSize(e){return this.Vr.getCacheSize(e)}gr(e,t){let o,r,i,s,c,d,u;const f=Date.now();return this.calculateTargetCount(e,this.params.percentileToCollect).next(g=>(g>this.params.maximumSequenceNumbersToCollect?(Y("LruGarbageCollector",`Capping sequence numbers to collect down to the maximum of ${this.params.maximumSequenceNumbersToCollect} from ${g}`),r=this.params.maximumSequenceNumbersToCollect):r=g,s=Date.now(),this.nthSequenceNumber(e,r))).next(g=>(o=g,c=Date.now(),this.removeTargets(e,o,t))).next(g=>(i=g,d=Date.now(),this.removeOrphanedDocuments(e,o))).next(g=>(u=Date.now(),dr()<=de.DEBUG&&Y("LruGarbageCollector",`LRU Garbage Collection
	Counted targets in ${s-f}ms
	Determined least recently used ${r} in `+(c-s)+`ms
	Removed ${i} targets in `+(d-c)+`ms
	Removed ${g} documents in `+(u-d)+`ms
Total Duration: ${u-f}ms`),U.resolve({didRun:!0,sequenceNumbersCollected:r,targetsRemoved:i,documentsRemoved:g})))}}function OT(n,e){return new RT(n,e)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class MT{constructor(){this.changes=new tr(e=>e.toString(),(e,t)=>e.isEqual(t)),this.changesApplied=!1}addEntry(e){this.assertNotApplied(),this.changes.set(e.key,e)}removeEntry(e,t){this.assertNotApplied(),this.changes.set(e,ht.newInvalidDocument(e).setReadTime(t))}getEntry(e,t){this.assertNotApplied();const o=this.changes.get(t);return o!==void 0?U.resolve(o):this.getFromCache(e,t)}getEntries(e,t){return this.getAllFromCache(e,t)}apply(e){return this.assertNotApplied(),this.changesApplied=!0,this.applyChanges(e)}assertNotApplied(){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class NT{constructor(e,t){this.overlayedDocument=e,this.mutatedFields=t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class LT{constructor(e,t,o,r){this.remoteDocumentCache=e,this.mutationQueue=t,this.documentOverlayCache=o,this.indexManager=r}getDocument(e,t){let o=null;return this.documentOverlayCache.getOverlay(e,t).next(r=>(o=r,this.remoteDocumentCache.getEntry(e,t))).next(r=>(o!==null&&Yi(o.mutation,r,Ot.empty(),Ce.now()),r))}getDocuments(e,t){return this.remoteDocumentCache.getEntries(e,t).next(o=>this.getLocalViewOfDocuments(e,o,fe()).next(()=>o))}getLocalViewOfDocuments(e,t,o=fe()){const r=Mo();return this.populateOverlays(e,r,t).next(()=>this.computeViews(e,t,r,o).next(i=>{let s=Ni();return i.forEach((c,d)=>{s=s.insert(c,d.overlayedDocument)}),s}))}getOverlayedDocuments(e,t){const o=Mo();return this.populateOverlays(e,o,t).next(()=>this.computeViews(e,t,o,fe()))}populateOverlays(e,t,o){const r=[];return o.forEach(i=>{t.has(i)||r.push(i)}),this.documentOverlayCache.getOverlays(e,r).next(i=>{i.forEach((s,c)=>{t.set(s,c)})})}computeViews(e,t,o,r){let i=Vn();const s=Gi(),c=function(){return Gi()}();return t.forEach((d,u)=>{const f=o.get(u.key);r.has(u.key)&&(f===void 0||f.mutation instanceof _o)?i=i.insert(u.key,u):f!==void 0?(s.set(u.key,f.mutation.getFieldMask()),Yi(f.mutation,u,f.mutation.getFieldMask(),Ce.now())):s.set(u.key,Ot.empty())}),this.recalculateAndSaveOverlays(e,i).next(d=>(d.forEach((u,f)=>s.set(u,f)),t.forEach((u,f)=>c.set(u,new NT(f,s.get(u)??null))),c))}recalculateAndSaveOverlays(e,t){const o=Gi();let r=new Ne((s,c)=>s-c),i=fe();return this.mutationQueue.getAllMutationBatchesAffectingDocumentKeys(e,t).next(s=>{for(const c of s)c.keys().forEach(d=>{const u=t.get(d);if(u===null)return;let f=o.get(d)||Ot.empty();f=c.applyToLocalView(u,f),o.set(d,f);const g=(r.get(c.batchId)||fe()).add(d);r=r.insert(c.batchId,g)})}).next(()=>{const s=[],c=r.getReverseIterator();for(;c.hasNext();){const d=c.getNext(),u=d.key,f=d.value,g=Yg();f.forEach(m=>{if(!i.has(m)){const v=nm(t.get(m),o.get(m));v!==null&&g.set(m,v),i=i.add(m)}}),s.push(this.documentOverlayCache.saveOverlays(e,u,g))}return U.waitFor(s)}).next(()=>o)}recalculateAndSaveOverlaysForDocumentKeys(e,t){return this.remoteDocumentCache.getEntries(e,t).next(o=>this.recalculateAndSaveOverlays(e,o))}getDocumentsMatchingQuery(e,t,o,r){return V0(t)?this.getDocumentsMatchingDocumentQuery(e,t.path):$g(t)?this.getDocumentsMatchingCollectionGroupQuery(e,t,o,r):this.getDocumentsMatchingCollectionQuery(e,t,o,r)}getNextDocuments(e,t,o,r){return this.remoteDocumentCache.getAllFromCollectionGroup(e,t,o,r).next(i=>{const s=r-i.size>0?this.documentOverlayCache.getOverlaysForCollectionGroup(e,t,o.largestBatchId,r-i.size):U.resolve(Mo());let c=ns,d=i;return s.next(u=>U.forEach(u,(f,g)=>(c<g.largestBatchId&&(c=g.largestBatchId),i.get(f)?U.resolve():this.remoteDocumentCache.getEntry(e,f).next(m=>{d=d.insert(f,m)}))).next(()=>this.populateOverlays(e,u,i)).next(()=>this.computeViews(e,d,u,fe())).next(f=>({batchId:c,changes:Gg(f)})))})}getDocumentsMatchingDocumentQuery(e,t){return this.getDocument(e,new Q(t)).next(o=>{let r=Ni();return o.isFoundDocument()&&(r=r.insert(o.key,o)),r})}getDocumentsMatchingCollectionGroupQuery(e,t,o,r){const i=t.collectionGroup;let s=Ni();return this.indexManager.getCollectionParents(e,i).next(c=>U.forEach(c,d=>{const u=function(g,m){return new Jr(m,null,g.explicitOrderBy.slice(),g.filters.slice(),g.limit,g.limitType,g.startAt,g.endAt)}(t,d.child(i));return this.getDocumentsMatchingCollectionQuery(e,u,o,r).next(f=>{f.forEach((g,m)=>{s=s.insert(g,m)})})}).next(()=>s))}getDocumentsMatchingCollectionQuery(e,t,o,r){let i;return this.documentOverlayCache.getOverlaysForCollection(e,t.path,o.largestBatchId).next(s=>(i=s,this.remoteDocumentCache.getDocumentsMatchingQuery(e,t,o,i,r))).next(s=>{i.forEach((d,u)=>{const f=u.getKey();s.get(f)===null&&(s=s.insert(f,ht.newInvalidDocument(f)))});let c=Ni();return s.forEach((d,u)=>{const f=i.get(d);f!==void 0&&Yi(f.mutation,u,Ot.empty(),Ce.now()),dl(t,u)&&(c=c.insert(d,u))}),c})}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class DT{constructor(e){this.serializer=e,this.Nr=new Map,this.Br=new Map}getBundleMetadata(e,t){return U.resolve(this.Nr.get(t))}saveBundleMetadata(e,t){return this.Nr.set(t.id,function(r){return{id:r.id,version:r.version,createTime:dn(r.createTime)}}(t)),U.resolve()}getNamedQuery(e,t){return U.resolve(this.Br.get(t))}saveNamedQuery(e,t){return this.Br.set(t.name,function(r){return{name:r.name,query:xT(r.bundledQuery),readTime:dn(r.readTime)}}(t)),U.resolve()}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class VT{constructor(){this.overlays=new Ne(Q.comparator),this.Lr=new Map}getOverlay(e,t){return U.resolve(this.overlays.get(t))}getOverlays(e,t){const o=Mo();return U.forEach(t,r=>this.getOverlay(e,r).next(i=>{i!==null&&o.set(r,i)})).next(()=>o)}saveOverlays(e,t,o){return o.forEach((r,i)=>{this.St(e,t,i)}),U.resolve()}removeOverlaysForBatchId(e,t,o){const r=this.Lr.get(o);return r!==void 0&&(r.forEach(i=>this.overlays=this.overlays.remove(i)),this.Lr.delete(o)),U.resolve()}getOverlaysForCollection(e,t,o){const r=Mo(),i=t.length+1,s=new Q(t.child("")),c=this.overlays.getIteratorFrom(s);for(;c.hasNext();){const d=c.getNext().value,u=d.getKey();if(!t.isPrefixOf(u.path))break;u.path.length===i&&d.largestBatchId>o&&r.set(d.getKey(),d)}return U.resolve(r)}getOverlaysForCollectionGroup(e,t,o,r){let i=new Ne((u,f)=>u-f);const s=this.overlays.getIterator();for(;s.hasNext();){const u=s.getNext().value;if(u.getKey().getCollectionGroup()===t&&u.largestBatchId>o){let f=i.get(u.largestBatchId);f===null&&(f=Mo(),i=i.insert(u.largestBatchId,f)),f.set(u.getKey(),u)}}const c=Mo(),d=i.getIterator();for(;d.hasNext()&&(d.getNext().value.forEach((u,f)=>c.set(u,f)),!(c.size()>=r)););return U.resolve(c)}St(e,t,o){const r=this.overlays.get(o.key);if(r!==null){const s=this.Lr.get(r.largestBatchId).delete(o.key);this.Lr.set(r.largestBatchId,s)}this.overlays=this.overlays.insert(o.key,new tT(t,o));let i=this.Lr.get(t);i===void 0&&(i=fe(),this.Lr.set(t,i)),this.Lr.set(t,i.add(o.key))}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class FT{constructor(){this.sessionToken=lt.EMPTY_BYTE_STRING}getSessionToken(e){return U.resolve(this.sessionToken)}setSessionToken(e,t){return this.sessionToken=t,U.resolve()}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ru{constructor(){this.kr=new Ze(ot.qr),this.Kr=new Ze(ot.Ur)}isEmpty(){return this.kr.isEmpty()}addReference(e,t){const o=new ot(e,t);this.kr=this.kr.add(o),this.Kr=this.Kr.add(o)}$r(e,t){e.forEach(o=>this.addReference(o,t))}removeReference(e,t){this.Wr(new ot(e,t))}Qr(e,t){e.forEach(o=>this.removeReference(o,t))}Gr(e){const t=new Q(new xe([])),o=new ot(t,e),r=new ot(t,e+1),i=[];return this.Kr.forEachInRange([o,r],s=>{this.Wr(s),i.push(s.key)}),i}zr(){this.kr.forEach(e=>this.Wr(e))}Wr(e){this.kr=this.kr.delete(e),this.Kr=this.Kr.delete(e)}jr(e){const t=new Q(new xe([])),o=new ot(t,e),r=new ot(t,e+1);let i=fe();return this.Kr.forEachInRange([o,r],s=>{i=i.add(s.key)}),i}containsKey(e){const t=new ot(e,0),o=this.kr.firstAfterOrEqual(t);return o!==null&&e.isEqual(o.key)}}class ot{constructor(e,t){this.key=e,this.Jr=t}static qr(e,t){return Q.comparator(e.key,t.key)||he(e.Jr,t.Jr)}static Ur(e,t){return he(e.Jr,t.Jr)||Q.comparator(e.key,t.key)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class UT{constructor(e,t){this.indexManager=e,this.referenceDelegate=t,this.mutationQueue=[],this.Yn=1,this.Hr=new Ze(ot.qr)}checkEmpty(e){return U.resolve(this.mutationQueue.length===0)}addMutationBatch(e,t,o,r){const i=this.Yn;this.Yn++,this.mutationQueue.length>0&&this.mutationQueue[this.mutationQueue.length-1];const s=new eT(i,t,o,r);this.mutationQueue.push(s);for(const c of r)this.Hr=this.Hr.add(new ot(c.key,i)),this.indexManager.addToCollectionParentIndex(e,c.key.path.popLast());return U.resolve(s)}lookupMutationBatch(e,t){return U.resolve(this.Zr(t))}getNextMutationBatchAfterBatchId(e,t){const o=t+1,r=this.Xr(o),i=r<0?0:r;return U.resolve(this.mutationQueue.length>i?this.mutationQueue[i]:null)}getHighestUnacknowledgedBatchId(){return U.resolve(this.mutationQueue.length===0?_u:this.Yn-1)}getAllMutationBatches(e){return U.resolve(this.mutationQueue.slice())}getAllMutationBatchesAffectingDocumentKey(e,t){const o=new ot(t,0),r=new ot(t,Number.POSITIVE_INFINITY),i=[];return this.Hr.forEachInRange([o,r],s=>{const c=this.Zr(s.Jr);i.push(c)}),U.resolve(i)}getAllMutationBatchesAffectingDocumentKeys(e,t){let o=new Ze(he);return t.forEach(r=>{const i=new ot(r,0),s=new ot(r,Number.POSITIVE_INFINITY);this.Hr.forEachInRange([i,s],c=>{o=o.add(c.Jr)})}),U.resolve(this.Yr(o))}getAllMutationBatchesAffectingQuery(e,t){const o=t.path,r=o.length+1;let i=o;Q.isDocumentKey(i)||(i=i.child(""));const s=new ot(new Q(i),0);let c=new Ze(he);return this.Hr.forEachWhile(d=>{const u=d.key.path;return!!o.isPrefixOf(u)&&(u.length===r&&(c=c.add(d.Jr)),!0)},s),U.resolve(this.Yr(c))}Yr(e){const t=[];return e.forEach(o=>{const r=this.Zr(o);r!==null&&t.push(r)}),t}removeMutationBatch(e,t){be(this.ei(t.batchId,"removed")===0,55003),this.mutationQueue.shift();let o=this.Hr;return U.forEach(t.mutations,r=>{const i=new ot(r.key,t.batchId);return o=o.delete(i),this.referenceDelegate.markPotentiallyOrphaned(e,r.key)}).next(()=>{this.Hr=o})}nr(e){}containsKey(e,t){const o=new ot(t,0),r=this.Hr.firstAfterOrEqual(o);return U.resolve(t.isEqual(r&&r.key))}performConsistencyCheck(e){return this.mutationQueue.length,U.resolve()}ei(e,t){return this.Xr(e)}Xr(e){return this.mutationQueue.length===0?0:e-this.mutationQueue[0].batchId}Zr(e){const t=this.Xr(e);return t<0||t>=this.mutationQueue.length?null:this.mutationQueue[t]}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class qT{constructor(e){this.ti=e,this.docs=function(){return new Ne(Q.comparator)}(),this.size=0}setIndexManager(e){this.indexManager=e}addEntry(e,t){const o=t.key,r=this.docs.get(o),i=r?r.size:0,s=this.ti(t);return this.docs=this.docs.insert(o,{document:t.mutableCopy(),size:s}),this.size+=s-i,this.indexManager.addToCollectionParentIndex(e,o.path.popLast())}removeEntry(e){const t=this.docs.get(e);t&&(this.docs=this.docs.remove(e),this.size-=t.size)}getEntry(e,t){const o=this.docs.get(t);return U.resolve(o?o.document.mutableCopy():ht.newInvalidDocument(t))}getEntries(e,t){let o=Vn();return t.forEach(r=>{const i=this.docs.get(r);o=o.insert(r,i?i.document.mutableCopy():ht.newInvalidDocument(r))}),U.resolve(o)}getDocumentsMatchingQuery(e,t,o,r){let i=Vn();const s=t.path,c=new Q(s.child("__id-9223372036854775808__")),d=this.docs.getIteratorFrom(c);for(;d.hasNext();){const{key:u,value:{document:f}}=d.getNext();if(!s.isPrefixOf(u.path))break;u.path.length>s.length+1||f0(h0(f),o)<=0||(r.has(f.key)||dl(t,f))&&(i=i.insert(f.key,f.mutableCopy()))}return U.resolve(i)}getAllFromCollectionGroup(e,t,o,r){ee(9500)}ni(e,t){return U.forEach(this.docs,o=>t(o))}newChangeBuffer(e){return new zT(this)}getSize(e){return U.resolve(this.size)}}class zT extends MT{constructor(e){super(),this.Mr=e}applyChanges(e){const t=[];return this.changes.forEach((o,r)=>{r.isValidDocument()?t.push(this.Mr.addEntry(e,r)):this.Mr.removeEntry(o)}),U.waitFor(t)}getFromCache(e,t){return this.Mr.getEntry(e,t)}getAllFromCache(e,t){return this.Mr.getEntries(e,t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class BT{constructor(e){this.persistence=e,this.ri=new tr(t=>Iu(t),xu),this.lastRemoteSnapshotVersion=ne.min(),this.highestTargetId=0,this.ii=0,this.si=new Ru,this.targetCount=0,this.oi=Ur._r()}forEachTarget(e,t){return this.ri.forEach((o,r)=>t(r)),U.resolve()}getLastRemoteSnapshotVersion(e){return U.resolve(this.lastRemoteSnapshotVersion)}getHighestSequenceNumber(e){return U.resolve(this.ii)}allocateTargetId(e){return this.highestTargetId=this.oi.next(),U.resolve(this.highestTargetId)}setTargetsMetadata(e,t,o){return o&&(this.lastRemoteSnapshotVersion=o),t>this.ii&&(this.ii=t),U.resolve()}lr(e){this.ri.set(e.target,e);const t=e.targetId;t>this.highestTargetId&&(this.oi=new Ur(t),this.highestTargetId=t),e.sequenceNumber>this.ii&&(this.ii=e.sequenceNumber)}addTargetData(e,t){return this.lr(t),this.targetCount+=1,U.resolve()}updateTargetData(e,t){return this.lr(t),U.resolve()}removeTargetData(e,t){return this.ri.delete(t.target),this.si.Gr(t.targetId),this.targetCount-=1,U.resolve()}removeTargets(e,t,o){let r=0;const i=[];return this.ri.forEach((s,c)=>{c.sequenceNumber<=t&&o.get(c.targetId)===null&&(this.ri.delete(s),i.push(this.removeMatchingKeysForTargetId(e,c.targetId)),r++)}),U.waitFor(i).next(()=>r)}getTargetCount(e){return U.resolve(this.targetCount)}getTargetData(e,t){const o=this.ri.get(t)||null;return U.resolve(o)}addMatchingKeys(e,t,o){return this.si.$r(t,o),U.resolve()}removeMatchingKeys(e,t,o){this.si.Qr(t,o);const r=this.persistence.referenceDelegate,i=[];return r&&t.forEach(s=>{i.push(r.markPotentiallyOrphaned(e,s))}),U.waitFor(i)}removeMatchingKeysForTargetId(e,t){return this.si.Gr(t),U.resolve()}getMatchingKeysForTargetId(e,t){const o=this.si.jr(t);return U.resolve(o)}containsKey(e,t){return U.resolve(this.si.containsKey(t))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class mm{constructor(e,t){this._i={},this.overlays={},this.ai=new sl(0),this.ui=!1,this.ui=!0,this.ci=new FT,this.referenceDelegate=e(this),this.li=new BT(this),this.indexManager=new ST,this.remoteDocumentCache=function(r){return new qT(r)}(o=>this.referenceDelegate.hi(o)),this.serializer=new IT(t),this.Pi=new DT(this.serializer)}start(){return Promise.resolve()}shutdown(){return this.ui=!1,Promise.resolve()}get started(){return this.ui}setDatabaseDeletedListener(){}setNetworkEnabled(){}getIndexManager(e){return this.indexManager}getDocumentOverlayCache(e){let t=this.overlays[e.toKey()];return t||(t=new VT,this.overlays[e.toKey()]=t),t}getMutationQueue(e,t){let o=this._i[e.toKey()];return o||(o=new UT(t,this.referenceDelegate),this._i[e.toKey()]=o),o}getGlobalsCache(){return this.ci}getTargetCache(){return this.li}getRemoteDocumentCache(){return this.remoteDocumentCache}getBundleCache(){return this.Pi}runTransaction(e,t,o){Y("MemoryPersistence","Starting transaction:",e);const r=new $T(this.ai.next());return this.referenceDelegate.Ti(),o(r).next(i=>this.referenceDelegate.Ei(r).next(()=>i)).toPromise().then(i=>(r.raiseOnCommittedEvent(),i))}Ii(e,t){return U.or(Object.values(this._i).map(o=>()=>o.containsKey(e,t)))}}class $T extends g0{constructor(e){super(),this.currentSequenceNumber=e}}class Ou{constructor(e){this.persistence=e,this.Ri=new Ru,this.Ai=null}static Vi(e){return new Ou(e)}get di(){if(this.Ai)return this.Ai;throw ee(60996)}addReference(e,t,o){return this.Ri.addReference(o,t),this.di.delete(o.toString()),U.resolve()}removeReference(e,t,o){return this.Ri.removeReference(o,t),this.di.add(o.toString()),U.resolve()}markPotentiallyOrphaned(e,t){return this.di.add(t.toString()),U.resolve()}removeTarget(e,t){this.Ri.Gr(t.targetId).forEach(r=>this.di.add(r.toString()));const o=this.persistence.getTargetCache();return o.getMatchingKeysForTargetId(e,t.targetId).next(r=>{r.forEach(i=>this.di.add(i.toString()))}).next(()=>o.removeTargetData(e,t))}Ti(){this.Ai=new Set}Ei(e){const t=this.persistence.getRemoteDocumentCache().newChangeBuffer();return U.forEach(this.di,o=>{const r=Q.fromPath(o);return this.mi(e,r).next(i=>{i||t.removeEntry(r,ne.min())})}).next(()=>(this.Ai=null,t.apply(e)))}updateLimboDocument(e,t){return this.mi(e,t).next(o=>{o?this.di.delete(t.toString()):this.di.add(t.toString())})}hi(e){return 0}mi(e,t){return U.or([()=>U.resolve(this.Ri.containsKey(t)),()=>this.persistence.getTargetCache().containsKey(e,t),()=>this.persistence.Ii(e,t)])}}class Fa{constructor(e,t){this.persistence=e,this.fi=new tr(o=>v0(o.path),(o,r)=>o.isEqual(r)),this.garbageCollector=OT(this,t)}static Vi(e,t){return new Fa(e,t)}Ti(){}Ei(e){return U.resolve()}forEachTarget(e,t){return this.persistence.getTargetCache().forEachTarget(e,t)}dr(e){const t=this.pr(e);return this.persistence.getTargetCache().getTargetCount(e).next(o=>t.next(r=>o+r))}pr(e){let t=0;return this.mr(e,o=>{t++}).next(()=>t)}mr(e,t){return U.forEach(this.fi,(o,r)=>this.wr(e,o,r).next(i=>i?U.resolve():t(r)))}removeTargets(e,t,o){return this.persistence.getTargetCache().removeTargets(e,t,o)}removeOrphanedDocuments(e,t){let o=0;const r=this.persistence.getRemoteDocumentCache(),i=r.newChangeBuffer();return r.ni(e,s=>this.wr(e,s,t).next(c=>{c||(o++,i.removeEntry(s,ne.min()))})).next(()=>i.apply(e)).next(()=>o)}markPotentiallyOrphaned(e,t){return this.fi.set(t,e.currentSequenceNumber),U.resolve()}removeTarget(e,t){const o=t.withSequenceNumber(e.currentSequenceNumber);return this.persistence.getTargetCache().updateTargetData(e,o)}addReference(e,t,o){return this.fi.set(o,e.currentSequenceNumber),U.resolve()}removeReference(e,t,o){return this.fi.set(o,e.currentSequenceNumber),U.resolve()}updateLimboDocument(e,t){return this.fi.set(t,e.currentSequenceNumber),U.resolve()}hi(e){let t=e.key.toString().length;return e.isFoundDocument()&&(t+=ga(e.data.value)),t}wr(e,t,o){return U.or([()=>this.persistence.Ii(e,t),()=>this.persistence.getTargetCache().containsKey(e,t),()=>{const r=this.fi.get(t);return U.resolve(r!==void 0&&r>o)}])}getCacheSize(e){return this.persistence.getRemoteDocumentCache().getSize(e)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Mu{constructor(e,t,o,r){this.targetId=e,this.fromCache=t,this.Ts=o,this.Es=r}static Is(e,t){let o=fe(),r=fe();for(const i of t.docChanges)switch(i.type){case 0:o=o.add(i.doc.key);break;case 1:r=r.add(i.doc.key)}return new Mu(e,t.fromCache,o,r)}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class jT{constructor(){this._documentReadCount=0}get documentReadCount(){return this._documentReadCount}incrementDocumentReadCount(e){this._documentReadCount+=e}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class WT{constructor(){this.Rs=!1,this.As=!1,this.Vs=100,this.ds=function(){return Ov()?8:m0(ft())>0?6:4}()}initialize(e,t){this.fs=e,this.indexManager=t,this.Rs=!0}getDocumentsMatchingQuery(e,t,o,r){const i={result:null};return this.gs(e,t).next(s=>{i.result=s}).next(()=>{if(!i.result)return this.ps(e,t,r,o).next(s=>{i.result=s})}).next(()=>{if(i.result)return;const s=new jT;return this.ys(e,t,s).next(c=>{if(i.result=c,this.As)return this.ws(e,t,s,c.size)})}).next(()=>i.result)}ws(e,t,o,r){return o.documentReadCount<this.Vs?(dr()<=de.DEBUG&&Y("QueryEngine","SDK will not create cache indexes for query:",hr(t),"since it only creates cache indexes for collection contains","more than or equal to",this.Vs,"documents"),U.resolve()):(dr()<=de.DEBUG&&Y("QueryEngine","Query:",hr(t),"scans",o.documentReadCount,"local documents and returns",r,"documents as results."),o.documentReadCount>this.ds*r?(dr()<=de.DEBUG&&Y("QueryEngine","The SDK decides to create cache indexes for query:",hr(t),"as using cache indexes may help improve performance."),this.indexManager.createTargetIndexes(e,un(t))):U.resolve())}gs(e,t){if(uf(t))return U.resolve(null);let o=un(t);return this.indexManager.getIndexType(e,o).next(r=>r===0?null:(t.limit!==null&&r===1&&(t=Da(t,null,"F"),o=un(t)),this.indexManager.getDocumentsMatchingTarget(e,o).next(i=>{const s=fe(...i);return this.fs.getDocuments(e,s).next(c=>this.indexManager.getMinOffset(e,o).next(d=>{const u=this.Ss(t,c);return this.bs(t,u,s,d.readTime)?this.gs(e,Da(t,null,"F")):this.Ds(e,u,t,d)}))})))}ps(e,t,o,r){return uf(t)||r.isEqual(ne.min())?U.resolve(null):this.fs.getDocuments(e,o).next(i=>{const s=this.Ss(t,i);return this.bs(t,s,o,r)?U.resolve(null):(dr()<=de.DEBUG&&Y("QueryEngine","Re-using previous result from %s to execute query: %s",r.toString(),hr(t)),this.Ds(e,s,t,d0(r,ns)).next(c=>c))})}Ss(e,t){let o=new Ze(Wg(e));return t.forEach((r,i)=>{dl(e,i)&&(o=o.add(i))}),o}bs(e,t,o,r){if(e.limit===null)return!1;if(o.size!==t.size)return!0;const i=e.limitType==="F"?t.last():t.first();return!!i&&(i.hasPendingWrites||i.version.compareTo(r)>0)}ys(e,t,o){return dr()<=de.DEBUG&&Y("QueryEngine","Using full collection scan to execute query:",hr(t)),this.fs.getDocumentsMatchingQuery(e,t,ho.min(),o)}Ds(e,t,o,r){return this.fs.getDocumentsMatchingQuery(e,o,r).next(i=>(t.forEach(s=>{i=i.insert(s.key,s)}),i))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Nu="LocalStore",HT=3e8;class GT{constructor(e,t,o,r){this.persistence=e,this.Cs=t,this.serializer=r,this.vs=new Ne(he),this.Fs=new tr(i=>Iu(i),xu),this.Ms=new Map,this.xs=e.getRemoteDocumentCache(),this.li=e.getTargetCache(),this.Pi=e.getBundleCache(),this.Os(o)}Os(e){this.documentOverlayCache=this.persistence.getDocumentOverlayCache(e),this.indexManager=this.persistence.getIndexManager(e),this.mutationQueue=this.persistence.getMutationQueue(e,this.indexManager),this.localDocuments=new LT(this.xs,this.mutationQueue,this.documentOverlayCache,this.indexManager),this.xs.setIndexManager(this.indexManager),this.Cs.initialize(this.localDocuments,this.indexManager)}collectGarbage(e){return this.persistence.runTransaction("Collect garbage","readwrite-primary",t=>e.collect(t,this.vs))}}function YT(n,e,t,o){return new GT(n,e,t,o)}async function ym(n,e){const t=oe(n);return await t.persistence.runTransaction("Handle user change","readonly",o=>{let r;return t.mutationQueue.getAllMutationBatches(o).next(i=>(r=i,t.Os(e),t.mutationQueue.getAllMutationBatches(o))).next(i=>{const s=[],c=[];let d=fe();for(const u of r){s.push(u.batchId);for(const f of u.mutations)d=d.add(f.key)}for(const u of i){c.push(u.batchId);for(const f of u.mutations)d=d.add(f.key)}return t.localDocuments.getDocuments(o,d).next(u=>({Ns:u,removedBatchIds:s,addedBatchIds:c}))})})}function KT(n,e){const t=oe(n);return t.persistence.runTransaction("Acknowledge batch","readwrite-primary",o=>{const r=e.batch.keys(),i=t.xs.newChangeBuffer({trackRemovals:!0});return function(c,d,u,f){const g=u.batch,m=g.keys();let v=U.resolve();return m.forEach(O=>{v=v.next(()=>f.getEntry(d,O)).next(C=>{const L=u.docVersions.get(O);be(L!==null,48541),C.version.compareTo(L)<0&&(g.applyToRemoteDocument(C,u),C.isValidDocument()&&(C.setReadTime(u.commitVersion),f.addEntry(C)))})}),v.next(()=>c.mutationQueue.removeMutationBatch(d,g))}(t,o,e,i).next(()=>i.apply(o)).next(()=>t.mutationQueue.performConsistencyCheck(o)).next(()=>t.documentOverlayCache.removeOverlaysForBatchId(o,r,e.batch.batchId)).next(()=>t.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(o,function(c){let d=fe();for(let u=0;u<c.mutationResults.length;++u)c.mutationResults[u].transformResults.length>0&&(d=d.add(c.batch.mutations[u].key));return d}(e))).next(()=>t.localDocuments.getDocuments(o,r))})}function vm(n){const e=oe(n);return e.persistence.runTransaction("Get last remote snapshot version","readonly",t=>e.li.getLastRemoteSnapshotVersion(t))}function XT(n,e){const t=oe(n),o=e.snapshotVersion;let r=t.vs;return t.persistence.runTransaction("Apply remote event","readwrite-primary",i=>{const s=t.xs.newChangeBuffer({trackRemovals:!0});r=t.vs;const c=[];e.targetChanges.forEach((f,g)=>{const m=r.get(g);if(!m)return;c.push(t.li.removeMatchingKeys(i,f.removedDocuments,g).next(()=>t.li.addMatchingKeys(i,f.addedDocuments,g)));let v=m.withSequenceNumber(i.currentSequenceNumber);e.targetMismatches.get(g)!==null?v=v.withResumeToken(lt.EMPTY_BYTE_STRING,ne.min()).withLastLimboFreeSnapshotVersion(ne.min()):f.resumeToken.approximateByteSize()>0&&(v=v.withResumeToken(f.resumeToken,o)),r=r.insert(g,v),function(C,L,H){return C.resumeToken.approximateByteSize()===0||L.snapshotVersion.toMicroseconds()-C.snapshotVersion.toMicroseconds()>=HT?!0:H.addedDocuments.size+H.modifiedDocuments.size+H.removedDocuments.size>0}(m,v,f)&&c.push(t.li.updateTargetData(i,v))});let d=Vn(),u=fe();if(e.documentUpdates.forEach(f=>{e.resolvedLimboDocuments.has(f)&&c.push(t.persistence.referenceDelegate.updateLimboDocument(i,f))}),c.push(QT(i,s,e.documentUpdates).next(f=>{d=f.Bs,u=f.Ls})),!o.isEqual(ne.min())){const f=t.li.getLastRemoteSnapshotVersion(i).next(g=>t.li.setTargetsMetadata(i,i.currentSequenceNumber,o));c.push(f)}return U.waitFor(c).next(()=>s.apply(i)).next(()=>t.localDocuments.getLocalViewOfDocuments(i,d,u)).next(()=>d)}).then(i=>(t.vs=r,i))}function QT(n,e,t){let o=fe(),r=fe();return t.forEach(i=>o=o.add(i)),e.getEntries(n,o).next(i=>{let s=Vn();return t.forEach((c,d)=>{const u=i.get(c);d.isFoundDocument()!==u.isFoundDocument()&&(r=r.add(c)),d.isNoDocument()&&d.version.isEqual(ne.min())?(e.removeEntry(c,d.readTime),s=s.insert(c,d)):!u.isValidDocument()||d.version.compareTo(u.version)>0||d.version.compareTo(u.version)===0&&u.hasPendingWrites?(e.addEntry(d),s=s.insert(c,d)):Y(Nu,"Ignoring outdated watch update for ",c,". Current version:",u.version," Watch version:",d.version)}),{Bs:s,Ls:r}})}function JT(n,e){const t=oe(n);return t.persistence.runTransaction("Get next mutation batch","readonly",o=>(e===void 0&&(e=_u),t.mutationQueue.getNextMutationBatchAfterBatchId(o,e)))}function ZT(n,e){const t=oe(n);return t.persistence.runTransaction("Allocate target","readwrite",o=>{let r;return t.li.getTargetData(o,e).next(i=>i?(r=i,U.resolve(r)):t.li.allocateTargetId(o).next(s=>(r=new to(e,s,"TargetPurposeListen",o.currentSequenceNumber),t.li.addTargetData(o,r).next(()=>r))))}).then(o=>{const r=t.vs.get(o.targetId);return(r===null||o.snapshotVersion.compareTo(r.snapshotVersion)>0)&&(t.vs=t.vs.insert(o.targetId,o),t.Fs.set(e,o.targetId)),o})}async function Cc(n,e,t){const o=oe(n),r=o.vs.get(e),i=t?"readwrite":"readwrite-primary";try{t||await o.persistence.runTransaction("Release target",i,s=>o.persistence.referenceDelegate.removeTarget(s,r))}catch(s){if(!Qr(s))throw s;Y(Nu,`Failed to update sequence numbers for target ${e}: ${s}`)}o.vs=o.vs.remove(e),o.Fs.delete(r.target)}function Ef(n,e,t){const o=oe(n);let r=ne.min(),i=fe();return o.persistence.runTransaction("Execute query","readwrite",s=>function(d,u,f){const g=oe(d),m=g.Fs.get(f);return m!==void 0?U.resolve(g.vs.get(m)):g.li.getTargetData(u,f)}(o,s,un(e)).next(c=>{if(c)return r=c.lastLimboFreeSnapshotVersion,o.li.getMatchingKeysForTargetId(s,c.targetId).next(d=>{i=d})}).next(()=>o.Cs.getDocumentsMatchingQuery(s,e,t?r:ne.min(),t?i:fe())).next(c=>(eE(o,q0(e),c),{documents:c,ks:i})))}function eE(n,e,t){let o=n.Ms.get(e)||ne.min();t.forEach((r,i)=>{i.readTime.compareTo(o)>0&&(o=i.readTime)}),n.Ms.set(e,o)}class If{constructor(){this.activeTargetIds=H0()}Qs(e){this.activeTargetIds=this.activeTargetIds.add(e)}Gs(e){this.activeTargetIds=this.activeTargetIds.delete(e)}Ws(){const e={activeTargetIds:this.activeTargetIds.toArray(),updateTimeMs:Date.now()};return JSON.stringify(e)}}class tE{constructor(){this.vo=new If,this.Fo={},this.onlineStateHandler=null,this.sequenceNumberHandler=null}addPendingMutation(e){}updateMutationState(e,t,o){}addLocalQueryTarget(e,t=!0){return t&&this.vo.Qs(e),this.Fo[e]||"not-current"}updateQueryState(e,t,o){this.Fo[e]=t}removeLocalQueryTarget(e){this.vo.Gs(e)}isLocalQueryTarget(e){return this.vo.activeTargetIds.has(e)}clearQueryState(e){delete this.Fo[e]}getAllActiveQueryTargets(){return this.vo.activeTargetIds}isActiveQueryTarget(e){return this.vo.activeTargetIds.has(e)}start(){return this.vo=new If,Promise.resolve()}handleUserChange(e,t,o){}setOnlineState(e){}shutdown(){}writeSequenceNumber(e){}notifyBundleLoaded(e){}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class nE{Mo(e){}shutdown(){}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const xf="ConnectivityMonitor";class Sf{constructor(){this.xo=()=>this.Oo(),this.No=()=>this.Bo(),this.Lo=[],this.ko()}Mo(e){this.Lo.push(e)}shutdown(){window.removeEventListener("online",this.xo),window.removeEventListener("offline",this.No)}ko(){window.addEventListener("online",this.xo),window.addEventListener("offline",this.No)}Oo(){Y(xf,"Network connectivity changed: AVAILABLE");for(const e of this.Lo)e(0)}Bo(){Y(xf,"Network connectivity changed: UNAVAILABLE");for(const e of this.Lo)e(1)}static v(){return typeof window<"u"&&window.addEventListener!==void 0&&window.removeEventListener!==void 0}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Js=null;function Pc(){return Js===null?Js=function(){return 268435456+Math.round(2147483648*Math.random())}():Js++,"0x"+Js.toString(16)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Xl="RestConnection",oE={BatchGetDocuments:"batchGet",Commit:"commit",RunQuery:"runQuery",RunAggregationQuery:"runAggregationQuery",ExecutePipeline:"executePipeline"};class rE{get qo(){return!1}constructor(e){this.databaseInfo=e,this.databaseId=e.databaseId;const t=e.ssl?"https":"http",o=encodeURIComponent(this.databaseId.projectId),r=encodeURIComponent(this.databaseId.database);this.Ko=t+"://"+e.host,this.Uo=`projects/${o}/databases/${r}`,this.$o=this.databaseId.database===Ma?`project_id=${o}`:`project_id=${o}&database_id=${r}`}Wo(e,t,o,r,i){const s=Pc(),c=this.Qo(e,t.toUriEncodedString());Y(Xl,`Sending RPC '${e}' ${s}:`,c,o);const d={"google-cloud-resource-prefix":this.Uo,"x-goog-request-params":this.$o};this.Go(d,r,i);const{host:u}=new URL(c),f=_s(u);return this.zo(e,c,d,o,f).then(g=>(Y(Xl,`Received RPC '${e}' ${s}: `,g),g),g=>{throw Yo(Xl,`RPC '${e}' ${s} failed with error: `,g,"url: ",c,"request:",o),g})}jo(e,t,o,r,i,s){return this.Wo(e,t,o,r,i)}Go(e,t,o){e["X-Goog-Api-Client"]=function(){return"gl-js/ fire/"+Kr}(),e["Content-Type"]="text/plain",this.databaseInfo.appId&&(e["X-Firebase-GMPID"]=this.databaseInfo.appId),t&&t.headers.forEach((r,i)=>e[i]=r),o&&o.headers.forEach((r,i)=>e[i]=r)}Qo(e,t){const o=oE[e];let r=`${this.Ko}/v1/${t}:${o}`;return this.databaseInfo.apiKey&&(r=`${r}?key=${encodeURIComponent(this.databaseInfo.apiKey)}`),r}terminate(){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class iE{constructor(e){this.Jo=e.Jo,this.Ho=e.Ho}Zo(e){this.Xo=e}Yo(e){this.e_=e}t_(e){this.n_=e}onMessage(e){this.r_=e}close(){this.Ho()}send(e){this.Jo(e)}i_(){this.Xo()}s_(){this.e_()}o_(e){this.n_(e)}__(e){this.r_(e)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ct="WebChannelConnection",Ii=(n,e,t)=>{n.listen(e,o=>{try{t(o)}catch(r){setTimeout(()=>{throw r},0)}})};class Tr extends rE{constructor(e){super(e),this.a_=[],this.forceLongPolling=e.forceLongPolling,this.autoDetectLongPolling=e.autoDetectLongPolling,this.useFetchStreams=e.useFetchStreams,this.longPollingOptions=e.longPollingOptions}static u_(){if(!Tr.c_){const e=_g();Ii(e,wg.STAT_EVENT,t=>{t.stat===vc.PROXY?Y(ct,"STAT_EVENT: detected buffering proxy"):t.stat===vc.NOPROXY&&Y(ct,"STAT_EVENT: detected no buffering proxy")}),Tr.c_=!0}}zo(e,t,o,r,i){const s=Pc();return new Promise((c,d)=>{const u=new vg;u.setWithCredentials(!0),u.listenOnce(bg.COMPLETE,()=>{try{switch(u.getLastErrorCode()){case pa.NO_ERROR:const g=u.getResponseJson();Y(ct,`XHR for RPC '${e}' ${s} received:`,JSON.stringify(g)),c(g);break;case pa.TIMEOUT:Y(ct,`RPC '${e}' ${s} timed out`),d(new G(F.DEADLINE_EXCEEDED,"Request time out"));break;case pa.HTTP_ERROR:const m=u.getStatus();if(Y(ct,`RPC '${e}' ${s} failed with status:`,m,"response text:",u.getResponseText()),m>0){let v=u.getResponseJson();Array.isArray(v)&&(v=v[0]);const O=v==null?void 0:v.error;if(O&&O.status&&O.message){const C=function(H){const z=H.toLowerCase().replace(/_/g,"-");return Object.values(F).indexOf(z)>=0?z:F.UNKNOWN}(O.status);d(new G(C,O.message))}else d(new G(F.UNKNOWN,"Server responded with status "+u.getStatus()))}else d(new G(F.UNAVAILABLE,"Connection failed."));break;default:ee(9055,{l_:e,streamId:s,h_:u.getLastErrorCode(),P_:u.getLastError()})}}finally{Y(ct,`RPC '${e}' ${s} completed.`)}});const f=JSON.stringify(r);Y(ct,`RPC '${e}' ${s} sending request:`,r),u.send(t,"POST",f,o,15)})}T_(e,t,o){const r=Pc(),i=[this.Ko,"/","google.firestore.v1.Firestore","/",e,"/channel"],s=this.createWebChannelTransport(),c={httpSessionIdParam:"gsessionid",initMessageHeaders:{},messageUrlParams:{database:`projects/${this.databaseId.projectId}/databases/${this.databaseId.database}`},sendRawJson:!0,supportsCrossDomainXhr:!0,internalChannelParams:{forwardChannelRequestTimeoutMs:6e5},forceLongPolling:this.forceLongPolling,detectBufferingProxy:this.autoDetectLongPolling},d=this.longPollingOptions.timeoutSeconds;d!==void 0&&(c.longPollingTimeout=Math.round(1e3*d)),this.useFetchStreams&&(c.useFetchStreams=!0),this.Go(c.initMessageHeaders,t,o),c.encodeInitMessageHeaders=!0;const u=i.join("");Y(ct,`Creating RPC '${e}' stream ${r}: ${u}`,c);const f=s.createWebChannel(u,c);this.E_(f);let g=!1,m=!1;const v=new iE({Jo:O=>{m?Y(ct,`Not sending because RPC '${e}' stream ${r} is closed:`,O):(g||(Y(ct,`Opening RPC '${e}' stream ${r} transport.`),f.open(),g=!0),Y(ct,`RPC '${e}' stream ${r} sending:`,O),f.send(O))},Ho:()=>f.close()});return Ii(f,Mi.EventType.OPEN,()=>{m||(Y(ct,`RPC '${e}' stream ${r} transport opened.`),v.i_())}),Ii(f,Mi.EventType.CLOSE,()=>{m||(m=!0,Y(ct,`RPC '${e}' stream ${r} transport closed`),v.o_(),this.I_(f))}),Ii(f,Mi.EventType.ERROR,O=>{m||(m=!0,Yo(ct,`RPC '${e}' stream ${r} transport errored. Name:`,O.name,"Message:",O.message),v.o_(new G(F.UNAVAILABLE,"The operation could not be completed")))}),Ii(f,Mi.EventType.MESSAGE,O=>{var C;if(!m){const L=O.data[0];be(!!L,16349);const H=L,z=(H==null?void 0:H.error)||((C=H[0])==null?void 0:C.error);if(z){Y(ct,`RPC '${e}' stream ${r} received error:`,z);const N=z.status;let $=function(E){const w=qe[E];if(w!==void 0)return rm(w)}(N),j=z.message;N==="NOT_FOUND"&&j.includes("database")&&j.includes("does not exist")&&j.includes(this.databaseId.database)&&Yo(`Database '${this.databaseId.database}' not found. Please check your project configuration.`),$===void 0&&($=F.INTERNAL,j="Unknown error status: "+N+" with message "+z.message),m=!0,v.o_(new G($,j)),f.close()}else Y(ct,`RPC '${e}' stream ${r} received:`,L),v.__(L)}}),Tr.u_(),setTimeout(()=>{v.s_()},0),v}terminate(){this.a_.forEach(e=>e.close()),this.a_=[]}E_(e){this.a_.push(e)}I_(e){this.a_=this.a_.filter(t=>t===e)}Go(e,t,o){super.Go(e,t,o),this.databaseInfo.apiKey&&(e["x-goog-api-key"]=this.databaseInfo.apiKey)}createWebChannelTransport(){return Tg()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function sE(n){return new Tr(n)}function Ql(){return typeof document<"u"?document:null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function gl(n){return new uT(n,!0)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */Tr.c_=!1;class bm{constructor(e,t,o=1e3,r=1.5,i=6e4){this.Ci=e,this.timerId=t,this.R_=o,this.A_=r,this.V_=i,this.d_=0,this.m_=null,this.f_=Date.now(),this.reset()}reset(){this.d_=0}g_(){this.d_=this.V_}p_(e){this.cancel();const t=Math.floor(this.d_+this.y_()),o=Math.max(0,Date.now()-this.f_),r=Math.max(0,t-o);r>0&&Y("ExponentialBackoff",`Backing off for ${r} ms (base delay: ${this.d_} ms, delay with jitter: ${t} ms, last attempt: ${o} ms ago)`),this.m_=this.Ci.enqueueAfterDelay(this.timerId,r,()=>(this.f_=Date.now(),e())),this.d_*=this.A_,this.d_<this.R_&&(this.d_=this.R_),this.d_>this.V_&&(this.d_=this.V_)}w_(){this.m_!==null&&(this.m_.skipDelay(),this.m_=null)}cancel(){this.m_!==null&&(this.m_.cancel(),this.m_=null)}y_(){return(Math.random()-.5)*this.d_}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Af="PersistentStream";class wm{constructor(e,t,o,r,i,s,c,d){this.Ci=e,this.S_=o,this.b_=r,this.connection=i,this.authCredentialsProvider=s,this.appCheckCredentialsProvider=c,this.listener=d,this.state=0,this.D_=0,this.C_=null,this.v_=null,this.stream=null,this.F_=0,this.M_=new bm(e,t)}x_(){return this.state===1||this.state===5||this.O_()}O_(){return this.state===2||this.state===3}start(){this.F_=0,this.state!==4?this.auth():this.N_()}async stop(){this.x_()&&await this.close(0)}B_(){this.state=0,this.M_.reset()}L_(){this.O_()&&this.C_===null&&(this.C_=this.Ci.enqueueAfterDelay(this.S_,6e4,()=>this.k_()))}q_(e){this.K_(),this.stream.send(e)}async k_(){if(this.O_())return this.close(0)}K_(){this.C_&&(this.C_.cancel(),this.C_=null)}U_(){this.v_&&(this.v_.cancel(),this.v_=null)}async close(e,t){this.K_(),this.U_(),this.M_.cancel(),this.D_++,e!==4?this.M_.reset():t&&t.code===F.RESOURCE_EXHAUSTED?(Dn(t.toString()),Dn("Using maximum backoff delay to prevent overloading the backend."),this.M_.g_()):t&&t.code===F.UNAUTHENTICATED&&this.state!==3&&(this.authCredentialsProvider.invalidateToken(),this.appCheckCredentialsProvider.invalidateToken()),this.stream!==null&&(this.W_(),this.stream.close(),this.stream=null),this.state=e,await this.listener.t_(t)}W_(){}auth(){this.state=1;const e=this.Q_(this.D_),t=this.D_;Promise.all([this.authCredentialsProvider.getToken(),this.appCheckCredentialsProvider.getToken()]).then(([o,r])=>{this.D_===t&&this.G_(o,r)},o=>{e(()=>{const r=new G(F.UNKNOWN,"Fetching auth token failed: "+o.message);return this.z_(r)})})}G_(e,t){const o=this.Q_(this.D_);this.stream=this.j_(e,t),this.stream.Zo(()=>{o(()=>this.listener.Zo())}),this.stream.Yo(()=>{o(()=>(this.state=2,this.v_=this.Ci.enqueueAfterDelay(this.b_,1e4,()=>(this.O_()&&(this.state=3),Promise.resolve())),this.listener.Yo()))}),this.stream.t_(r=>{o(()=>this.z_(r))}),this.stream.onMessage(r=>{o(()=>++this.F_==1?this.J_(r):this.onNext(r))})}N_(){this.state=5,this.M_.p_(async()=>{this.state=0,this.start()})}z_(e){return Y(Af,`close with error: ${e}`),this.stream=null,this.close(4,e)}Q_(e){return t=>{this.Ci.enqueueAndForget(()=>this.D_===e?t():(Y(Af,"stream callback skipped by getCloseGuardedDispatcher."),Promise.resolve()))}}}class aE extends wm{constructor(e,t,o,r,i,s){super(e,"listen_stream_connection_backoff","listen_stream_idle","health_check_timeout",t,o,r,s),this.serializer=i}j_(e,t){return this.connection.T_("Listen",e,t)}J_(e){return this.onNext(e)}onNext(e){this.M_.reset();const t=fT(this.serializer,e),o=function(i){if(!("targetChange"in i))return ne.min();const s=i.targetChange;return s.targetIds&&s.targetIds.length?ne.min():s.readTime?dn(s.readTime):ne.min()}(e);return this.listener.H_(t,o)}Z_(e){const t={};t.database=kc(this.serializer),t.addTarget=function(i,s){let c;const d=s.target;if(c=Ec(d)?{documents:mT(i,d)}:{query:yT(i,d).ft},c.targetId=s.targetId,s.resumeToken.approximateByteSize()>0){c.resumeToken=am(i,s.resumeToken);const u=xc(i,s.expectedCount);u!==null&&(c.expectedCount=u)}else if(s.snapshotVersion.compareTo(ne.min())>0){c.readTime=Va(i,s.snapshotVersion.toTimestamp());const u=xc(i,s.expectedCount);u!==null&&(c.expectedCount=u)}return c}(this.serializer,e);const o=bT(this.serializer,e);o&&(t.labels=o),this.q_(t)}X_(e){const t={};t.database=kc(this.serializer),t.removeTarget=e,this.q_(t)}}class lE extends wm{constructor(e,t,o,r,i,s){super(e,"write_stream_connection_backoff","write_stream_idle","health_check_timeout",t,o,r,s),this.serializer=i}get Y_(){return this.F_>0}start(){this.lastStreamToken=void 0,super.start()}W_(){this.Y_&&this.ea([])}j_(e,t){return this.connection.T_("Write",e,t)}J_(e){return be(!!e.streamToken,31322),this.lastStreamToken=e.streamToken,be(!e.writeResults||e.writeResults.length===0,55816),this.listener.ta()}onNext(e){be(!!e.streamToken,12678),this.lastStreamToken=e.streamToken,this.M_.reset();const t=gT(e.writeResults,e.commitTime),o=dn(e.commitTime);return this.listener.na(o,t)}ra(){const e={};e.database=kc(this.serializer),this.q_(e)}ea(e){const t={streamToken:this.lastStreamToken,writes:e.map(o=>pT(this.serializer,o))};this.q_(t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class cE{}class uE extends cE{constructor(e,t,o,r){super(),this.authCredentials=e,this.appCheckCredentials=t,this.connection=o,this.serializer=r,this.ia=!1}sa(){if(this.ia)throw new G(F.FAILED_PRECONDITION,"The client has already been terminated.")}Wo(e,t,o,r){return this.sa(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then(([i,s])=>this.connection.Wo(e,Sc(t,o),r,i,s)).catch(i=>{throw i.name==="FirebaseError"?(i.code===F.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),i):new G(F.UNKNOWN,i.toString())})}jo(e,t,o,r,i){return this.sa(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then(([s,c])=>this.connection.jo(e,Sc(t,o),r,s,c,i)).catch(s=>{throw s.name==="FirebaseError"?(s.code===F.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),s):new G(F.UNKNOWN,s.toString())})}terminate(){this.ia=!0,this.connection.terminate()}}function dE(n,e,t,o){return new uE(n,e,t,o)}class hE{constructor(e,t){this.asyncQueue=e,this.onlineStateHandler=t,this.state="Unknown",this.oa=0,this._a=null,this.aa=!0}ua(){this.oa===0&&(this.ca("Unknown"),this._a=this.asyncQueue.enqueueAfterDelay("online_state_timeout",1e4,()=>(this._a=null,this.la("Backend didn't respond within 10 seconds."),this.ca("Offline"),Promise.resolve())))}ha(e){this.state==="Online"?this.ca("Unknown"):(this.oa++,this.oa>=1&&(this.Pa(),this.la(`Connection failed 1 times. Most recent error: ${e.toString()}`),this.ca("Offline")))}set(e){this.Pa(),this.oa=0,e==="Online"&&(this.aa=!1),this.ca(e)}ca(e){e!==this.state&&(this.state=e,this.onlineStateHandler(e))}la(e){const t=`Could not reach Cloud Firestore backend. ${e}
This typically indicates that your device does not have a healthy Internet connection at the moment. The client will operate in offline mode until it is able to successfully connect to the backend.`;this.aa?(Dn(t),this.aa=!1):Y("OnlineStateTracker",t)}Pa(){this._a!==null&&(this._a.cancel(),this._a=null)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ko="RemoteStore";class fE{constructor(e,t,o,r,i){this.localStore=e,this.datastore=t,this.asyncQueue=o,this.remoteSyncer={},this.Ta=[],this.Ea=new Map,this.Ia=new Set,this.Ra=[],this.Aa=i,this.Aa.Mo(s=>{o.enqueueAndForget(async()=>{nr(this)&&(Y(Ko,"Restarting streams for network reachability change."),await async function(d){const u=oe(d);u.Ia.add(4),await ks(u),u.Va.set("Unknown"),u.Ia.delete(4),await ml(u)}(this))})}),this.Va=new hE(o,r)}}async function ml(n){if(nr(n))for(const e of n.Ra)await e(!0)}async function ks(n){for(const e of n.Ra)await e(!1)}function _m(n,e){const t=oe(n);t.Ea.has(e.targetId)||(t.Ea.set(e.targetId,e),Fu(t)?Vu(t):Zr(t).O_()&&Du(t,e))}function Lu(n,e){const t=oe(n),o=Zr(t);t.Ea.delete(e),o.O_()&&Tm(t,e),t.Ea.size===0&&(o.O_()?o.L_():nr(t)&&t.Va.set("Unknown"))}function Du(n,e){if(n.da.$e(e.targetId),e.resumeToken.approximateByteSize()>0||e.snapshotVersion.compareTo(ne.min())>0){const t=n.remoteSyncer.getRemoteKeysForTarget(e.targetId).size;e=e.withExpectedCount(t)}Zr(n).Z_(e)}function Tm(n,e){n.da.$e(e),Zr(n).X_(e)}function Vu(n){n.da=new sT({getRemoteKeysForTarget:e=>n.remoteSyncer.getRemoteKeysForTarget(e),At:e=>n.Ea.get(e)||null,ht:()=>n.datastore.serializer.databaseId}),Zr(n).start(),n.Va.ua()}function Fu(n){return nr(n)&&!Zr(n).x_()&&n.Ea.size>0}function nr(n){return oe(n).Ia.size===0}function Em(n){n.da=void 0}async function pE(n){n.Va.set("Online")}async function gE(n){n.Ea.forEach((e,t)=>{Du(n,e)})}async function mE(n,e){Em(n),Fu(n)?(n.Va.ha(e),Vu(n)):n.Va.set("Unknown")}async function yE(n,e,t){if(n.Va.set("Online"),e instanceof sm&&e.state===2&&e.cause)try{await async function(r,i){const s=i.cause;for(const c of i.targetIds)r.Ea.has(c)&&(await r.remoteSyncer.rejectListen(c,s),r.Ea.delete(c),r.da.removeTarget(c))}(n,e)}catch(o){Y(Ko,"Failed to remove targets %s: %s ",e.targetIds.join(","),o),await Ua(n,o)}else if(e instanceof va?n.da.Xe(e):e instanceof im?n.da.st(e):n.da.tt(e),!t.isEqual(ne.min()))try{const o=await vm(n.localStore);t.compareTo(o)>=0&&await function(i,s){const c=i.da.Tt(s);return c.targetChanges.forEach((d,u)=>{if(d.resumeToken.approximateByteSize()>0){const f=i.Ea.get(u);f&&i.Ea.set(u,f.withResumeToken(d.resumeToken,s))}}),c.targetMismatches.forEach((d,u)=>{const f=i.Ea.get(d);if(!f)return;i.Ea.set(d,f.withResumeToken(lt.EMPTY_BYTE_STRING,f.snapshotVersion)),Tm(i,d);const g=new to(f.target,d,u,f.sequenceNumber);Du(i,g)}),i.remoteSyncer.applyRemoteEvent(c)}(n,t)}catch(o){Y(Ko,"Failed to raise snapshot:",o),await Ua(n,o)}}async function Ua(n,e,t){if(!Qr(e))throw e;n.Ia.add(1),await ks(n),n.Va.set("Offline"),t||(t=()=>vm(n.localStore)),n.asyncQueue.enqueueRetryable(async()=>{Y(Ko,"Retrying IndexedDB access"),await t(),n.Ia.delete(1),await ml(n)})}function Im(n,e){return e().catch(t=>Ua(n,t,e))}async function yl(n){const e=oe(n),t=mo(e);let o=e.Ta.length>0?e.Ta[e.Ta.length-1].batchId:_u;for(;vE(e);)try{const r=await JT(e.localStore,o);if(r===null){e.Ta.length===0&&t.L_();break}o=r.batchId,bE(e,r)}catch(r){await Ua(e,r)}xm(e)&&Sm(e)}function vE(n){return nr(n)&&n.Ta.length<10}function bE(n,e){n.Ta.push(e);const t=mo(n);t.O_()&&t.Y_&&t.ea(e.mutations)}function xm(n){return nr(n)&&!mo(n).x_()&&n.Ta.length>0}function Sm(n){mo(n).start()}async function wE(n){mo(n).ra()}async function _E(n){const e=mo(n);for(const t of n.Ta)e.ea(t.mutations)}async function TE(n,e,t){const o=n.Ta.shift(),r=ku.from(o,e,t);await Im(n,()=>n.remoteSyncer.applySuccessfulWrite(r)),await yl(n)}async function EE(n,e){e&&mo(n).Y_&&await async function(o,r){if(function(s){return oT(s)&&s!==F.ABORTED}(r.code)){const i=o.Ta.shift();mo(o).B_(),await Im(o,()=>o.remoteSyncer.rejectFailedWrite(i.batchId,r)),await yl(o)}}(n,e),xm(n)&&Sm(n)}async function kf(n,e){const t=oe(n);t.asyncQueue.verifyOperationInProgress(),Y(Ko,"RemoteStore received new credentials");const o=nr(t);t.Ia.add(3),await ks(t),o&&t.Va.set("Unknown"),await t.remoteSyncer.handleCredentialChange(e),t.Ia.delete(3),await ml(t)}async function IE(n,e){const t=oe(n);e?(t.Ia.delete(2),await ml(t)):e||(t.Ia.add(2),await ks(t),t.Va.set("Unknown"))}function Zr(n){return n.ma||(n.ma=function(t,o,r){const i=oe(t);return i.sa(),new aE(o,i.connection,i.authCredentials,i.appCheckCredentials,i.serializer,r)}(n.datastore,n.asyncQueue,{Zo:pE.bind(null,n),Yo:gE.bind(null,n),t_:mE.bind(null,n),H_:yE.bind(null,n)}),n.Ra.push(async e=>{e?(n.ma.B_(),Fu(n)?Vu(n):n.Va.set("Unknown")):(await n.ma.stop(),Em(n))})),n.ma}function mo(n){return n.fa||(n.fa=function(t,o,r){const i=oe(t);return i.sa(),new lE(o,i.connection,i.authCredentials,i.appCheckCredentials,i.serializer,r)}(n.datastore,n.asyncQueue,{Zo:()=>Promise.resolve(),Yo:wE.bind(null,n),t_:EE.bind(null,n),ta:_E.bind(null,n),na:TE.bind(null,n)}),n.Ra.push(async e=>{e?(n.fa.B_(),await yl(n)):(await n.fa.stop(),n.Ta.length>0&&(Y(Ko,`Stopping write stream with ${n.Ta.length} pending writes`),n.Ta=[]))})),n.fa}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Uu{constructor(e,t,o,r,i){this.asyncQueue=e,this.timerId=t,this.targetTimeMs=o,this.op=r,this.removalCallback=i,this.deferred=new Pn,this.then=this.deferred.promise.then.bind(this.deferred.promise),this.deferred.promise.catch(s=>{})}get promise(){return this.deferred.promise}static createAndSchedule(e,t,o,r,i){const s=Date.now()+o,c=new Uu(e,t,s,r,i);return c.start(o),c}start(e){this.timerHandle=setTimeout(()=>this.handleDelayElapsed(),e)}skipDelay(){return this.handleDelayElapsed()}cancel(e){this.timerHandle!==null&&(this.clearTimeout(),this.deferred.reject(new G(F.CANCELLED,"Operation cancelled"+(e?": "+e:""))))}handleDelayElapsed(){this.asyncQueue.enqueueAndForget(()=>this.timerHandle!==null?(this.clearTimeout(),this.op().then(e=>this.deferred.resolve(e))):Promise.resolve())}clearTimeout(){this.timerHandle!==null&&(this.removalCallback(this),clearTimeout(this.timerHandle),this.timerHandle=null)}}function qu(n,e){if(Dn("AsyncQueue",`${e}: ${n}`),Qr(n))return new G(F.UNAVAILABLE,`${e}: ${n}`);throw n}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Er{static emptySet(e){return new Er(e.comparator)}constructor(e){this.comparator=e?(t,o)=>e(t,o)||Q.comparator(t.key,o.key):(t,o)=>Q.comparator(t.key,o.key),this.keyedMap=Ni(),this.sortedSet=new Ne(this.comparator)}has(e){return this.keyedMap.get(e)!=null}get(e){return this.keyedMap.get(e)}first(){return this.sortedSet.minKey()}last(){return this.sortedSet.maxKey()}isEmpty(){return this.sortedSet.isEmpty()}indexOf(e){const t=this.keyedMap.get(e);return t?this.sortedSet.indexOf(t):-1}get size(){return this.sortedSet.size}forEach(e){this.sortedSet.inorderTraversal((t,o)=>(e(t),!1))}add(e){const t=this.delete(e.key);return t.copy(t.keyedMap.insert(e.key,e),t.sortedSet.insert(e,null))}delete(e){const t=this.get(e);return t?this.copy(this.keyedMap.remove(e),this.sortedSet.remove(t)):this}isEqual(e){if(!(e instanceof Er)||this.size!==e.size)return!1;const t=this.sortedSet.getIterator(),o=e.sortedSet.getIterator();for(;t.hasNext();){const r=t.getNext().key,i=o.getNext().key;if(!r.isEqual(i))return!1}return!0}toString(){const e=[];return this.forEach(t=>{e.push(t.toString())}),e.length===0?"DocumentSet ()":`DocumentSet (
  `+e.join(`  
`)+`
)`}copy(e,t){const o=new Er;return o.comparator=this.comparator,o.keyedMap=e,o.sortedSet=t,o}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Cf{constructor(){this.ga=new Ne(Q.comparator)}track(e){const t=e.doc.key,o=this.ga.get(t);o?e.type!==0&&o.type===3?this.ga=this.ga.insert(t,e):e.type===3&&o.type!==1?this.ga=this.ga.insert(t,{type:o.type,doc:e.doc}):e.type===2&&o.type===2?this.ga=this.ga.insert(t,{type:2,doc:e.doc}):e.type===2&&o.type===0?this.ga=this.ga.insert(t,{type:0,doc:e.doc}):e.type===1&&o.type===0?this.ga=this.ga.remove(t):e.type===1&&o.type===2?this.ga=this.ga.insert(t,{type:1,doc:o.doc}):e.type===0&&o.type===1?this.ga=this.ga.insert(t,{type:2,doc:e.doc}):ee(63341,{Vt:e,pa:o}):this.ga=this.ga.insert(t,e)}ya(){const e=[];return this.ga.inorderTraversal((t,o)=>{e.push(o)}),e}}class qr{constructor(e,t,o,r,i,s,c,d,u){this.query=e,this.docs=t,this.oldDocs=o,this.docChanges=r,this.mutatedKeys=i,this.fromCache=s,this.syncStateChanged=c,this.excludesMetadataChanges=d,this.hasCachedResults=u}static fromInitialDocuments(e,t,o,r,i){const s=[];return t.forEach(c=>{s.push({type:0,doc:c})}),new qr(e,t,Er.emptySet(t),s,o,r,!0,!1,i)}get hasPendingWrites(){return!this.mutatedKeys.isEmpty()}isEqual(e){if(!(this.fromCache===e.fromCache&&this.hasCachedResults===e.hasCachedResults&&this.syncStateChanged===e.syncStateChanged&&this.mutatedKeys.isEqual(e.mutatedKeys)&&ul(this.query,e.query)&&this.docs.isEqual(e.docs)&&this.oldDocs.isEqual(e.oldDocs)))return!1;const t=this.docChanges,o=e.docChanges;if(t.length!==o.length)return!1;for(let r=0;r<t.length;r++)if(t[r].type!==o[r].type||!t[r].doc.isEqual(o[r].doc))return!1;return!0}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xE{constructor(){this.wa=void 0,this.Sa=[]}ba(){return this.Sa.some(e=>e.Da())}}class SE{constructor(){this.queries=Pf(),this.onlineState="Unknown",this.Ca=new Set}terminate(){(function(t,o){const r=oe(t),i=r.queries;r.queries=Pf(),i.forEach((s,c)=>{for(const d of c.Sa)d.onError(o)})})(this,new G(F.ABORTED,"Firestore shutting down"))}}function Pf(){return new tr(n=>jg(n),ul)}async function zu(n,e){const t=oe(n);let o=3;const r=e.query;let i=t.queries.get(r);i?!i.ba()&&e.Da()&&(o=2):(i=new xE,o=e.Da()?0:1);try{switch(o){case 0:i.wa=await t.onListen(r,!0);break;case 1:i.wa=await t.onListen(r,!1);break;case 2:await t.onFirstRemoteStoreListen(r)}}catch(s){const c=qu(s,`Initialization of query '${hr(e.query)}' failed`);return void e.onError(c)}t.queries.set(r,i),i.Sa.push(e),e.va(t.onlineState),i.wa&&e.Fa(i.wa)&&$u(t)}async function Bu(n,e){const t=oe(n),o=e.query;let r=3;const i=t.queries.get(o);if(i){const s=i.Sa.indexOf(e);s>=0&&(i.Sa.splice(s,1),i.Sa.length===0?r=e.Da()?0:1:!i.ba()&&e.Da()&&(r=2))}switch(r){case 0:return t.queries.delete(o),t.onUnlisten(o,!0);case 1:return t.queries.delete(o),t.onUnlisten(o,!1);case 2:return t.onLastRemoteStoreUnlisten(o);default:return}}function AE(n,e){const t=oe(n);let o=!1;for(const r of e){const i=r.query,s=t.queries.get(i);if(s){for(const c of s.Sa)c.Fa(r)&&(o=!0);s.wa=r}}o&&$u(t)}function kE(n,e,t){const o=oe(n),r=o.queries.get(e);if(r)for(const i of r.Sa)i.onError(t);o.queries.delete(e)}function $u(n){n.Ca.forEach(e=>{e.next()})}var Rc,Rf;(Rf=Rc||(Rc={})).Ma="default",Rf.Cache="cache";class ju{constructor(e,t,o){this.query=e,this.xa=t,this.Oa=!1,this.Na=null,this.onlineState="Unknown",this.options=o||{}}Fa(e){if(!this.options.includeMetadataChanges){const o=[];for(const r of e.docChanges)r.type!==3&&o.push(r);e=new qr(e.query,e.docs,e.oldDocs,o,e.mutatedKeys,e.fromCache,e.syncStateChanged,!0,e.hasCachedResults)}let t=!1;return this.Oa?this.Ba(e)&&(this.xa.next(e),t=!0):this.La(e,this.onlineState)&&(this.ka(e),t=!0),this.Na=e,t}onError(e){this.xa.error(e)}va(e){this.onlineState=e;let t=!1;return this.Na&&!this.Oa&&this.La(this.Na,e)&&(this.ka(this.Na),t=!0),t}La(e,t){if(!e.fromCache||!this.Da())return!0;const o=t!=="Offline";return(!this.options.qa||!o)&&(!e.docs.isEmpty()||e.hasCachedResults||t==="Offline")}Ba(e){if(e.docChanges.length>0)return!0;const t=this.Na&&this.Na.hasPendingWrites!==e.hasPendingWrites;return!(!e.syncStateChanged&&!t)&&this.options.includeMetadataChanges===!0}ka(e){e=qr.fromInitialDocuments(e.query,e.docs,e.mutatedKeys,e.fromCache,e.hasCachedResults),this.Oa=!0,this.xa.next(e)}Da(){return this.options.source!==Rc.Cache}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Am{constructor(e){this.key=e}}class km{constructor(e){this.key=e}}class CE{constructor(e,t){this.query=e,this.Za=t,this.Xa=null,this.hasCachedResults=!1,this.current=!1,this.Ya=fe(),this.mutatedKeys=fe(),this.eu=Wg(e),this.tu=new Er(this.eu)}get nu(){return this.Za}ru(e,t){const o=t?t.iu:new Cf,r=t?t.tu:this.tu;let i=t?t.mutatedKeys:this.mutatedKeys,s=r,c=!1;const d=this.query.limitType==="F"&&r.size===this.query.limit?r.last():null,u=this.query.limitType==="L"&&r.size===this.query.limit?r.first():null;if(e.inorderTraversal((f,g)=>{const m=r.get(f),v=dl(this.query,g)?g:null,O=!!m&&this.mutatedKeys.has(m.key),C=!!v&&(v.hasLocalMutations||this.mutatedKeys.has(v.key)&&v.hasCommittedMutations);let L=!1;m&&v?m.data.isEqual(v.data)?O!==C&&(o.track({type:3,doc:v}),L=!0):this.su(m,v)||(o.track({type:2,doc:v}),L=!0,(d&&this.eu(v,d)>0||u&&this.eu(v,u)<0)&&(c=!0)):!m&&v?(o.track({type:0,doc:v}),L=!0):m&&!v&&(o.track({type:1,doc:m}),L=!0,(d||u)&&(c=!0)),L&&(v?(s=s.add(v),i=C?i.add(f):i.delete(f)):(s=s.delete(f),i=i.delete(f)))}),this.query.limit!==null)for(;s.size>this.query.limit;){const f=this.query.limitType==="F"?s.last():s.first();s=s.delete(f.key),i=i.delete(f.key),o.track({type:1,doc:f})}return{tu:s,iu:o,bs:c,mutatedKeys:i}}su(e,t){return e.hasLocalMutations&&t.hasCommittedMutations&&!t.hasLocalMutations}applyChanges(e,t,o,r){const i=this.tu;this.tu=e.tu,this.mutatedKeys=e.mutatedKeys;const s=e.iu.ya();s.sort((f,g)=>function(v,O){const C=L=>{switch(L){case 0:return 1;case 2:case 3:return 2;case 1:return 0;default:return ee(20277,{Vt:L})}};return C(v)-C(O)}(f.type,g.type)||this.eu(f.doc,g.doc)),this.ou(o),r=r??!1;const c=t&&!r?this._u():[],d=this.Ya.size===0&&this.current&&!r?1:0,u=d!==this.Xa;return this.Xa=d,s.length!==0||u?{snapshot:new qr(this.query,e.tu,i,s,e.mutatedKeys,d===0,u,!1,!!o&&o.resumeToken.approximateByteSize()>0),au:c}:{au:c}}va(e){return this.current&&e==="Offline"?(this.current=!1,this.applyChanges({tu:this.tu,iu:new Cf,mutatedKeys:this.mutatedKeys,bs:!1},!1)):{au:[]}}uu(e){return!this.Za.has(e)&&!!this.tu.has(e)&&!this.tu.get(e).hasLocalMutations}ou(e){e&&(e.addedDocuments.forEach(t=>this.Za=this.Za.add(t)),e.modifiedDocuments.forEach(t=>{}),e.removedDocuments.forEach(t=>this.Za=this.Za.delete(t)),this.current=e.current)}_u(){if(!this.current)return[];const e=this.Ya;this.Ya=fe(),this.tu.forEach(o=>{this.uu(o.key)&&(this.Ya=this.Ya.add(o.key))});const t=[];return e.forEach(o=>{this.Ya.has(o)||t.push(new km(o))}),this.Ya.forEach(o=>{e.has(o)||t.push(new Am(o))}),t}cu(e){this.Za=e.ks,this.Ya=fe();const t=this.ru(e.documents);return this.applyChanges(t,!0)}lu(){return qr.fromInitialDocuments(this.query,this.tu,this.mutatedKeys,this.Xa===0,this.hasCachedResults)}}const Wu="SyncEngine";class PE{constructor(e,t,o){this.query=e,this.targetId=t,this.view=o}}class RE{constructor(e){this.key=e,this.hu=!1}}class OE{constructor(e,t,o,r,i,s){this.localStore=e,this.remoteStore=t,this.eventManager=o,this.sharedClientState=r,this.currentUser=i,this.maxConcurrentLimboResolutions=s,this.Pu={},this.Tu=new tr(c=>jg(c),ul),this.Eu=new Map,this.Iu=new Set,this.Ru=new Ne(Q.comparator),this.Au=new Map,this.Vu=new Ru,this.du={},this.mu=new Map,this.fu=Ur.ar(),this.onlineState="Unknown",this.gu=void 0}get isPrimaryClient(){return this.gu===!0}}async function ME(n,e,t=!0){const o=Nm(n);let r;const i=o.Tu.get(e);return i?(o.sharedClientState.addLocalQueryTarget(i.targetId),r=i.view.lu()):r=await Cm(o,e,t,!0),r}async function NE(n,e){const t=Nm(n);await Cm(t,e,!0,!1)}async function Cm(n,e,t,o){const r=await ZT(n.localStore,un(e)),i=r.targetId,s=n.sharedClientState.addLocalQueryTarget(i,t);let c;return o&&(c=await LE(n,e,i,s==="current",r.resumeToken)),n.isPrimaryClient&&t&&_m(n.remoteStore,r),c}async function LE(n,e,t,o,r){n.pu=(g,m,v)=>async function(C,L,H,z){let N=L.view.ru(H);N.bs&&(N=await Ef(C.localStore,L.query,!1).then(({documents:E})=>L.view.ru(E,N)));const $=z&&z.targetChanges.get(L.targetId),j=z&&z.targetMismatches.get(L.targetId)!=null,D=L.view.applyChanges(N,C.isPrimaryClient,$,j);return Mf(C,L.targetId,D.au),D.snapshot}(n,g,m,v);const i=await Ef(n.localStore,e,!0),s=new CE(e,i.ks),c=s.ru(i.documents),d=As.createSynthesizedTargetChangeForCurrentChange(t,o&&n.onlineState!=="Offline",r),u=s.applyChanges(c,n.isPrimaryClient,d);Mf(n,t,u.au);const f=new PE(e,t,s);return n.Tu.set(e,f),n.Eu.has(t)?n.Eu.get(t).push(e):n.Eu.set(t,[e]),u.snapshot}async function DE(n,e,t){const o=oe(n),r=o.Tu.get(e),i=o.Eu.get(r.targetId);if(i.length>1)return o.Eu.set(r.targetId,i.filter(s=>!ul(s,e))),void o.Tu.delete(e);o.isPrimaryClient?(o.sharedClientState.removeLocalQueryTarget(r.targetId),o.sharedClientState.isActiveQueryTarget(r.targetId)||await Cc(o.localStore,r.targetId,!1).then(()=>{o.sharedClientState.clearQueryState(r.targetId),t&&Lu(o.remoteStore,r.targetId),Oc(o,r.targetId)}).catch(Xr)):(Oc(o,r.targetId),await Cc(o.localStore,r.targetId,!0))}async function VE(n,e){const t=oe(n),o=t.Tu.get(e),r=t.Eu.get(o.targetId);t.isPrimaryClient&&r.length===1&&(t.sharedClientState.removeLocalQueryTarget(o.targetId),Lu(t.remoteStore,o.targetId))}async function FE(n,e,t){const o=WE(n);try{const r=await function(s,c){const d=oe(s),u=Ce.now(),f=c.reduce((v,O)=>v.add(O.key),fe());let g,m;return d.persistence.runTransaction("Locally write mutations","readwrite",v=>{let O=Vn(),C=fe();return d.xs.getEntries(v,f).next(L=>{O=L,O.forEach((H,z)=>{z.isValidDocument()||(C=C.add(H))})}).next(()=>d.localDocuments.getOverlayedDocuments(v,O)).next(L=>{g=L;const H=[];for(const z of c){const N=J0(z,g.get(z.key).overlayedDocument);N!=null&&H.push(new _o(z.key,N,Dg(N.value.mapValue),$t.exists(!0)))}return d.mutationQueue.addMutationBatch(v,u,H,c)}).next(L=>{m=L;const H=L.applyToLocalDocumentSet(g,C);return d.documentOverlayCache.saveOverlays(v,L.batchId,H)})}).then(()=>({batchId:m.batchId,changes:Gg(g)}))}(o.localStore,e);o.sharedClientState.addPendingMutation(r.batchId),function(s,c,d){let u=s.du[s.currentUser.toKey()];u||(u=new Ne(he)),u=u.insert(c,d),s.du[s.currentUser.toKey()]=u}(o,r.batchId,t),await Cs(o,r.changes),await yl(o.remoteStore)}catch(r){const i=qu(r,"Failed to persist write");t.reject(i)}}async function Pm(n,e){const t=oe(n);try{const o=await XT(t.localStore,e);e.targetChanges.forEach((r,i)=>{const s=t.Au.get(i);s&&(be(r.addedDocuments.size+r.modifiedDocuments.size+r.removedDocuments.size<=1,22616),r.addedDocuments.size>0?s.hu=!0:r.modifiedDocuments.size>0?be(s.hu,14607):r.removedDocuments.size>0&&(be(s.hu,42227),s.hu=!1))}),await Cs(t,o,e)}catch(o){await Xr(o)}}function Of(n,e,t){const o=oe(n);if(o.isPrimaryClient&&t===0||!o.isPrimaryClient&&t===1){const r=[];o.Tu.forEach((i,s)=>{const c=s.view.va(e);c.snapshot&&r.push(c.snapshot)}),function(s,c){const d=oe(s);d.onlineState=c;let u=!1;d.queries.forEach((f,g)=>{for(const m of g.Sa)m.va(c)&&(u=!0)}),u&&$u(d)}(o.eventManager,e),r.length&&o.Pu.H_(r),o.onlineState=e,o.isPrimaryClient&&o.sharedClientState.setOnlineState(e)}}async function UE(n,e,t){const o=oe(n);o.sharedClientState.updateQueryState(e,"rejected",t);const r=o.Au.get(e),i=r&&r.key;if(i){let s=new Ne(Q.comparator);s=s.insert(i,ht.newNoDocument(i,ne.min()));const c=fe().add(i),d=new pl(ne.min(),new Map,new Ne(he),s,c);await Pm(o,d),o.Ru=o.Ru.remove(i),o.Au.delete(e),Hu(o)}else await Cc(o.localStore,e,!1).then(()=>Oc(o,e,t)).catch(Xr)}async function qE(n,e){const t=oe(n),o=e.batch.batchId;try{const r=await KT(t.localStore,e);Om(t,o,null),Rm(t,o),t.sharedClientState.updateMutationState(o,"acknowledged"),await Cs(t,r)}catch(r){await Xr(r)}}async function zE(n,e,t){const o=oe(n);try{const r=await function(s,c){const d=oe(s);return d.persistence.runTransaction("Reject batch","readwrite-primary",u=>{let f;return d.mutationQueue.lookupMutationBatch(u,c).next(g=>(be(g!==null,37113),f=g.keys(),d.mutationQueue.removeMutationBatch(u,g))).next(()=>d.mutationQueue.performConsistencyCheck(u)).next(()=>d.documentOverlayCache.removeOverlaysForBatchId(u,f,c)).next(()=>d.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(u,f)).next(()=>d.localDocuments.getDocuments(u,f))})}(o.localStore,e);Om(o,e,t),Rm(o,e),o.sharedClientState.updateMutationState(e,"rejected",t),await Cs(o,r)}catch(r){await Xr(r)}}function Rm(n,e){(n.mu.get(e)||[]).forEach(t=>{t.resolve()}),n.mu.delete(e)}function Om(n,e,t){const o=oe(n);let r=o.du[o.currentUser.toKey()];if(r){const i=r.get(e);i&&(t?i.reject(t):i.resolve(),r=r.remove(e)),o.du[o.currentUser.toKey()]=r}}function Oc(n,e,t=null){n.sharedClientState.removeLocalQueryTarget(e);for(const o of n.Eu.get(e))n.Tu.delete(o),t&&n.Pu.yu(o,t);n.Eu.delete(e),n.isPrimaryClient&&n.Vu.Gr(e).forEach(o=>{n.Vu.containsKey(o)||Mm(n,o)})}function Mm(n,e){n.Iu.delete(e.path.canonicalString());const t=n.Ru.get(e);t!==null&&(Lu(n.remoteStore,t),n.Ru=n.Ru.remove(e),n.Au.delete(t),Hu(n))}function Mf(n,e,t){for(const o of t)o instanceof Am?(n.Vu.addReference(o.key,e),BE(n,o)):o instanceof km?(Y(Wu,"Document no longer in limbo: "+o.key),n.Vu.removeReference(o.key,e),n.Vu.containsKey(o.key)||Mm(n,o.key)):ee(19791,{wu:o})}function BE(n,e){const t=e.key,o=t.path.canonicalString();n.Ru.get(t)||n.Iu.has(o)||(Y(Wu,"New document in limbo: "+t),n.Iu.add(o),Hu(n))}function Hu(n){for(;n.Iu.size>0&&n.Ru.size<n.maxConcurrentLimboResolutions;){const e=n.Iu.values().next().value;n.Iu.delete(e);const t=new Q(xe.fromString(e)),o=n.fu.next();n.Au.set(o,new RE(t)),n.Ru=n.Ru.insert(t,o),_m(n.remoteStore,new to(un(cl(t.path)),o,"TargetPurposeLimboResolution",sl.ce))}}async function Cs(n,e,t){const o=oe(n),r=[],i=[],s=[];o.Tu.isEmpty()||(o.Tu.forEach((c,d)=>{s.push(o.pu(d,e,t).then(u=>{var f;if((u||t)&&o.isPrimaryClient){const g=u?!u.fromCache:(f=t==null?void 0:t.targetChanges.get(d.targetId))==null?void 0:f.current;o.sharedClientState.updateQueryState(d.targetId,g?"current":"not-current")}if(u){r.push(u);const g=Mu.Is(d.targetId,u);i.push(g)}}))}),await Promise.all(s),o.Pu.H_(r),await async function(d,u){const f=oe(d);try{await f.persistence.runTransaction("notifyLocalViewChanges","readwrite",g=>U.forEach(u,m=>U.forEach(m.Ts,v=>f.persistence.referenceDelegate.addReference(g,m.targetId,v)).next(()=>U.forEach(m.Es,v=>f.persistence.referenceDelegate.removeReference(g,m.targetId,v)))))}catch(g){if(!Qr(g))throw g;Y(Nu,"Failed to update sequence numbers: "+g)}for(const g of u){const m=g.targetId;if(!g.fromCache){const v=f.vs.get(m),O=v.snapshotVersion,C=v.withLastLimboFreeSnapshotVersion(O);f.vs=f.vs.insert(m,C)}}}(o.localStore,i))}async function $E(n,e){const t=oe(n);if(!t.currentUser.isEqual(e)){Y(Wu,"User change. New user:",e.toKey());const o=await ym(t.localStore,e);t.currentUser=e,function(i,s){i.mu.forEach(c=>{c.forEach(d=>{d.reject(new G(F.CANCELLED,s))})}),i.mu.clear()}(t,"'waitForPendingWrites' promise is rejected due to a user change."),t.sharedClientState.handleUserChange(e,o.removedBatchIds,o.addedBatchIds),await Cs(t,o.Ns)}}function jE(n,e){const t=oe(n),o=t.Au.get(e);if(o&&o.hu)return fe().add(o.key);{let r=fe();const i=t.Eu.get(e);if(!i)return r;for(const s of i){const c=t.Tu.get(s);r=r.unionWith(c.view.nu)}return r}}function Nm(n){const e=oe(n);return e.remoteStore.remoteSyncer.applyRemoteEvent=Pm.bind(null,e),e.remoteStore.remoteSyncer.getRemoteKeysForTarget=jE.bind(null,e),e.remoteStore.remoteSyncer.rejectListen=UE.bind(null,e),e.Pu.H_=AE.bind(null,e.eventManager),e.Pu.yu=kE.bind(null,e.eventManager),e}function WE(n){const e=oe(n);return e.remoteStore.remoteSyncer.applySuccessfulWrite=qE.bind(null,e),e.remoteStore.remoteSyncer.rejectFailedWrite=zE.bind(null,e),e}class qa{constructor(){this.kind="memory",this.synchronizeTabs=!1}async initialize(e){this.serializer=gl(e.databaseInfo.databaseId),this.sharedClientState=this.Du(e),this.persistence=this.Cu(e),await this.persistence.start(),this.localStore=this.vu(e),this.gcScheduler=this.Fu(e,this.localStore),this.indexBackfillerScheduler=this.Mu(e,this.localStore)}Fu(e,t){return null}Mu(e,t){return null}vu(e){return YT(this.persistence,new WT,e.initialUser,this.serializer)}Cu(e){return new mm(Ou.Vi,this.serializer)}Du(e){return new tE}async terminate(){var e,t;(e=this.gcScheduler)==null||e.stop(),(t=this.indexBackfillerScheduler)==null||t.stop(),this.sharedClientState.shutdown(),await this.persistence.shutdown()}}qa.provider={build:()=>new qa};class HE extends qa{constructor(e){super(),this.cacheSizeBytes=e}Fu(e,t){be(this.persistence.referenceDelegate instanceof Fa,46915);const o=this.persistence.referenceDelegate.garbageCollector;return new PT(o,e.asyncQueue,t)}Cu(e){const t=this.cacheSizeBytes!==void 0?vt.withCacheSize(this.cacheSizeBytes):vt.DEFAULT;return new mm(o=>Fa.Vi(o,t),this.serializer)}}class Mc{async initialize(e,t){this.localStore||(this.localStore=e.localStore,this.sharedClientState=e.sharedClientState,this.datastore=this.createDatastore(t),this.remoteStore=this.createRemoteStore(t),this.eventManager=this.createEventManager(t),this.syncEngine=this.createSyncEngine(t,!e.synchronizeTabs),this.sharedClientState.onlineStateHandler=o=>Of(this.syncEngine,o,1),this.remoteStore.remoteSyncer.handleCredentialChange=$E.bind(null,this.syncEngine),await IE(this.remoteStore,this.syncEngine.isPrimaryClient))}createEventManager(e){return function(){return new SE}()}createDatastore(e){const t=gl(e.databaseInfo.databaseId),o=sE(e.databaseInfo);return dE(e.authCredentials,e.appCheckCredentials,o,t)}createRemoteStore(e){return function(o,r,i,s,c){return new fE(o,r,i,s,c)}(this.localStore,this.datastore,e.asyncQueue,t=>Of(this.syncEngine,t,0),function(){return Sf.v()?new Sf:new nE}())}createSyncEngine(e,t){return function(r,i,s,c,d,u,f){const g=new OE(r,i,s,c,d,u);return f&&(g.gu=!0),g}(this.localStore,this.remoteStore,this.eventManager,this.sharedClientState,e.initialUser,e.maxConcurrentLimboResolutions,t)}async terminate(){var e,t;await async function(r){const i=oe(r);Y(Ko,"RemoteStore shutting down."),i.Ia.add(5),await ks(i),i.Aa.shutdown(),i.Va.set("Unknown")}(this.remoteStore),(e=this.datastore)==null||e.terminate(),(t=this.eventManager)==null||t.terminate()}}Mc.provider={build:()=>new Mc};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Gu{constructor(e){this.observer=e,this.muted=!1}next(e){this.muted||this.observer.next&&this.Ou(this.observer.next,e)}error(e){this.muted||(this.observer.error?this.Ou(this.observer.error,e):Dn("Uncaught Error in snapshot listener:",e.toString()))}Nu(){this.muted=!0}Ou(e,t){setTimeout(()=>{this.muted||e(t)},0)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const yo="FirestoreClient";class GE{constructor(e,t,o,r,i){this.authCredentials=e,this.appCheckCredentials=t,this.asyncQueue=o,this._databaseInfo=r,this.user=ut.UNAUTHENTICATED,this.clientId=wu.newId(),this.authCredentialListener=()=>Promise.resolve(),this.appCheckCredentialListener=()=>Promise.resolve(),this._uninitializedComponentsProvider=i,this.authCredentials.start(o,async s=>{Y(yo,"Received user=",s.uid),await this.authCredentialListener(s),this.user=s}),this.appCheckCredentials.start(o,s=>(Y(yo,"Received new app check token=",s),this.appCheckCredentialListener(s,this.user)))}get configuration(){return{asyncQueue:this.asyncQueue,databaseInfo:this._databaseInfo,clientId:this.clientId,authCredentials:this.authCredentials,appCheckCredentials:this.appCheckCredentials,initialUser:this.user,maxConcurrentLimboResolutions:100}}setCredentialChangeListener(e){this.authCredentialListener=e}setAppCheckTokenChangeListener(e){this.appCheckCredentialListener=e}terminate(){this.asyncQueue.enterRestrictedMode();const e=new Pn;return this.asyncQueue.enqueueAndForgetEvenWhileRestricted(async()=>{try{this._onlineComponents&&await this._onlineComponents.terminate(),this._offlineComponents&&await this._offlineComponents.terminate(),this.authCredentials.shutdown(),this.appCheckCredentials.shutdown(),e.resolve()}catch(t){const o=qu(t,"Failed to shutdown persistence");e.reject(o)}}),e.promise}}async function Jl(n,e){n.asyncQueue.verifyOperationInProgress(),Y(yo,"Initializing OfflineComponentProvider");const t=n.configuration;await e.initialize(t);let o=t.initialUser;n.setCredentialChangeListener(async r=>{o.isEqual(r)||(await ym(e.localStore,r),o=r)}),e.persistence.setDatabaseDeletedListener(()=>n.terminate()),n._offlineComponents=e}async function Nf(n,e){n.asyncQueue.verifyOperationInProgress();const t=await YE(n);Y(yo,"Initializing OnlineComponentProvider"),await e.initialize(t,n.configuration),n.setCredentialChangeListener(o=>kf(e.remoteStore,o)),n.setAppCheckTokenChangeListener((o,r)=>kf(e.remoteStore,r)),n._onlineComponents=e}async function YE(n){if(!n._offlineComponents)if(n._uninitializedComponentsProvider){Y(yo,"Using user provided OfflineComponentProvider");try{await Jl(n,n._uninitializedComponentsProvider._offline)}catch(e){const t=e;if(!function(r){return r.name==="FirebaseError"?r.code===F.FAILED_PRECONDITION||r.code===F.UNIMPLEMENTED:!(typeof DOMException<"u"&&r instanceof DOMException)||r.code===22||r.code===20||r.code===11}(t))throw t;Yo("Error using user provided cache. Falling back to memory cache: "+t),await Jl(n,new qa)}}else Y(yo,"Using default OfflineComponentProvider"),await Jl(n,new HE(void 0));return n._offlineComponents}async function Lm(n){return n._onlineComponents||(n._uninitializedComponentsProvider?(Y(yo,"Using user provided OnlineComponentProvider"),await Nf(n,n._uninitializedComponentsProvider._online)):(Y(yo,"Using default OnlineComponentProvider"),await Nf(n,new Mc))),n._onlineComponents}function KE(n){return Lm(n).then(e=>e.syncEngine)}async function za(n){const e=await Lm(n),t=e.eventManager;return t.onListen=ME.bind(null,e.syncEngine),t.onUnlisten=DE.bind(null,e.syncEngine),t.onFirstRemoteStoreListen=NE.bind(null,e.syncEngine),t.onLastRemoteStoreUnlisten=VE.bind(null,e.syncEngine),t}function XE(n,e,t,o){const r=new Gu(o),i=new ju(e,r,t);return n.asyncQueue.enqueueAndForget(async()=>zu(await za(n),i)),()=>{r.Nu(),n.asyncQueue.enqueueAndForget(async()=>Bu(await za(n),i))}}function QE(n,e,t={}){const o=new Pn;return n.asyncQueue.enqueueAndForget(async()=>function(i,s,c,d,u){const f=new Gu({next:m=>{f.Nu(),s.enqueueAndForget(()=>Bu(i,g));const v=m.docs.has(c);!v&&m.fromCache?u.reject(new G(F.UNAVAILABLE,"Failed to get document because the client is offline.")):v&&m.fromCache&&d&&d.source==="server"?u.reject(new G(F.UNAVAILABLE,'Failed to get document from server. (However, this document does exist in the local cache. Run again without setting source to "server" to retrieve the cached document.)')):u.resolve(m)},error:m=>u.reject(m)}),g=new ju(cl(c.path),f,{includeMetadataChanges:!0,qa:!0});return zu(i,g)}(await za(n),n.asyncQueue,e,t,o)),o.promise}function JE(n,e,t={}){const o=new Pn;return n.asyncQueue.enqueueAndForget(async()=>function(i,s,c,d,u){const f=new Gu({next:m=>{f.Nu(),s.enqueueAndForget(()=>Bu(i,g)),m.fromCache&&d.source==="server"?u.reject(new G(F.UNAVAILABLE,'Failed to get documents from server. (However, these documents may exist in the local cache. Run again without setting source to "server" to retrieve the cached documents.)')):u.resolve(m)},error:m=>u.reject(m)}),g=new ju(c,f,{includeMetadataChanges:!0,qa:!0});return zu(i,g)}(await za(n),n.asyncQueue,e,t,o)),o.promise}function ZE(n,e){const t=new Pn;return n.asyncQueue.enqueueAndForget(async()=>FE(await KE(n),e,t)),t.promise}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Dm(n){const e={};return n.timeoutSeconds!==void 0&&(e.timeoutSeconds=n.timeoutSeconds),e}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const eI="ComponentProvider",Lf=new Map;function tI(n,e,t,o,r){return new _0(n,e,t,r.host,r.ssl,r.experimentalForceLongPolling,r.experimentalAutoDetectLongPolling,Dm(r.experimentalLongPollingOptions),r.useFetchStreams,r.isUsingEmulator,o)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Vm="firestore.googleapis.com",Df=!0;class Vf{constructor(e){if(e.host===void 0){if(e.ssl!==void 0)throw new G(F.INVALID_ARGUMENT,"Can't provide ssl option if host option is not set");this.host=Vm,this.ssl=Df}else this.host=e.host,this.ssl=e.ssl??Df;if(this.isUsingEmulator=e.emulatorOptions!==void 0,this.credentials=e.credentials,this.ignoreUndefinedProperties=!!e.ignoreUndefinedProperties,this.localCache=e.localCache,e.cacheSizeBytes===void 0)this.cacheSizeBytes=gm;else{if(e.cacheSizeBytes!==-1&&e.cacheSizeBytes<kT)throw new G(F.INVALID_ARGUMENT,"cacheSizeBytes must be at least 1048576");this.cacheSizeBytes=e.cacheSizeBytes}c0("experimentalForceLongPolling",e.experimentalForceLongPolling,"experimentalAutoDetectLongPolling",e.experimentalAutoDetectLongPolling),this.experimentalForceLongPolling=!!e.experimentalForceLongPolling,this.experimentalForceLongPolling?this.experimentalAutoDetectLongPolling=!1:e.experimentalAutoDetectLongPolling===void 0?this.experimentalAutoDetectLongPolling=!0:this.experimentalAutoDetectLongPolling=!!e.experimentalAutoDetectLongPolling,this.experimentalLongPollingOptions=Dm(e.experimentalLongPollingOptions??{}),function(o){if(o.timeoutSeconds!==void 0){if(isNaN(o.timeoutSeconds))throw new G(F.INVALID_ARGUMENT,`invalid long polling timeout: ${o.timeoutSeconds} (must not be NaN)`);if(o.timeoutSeconds<5)throw new G(F.INVALID_ARGUMENT,`invalid long polling timeout: ${o.timeoutSeconds} (minimum allowed value is 5)`);if(o.timeoutSeconds>30)throw new G(F.INVALID_ARGUMENT,`invalid long polling timeout: ${o.timeoutSeconds} (maximum allowed value is 30)`)}}(this.experimentalLongPollingOptions),this.useFetchStreams=!!e.useFetchStreams}isEqual(e){return this.host===e.host&&this.ssl===e.ssl&&this.credentials===e.credentials&&this.cacheSizeBytes===e.cacheSizeBytes&&this.experimentalForceLongPolling===e.experimentalForceLongPolling&&this.experimentalAutoDetectLongPolling===e.experimentalAutoDetectLongPolling&&function(o,r){return o.timeoutSeconds===r.timeoutSeconds}(this.experimentalLongPollingOptions,e.experimentalLongPollingOptions)&&this.ignoreUndefinedProperties===e.ignoreUndefinedProperties&&this.useFetchStreams===e.useFetchStreams}}class vl{constructor(e,t,o,r){this._authCredentials=e,this._appCheckCredentials=t,this._databaseId=o,this._app=r,this.type="firestore-lite",this._persistenceKey="(lite)",this._settings=new Vf({}),this._settingsFrozen=!1,this._emulatorOptions={},this._terminateTask="notTerminated"}get app(){if(!this._app)throw new G(F.FAILED_PRECONDITION,"Firestore was not initialized using the Firebase SDK. 'app' is not available");return this._app}get _initialized(){return this._settingsFrozen}get _terminated(){return this._terminateTask!=="notTerminated"}_setSettings(e){if(this._settingsFrozen)throw new G(F.FAILED_PRECONDITION,"Firestore has already been started and its settings can no longer be changed. You can only modify settings before calling any other methods on a Firestore object.");this._settings=new Vf(e),this._emulatorOptions=e.emulatorOptions||{},e.credentials!==void 0&&(this._authCredentials=function(o){if(!o)return new Z_;switch(o.type){case"firstParty":return new o0(o.sessionIndex||"0",o.iamToken||null,o.authTokenFactory||null);case"provider":return o.client;default:throw new G(F.INVALID_ARGUMENT,"makeAuthCredentialsProvider failed due to invalid credential type")}}(e.credentials))}_getSettings(){return this._settings}_getEmulatorOptions(){return this._emulatorOptions}_freezeSettings(){return this._settingsFrozen=!0,this._settings}_delete(){return this._terminateTask==="notTerminated"&&(this._terminateTask=this._terminate()),this._terminateTask}async _restart(){this._terminateTask==="notTerminated"?await this._terminate():this._terminateTask="notTerminated"}toJSON(){return{app:this._app,databaseId:this._databaseId,settings:this._settings}}_terminate(){return function(t){const o=Lf.get(t);o&&(Y(eI,"Removing Datastore"),Lf.delete(t),o.terminate())}(this),Promise.resolve()}}function nI(n,e,t,o={}){var u;n=Mt(n,vl);const r=_s(e),i=n._getSettings(),s={...i,emulatorOptions:n._getEmulatorOptions()},c=`${e}:${t}`;r&&Op(`https://${c}`),i.host!==Vm&&i.host!==c&&Yo("Host has been set in both settings() and connectFirestoreEmulator(), emulator host will be used.");const d={...i,host:c,ssl:r,emulatorOptions:o};if(!jo(d,s)&&(n._setSettings(d),o.mockUserToken)){let f,g;if(typeof o.mockUserToken=="string")f=o.mockUserToken,g=ut.MOCK_USER;else{f=xv(o.mockUserToken,(u=n._app)==null?void 0:u.options.projectId);const m=o.mockUserToken.sub||o.mockUserToken.user_id;if(!m)throw new G(F.INVALID_ARGUMENT,"mockUserToken must contain 'sub' or 'user_id' field!");g=new ut(m)}n._authCredentials=new e0(new Ig(f,g))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class qn{constructor(e,t,o){this.converter=t,this._query=o,this.type="query",this.firestore=e}withConverter(e){return new qn(this.firestore,e,this._query)}}class Ve{constructor(e,t,o){this.converter=t,this._key=o,this.type="document",this.firestore=e}get _path(){return this._key.path}get id(){return this._key.path.lastSegment()}get path(){return this._key.path.canonicalString()}get parent(){return new ao(this.firestore,this.converter,this._key.path.popLast())}withConverter(e){return new Ve(this.firestore,e,this._key)}toJSON(){return{type:Ve._jsonSchemaVersion,referencePath:this._key.toString()}}static fromJSON(e,t,o){if(xs(t,Ve._jsonSchema))return new Ve(e,o||null,new Q(xe.fromString(t.referencePath)))}}Ve._jsonSchemaVersion="firestore/documentReference/1.0",Ve._jsonSchema={type:We("string",Ve._jsonSchemaVersion),referencePath:We("string")};class ao extends qn{constructor(e,t,o){super(e,t,cl(o)),this._path=o,this.type="collection"}get id(){return this._query.path.lastSegment()}get path(){return this._query.path.canonicalString()}get parent(){const e=this._path.popLast();return e.isEmpty()?null:new Ve(this.firestore,null,new Q(e))}withConverter(e){return new ao(this.firestore,e,this._path)}}function mn(n,e,...t){if(n=rt(n),xg("collection","path",e),n instanceof vl){const o=xe.fromString(e,...t);return Kh(o),new ao(n,null,o)}{if(!(n instanceof Ve||n instanceof ao))throw new G(F.INVALID_ARGUMENT,"Expected first argument to collection() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const o=n._path.child(xe.fromString(e,...t));return Kh(o),new ao(n.firestore,null,o)}}function Pe(n,e,...t){if(n=rt(n),arguments.length===1&&(e=wu.newId()),xg("doc","path",e),n instanceof vl){const o=xe.fromString(e,...t);return Yh(o),new Ve(n,null,new Q(o))}{if(!(n instanceof Ve||n instanceof ao))throw new G(F.INVALID_ARGUMENT,"Expected first argument to doc() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const o=n._path.child(xe.fromString(e,...t));return Yh(o),new Ve(n.firestore,n instanceof ao?n.converter:null,new Q(o))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ff="AsyncQueue";class Uf{constructor(e=Promise.resolve()){this.Yu=[],this.ec=!1,this.tc=[],this.nc=null,this.rc=!1,this.sc=!1,this.oc=[],this.M_=new bm(this,"async_queue_retry"),this._c=()=>{const o=Ql();o&&Y(Ff,"Visibility state changed to "+o.visibilityState),this.M_.w_()},this.ac=e;const t=Ql();t&&typeof t.addEventListener=="function"&&t.addEventListener("visibilitychange",this._c)}get isShuttingDown(){return this.ec}enqueueAndForget(e){this.enqueue(e)}enqueueAndForgetEvenWhileRestricted(e){this.uc(),this.cc(e)}enterRestrictedMode(e){if(!this.ec){this.ec=!0,this.sc=e||!1;const t=Ql();t&&typeof t.removeEventListener=="function"&&t.removeEventListener("visibilitychange",this._c)}}enqueue(e){if(this.uc(),this.ec)return new Promise(()=>{});const t=new Pn;return this.cc(()=>this.ec&&this.sc?Promise.resolve():(e().then(t.resolve,t.reject),t.promise)).then(()=>t.promise)}enqueueRetryable(e){this.enqueueAndForget(()=>(this.Yu.push(e),this.lc()))}async lc(){if(this.Yu.length!==0){try{await this.Yu[0](),this.Yu.shift(),this.M_.reset()}catch(e){if(!Qr(e))throw e;Y(Ff,"Operation failed with retryable error: "+e)}this.Yu.length>0&&this.M_.p_(()=>this.lc())}}cc(e){const t=this.ac.then(()=>(this.rc=!0,e().catch(o=>{throw this.nc=o,this.rc=!1,Dn("INTERNAL UNHANDLED ERROR: ",qf(o)),o}).then(o=>(this.rc=!1,o))));return this.ac=t,t}enqueueAfterDelay(e,t,o){this.uc(),this.oc.indexOf(e)>-1&&(t=0);const r=Uu.createAndSchedule(this,e,t,o,i=>this.hc(i));return this.tc.push(r),r}uc(){this.nc&&ee(47125,{Pc:qf(this.nc)})}verifyOperationInProgress(){}async Tc(){let e;do e=this.ac,await e;while(e!==this.ac)}Ec(e){for(const t of this.tc)if(t.timerId===e)return!0;return!1}Ic(e){return this.Tc().then(()=>{this.tc.sort((t,o)=>t.targetTimeMs-o.targetTimeMs);for(const t of this.tc)if(t.skipDelay(),e!=="all"&&t.timerId===e)break;return this.Tc()})}Rc(e){this.oc.push(e)}hc(e){const t=this.tc.indexOf(e);this.tc.splice(t,1)}}function qf(n){let e=n.message||"";return n.stack&&(e=n.stack.includes(n.message)?n.stack:n.message+`
`+n.stack),e}class vo extends vl{constructor(e,t,o,r){super(e,t,o,r),this.type="firestore",this._queue=new Uf,this._persistenceKey=(r==null?void 0:r.name)||"[DEFAULT]"}async _terminate(){if(this._firestoreClient){const e=this._firestoreClient.terminate();this._queue=new Uf(e),this._firestoreClient=void 0,await e}}}function oI(n,e){const t=typeof n=="object"?n:Lp(),o=typeof n=="string"?n:Ma,r=cu(t,"firestore").getImmediate({identifier:o});if(!r._initialized){const i=Ev("firestore");i&&nI(r,...i)}return r}function bl(n){if(n._terminated)throw new G(F.FAILED_PRECONDITION,"The client has already been terminated.");return n._firestoreClient||rI(n),n._firestoreClient}function rI(n){var o,r,i,s;const e=n._freezeSettings(),t=tI(n._databaseId,((o=n._app)==null?void 0:o.options.appId)||"",n._persistenceKey,(r=n._app)==null?void 0:r.options.apiKey,e);n._componentsProvider||(i=e.localCache)!=null&&i._offlineComponentProvider&&((s=e.localCache)!=null&&s._onlineComponentProvider)&&(n._componentsProvider={_offline:e.localCache._offlineComponentProvider,_online:e.localCache._onlineComponentProvider}),n._firestoreClient=new GE(n._authCredentials,n._appCheckCredentials,n._queue,t,n._componentsProvider&&function(d){const u=d==null?void 0:d._online.build();return{_offline:d==null?void 0:d._offline.build(u),_online:u}}(n._componentsProvider))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Lt{constructor(e){this._byteString=e}static fromBase64String(e){try{return new Lt(lt.fromBase64String(e))}catch(t){throw new G(F.INVALID_ARGUMENT,"Failed to construct data from Base64 string: "+t)}}static fromUint8Array(e){return new Lt(lt.fromUint8Array(e))}toBase64(){return this._byteString.toBase64()}toUint8Array(){return this._byteString.toUint8Array()}toString(){return"Bytes(base64: "+this.toBase64()+")"}isEqual(e){return this._byteString.isEqual(e._byteString)}toJSON(){return{type:Lt._jsonSchemaVersion,bytes:this.toBase64()}}static fromJSON(e){if(xs(e,Lt._jsonSchema))return Lt.fromBase64String(e.bytes)}}Lt._jsonSchemaVersion="firestore/bytes/1.0",Lt._jsonSchema={type:We("string",Lt._jsonSchemaVersion),bytes:We("string")};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Yu{constructor(...e){for(let t=0;t<e.length;++t)if(e[t].length===0)throw new G(F.INVALID_ARGUMENT,"Invalid field name at argument $(i + 1). Field names must not be empty.");this._internalPath=new st(e)}isEqual(e){return this._internalPath.isEqual(e._internalPath)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ps{constructor(e){this._methodName=e}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class hn{constructor(e,t){if(!isFinite(e)||e<-90||e>90)throw new G(F.INVALID_ARGUMENT,"Latitude must be a number between -90 and 90, but was: "+e);if(!isFinite(t)||t<-180||t>180)throw new G(F.INVALID_ARGUMENT,"Longitude must be a number between -180 and 180, but was: "+t);this._lat=e,this._long=t}get latitude(){return this._lat}get longitude(){return this._long}isEqual(e){return this._lat===e._lat&&this._long===e._long}_compareTo(e){return he(this._lat,e._lat)||he(this._long,e._long)}toJSON(){return{latitude:this._lat,longitude:this._long,type:hn._jsonSchemaVersion}}static fromJSON(e){if(xs(e,hn._jsonSchema))return new hn(e.latitude,e.longitude)}}hn._jsonSchemaVersion="firestore/geoPoint/1.0",hn._jsonSchema={type:We("string",hn._jsonSchemaVersion),latitude:We("number"),longitude:We("number")};/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class jt{constructor(e){this._values=(e||[]).map(t=>t)}toArray(){return this._values.map(e=>e)}isEqual(e){return function(o,r){if(o.length!==r.length)return!1;for(let i=0;i<o.length;++i)if(o[i]!==r[i])return!1;return!0}(this._values,e._values)}toJSON(){return{type:jt._jsonSchemaVersion,vectorValues:this._values}}static fromJSON(e){if(xs(e,jt._jsonSchema)){if(Array.isArray(e.vectorValues)&&e.vectorValues.every(t=>typeof t=="number"))return new jt(e.vectorValues);throw new G(F.INVALID_ARGUMENT,"Expected 'vectorValues' field to be a number array")}}}jt._jsonSchemaVersion="firestore/vectorValue/1.0",jt._jsonSchema={type:We("string",jt._jsonSchemaVersion),vectorValues:We("object")};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const iI=/^__.*__$/;class sI{constructor(e,t,o){this.data=e,this.fieldMask=t,this.fieldTransforms=o}toMutation(e,t){return this.fieldMask!==null?new _o(e,this.data,this.fieldMask,t,this.fieldTransforms):new Ss(e,this.data,t,this.fieldTransforms)}}class Fm{constructor(e,t,o){this.data=e,this.fieldMask=t,this.fieldTransforms=o}toMutation(e,t){return new _o(e,this.data,this.fieldMask,t,this.fieldTransforms)}}function Um(n){switch(n){case 0:case 2:case 1:return!0;case 3:case 4:return!1;default:throw ee(40011,{dataSource:n})}}class Ku{constructor(e,t,o,r,i,s){this.settings=e,this.databaseId=t,this.serializer=o,this.ignoreUndefinedProperties=r,i===void 0&&this.Ac(),this.fieldTransforms=i||[],this.fieldMask=s||[]}get path(){return this.settings.path}get dataSource(){return this.settings.dataSource}i(e){return new Ku({...this.settings,...e},this.databaseId,this.serializer,this.ignoreUndefinedProperties,this.fieldTransforms,this.fieldMask)}dc(e){var r;const t=(r=this.path)==null?void 0:r.child(e),o=this.i({path:t,arrayElement:!1});return o.mc(e),o}fc(e){var r;const t=(r=this.path)==null?void 0:r.child(e),o=this.i({path:t,arrayElement:!1});return o.Ac(),o}gc(e){return this.i({path:void 0,arrayElement:!0})}yc(e){return Ba(e,this.settings.methodName,this.settings.hasConverter||!1,this.path,this.settings.targetDoc)}contains(e){return this.fieldMask.find(t=>e.isPrefixOf(t))!==void 0||this.fieldTransforms.find(t=>e.isPrefixOf(t.field))!==void 0}Ac(){if(this.path)for(let e=0;e<this.path.length;e++)this.mc(this.path.get(e))}mc(e){if(e.length===0)throw this.yc("Document fields must not be empty");if(Um(this.dataSource)&&iI.test(e))throw this.yc('Document fields cannot begin and end with "__"')}}class aI{constructor(e,t,o){this.databaseId=e,this.ignoreUndefinedProperties=t,this.serializer=o||gl(e)}I(e,t,o,r=!1){return new Ku({dataSource:e,methodName:t,targetDoc:o,path:st.emptyPath(),arrayElement:!1,hasConverter:r},this.databaseId,this.serializer,this.ignoreUndefinedProperties)}}function Xu(n){const e=n._freezeSettings(),t=gl(n._databaseId);return new aI(n._databaseId,!!e.ignoreUndefinedProperties,t)}function lI(n,e,t,o,r,i={}){const s=n.I(i.merge||i.mergeFields?2:0,e,t,r);Zu("Data must be an object, but it was:",s,o);const c=qm(o,s);let d,u;if(i.merge)d=new Ot(s.fieldMask),u=s.fieldTransforms;else if(i.mergeFields){const f=[];for(const g of i.mergeFields){const m=zr(e,g,t);if(!s.contains(m))throw new G(F.INVALID_ARGUMENT,`Field '${m}' is specified in your field mask but missing from your input data.`);$m(f,m)||f.push(m)}d=new Ot(f),u=s.fieldTransforms.filter(g=>d.covers(g.field))}else d=null,u=s.fieldTransforms;return new sI(new wt(c),d,u)}class wl extends Ps{_toFieldTransform(e){if(e.dataSource!==2)throw e.dataSource===1?e.yc(`${this._methodName}() can only appear at the top level of your update data`):e.yc(`${this._methodName}() cannot be used with set() unless you pass {merge:true}`);return e.fieldMask.push(e.path),null}isEqual(e){return e instanceof wl}}class Qu extends Ps{_toFieldTransform(e){return new tm(e.path,new as)}isEqual(e){return e instanceof Qu}}class Ju extends Ps{constructor(e,t){super(e),this.bc=t}_toFieldTransform(e){const t=new us(e.serializer,Xg(e.serializer,this.bc));return new tm(e.path,t)}isEqual(e){return e instanceof Ju&&this.bc===e.bc}}function cI(n,e,t,o){const r=n.I(1,e,t);Zu("Data must be an object, but it was:",r,o);const i=[],s=wt.empty();wo(o,(d,u)=>{const f=Bm(e,d,t);u=rt(u);const g=r.fc(f);if(u instanceof wl)i.push(f);else{const m=Rs(u,g);m!=null&&(i.push(f),s.set(f,m))}});const c=new Ot(i);return new Fm(s,c,r.fieldTransforms)}function uI(n,e,t,o,r,i){const s=n.I(1,e,t),c=[zr(e,o,t)],d=[r];if(i.length%2!=0)throw new G(F.INVALID_ARGUMENT,`Function ${e}() needs to be called with an even number of arguments that alternate between field names and values.`);for(let m=0;m<i.length;m+=2)c.push(zr(e,i[m])),d.push(i[m+1]);const u=[],f=wt.empty();for(let m=c.length-1;m>=0;--m)if(!$m(u,c[m])){const v=c[m];let O=d[m];O=rt(O);const C=s.fc(v);if(O instanceof wl)u.push(v);else{const L=Rs(O,C);L!=null&&(u.push(v),f.set(v,L))}}const g=new Ot(u);return new Fm(f,g,s.fieldTransforms)}function dI(n,e,t,o=!1){return Rs(t,n.I(o?4:3,e))}function Rs(n,e){if(zm(n=rt(n)))return Zu("Unsupported field value:",e,n),qm(n,e);if(n instanceof Ps)return function(o,r){if(!Um(r.dataSource))throw r.yc(`${o._methodName}() can only be used with update() and set()`);if(!r.path)throw r.yc(`${o._methodName}() is not currently supported inside arrays`);const i=o._toFieldTransform(r);i&&r.fieldTransforms.push(i)}(n,e),null;if(n===void 0&&e.ignoreUndefinedProperties)return null;if(e.path&&e.fieldMask.push(e.path),n instanceof Array){if(e.settings.arrayElement&&e.dataSource!==4)throw e.yc("Nested arrays are not supported");return function(o,r){const i=[];let s=0;for(const c of o){let d=Rs(c,r.gc(s));d==null&&(d={nullValue:"NULL_VALUE"}),i.push(d),s++}return{arrayValue:{values:i}}}(n,e)}return function(o,r){if((o=rt(o))===null)return{nullValue:"NULL_VALUE"};if(typeof o=="number")return Xg(r.serializer,o);if(typeof o=="boolean")return{booleanValue:o};if(typeof o=="string")return{stringValue:o};if(o instanceof Date){const i=Ce.fromDate(o);return{timestampValue:Va(r.serializer,i)}}if(o instanceof Ce){const i=new Ce(o.seconds,1e3*Math.floor(o.nanoseconds/1e3));return{timestampValue:Va(r.serializer,i)}}if(o instanceof hn)return{geoPointValue:{latitude:o.latitude,longitude:o.longitude}};if(o instanceof Lt)return{bytesValue:am(r.serializer,o._byteString)};if(o instanceof Ve){const i=r.databaseId,s=o.firestore._databaseId;if(!s.isEqual(i))throw r.yc(`Document reference is for database ${s.projectId}/${s.database} but should be for database ${i.projectId}/${i.database}`);return{referenceValue:Pu(o.firestore._databaseId||r.databaseId,o._key.path)}}if(o instanceof jt)return function(s,c){const d=s instanceof jt?s.toArray():s;return{mapValue:{fields:{[Ng]:{stringValue:Lg},[Na]:{arrayValue:{values:d.map(f=>{if(typeof f!="number")throw c.yc("VectorValues must only contain numeric values.");return Su(c.serializer,f)})}}}}}}(o,r);if(pm(o))return o._toProto(r.serializer);throw r.yc(`Unsupported field value: ${il(o)}`)}(n,e)}function qm(n,e){const t={};return kg(n)?e.path&&e.path.length>0&&e.fieldMask.push(e.path):wo(n,(o,r)=>{const i=Rs(r,e.dc(o));i!=null&&(t[o]=i)}),{mapValue:{fields:t}}}function zm(n){return!(typeof n!="object"||n===null||n instanceof Array||n instanceof Date||n instanceof Ce||n instanceof hn||n instanceof Lt||n instanceof Ve||n instanceof Ps||n instanceof jt||pm(n))}function Zu(n,e,t){if(!zm(t)||!Sg(t)){const o=il(t);throw o==="an object"?e.yc(n+" a custom object"):e.yc(n+" "+o)}}function zr(n,e,t){if((e=rt(e))instanceof Yu)return e._internalPath;if(typeof e=="string")return Bm(n,e);throw Ba("Field path arguments must be of type string or ",n,!1,void 0,t)}const hI=new RegExp("[~\\*/\\[\\]]");function Bm(n,e,t){if(e.search(hI)>=0)throw Ba(`Invalid field path (${e}). Paths must not contain '~', '*', '/', '[', or ']'`,n,!1,void 0,t);try{return new Yu(...e.split("."))._internalPath}catch{throw Ba(`Invalid field path (${e}). Paths must not be empty, begin with '.', end with '.', or contain '..'`,n,!1,void 0,t)}}function Ba(n,e,t,o,r){const i=o&&!o.isEmpty(),s=r!==void 0;let c=`Function ${e}() called with invalid data`;t&&(c+=" (via `toFirestore()`)"),c+=". ";let d="";return(i||s)&&(d+=" (found",i&&(d+=` in field ${o}`),s&&(d+=` in document ${r}`),d+=")"),new G(F.INVALID_ARGUMENT,c+n+d)}function $m(n,e){return n.some(t=>t.isEqual(e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fI{convertValue(e,t="none"){switch(go(e)){case 0:return null;case 1:return e.booleanValue;case 2:return Fe(e.integerValue||e.doubleValue);case 3:return this.convertTimestamp(e.timestampValue);case 4:return this.convertServerTimestamp(e,t);case 5:return e.stringValue;case 6:return this.convertBytes(po(e.bytesValue));case 7:return this.convertReference(e.referenceValue);case 8:return this.convertGeoPoint(e.geoPointValue);case 9:return this.convertArray(e.arrayValue,t);case 11:return this.convertObject(e.mapValue,t);case 10:return this.convertVectorValue(e.mapValue);default:throw ee(62114,{value:e})}}convertObject(e,t){return this.convertObjectMap(e.fields,t)}convertObjectMap(e,t="none"){const o={};return wo(e,(r,i)=>{o[r]=this.convertValue(i,t)}),o}convertVectorValue(e){var o,r,i;const t=(i=(r=(o=e.fields)==null?void 0:o[Na].arrayValue)==null?void 0:r.values)==null?void 0:i.map(s=>Fe(s.doubleValue));return new jt(t)}convertGeoPoint(e){return new hn(Fe(e.latitude),Fe(e.longitude))}convertArray(e,t){return(e.values||[]).map(o=>this.convertValue(o,t))}convertServerTimestamp(e,t){switch(t){case"previous":const o=ll(e);return o==null?null:this.convertValue(o,t);case"estimate":return this.convertTimestamp(os(e));default:return null}}convertTimestamp(e){const t=fo(e);return new Ce(t.seconds,t.nanos)}convertDocumentKey(e,t){const o=xe.fromString(e);be(fm(o),9688,{name:e});const r=new rs(o.get(1),o.get(3)),i=new Q(o.popFirst(5));return r.isEqual(t)||Dn(`Document ${i} contains a document reference within a different database (${r.projectId}/${r.database}) which is not supported. It will be treated as a reference in the current database (${t.projectId}/${t.database}) instead.`),i}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ed extends fI{constructor(e){super(),this.firestore=e}convertBytes(e){return new Lt(e)}convertReference(e){const t=this.convertDocumentKey(e,this.firestore._databaseId);return new Ve(this.firestore,null,t)}}function Xo(){return new Qu("serverTimestamp")}function $a(n){return new Ju("increment",n)}const zf="@firebase/firestore",Bf="4.14.0";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function $f(n){return function(t,o){if(typeof t!="object"||t===null)return!1;const r=t;for(const i of o)if(i in r&&typeof r[i]=="function")return!0;return!1}(n,["next","error","complete"])}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class jm{constructor(e,t,o,r,i){this._firestore=e,this._userDataWriter=t,this._key=o,this._document=r,this._converter=i}get id(){return this._key.path.lastSegment()}get ref(){return new Ve(this._firestore,this._converter,this._key)}exists(){return this._document!==null}data(){if(this._document){if(this._converter){const e=new pI(this._firestore,this._userDataWriter,this._key,this._document,null);return this._converter.fromFirestore(e)}return this._userDataWriter.convertValue(this._document.data.value)}}_fieldsProto(){var e;return((e=this._document)==null?void 0:e.data.clone().value.mapValue.fields)??void 0}get(e){if(this._document){const t=this._document.data.field(zr("DocumentSnapshot.get",e));if(t!==null)return this._userDataWriter.convertValue(t)}}}class pI extends jm{data(){return super.data()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Wm(n){if(n.limitType==="L"&&n.explicitOrderBy.length===0)throw new G(F.UNIMPLEMENTED,"limitToLast() queries require specifying at least one orderBy() clause")}class td{}class nd extends td{}function od(n,e,...t){let o=[];e instanceof td&&o.push(e),o=o.concat(t),function(i){const s=i.filter(d=>d instanceof id).length,c=i.filter(d=>d instanceof rd).length;if(s>1||s>0&&c>0)throw new G(F.INVALID_ARGUMENT,"InvalidQuery. When using composite filters, you cannot use more than one filter at the top level. Consider nesting the multiple filters within an `and(...)` statement. For example: change `query(query, where(...), or(...))` to `query(query, and(where(...), or(...)))`.")}(o);for(const r of o)n=r._apply(n);return n}class rd extends nd{constructor(e,t,o){super(),this._field=e,this._op=t,this._value=o,this.type="where"}static _create(e,t,o){return new rd(e,t,o)}_apply(e){const t=this._parse(e);return Hm(e._query,t),new qn(e.firestore,e.converter,Ic(e._query,t))}_parse(e){const t=Xu(e.firestore);return function(i,s,c,d,u,f,g){let m;if(u.isKeyField()){if(f==="array-contains"||f==="array-contains-any")throw new G(F.INVALID_ARGUMENT,`Invalid Query. You can't perform '${f}' queries on documentId().`);if(f==="in"||f==="not-in"){Wf(g,f);const O=[];for(const C of g)O.push(jf(d,i,C));m={arrayValue:{values:O}}}else m=jf(d,i,g)}else f!=="in"&&f!=="not-in"&&f!=="array-contains-any"||Wf(g,f),m=dI(c,s,g,f==="in"||f==="not-in");return je.create(u,f,m)}(e._query,"where",t,e.firestore._databaseId,this._field,this._op,this._value)}}class id extends td{constructor(e,t){super(),this.type=e,this._queryConstraints=t}static _create(e,t){return new id(e,t)}_parse(e){const t=this._queryConstraints.map(o=>o._parse(e)).filter(o=>o.getFilters().length>0);return t.length===1?t[0]:Gt.create(t,this._getOperator())}_apply(e){const t=this._parse(e);return t.getFilters().length===0?e:(function(r,i){let s=r;const c=i.getFlattenedFilters();for(const d of c)Hm(s,d),s=Ic(s,d)}(e._query,t),new qn(e.firestore,e.converter,Ic(e._query,t)))}_getQueryConstraints(){return this._queryConstraints}_getOperator(){return this.type==="and"?"and":"or"}}class sd extends nd{constructor(e,t){super(),this._field=e,this._direction=t,this.type="orderBy"}static _create(e,t){return new sd(e,t)}_apply(e){const t=function(r,i,s){if(r.startAt!==null)throw new G(F.INVALID_ARGUMENT,"Invalid query. You must not call startAt() or startAfter() before calling orderBy().");if(r.endAt!==null)throw new G(F.INVALID_ARGUMENT,"Invalid query. You must not call endAt() or endBefore() before calling orderBy().");return new ss(i,s)}(e._query,this._field,this._direction);return new qn(e.firestore,e.converter,U0(e._query,t))}}function ad(n,e="asc"){const t=e,o=zr("orderBy",n);return sd._create(o,t)}class ld extends nd{constructor(e,t,o){super(),this.type=e,this._limit=t,this._limitType=o}static _create(e,t,o){return new ld(e,t,o)}_apply(e){return new qn(e.firestore,e.converter,Da(e._query,this._limit,this._limitType))}}function cd(n){return u0("limit",n),ld._create("limit",n,"F")}function jf(n,e,t){if(typeof(t=rt(t))=="string"){if(t==="")throw new G(F.INVALID_ARGUMENT,"Invalid query. When querying with documentId(), you must provide a valid document ID, but it was an empty string.");if(!$g(e)&&t.indexOf("/")!==-1)throw new G(F.INVALID_ARGUMENT,`Invalid query. When querying a collection by documentId(), you must provide a plain document ID, but '${t}' contains a '/' character.`);const o=e.path.child(xe.fromString(t));if(!Q.isDocumentKey(o))throw new G(F.INVALID_ARGUMENT,`Invalid query. When querying a collection group by documentId(), the value provided must result in a valid document path, but '${o}' is not because it has an odd number of segments (${o.length}).`);return of(n,new Q(o))}if(t instanceof Ve)return of(n,t._key);throw new G(F.INVALID_ARGUMENT,`Invalid query. When querying with documentId(), you must provide a valid string or a DocumentReference, but it was: ${il(t)}.`)}function Wf(n,e){if(!Array.isArray(n)||n.length===0)throw new G(F.INVALID_ARGUMENT,`Invalid Query. A non-empty array is required for '${e.toString()}' filters.`)}function Hm(n,e){const t=function(r,i){for(const s of r)for(const c of s.getFlattenedFilters())if(i.indexOf(c.op)>=0)return c.op;return null}(n.filters,function(r){switch(r){case"!=":return["!=","not-in"];case"array-contains-any":case"in":return["not-in"];case"not-in":return["array-contains-any","in","not-in","!="];default:return[]}}(e.op));if(t!==null)throw t===e.op?new G(F.INVALID_ARGUMENT,`Invalid query. You cannot use more than one '${e.op.toString()}' filter.`):new G(F.INVALID_ARGUMENT,`Invalid query. You cannot use '${e.op.toString()}' filters with '${t.toString()}' filters.`)}function gI(n,e,t){let o;return o=n?t&&(t.merge||t.mergeFields)?n.toFirestore(e,t):n.toFirestore(e):e,o}class Di{constructor(e,t){this.hasPendingWrites=e,this.fromCache=t}isEqual(e){return this.hasPendingWrites===e.hasPendingWrites&&this.fromCache===e.fromCache}}class qo extends jm{constructor(e,t,o,r,i,s){super(e,t,o,r,s),this._firestore=e,this._firestoreImpl=e,this.metadata=i}exists(){return super.exists()}data(e={}){if(this._document){if(this._converter){const t=new ba(this._firestore,this._userDataWriter,this._key,this._document,this.metadata,null);return this._converter.fromFirestore(t,e)}return this._userDataWriter.convertValue(this._document.data.value,e.serverTimestamps)}}get(e,t={}){if(this._document){const o=this._document.data.field(zr("DocumentSnapshot.get",e));if(o!==null)return this._userDataWriter.convertValue(o,t.serverTimestamps)}}toJSON(){if(this.metadata.hasPendingWrites)throw new G(F.FAILED_PRECONDITION,"DocumentSnapshot.toJSON() attempted to serialize a document with pending writes. Await waitForPendingWrites() before invoking toJSON().");const e=this._document,t={};return t.type=qo._jsonSchemaVersion,t.bundle="",t.bundleSource="DocumentSnapshot",t.bundleName=this._key.toString(),!e||!e.isValidDocument()||!e.isFoundDocument()?t:(this._userDataWriter.convertObjectMap(e.data.value.mapValue.fields,"previous"),t.bundle=(this._firestore,this.ref.path,"NOT SUPPORTED"),t)}}qo._jsonSchemaVersion="firestore/documentSnapshot/1.0",qo._jsonSchema={type:We("string",qo._jsonSchemaVersion),bundleSource:We("string","DocumentSnapshot"),bundleName:We("string"),bundle:We("string")};class ba extends qo{data(e={}){return super.data(e)}}class zo{constructor(e,t,o,r){this._firestore=e,this._userDataWriter=t,this._snapshot=r,this.metadata=new Di(r.hasPendingWrites,r.fromCache),this.query=o}get docs(){const e=[];return this.forEach(t=>e.push(t)),e}get size(){return this._snapshot.docs.size}get empty(){return this.size===0}forEach(e,t){this._snapshot.docs.forEach(o=>{e.call(t,new ba(this._firestore,this._userDataWriter,o.key,o,new Di(this._snapshot.mutatedKeys.has(o.key),this._snapshot.fromCache),this.query.converter))})}docChanges(e={}){const t=!!e.includeMetadataChanges;if(t&&this._snapshot.excludesMetadataChanges)throw new G(F.INVALID_ARGUMENT,"To include metadata changes with your document changes, you must also pass { includeMetadataChanges:true } to onSnapshot().");return this._cachedChanges&&this._cachedChangesIncludeMetadataChanges===t||(this._cachedChanges=function(r,i){if(r._snapshot.oldDocs.isEmpty()){let s=0;return r._snapshot.docChanges.map(c=>{const d=new ba(r._firestore,r._userDataWriter,c.doc.key,c.doc,new Di(r._snapshot.mutatedKeys.has(c.doc.key),r._snapshot.fromCache),r.query.converter);return c.doc,{type:"added",doc:d,oldIndex:-1,newIndex:s++}})}{let s=r._snapshot.oldDocs;return r._snapshot.docChanges.filter(c=>i||c.type!==3).map(c=>{const d=new ba(r._firestore,r._userDataWriter,c.doc.key,c.doc,new Di(r._snapshot.mutatedKeys.has(c.doc.key),r._snapshot.fromCache),r.query.converter);let u=-1,f=-1;return c.type!==0&&(u=s.indexOf(c.doc.key),s=s.delete(c.doc.key)),c.type!==1&&(s=s.add(c.doc),f=s.indexOf(c.doc.key)),{type:mI(c.type),doc:d,oldIndex:u,newIndex:f}})}}(this,t),this._cachedChangesIncludeMetadataChanges=t),this._cachedChanges}toJSON(){if(this.metadata.hasPendingWrites)throw new G(F.FAILED_PRECONDITION,"QuerySnapshot.toJSON() attempted to serialize a document with pending writes. Await waitForPendingWrites() before invoking toJSON().");const e={};e.type=zo._jsonSchemaVersion,e.bundleSource="QuerySnapshot",e.bundleName=wu.newId(),this._firestore._databaseId.database,this._firestore._databaseId.projectId;const t=[],o=[],r=[];return this.docs.forEach(i=>{i._document!==null&&(t.push(i._document),o.push(this._userDataWriter.convertObjectMap(i._document.data.value.mapValue.fields,"previous")),r.push(i.ref.path))}),e.bundle=(this._firestore,this.query._query,e.bundleName,"NOT SUPPORTED"),e}}function mI(n){switch(n){case 0:return"added";case 2:case 3:return"modified";case 1:return"removed";default:return ee(61501,{type:n})}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */zo._jsonSchemaVersion="firestore/querySnapshot/1.0",zo._jsonSchema={type:We("string",zo._jsonSchemaVersion),bundleSource:We("string","QuerySnapshot"),bundleName:We("string"),bundle:We("string")};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ei(n){n=Mt(n,Ve);const e=Mt(n.firestore,vo),t=bl(e);return QE(t,n._key).then(o=>Gm(e,n,o))}function _l(n){n=Mt(n,qn);const e=Mt(n.firestore,vo),t=bl(e),o=new ed(e);return Wm(n._query),JE(t,n._query).then(r=>new zo(e,o,n,r))}function gn(n,e,t){n=Mt(n,Ve);const o=Mt(n.firestore,vo),r=gI(n.converter,e,t),i=Xu(o);return ud(o,[lI(i,"setDoc",n._key,r,n.converter!==null,t).toMutation(n._key,$t.none())])}function bo(n,e,t,...o){n=Mt(n,Ve);const r=Mt(n.firestore,vo),i=Xu(r);let s;return s=typeof(e=rt(e))=="string"||e instanceof Yu?uI(i,"updateDoc",n._key,e,t,o):cI(i,"updateDoc",n._key,e),ud(r,[s.toMutation(n._key,$t.exists(!0))])}function ds(n){return ud(Mt(n.firestore,vo),[new Au(n._key,$t.none())])}function ti(n,...e){var u,f,g;n=rt(n);let t={includeMetadataChanges:!1,source:"default"},o=0;typeof e[o]!="object"||$f(e[o])||(t=e[o++]);const r={includeMetadataChanges:t.includeMetadataChanges,source:t.source};if($f(e[o])){const m=e[o];e[o]=(u=m.next)==null?void 0:u.bind(m),e[o+1]=(f=m.error)==null?void 0:f.bind(m),e[o+2]=(g=m.complete)==null?void 0:g.bind(m)}let i,s,c;if(n instanceof Ve)s=Mt(n.firestore,vo),c=cl(n._key.path),i={next:m=>{e[o]&&e[o](Gm(s,n,m))},error:e[o+1],complete:e[o+2]};else{const m=Mt(n,qn);s=Mt(m.firestore,vo),c=m._query;const v=new ed(s);i={next:O=>{e[o]&&e[o](new zo(s,v,m,O))},error:e[o+1],complete:e[o+2]},Wm(n._query)}const d=bl(s);return XE(d,c,r,i)}function ud(n,e){const t=bl(n);return ZE(t,e)}function Gm(n,e,t){const o=t.docs.get(e._key),r=new ed(n);return new qo(n,r,e._key,o,new Di(t.hasPendingWrites,t.fromCache),e.converter)}(function(e,t=!0){J_(Gr),Nr(new Wo("firestore",(o,{instanceIdentifier:r,options:i})=>{const s=o.getProvider("app").getImmediate(),c=new vo(new t0(o.getProvider("auth-internal")),new r0(s,o.getProvider("app-check-internal")),T0(s,r),s);return i={useFetchStreams:t,...i},c._setSettings(i),c},"PUBLIC").setMultipleInstances(!0)),io(zf,Bf,e),io(zf,Bf,"esm2020")})();let X=null;function yI(){let n;xa().length===0?n=uu(mg):n=xa()[0],X=oI(n),console.log("[OpenOverlay] Firestore initialized")}async function vI(n){if(!X){console.error("[OpenOverlay] Firestore not initialized");return}const e=Pe(X,"users",n.uid);(await ei(e)).exists()?(await bo(e,{displayName:n.displayName||"Anonymous",photoURL:n.photoURL||"",email:n.email||""}),console.log("[OpenOverlay] User profile updated")):(await gn(e,{uid:n.uid,displayName:n.displayName||"Anonymous",email:n.email||"",photoURL:n.photoURL||"",bio:"",createdAt:Xo(),followersCount:0,followingCount:0}),console.log("[OpenOverlay] User profile created"))}async function Tl(n){if(!X)return null;const e=Pe(X,"users",n),t=await ei(e);return t.exists()?t.data():null}async function bI(n){const e=ce();if(!X||!e)return;const t=Pe(X,"users",e.uid);await bo(t,{bio:n})}async function wI(n){const e=ce();if(!X||!e||e.uid===n)return;const t=Pe(X,"users",e.uid,"following",n);await gn(t,{followedAt:Xo()});const o=Pe(X,"users",n,"followers",e.uid);await gn(o,{followedAt:Xo()});const r=Pe(X,"users",e.uid),i=Pe(X,"users",n);await bo(r,{followingCount:$a(1)}),await bo(i,{followersCount:$a(1)}),console.log("[OpenOverlay] Followed user:",n)}async function _I(n){const e=ce();if(!X||!e||e.uid===n)return;const t=Pe(X,"users",e.uid,"following",n);await ds(t);const o=Pe(X,"users",n,"followers",e.uid);await ds(o);const r=Pe(X,"users",e.uid),i=Pe(X,"users",n);await bo(r,{followingCount:$a(-1)}),await bo(i,{followersCount:$a(-1)}),console.log("[OpenOverlay] Unfollowed user:",n)}async function TI(n){const e=ce();if(!X||!e)return!1;const t=Pe(X,"users",e.uid,"following",n);return(await ei(t)).exists()}async function EI(n,e=50){if(!X)return[];const t=mn(X,"users",n,"followers"),o=od(t,ad("followedAt","desc"),cd(e)),r=await _l(o),i=[];for(const s of r.docs){const c=await Tl(s.id);c&&i.push(c)}return i}async function II(n,e=50){if(!X)return[];const t=mn(X,"users",n,"following"),o=od(t,ad("followedAt","desc"),cd(e)),r=await _l(o),i=[];for(const s of r.docs){const c=await Tl(s.id);c&&i.push(c)}return i}function xI(n,e){if(!X)return null;const t=mn(X,"users",n,"followers"),o=od(t,ad("followedAt","desc"),cd(10));let r=!0;return ti(o,async i=>{var s;if(r){r=!1;return}for(const c of i.docChanges())if(c.type==="added"){const d=c.doc.id,f=((s=c.doc.data().followedAt)==null?void 0:s.toDate())||new Date,g=await Tl(d);g&&e({uid:d,displayName:g.displayName,photoURL:g.photoURL,followedAt:f})}})}async function Ym(n,e,t){const o=ce();if(!X||!o)return console.log("[OpenOverlay] Not logged in, skipping cloud save"),!1;try{const r=Pe(X,"pageDrawings",n,"contributors",o.uid);return await gn(r,{userId:o.uid,userDisplayName:o.displayName||"Anonymous",userPhotoURL:o.photoURL||"",pageUrl:e,items:JSON.stringify(t),updatedAt:Xo()}),console.log("[OpenOverlay] Drawing saved to cloud (public)"),!0}catch(r){return console.error("[OpenOverlay] Failed to save drawing to cloud:",r),!1}}async function SI(n){if(!X)return null;const e=ce();try{const t=mn(X,"pageDrawings",n,"contributors"),o=await _l(t),r=[],i=[],s=[];return o.docs.forEach(c=>{const d=c.data(),u=JSON.parse(d.items||"[]");s.push({userId:d.userId,displayName:d.userDisplayName,photoURL:d.userPhotoURL}),e&&d.userId===e.uid?r.push(...u):u.forEach(f=>{i.push({...f,_ownerId:d.userId,_ownerName:d.userDisplayName,_readOnly:!0})})}),console.log("[OpenOverlay] Loaded drawings:",r.length,"mine,",i.length,"from others"),{myItems:r,otherItems:i,contributors:s}}catch(t){return console.error("[OpenOverlay] Failed to load drawings from cloud:",t),null}}async function AI(n){const e=ce();if(!X||!e)return!1;try{const t=Pe(X,"pageDrawings",n,"contributors",e.uid);return await ds(t),console.log("[OpenOverlay] Drawing deleted from cloud"),!0}catch(t){return console.error("[OpenOverlay] Failed to delete drawing from cloud:",t),!1}}let Zs=null;function kI(n,e){if(!X)return console.log("[OpenOverlay] Cannot subscribe to drawings: Firestore not initialized"),null;Zs&&Zs();const t=ce(),o=mn(X,"pageDrawings",n,"contributors");return Zs=ti(o,r=>{const i=[],s=[],c=[];r.docs.forEach(d=>{const u=d.data(),f=JSON.parse(u.items||"[]");c.push({userId:u.userId,displayName:u.userDisplayName,photoURL:u.userPhotoURL}),t&&u.userId===t.uid?i.push(...f):f.forEach(g=>{s.push({...g,_ownerId:u.userId,_ownerName:u.userDisplayName,_readOnly:!0})})}),console.log("[OpenOverlay] Real-time drawing update:",i.length,"mine,",s.length,"from others"),e({myItems:i,otherItems:s,contributors:c})},r=>{console.error("[OpenOverlay] Drawing subscription error:",r)}),console.log("[OpenOverlay] Subscribed to drawings on page:",n),Zs}function or(){return X!==null}function ja(){return ce()!==null}let ea=null;async function CI(n,e){if(!X)return console.log("[OpenOverlay] Cannot save annotation: Firestore not initialized"),!1;try{const t=Pe(X,"pageAnnotations",n,"annotations",e.id),o={...e,reactions:e.reactions||[],replies:e.replies||[],updatedAt:Xo()};return console.log("[OpenOverlay] Saving to Firestore:",t.path),await gn(t,o,{merge:!0}),console.log("[OpenOverlay] Annotation saved to cloud successfully"),!0}catch(t){return console.error("[OpenOverlay] Failed to save annotation:",(t==null?void 0:t.message)||t),(t==null?void 0:t.code)==="permission-denied"&&console.error("[OpenOverlay] Firestore security rules may need to be updated"),!1}}async function PI(n,e){if(!X)return!1;try{const t=Pe(X,"pageAnnotations",n,"annotations",e);return await ds(t),console.log("[OpenOverlay] Annotation deleted from cloud"),!0}catch(t){return console.error("[OpenOverlay] Failed to delete annotation:",t),!1}}async function Km(n){if(!X)return[];try{const e=mn(X,"pageAnnotations",n,"annotations"),t=await _l(e),o=[];return t.forEach(r=>{o.push({id:r.id,...r.data()})}),o.sort((r,i)=>(i.createdAt||0)-(r.createdAt||0)),console.log("[OpenOverlay] Fetched",o.length,"annotations from cloud"),o}catch(e){return console.error("[OpenOverlay] Failed to fetch annotations:",e),[]}}function RI(n,e){if(!X)return console.log("[OpenOverlay] Cannot subscribe to annotations: Firestore not initialized"),null;ea&&ea();const t=mn(X,"pageAnnotations",n,"annotations");return ea=ti(t,o=>{const r=[];o.forEach(i=>{r.push({id:i.id,...i.data()})}),r.sort((i,s)=>(s.createdAt||0)-(i.createdAt||0)),console.log("[OpenOverlay] Real-time update:",r.length,"annotations"),e(r)},o=>{console.error("[OpenOverlay] Annotation subscription error:",o),Km(n).then(e)}),ea}async function OI(n,e,t){if(!X)return!1;try{const o=Pe(X,"pageAnnotations",n,"annotations",e),r=await ei(o);if(!r.exists())return!1;const s=r.data().replies||[];return s.push(t),await bo(o,{replies:s}),console.log("[OpenOverlay] Reply added"),!0}catch(o){return console.error("[OpenOverlay] Failed to add reply:",o),!1}}async function MI(n,e,t,o){if(!X)return!1;try{const r=Pe(X,"pageAnnotations",n,"annotations",e),i=await ei(r);if(!i.exists())return!1;let c=i.data().reactions||[];const d=c.find(u=>u.emoji===t);return d?d.users.includes(o)?(d.users=d.users.filter(u=>u!==o),d.count=d.users.length,d.count===0&&(c=c.filter(u=>u.emoji!==t))):(d.users.push(o),d.count=d.users.length):c.push({emoji:t,count:1,users:[o]}),await bo(r,{reactions:c}),!0}catch(r){return console.error("[OpenOverlay] Failed to toggle reaction:",r),!1}}let No=null,Hf=0;async function NI(n,e){const t=ce();if(!X||!t){console.log("[OpenOverlay] Cannot sync position: db=",!!X,"user=",!!t);return}try{const o=Pe(X,"pageGames",n,"players",t.uid);await gn(o,{...e,odlPlayerId:t.uid,displayName:e.displayName||t.displayName||"Player",updatedAt:Date.now()},{merge:!0})}catch(o){const r=Date.now();r-Hf>1e4&&(Hf=r,console.error("[OpenOverlay] Position sync error:",(o==null?void 0:o.message)||o))}}function LI(n,e){if(!X)return console.log("[OpenOverlay] Cannot subscribe to players: Firestore not initialized"),null;const t=ce();console.log("[OpenOverlay] Subscribing to players for page:",n,"currentUser:",t==null?void 0:t.uid),No&&No();const o=mn(X,"pageGames",n,"players");return No=ti(o,r=>{const i=new Map,s=Date.now(),c=3e4;r.forEach(d=>{const u=d.data(),f=s-u.updatedAt;t&&d.id===t.uid||f>c||i.set(d.id,u)}),i.size>0&&console.log("[OpenOverlay] Got",i.size,"other players from snapshot"),e(i)},r=>{console.error("[OpenOverlay] Player subscription error:",r)}),console.log("[OpenOverlay] Subscribed to players on page:",n),No}async function Xm(n){const e=ce();if(!(!X||!e))try{const t=Pe(X,"pageGames",n,"players",e.uid);await ds(t),console.log("[OpenOverlay] Player removed from page")}catch(t){console.error("[OpenOverlay] Failed to remove player:",t)}}function Qm(){No&&(No(),No=null)}let Lo=null;function DI(n,e){if(!X)return console.log("[OpenOverlay] Cannot subscribe to tag game: Firestore not initialized"),null;Lo&&Lo();const t=Pe(X,"pageGames",n,"gameState","tag");return Lo=ti(t,o=>{o.exists()?e(o.data()):e(null)},o=>{console.error("[OpenOverlay] Tag game subscription error:",o),e(null)}),console.log("[OpenOverlay] Subscribed to tag game"),Lo}function VI(){Lo&&(Lo(),Lo=null)}async function FI(n){const e=ce();if(!X||!e)return!1;try{const t=Pe(X,"pageGames",n,"gameState","tag"),o=await ei(t);if(o.exists()){const r=o.data();return console.log("[OpenOverlay] Joined existing tag game, IT is:",r.itPlayerId),r.itPlayerId===e.uid}return await gn(t,{itPlayerId:e.uid,lastTagTime:Date.now(),gameActive:!0}),console.log("[OpenOverlay] Started new tag game - you are IT!"),!0}catch(t){return console.error("[OpenOverlay] Failed to start tag game:",t),!1}}async function UI(n,e){const t=ce();if(!X||!t)return!1;try{const o=Pe(X,"pageGames",n,"gameState","tag");return await gn(o,{itPlayerId:e,lastTagTime:Date.now(),gameActive:!0}),console.log("[OpenOverlay] Tagged player:",e),!0}catch(o){return console.error("[OpenOverlay] Failed to tag player:",o),!1}}async function qI(n,e){if(!X)return console.error("[OpenOverlay] Cannot submit feedback: Firestore not initialized"),!1;const t=ce();try{const o=mn(X,"feedback"),r=Pe(o);return await gn(r,{type:n,message:e,userId:(t==null?void 0:t.uid)||null,userEmail:(t==null?void 0:t.email)||null,userName:(t==null?void 0:t.displayName)||null,pageUrl:window.location.href,userAgent:navigator.userAgent,timestamp:Xo()}),console.log("[OpenOverlay] Feedback submitted successfully"),!0}catch(o){return console.error("[OpenOverlay] Failed to submit feedback:",o),!1}}let ta=null;async function zI(n,e){const t=ce();if(!X||!t)return console.log("[OpenOverlay] Not logged in, skipping course cloud save"),!1;try{const o=Pe(X,"pageCourses",n,"courses",t.uid);return await gn(o,{...e,authorId:t.uid,authorName:t.displayName||"Anonymous",updatedAt:Xo()}),console.log("[OpenOverlay] Course saved to cloud"),!0}catch(o){return console.error("[OpenOverlay] Failed to save course to cloud:",o),!1}}function BI(n,e){if(!X)return console.log("[OpenOverlay] Cannot subscribe to courses: Firestore not initialized"),null;ta&&ta();const t=ce(),o=mn(X,"pageCourses",n,"courses");return ta=ti(o,r=>{let i=null;const s=[];r.forEach(c=>{const d=c.data();t&&c.id===t.uid?i=d:s.push(d)}),console.log("[OpenOverlay] Course update: mine=",!!i,"others=",s.length),e({myCourse:i,otherCourses:s})},r=>{console.error("[OpenOverlay] Course subscription error:",r)}),console.log("[OpenOverlay] Subscribed to courses on page:",n),ta}let Zl=null,Br=null,dd=null;const wa=[];function $I(){xa().length===0?Zl=uu(mg):Zl=xa()[0],Br=X_(Zl),Fw(Br,async n=>{dd=n,console.log("[OpenOverlay] Auth state changed:",(n==null?void 0:n.displayName)||"signed out"),n&&await vI(n),wa.forEach(e=>e(n))}),console.log("[OpenOverlay] Auth initialized")}async function jI(){if(!Br)return console.error("[OpenOverlay] Auth not initialized"),null;const n=await new Promise(e=>{chrome.runtime.sendMessage({type:"GOOGLE_SIGN_IN"},e)});if(!n.success||!n.token)throw new Error(n.error||"Failed to get auth token");try{const e=In.credential(null,n.token),t=await Lw(Br,e);return console.log("[OpenOverlay] Signed in as:",t.user.displayName),t.user}catch(e){throw console.error("[OpenOverlay] Sign in error:",e),(e==null?void 0:e.code)==="auth/invalid-credential"&&await new Promise(t=>{chrome.runtime.sendMessage({type:"GOOGLE_SIGN_OUT"},()=>t())}),e}}async function WI(){Br&&(await new Promise(n=>{chrome.runtime.sendMessage({type:"GOOGLE_SIGN_OUT"},()=>n())}),await Uw(Br),console.log("[OpenOverlay] Signed out"))}function ce(){return dd}function Jm(n){return wa.push(n),n(dd),()=>{const e=wa.indexOf(n);e>-1&&wa.splice(e,1)}}let at=[],Vi=null,xi=null,Et=null,Do=null,lo=new Set;const ec=["#ffeb3b","#ff9800","#4caf50","#2196f3","#e91e63"],hd=["👍","❤️","😂","😮","😢","😡","🔥","👀","💯","🎉"],HI=`
  .oo-annotate-btn {
    position: absolute;
    background: #22c55e;
    color: white;
    border: none;
    padding: 6px 12px;
    border-radius: 6px;
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
    box-shadow: 0 2px 8px rgba(0,0,0,0.2);
    z-index: 2147483646;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    transition: transform 0.1s;
  }

  .oo-annotate-btn:hover {
    transform: scale(1.05);
  }

  .oo-annotation-form {
    position: absolute;
    background: #1a1a1a;
    border-radius: 12px;
    padding: 16px;
    box-shadow: 0 8px 32px rgba(0,0,0,0.3);
    z-index: 2147483646;
    width: 300px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  }

  .oo-annotation-form textarea {
    width: 100%;
    height: 80px;
    background: #2a2a2a;
    border: 1px solid #333;
    border-radius: 8px;
    color: #fff;
    padding: 10px;
    font-size: 14px;
    resize: none;
    font-family: inherit;
  }

  .oo-annotation-form textarea:focus {
    outline: none;
    border-color: #22c55e;
  }

  .oo-annotation-form .colors {
    display: flex;
    gap: 6px;
    margin: 12px 0;
  }

  .oo-annotation-form .color-btn {
    width: 24px;
    height: 24px;
    border-radius: 50%;
    border: 2px solid transparent;
    cursor: pointer;
    transition: transform 0.1s;
  }

  .oo-annotation-form .color-btn:hover {
    transform: scale(1.2);
  }

  .oo-annotation-form .color-btn.active {
    border-color: #fff;
  }

  .oo-annotation-form .actions {
    display: flex;
    justify-content: flex-end;
    gap: 8px;
    margin-top: 12px;
  }

  .oo-annotation-form button {
    padding: 8px 16px;
    border: none;
    border-radius: 6px;
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
    font-family: inherit;
  }

  .oo-annotation-form .cancel-btn {
    background: #333;
    color: #fff;
  }

  .oo-annotation-form .save-btn {
    background: #22c55e;
    color: #fff;
  }

  .oo-popup {
    position: absolute;
    background: #1a1a1a;
    border-radius: 12px;
    box-shadow: 0 8px 32px rgba(0,0,0,0.4);
    z-index: 2147483646;
    max-width: 320px;
    min-width: 200px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    pointer-events: auto;
    padding: 14px;
  }

  .oo-popup .popup-quote {
    font-size: 18px;
    font-weight: 700;
    color: #fff;
    line-height: 1.3;
    margin-bottom: 8px;
  }

  .oo-popup .popup-author {
    text-align: right;
    color: #888;
    font-size: 12px;
    margin-bottom: 10px;
  }

  .oo-popup .popup-footer {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
  }

  .oo-popup .popup-reactions {
    display: flex;
    gap: 4px;
    flex-wrap: wrap;
    flex: 1;
  }

  .oo-popup .reaction {
    background: #222;
    border: 1px solid #333;
    border-radius: 12px;
    padding: 2px 6px;
    font-size: 12px;
    cursor: pointer;
    transition: background 0.1s;
    display: flex;
    align-items: center;
    gap: 2px;
  }

  .oo-popup .reaction:hover {
    background: #333;
  }

  .oo-popup .reaction .count {
    color: #888;
    font-size: 11px;
  }

  .oo-popup .reaction.active {
    background: #22c55e33;
    border-color: #22c55e;
  }

  .oo-popup .popup-actions {
    display: flex;
    gap: 6px;
    align-items: center;
  }

  .oo-popup .comment-btn {
    background: #222;
    border: 1px solid #333;
    border-radius: 12px;
    padding: 2px 8px;
    font-size: 12px;
    cursor: pointer;
    color: #888;
    display: flex;
    align-items: center;
    gap: 4px;
  }

  .oo-popup .comment-btn:hover {
    background: #333;
    color: #fff;
  }

  .oo-popup .add-reaction {
    background: #222;
    border: 1px solid #333;
    border-radius: 12px;
    padding: 2px 6px;
    font-size: 14px;
    cursor: pointer;
    color: #888;
  }

  .oo-popup .add-reaction:hover {
    background: #333;
    border-color: #22c55e;
    color: #22c55e;
  }

  .oo-popup .maximize-btn {
    background: none;
    border: none;
    color: #666;
    font-size: 14px;
    cursor: pointer;
    padding: 2px 4px;
  }

  .oo-popup .maximize-btn:hover {
    color: #fff;
  }

  .oo-popup .bookmark-btn {
    background: transparent;
    border: none;
    padding: 2px 4px;
    cursor: pointer;
    font-size: 14px;
    color: #888;
    transition: color 0.15s;
  }

  .oo-popup .bookmark-btn:hover {
    color: #fff;
  }

  .oo-popup .bookmark-btn.active {
    color: #f59e0b;
  }

  .oo-popup .delete-btn {
    background: transparent;
    border: none;
    padding: 2px 4px;
    cursor: pointer;
    font-size: 14px;
    color: #666;
    transition: color 0.15s;
  }

  .oo-popup .delete-btn:hover {
    color: #ef4444;
  }

  .oo-comment-panel .delete-btn {
    background: #ef4444;
    color: white;
    border: none;
    padding: 8px 16px;
    border-radius: 6px;
    cursor: pointer;
    font-size: 13px;
    margin-top: 12px;
  }

  .oo-comment-panel .delete-btn:hover {
    background: #dc2626;
  }

  .oo-popup .popup-reply-section {
    margin-top: 10px;
    padding-top: 10px;
    border-top: 1px solid #333;
    display: none;
  }

  .oo-popup .popup-reply-section.open {
    display: block;
  }

  .oo-popup .popup-reply-input {
    display: flex;
    gap: 6px;
  }

  .oo-popup .popup-reply-input input {
    flex: 1;
    background: #222;
    border: 1px solid #333;
    border-radius: 14px;
    padding: 6px 10px;
    color: #fff;
    font-size: 12px;
  }

  .oo-popup .popup-reply-input input:focus {
    outline: none;
    border-color: #22c55e;
  }

  .oo-popup .popup-reply-input button {
    background: #22c55e;
    border: none;
    border-radius: 50%;
    width: 26px;
    height: 26px;
    color: white;
    font-size: 12px;
    cursor: pointer;
  }

  .oo-popup .quick-emojis {
    display: flex;
    gap: 2px;
    margin-top: 8px;
  }

  .oo-popup .quick-emoji {
    background: none;
    border: none;
    font-size: 16px;
    cursor: pointer;
    padding: 2px;
    border-radius: 4px;
    opacity: 0.6;
    transition: opacity 0.1s, transform 0.1s;
  }

  .oo-popup .quick-emoji:hover {
    opacity: 1;
    transform: scale(1.2);
  }

  .oo-popup-emoji-picker {
    position: absolute;
    background: #222;
    border-radius: 10px;
    padding: 6px;
    box-shadow: 0 4px 16px rgba(0,0,0,0.4);
    display: flex;
    flex-wrap: wrap;
    gap: 2px;
    width: 180px;
    bottom: 100%;
    left: 0;
    margin-bottom: 4px;
  }

  .oo-popup-emoji-picker .emoji-btn {
    width: 28px;
    height: 28px;
    border: none;
    background: transparent;
    border-radius: 4px;
    font-size: 16px;
    cursor: pointer;
  }

  .oo-popup-emoji-picker .emoji-btn:hover {
    background: #333;
  }

  .oo-comment-panel {
    position: fixed;
    right: 0;
    top: 0;
    width: 360px;
    height: 100vh;
    background: #111;
    box-shadow: -4px 0 24px rgba(0,0,0,0.3);
    z-index: 2147483646;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    display: flex;
    flex-direction: column;
    transform: translateX(100%);
    transition: transform 0.2s ease-out;
  }

  .oo-comment-panel.open {
    transform: translateX(0);
  }

  .oo-comment-panel .header {
    padding: 16px;
    border-bottom: 1px solid #222;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .oo-comment-panel .header h3 {
    margin: 0;
    color: #fff;
    font-size: 16px;
  }

  .oo-comment-panel .close-btn {
    background: none;
    border: none;
    color: #888;
    font-size: 24px;
    cursor: pointer;
    padding: 0;
    line-height: 1;
  }

  .oo-comment-panel .highlighted-text {
    padding: 16px;
    background: #1a1a1a;
    border-bottom: 1px solid #222;
  }

  .oo-comment-panel .highlighted-text blockquote {
    margin: 0;
    padding-left: 12px;
    border-left: 3px solid #22c55e;
    color: #aaa;
    font-style: italic;
  }

  .oo-comment-panel .main-comment {
    padding: 16px;
    border-bottom: 1px solid #222;
  }

  .oo-comment-panel .author-info {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 8px;
  }

  .oo-comment-panel .avatar {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    background: #333;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #888;
    font-size: 14px;
  }

  .oo-comment-panel .author-name {
    color: #fff;
    font-weight: 600;
    font-size: 14px;
  }

  .oo-comment-panel .timestamp {
    color: #666;
    font-size: 12px;
  }

  .oo-comment-panel .comment-text {
    color: #ddd;
    font-size: 14px;
    line-height: 1.5;
  }

  .oo-comment-panel .reactions {
    display: flex;
    gap: 8px;
    margin-top: 12px;
    flex-wrap: wrap;
  }

  .oo-comment-panel .reaction {
    background: #222;
    border: 1px solid #333;
    border-radius: 16px;
    padding: 4px 10px;
    font-size: 13px;
    cursor: pointer;
    transition: background 0.1s;
  }

  .oo-comment-panel .reaction:hover {
    background: #333;
  }

  .oo-comment-panel .reaction .emoji {
    margin-right: 4px;
  }

  .oo-comment-panel .reaction .count {
    color: #888;
  }

  .oo-comment-panel .add-reaction {
    background: #1a1a1a;
    border: 1px dashed #444;
    color: #888;
    font-size: 16px;
    min-width: 36px;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .oo-comment-panel .add-reaction:hover {
    border-color: #22c55e;
    color: #22c55e;
  }

  .oo-comment-panel .reaction.active {
    background: #22c55e33;
    border-color: #22c55e;
  }

  .oo-emoji-picker {
    position: absolute;
    background: #222;
    border-radius: 12px;
    padding: 8px;
    box-shadow: 0 4px 16px rgba(0,0,0,0.4);
    display: flex;
    flex-wrap: wrap;
    gap: 4px;
    width: 200px;
    z-index: 10;
  }

  .oo-emoji-picker .emoji-btn {
    width: 32px;
    height: 32px;
    border: none;
    background: transparent;
    border-radius: 6px;
    font-size: 18px;
    cursor: pointer;
    transition: background 0.1s, transform 0.1s;
  }

  .oo-emoji-picker .emoji-btn:hover {
    background: #333;
    transform: scale(1.2);
  }

  .oo-comment-panel .replies-section {
    flex: 1;
    overflow-y: auto;
    padding: 16px;
  }

  .oo-comment-panel .reply {
    margin-bottom: 16px;
    padding-bottom: 16px;
    border-bottom: 1px solid #222;
  }

  .oo-comment-panel .reply:last-child {
    border-bottom: none;
  }

  .oo-comment-panel .reply-input {
    padding: 16px;
    border-top: 1px solid #222;
    display: flex;
    gap: 8px;
  }

  .oo-comment-panel .reply-input input {
    flex: 1;
    background: #222;
    border: 1px solid #333;
    border-radius: 20px;
    padding: 10px 16px;
    color: #fff;
    font-size: 14px;
  }

  .oo-comment-panel .reply-input input:focus {
    outline: none;
    border-color: #22c55e;
  }

  .oo-comment-panel .reply-input button {
    background: #22c55e;
    border: none;
    border-radius: 50%;
    width: 40px;
    height: 40px;
    color: white;
    font-size: 18px;
    cursor: pointer;
  }
`;function GI(){console.log("[OpenOverlay] initAnnotations starting..."),xi=document.createElement("div"),xi.id="openoverlay-annotations",xi.style.cssText=`
    position: fixed;
    top: 0;
    left: 0;
    width: 0;
    height: 0;
    z-index: 2147483646;
    pointer-events: none;
  `,Et=xi.attachShadow({mode:"open"});const n=document.createElement("style");n.textContent=HI,Et.appendChild(n),document.body.appendChild(xi),document.addEventListener("mouseup",KI),document.addEventListener("selectionchange",YI),ix(),dx(),El(),console.log("[OpenOverlay] Annotations initialized")}let tc=null;function YI(){tc&&clearTimeout(tc),tc=window.setTimeout(()=>{Zm()},100)}function KI(n){var e,t;(e=n.target)!=null&&e.closest("#openoverlay-annotations")||(t=n.target)!=null&&t.closest("#openoverlay-ui")||setTimeout(Zm,10)}function Zm(){const n=window.getSelection();if(!n||n.isCollapsed||!n.toString().trim()){Wa();return}if(n.toString().trim().length<3){Wa();return}const o=n.getRangeAt(0).getBoundingClientRect();XI(o,n)}function XI(n,e){if(Wa(),!Et)return;const t=document.createElement("button");t.className="oo-annotate-btn",t.textContent="+ Annotate",t.style.pointerEvents="auto";const o=Math.max(10,Math.min(n.left+n.width/2-50,window.innerWidth-110)),r=n.bottom+2,i=r+32>window.innerHeight?n.top-34:r;t.style.left=`${o}px`,t.style.top=`${i}px`,t.onclick=s=>{s.preventDefault(),s.stopPropagation(),QI(n,e)},Et.appendChild(t),Vi=t}function Wa(){Vi&&(Et!=null&&Et.contains(Vi))&&Vi.remove(),Vi=null}function QI(n,e){var v,O;if(Wa(),!Et)return;const t=e.toString().trim(),o=e.getRangeAt(0),r=e.anchorNode,i=e.focusNode,s=document.createElement("div");s.className="oo-annotation-form",s.style.pointerEvents="auto";const c=Math.max(10,Math.min(n.left,window.innerWidth-320)),d=n.bottom+4,u=180,f=d+u>window.innerHeight?Math.max(10,n.top-u-4):d;s.style.left=`${c}px`,s.style.top=`${f}px`;let g=ec[0];s.innerHTML=`
    <textarea placeholder="Add your annotation..." autofocus></textarea>
    <div class="colors">
      ${ec.map((C,L)=>`
        <div class="color-btn ${L===0?"active":""}"
             data-color="${C}"
             style="background: ${C}"></div>
      `).join("")}
    </div>
    <div class="actions">
      <button class="cancel-btn">Cancel</button>
      <button class="save-btn">Save</button>
    </div>
  `,s.querySelectorAll(".color-btn").forEach(C=>{C.addEventListener("click",()=>{s.querySelectorAll(".color-btn").forEach(L=>L.classList.remove("active")),C.classList.add("active"),g=C.dataset.color||ec[0]})}),(v=s.querySelector(".cancel-btn"))==null||v.addEventListener("click",()=>{var C;s.remove(),(C=window.getSelection())==null||C.removeAllRanges()}),(O=s.querySelector(".save-btn"))==null||O.addEventListener("click",()=>{var $;const C=s.querySelector("textarea"),L=C.value.trim();if(!L){C.focus();return}const{contextBefore:H,contextAfter:z}=ZI(o,t),N={id:JI(),text:t,contextBefore:H,contextAfter:z,anchorSelector:Gf(r),anchorOffset:e.anchorOffset,focusSelector:Gf(i),focusOffset:e.focusOffset,comment:L,color:g,authorId:"local-user",authorName:"You",createdAt:Date.now(),reactions:[],replies:[]};at.push(N),Wt(),El(),rx(N),s.remove(),($=window.getSelection())==null||$.removeAllRanges(),console.log("[OpenOverlay] Annotation created:",N.id)}),Et.appendChild(s),setTimeout(()=>{var C;(C=s.querySelector("textarea"))==null||C.focus()},10);const m=s.querySelector("textarea");m==null||m.addEventListener("keydown",C=>{if(C.stopPropagation(),C.key==="Enter"&&!C.shiftKey){C.preventDefault();const L=s.querySelector(".save-btn");L==null||L.click()}})}function Gf(n){if(!n)return"body";const e=n.nodeType===Node.TEXT_NODE?n.parentElement:n;if(!e)return"body";const t=[];let o=e;for(;o&&o!==document.body&&o!==document.documentElement;){let r=o.tagName.toLowerCase();if(o.id){t.unshift(`#${CSS.escape(o.id)}`);break}const i=o.parentElement;if(i){const c=Array.from(i.children).indexOf(o)+1;r+=`:nth-child(${c})`}t.unshift(r),o=o.parentElement}return t.join(" > ")||"body"}function JI(){return Math.random().toString(36).substr(2,9)}function ZI(n,e){var o;try{const r=n.commonAncestorContainer,i=r.nodeType===Node.TEXT_NODE?r.parentElement:r;if(!i)return{contextBefore:"",contextAfter:""};const s=i.textContent||"",c=((o=n.startContainer.textContent)==null?void 0:o.substring(0,n.startOffset))||"";let d="";const u=document.createTreeWalker(i,NodeFilter.SHOW_TEXT,null);let f;for(;f=u.nextNode();){if(f===n.startContainer){d+=c;break}d+=f.textContent||""}const g=d.slice(-30),m=d.length+e.length,v=s.substring(m,m+30);return{contextBefore:g,contextAfter:v}}catch(r){return console.warn("[OpenOverlay] Failed to get selection context:",r),{contextBefore:"",contextAfter:""}}}function fd(){document.querySelectorAll(".oo-highlight").forEach(n=>{const e=n.parentNode;e&&(e.replaceChild(document.createTextNode(n.textContent||""),n),e.normalize())})}function El(){fd();for(const n of at)try{ex(n)}catch(e){console.warn("[OpenOverlay] Failed to highlight annotation:",n.id,e)}}function ex(n){(n.contextBefore||"")+n.text+(n.contextAfter||"");const e=n.text,t=[],o=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,null);let r="",i;for(;i=o.nextNode();){const u=i.textContent||"";t.push({node:i,start:r.length,end:r.length+u.length}),r+=u}let s=-1;if(n.contextBefore||n.contextAfter){const u=n.contextBefore||"",f=n.contextAfter||"";let g=0;for(;g<r.length;){const m=r.indexOf(e,g);if(m===-1)break;const v=u===""||r.substring(Math.max(0,m-u.length),m).endsWith(u),O=f===""||r.substring(m+e.length,m+e.length+f.length).startsWith(f);if(v&&O){s=m;break}g=m+1}}if(s===-1&&(s=r.indexOf(e)),s===-1)return;let c=null,d=0;for(const u of t)if(s>=u.start&&s<u.end){c=u.node,d=s-u.start;break}if(c)try{const u=document.createRange();u.setStart(c,d),u.setEnd(c,d+e.length);const f=document.createElement("span");f.className="oo-highlight",f.dataset.annotationId=n.id,f.style.cssText=`
      background: ${n.color}40;
      border-bottom: 2px solid ${n.color};
      cursor: pointer;
      transition: background 0.15s;
    `,f.addEventListener("mouseenter",g=>{f.style.background=`${n.color}60`,Nc(n,g,f)}),f.addEventListener("mouseleave",g=>{f.style.background=`${n.color}40`,ey()}),u.surroundContents(f)}catch(u){console.warn("[OpenOverlay] Failed to highlight annotation:",n.id,u)}}let Bo=null,tn=null,Ir=null,xr=!1;function ey(){xr||(Ir&&clearTimeout(Ir),Ir=window.setTimeout(()=>{Zn()},150))}function Fi(){Ir&&(clearTimeout(Ir),Ir=null)}function Nc(n,e,t){var C,L,H,z;if(fn)return;if(Bo&&(tn==null?void 0:tn.id)===n.id){Fi();return}if(Fi(),Zn(),xr=!1,!Et)return;tn=n;const o=document.createElement("div");o.className="oo-popup";let r,i;if(t){const N=t.getBoundingClientRect();r=N.left,i=N.bottom+4}else r=e.clientX-100,i=e.clientY+10;r<10&&(r=10),r+320>window.innerWidth&&(r=window.innerWidth-330),i+200>window.innerHeight&&(i=t?t.getBoundingClientRect().top-200:e.clientY-200),o.style.left=`${r}px`,o.style.top=`${i}px`;const s=n.reactions.filter(N=>N.count>0),c=n.replies.length,d=ce(),u=d?n.authorId===d.uid:n.authorId==="local-user";o.innerHTML=`
    <div class="popup-quote">"${Vt(n.comment)}"</div>
    <div class="popup-author">— ${Vt(n.authorName)}</div>
    <div class="popup-footer">
      <div class="popup-reactions" id="popup-reactions">
        ${s.map(N=>`
          <div class="reaction ${N.userReacted?"active":""}" data-emoji="${N.emoji}">
            <span class="emoji">${N.emoji}</span>
            <span class="count">${N.count}</span>
          </div>
        `).join("")}
      </div>
      <div class="popup-actions">
        <button class="comment-btn" id="popup-comment-btn" title="Comments">
          💬 ${c>0?c:""}
        </button>
        <button class="add-reaction" id="popup-add-reaction" title="React">+</button>
        <button class="bookmark-btn ${lo.has(n.id)?"active":""}" id="popup-bookmark-btn" title="Bookmark">🔖</button>
        <button class="maximize-btn" title="Open in sidebar">⛶</button>
        ${u?'<button class="delete-btn" id="popup-delete-btn" title="Delete annotation">🗑️</button>':""}
      </div>
    </div>
    <div class="popup-reply-section" id="popup-reply-section">
      <div class="popup-reply-input">
        <input type="text" placeholder="Add a comment..." />
        <button>➤</button>
      </div>
      <div class="quick-emojis">
        ${hd.slice(0,6).map(N=>`
          <button class="quick-emoji" data-emoji="${N}">${N}</button>
        `).join("")}
      </div>
    </div>
  `,o.addEventListener("mouseenter",()=>{Fi()}),o.addEventListener("mouseleave",()=>{ey()}),o.addEventListener("click",N=>{N.stopPropagation(),xr=!0,Fi()}),(C=o.querySelector(".maximize-btn"))==null||C.addEventListener("click",N=>{N.stopPropagation(),xr=!1,Zn(),ox(n)}),(L=o.querySelector("#popup-bookmark-btn"))==null||L.addEventListener("click",N=>{N.stopPropagation(),cx(n.id);const $=o.querySelector("#popup-bookmark-btn");$==null||$.classList.toggle("active",lo.has(n.id))}),(H=o.querySelector("#popup-delete-btn"))==null||H.addEventListener("click",N=>{N.stopPropagation(),confirm("Delete this annotation and all its comments?")&&(cy(n.id),Zn())});const f=o.querySelector("#popup-comment-btn"),g=o.querySelector("#popup-reply-section");f==null||f.addEventListener("click",N=>{if(N.stopPropagation(),g==null||g.classList.toggle("open"),g!=null&&g.classList.contains("open")){const $=o.querySelector(".popup-reply-input input");$==null||$.focus()}}),o.querySelectorAll(".reaction").forEach(N=>{N.addEventListener("click",$=>{$.stopPropagation();const j=N.dataset.emoji;if(!j)return;const D=n.reactions.find(E=>E.emoji===j);D&&(D.userReacted?(D.count--,D.userReacted=!1,D.count<=0&&(n.reactions=n.reactions.filter(E=>E.emoji!==j))):(D.count++,D.userReacted=!0),Wt(),Qo(n,j),Zn(),Nc(n,$))})}),(z=o.querySelector("#popup-add-reaction"))==null||z.addEventListener("click",N=>{N.stopPropagation();const $=o.querySelector("#popup-reactions");ny(o,n,$)}),o.querySelectorAll(".quick-emoji").forEach(N=>{N.addEventListener("click",$=>{$.stopPropagation();const j=N.dataset.emoji;if(!j)return;let D=n.reactions.find(E=>E.emoji===j);D?D.userReacted||(D.count++,D.userReacted=!0):n.reactions.push({emoji:j,count:1,userReacted:!0}),Wt(),Qo(n,j),Zn(),Nc(n,$)})});const m=o.querySelector(".popup-reply-input input"),v=o.querySelector(".popup-reply-input button"),O=()=>{const N=m.value.trim();if(!N)return;const $=ce(),j={authorName:($==null?void 0:$.displayName)||"You",text:N,createdAt:Date.now()};n.replies.push(j),Wt(),ly(n,j),m.value="";const D=o.querySelector("#popup-comment-btn");D&&(D.innerHTML=`💬 ${n.replies.length}`)};v==null||v.addEventListener("click",N=>{N.stopPropagation(),O()}),m==null||m.addEventListener("keypress",N=>{N.key==="Enter"&&(N.stopPropagation(),O())}),Et.appendChild(o),Bo=o,setTimeout(()=>{document.addEventListener("click",ry)},10)}function tx(n){return`
    ${n.reactions.map(e=>`
      <div class="reaction ${e.userReacted?"active":""}" data-emoji="${e.emoji}">
        <span class="emoji">${e.emoji}</span>
        <span class="count">${e.count}</span>
      </div>
    `).join("")}
    <div class="reaction add-reaction" id="popup-add-reaction">😀+</div>
  `}function nx(n,e){var o;const t=n.querySelector("#popup-reactions");t&&(t.querySelectorAll(".reaction:not(.add-reaction)").forEach(r=>{r.addEventListener("click",i=>{i.stopPropagation();const s=r.dataset.emoji;if(!s)return;const c=e.reactions.find(d=>d.emoji===s);c&&(c.userReacted?(c.count--,c.userReacted=!1,c.count<=0&&(e.reactions=e.reactions.filter(d=>d.emoji!==s))):(c.count++,c.userReacted=!0),Wt(),Qo(e,s),ty(n,e))})}),(o=t.querySelector("#popup-add-reaction"))==null||o.addEventListener("click",r=>{r.stopPropagation(),ny(n,e,t)}))}function ty(n,e){const t=n.querySelector("#popup-reactions");t&&(t.innerHTML=tx(e),nx(n,e))}let Sr=null;function ny(n,e,t){Ha();const o=document.createElement("div");o.className="oo-popup-emoji-picker",o.innerHTML=hd.map(r=>`
    <button class="emoji-btn" data-emoji="${r}">${r}</button>
  `).join(""),o.querySelectorAll(".emoji-btn").forEach(r=>{r.addEventListener("click",i=>{i.stopPropagation();const s=r.dataset.emoji;if(!s)return;let c=e.reactions.find(d=>d.emoji===s);c?c.userReacted||(c.count++,c.userReacted=!0):e.reactions.push({emoji:s,count:1,userReacted:!0}),Wt(),Qo(e,s),ty(n,e),Ha()})}),t.appendChild(o),Sr=o,setTimeout(()=>{document.addEventListener("click",oy)},10)}function oy(n){Sr&&!Sr.contains(n.target)&&Ha()}function Ha(){document.removeEventListener("click",oy),Sr&&(Sr.remove(),Sr=null)}function ry(n){xr&&Bo&&!Bo.contains(n.target)&&Zn()}function Zn(){Fi(),document.removeEventListener("click",ry),Ha(),Bo&&(Bo.remove(),Bo=null),tn=null,xr=!1}let fn=null;function ox(n){var u,f,g;if(Zn(),_a(),!Et)return;const e=document.createElement("div");e.className="oo-comment-panel open",e.style.pointerEvents="auto";const t=Dc(n.createdAt),o=ce(),r=o?n.authorId===o.uid:n.authorId==="local-user";e.innerHTML=`
    <div class="header">
      <h3>Annotation</h3>
      <button class="close-btn">&times;</button>
    </div>
    <div class="highlighted-text">
      <blockquote>"${Vt(n.text)}"</blockquote>
    </div>
    <div class="main-comment">
      <div class="author-info">
        <div class="avatar">${n.authorName.charAt(0).toUpperCase()}</div>
        <div>
          <div class="author-name">${Vt(n.authorName)}</div>
          <div class="timestamp">${t}</div>
        </div>
      </div>
      <div class="comment-text">${Vt(n.comment)}</div>
      <div class="reactions" id="reactions-container">
        ${n.reactions.map(m=>`
          <div class="reaction ${m.userReacted?"active":""}" data-emoji="${m.emoji}">
            <span class="emoji">${m.emoji}</span>
            <span class="count">${m.count}</span>
          </div>
        `).join("")}
        <div class="reaction add-reaction" id="add-reaction-btn">😀+</div>
      </div>
      ${r?'<button class="delete-btn" id="panel-delete-btn">🗑️ Delete Annotation</button>':""}
    </div>
    <div class="replies-section">
      ${n.replies.map(m=>`
        <div class="reply">
          <div class="author-info">
            <div class="avatar">${m.authorName.charAt(0).toUpperCase()}</div>
            <div>
              <div class="author-name">${Vt(m.authorName)}</div>
              <div class="timestamp">${Dc(m.createdAt)}</div>
            </div>
          </div>
          <div class="comment-text">${Vt(m.text)}</div>
        </div>
      `).join("")}
    </div>
    <div class="reply-input">
      <input type="text" placeholder="Add a reply..." />
      <button>➤</button>
    </div>
  `,e.addEventListener("click",m=>{m.stopPropagation()}),(u=e.querySelector(".close-btn"))==null||u.addEventListener("click",m=>{m.stopPropagation(),_a()}),(f=e.querySelector("#panel-delete-btn"))==null||f.addEventListener("click",m=>{m.stopPropagation(),confirm("Delete this annotation and all its comments?")&&(cy(n.id),_a())});const i=e.querySelector(".reply-input input"),s=e.querySelector(".reply-input button"),c=()=>{const m=i.value.trim();if(!m)return;const v=ce(),O=(v==null?void 0:v.displayName)||"You",C={authorName:O,text:m,createdAt:Date.now()};n.replies.push(C),Wt(),ly(n,C);const L=e.querySelector(".replies-section");if(L){const H=`
        <div class="reply">
          <div class="author-info">
            <div class="avatar">${O.charAt(0).toUpperCase()}</div>
            <div>
              <div class="author-name">${Vt(O)}</div>
              <div class="timestamp">just now</div>
            </div>
          </div>
          <div class="comment-text">${Vt(m)}</div>
        </div>
      `;L.insertAdjacentHTML("beforeend",H)}i.value="",i.focus()};s==null||s.addEventListener("click",m=>{m.stopPropagation(),c()}),i==null||i.addEventListener("keypress",m=>{m.key==="Enter"&&(m.stopPropagation(),c())});const d=e.querySelector("#reactions-container");e.querySelectorAll(".reaction:not(.add-reaction)").forEach(m=>{m.addEventListener("click",v=>{v.stopPropagation();const O=m.dataset.emoji;if(!O)return;const C=n.reactions.find(L=>L.emoji===O);C&&(C.userReacted?(C.count--,C.userReacted=!1,C.count<=0&&(n.reactions=n.reactions.filter(L=>L.emoji!==O))):(C.count++,C.userReacted=!0),Wt(),Qo(n,O),pd(n,d))})}),(g=e.querySelector("#add-reaction-btn"))==null||g.addEventListener("click",m=>{m.stopPropagation(),iy(n,m.target,d)}),Et.appendChild(e),fn=e,Do=n,setTimeout(()=>i==null?void 0:i.focus(),100),setTimeout(()=>{document.addEventListener("click",ay)},50)}let Ar=null;function iy(n,e,t){Lc();const o=document.createElement("div");o.className="oo-emoji-picker",e.getBoundingClientRect(),o.style.bottom="40px",o.style.left="0",o.innerHTML=hd.map(r=>`
    <button class="emoji-btn" data-emoji="${r}">${r}</button>
  `).join(""),o.querySelectorAll(".emoji-btn").forEach(r=>{r.addEventListener("click",i=>{i.stopPropagation();const s=r.dataset.emoji;if(!s)return;let c=n.reactions.find(d=>d.emoji===s);c?c.userReacted||(c.count++,c.userReacted=!0):n.reactions.push({emoji:s,count:1,userReacted:!0}),Wt(),Qo(n,s),pd(n,t),Lc()})}),t.style.position="relative",t.appendChild(o),Ar=o,setTimeout(()=>{document.addEventListener("click",sy)},10)}function sy(n){Ar&&!Ar.contains(n.target)&&Lc()}function Lc(){document.removeEventListener("click",sy),Ar&&(Ar.remove(),Ar=null)}function pd(n,e){var t;e&&(e.innerHTML=`
    ${n.reactions.map(o=>`
      <div class="reaction ${o.userReacted?"active":""}" data-emoji="${o.emoji}">
        <span class="emoji">${o.emoji}</span>
        <span class="count">${o.count}</span>
      </div>
    `).join("")}
    <div class="reaction add-reaction" id="add-reaction-btn">😀+</div>
  `,e.querySelectorAll(".reaction:not(.add-reaction)").forEach(o=>{o.addEventListener("click",r=>{r.stopPropagation();const i=o.dataset.emoji;if(!i)return;const s=n.reactions.find(c=>c.emoji===i);s&&(s.userReacted?(s.count--,s.userReacted=!1,s.count<=0&&(n.reactions=n.reactions.filter(c=>c.emoji!==i))):(s.count++,s.userReacted=!0),Wt(),Qo(n,i),pd(n,e))})}),(t=e.querySelector("#add-reaction-btn"))==null||t.addEventListener("click",o=>{o.stopPropagation(),iy(n,o.target,e)}))}function ay(n){fn&&!fn.contains(n.target)&&_a()}function _a(){document.removeEventListener("click",ay),fn&&(fn.remove(),fn=null),Do=null}function Vt(n){const e=document.createElement("div");return e.textContent=n,e.innerHTML}function Dc(n){const e=Math.floor((Date.now()-n)/1e3);return e<60?"just now":e<3600?`${Math.floor(e/60)}m ago`:e<86400?`${Math.floor(e/3600)}h ago`:e<604800?`${Math.floor(e/86400)}d ago`:new Date(n).toLocaleDateString()}function Wt(){const n=To();localStorage.setItem(`oo_annotations_${n}`,JSON.stringify(at)),console.log("[OpenOverlay] Saved",at.length,"annotations locally")}async function rx(n){if(!or()){console.log("[OpenOverlay] Firestore not available, skipping cloud save");return}const e=ce(),t=To();console.log("[OpenOverlay] Saving annotation to cloud:",n.id,"pageKey:",t);const o={id:n.id,pageKey:t,text:n.text,contextBefore:n.contextBefore||"",contextAfter:n.contextAfter||"",anchorSelector:n.anchorSelector,anchorOffset:n.anchorOffset,focusSelector:n.focusSelector,focusOffset:n.focusOffset,comment:n.comment,color:n.color,authorId:(e==null?void 0:e.uid)||n.authorId,authorName:(e==null?void 0:e.displayName)||n.authorName,createdAt:n.createdAt,reactions:n.reactions.map(r=>({emoji:r.emoji,count:r.count,users:r.userReacted&&e?[e.uid]:[]})),replies:n.replies.map(r=>({authorId:"",authorName:r.authorName,text:r.text,createdAt:r.createdAt}))};await CI(t,o)}async function Qo(n,e){if(!or())return;const t=ce();if(!t)return;const o=To();await MI(o,n.id,e,t.uid)}async function ly(n,e){if(!or())return;const t=ce(),o=To();await OI(o,n.id,{authorId:(t==null?void 0:t.uid)||"",authorName:(t==null?void 0:t.displayName)||e.authorName,text:e.text,createdAt:e.createdAt})}function ix(){const n=To(),e=localStorage.getItem(`oo_annotations_${n}`);if(e)try{at=JSON.parse(e),console.log("[OpenOverlay] Loaded",at.length,"annotations from localStorage")}catch{console.warn("[OpenOverlay] Failed to load annotations"),at=[]}sx()}async function sx(){if(!or()){console.log("[OpenOverlay] Firestore not available, skipping real-time sync");return}const n=To();if(console.log("[OpenOverlay] Setting up real-time sync for page:",n),!RI(n,t=>{Yf(t)})){console.log("[OpenOverlay] Real-time subscription failed, trying one-time fetch");const t=await Km(n);Yf(t)}}function Yf(n){const e=ce();if(console.log("[OpenOverlay] Processing",n.length,"cloud annotations"),n.length===0){console.log("[OpenOverlay] No cloud annotations found");return}const t=new Map;for(const r of at)t.set(r.id,r);for(const r of n){const i=t.get(r.id),s={id:r.id,text:r.text,contextBefore:r.contextBefore||"",contextAfter:r.contextAfter||"",anchorSelector:r.anchorSelector,anchorOffset:r.anchorOffset,focusSelector:r.focusSelector,focusOffset:r.focusOffset,comment:r.comment,color:r.color,authorId:r.authorId,authorName:r.authorName,createdAt:r.createdAt,reactions:(r.reactions||[]).map(c=>({emoji:c.emoji,count:c.count,userReacted:e?c.users.includes(e.uid):!1})),replies:(r.replies||[]).map(c=>({authorName:c.authorName,text:c.text,createdAt:c.createdAt}))};(!i||r.createdAt>=i.createdAt)&&t.set(r.id,s)}at=Array.from(t.values()),console.log("[OpenOverlay] Merged to",at.length,"total annotations");const o=To();localStorage.setItem(`oo_annotations_${o}`,JSON.stringify(at)),fd(),El(),ax()}function ax(){if(tn){const n=at.find(e=>e.id===(tn==null?void 0:tn.id));n&&(tn=n)}if(fn&&Do){const n=at.find(e=>e.id===(Do==null?void 0:Do.id));n&&lx(n)}}function lx(n){if(!fn||!Et)return;const e=fn.querySelector(".replies-section");e&&(e.innerHTML=n.replies.map(t=>`
    <div class="reply">
      <div class="author-info">
        <div class="avatar">${t.authorName.charAt(0).toUpperCase()}</div>
        <div>
          <div class="author-name">${Vt(t.authorName)}</div>
          <div class="timestamp">${Dc(t.createdAt)}</div>
        </div>
      </div>
      <div class="comment-text">${Vt(t.text)}</div>
    </div>
  `).join(""),Do=n,console.log("[OpenOverlay] Comment panel refreshed with",n.replies.length,"replies"))}async function cy(n){const e=at.find(r=>r.id===n);if(!e)return;const t=ce();if(!(t?e.authorId===t.uid:e.authorId==="local-user")){console.warn("[OpenOverlay] Cannot delete: not the author");return}if(at=at.filter(r=>r.id!==n),Wt(),or()){const r=To();await PI(r,n)}lo.has(n)&&(lo.delete(n),uy(n)),fd(),El(),console.log("[OpenOverlay] Annotation deleted:",n)}function cx(n){if(lo.has(n))lo.delete(n),uy(n),console.log("[OpenOverlay] Removed bookmark");else{lo.add(n);const e=at.find(t=>t.id===n);e&&(ux(e),console.log("[OpenOverlay] Added bookmark"))}}function ux(n){const e=Il();e.some(t=>t.id===n.id)||(e.push({id:n.id,pageUrl:window.location.href,pageTitle:document.title,text:n.text,comment:n.comment,authorName:n.authorName,bookmarkedAt:Date.now()}),localStorage.setItem("oo_bookmarks",JSON.stringify(e)))}function uy(n){const e=Il().filter(t=>t.id!==n);localStorage.setItem("oo_bookmarks",JSON.stringify(e))}function Il(){try{return JSON.parse(localStorage.getItem("oo_bookmarks")||"[]")}catch{return[]}}function dx(){const n=Il();lo=new Set(n.map(e=>e.id))}function To(){return btoa(window.location.href).slice(0,32)}let Si=null,S=null,Po=!1,Ut="none",dy="solid",hy="normal",fy="none",Ui=!1,kr=!1,Qe="normal",hs="",Ro="play",Kf="spawn",Vc=!1,Fc=null,rn=!1,Cr=null,co=0,qi=!1;const hx=["#ff3366","#ff6b35","#f59e0b","#22c55e","#06b6d4","#3b82f6","#8b5cf6","#ec4899","#ef4444","#000000","#ffffff","#6b7280"],fx=[{id:"solid",label:"━",title:"Solid"},{id:"spray",label:"░",title:"Spray"},{id:"dots",label:"•••",title:"Dots"},{id:"square",label:"▬",title:"Square"},{id:"rainbow",label:"🌈",title:"Rainbow"},{id:"glow",label:"✦",title:"Glow"}],px=[{id:"normal",label:"A",title:"Normal"},{id:"rainbow",label:"🌈",title:"Rainbow"},{id:"aged",label:"🏚️",title:"Aged"}],gx=[{id:"none",label:"✏️",title:"Freehand"},{id:"line",label:"╱",title:"Line"},{id:"rectangle",label:"▢",title:"Rectangle"},{id:"circle",label:"○",title:"Circle"},{id:"triangle",label:"△",title:"Triangle"},{id:"star",label:"☆",title:"Star"}],mx=["😀","😂","🤣","😍","🥰","😎","🤩","😜","😭","😤","🤯","🥺","😱","🤮","💀","👻","👍","👎","👏","🙌","🤝","✌️","🤟","👋","💪","🫶","🙏","👀","🧠","💅","🦾","🫡","❤️","🧡","💛","💚","💙","💜","🖤","💔","⭐","✨","🔥","💯","💥","💫","🎯","🏆","🐶","🐱","🐻","🦊","🐸","🐵","🦄","🐝","🍕","🍔","🌮","🍩","☕","🎂","🍿","🥤","⚽","🏀","🎮","🎸","🎤","🎬","📸","💻","🚀","💎","🎁","🎈","🎉","🪄","⚡","🌈"],yx=`
  * {
    box-sizing: border-box;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  }

  .fab-container {
    all: initial;
    position: fixed !important;
    right: 18px !important;
    bottom: 18px !important;
    z-index: 2147483647 !important;
    display: flex !important;
    flex-direction: column-reverse !important;
    align-items: center !important;
    gap: 8px !important;
    pointer-events: auto !important;
    touch-action: none !important;
    visibility: visible !important;
    opacity: 1 !important;
    transform: none !important;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif !important;
  }

  .fab-container.dragging {
    opacity: 0.8;
  }

  .fab-container.dragging .fab {
    cursor: grabbing;
  }

  .fab {
    all: initial;
    width: 56px !important;
    height: 56px !important;
    min-width: 56px !important;
    min-height: 56px !important;
    border-radius: 50% !important;
    border: none !important;
    background: rgba(255, 255, 255, 0.95) !important;
    color: #222 !important;
    font-size: 20px !important;
    cursor: pointer !important;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15) !important;
    transition: transform 0.15s, background 0.15s !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    visibility: visible !important;
    opacity: 1 !important;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif !important;
  }

  .fab:hover {
    transform: scale(1.05);
  }

  .fab.open {
    background: #22c55e;
    color: white;
  }

  .quick-explore {
    position: absolute;
    bottom: -8px;
    left: -8px;
    width: 24px;
    height: 24px;
    border-radius: 50%;
    border: 2px solid white;
    background: #ff69b4;
    color: white;
    font-size: 12px;
    cursor: pointer;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.25);
    transition: transform 0.15s, opacity 0.15s;
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 1;
  }

  .quick-explore:hover {
    transform: scale(1.15);
  }

  .fab-container.open .quick-explore {
    display: none;
  }

  .quick-visibility {
    position: absolute;
    bottom: -8px;
    right: -8px;
    width: 24px;
    height: 24px;
    border-radius: 50%;
    border: 2px solid white;
    background: #3b82f6;
    color: white;
    font-size: 11px;
    cursor: pointer;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.25);
    transition: transform 0.15s, opacity 0.15s;
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 1;
  }

  .quick-visibility:hover {
    transform: scale(1.15);
  }

  .quick-visibility.hidden {
    background: #64748b;
    opacity: 0.7;
  }

  .quick-visibility.hidden::after {
    content: '';
    position: absolute;
    width: 18px;
    height: 2px;
    background: #ef4444;
    transform: rotate(-45deg);
    border-radius: 1px;
  }

  .fab-container.open .quick-visibility {
    display: none;
  }

  .dismiss-smudgy {
    position: absolute;
    top: -8px;
    left: -8px;
    width: 20px;
    height: 20px;
    border-radius: 50%;
    border: 2px solid white;
    background: #ef4444;
    color: white;
    font-size: 10px;
    cursor: pointer;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.25);
    transition: transform 0.15s, opacity 0.15s;
    display: none;
    align-items: center;
    justify-content: center;
    font-weight: bold;
  }

  .dismiss-smudgy:hover {
    transform: scale(1.15);
  }

  .dismiss-smudgy.show {
    display: flex;
  }

  .mini {
    width: 44px;
    height: 44px;
    border-radius: 50%;
    border: none;
    background: #fff;
    color: #222;
    font-size: 18px;
    cursor: pointer;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.12);
    transition: transform 0.15s, opacity 0.15s;
    opacity: 0;
    transform: scale(0.5);
    pointer-events: none;
  }

  .mini.show {
    opacity: 1;
    transform: scale(1);
    pointer-events: auto;
  }

  .mini:hover {
    transform: scale(1.1);
  }

  .mini.active {
    background: #22c55e;
    color: white;
  }

  .toolbar {
    position: fixed;
    right: 90px;
    bottom: 18px;
    background: #111;
    color: #fff;
    padding: 10px;
    border-radius: 10px;
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.3);
    display: none;
    flex-direction: column;
    gap: 8px;
    align-items: stretch;
    pointer-events: auto;
    z-index: 2147483647;
    max-width: 320px;
  }

  .toolbar.game-mode {
    flex-direction: column;
    align-items: stretch;
  }

  .toolbar-drag-handle {
    cursor: grab;
    padding: 2px 8px;
    color: #666;
    font-size: 12px;
    user-select: none;
    text-align: center;
  }

  .toolbar-drag-handle:hover {
    color: #999;
  }

  .toolbar-drag-handle:active {
    cursor: grabbing;
  }

  .toolbar.game-mode .toolbar-drag-handle {
    align-self: center;
    margin-bottom: -4px;
  }

  .toolbar.show {
    display: flex;
  }

  .toolbar-row {
    display: flex;
    align-items: center;
    gap: 6px;
    flex-wrap: wrap;
  }

  .toolbar-section {
    display: flex;
    align-items: center;
    gap: 4px;
  }

  .toolbar-divider {
    display: none;
  }

  .toolbar label {
    font-size: 11px;
    color: #888;
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }

  .toolbar input[type="color"] {
    width: 24px;
    height: 24px;
    border: 2px solid #333;
    border-radius: 50%;
    cursor: pointer;
    padding: 0;
    background: none;
    flex-shrink: 0;
  }

  .toolbar input[type="color"]::-webkit-color-swatch-wrapper {
    padding: 0;
  }

  .toolbar input[type="color"]::-webkit-color-swatch {
    border: none;
    border-radius: 50%;
  }

  .toolbar input[type="range"] {
    height: 6px;
    -webkit-appearance: none;
    background: #333;
    border-radius: 3px;
  }

  .toolbar input[type="range"]::-webkit-slider-thumb {
    -webkit-appearance: none;
    width: 18px;
    height: 18px;
    background: #fff;
    border-radius: 50%;
    cursor: pointer;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
  }

  .quick-colors {
    display: grid;
    grid-template-columns: repeat(4, 14px);
    gap: 2px;
  }

  .quick-color {
    width: 14px;
    height: 14px;
    border-radius: 50%;
    border: 2px solid transparent;
    cursor: pointer;
    transition: transform 0.1s;
  }

  .quick-color:hover {
    transform: scale(1.15);
  }

  .quick-color.active {
    border-color: #fff;
    box-shadow: 0 0 0 1px #000;
  }

  .quick-color[data-color="#ffffff"] {
    border-color: #ccc;
  }

  .quick-color[data-color="#000000"] {
    border-color: #333;
  }

  .toolbar.game-mode .quick-colors {
    grid-template-columns: repeat(4, 14px);
  }

  .brush-styles {
    display: flex;
    gap: 2px;
  }

  .brush-btn {
    width: 28px;
    height: 28px;
    border: none;
    background: #222;
    color: #aaa;
    border-radius: 6px;
    cursor: pointer;
    font-size: 14px;
    transition: background 0.1s;
  }

  .brush-btn:hover {
    background: #333;
  }

  .brush-btn.active {
    background: #22c55e;
    color: white;
  }

  .tool-btn {
    width: 32px;
    height: 32px;
    border: none;
    background: #222;
    color: #aaa;
    border-radius: 8px;
    cursor: pointer;
    font-size: 16px;
    transition: background 0.1s;
  }

  .tool-btn:hover {
    background: #333;
  }

  .tool-btn.active {
    background: #ef4444;
    color: white;
  }

  .eraser-btn {
    width: 36px;
    height: 32px;
    background: #222;
    border: 1px solid #333;
    border-radius: 6px;
    font-size: 16px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .eraser-btn:hover {
    background: #333;
  }

  .eraser-btn.active {
    background: #ef4444;
    color: white;
  }

  .shape-tools {
    display: flex;
    gap: 2px;
  }

  .shape-btn {
    width: 28px;
    height: 28px;
    border: none;
    background: #222;
    color: #aaa;
    border-radius: 6px;
    cursor: pointer;
    font-size: 14px;
    transition: background 0.1s;
  }

  .shape-btn:hover {
    background: #333;
  }

  .shape-btn.active {
    background: #8b5cf6;
    color: white;
  }

  .fill-btn {
    width: 28px;
    height: 28px;
    border: none;
    background: #222;
    color: #aaa;
    border-radius: 6px;
    cursor: pointer;
    font-size: 16px;
    margin-left: 4px;
  }

  .fill-btn:hover {
    background: #333;
  }

  .fill-btn.active {
    background: #f59e0b;
    color: white;
  }

  .toolbar button.action-btn {
    padding: 5px 10px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 11px;
    font-weight: 600;
    transition: background 0.1s;
  }

  .btn-undo {
    background: #333;
    color: #fff;
  }

  .btn-undo:hover {
    background: #444;
  }

  .btn-clear {
    background: #333;
    color: #fff;
  }

  .btn-clear:hover {
    background: #444;
  }

  .btn-save {
    background: #22c55e;
    color: white;
  }

  .btn-save:hover {
    background: #16a34a;
  }

  .btn-cancel {
    background: #333;
    color: white;
  }

  .btn-cancel:hover {
    background: #444;
  }

  .size-display {
    font-size: 11px;
    color: #888;
    min-width: 20px;
    text-align: center;
  }

  .opacity-display {
    font-size: 11px;
    color: #888;
    min-width: 28px;
    text-align: center;
  }

  .draw-controls, .text-controls {
    display: none;
    flex-direction: column;
    gap: 6px;
  }

  .draw-controls.active, .text-controls.active {
    display: flex;
  }

  .text-input {
    background: #222;
    border: 1px solid #333;
    border-radius: 6px;
    color: #fff;
    padding: 6px 10px;
    font-size: 13px;
    flex: 1;
    min-width: 100px;
    font-family: inherit;
  }

  .text-input:focus {
    outline: none;
    border-color: #22c55e;
  }

  .text-input::placeholder {
    color: #666;
  }

  .emoji-btn {
    width: 36px;
    height: 32px;
    background: #222;
    border: 1px solid #333;
    border-radius: 6px;
    font-size: 18px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .emoji-btn:hover {
    background: #333;
  }

  .emoji-picker {
    display: none;
    position: absolute;
    bottom: 100%;
    left: 0;
    right: 0;
    margin-bottom: 8px;
    background: #1a1a1a;
    border: 1px solid #333;
    border-radius: 8px;
    padding: 8px;
    max-height: 200px;
    overflow-y: auto;
    z-index: 100;
  }

  .emoji-picker.show {
    display: block;
  }

  .emoji-picker-header {
    font-size: 10px;
    color: #888;
    text-transform: uppercase;
    margin-bottom: 6px;
    padding-bottom: 4px;
    border-bottom: 1px solid #333;
  }

  .emoji-grid {
    display: grid;
    grid-template-columns: repeat(8, 1fr);
    gap: 2px;
  }

  .emoji-item {
    width: 32px;
    height: 32px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 20px;
    cursor: pointer;
    border-radius: 4px;
    background: transparent;
    border: none;
  }

  .emoji-item:hover {
    background: #333;
  }

  .text-styles {
    display: flex;
    gap: 2px;
  }

  .text-style-btn {
    width: 32px;
    height: 32px;
    border: none;
    background: #222;
    color: #aaa;
    border-radius: 6px;
    cursor: pointer;
    font-size: 14px;
    transition: background 0.1s;
  }

  .text-style-btn:hover {
    background: #333;
  }

  .text-style-btn.active {
    background: #22c55e;
    color: white;
  }

  .place-hint {
    font-size: 11px;
    color: #666;
    font-style: italic;
  }

  .game-controls {
    display: none;
    flex-direction: column;
    gap: 8px;
  }

  .game-controls.active {
    display: flex;
  }

  .game-row {
    display: flex;
    align-items: center;
    gap: 6px;
    justify-content: center;
  }

  .game-actions {
    display: flex;
    gap: 4px;
    margin-left: auto;
  }

  .game-colors {
    display: flex;
    gap: 3px;
  }

  .toolbar.game-mode .drawing-only {
    display: none !important;
  }

  .toolbar.game-mode > .toolbar-row,
  .toolbar.game-mode > .toolbar-section,
  .toolbar.game-mode > .toolbar-divider {
    display: none !important;
  }

  .toolbar.game-mode > .toolbar-drag-handle,
  .toolbar.game-mode > .game-controls {
    display: flex !important;
  }

  .char-style-toggle {
    display: flex;
    background: #222;
    border-radius: 4px;
    padding: 2px;
  }

  .char-style-btn {
    padding: 3px 6px;
    border: none;
    background: transparent;
    border-radius: 3px;
    cursor: pointer;
    font-size: 14px;
    transition: background 0.1s;
  }

  .char-style-btn:hover {
    background: #333;
  }

  .char-style-btn.active {
    background: #22c55e;
  }

  .char-customize-select {
    background: #222;
    color: #fff;
    border: 1px solid #333;
    border-radius: 4px;
    padding: 3px 4px;
    font-size: 14px;
    cursor: pointer;
    min-width: 36px;
    text-align: center;
  }

  .char-customize-select:hover {
    border-color: #555;
  }

  .char-customize-select:focus {
    outline: none;
    border-color: #22c55e;
  }

  .screen-name-section {
    margin: 16px 0;
    padding: 12px;
    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
    border-radius: 10px;
    border: 2px solid #0f3460;
  }

  .screen-name-label {
    display: block;
    font-size: 13px;
    color: #e94560;
    margin-bottom: 8px;
    text-transform: uppercase;
    letter-spacing: 1px;
    font-weight: bold;
    text-align: center;
  }

  .screen-name-input {
    width: 100%;
    background: #0a0a15;
    color: #fff;
    border: 2px solid #e94560;
    border-radius: 8px;
    padding: 10px 14px;
    font-size: 18px;
    font-family: "Comic Sans MS", "Chalkboard SE", cursive;
    text-align: center;
    box-sizing: border-box;
  }

  .screen-name-input::placeholder {
    color: #666;
    font-style: italic;
  }

  .screen-name-input:focus {
    outline: none;
    border-color: #22c55e;
    background: #111;
    box-shadow: 0 0 10px rgba(233, 69, 96, 0.3);
  }

  .game-mode-toggle {
    display: flex;
    background: #222;
    border-radius: 6px;
    padding: 2px;
  }

  .game-mode-btn {
    padding: 4px 8px;
    border: none;
    background: transparent;
    color: #888;
    border-radius: 4px;
    cursor: pointer;
    font-size: 14px;
    transition: background 0.1s, color 0.1s;
  }

  .game-mode-btn:hover {
    color: #fff;
  }

  .game-mode-btn.active {
    background: #22c55e;
    color: white;
  }

  .build-tools-section {
    display: flex;
    align-items: center;
  }

  .game-tools {
    display: flex;
    gap: 2px;
  }

  .game-tool-btn {
    width: 28px;
    height: 28px;
    padding: 0;
    border: none;
    background: #222;
    color: #aaa;
    border-radius: 4px;
    cursor: pointer;
    font-size: 13px;
    transition: background 0.1s;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .game-tool-btn:hover {
    background: #333;
  }

  .game-tool-btn.active {
    background: #3b82f6;
    color: white;
  }

  .multiplayer-btn {
    padding: 4px 8px;
    border: none;
    background: #7c3aed;
    color: #fff;
    border-radius: 4px;
    cursor: pointer;
    font-size: 11px;
    font-weight: 600;
    transition: background 0.1s;
  }

  .multiplayer-btn:hover {
    background: #6d28d9;
  }

  .multiplayer-btn.active {
    background: #22c55e;
  }

  .mini.game-btn {
    background: #8b5cf6;
    color: white;
  }

  .mini.game-btn.active {
    background: #22c55e;
  }

  /* Profile button */
  .mini.profile-btn {
    padding: 0;
    overflow: hidden;
  }

  .mini.profile-btn img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    border-radius: 50%;
  }

  /* Profile modal */
  .profile-modal {
    position: fixed;
    bottom: 80px;
    right: 20px;
    width: 320px;
    max-height: calc(100vh - 100px);
    background: #111;
    border-radius: 16px;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
    display: none;
    flex-direction: column;
    overflow-y: auto;
    z-index: 2147483647;
    pointer-events: auto;
  }

  .profile-modal.show {
    display: flex;
  }

  .profile-close {
    position: absolute;
    top: 10px;
    right: 10px;
    width: 28px;
    height: 28px;
    border: none;
    background: #333;
    color: #fff;
    border-radius: 50%;
    font-size: 18px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 10;
  }

  .profile-close:hover {
    background: #444;
  }

  .profile-header {
    padding: 20px;
    display: flex;
    align-items: center;
    gap: 16px;
    border-bottom: 1px solid #333;
  }

  .profile-avatar {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    object-fit: cover;
    border: 2px solid #3b82f6;
  }

  .profile-info {
    flex: 1;
  }

  .profile-name {
    font-size: 18px;
    font-weight: bold;
    color: #fff;
    margin: 0 0 4px 0;
  }

  .profile-email {
    font-size: 12px;
    color: #888;
    margin: 0;
  }

  .profile-stats {
    display: flex;
    gap: 20px;
    padding: 16px 20px;
    border-bottom: 1px solid #333;
  }

  .profile-stat {
    text-align: center;
    cursor: pointer;
  }

  .profile-stat:hover {
    opacity: 0.8;
  }

  .profile-stat-value {
    font-size: 20px;
    font-weight: bold;
    color: #fff;
  }

  .profile-stat-label {
    font-size: 11px;
    color: #888;
    text-transform: uppercase;
  }

  .profile-stat {
    position: relative;
  }

  .notification-badge {
    position: absolute;
    top: -5px;
    right: -5px;
    background: #ef4444;
    color: white;
    font-size: 10px;
    font-weight: bold;
    min-width: 16px;
    height: 16px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 0 4px;
    animation: pulse 2s infinite;
  }

  @keyframes pulse {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.1); }
  }

  .followers-panel {
    display: none;
    padding: 12px 20px;
    border-bottom: 1px solid #333;
    background: rgba(34, 197, 94, 0.1);
  }

  .followers-panel.show {
    display: block;
  }

  .followers-panel-header {
    font-size: 12px;
    font-weight: bold;
    color: #22c55e;
    margin-bottom: 8px;
    text-transform: uppercase;
  }

  .follower-item {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 8px 0;
    border-bottom: 1px solid #333;
  }

  .follower-item:last-child {
    border-bottom: none;
  }

  .follower-avatar {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    object-fit: cover;
    background: #333;
  }

  .follower-info {
    flex: 1;
  }

  .follower-name {
    font-size: 14px;
    color: #fff;
    font-weight: 500;
  }

  .follower-time {
    font-size: 11px;
    color: #888;
  }

  .no-followers {
    color: #666;
    font-size: 13px;
    font-style: italic;
    padding: 8px 0;
  }

  .profile-bio {
    padding: 16px 20px;
    border-bottom: 1px solid #333;
  }

  .profile-bio-label {
    font-size: 11px;
    color: #888;
    text-transform: uppercase;
    margin-bottom: 6px;
  }

  .profile-bio-content {
    color: #ccc;
    font-size: 14px;
    cursor: pointer;
    padding: 8px;
    border-radius: 6px;
    transition: background 0.2s;
  }

  .profile-bio-content:hover {
    background: rgba(255,255,255,0.05);
  }

  .profile-bio-empty {
    color: #666;
    font-style: italic;
  }

  .profile-bio-input {
    width: 100%;
    background: #1a1a1a;
    border: 1px solid #444;
    border-radius: 6px;
    padding: 8px;
    color: #fff;
    font-size: 14px;
    resize: none;
    font-family: inherit;
  }

  .profile-bio-input:focus {
    outline: none;
    border-color: #3b82f6;
  }

  .profile-bio-actions {
    display: flex;
    gap: 8px;
    margin-top: 8px;
  }

  .profile-bio-save {
    background: #22c55e;
    color: white;
    border: none;
    padding: 6px 12px;
    border-radius: 4px;
    font-size: 12px;
    cursor: pointer;
  }

  .profile-bio-cancel {
    background: #666;
    color: white;
    border: none;
    padding: 6px 12px;
    border-radius: 4px;
    font-size: 12px;
    cursor: pointer;
  }

  .profile-actions {
    padding: 16px 20px;
    display: flex;
    gap: 10px;
  }

  .feedback-section {
    padding: 12px 20px;
    border-bottom: 1px solid #333;
    background: linear-gradient(135deg, rgba(34, 197, 94, 0.1) 0%, rgba(59, 130, 246, 0.1) 100%);
  }

  .feedback-header {
    color: #fff;
    font-size: 13px;
    font-weight: 600;
    margin-bottom: 10px;
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .beta-badge {
    background: linear-gradient(135deg, #22c55e, #3b82f6);
    color: white;
    font-size: 9px;
    font-weight: 700;
    padding: 2px 6px;
    border-radius: 4px;
    letter-spacing: 0.5px;
  }

  .feedback-form {
    display: flex;
    flex-direction: column;
    gap: 8px;
  }

  .feedback-select {
    background: #222;
    border: 1px solid #333;
    border-radius: 6px;
    color: #fff;
    padding: 8px 10px;
    font-size: 13px;
    cursor: pointer;
  }

  .feedback-select:focus {
    outline: none;
    border-color: #22c55e;
  }

  .feedback-textarea {
    background: #222;
    border: 1px solid #333;
    border-radius: 6px;
    color: #fff;
    padding: 8px 10px;
    font-size: 13px;
    resize: none;
    font-family: inherit;
  }

  .feedback-textarea:focus {
    outline: none;
    border-color: #22c55e;
  }

  .feedback-textarea::placeholder {
    color: #666;
  }

  .feedback-submit {
    background: #22c55e;
    color: white;
    border: none;
    border-radius: 6px;
    padding: 8px 16px;
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
    transition: background 0.2s;
  }

  .feedback-submit:hover {
    background: #16a34a;
  }

  .feedback-submit:disabled {
    background: #333;
    color: #666;
    cursor: not-allowed;
  }

  .feedback-success {
    color: #22c55e;
    font-size: 13px;
    text-align: center;
    padding: 10px;
  }

  .profile-settings {
    padding: 12px 20px;
    border-bottom: 1px solid #333;
  }

  .profile-settings-header {
    color: #888;
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 8px;
  }

  .profile-setting-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 8px 0;
  }

  .profile-setting-label {
    color: #ccc;
    font-size: 14px;
  }

  .profile-contributors {
    margin-top: 16px;
    padding-top: 12px;
    border-top: 1px solid #333;
  }

  .profile-contributors-header {
    color: #888;
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 8px;
  }

  .contributors-list {
    max-height: 150px;
    overflow-y: auto;
  }

  .no-contributors {
    color: #666;
    font-size: 13px;
    font-style: italic;
    padding: 8px 0;
  }

  .contributor-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 6px 0;
    gap: 10px;
  }

  .contributor-info {
    display: flex;
    align-items: center;
    gap: 8px;
    flex: 1;
    min-width: 0;
  }

  .contributor-avatar {
    width: 24px;
    height: 24px;
    border-radius: 50%;
    background: #333;
    object-fit: cover;
    flex-shrink: 0;
  }

  .contributor-name {
    color: #ddd;
    font-size: 13px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .contributor-toggle {
    flex-shrink: 0;
  }

  .contributor-actions {
    display: flex;
    align-items: center;
    gap: 8px;
    flex-shrink: 0;
  }

  .follow-btn {
    padding: 4px 10px;
    border-radius: 12px;
    border: none;
    font-size: 11px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s;
  }

  .follow-btn.follow {
    background: #3b82f6;
    color: white;
  }

  .follow-btn.follow:hover {
    background: #2563eb;
  }

  .follow-btn.following {
    background: #333;
    color: #aaa;
  }

  .follow-btn.following:hover {
    background: #ef4444;
    color: white;
  }

  .toggle-switch {
    position: relative;
    width: 44px;
    height: 24px;
    background: #333;
    border-radius: 12px;
    cursor: pointer;
    transition: background 0.2s;
  }

  .toggle-switch.active {
    background: #22c55e;
  }

  .toggle-switch::after {
    content: '';
    position: absolute;
    top: 2px;
    left: 2px;
    width: 20px;
    height: 20px;
    background: #fff;
    border-radius: 50%;
    transition: transform 0.2s;
  }

  .toggle-switch.active::after {
    transform: translateX(20px);
  }

  .toggle-switch.small {
    width: 32px;
    height: 18px;
    border-radius: 9px;
  }

  .toggle-switch.small::after {
    width: 14px;
    height: 14px;
  }

  .toggle-switch.small.active::after {
    transform: translateX(14px);
  }

  .char-toggle-profile {
    display: flex;
    gap: 4px;
  }

  .char-btn-profile {
    width: 32px;
    height: 32px;
    border-radius: 6px;
    border: 2px solid #333;
    background: #222;
    font-size: 16px;
    cursor: pointer;
    transition: all 0.15s;
  }

  .char-btn-profile:hover {
    border-color: #555;
  }

  .char-btn-profile.active {
    border-color: #22c55e;
    background: #22c55e22;
  }

  .body-part-toggles {
    display: flex;
    gap: 4px;
  }

  .part-toggle {
    width: 28px;
    height: 28px;
    border-radius: 50%;
    border: 2px solid #444;
    background: #222;
    font-size: 12px;
    cursor: pointer;
    transition: all 0.15s;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .part-toggle:hover {
    border-color: #666;
    transform: scale(1.05);
  }

  .part-toggle.active {
    border-color: #22c55e;
    background: #22c55e22;
  }

  .profile-color-picker {
    display: flex;
    align-items: center;
  }

  .profile-color-swatches {
    display: flex;
    gap: 4px;
    flex-wrap: wrap;
  }

  .profile-color-swatch {
    width: 24px;
    height: 24px;
    border-radius: 50%;
    border: 2px solid #333;
    cursor: pointer;
    transition: all 0.15s;
  }

  .profile-color-swatch:hover {
    transform: scale(1.1);
    border-color: #555;
  }

  .profile-color-swatch.active {
    border-color: #fff;
    box-shadow: 0 0 0 2px #22c55e;
  }

  .profile-select {
    background: #222;
    color: #fff;
    border: 1px solid #333;
    border-radius: 6px;
    padding: 6px 10px;
    font-size: 13px;
    cursor: pointer;
  }

  .profile-select:focus {
    outline: none;
    border-color: #22c55e;
  }

  .profile-bookmarks {
    padding: 12px 20px;
    border-bottom: 1px solid #333;
    max-height: 200px;
    overflow-y: auto;
  }

  .profile-bookmarks-header {
    color: #888;
    font-size: 12px;
    text-transform: uppercase;
    margin-bottom: 10px;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .profile-bookmarks-count {
    background: #333;
    padding: 2px 8px;
    border-radius: 10px;
    font-size: 11px;
  }

  .bookmark-item {
    background: #222;
    border-radius: 8px;
    padding: 10px;
    margin-bottom: 8px;
    cursor: pointer;
    transition: background 0.15s;
  }

  .bookmark-item:hover {
    background: #333;
  }

  .bookmark-quote {
    color: #fff;
    font-size: 13px;
    margin-bottom: 4px;
    font-style: italic;
  }

  .bookmark-meta {
    color: #888;
    font-size: 11px;
  }

  .no-bookmarks {
    color: #666;
    font-size: 13px;
    font-style: italic;
    text-align: center;
    padding: 20px;
  }

  .profile-btn {
    flex: 1;
    padding: 10px 16px;
    border: none;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    transition: background 0.15s;
  }

  .profile-btn.primary {
    background: #3b82f6;
    color: white;
  }

  .profile-btn.primary:hover {
    background: #2563eb;
  }

  .profile-btn.secondary {
    background: #333;
    color: #fff;
  }

  .profile-btn.secondary:hover {
    background: #444;
  }

  .profile-btn.danger {
    background: #ef4444;
    color: white;
  }

  .profile-btn.danger:hover {
    background: #dc2626;
  }

  .login-prompt {
    padding: 40px 20px;
    text-align: center;
  }

  .login-prompt p {
    color: #888;
    margin: 0 0 20px 0;
  }

  .login-btn {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    padding: 12px 24px;
    background: #fff;
    color: #333;
    border: none;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
  }

  .login-btn:hover {
    background: #f0f0f0;
  }

  .login-btn img {
    width: 20px;
    height: 20px;
  }

  .help-btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 8px 16px;
    background: transparent;
    color: #ff69b4;
    border: 2px solid #ff69b4;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 500;
    cursor: pointer;
    margin-top: 12px;
    transition: all 0.2s;
  }

  .help-btn:hover {
    background: #ff69b4;
    color: white;
  }

  .help-modal {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0,0,0,0.85);
    z-index: 10000;
    display: none;
    padding: 20px;
  }

  .help-modal.show {
    display: flex;
    justify-content: center;
    align-items: flex-start;
  }

  .help-content {
    position: relative;
    max-width: 600px;
    width: 100%;
    max-height: calc(100vh - 80px);
    overflow-y: auto;
    background: #1a1a2e;
    border-radius: 16px;
    padding: 24px;
    padding-top: 50px;
    padding-bottom: 40px;
    color: white;
    font-family: system-ui, sans-serif;
    margin-top: 20px;
  }

  .help-close {
    position: absolute;
    top: 12px;
    right: 12px;
    background: #333;
    border: none;
    color: white;
    font-size: 24px;
    width: 36px;
    height: 36px;
    border-radius: 50%;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 10;
  }

  .help-close:hover {
    background: #ff69b4;
  }

  .help-title {
    font-size: 24px;
    font-weight: bold;
    color: #ff69b4;
    margin: 0 0 20px 0;
    text-align: center;
  }

  .help-section {
    margin-bottom: 24px;
  }

  .help-section-title {
    font-size: 16px;
    font-weight: bold;
    color: #ff69b4;
    margin: 0 0 12px 0;
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .help-section-content {
    font-size: 14px;
    line-height: 1.6;
    color: #ccc;
  }

  .help-grid {
    display: grid;
    grid-template-columns: auto 1fr;
    gap: 8px 16px;
    margin-top: 8px;
  }

  .help-key {
    font-weight: bold;
    color: white;
    background: #333;
    padding: 2px 8px;
    border-radius: 4px;
    font-size: 13px;
  }

  .help-value {
    color: #aaa;
  }

  .help-buttons {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    margin-top: 8px;
  }

  .help-button-item {
    background: #2a2a3e;
    padding: 6px 12px;
    border-radius: 6px;
    font-size: 13px;
  }

  .help-button-icon {
    margin-right: 4px;
  }
`,Xf="oo_signin_reminder_last",vx=4*60*60*1e3;function Uc(n){const e=document.createElement("div");e.style.cssText=`
    position: fixed;
    top: 80px;
    left: 50%;
    transform: translateX(-50%);
    background: linear-gradient(135deg, #ff6b6b, #ee5a5a);
    color: white;
    padding: 12px 24px;
    border-radius: 8px;
    font-family: system-ui, sans-serif;
    font-size: 14px;
    font-weight: 500;
    z-index: 2147483647;
    box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    animation: slideDown 0.3s ease;
  `,e.textContent=n+" - Click the profile button to sign in",document.body.appendChild(e),setTimeout(()=>{e.style.opacity="0",e.style.transition="opacity 0.3s",setTimeout(()=>e.remove(),300)},3e3)}function bx(){if(ce())return;const e=localStorage.getItem(Xf),t=Date.now();(!e||t-parseInt(e,10)>vx)&&setTimeout(()=>{ce()||(Uc("Sign in to share drawings with others"),localStorage.setItem(Xf,t.toString()))},1e4)}function wx(){if(console.log("[OpenOverlay] initUI starting..."),!document.body){console.error("[OpenOverlay] No document.body!");return}Si=document.createElement("div"),Si.id="openoverlay-ui",Si.style.cssText=`
    all: initial;
    position: fixed !important;
    top: 0 !important;
    left: 0 !important;
    right: 0 !important;
    bottom: 0 !important;
    width: 100vw !important;
    height: 100vh !important;
    z-index: 2147483647 !important;
    pointer-events: none !important;
    overflow: visible !important;
    display: block !important;
    visibility: visible !important;
    opacity: 1 !important;
    transform: none !important;
    margin: 0 !important;
    padding: 0 !important;
    border: none !important;
    box-sizing: border-box !important;
  `,S=Si.attachShadow({mode:"open"});const n=document.createElement("style");n.textContent=yx,S.appendChild(n);const e=document.createElement("div");e.className="fab-container";const t=document.createElement("button");t.className="fab",t.textContent="•••",t.title="OpenOverlay",t.onclick=()=>{var D;rn&&(rn=!1,(D=S==null?void 0:S.querySelector("#oo-profile-modal"))==null||D.classList.remove("show")),py()},e.appendChild(t);const o=document.createElement("button");o.className="quick-explore",o.textContent="🏃",o.title="Quick drop Smudgy";let r=!1;o.onclick=D=>{D.stopPropagation(),r?(r=!1,Ut="none",o.style.background="#ff69b4",document.dispatchEvent(new CustomEvent("oo:gamemode",{detail:{mode:"none"}}))):(r=!0,Ut="game",o.style.background="#22c55e",document.dispatchEvent(new CustomEvent("oo:gamemode",{detail:{mode:"play",playmode:"explore"}})))},document.addEventListener("oo:gamemode",D=>{D.detail.mode==="none"?(r=!1,o.style.background="#ff69b4"):D.detail.mode==="play"&&D.detail.playmode==="explore"&&(r=!0,o.style.background="#22c55e")}),e.appendChild(o);const i=document.createElement("button");i.className="quick-visibility",i.innerHTML="👁",i.title="Hide drawings";let s=!0;const c=()=>{i.classList.toggle("hidden",!s),i.title=s?"Hide drawings":"Show drawings"};i.onclick=D=>{var E;D.stopPropagation(),s=!s,c(),ze.showAll=s,(E=S==null?void 0:S.querySelector("#toggle-all-drawings"))==null||E.classList.toggle("active",s),document.dispatchEvent(new CustomEvent("oo:visibility:all",{detail:{show:s}}))},document.addEventListener("oo:visibility:all",D=>{s=D.detail.show,c()}),e.appendChild(i);const d=document.createElement("button");d.className="dismiss-smudgy",d.textContent="✕",d.title="Dismiss Smudgy",d.onclick=D=>{D.stopPropagation(),document.dispatchEvent(new CustomEvent("oo:dismisssmudgy")),d.classList.remove("show")},e.appendChild(d),document.addEventListener("oo:ambientstart",()=>{d.classList.add("show")}),document.addEventListener("oo:ambientend",()=>{d.classList.remove("show")});const u=document.createElement("button");u.className="mini",u.textContent="✏️",u.title="Draw",u.onclick=()=>nc("draw"),e.appendChild(u);const f=document.createElement("button");f.className="mini",f.textContent="T",f.title="Text",f.onclick=()=>nc("text"),e.appendChild(f);const g=document.createElement("button");g.className="mini game-btn",g.textContent="🎮",g.title="Game",g.onclick=()=>nc("game"),e.appendChild(g);const m=document.createElement("button");m.className="mini profile-btn",m.id="oo-profile-btn",m.textContent="⚙️",m.title="Settings & Profile",m.onclick=Sx,e.appendChild(m),S.appendChild(e);let v=!1,O=0,C=0,L=18,H=18;const z=localStorage.getItem("oo_fab_position");if(z)try{const D=JSON.parse(z);e.style.right=D.right+"px",e.style.bottom=D.bottom+"px",L=D.right,H=D.bottom}catch{}t.addEventListener("pointerdown",D=>{if(D.shiftKey){D.preventDefault(),v=!0,O=D.clientX,C=D.clientY;const E=getComputedStyle(e);L=parseInt(E.right)||18,H=parseInt(E.bottom)||18,e.classList.add("dragging"),t.setPointerCapture(D.pointerId)}}),t.addEventListener("pointermove",D=>{if(!v)return;D.preventDefault();const E=O-D.clientX,w=C-D.clientY,b=Math.max(10,Math.min(window.innerWidth-70,L+E)),I=Math.max(10,Math.min(window.innerHeight-70,H+w));e.style.right=b+"px",e.style.bottom=I+"px"}),t.addEventListener("pointerup",D=>{if(v){v=!1,e.classList.remove("dragging"),t.releasePointerCapture(D.pointerId);const E=getComputedStyle(e);localStorage.setItem("oo_fab_position",JSON.stringify({right:parseInt(E.right)||18,bottom:parseInt(E.bottom)||18}))}});const N=document.createElement("div");N.className="profile-modal",N.id="oo-profile-modal",N.innerHTML=`
    <button class="profile-close" id="profile-close-btn">&times;</button>
    <div class="login-prompt" id="login-prompt">
      <p>Sign in to save your drawings and follow other users +many more features</p>
      <button class="help-btn" id="help-btn-login">📖 How to Use</button>
      <button class="login-btn" id="google-login-btn">
        <svg width="20" height="20" viewBox="0 0 24 24">
          <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
          <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
          <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
          <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
        </svg>
        Sign in with Google
      </button>
    </div>
    <div class="profile-content" id="profile-content" style="display: none;">
      <div class="profile-header">
        <img class="profile-avatar" id="profile-avatar" src="" alt="Profile">
        <div class="profile-info">
          <h3 class="profile-name" id="profile-name">User Name</h3>
          <p class="profile-email" id="profile-email">email@example.com</p>
        </div>
      </div>
      <div class="screen-name-section">
        <label class="screen-name-label">Your Game Name</label>
        <input type="text" class="screen-name-input" id="oo-screen-name" placeholder="Pick a nickname!" maxlength="12">
      </div>
      <div class="profile-stats">
        <div class="profile-stat" id="followers-stat" title="Click to view followers">
          <div class="profile-stat-value" id="followers-count">0</div>
          <div class="profile-stat-label">Followers</div>
        </div>
        <div class="profile-stat" id="following-stat" title="Click to view following">
          <div class="profile-stat-value" id="following-count">0</div>
          <div class="profile-stat-label">Following</div>
        </div>
      </div>
      <div class="followers-panel" id="followers-panel">
        <div class="followers-panel-header">Your Followers</div>
        <div id="followers-list">
          <div class="no-followers">Loading followers...</div>
        </div>
      </div>
      <div class="profile-bio" id="profile-bio">
        <div class="profile-bio-label">Bio (click to edit)</div>
        <div class="profile-bio-content" id="profile-bio-content">
          <span class="profile-bio-empty">Click to add a bio...</span>
        </div>
        <div class="profile-bio-edit" id="profile-bio-edit" style="display:none;">
          <textarea class="profile-bio-input" id="profile-bio-input" placeholder="Tell others about yourself..." maxlength="150" rows="3"></textarea>
          <div class="profile-bio-actions">
            <button class="profile-bio-save" id="profile-bio-save">Save</button>
            <button class="profile-bio-cancel" id="profile-bio-cancel">Cancel</button>
          </div>
        </div>
      </div>
      <div class="profile-settings" id="character-settings">
        <div class="profile-settings-header">Character Settings</div>
        <div class="profile-setting-row">
          <span class="profile-setting-label">Character</span>
          <div class="char-toggle-profile">
            <button class="char-btn-profile active" id="profile-char-boy" title="Boy">👦</button>
            <button class="char-btn-profile" id="profile-char-girl" title="Girl">👧</button>
          </div>
        </div>
        <div class="profile-setting-row">
          <span class="profile-setting-label">Part</span>
          <div class="body-part-toggles" id="body-part-toggles">
            <button class="part-toggle active" data-part="body" title="Body">🦴</button>
            <button class="part-toggle" data-part="head" title="Head">⚪</button>
            <button class="part-toggle" data-part="face" title="Face">🩷</button>
            <button class="part-toggle" data-part="hair" title="Hair">💇</button>
            <button class="part-toggle" data-part="dress" title="Dress">👗</button>
          </div>
        </div>
        <div class="profile-setting-row">
          <span class="profile-setting-label">Color</span>
          <div class="profile-color-picker" id="profile-color-picker">
            <div class="profile-color-swatches" id="profile-color-swatches"></div>
          </div>
        </div>
        <div class="profile-setting-row">
          <span class="profile-setting-label">Hat</span>
          <select class="profile-select" id="profile-hat-select">
            <option value="none">None</option>
            <option value="cap">🧢 Cap</option>
            <option value="tophat">🎩 Top Hat</option>
            <option value="crown">👑 Crown</option>
            <option value="beanie">🧶 Beanie</option>
            <option value="party">🎉 Party</option>
          </select>
        </div>
        <div class="profile-setting-row">
          <span class="profile-setting-label">Face</span>
          <select class="profile-select" id="profile-accessory-select">
            <option value="none">None</option>
            <option value="glasses">👓 Glasses</option>
            <option value="sunglasses">🕶️ Sunglasses</option>
            <option value="mustache">🥸 Mustache</option>
            <option value="beard">🧔 Beard</option>
            <option value="mask">😷 Mask</option>
          </select>
        </div>
        <div class="profile-setting-row">
          <span class="profile-setting-label">Respawn in explore</span>
          <div class="toggle-switch active" id="toggle-respawn" title="Respawn when falling off screen"></div>
        </div>
      </div>
      <div class="profile-settings">
        <div class="profile-settings-header">Drawing Visibility</div>
        <div class="profile-setting-row">
          <span class="profile-setting-label">Show all drawings</span>
          <div class="toggle-switch active" id="toggle-all-drawings" title="Master toggle - hide all drawings"></div>
        </div>
        <div class="profile-setting-row">
          <span class="profile-setting-label">My drawings</span>
          <div class="toggle-switch active" id="toggle-my-drawings" title="Show or hide your own drawings"></div>
        </div>
        <div class="profile-setting-row">
          <span class="profile-setting-label">Only people I follow</span>
          <div class="toggle-switch" id="toggle-following-only" title="Show only drawings from users you follow"></div>
        </div>
        <div class="profile-contributors" id="contributors-section">
          <div class="profile-contributors-header">Contributors on this page</div>
          <div id="contributors-list" class="contributors-list">
            <div class="no-contributors">No other contributors yet</div>
          </div>
        </div>
      </div>
      <div class="profile-settings" id="race-course-settings" style="display: none;">
        <div class="profile-settings-header">Race Course</div>
        <div class="profile-setting-row">
          <span class="profile-setting-label">Select course</span>
          <select class="profile-select" id="race-course-select">
            <option value="mine">My Course</option>
          </select>
        </div>
      </div>
      <div class="profile-bookmarks" id="profile-bookmarks">
        <div class="profile-bookmarks-header">
          Bookmarks <span class="profile-bookmarks-count" id="bookmarks-count">0</span>
        </div>
        <div id="bookmarks-list"></div>
      </div>
      <div class="feedback-section">
        <div class="feedback-header">
          <span class="beta-badge">BETA</span>
          Send Feedback
        </div>
        <div class="feedback-form" id="feedback-form">
          <select id="feedback-type" class="feedback-select">
            <option value="bug">🐛 Bug Report</option>
            <option value="feature">💡 Feature Request</option>
            <option value="other">💬 Other Feedback</option>
          </select>
          <textarea id="feedback-text" class="feedback-textarea" placeholder="Describe the issue or suggestion..." rows="3"></textarea>
          <button class="feedback-submit" id="feedback-submit">Send Feedback</button>
        </div>
        <div class="feedback-success" id="feedback-success" style="display:none;">
          ✓ Thanks for your feedback!
        </div>
      </div>
      <div class="profile-actions">
        <button class="help-btn" id="help-btn-profile">📖 How to Use</button>
        <button class="profile-btn danger" id="signout-btn">Sign Out</button>
      </div>
    </div>
  `,S.appendChild(N);const $=document.createElement("div");$.id="oo-help-modal",$.style.cssText=`
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0,0,0,0.9);
    z-index: 2147483647;
    display: none;
    justify-content: center;
    align-items: flex-start;
    padding: 20px;
    font-family: system-ui, -apple-system, sans-serif;
  `,$.innerHTML=`
    <div id="oo-help-content" style="
      position: relative;
      max-width: 600px;
      width: 100%;
      max-height: calc(100vh - 80px);
      overflow-y: auto;
      background: #1a1a2e;
      border-radius: 16px;
      padding: 24px;
      padding-top: 50px;
      padding-bottom: 40px;
      color: white;
      margin-top: 20px;
    ">
      <button id="oo-help-close" style="
        position: absolute;
        top: 12px;
        right: 12px;
        background: #444;
        border: none;
        color: white;
        font-size: 20px;
        width: 36px;
        height: 36px;
        border-radius: 50%;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
      ">&times;</button>
      <h1 style="font-size: 24px; font-weight: bold; color: #ff69b4; margin: 0 0 20px 0; text-align: center;">📖 How to Use OpenOverlay</h1>

      <div style="margin-bottom: 24px;">
        <h2 style="font-size: 16px; font-weight: bold; color: #ff69b4; margin: 0 0 12px 0;">🎯 Getting Started</h2>
        <div style="font-size: 14px; line-height: 1.6; color: #ccc;">
          Click the pink Smudgy button in the bottom-right corner to open the menu. You'll see 4 buttons for different features.
        </div>
      </div>

      <div style="margin-bottom: 24px;">
        <h2 style="font-size: 16px; font-weight: bold; color: #ff69b4; margin: 0 0 12px 0;">✏️ Draw Mode</h2>
        <div style="font-size: 14px; line-height: 1.6; color: #ccc;">
          Draw on any webpage! Your drawings become platforms your character can walk on.
          <div style="display: flex; flex-wrap: wrap; gap: 8px; margin-top: 8px;">
            <span style="background: #2a2a3e; padding: 6px 12px; border-radius: 6px; font-size: 13px;">● Solid</span>
            <span style="background: #2a2a3e; padding: 6px 12px; border-radius: 6px; font-size: 13px;">○ Outline</span>
            <span style="background: #2a2a3e; padding: 6px 12px; border-radius: 6px; font-size: 13px;">••• Dots</span>
            <span style="background: #2a2a3e; padding: 6px 12px; border-radius: 6px; font-size: 13px;">≋ Spray</span>
            <span style="background: #2a2a3e; padding: 6px 12px; border-radius: 6px; font-size: 13px;">～ Glow</span>
          </div>
          <div style="display: grid; grid-template-columns: auto 1fr; gap: 8px 16px; margin-top: 12px;">
            <span style="font-weight: bold; color: white; background: #333; padding: 2px 8px; border-radius: 4px; font-size: 13px;">🧹</span><span style="color: #aaa;">Eraser</span>
            <span style="font-weight: bold; color: white; background: #333; padding: 2px 8px; border-radius: 4px; font-size: 13px;">⬇️</span><span style="color: #aaa;">Draw behind character</span>
            <span style="font-weight: bold; color: white; background: #333; padding: 2px 8px; border-radius: 4px; font-size: 13px;">⬆️</span><span style="color: #aaa;">Draw in front of character</span>
          </div>
        </div>
      </div>

      <div style="margin-bottom: 24px;">
        <h2 style="font-size: 16px; font-weight: bold; color: #ff69b4; margin: 0 0 12px 0;">📝 Text Mode</h2>
        <div style="font-size: 14px; line-height: 1.6; color: #ccc;">
          Add text stickers and emojis to any page! Click anywhere to place your text.
          <div style="display: grid; grid-template-columns: auto 1fr; gap: 8px 16px; margin-top: 8px;">
            <span style="font-weight: bold; color: white; background: #333; padding: 2px 8px; border-radius: 4px; font-size: 13px;">😀</span><span style="color: #aaa;">Open emoji picker</span>
            <span style="font-weight: bold; color: white; background: #333; padding: 2px 8px; border-radius: 4px; font-size: 13px;">B / I</span><span style="color: #aaa;">Bold / Italic text</span>
          </div>
        </div>
      </div>

      <div style="margin-bottom: 24px;">
        <h2 style="font-size: 16px; font-weight: bold; color: #ff69b4; margin: 0 0 12px 0;">🎮 Game Mode</h2>
        <div style="font-size: 14px; line-height: 1.6; color: #ccc;">
          Spawn your character and play! Walk on the drawings you create.
          <div style="display: grid; grid-template-columns: auto 1fr; gap: 8px 16px; margin-top: 8px;">
            <span style="font-weight: bold; color: white; background: #333; padding: 2px 8px; border-radius: 4px; font-size: 13px;">A / ←</span><span style="color: #aaa;">Move left</span>
            <span style="font-weight: bold; color: white; background: #333; padding: 2px 8px; border-radius: 4px; font-size: 13px;">D / →</span><span style="color: #aaa;">Move right</span>
            <span style="font-weight: bold; color: white; background: #333; padding: 2px 8px; border-radius: 4px; font-size: 13px;">W / Space</span><span style="color: #aaa;">Jump</span>
          </div>
          <div style="display: flex; flex-wrap: wrap; gap: 8px; margin-top: 12px;">
            <span style="background: #2a2a3e; padding: 6px 12px; border-radius: 6px; font-size: 13px;">👥 Multiplayer</span>
            <span style="background: #2a2a3e; padding: 6px 12px; border-radius: 6px; font-size: 13px;">🏷️ Tag Game</span>
            <span style="background: #2a2a3e; padding: 6px 12px; border-radius: 6px; font-size: 13px;">🏃 Race Mode</span>
          </div>
        </div>
      </div>

      <div style="margin-bottom: 24px;">
        <h2 style="font-size: 16px; font-weight: bold; color: #ff69b4; margin: 0 0 12px 0;">🏗️ Build Race Courses</h2>
        <div style="font-size: 14px; line-height: 1.6; color: #ccc;">
          Create custom race tracks with obstacles!
          <div style="display: grid; grid-template-columns: auto 1fr; gap: 8px 16px; margin-top: 8px;">
            <span style="font-weight: bold; color: white; background: #333; padding: 2px 8px; border-radius: 4px; font-size: 13px;">🏁</span><span style="color: #aaa;">Start line</span>
            <span style="font-weight: bold; color: white; background: #333; padding: 2px 8px; border-radius: 4px; font-size: 13px;">🏆</span><span style="color: #aaa;">Finish line</span>
            <span style="font-weight: bold; color: white; background: #333; padding: 2px 8px; border-radius: 4px; font-size: 13px;">🚩</span><span style="color: #aaa;">Checkpoints</span>
            <span style="font-weight: bold; color: white; background: #333; padding: 2px 8px; border-radius: 4px; font-size: 13px;">🔶</span><span style="color: #aaa;">Trampolines</span>
            <span style="font-weight: bold; color: white; background: #333; padding: 2px 8px; border-radius: 4px; font-size: 13px;">🔺</span><span style="color: #aaa;">Spikes (hazard!)</span>
          </div>
        </div>
      </div>

      <div style="margin-bottom: 24px;">
        <h2 style="font-size: 16px; font-weight: bold; color: #ff69b4; margin: 0 0 12px 0;">👤 Profile Features</h2>
        <div style="font-size: 14px; line-height: 1.6; color: #ccc;">
          Sign in to save drawings, customize your character, and play multiplayer!
        </div>
      </div>
    </div>
  `,document.body.appendChild($);const j=document.createElement("div");j.className="toolbar",j.id="oo-toolbar",j.innerHTML=`
    <!-- DRAG HANDLE -->
    <div class="toolbar-drag-handle" id="oo-drag-handle" title="Drag to move">⠿</div>

    <!-- DRAW MODE CONTROLS -->
    <div class="draw-controls active" id="draw-controls">
      <!-- Row 1: Brushes + Tools -->
      <div class="toolbar-row">
        <div class="brush-styles" id="oo-brushes">
          ${fx.map(D=>`
            <button class="brush-btn ${D.id==="solid"?"active":""}"
                    data-brush="${D.id}" title="${D.title}">${D.label}</button>
          `).join("")}
        </div>
        <button class="eraser-btn" id="oo-eraser" title="Eraser">🧹</button>
        <button class="tool-btn" id="oo-layer-bg" title="Background">⬇️</button>
        <button class="tool-btn" id="oo-layer-fg" title="Foreground">⬆️</button>
      </div>
      <!-- Row 2: Shapes -->
      <div class="toolbar-row">
        <div class="shape-tools" id="oo-shapes">
          ${gx.map(D=>`
            <button class="shape-btn ${D.id==="none"?"active":""}"
                    data-shape="${D.id}" title="${D.title}">${D.label}</button>
          `).join("")}
        </div>
        <button class="fill-btn" id="oo-fill-toggle" title="Toggle fill">◧</button>
      </div>
    </div>

    <!-- TEXT MODE CONTROLS -->
    <div class="text-controls" id="text-controls" style="position: relative;">
      <div class="emoji-picker" id="oo-emoji-picker">
        <div class="emoji-picker-header">Emojis & Stickers</div>
        <div class="emoji-grid" id="oo-emoji-grid"></div>
      </div>
      <div class="toolbar-row">
        <button class="emoji-btn" id="oo-emoji-btn" title="Add emoji">😀</button>
        <input type="text" class="text-input" id="oo-text-input" placeholder="Type or pick emoji...">
        <div class="text-styles" id="oo-text-styles">
          ${px.map(D=>`
            <button class="text-style-btn ${D.id==="normal"?"active":""}"
                    data-style="${D.id}" title="${D.title}">${D.label}</button>
          `).join("")}
        </div>
        <button class="tool-btn" id="oo-text-layer-bg" title="Background (behind character)">⬇️</button>
        <button class="tool-btn" id="oo-text-layer-fg" title="Foreground (in front of character)">⬆️</button>
      </div>
      <span class="place-hint">Click page to place (default: regular layer)</span>
    </div>

    <!-- GAME MODE CONTROLS -->
    <div class="game-controls" id="game-controls">
      <!-- Row 1: Play Mode Buttons -->
      <div class="game-row">
        <div class="game-mode-toggle">
          <button class="game-mode-btn" id="oo-multiplayer-setup" data-mode="play" data-playmode="explore" title="Multiplayer Explore">👥 MP</button>
          <button class="game-mode-btn" id="oo-tag-game" data-mode="play" data-playmode="explore" title="Tag Game">🏷️ Tag</button>
          <button class="game-mode-btn" data-mode="play" data-playmode="race" title="Race">🏃 Race</button>
        </div>
      </div>

      <!-- Row 2: Build Tools (shown by default in build mode) -->
      <div class="game-row build-tools-section">
        <div class="game-tools" id="game-tools">
          <button class="game-tool-btn" data-tool="select" title="Select">✋</button>
          <button class="game-tool-btn active" data-tool="spawn" title="Spawn">👤</button>
          <button class="game-tool-btn" data-tool="start" title="Start">🏁</button>
          <button class="game-tool-btn" data-tool="finish" title="Finish">🏆</button>
          <button class="game-tool-btn" data-tool="checkpoint" title="Checkpoint">🚩</button>
          <button class="game-tool-btn" data-tool="trampoline" title="Bounce">🔶</button>
          <button class="game-tool-btn" data-tool="speedBoost" title="Speed">💨</button>
          <button class="game-tool-btn" data-tool="highJump" title="Jump">🦘</button>
          <button class="game-tool-btn" data-tool="spike" title="Spike">🔺</button>
        </div>
      </div>

      <!-- Row 3: Actions -->
      <div class="game-row">
        <div class="game-actions">
          <button class="action-btn btn-undo" id="oo-game-undo" title="Undo">↩</button>
          <button class="action-btn btn-clear" id="oo-game-clear" title="Clear">🗑</button>
          <button class="action-btn btn-cancel" id="oo-game-cancel">✕</button>
          <button class="action-btn btn-save" id="oo-game-save">✓</button>
        </div>
      </div>
    </div>

    <!-- SHARED CONTROLS -->
    <!-- Color Row -->
    <div class="toolbar-row">
      <input type="color" id="oo-color" value="#ff3366" title="Color">
      <div class="quick-colors" id="oo-quick-colors">
        ${hx.map((D,E)=>`
          <div class="quick-color ${E===0?"active":""}"
               data-color="${D}"
               style="background: ${D}"
               title="${D}"></div>
        `).join("")}
      </div>
    </div>

    <!-- Size/Opacity Row (hidden in game mode) -->
    <div class="toolbar-row drawing-only">
      <label>Size</label>
      <input type="range" id="oo-size" min="1" max="150" value="24" style="width: 80px;">
      <span class="size-display" id="oo-size-display">24</span>
      <label style="margin-left: 8px;">Op</label>
      <input type="range" id="oo-opacity" min="10" max="100" value="100" style="width: 60px;">
      <span class="opacity-display" id="oo-opacity-display">100%</span>
    </div>

    <!-- Actions Row -->
    <div class="toolbar-row">
      <button class="action-btn btn-undo" id="oo-undo" title="Undo">↩</button>
      <button class="action-btn btn-clear" id="oo-clear" title="Clear All">🗑</button>
      <div style="flex: 1;"></div>
      <button class="action-btn btn-cancel" id="oo-cancel">Cancel</button>
      <button class="action-btn btn-save" id="oo-save">Save</button>
    </div>
  `,S.appendChild(j),_x(j),document.body.appendChild(Si),document.addEventListener("oo:hidetoolbar",()=>{const D=S==null?void 0:S.querySelector(".toolbar");D==null||D.classList.remove("show"),Ut="none",Ro="play";const E=S==null?void 0:S.querySelectorAll(".mini");E==null||E.forEach(w=>w.classList.remove("active"))}),console.log("[OpenOverlay] UI initialized"),bx()}function _x(n){var ii,Ge,et,Eo,Ms,si,Ns,zn,ai,li,ar,Ls,Ds;n.querySelectorAll(".brush-btn").forEach(P=>{P.addEventListener("click",()=>{dy=P.dataset.brush||"solid",n.querySelectorAll(".brush-btn").forEach(K=>K.classList.remove("active")),P.classList.add("active"),mt()})}),n.querySelectorAll(".text-style-btn").forEach(P=>{P.addEventListener("click",()=>{hy=P.dataset.style||"normal",n.querySelectorAll(".text-style-btn").forEach(K=>K.classList.remove("active")),P.classList.add("active"),mt()})}),n.querySelectorAll(".shape-btn").forEach(P=>{P.addEventListener("click",()=>{fy=P.dataset.shape||"none",n.querySelectorAll(".shape-btn").forEach(K=>K.classList.remove("active")),P.classList.add("active"),mt()})});const e=n.querySelector("#oo-fill-toggle");e==null||e.addEventListener("click",()=>{Ui=!Ui,e.classList.toggle("active",Ui),e.textContent=Ui?"◼":"◧",mt()});const t=n.querySelector("#oo-emoji-btn"),o=n.querySelector("#oo-emoji-picker"),r=n.querySelector("#oo-emoji-grid");r&&(r.innerHTML=mx.map(P=>`<button class="emoji-item" data-emoji="${P}">${P}</button>`).join("")),t==null||t.addEventListener("click",P=>{P.stopPropagation(),o==null||o.classList.toggle("show")}),r==null||r.addEventListener("click",P=>{const K=P.target.dataset.emoji;if(K){const re=n.querySelector("#oo-text-input");if(re){const Ye=re.selectionStart||re.value.length,Ae=re.selectionEnd||re.value.length,Ke=re.value.substring(0,Ye),Io=re.value.substring(Ae);re.value=Ke+K+Io,re.focus(),re.dispatchEvent(new Event("input",{bubbles:!0}))}o==null||o.classList.remove("show")}}),document.addEventListener("click",P=>{if(o!=null&&o.classList.contains("show")){const B=P.target;!o.contains(B)&&B!==t&&o.classList.remove("show")}});const i=n.querySelector("#oo-text-input");let s=null;i==null||i.addEventListener("input",()=>{const P=i.value;hs=P,console.log("[OpenOverlay] Text input:",P,"liveTextId:",s),P.trim()&&!s?(console.log("[OpenOverlay] Creating text in center"),document.dispatchEvent(new CustomEvent("oo:textcreate",{detail:{text:P}}))):P.trim()&&s?document.dispatchEvent(new CustomEvent("oo:textupdate",{detail:{text:P}})):!P.trim()&&s&&(document.dispatchEvent(new CustomEvent("oo:textdelete",{detail:{id:s}})),s=null),mt()}),document.addEventListener("oo:textcreated",P=>{console.log("[OpenOverlay] Text created with id:",P.detail.id),s=P.detail.id}),document.addEventListener("oo:textsaved",()=>{console.log("[OpenOverlay] Text saved, resetting"),s=null,i&&(i.value=""),hs=""}),n.querySelectorAll(".quick-color").forEach(P=>{P.addEventListener("click",()=>{const B=P.dataset.color||"#ff3366",K=n.querySelector("#oo-color");K&&(K.value=B),n.querySelectorAll(".quick-color").forEach(re=>re.classList.remove("active")),P.classList.add("active"),mt(),Ut==="game"&&document.dispatchEvent(new CustomEvent("oo:playercolor",{detail:{color:B}}))})}),(ii=n.querySelector("#oo-color"))==null||ii.addEventListener("input",()=>{const P=n.querySelector("#oo-color");n.querySelectorAll(".quick-color").forEach(B=>B.classList.remove("active")),mt(),Ut==="game"&&P&&document.dispatchEvent(new CustomEvent("oo:playercolor",{detail:{color:P.value}}))});const c=n.querySelector("#oo-size"),d=n.querySelector("#oo-size-display");c==null||c.addEventListener("input",()=>{d&&(d.textContent=c.value),mt()});const u=n.querySelector("#oo-opacity"),f=n.querySelector("#oo-opacity-display");u==null||u.addEventListener("input",()=>{f&&(f.textContent=u.value+"%"),mt()});const g=n.querySelector("#oo-eraser");g==null||g.addEventListener("click",()=>{kr=!kr,g.classList.toggle("active",kr),mt()}),(Ge=n.querySelector("#oo-layer-bg"))==null||Ge.addEventListener("click",()=>{var P,B;Qe==="background"?Qe="normal":Qe="background",(P=n.querySelector("#oo-layer-bg"))==null||P.classList.toggle("active",Qe==="background"),(B=n.querySelector("#oo-layer-fg"))==null||B.classList.remove("active"),mt()}),(et=n.querySelector("#oo-layer-fg"))==null||et.addEventListener("click",()=>{var P,B;Qe==="foreground"?Qe="normal":Qe="foreground",(P=n.querySelector("#oo-layer-fg"))==null||P.classList.toggle("active",Qe==="foreground"),(B=n.querySelector("#oo-layer-bg"))==null||B.classList.remove("active"),mt()}),(Eo=n.querySelector("#oo-text-layer-bg"))==null||Eo.addEventListener("click",()=>{var P,B;Qe==="background"?Qe="normal":Qe="background",(P=n.querySelector("#oo-text-layer-bg"))==null||P.classList.toggle("active",Qe==="background"),(B=n.querySelector("#oo-text-layer-fg"))==null||B.classList.remove("active"),mt()}),(Ms=n.querySelector("#oo-text-layer-fg"))==null||Ms.addEventListener("click",()=>{var P,B;Qe==="foreground"?Qe="normal":Qe="foreground",(P=n.querySelector("#oo-text-layer-fg"))==null||P.classList.toggle("active",Qe==="foreground"),(B=n.querySelector("#oo-text-layer-bg"))==null||B.classList.remove("active"),mt()}),(si=n.querySelector("#oo-undo"))==null||si.addEventListener("click",()=>{document.dispatchEvent(new CustomEvent("oo:undo"))}),(Ns=n.querySelector("#oo-clear"))==null||Ns.addEventListener("click",()=>{document.dispatchEvent(new CustomEvent("oo:clear"))}),(zn=n.querySelector("#oo-cancel"))==null||zn.addEventListener("click",()=>{fs("none"),document.dispatchEvent(new CustomEvent("oo:cancel"))}),(ai=n.querySelector("#oo-save"))==null||ai.addEventListener("click",()=>{fs("none"),document.dispatchEvent(new CustomEvent("oo:save"))}),n.querySelectorAll(".game-mode-btn").forEach(P=>{const B=P.id;B==="oo-multiplayer-setup"||B==="oo-tag-game"||P.addEventListener("click",()=>{const K=P.dataset.mode,re=P.dataset.playmode;Ro=K,n.querySelectorAll(".game-mode-btn").forEach(Ae=>Ae.classList.remove("active")),P.classList.add("active");const Ye=n.querySelector(".build-tools-section");Ye&&(Ye.style.display="none"),document.dispatchEvent(new CustomEvent("oo:gamemode",{detail:{mode:K,tool:Kf,playmode:re||"explore"}}))})}),n.querySelectorAll(".game-tool-btn[data-tool]").forEach(P=>{P.addEventListener("click",()=>{const B=P.dataset.tool||"platform";Kf=B,n.querySelectorAll(".game-tool-btn[data-tool]").forEach(K=>K.classList.remove("active")),P.classList.add("active"),document.dispatchEvent(new CustomEvent("oo:gamemode",{detail:{mode:Ro,tool:B}}))})}),(li=n.querySelector("#oo-game-undo"))==null||li.addEventListener("click",()=>{document.dispatchEvent(new CustomEvent("oo:undo"))}),(ar=n.querySelector("#oo-game-clear"))==null||ar.addEventListener("click",()=>{document.dispatchEvent(new CustomEvent("oo:clear"))}),(Ls=n.querySelector("#oo-game-cancel"))==null||Ls.addEventListener("click",()=>{document.dispatchEvent(new CustomEvent("oo:save")),n.classList.remove("show"),Ut="none"}),(Ds=n.querySelector("#oo-game-save"))==null||Ds.addEventListener("click",()=>{document.dispatchEvent(new CustomEvent("oo:save")),document.dispatchEvent(new CustomEvent("oo:gamemode",{detail:{mode:"play",playmode:"explore"}})),n.classList.remove("show"),Ut="none"}),document.addEventListener("click",P=>{if(Vc){Vc=!1;return}if(Ut!=="game"||!n.classList.contains("show")||Ro==="build")return;const B=P.composedPath(),K=S==null?void 0:S.host;K&&B.includes(K)||(document.dispatchEvent(new CustomEvent("oo:save")),document.dispatchEvent(new CustomEvent("oo:gamemode",{detail:{mode:"play",playmode:"explore"}})),n.classList.remove("show"),Ut="none")}),document.addEventListener("click",P=>{var re;if(!rn)return;const B=P.composedPath(),K=S==null?void 0:S.host;K&&B.includes(K)||(rn=!1,(re=S==null?void 0:S.querySelector("#oo-profile-modal"))==null||re.classList.remove("show"))});const m=n.querySelector("#oo-multiplayer-setup");m==null||m.addEventListener("click",async()=>{if(!ce()){Uc("Multiplayer requires sign-in");return}const B=m;B.textContent="⏳",B.disabled=!0;try{const K=await chrome.runtime.sendMessage({type:"SETUP_MULTIPLAYER"});if(K!=null&&K.success){B.textContent="✓ Ready",n.querySelectorAll(".game-mode-btn").forEach(Ye=>Ye.classList.remove("active")),B.classList.add("active");const re=n.querySelector(".build-tools-section");re&&(re.style.display="none"),Ro="play",document.dispatchEvent(new CustomEvent("oo:gamemode",{detail:{mode:"play",playmode:"explore",skipTagGame:!0}})),setTimeout(()=>{B.textContent="👥 MP",B.disabled=!1},1500)}else B.textContent="❌ Error",setTimeout(()=>{B.textContent="👥 MP",B.disabled=!1,B.classList.remove("active")},2e3)}catch(K){console.error("[OpenOverlay] Multiplayer setup error:",K),B.textContent="👥 MP",B.disabled=!1}});const v=n.querySelector("#oo-tag-game");let O=!1;v==null||v.addEventListener("click",async()=>{if(!ce()){Uc("Tag game requires sign-in");return}if(O){document.dispatchEvent(new CustomEvent("oo:toggletag"));return}v.textContent="⏳",v.disabled=!0;try{const B=await chrome.runtime.sendMessage({type:"SETUP_MULTIPLAYER"});if(B!=null&&B.success){console.log("[OpenOverlay UI] Multiplayer setup complete, starting tag game"),n.querySelectorAll(".game-mode-btn").forEach(re=>re.classList.remove("active")),v.classList.add("active");const K=n.querySelector(".build-tools-section");K&&(K.style.display="none"),Ro="play",document.dispatchEvent(new CustomEvent("oo:toggletag"))}else console.error("[OpenOverlay UI] Multiplayer setup failed:",B==null?void 0:B.error),v.textContent="❌",setTimeout(()=>{v.textContent="🏷️ Tag",v.disabled=!1},1500)}catch(B){console.error("[OpenOverlay UI] Error setting up multiplayer:",B),v.textContent="❌",setTimeout(()=>{v.textContent="🏷️ Tag",v.disabled=!1},1500)}}),document.addEventListener("oo:tagstatechange",P=>{const{isTagMode:B,isIt:K}=P.detail;O=B,v.disabled=!1,B?K?(v.textContent="🏷️ IT!",v.classList.add("active")):(v.textContent="🏷️ Run!",v.classList.add("active")):(v.textContent="🏷️ Tag",v.classList.remove("active"))});const C=n.querySelector("#oo-drag-handle");let L=!1,H=0,z=0,N=0,$=0;C==null||C.addEventListener("pointerdown",P=>{const B=P;L=!0,H=B.clientX,z=B.clientY;const K=n.getBoundingClientRect();N=K.left,$=K.top,n.style.right="auto",n.style.bottom="auto",n.style.left=`${K.left}px`,n.style.top=`${K.top}px`,C.style.cursor="grabbing",B.preventDefault()}),document.addEventListener("pointermove",P=>{if(!L)return;const B=P.clientX-H,K=P.clientY-z;n.style.left=`${N+B}px`,n.style.top=`${$+K}px`}),document.addEventListener("pointerup",()=>{L&&(L=!1,C&&(C.style.cursor="grab"))});const j=S.querySelector("#google-login-btn"),D=S.querySelector("#signout-btn"),E=S.querySelector("#profile-close-btn");E==null||E.addEventListener("click",()=>{rn=!1;const P=S==null?void 0:S.querySelector("#oo-profile-modal");P==null||P.classList.remove("show")}),j==null||j.addEventListener("click",async()=>{try{await jI()}catch(P){console.error("[OpenOverlay] Login failed:",P)}}),D==null||D.addEventListener("click",async()=>{try{await WI(),rn=!1;const P=S==null?void 0:S.querySelector("#oo-profile-modal");P==null||P.classList.remove("show")}catch(P){console.error("[OpenOverlay] Sign out failed:",P)}});const w=document.getElementById("oo-help-modal"),b=document.getElementById("oo-help-close"),I=document.getElementById("oo-help-content"),_=S.querySelector("#help-btn-login"),x=S.querySelector("#help-btn-profile"),T=()=>{w&&(w.style.display="flex")},Z=()=>{w&&(w.style.display="none")};_==null||_.addEventListener("click",P=>{P.stopPropagation(),T()}),x==null||x.addEventListener("click",P=>{P.stopPropagation(),T()}),b==null||b.addEventListener("click",P=>{P.stopPropagation(),Z()}),w==null||w.addEventListener("click",P=>{P.target===w&&Z()}),I==null||I.addEventListener("wheel",P=>{const B=P.currentTarget,K=B.scrollTop<=0,re=B.scrollTop+B.clientHeight>=B.scrollHeight-1,Ye=P.deltaY<0,Ae=P.deltaY>0;(K&&Ye||re&&Ae)&&P.preventDefault(),P.stopPropagation()},{passive:!1}),w==null||w.addEventListener("wheel",P=>{P.target===w&&P.preventDefault(),P.stopPropagation()},{passive:!1});const ue=S.querySelector("#oo-screen-name");if(ue){const P=localStorage.getItem("oo_screen_name");P&&(ue.value=P),ue.addEventListener("change",()=>{const B=ue.value.trim();localStorage.setItem("oo_screen_name",B),document.dispatchEvent(new CustomEvent("oo:screenname",{detail:{name:B}}))}),ue.addEventListener("keydown",B=>{B.stopPropagation(),B.key==="Enter"&&ue.blur()})}const me=S.querySelector("#profile-bio-content"),Re=S.querySelector("#profile-bio-edit"),Se=S.querySelector("#profile-bio-input"),_e=S.querySelector("#profile-bio-save"),Ee=S.querySelector("#profile-bio-cancel");me==null||me.addEventListener("click",()=>{const P=me.dataset.bio||"";Se.value=P,me.style.display="none",Re.style.display="block",Se.focus()}),Se==null||Se.addEventListener("keydown",P=>{P.stopPropagation()}),_e==null||_e.addEventListener("click",async()=>{const P=Se.value.trim();_e.disabled=!0,_e.textContent="Saving...";try{await bI(P),me.innerHTML=P?sn(P):'<span class="profile-bio-empty">Click to add a bio...</span>',me.dataset.bio=P,Re.style.display="none",me.style.display="block"}catch(B){console.error("[OpenOverlay] Failed to save bio:",B)}finally{_e.disabled=!1,_e.textContent="Save"}}),Ee==null||Ee.addEventListener("click",()=>{Re.style.display="none",me.style.display="block"});const ae=S.querySelector("#feedback-text");ae==null||ae.addEventListener("keydown",P=>{P.stopPropagation()});const Te=S.querySelector("#feedback-submit");Te==null||Te.addEventListener("click",async()=>{var ci;const P=S==null?void 0:S.querySelector("#feedback-type"),B=S==null?void 0:S.querySelector("#feedback-text"),K=S==null?void 0:S.querySelector("#feedback-form"),re=S==null?void 0:S.querySelector("#feedback-success"),Ye=P==null?void 0:P.value,Ae=(ci=B==null?void 0:B.value)==null?void 0:ci.trim();if(!Ae){B==null||B.focus();return}const Ke=Te;Ke.disabled=!0,Ke.textContent="Sending...",await qI(Ye,Ae)?(K.style.display="none",re.style.display="block",setTimeout(()=>{B.value="",P.selectedIndex=0,K.style.display="block",re.style.display="none",Ke.disabled=!1,Ke.textContent="Send Feedback"},3e3)):(Ke.disabled=!1,Ke.textContent="Send Feedback",alert("Failed to send feedback. Please try again."))}),Tx(S),document.addEventListener("oo:contributors",P=>{Ix(S,P.detail.contributors)});const le=S.querySelector("#profile-char-boy"),we=S.querySelector("#profile-char-girl"),It=S.querySelector("#profile-hat-select"),Nt=S.querySelector("#toggle-respawn");le==null||le.addEventListener("click",()=>{le.classList.add("active"),we==null||we.classList.remove("active"),document.dispatchEvent(new CustomEvent("oo:playerstyle",{detail:{isGirl:!1}})),localStorage.setItem("oo_player_girl","false")}),we==null||we.addEventListener("click",()=>{we.classList.add("active"),le==null||le.classList.remove("active"),document.dispatchEvent(new CustomEvent("oo:playerstyle",{detail:{isGirl:!0}})),localStorage.setItem("oo_player_girl","true")}),localStorage.getItem("oo_player_girl")==="true"&&(le==null||le.classList.remove("active"),we==null||we.classList.add("active")),It==null||It.addEventListener("change",()=>{const P=It.value;document.dispatchEvent(new CustomEvent("oo:playerhat",{detail:{hat:P}})),localStorage.setItem("oo_player_hat",P)});const rr=localStorage.getItem("oo_player_hat");rr&&It&&(It.value=rr);const Yt=S.querySelector("#profile-accessory-select");Yt==null||Yt.addEventListener("change",()=>{const P=Yt.value;document.dispatchEvent(new CustomEvent("oo:playeraccessory",{detail:{accessory:P}})),localStorage.setItem("oo_player_accessory",P)});const oi=localStorage.getItem("oo_player_accessory");oi&&Yt&&(Yt.value=oi),localStorage.getItem("oo_explore_respawn")!=="false"||Nt==null||Nt.classList.remove("active"),Nt==null||Nt.addEventListener("click",()=>{Nt.classList.toggle("active");const P=Nt.classList.contains("active");localStorage.setItem("oo_explore_respawn",P?"true":"false"),document.dispatchEvent(new CustomEvent("oo:respawnsetting",{detail:{respawn:P}}))});const yn=S.querySelector("#profile-color-swatches"),ir=S.querySelector("#body-part-toggles");let Kt="body";const ri=P=>{if(P==="face")return localStorage.getItem("oo_color_face")||"#ff69b4";const B=localStorage.getItem(`oo_color_${P}`);return B||localStorage.getItem("oo_player_color")||"#ffffff"},Sl=P=>{const B=ri(P);yn==null||yn.querySelectorAll(".profile-color-swatch").forEach(K=>{K.classList.toggle("active",K.dataset.color===B)})};if(yn){const P=["#ff3366","#22c55e","#3b82f6","#f59e0b","#8b5cf6","#ff69b4","#fff","#000"],B=ri(Kt);yn.innerHTML=P.map(K=>`
      <div class="profile-color-swatch ${K===B?"active":""}" data-color="${K}" style="background: ${K}" title="${K}"></div>
    `).join(""),yn.querySelectorAll(".profile-color-swatch").forEach(K=>{K.addEventListener("click",()=>{const re=K.dataset.color||"#ff3366";yn.querySelectorAll(".profile-color-swatch").forEach(Ye=>Ye.classList.remove("active")),K.classList.add("active"),localStorage.setItem(`oo_color_${Kt}`,re),document.dispatchEvent(new CustomEvent("oo:partcolor",{detail:{part:Kt,color:re}})),Kt==="body"&&(localStorage.setItem("oo_player_color",re),document.dispatchEvent(new CustomEvent("oo:playercolor",{detail:{color:re}})))})})}ir&&ir.querySelectorAll(".part-toggle").forEach(P=>{P.addEventListener("click",()=>{ir.querySelectorAll(".part-toggle").forEach(B=>B.classList.remove("active")),P.classList.add("active"),Kt=P.dataset.part||"body",Sl(Kt)})});const sr=S.querySelector("#race-course-settings"),xt=S.querySelector("#race-course-select");document.addEventListener("oo:coursesupdate",P=>{var Ye;const{myCourse:B,otherCourses:K}=P.detail,re=[{id:"mine",name:"My Course",hasElements:((Ye=B==null?void 0:B.checkpoints)==null?void 0:Ye.length)>0},...K.map(Ae=>{var Ke;return{id:Ae.userId,name:Ae.displayName||"Unknown",hasElements:((Ke=Ae.checkpoints)==null?void 0:Ke.length)>0}})].filter(Ae=>Ae.hasElements);if(sr&&(sr.style.display=re.length>0?"block":"none"),xt&&re.length>0){const Ae=xt.value;xt.innerHTML=re.map(Ke=>`<option value="${Ke.id}">${Ke.name}</option>`).join(""),re.some(Ke=>Ke.id===Ae)?xt.value=Ae:(xt.value=re[0].id,document.dispatchEvent(new CustomEvent("oo:selectcourse",{detail:{courseId:re[0].id}})))}}),xt==null||xt.addEventListener("change",()=>{document.dispatchEvent(new CustomEvent("oo:selectcourse",{detail:{courseId:xt.value}}))}),Jm(P=>{Fc=P,xx(P)})}let ze={showAll:!0,showMine:!0,showFollowing:!1,hiddenUsers:new Set};function Tx(n){Ex();const e=n.querySelector("#toggle-all-drawings"),t=n.querySelector("#toggle-my-drawings"),o=n.querySelector("#toggle-following-only");e==null||e.classList.toggle("active",ze.showAll),t==null||t.classList.toggle("active",ze.showMine),o==null||o.classList.toggle("active",ze.showFollowing),e==null||e.addEventListener("click",()=>{ze.showAll=!ze.showAll,e.classList.toggle("active",ze.showAll),document.dispatchEvent(new CustomEvent("oo:visibility:all",{detail:{show:ze.showAll}}))}),t==null||t.addEventListener("click",()=>{ze.showMine=!ze.showMine,t.classList.toggle("active",ze.showMine),document.dispatchEvent(new CustomEvent("oo:visibility:mine",{detail:{show:ze.showMine}}))}),o==null||o.addEventListener("click",()=>{ze.showFollowing=!ze.showFollowing,o.classList.toggle("active",ze.showFollowing),document.dispatchEvent(new CustomEvent("oo:visibility:following",{detail:{show:ze.showFollowing}}))})}function Ex(){try{const n=localStorage.getItem("oo_visibility_prefs");if(n){const e=JSON.parse(n);ze={showAll:e.showAll??!0,showMine:e.showMine??!0,showFollowing:e.showFollowing??!1,hiddenUsers:new Set(e.hiddenUsers??[])}}}catch{}}async function Ix(n,e){const t=n.querySelector("#contributors-list");if(!t)return;const o=ce(),r=e.filter(s=>s.userId!==(o==null?void 0:o.uid));if(r.length===0){t.innerHTML='<div class="no-contributors">No other contributors yet</div>';return}const i=new Map;o&&await Promise.all(r.map(async s=>{const c=await TI(o.uid,s.userId);i.set(s.userId,c)})),t.innerHTML=r.map(s=>{var g;const c=!ze.hiddenUsers.has(s.userId),d=s.photoURL||"",u=((g=s.displayName)==null?void 0:g.charAt(0).toUpperCase())||"?",f=i.get(s.userId)||!1;return`
      <div class="contributor-row" data-user-id="${s.userId}">
        <div class="contributor-info">
          ${d?`<img src="${d}" class="contributor-avatar" alt="${s.displayName}">`:`<div class="contributor-avatar" style="display:flex;align-items:center;justify-content:center;color:#888;font-size:12px;">${u}</div>`}
          <span class="contributor-name">${sn(s.displayName)}</span>
        </div>
        <div class="contributor-actions">
          ${o?`
            <button class="follow-btn ${f?"following":"follow"}"
                    data-follow-user="${s.userId}"
                    data-user-name="${sn(s.displayName)}"
                    data-user-photo="${d}">
              ${f?"Following":"Follow"}
            </button>
          `:""}
          <div class="toggle-switch small ${c?"active":""}" data-toggle-user="${s.userId}" title="Show/hide this user's drawings"></div>
        </div>
      </div>
    `}).join(""),t.querySelectorAll("[data-toggle-user]").forEach(s=>{s.addEventListener("click",()=>{const c=s.getAttribute("data-toggle-user");if(!c)return;const d=s.classList.toggle("active");d?ze.hiddenUsers.delete(c):ze.hiddenUsers.add(c),document.dispatchEvent(new CustomEvent("oo:visibility:user",{detail:{userId:c,show:d}}))})}),t.querySelectorAll("[data-follow-user]").forEach(s=>{s.addEventListener("click",async()=>{const c=s.getAttribute("data-follow-user");if(s.getAttribute("data-user-name"),s.getAttribute("data-user-photo"),!c||!o)return;const d=s,u=d.classList.contains("following");d.disabled=!0;try{u?(await _I(c),d.classList.remove("following"),d.classList.add("follow"),d.textContent="Follow",document.dispatchEvent(new CustomEvent("oo:following:changed",{detail:{userId:c,action:"unfollow"}}))):(await wI(c),d.classList.remove("follow"),d.classList.add("following"),d.textContent="Following",document.dispatchEvent(new CustomEvent("oo:following:changed",{detail:{userId:c,action:"follow"}})))}catch(f){console.error("[OpenOverlay] Follow action failed:",f),u?(d.classList.add("following"),d.classList.remove("follow"),d.textContent="Following"):(d.classList.add("follow"),d.classList.remove("following"),d.textContent="Follow")}finally{d.disabled=!1}})})}function xx(n){var r;const e=S==null?void 0:S.querySelector("#oo-profile-btn"),t=S==null?void 0:S.querySelector("#login-prompt"),o=S==null?void 0:S.querySelector("#profile-content");if(!(!e||!t||!o))if(n){n.photoURL?e.innerHTML=`<img src="${n.photoURL}" alt="Profile">`:e.textContent=((r=n.displayName)==null?void 0:r.charAt(0).toUpperCase())||"👤",t.style.display="none",o.style.display="block";const i=S==null?void 0:S.querySelector("#profile-avatar"),s=S==null?void 0:S.querySelector("#profile-name"),c=S==null?void 0:S.querySelector("#profile-email");i&&(i.src=n.photoURL||""),s&&(s.textContent=n.displayName||"Anonymous"),c&&(c.textContent=n.email||""),Tl(n.uid).then(d=>{if(d){const u=S==null?void 0:S.querySelector("#followers-count"),f=S==null?void 0:S.querySelector("#following-count");S==null||S.querySelector("#profile-bio"),u&&(u.textContent=String(d.followersCount||0)),f&&(f.textContent=String(d.followingCount||0));const g=S==null?void 0:S.querySelector("#profile-bio-content");g&&(g.innerHTML=d.bio?sn(d.bio):'<span class="profile-bio-empty">Click to add a bio...</span>',g.dataset.bio=d.bio||"")}}),Ax(n.uid),kx()}else Cr&&(Cr(),Cr=null),co=0,qi=!1,e.textContent="👤",t.style.display="block",o.style.display="none"}function Sx(){rn=!rn;const n=S==null?void 0:S.querySelector("#oo-profile-modal");n==null||n.classList.toggle("show",rn),rn&&(Px(),co>0&&(co=0,gd()))}function Ax(n){Cr&&Cr();const e=xI(n,t=>{console.log("[OpenOverlay] New follower:",t.displayName),co++,gd();const o=S==null?void 0:S.querySelector("#followers-count");if(o){const r=parseInt(o.textContent||"0");o.textContent=String(r+1)}});e&&(Cr=e)}function gd(){const n=S==null?void 0:S.querySelector("#followers-stat");if(!n)return;const e=n.querySelector(".notification-badge");if(e&&e.remove(),co>0){const t=document.createElement("div");t.className="notification-badge",t.textContent=co>9?"9+":String(co),n.appendChild(t)}}function kx(){var o;const n=S==null?void 0:S.querySelector("#followers-stat"),e=S==null?void 0:S.querySelector("#followers-panel");if(!n||!e)return;const t=n.cloneNode(!0);(o=n.parentNode)==null||o.replaceChild(t,n),t.addEventListener("click",async()=>{qi=!qi,e.classList.toggle("show",qi),qi&&(co=0,gd(),await Cx())})}async function Cx(){const n=S==null?void 0:S.querySelector("#followers-list");if(!(!n||!Fc)){n.innerHTML='<div class="no-followers">Loading...</div>';try{const e=await EI(Fc.uid,20);if(e.length===0){n.innerHTML='<div class="no-followers">No followers yet. Share your drawings to get followers!</div>';return}n.innerHTML=e.map(t=>`
      <div class="follower-item">
        <img class="follower-avatar" src="${t.photoURL||""}" alt="${sn(t.displayName)}" onerror="this.style.display='none'">
        <div class="follower-info">
          <div class="follower-name">${sn(t.displayName)}</div>
        </div>
      </div>
    `).join("")}catch(e){console.error("[OpenOverlay] Failed to load followers:",e),n.innerHTML='<div class="no-followers">Failed to load followers</div>'}}}function Px(){const n=S==null?void 0:S.querySelector("#bookmarks-list"),e=S==null?void 0:S.querySelector("#bookmarks-count");if(!n)return;const t=Il();if(e&&(e.textContent=String(t.length)),t.length===0){n.innerHTML='<div class="no-bookmarks">No bookmarks yet</div>';return}n.innerHTML=t.slice(0,10).map(o=>`
    <div class="bookmark-item" data-url="${sn(o.pageUrl)}">
      <div class="bookmark-quote">"${sn(Qf(o.comment,50))}"</div>
      <div class="bookmark-meta">${sn(Qf(o.pageTitle,30))} • ${sn(o.authorName)}</div>
    </div>
  `).join(""),n.querySelectorAll(".bookmark-item").forEach(o=>{o.addEventListener("click",()=>{const r=o.dataset.url;r&&window.open(r,"_blank")})})}function sn(n){const e=document.createElement("div");return e.textContent=n,e.innerHTML}function Qf(n,e){return n.length<=e?n:n.slice(0,e)+"..."}function mt(){document.dispatchEvent(new CustomEvent("oo:settings",{detail:{color:Jo(),size:Zo(),opacity:er(),brush:md(),textStyle:yd(),eraser:kr,layer:Qe}}))}function py(){const n=Po;Po=!Po;const e=S==null?void 0:S.querySelector(".fab"),t=S==null?void 0:S.querySelectorAll(".mini");e==null||e.classList.toggle("open",Po),t==null||t.forEach(o=>o.classList.toggle("show",Po)),n&&!Po&&window.dispatchEvent(new CustomEvent("oo:menuClosed"))}function nc(n){fs(Ut===n?"none":n)}function fs(n){var d,u,f,g,m;Ut=n;const e=S==null?void 0:S.querySelectorAll(".mini");e==null||e.forEach((v,O)=>{O===0&&v.classList.toggle("active",n==="draw"),O===1&&v.classList.toggle("active",n==="text"),O===2&&v.classList.toggle("active",n==="game")});const t=S==null?void 0:S.querySelector(".toolbar");t==null||t.classList.toggle("show",n!=="none"),t==null||t.classList.toggle("game-mode",n==="game");const o=S==null?void 0:S.querySelector("#draw-controls"),r=S==null?void 0:S.querySelector("#text-controls"),i=S==null?void 0:S.querySelector("#game-controls");o==null||o.classList.toggle("active",n==="draw"),r==null||r.classList.toggle("active",n==="text"),i==null||i.classList.toggle("active",n==="game");const s=S==null?void 0:S.querySelector("#oo-size"),c=S==null?void 0:S.querySelector("#oo-size-display");if(s&&c&&(n==="text"?(s.value="32",s.max="200",c.textContent="32"):n==="draw"&&(s.value="4",s.max="150",c.textContent="4")),n!=="none"&&(kr=!1,(d=S==null?void 0:S.querySelector("#oo-eraser"))==null||d.classList.remove("active"),Qe="normal",(u=S==null?void 0:S.querySelector("#oo-layer-bg"))==null||u.classList.remove("active"),(f=S==null?void 0:S.querySelector("#oo-layer-fg"))==null||f.classList.remove("active"),(g=S==null?void 0:S.querySelector("#oo-text-layer-bg"))==null||g.classList.remove("active"),(m=S==null?void 0:S.querySelector("#oo-text-layer-fg"))==null||m.classList.remove("active")),n!=="text"){hs="";const v=S==null?void 0:S.querySelector("#oo-text-input");v&&(v.value="")}if(document.dispatchEvent(new CustomEvent("oo:mode",{detail:{mode:n}})),n==="game"){Vc=!0,Ro="build";const v=S==null?void 0:S.querySelectorAll(".game-mode-btn");v==null||v.forEach(C=>C.classList.remove("active"));const O=S==null?void 0:S.querySelector(".build-tools-section");O&&(O.style.display="flex"),document.dispatchEvent(new CustomEvent("oo:gamemode",{detail:{mode:"build"}}))}console.log("[OpenOverlay] Mode:",n)}function Jo(){const n=S==null?void 0:S.querySelector("#oo-color");return(n==null?void 0:n.value)||"#ff3366"}function Zo(){const n=S==null?void 0:S.querySelector("#oo-size");return parseInt((n==null?void 0:n.value)||"4",10)}function er(){const n=S==null?void 0:S.querySelector("#oo-opacity");return parseInt((n==null?void 0:n.value)||"100",10)/100}function md(){return dy}function Ga(){return kr}function Ya(){return Qe}function yd(){return hy}function Rx(){return fy}function gy(){return Ui}function Ox(){return hs}function Jf(){hs="";const n=S==null?void 0:S.querySelector("#oo-text-input");n&&(n.value="")}function Os(){return S}function Mx(){Po||py()}function Zf(n){fs(n)}function Nx(){if(!S)return null;const n=S.querySelector(".quick-explore");if(!n)return null;const e=n.getBoundingClientRect();return{x:e.left+e.width/2,y:e.top+e.height/2}}function Lx(){if(!S)return null;const n=S.querySelector("#oo-profile-btn");if(!n)return null;const e=n.getBoundingClientRect();return{x:e.left+e.width/2,y:e.top+e.height/2}}function qc(n){if(!S)return;const e=S.querySelector("#oo-profile-btn");e&&(n?(e.style.background="#22c55e",e.style.boxShadow="0 0 20px #22c55e, 0 0 40px #22c55e",e.style.transform="scale(1.1)"):(e.style.background="",e.style.boxShadow="",e.style.transform=""))}let ge=null,q=null,Je=null,bt=null,Pt=null,Vo=null,$r=!1,dt="none",Ka="none",ie=[],gr=[],Be={showAll:!0,showMine:!0,showFollowing:!1,hiddenUsers:new Set},Dt=null,na=[],Pr=[],vn=null,Rr="none",kn=null,Cn=null,my=!1,oc=0,$e=null,zc={x:0,y:0},nn="none",Ta={x:0,y:0,size:0};const oa=10,yy=30;function vd(n){if(n===document.body||n===document.documentElement)return"body";if(n.id)return`#${CSS.escape(n.id)}`;const e=[];let t=n;for(;t&&t!==document.body&&t!==document.documentElement;){let o=t.tagName.toLowerCase();if(t.className&&typeof t.className=="string"){const i=t.className.trim().split(/\s+/).slice(0,2);i.length>0&&i[0]&&(o+="."+i.map(s=>CSS.escape(s)).join("."))}const r=t.parentElement;if(r){const i=Array.from(r.children).filter(s=>s.tagName===t.tagName);if(i.length>1){const s=i.indexOf(t)+1;o+=`:nth-of-type(${s})`}}if(e.unshift(o),e.length>=4)break;t=t.parentElement}return e.join(" > ")||"body"}function bd(n,e){ge&&(ge.style.pointerEvents="none");const t=document.elementsFromPoint(n,e);ge&&(ge.style.pointerEvents=dt==="draw"||dt==="text"?"auto":"none");for(const o of t){if(o.id==="oo-canvas"||o.id==="openoverlay-ui"||o===document.body||o===document.documentElement)continue;const r=o.getBoundingClientRect();if(!(r.width<20||r.height<20))return o}return document.body}function Dx(){console.log("[OpenOverlay] initCanvas starting..."),ge=document.createElement("canvas"),ge.id="oo-canvas",ge.style.cssText=`
    position: absolute;
    top: 0;
    left: 0;
    z-index: 2147483640;
    pointer-events: none;
  `,document.body.appendChild(ge),q=ge.getContext("2d"),Je=document.createElement("canvas"),bt=Je.getContext("2d"),Pt=document.createElement("canvas"),Pt.id="oo-background-canvas",Pt.style.cssText=`
    position: absolute;
    top: 0;
    left: 0;
    z-index: 2147483635;
    pointer-events: none;
  `,document.body.appendChild(Pt),Vo=Pt.getContext("2d"),Ai(),window.addEventListener("resize",Ai);const n=/yahoo|facebook|twitter|instagram|tiktok|reddit/i.test(window.location.hostname),e=n?500:150;let t=null;window.addEventListener("scroll",()=>{t&&clearTimeout(t),t=window.setTimeout(()=>{$r||ye()},e)},{passive:!0});let o=null;new ResizeObserver(()=>{n?(o&&clearTimeout(o),o=window.setTimeout(Ai,500)):Ai()}).observe(document.documentElement);const i=n?2e3:500;let s=null,c=!1;new MutationObserver(()=>{c||(c=!0,s&&clearTimeout(s),s=window.setTimeout(()=>{c=!1,$r||(Ai(),ye())},i))}).observe(document.body,{childList:!0,subtree:!1}),n&&console.log("[OpenOverlay] Heavy site detected, using longer debounce"),document.addEventListener("oo:mode",u=>{dt=u.detail.mode,ge&&(ge.style.pointerEvents=dt==="draw"||dt==="text"?"auto":"none",ge.style.cursor=dt==="draw"?"crosshair":dt==="text"?"text":"default")}),document.addEventListener("oo:save",eS),document.addEventListener("oo:cancel",tS),document.addEventListener("oo:undo",Jx),document.addEventListener("oo:clear",Zx),document.addEventListener("oo:visibility:all",u=>{Be.showAll=u.detail.show,ki(),ye(),console.log("[OpenOverlay] Visibility - show all:",u.detail.show)}),document.addEventListener("oo:visibility:mine",u=>{Be.showMine=u.detail.show,ki(),ye(),console.log("[OpenOverlay] Visibility - show mine:",u.detail.show)}),document.addEventListener("oo:visibility:following",u=>{Be.showFollowing=u.detail.show,ki(),ye(),console.log("[OpenOverlay] Visibility - following only:",u.detail.show)}),document.addEventListener("oo:visibility:user",u=>{const{userId:f,show:g}=u.detail;g?Be.hiddenUsers.delete(f):Be.hiddenUsers.add(f),ki(),ye(),console.log("[OpenOverlay] Visibility - user",f,":",g?"shown":"hidden")}),document.addEventListener("oo:toggleothers",u=>{Be.showAll=u.detail.show,ki(),ye()}),document.addEventListener("oo:following:changed",u=>{const{userId:f,action:g}=u.detail;Dt||(Dt=new Set),g==="follow"?(Dt.add(f),console.log("[OpenOverlay] Added to following cache:",f)):(Dt.delete(f),console.log("[OpenOverlay] Removed from following cache:",f)),Be.showFollowing&&ye()}),Hx(),document.addEventListener("oo:gamemode",u=>{Ka=u.detail.mode||"none",(u.detail.mode==="play"||u.detail.mode==="build")&&ye()}),document.addEventListener("oo:settings",u=>{if($e&&dt==="text"){const f=ie.find(g=>g.type==="text"&&g.id===$e);f&&(f.size=u.detail.size,f.color=u.detail.color,f.opacity=u.detail.opacity,f.style=u.detail.textStyle,ye())}}),document.addEventListener("oo:textcreate",u=>{if(console.log("[OpenOverlay] oo:textcreate received, currentMode:",dt),dt!=="text")return;const f=window.innerWidth/2,g=window.innerHeight/2,m=bd(f,g);if(!m){console.log("[OpenOverlay] No anchor found at center");return}const v=m.getBoundingClientRect(),O=window.scrollX,C=window.scrollY,L=v.left+O,H=v.top+C,z=(f+O-L)/v.width,N=(g+C-H)/v.height,$=_y(),j={type:"text",id:$,anchorSelector:vd(m),x:z,y:N,anchorBounds:{x:L,y:H,width:v.width,height:v.height},text:u.detail.text,color:Jo(),size:Zo(),opacity:er(),style:yd(),rotation:0,layer:Ya()};ie.push(j),$e=j.id,console.log("[OpenOverlay] Text created:",$),document.dispatchEvent(new CustomEvent("oo:textcreated",{detail:{id:$}})),ye()}),document.addEventListener("oo:textupdate",u=>{if(!$e)return;const f=ie.find(g=>g.type==="text"&&g.id===$e);f&&(f.text=u.detail.text,ye())}),document.addEventListener("oo:textdelete",u=>{const f=u.detail.id,g=ie.findIndex(m=>m.id===f);g!==-1&&(ie.splice(g,1),$e===f&&($e=null),ye())}),ge.addEventListener("pointerdown",Vx),ge.addEventListener("pointermove",qx),ge.addEventListener("pointerup",np),ge.addEventListener("pointerleave",np),wd(),nS(),console.log("[OpenOverlay] Canvas initialized")}let ep=0,tp=0;function Ai(){if(!ge||!q)return;const n=Math.max(document.body.scrollWidth||0,document.body.offsetWidth||0,document.documentElement.scrollWidth||0,document.documentElement.offsetWidth||0,window.innerWidth||0),e=Math.max(document.body.scrollHeight||0,document.body.offsetHeight||0,document.documentElement.scrollHeight||0,document.documentElement.offsetHeight||0,window.innerHeight||0);if(n===ep&&e===tp)return;ep=n,tp=e;const t=window.devicePixelRatio||1;ge.style.width=`${n}px`,ge.style.height=`${e}px`,ge.width=n*t,ge.height=e*t,q.scale(t,t),Je&&bt&&(Je.width=n*t,Je.height=e*t,bt.setTransform(1,0,0,1,0,0),bt.scale(t,t)),Pt&&Vo&&(Pt.style.width=`${n}px`,Pt.style.height=`${e}px`,Pt.width=n*t,Pt.height=e*t,Vo.scale(t,t)),ye()}function Vx(n){if(dt==="text"){Ux(n);return}if(dt!=="draw")return;$r=!0;const e=bd(n.clientX,n.clientY);if(e){const o=e.getBoundingClientRect();vn={element:e,selector:vd(e),bounds:o}}const t=Rx();t!=="none"?(Rr=t,kn={x:n.pageX,y:n.pageY},Cn={x:n.pageX,y:n.pageY},my=gy()):Pr=[{x:n.pageX,y:n.pageY}]}function Xa(n){if(!q)return null;const e=by(n);if(!e)return null;q.font=`bold ${n.size||32}px Impact, Arial, sans-serif`;const o=q.measureText(n.text).width,r=n.size;return{x:e.x,y:e.y,width:o,height:r,centerX:e.x+o/2,centerY:e.y+r/2}}function vy(n,e,t){const o=Xa(t);if(!o)return"none";const r=8,i=t.rotation||0,s=[{x:o.x+o.width+r,y:o.y+o.height+r,mode:"resize"}],c=o.centerX,d=o.y-r-yy,u=Math.cos(i),f=Math.sin(i),g=c-o.centerX,m=d-o.centerY,v=o.centerX+g*u-m*f,O=o.centerY+g*f+m*u;if(Math.abs(n-v)<oa&&Math.abs(e-O)<oa)return"rotate";const C=s[0].x-o.centerX,L=s[0].y-o.centerY,H=o.centerX+C*u-L*f,z=o.centerY+C*f+L*u;return Math.abs(n-H)<oa&&Math.abs(e-z)<oa?"resize":"none"}function Fx(n){if(!ge||dt!=="text")return;if($e){const t=ie.find(o=>o.type==="text"&&o.id===$e);if(t){const o=vy(n.pageX,n.pageY,t);if(o==="resize"){ge.style.cursor="nwse-resize";return}else if(o==="rotate"){ge.style.cursor="crosshair";return}}}wy(n.pageX,n.pageY)?ge.style.cursor="grab":ge.style.cursor="default"}function Ux(n){if($e){const o=ie.find(r=>r.type==="text"&&r.id===$e);if(o){const r=vy(n.pageX,n.pageY,o);if(r!=="none"){nn=r,Xa(o)&&(Ta={x:n.pageX,y:n.pageY,size:o.size,rotation:o.rotation||0});return}}}const e=wy(n.pageX,n.pageY);if(e){$e=e.id,nn="move";const o=by(e);o&&(zc={x:n.pageX-o.x,y:n.pageY-o.y}),ge&&(ge.style.cursor="grabbing"),ye();return}if($e){$e=null,nn="none",Jf(),document.dispatchEvent(new CustomEvent("oo:textsaved")),ye();return}const t=Ox();if(t&&t.trim()){const o=bd(n.clientX,n.clientY);if(!o)return;const r=o.getBoundingClientRect(),i=window.scrollX,s=window.scrollY,c=r.left+i,d=r.top+s,u=(n.pageX-c)/r.width,f=(n.pageY-d)/r.height,g={type:"text",id:_y(),anchorSelector:vd(o),x:u,y:f,anchorBounds:{x:c,y:d,width:r.width,height:r.height},text:t,color:Jo(),size:Zo(),opacity:er(),style:yd(),rotation:0,layer:Ya()};ie.push(g),$e=g.id,Jf(),document.dispatchEvent(new CustomEvent("oo:textsaved")),ye()}}function by(n){let e=null;try{e=document.querySelector(n.anchorSelector)}catch{}if(!e)return null;const t=e.getBoundingClientRect(),o=window.scrollX,r=window.scrollY;return{x:t.left+o+n.x*t.width,y:t.top+r+n.y*t.height}}function qx(n){if(dt==="text"&&nn==="none"&&Fx(n),$e&&dt==="text"&&nn!=="none"){const e=ie.find(t=>t.type==="text"&&t.id===$e);if(!e)return;if(nn==="move"){let t=null;try{t=document.querySelector(e.anchorSelector)}catch{}if(t){const o=t.getBoundingClientRect(),r=window.scrollX,i=window.scrollY,s=n.pageX-zc.x,c=n.pageY-zc.y;e.x=(s-o.left-r)/o.width,e.y=(c-o.top-i)/o.height,ye()}}else if(nn==="resize"){if(Xa(e)){const o=n.pageX-Ta.x,r=n.pageY-Ta.y,i=(o+r)/2,s=Math.max(12,Math.min(200,Ta.size+i));e.size=s,ye()}}else if(nn==="rotate"){const t=Xa(e);if(t){const o=Math.atan2(n.pageY-t.centerY,n.pageX-t.centerX);e.rotation=o+Math.PI/2,ye()}}return}if(!(!$r||!q)){if(Rr!=="none"&&kn){Cn={x:n.pageX,y:n.pageY},ye(),Bx();return}Pr.push({x:n.pageX,y:n.pageY}),ye(),zx(Pr,Jo(),Zo(),er(),md(),Ga())}}function np(){if(nn!=="none"){nn="none",ge&&(ge.style.cursor="grab");return}if($r){if($r=!1,Rr!=="none"&&kn&&Cn&&vn){const n=vn.element.getBoundingClientRect(),e=window.scrollX,t=window.scrollY,o=n.left+e,r=n.top+t,i=(kn.x-o)/n.width,s=(kn.y-r)/n.height,c=(Cn.x-o)/n.width,d=(Cn.y-r)/n.height;ie.push({type:"shape",id:"shape_"+Date.now(),anchorSelector:vn.selector,x1:i,y1:s,x2:c,y2:d,anchorBounds:{x:o,y:r,width:n.width,height:n.height},shape:Rr,color:Jo(),width:Zo(),opacity:er(),filled:my,eraser:Ga(),layer:Ya()}),kn=null,Cn=null,Rr="none",vn=null,ye();return}if(Pr.length>1&&vn){const n=vn.element.getBoundingClientRect(),e=window.scrollX,t=window.scrollY,o=n.left+e,r=n.top+t,i=Pr.map(s=>({x:(s.x-o)/n.width,y:(s.y-r)/n.height}));ie.push({type:"stroke",anchorSelector:vn.selector,points:i,anchorBounds:{x:o,y:r,width:n.width,height:n.height},color:Jo(),width:Zo(),opacity:er(),brush:md(),eraser:Ga(),layer:Ya()})}Pr=[],vn=null,ye()}}function wy(n,e){const t=window.scrollX,o=window.scrollY;for(let r=ie.length-1;r>=0;r--){const i=ie[r];if(i.type!=="text")continue;let s=null;try{s=document.querySelector(i.anchorSelector)}catch{}if(!s)continue;const c=s.getBoundingClientRect(),d={x:c.left+t,y:c.top+o,width:c.width,height:c.height},u=d.x+i.x*d.width,f=d.y+i.y*d.height,g=i.text.length*i.size*.6,m=i.size,v=10;if(n>=u-v&&n<=u+g+v&&e>=f-v&&e<=f+m+v)return i}return null}function _y(){return Math.random().toString(36).substr(2,9)}function zx(n,e,t,o,r,i){if(!(!q||n.length<2)){switch(q.save(),q.globalAlpha=o,i&&(q.globalCompositeOperation="destination-out",q.globalAlpha=1),r){case"spray":Iy(q,n,e,t);break;case"dots":xy(q,n,e,t);break;case"square":Sy(q,n,e,t);break;case"rainbow":$x(q,n,t);break;case"glow":Ay(q,n,e,t);break;default:Ey(q,n,e,t)}q.restore()}}function op(n,e){if(!q||n.points.length<2)return;const t=n.points.map(o=>({x:e.x+o.x*e.width,y:e.y+o.y*e.height}));switch(q.save(),q.globalAlpha=n.opacity,n.eraser&&(q.globalCompositeOperation="destination-out",q.globalAlpha=1),n.brush){case"spray":Iy(q,t,n.color,n.width);break;case"dots":xy(q,t,n.color,n.width);break;case"square":Sy(q,t,n.color,n.width);break;case"rainbow":jx(q,t,n.width);break;case"glow":Ay(q,t,n.color,n.width);break;default:Ey(q,t,n.color,n.width)}q.restore()}function Bx(){if(!q||!kn||!Cn)return;const n=Jo(),e=Zo(),t=er(),o=gy(),r=Ga();q.save(),q.globalAlpha=t,q.strokeStyle=n,q.fillStyle=n,q.lineWidth=e,q.lineCap="round",q.lineJoin="round",r&&(q.globalCompositeOperation="destination-out",q.globalAlpha=1);const i=kn.x,s=kn.y,c=Cn.x,d=Cn.y;Ty(q,Rr,i,s,c,d,o),q.restore()}function rp(n,e){if(!q)return;const t=e.x+n.x1*e.width,o=e.y+n.y1*e.height,r=e.x+n.x2*e.width,i=e.y+n.y2*e.height;q.save(),q.globalAlpha=n.opacity,q.strokeStyle=n.color,q.fillStyle=n.color,q.lineWidth=n.width,q.lineCap="round",q.lineJoin="round",n.eraser&&(q.globalCompositeOperation="destination-out",q.globalAlpha=1),Ty(q,n.shape,t,o,r,i,n.filled),q.restore()}function Ty(n,e,t,o,r,i,s){const c=Math.min(t,r),d=Math.min(o,i),u=Math.abs(r-t),f=Math.abs(i-o),g=(t+r)/2,m=(o+i)/2;switch(n.beginPath(),e){case"line":n.moveTo(t,o),n.lineTo(r,i),n.stroke();break;case"rectangle":s&&n.fillRect(c,d,u,f),n.strokeRect(c,d,u,f);break;case"circle":const v=Math.sqrt(u*u+f*f)/2;n.arc(g,m,v,0,Math.PI*2),s&&n.fill(),n.stroke();break;case"triangle":n.moveTo(g,d),n.lineTo(c,d+f),n.lineTo(c+u,d+f),n.closePath(),s&&n.fill(),n.stroke();break;case"star":const O=Math.min(u,f)/2,C=O*.4,L=5;for(let H=0;H<L*2;H++){const z=H%2===0?O:C,N=Math.PI/L*H-Math.PI/2,$=g+z*Math.cos(N),j=m+z*Math.sin(N);H===0?n.moveTo($,j):n.lineTo($,j)}n.closePath(),s&&n.fill(),n.stroke();break}}function Ey(n,e,t,o){n.beginPath(),n.strokeStyle=t,n.lineWidth=o,n.lineCap="round",n.lineJoin="round",n.moveTo(e[0].x,e[0].y);for(let r=1;r<e.length;r++)n.lineTo(e[r].x,e[r].y);n.stroke()}function Iy(n,e,t,o){n.fillStyle=t;const r=Math.max(10,o*2);for(const i of e)for(let s=0;s<r;s++){const c=Math.random()*Math.PI*2,d=Math.random()*o,u=i.x+Math.cos(c)*d,f=i.y+Math.sin(c)*d;n.beginPath(),n.arc(u,f,.5,0,Math.PI*2),n.fill()}}function xy(n,e,t,o){n.fillStyle=t;const r=Math.max(o*.8,4);let i=0;for(let s=0;s<e.length;s++){if(s===0){n.beginPath(),n.arc(e[0].x,e[0].y,o/2,0,Math.PI*2),n.fill();continue}const c=e[s].x-e[s-1].x,d=e[s].y-e[s-1].y,u=Math.sqrt(c*c+d*d);i+=u,i>=r&&(n.beginPath(),n.arc(e[s].x,e[s].y,o/2,0,Math.PI*2),n.fill(),i=0)}}function Sy(n,e,t,o){n.beginPath(),n.strokeStyle=t,n.lineWidth=o,n.lineCap="square",n.lineJoin="bevel",n.moveTo(e[0].x,e[0].y);for(let r=1;r<e.length;r++)n.lineTo(e[r].x,e[r].y);n.stroke()}function $x(n,e,t){n.lineWidth=t,n.lineCap="round",n.lineJoin="round";for(let o=1;o<e.length;o++){const r=`hsl(${oc}, 100%, 50%)`;n.beginPath(),n.strokeStyle=r,n.shadowColor=r,n.shadowBlur=t*.8,n.moveTo(e[o-1].x,e[o-1].y),n.lineTo(e[o].x,e[o].y),n.stroke(),oc=(oc+2)%360}n.shadowBlur=0}function jx(n,e,t){n.lineWidth=t,n.lineCap="round",n.lineJoin="round";let o=0;for(let r=1;r<e.length;r++){const i=`hsl(${o}, 100%, 50%)`;n.beginPath(),n.strokeStyle=i,n.shadowColor=i,n.shadowBlur=t*.8,n.moveTo(e[r-1].x,e[r-1].y),n.lineTo(e[r].x,e[r].y),n.stroke(),o=(o+2)%360}n.shadowBlur=0}function Ay(n,e,t,o){const r=o*3;let i=1/0,s=1/0,c=-1/0,d=-1/0;for(const C of e)i=Math.min(i,C.x),s=Math.min(s,C.y),c=Math.max(c,C.x),d=Math.max(d,C.y);const u=Math.ceil(c-i+r*2),f=Math.ceil(d-s+r*2),g=document.createElement("canvas");g.width=u,g.height=f;const m=g.getContext("2d");if(!m)return;const v=i-r,O=s-r;m.strokeStyle=t,m.lineWidth=o,m.lineCap="round",m.lineJoin="round",m.shadowColor=t,m.shadowBlur=o*2.5,m.beginPath(),m.moveTo(e[0].x-v,e[0].y-O);for(let C=1;C<e.length;C++)m.lineTo(e[C].x-v,e[C].y-O);m.stroke(),m.shadowBlur=o,m.stroke(),n.drawImage(g,v,O)}function Wx(){const{showAll:n,showMine:e,showFollowing:t,hiddenUsers:o}=Be;if(!n)return[];const r=[];e&&r.push(...ie.map(i=>({item:i,isOtherUser:!1})));for(const i of gr){const s=i._ownerId;s&&(o.has(s)||t&&!((Dt==null?void 0:Dt.has(s))??!1)||r.push({item:i,isOtherUser:!0}))}return r}function ki(){const n={showAll:Be.showAll,showMine:Be.showMine,showFollowing:Be.showFollowing,hiddenUsers:Array.from(Be.hiddenUsers)};localStorage.setItem("oo_visibility_prefs",JSON.stringify(n))}function Hx(){try{const n=localStorage.getItem("oo_visibility_prefs");if(n){const e=JSON.parse(n);Be={showAll:e.showAll!==!1,showMine:e.showMine!==!1,showFollowing:e.showFollowing===!0,hiddenUsers:new Set(Array.isArray(e.hiddenUsers)?e.hiddenUsers:[])},console.log("[OpenOverlay] Loaded visibility prefs:",{showAll:Be.showAll,showMine:Be.showMine,showFollowing:Be.showFollowing,hiddenUsers:Be.hiddenUsers.size}),(!Be.showAll||!Be.showMine)&&(console.warn("[OpenOverlay] Visibility prefs seem corrupted, resetting to defaults"),Be={showAll:!0,showMine:!0,showFollowing:!1,hiddenUsers:new Set},localStorage.removeItem("oo_visibility_prefs"))}}catch(n){console.warn("[OpenOverlay] Failed to load visibility prefs, using defaults:",n),localStorage.removeItem("oo_visibility_prefs")}}async function Gx(){const n=ce();if(!n){Dt=new Set;return}try{const e=await II(n.uid);Dt=new Set(e.map(t=>t.uid)),console.log("[OpenOverlay] Loaded following cache:",Dt.size,"users")}catch(e){console.warn("[OpenOverlay] Failed to load following cache:",e),Dt=new Set}}function ye(){if(!q||!ge)return;q.clearRect(0,0,ge.width,ge.height),Je&&bt&&bt.clearRect(0,0,Je.width,Je.height),Pt&&Vo&&Vo.clearRect(0,0,Pt.width,Pt.height);const n=window.scrollX,e=window.scrollY,t=(d,u,f=!1)=>{let g=null;try{g=document.querySelector(u.anchorSelector)}catch{}if(!g)return;const m=g.getBoundingClientRect();if(m.width===0||m.height===0)return;const v={x:m.left+n,y:m.top+e,width:m.width,height:m.height},O=q;q=d,u.type==="text"?(ip(u,v),!f&&u.id===$e&&(console.log("[OpenOverlay] Drawing selection for text:",u.id),Yx(u,v))):u.type==="shape"?rp(u,v):op(u,v),q=O},o=d=>{if(!bt)return;let u=null;try{u=document.querySelector(d.anchorSelector)}catch{return}if(!u)return;const f=u.getBoundingClientRect();if(f.width===0||f.height===0)return;const g={x:f.left+n,y:f.top+e,width:f.width,height:f.height},m=q;q=bt,d.type==="text"?ip(d,g):d.type==="shape"?rp(d,g):(d.type==="stroke"||!d.type)&&op(d,g),q=m},r=Wx(),i=r.filter(({item:d})=>d.layer==="background"),s=r.filter(({item:d})=>{const u=d.layer;return!u||u==="normal"}),c=r.filter(({item:d})=>d.layer==="foreground");if(Vo)for(const{item:d,isOtherUser:u}of i)t(Vo,d,u);for(const{item:d,isOtherUser:u}of s)t(q,d,u),o(d);for(const{item:d,isOtherUser:u}of c)t(q,d,u)}function Yx(n,e){if(!q)return;console.log("[OpenOverlay] Drawing text selection for:",n.id,"selectedTextId:",$e);const t=e.x+n.x*e.width,o=e.y+n.y*e.height;q.font=`bold ${n.size||32}px Impact, Arial, sans-serif`;const i=q.measureText(n.text).width,s=n.size,c=8,d=t+i/2,u=o+s/2,f=n.rotation||0;q.save(),q.translate(d,u),q.rotate(f),q.translate(-d,-u),q.strokeStyle="#22c55e",q.lineWidth=2,q.setLineDash([5,3]),q.strokeRect(t-c,o-c,i+c*2,s+c*2),q.setLineDash([]),q.fillStyle="#22c55e";const g=8;q.fillRect(t+i+c-g/2,o+s+c-g/2,g,g);const m=o-c-yy;q.beginPath(),q.arc(d,m,6,0,Math.PI*2),q.fill(),q.beginPath(),q.strokeStyle="#22c55e",q.setLineDash([]),q.lineWidth=2,q.moveTo(d,o-c),q.lineTo(d,m+6),q.stroke(),q.restore()}function ip(n,e){if(!q)return;const t=e.x+n.x*e.width,o=e.y+n.y*e.height;q.save(),q.globalAlpha=n.opacity||1,q.font=`bold ${n.size||32}px Impact, Arial, sans-serif`,q.textBaseline="top";const r=n.rotation||0;if(r!==0){const i=q.measureText(n.text),s=t+i.width/2,c=o+n.size/2;q.translate(s,c),q.rotate(r),q.translate(-s,-c)}switch(n.style){case"rainbow":Xx(q,n.text,t,o,n.size);break;case"aged":Qx(q,n.text,t,o,n.size,n.color);break;default:Kx(q,n.text,t,o,n.color)}q.restore()}function Kx(n,e,t,o,r){n.strokeStyle="#000",n.lineWidth=3,n.strokeText(e,t,o),n.fillStyle=r,n.fillText(e,t,o)}function Xx(n,e,t,o,r){const i=n.measureText(e).width,s=n.createLinearGradient(t,o,t+i,o);s.addColorStop(0,"hsl(0, 100%, 50%)"),s.addColorStop(.17,"hsl(60, 100%, 50%)"),s.addColorStop(.33,"hsl(120, 100%, 50%)"),s.addColorStop(.5,"hsl(180, 100%, 50%)"),s.addColorStop(.67,"hsl(240, 100%, 50%)"),s.addColorStop(.83,"hsl(300, 100%, 50%)"),s.addColorStop(1,"hsl(360, 100%, 50%)");let c=0;for(let d=0;d<e.length;d++){const u=e[d],f=n.measureText(u).width,m=(c+f/2)/i*360;n.shadowColor=`hsl(${m}, 100%, 50%)`,n.shadowBlur=r*.2,n.shadowOffsetX=0,n.shadowOffsetY=0,n.fillStyle=s,n.fillText(u,t+c,o),c+=f}n.shadowBlur=0,n.strokeStyle="#000",n.lineWidth=3,n.strokeText(e,t,o),n.fillStyle=s,n.fillText(e,t,o)}function Qx(n,e,t,o,r,i){n.shadowColor="rgba(0,0,0,0.5)",n.shadowBlur=4,n.shadowOffsetX=2,n.shadowOffsetY=2,n.strokeStyle="#222",n.lineWidth=4,n.strokeText(e,t,o),n.shadowBlur=0,n.shadowOffsetX=0,n.shadowOffsetY=0;const s=n.createLinearGradient(t,o,t,o+r);s.addColorStop(0,sp(i,20)),s.addColorStop(.5,i),s.addColorStop(1,sp(i,-30)),n.fillStyle=s,n.fillText(e,t,o),n.globalAlpha=.3,n.strokeStyle="#000",n.lineWidth=1;const c=n.measureText(e).width;for(let d=0;d<5;d++){const u=t+Math.random()*c,f=o+Math.random()*r;n.beginPath(),n.moveTo(u,f),n.lineTo(u+Math.random()*10-5,f+Math.random()*10),n.stroke()}}function sp(n,e){const t=n.replace("#",""),o=Math.max(0,Math.min(255,parseInt(t.substr(0,2),16)+e)),r=Math.max(0,Math.min(255,parseInt(t.substr(2,2),16)+e)),i=Math.max(0,Math.min(255,parseInt(t.substr(4,2),16)+e));return`rgb(${o},${r},${i})`}function Jx(){if(console.log("[OpenOverlay] Undo called - gameMode:",Ka,"items:",ie.length),Ka==="build"){console.log("[OpenOverlay] Undo skipped - build mode active (game handles checkpoints)");return}if(ie.length>0){const n=ie.pop();console.log("[OpenOverlay] Undo - removed item type:",n==null?void 0:n.type,"eraser:",n==null?void 0:n.eraser),ye(),console.log("[OpenOverlay] Undo - items remaining:",ie.length)}else console.log("[OpenOverlay] Undo - no items to undo")}async function Zx(){if(Ka==="build")return;dt==="text"?(ie=ie.filter(e=>e.type!=="text"),console.log("[OpenOverlay] Cleared text stamps (drawings preserved)")):(ie=ie.filter(e=>e.type==="text"),console.log("[OpenOverlay] Cleared drawings (text stamps preserved)"));const n=_d();ie.length>0?(localStorage.setItem(`oo_drawing_${n}`,JSON.stringify(ie)),ja()&&await Ym(n,window.location.href,ie)):(localStorage.removeItem(`oo_drawing_${n}`),ja()&&await AI(n)),ye()}async function eS(){console.log("[OpenOverlay] Saving",ie.length,"items"),$e=null,document.dispatchEvent(new CustomEvent("oo:textsaved"));const n=_d(),e=JSON.stringify(ie);localStorage.setItem(`oo_drawing_${n}`,e),ja()&&await Ym(n,window.location.href,ie),ye(),console.log("[OpenOverlay] Drawing saved")}function tS(){console.log("[OpenOverlay] Canceling drawing"),wd()}async function wd(){const n=_d();if(or()){if(kI(n,r=>{ie=r.myItems,gr=r.otherItems,na=r.contributors,localStorage.setItem(`oo_drawing_${n}`,JSON.stringify(ie)),console.log("[OpenOverlay] Real-time update:",ie.length,"mine,",gr.length,"from others"),r.contributors.length>0&&console.log("[OpenOverlay] Contributors:",r.contributors.map(i=>i.displayName).join(", ")),document.dispatchEvent(new CustomEvent("oo:contributors",{detail:{contributors:na}})),ye()})){console.log("[OpenOverlay] Subscribed to real-time drawing updates");return}console.log("[OpenOverlay] Real-time subscription failed, trying one-time fetch");const o=await SI(n);if(o!==null){ie=o.myItems,gr=o.otherItems,na=o.contributors,localStorage.setItem(`oo_drawing_${n}`,JSON.stringify(ie)),console.log("[OpenOverlay] Loaded from cloud:",ie.length,"mine,",gr.length,"from others"),document.dispatchEvent(new CustomEvent("oo:contributors",{detail:{contributors:na}})),ye();return}}gr=[];const e=localStorage.getItem(`oo_drawing_${n}`);if(e)try{ie=JSON.parse(e),console.log("[OpenOverlay] Loaded",ie.length,"items from localStorage"),ye()}catch{console.warn("[OpenOverlay] Failed to load drawings"),ie=[]}else ie=[]}function _d(){return btoa(window.location.href).slice(0,32)}function nS(){Jm(n=>{n?(console.log("[OpenOverlay] User logged in, reloading drawings from cloud"),Gx()):(console.log("[OpenOverlay] User logged out, reloading public drawings"),Dt=null),wd()})}function Ci(n,e,t,o,r){if(!Je||!bt)return{floor:!1,floorY:0,ceiling:!1,ceilingY:0,leftWall:!1,leftWallX:0,rightWall:!1,rightWallX:0,slopeAngle:0,slopeAheadY:0};const i=window.devicePixelRatio||1;let s=!1,c=0,d=!1,u=0,f=!1,g=0,m=!1,v=0,O=0,C=0;const L=Math.max(1,Math.floor(t*.5*i)),H=Math.floor((n+t/2)*i),z=Math.max(0,H-Math.floor(L/2));try{const N=e+o,$=Math.floor((N-5)*i),j=Math.floor(20*i);if(z>=0&&$>=0&&z+L<=Je.width&&$+j<=Je.height){const Ee=bt.getImageData(z,$,L,j);for(let ae=0;ae<j;ae++){let Te=!1;for(let le=0;le<L;le++){const we=(ae*L+le)*4;if(Ee.data[we+3]>30){Te=!0;break}}if(Te){const le=$/i+ae/i;le>=N-8&&(s=!0,c=le);break}}}const D=e,E=Math.max(0,Math.floor((D-15)*i)),w=Math.floor(15*i);if(z>=0&&E>=0&&z+L<=Je.width&&E+w<=Je.height){const Ee=bt.getImageData(z,E,L,w);for(let ae=w-1;ae>=0;ae--){let Te=!1;for(let le=0;le<L;le++){const we=(ae*L+le)*4;if(Ee.data[we+3]>30){Te=!0;break}}if(Te){const le=E/i+(ae+1)/i;le<=D+5&&(d=!0,u=le);break}}}const b=Math.floor(e*i),I=Math.floor(o*.85*i),_=Math.floor(10*i),x=Math.max(0,Math.floor(n*i)-_);if(x>=0&&b>=0&&x+_<=Je.width&&b+I<=Je.height){const Ee=bt.getImageData(x,b,_,I);e:for(let ae=_-1;ae>=0;ae--)for(let Te=0;Te<I;Te++){const le=(Te*_+ae)*4;if(Ee.data[le+3]>30){f=!0,g=(x+ae+1)/i;break e}}}const T=Math.floor((n+t)*i);if(T>=0&&b>=0&&T+_<=Je.width&&b+I<=Je.height){const Ee=bt.getImageData(T,b,_,I);e:for(let ae=0;ae<_;ae++)for(let Te=0;Te<I;Te++){const le=(Te*_+ae)*4;if(Ee.data[le+3]>30){m=!0,v=(T+ae)/i;break e}}}const Z=e+o,ue=20,me=r!==!1?n+t+ue:n-ue,Re=Math.floor(me*i),Se=Math.floor((Z-30)*i),_e=Math.floor(50*i);if(Re>=0&&Re<Je.width&&Se>=0&&Se+_e<=Je.height){const Ee=bt.getImageData(Re,Se,1,_e);for(let ae=0;ae<_e;ae++)if(Ee.data[ae*4+3]>30){C=Se/i+ae/i;const we=(s?c:Z)-C;O=Math.atan2(we,ue)*(180/Math.PI);break}}}catch{}return{floor:s,floorY:c,ceiling:d,ceilingY:u,leftWall:f,leftWallX:g,rightWall:m,rightWallX:v,slopeAngle:O,slopeAheadY:C}}function oS(n,e,t){if(n.length<2)return;const r=document.body.getBoundingClientRect(),i=window.scrollX,s=window.scrollY,c=n.map(d=>({x:(d.x-i)/r.width,y:(d.y-s)/r.height}));ie.push({type:"stroke",anchorSelector:"body",points:c,anchorBounds:{x:i,y:s,width:r.width,height:r.height},color:e,width:t,opacity:1,brush:"solid",eraser:!1,layer:"normal"}),ye()}function rS(){ie.length>0&&(ie.pop(),ye())}let Oe=null,l=null,Rt=null,J=null,Ue="none",ps="spawn",A={x:100,y:100,vx:0,vy:0,width:23,height:41,onGround:!1,facingRight:!0,animFrame:0,jumpsRemaining:2,maxJumps:2},ra=!1,Pi=0,ia=0,bn=!1,Ea=0,ap=0;const iS=12e4,sS=2e3;let xn="none",Fo=0,lp=0,cp=0;const up=3e4,aS=9e4,lS=1500;let cS=!1,Bc=localStorage.getItem("oo_player_color")||"#ffffff",$c=localStorage.getItem("oo_color_head")||localStorage.getItem("oo_player_color")||"#ffffff",Kn=localStorage.getItem("oo_color_body")||localStorage.getItem("oo_player_color")||"#ffffff",jc=localStorage.getItem("oo_color_face")||"#ff69b4",zi=localStorage.getItem("oo_color_hair")||localStorage.getItem("oo_player_color")||"#ffffff",ky=localStorage.getItem("oo_color_dress")||localStorage.getItem("oo_player_color")||"#ffffff",gs=localStorage.getItem("oo_player_hat")||"none",ms=localStorage.getItem("oo_player_accessory")||"none",Cy=localStorage.getItem("oo_explore_respawn")!=="false",Wc=localStorage.getItem("oo_screen_name")||"";function uS(n,e){const t=n.replace(/^#?([a-f\d])([a-f\d])([a-f\d])$/i,(c,d,u,f)=>d+d+u+u+f+f),o=/^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(t);if(!o)return n;const r=Math.max(0,Math.round(parseInt(o[1],16)*(1-e))),i=Math.max(0,Math.round(parseInt(o[2],16)*(1-e))),s=Math.max(0,Math.round(parseInt(o[3],16)*(1-e)));return`#${r.toString(16).padStart(2,"0")}${i.toString(16).padStart(2,"0")}${s.toString(16).padStart(2,"0")}`}let yr=localStorage.getItem("oo_player_girl")==="true",ys=localStorage.getItem("oo_player_face")||"smudgy",_n=0;const dS=.02;let Ki=0;const dp=15;let hp=0,sa=35,Ri=!1,rc=0;const hS=60,fp=400,fS=600,pp=40,pS=80;let Xi=[],Bt=new Map,eo=new Map,ic=0,gp=0,mp=0;const gS=80;let He=!1,gt=null,Rn=0,Me=!1,Tn=null,no=null,$o=0;const Qa=3e3,Py=5e3,Ry=3e3;let Hc=0;const mS=4e3;let Oy=0;function Gc(){Oy=performance.now()+mS}const yS=5e3;function jr(){const n=ce();return n?gt!=null&&gt.gameActive?gt.itPlayerId===n.uid:Me:!1}let ve={id:zy(),name:"New Course",checkpoints:[],authorId:"local-user",authorName:"You",createdAt:Date.now()},Wr=[],Qi=null;function My(){if(Qi&&Qi!=="mine"){const n=Wr.find(e=>e.userId===Qi);if(n)return n}return ve}function yp(){document.dispatchEvent(new CustomEvent("oo:coursesupdate",{detail:{myCourse:ve,otherCourses:Wr.map(n=>({userId:n.userId,displayName:n.displayName,checkpoints:n.checkpoints}))}}))}const vS=.6,vp=-12,bp=4,bS=.7,wp=14,sc=6,Ft={};function wS(){for(const n in Ft)Ft[n]=!1}let vr=null,Yc=0,_t=!1,Kc=0,ni=0,Oo=0,uo=3,Td=3,an=!1,Xc=0;const _p=1500,_S=2e3;let Ed=0,Ja=!1,Tt="explore",On=!1,Id=0;const Ny=2e3;let De=null,wn=null,yt=null,Or=!1,on=0,Ji=localStorage.getItem("oo_player_name")||"";function TS(){console.log("[OpenOverlay] initGame starting..."),Oe=document.createElement("canvas"),Oe.id="oo-game-canvas",Oe.style.cssText=`
    position: absolute;
    top: 0;
    left: 0;
    z-index: 2147483638;
    pointer-events: none;
  `,document.body.appendChild(Oe),l=Oe.getContext("2d"),Rt=document.createElement("canvas"),Rt.id="oo-overlay-canvas",Rt.style.cssText=`
    position: absolute;
    top: 0;
    left: 0;
    z-index: 2147483646;
    pointer-events: none;
  `,document.body.appendChild(Rt),J=Rt.getContext("2d"),ac(),window.addEventListener("resize",ac),new ResizeObserver(ac).observe(document.body),document.addEventListener("keydown",jS),document.addEventListener("keyup",WS),document.addEventListener("oo:gamemode",t=>{Tp(t.detail.mode,t.detail.tool,t.detail.playmode,t.detail.spawnPos,t.detail.fromOnboarding,t.detail.skipTagGame)}),document.addEventListener("oo:undo",()=>{Ue==="build"&&ve.checkpoints.length>0&&(ve.checkpoints.pop(),Hr(),nt())}),document.addEventListener("oo:clear",()=>{Ue==="build"&&(ve.checkpoints=[],Hr(),nt())}),document.addEventListener("oo:selectcourse",t=>{Qi=t.detail.courseId==="mine"?null:t.detail.courseId,console.log("[OpenOverlay] Selected race course:",Qi||"mine"),nt()}),document.addEventListener("oo:playercolor",t=>{Bc=t.detail.color,localStorage.setItem("oo_player_color",Bc),nt()}),document.addEventListener("oo:partcolor",t=>{const{part:o,color:r}=t.detail;switch(o){case"head":$c=r,localStorage.setItem("oo_color_head",r);break;case"body":Kn=r,localStorage.setItem("oo_color_body",r);break;case"face":jc=r,localStorage.setItem("oo_color_face",r);break;case"hair":zi=r,localStorage.setItem("oo_color_hair",r);break;case"dress":ky=r,localStorage.setItem("oo_color_dress",r);break}nt()}),document.addEventListener("oo:playerstyle",t=>{yr=t.detail.isGirl,nt()}),document.addEventListener("oo:playerhat",t=>{gs=t.detail.hat,localStorage.setItem("oo_player_hat",gs),nt()}),document.addEventListener("oo:playeraccessory",t=>{ms=t.detail.accessory,localStorage.setItem("oo_player_accessory",ms),nt()}),document.addEventListener("oo:playerface",t=>{ys=t.detail.face,localStorage.setItem("oo_player_face",ys),nt()}),document.addEventListener("oo:screenname",t=>{Wc=t.detail.name,localStorage.setItem("oo_screen_name",Wc),vs()}),document.addEventListener("oo:respawnsetting",t=>{Cy=t.detail.respawn}),document.addEventListener("oo:toggletag",()=>{console.log("[OpenOverlay] Tag toggle requested, gameMode:",Ue),Jc=!1,Ue!=="play"&&(console.log("[OpenOverlay] Auto-switching to play mode for tag"),Tp("play","explore")),ZS()}),Oe.addEventListener("pointerdown",GS),Oe.addEventListener("pointermove",YS),Oe.addEventListener("pointerup",KS),Oe.addEventListener("contextmenu",t=>{Ue==="build"&&t.preventDefault()}),XS(),nt();const e=()=>{Ue==="play"&&(Qm(),Xm(Fn()))};window.addEventListener("beforeunload",e),window.addEventListener("pagehide",e),document.addEventListener("visibilitychange",()=>{document.hidden&&Ue==="play"&&vs()}),document.addEventListener("oo:save",()=>{performance.now()}),document.addEventListener("mousemove",t=>{t.pageX,t.pageY}),document.addEventListener("oo:dismisssmudgy",()=>{}),performance.now(),console.log("[OpenOverlay] Game initialized")}function ac(){if(!Oe||!l)return;const n=Math.max(document.body.scrollWidth,document.body.offsetWidth,document.documentElement.scrollWidth,document.documentElement.offsetWidth),e=Math.max(document.body.scrollHeight,document.body.offsetHeight,document.documentElement.scrollHeight,document.documentElement.offsetHeight),t=window.devicePixelRatio||1;Oe.style.width=`${n}px`,Oe.style.height=`${e}px`,Oe.width=n*t,Oe.height=e*t,l.scale(t,t),Rt&&J&&(Rt.style.width=`${n}px`,Rt.style.height=`${e}px`,Rt.width=n*t,Rt.height=e*t,J.scale(t,t)),nt()}let Bi=null,Qc=!1,Jc=!1;function Tp(n,e,t,o,r,i){if(Ue=n,e&&(ps=e),t&&(Tt=t),o&&(Bi=o),Qc=r||!1,Jc=i||!1,n==="play"&&Gc(),Oe&&(Oe.style.pointerEvents=n==="build"?"auto":"none",Oe.style.cursor=n==="build"?"crosshair":"default"),n==="play"){_t=!1,ni=0,Oo=0,ve.checkpoints.forEach(c=>c.reached=!1),uo=Td,an=!1,On=!1,De=null,Or=!1;const s=Fn();console.log("[OpenOverlay] Subscribing to players on page:",s),LI(s,c=>{if(Bt=c,c.size>0&&(console.log("[OpenOverlay] Received",c.size,"other players"),c.forEach((d,u)=>{console.log("[OpenOverlay] Player",u,"at",d.x,d.y)}),He)){const d=ce(),u=Date.now();let f=null;for(const[v,O]of c)O.taggedPlayerId===(d==null?void 0:d.uid)&&O.taggedAt&&u-O.taggedAt<Py&&!Me&&u>Rn&&(console.log("[OpenOverlay] EXPLICITLY TAGGED by:",v,"via taggedPlayerId"),Me=!0,Tn=v,Rn=u+Qa,Ht("You're IT!","Tag someone!",2e3),Zc(),document.dispatchEvent(new CustomEvent("oo:tagstatechange",{detail:{isTagMode:!0,isIt:!0,gameActive:!0}})));for(const[v,O]of c){if(console.log("[OpenOverlay] Checking player",v,"isIt:",O.isIt),O.isIt){f=v,console.log("[OpenOverlay] Found IT player in sync:",O.displayName,"id:",v);break}v===Tn&&!O.isIt&&(console.log("[OpenOverlay] Clearing lastTaggedByPlayerId - sync caught up"),Tn=null)}const g=u<Rn,m=f===Tn;f&&Me&&d&&!g&&!m?f<d.uid?(console.log("[OpenOverlay] Tiebreaker: other player wins (lower ID), giving up IT"),Me=!1,Tn=null,document.dispatchEvent(new CustomEvent("oo:tagstatechange",{detail:{isTagMode:!0,isIt:!1,gameActive:!0}}))):console.log("[OpenOverlay] Tiebreaker: we win (lower ID), keeping IT"):f&&Me&&g?console.log("[OpenOverlay] Skipping tiebreaker - in tag cooldown"):f&&Me&&m?console.log("[OpenOverlay] Skipping tiebreaker - was tagged by this player (stale sync)"):f&&!Me&&console.log("[OpenOverlay] Other player is IT, we are not")}}),DI(s,c=>{if(Jc){console.log("[OpenOverlay] Skipping tag game - MP mode only");return}const d=gt;gt=c,console.log("[OpenOverlay] Tag game state changed:",c);const u=ce(),f=(c==null?void 0:c.itPlayerId)===(u==null?void 0:u.uid);document.dispatchEvent(new CustomEvent("oo:tagstatechange",{detail:{isTagMode:He,isIt:f,gameActive:(c==null?void 0:c.gameActive)??!1}})),c!=null&&c.gameActive&&(console.log('[OpenOverlay] Tag game active, "it" is:',c.itPlayerId),(d==null?void 0:d.itPlayerId)!==c.itPlayerId&&(f?Ht("You're IT!","Tag someone!",2e3):(d==null?void 0:d.itPlayerId)===(u==null?void 0:u.uid)&&Ht("You're not IT!","Run away!",2e3)))}),Vy(),Tt==="race"&&document.dispatchEvent(new CustomEvent("oo:hidetoolbar")),ES()}else n==="build"?(Or=!1,On=!1,De=null,He=!1,Me=!1,Tn=null,no=null,$o=0,gt=null):(Or=!1,On=!1,De=null,Qm(),VI(),Xm(Fn()),Bt.clear(),eo.clear(),He=!1,Me=!1,Tn=null,no=null,$o=0,gt=null);nt()}function ES(){vr&&(cancelAnimationFrame(vr),vr=null),Yc=performance.now(),vr=requestAnimationFrame(Ly)}function Ly(n){const e=Math.min((n-Yc)/16.67,3);Yc=n,AS(e),nt(),Ue==="play"||Ue==="build"||cS?vr=requestAnimationFrame(Ly):vr=null}function Dy(){if(Bi){A.x=Bi.x-A.width/2,A.y=Bi.y-A.height,Bi=null,A.vx=0,A.vy=0,A.onGround=!0,A.jumpsRemaining=A.maxJumps;return}const n=Tt==="race"?My():ve,e=n.checkpoints.find(r=>r.type==="spawn"),t=n.checkpoints.find(r=>r.type==="start"),o=e||t;o?(A.x=o.x-A.width/2,A.y=o.y-A.height-10):(A.x=window.scrollX+window.innerWidth/2-A.width/2,A.y=window.scrollY+100),A.vx=0,A.vy=0,A.onGround=!1,A.jumpsRemaining=A.maxJumps}function Vy(){if(wS(),Dy(),Tt==="explore"){On=!1,_t=!1,Ht("Explore!","No timer, unlimited respawns",2e3),setTimeout(()=>{},150);return}On=!0,Id=performance.now(),Ht("Get Ready!","2")}function Ht(n,e,t=1e3){De={text:n,subtext:e,endTime:performance.now()+t}}function IS(n,e=1e3){const t=performance.now();wn={text:n,startTime:t,endTime:t+e}}function Zc(){Hc=performance.now()+Ry}function Fy(n){yt&&aa();const{top10:e}=JS();yt=document.createElement("div"),yt.id="oo-game-popup",yt.style.cssText=`
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background: rgba(0,0,0,0.7);
    z-index: 2147483647;
    display: flex;
    align-items: center;
    justify-content: center;
    font-family: system-ui, -apple-system, sans-serif;
  `;const t=n==="finish",o=t?"🏆 RACE COMPLETE!":"💀 GAME OVER",r=t?"#22c55e":"#ef4444",i=(ni/1e3).toFixed(2),s=t&&on===ve.bestTime;let c="";e.length>0&&(c=`
      <div style="margin-top: 15px; max-height: 200px; overflow-y: auto;">
        <div style="color: #fbbf24; font-weight: bold; margin-bottom: 8px;">🏆 Today's Best</div>
        ${e.slice(0,5).map((m,v)=>`
          <div style="display: flex; justify-content: space-between; color: ${v<3?["#fbbf24","#c0c0c0","#cd7f32"][v]:"#888"}; font-size: 13px; padding: 2px 0;">
            <span>${v+1}. ${m.name.slice(0,10)}</span>
            <span>${(m.time/1e3).toFixed(2)}s</span>
          </div>
        `).join("")}
      </div>
    `);const d=document.createElement("div");d.style.cssText=`
    background: #111;
    border: 3px solid ${r};
    border-radius: 12px;
    padding: 25px 35px;
    text-align: center;
    min-width: 300px;
    max-width: 400px;
    box-shadow: 0 10px 40px rgba(0,0,0,0.8);
  `,d.innerHTML=`
    <div style="color: ${r}; font-size: 24px; font-weight: bold; margin-bottom: 15px;">${o}</div>
    <div style="color: #fff; font-size: 40px; font-weight: bold; font-family: monospace;">${i}s</div>
    ${s?'<div style="color: #fbbf24; font-size: 14px; margin-top: 5px;">⭐ NEW PERSONAL BEST!</div>':""}
    ${t?`
      <div style="margin-top: 15px;">
        <input type="text" id="oo-popup-name" placeholder="Enter name..." value="${Ji}"
          style="padding: 8px 12px; border-radius: 6px; border: 2px solid #333; background: #222; color: #fff; font-size: 14px; width: 180px; text-align: center;">
      </div>
    `:""}
    ${c}
    <div style="display: flex; gap: 10px; justify-content: center; margin-top: 20px;">
      <button id="oo-popup-retry" style="padding: 10px 25px; background: ${r}; color: white; border: none; border-radius: 8px; font-size: 14px; font-weight: bold; cursor: pointer;">
        🔄 Retry
      </button>
      <button id="oo-popup-close" style="padding: 10px 25px; background: #333; color: white; border: none; border-radius: 8px; font-size: 14px; font-weight: bold; cursor: pointer;">
        ✕ Close
      </button>
    </div>
  `,yt.appendChild(d),document.body.appendChild(yt);const u=yt.querySelector("#oo-popup-retry"),f=yt.querySelector("#oo-popup-close"),g=yt.querySelector("#oo-popup-name");u==null||u.addEventListener("click",()=>{t&&g&&g.value.trim()&&la(g.value.trim(),on),aa(),xS()}),f==null||f.addEventListener("click",()=>{t&&g&&g.value.trim()&&la(g.value.trim(),on),aa(),Ep()}),yt.addEventListener("click",m=>{m.target===yt&&(t&&g&&g.value.trim()&&la(g.value.trim(),on),aa(),Ep())}),g==null||g.focus(),g==null||g.addEventListener("keydown",m=>{m.stopPropagation(),m.key==="Enter"&&g.value.trim()&&(m.preventDefault(),la(g.value.trim(),on),g.value="✓ Saved!",g.disabled=!0,g.style.background="#22c55e",u==null||u.focus())})}function aa(){yt&&(yt.remove(),yt=null)}function xS(){_t=!1,ni=0,Oo=0,ve.checkpoints.forEach(n=>n.reached=!1),uo=Td,an=!1,Or=!1,Xi=[],Vy()}function Ep(){document.dispatchEvent(new CustomEvent("oo:gamemode",{detail:{mode:"build"}})),_t=!1,Or=!1}function Uy(){an||(an=!0,Xc=performance.now(),Tt==="race"&&_t&&(uo--,console.log("[OpenOverlay] Died! Lives remaining:",uo)))}let Ip=!1;function SS(){const n=performance.now();for(const[t,o]of Bt){let r=eo.get(t);if(!r){r={x:o.x,y:o.y,vx:o.vx,vy:o.vy,lastSyncTime:n,targetX:o.x,targetY:o.y},eo.set(t,r);continue}const i=Math.abs(o.x-r.targetX)>.1||Math.abs(o.y-r.targetY)>.1,s=Math.abs(o.vx-r.vx)>.1||Math.abs(o.vy-r.vy)>.1;if(i||s){r.vx=o.vx,r.vy=o.vy,r.lastSyncTime=n;const g=5;r.targetX=o.x+o.vx*g,r.targetY=o.y+o.vy*g}r.x+=r.vx*.5,r.y+=r.vy*.5;const c=.12,d=r.targetX-r.x,u=r.targetY-r.y;(Math.abs(d)>1||Math.abs(u)>1)&&(r.x+=d*c,r.y+=u*c),Math.sqrt(d*d+u*u)>150&&(r.x=o.x,r.y=o.y)}for(const t of eo.keys())Bt.has(t)||eo.delete(t);const e=Date.now();for(const[t,o]of Bt)o.updatedAt&&e-o.updatedAt>yS&&(console.log("[OpenOverlay] Removing stale player:",t),Bt.delete(t),eo.delete(t))}function AS(n){if(Ue!=="play")return;if(SS(),On){const N=performance.now()-Id,$=Ny-N;$>1e3?De={text:"Get Ready!",subtext:"2",endTime:performance.now()+100}:$>0?De={text:"Get Ready!",subtext:"1",endTime:performance.now()+100}:(On=!1,De={text:"GO!",endTime:performance.now()+500},Tt==="race"&&(_t=!0,Kc=performance.now()));return}if(an){const N=_p-(performance.now()-Xc);if(N>0&&(De={text:"You fell!",subtext:`Respawning in ${Math.ceil(N/1e3)}...`,endTime:performance.now()+100}),performance.now()-Xc>=_p){if(Tt==="race"&&uo<=0){_t=!1,an=!1,Fy("gameover");return}if(Tt==="explore"&&!Cy){an=!1,De=null,document.dispatchEvent(new CustomEvent("oo:gamemode",{detail:{mode:"none"}}));return}an=!1,Dy(),De=null,setTimeout(()=>{},100)}return}De&&performance.now()>De.endTime&&(De=null);const t=performance.now()<Ed?bp*2:bp;if(Ft.ArrowLeft||Ft.KeyA)A.vx=-t,A.facingRight=!1,ia=performance.now(),bn=!1;else if(Ft.ArrowRight||Ft.KeyD)A.vx=t,A.facingRight=!0,ia=performance.now(),bn=!1;else{const N=Pi>0?.92:bS;A.vx*=N,Math.abs(A.vx)<.1&&(A.vx=0)}if(Pi>0&&Pi--,Math.abs(A.vx)>.5){const N=(gt==null?void 0:gt.gameActive)&&!jr(),$=Tt==="explore"||N,j=Math.abs(A.x-hp);$&&j>sa&&!Ri&&(Ri=!0,rc=0,hp=A.x,N?sa=pp+Math.random()*(pS-pp):sa=fp+Math.random()*(fS-fp)),Ri?(_n=-1,rc++,rc>=hS&&(Ri=!1)):_n=1,Ki=0}else Ri=!1,sa=50,Ki===0&&Math.abs(_n)>.1&&(_n=A.facingRight?1:-1),Math.abs(_n)>.1?_n*=1-dS:_n=0,Ki++;if(A.onGround&&Math.abs(A.vx)<.1){const N=performance.now(),$=N-ia;if($>iS&&!bn&&(bn=!0,ap=N,Ea=0),bn&&(N-ap<sS?Ea+=.15:(bn=!1,ia=N)),!bn&&xn==="none"&&N>cp&&$>1e3){const j=["headScratch","buttScratch","weightShift","lookAround"];xn=j[Math.floor(Math.random()*j.length)],lp=N,Fo=0}xn!=="none"&&(Fo+=.1,N-lp>lS&&(xn="none",Fo=0,cp=N+up+Math.random()*(aS-up)))}else bn=!1,Ea=0,xn="none",Fo=0;const r=Ft.ArrowUp||Ft.KeyW||Ft.Space;if(r&&!Ip&&A.jumpsRemaining>0){const N=Ja?vp*1.5:vp;A.vy=N,A.onGround=!1,A.jumpsRemaining--,Ja=!1}Ip=r,A.vy+=vS*n,A.vy>wp&&(A.vy=wp);const i=50,s=A.vx>=0;A.onGround=!1;const c=A.vx*n,d=A.vy*n,u=Math.sqrt(c*c+d*d),f=Math.max(1,Math.ceil(u/sc)),g=c/f,m=d/f;for(let N=0;N<f;N++){const $=A.x+g,j=A.y+m,D=Ci($,A.y,A.width,A.height,s);let E=!0;A.vx<0&&D.leftWall&&(A.x=D.leftWallX,A.vx=0,E=!1),A.vx>0&&D.rightWall&&(A.x=D.rightWallX-A.width,A.vx=0,E=!1),E&&Math.abs(A.vx)>.5&&D.slopeAheadY>0&&D.slopeAngle>i&&(A.vx=0,E=!1);let w=!0;if(A.vy<0){const b=Ci(A.x,j,A.width,A.height,s);b.ceiling&&(A.y=b.ceilingY,A.vy=1,w=!1)}if(E&&(A.x+=g),w&&(A.y+=m),A.vy>=0){const b=Ci(A.x,A.y,A.width,A.height,s);if(b.floor){const I=b.floorY-A.height,_=A.y-I,T=A.vy>5?2:8;if(_<=T&&_>=-sc){!ra&&Math.abs(A.vx)>.5&&(Pi=8),!ra&&Qc&&(Qc=!1,IS("Move with WASD/Arrows!",1500)),A.y=I,A.vy=0,A.onGround=!0,A.jumpsRemaining=A.maxJumps;break}}}}const v=Ci(A.x,A.y,A.width,A.height,s);A.vy<0&&v.ceiling&&(A.y=v.ceilingY,A.vy=1);const O=v.leftWall&&A.x<v.leftWallX,C=v.rightWall&&A.x+A.width>v.rightWallX;if(O&&C){const N=v.leftWallX-A.x,$=A.x+A.width-v.rightWallX;N<$?A.x=v.leftWallX:A.x=v.rightWallX-A.width,A.vx=0}else O?(A.x=v.leftWallX,A.vx=0):C&&(A.x=v.rightWallX-A.width,A.vx=0);if(A.vy>0&&!A.onGround&&v.floor){const N=v.floorY-A.height,$=A.y-N;$<=8&&$>=-sc&&(!ra&&Math.abs(A.vx)>.5&&(Pi=8),A.y=N,A.vy=0,A.onGround=!0,A.jumpsRemaining=A.maxJumps)}if(A.onGround&&Math.abs(A.vx)>.5){const N=Math.abs(A.vx),$=Math.min(3,Math.ceil(N*.3));for(let j=1;j<=$;j++){const D=A.y-j,E=Ci(A.x,D,A.width,A.height,s);if(E.floor&&!E.leftWall&&!E.rightWall){const w=E.floorY-A.height,b=A.y-w;if(b>0&&b<=$){A.y=w;break}}}}ra=A.onGround;const L=Math.max(document.body.scrollHeight,window.innerHeight),H=Math.max(document.body.scrollWidth,window.innerWidth);(A.y>L+_S||A.x<-100||A.x>H+100)&&Uy(),Math.abs(A.vx)>.5?A.animFrame=(A.animFrame+.15*n)%4:A.animFrame=0,kS(),CS(),He&&PS(),_t&&Tt==="race"&&(ni=performance.now()-Kc);const z=performance.now();if(Ue==="play"&&z-ic>gS){const N=Math.abs(A.x-gp)>5||Math.abs(A.y-mp)>5,$=z-ic>5e3;(N||$)&&(ic=z,gp=A.x,mp=A.y,vs())}}function vs(){const n=Fn(),e=ce(),t=He&&jr();He&&console.log("[OpenOverlay] Syncing player with isIt:",t,"isTagMode:",He,"localIsIt:",Me);const o=Date.now();no&&o-$o>Py&&(no=null,$o=0);const r=Math.abs(A.vx)>.5,i={x:A.x,y:A.y+A.height,vx:A.vx,vy:A.vy,facingRight:A.facingRight,animFrame:A.animFrame,onGround:A.onGround,isDead:an,isMoving:r,playerColor:Bc,playerHat:gs,playerAccessory:ms,isGirlMode:yr,faceStyle:ys,displayName:Wc||(e==null?void 0:e.displayName)||"",updatedAt:o,isIt:He&&jr(),tagCooldownUntil:Rn};no&&(i.taggedPlayerId=no,i.taggedAt=$o),NI(n,i)}function kS(){if(Tt!=="race")return;const n=My(),e=n.checkpoints,t=e.filter(o=>o.type==="checkpoint").length;for(const o of e){if(o.reached)continue;const r=A.x+A.width/2,i=A.y+A.height/2;if(Math.hypot(r-o.x,i-o.y)<50)if(o.type==="start"&&!_t)_t=!0,Kc=performance.now(),o.reached=!0,console.log("[OpenOverlay] Race started!");else if(o.type==="checkpoint"&&_t){const c=Oo+1;o.order===c&&(o.reached=!0,Oo++,console.log("[OpenOverlay] Checkpoint",Oo,"of",t,"reached!"),Ht(`Flag ${Oo}/${t}`,"",1500))}else o.type==="finish"&&_t&&Oo>=t&&(o.reached=!0,_t=!1,on=ni,console.log("[OpenOverlay] Race finished! Time:",(on/1e3).toFixed(2)+"s"),(!n.bestTime||on<n.bestTime)&&(n.bestTime=on,n===ve&&Hr()),Fy("finish"),document.dispatchEvent(new CustomEvent("oo:racefinish",{detail:{time:on,bestTime:n.bestTime}})))}}function CS(){const n=[...ve.checkpoints,...Wr.flatMap(e=>e.checkpoints)];for(const e of n){if(!["trampoline","speedBoost","highJump","spike"].includes(e.type))continue;const t=e.width||60,o=e.height||20,r=e.x-t/2,i=e.x+t/2,s=e.y-o,c=e.y,d=A.x,u=A.x+A.width,f=A.y,g=A.y+A.height;if(u>r&&d<i&&g>s&&f<c)switch(e.type){case"trampoline":A.vy>0&&(A.vy=-20,A.onGround=!1,A.jumpsRemaining=A.maxJumps);break;case"speedBoost":Ed=performance.now()+3e3;break;case"highJump":Ja=!0;break;case"spike":an||(Xi.push({x:A.x+A.width/2,y:A.y+A.height,createdAt:performance.now()}),Uy());break}}}function PS(){if(!He||!ce())return;const e=Date.now(),t=Fn(),o=A.x+A.width/2,r=A.y+A.height,i=jr();for(const[s,c]of Bt){const d=eo.get(s),u=d?d.x:c.x,f=d?d.y:c.y,g=o-u,m=r-f;if(Math.sqrt(g*g+m*m)<40){const O=e>Rn,C=!c.tagCooldownUntil||e>c.tagCooldownUntil;i&&O&&C&&(console.log("[OpenOverlay] TAGGING player:",s),Me=!1,no=s,$o=e,Rn=e+Qa,UI(t,s).catch(()=>{console.log("[OpenOverlay] Firebase tag update failed")}),Ht("Tagged!",c.displayName||"Player",1500),Zc(),document.dispatchEvent(new CustomEvent("oo:tagstatechange",{detail:{isTagMode:!0,isIt:!1,gameActive:!0}})),vs());const L=!c.tagCooldownUntil||e>c.tagCooldownUntil;!i&&c.isIt&&O&&L&&(console.log("[OpenOverlay] GOT TAGGED by:",s),Me=!0,Rn=e+Qa,Tn=s,Ht("You're IT!","Tag someone!",2e3),Zc(),document.dispatchEvent(new CustomEvent("oo:tagstatechange",{detail:{isTagMode:!0,isIt:!0,gameActive:!0}})))}}}function nt(){if(!(!l||!Oe)){l.clearRect(0,0,Oe.width,Oe.height),J&&Rt&&J.clearRect(0,0,Rt.width,Rt.height),RS();for(const n of ve.checkpoints)xp(n);for(const n of Wr)for(const e of n.checkpoints)xp(e,n.authorName);(Ue==="play"||Ue==="build")&&(OS(),LS(),Ue==="play"&&US()),Ue==="build"&&$S()}}function RS(){if(!l)return;const n=performance.now(),e=5e3;Xi=Xi.filter(t=>n-t.createdAt<e);for(const t of Xi){const o=n-t.createdAt,r=Math.max(0,1-o/e);l.save(),l.globalAlpha=r,l.fillStyle="#dc2626",l.beginPath(),l.arc(t.x,t.y,12,0,Math.PI*2),l.fill(),l.fillStyle="#b91c1c";for(let i=0;i<5;i++){const s=i/5*Math.PI*2+Math.random()*.5,c=15+Math.random()*10,d=Math.cos(s)*c,u=Math.sin(s)*c*.5;l.beginPath(),l.arc(t.x+d,t.y+u,4+Math.random()*3,0,Math.PI*2),l.fill()}l.restore()}}function xp(n,e){if(!l)return;const t=n.x,o=n.y;if(l.save(),e&&(n.type==="start"||n.type==="finish")&&(l.font="10px Arial",l.fillStyle="rgba(255,255,255,0.7)",l.textAlign="center",l.fillText(`by ${e}`,t,o+15)),n.type==="start"){const r=n.reached?"#86efac":"#22c55e",i=80,s=70;l.strokeStyle="#444",l.lineWidth=6,l.beginPath(),l.moveTo(t-i/2,o),l.lineTo(t-i/2,o-s),l.stroke(),l.beginPath(),l.moveTo(t+i/2,o),l.lineTo(t+i/2,o-s),l.stroke(),l.fillStyle=r,l.fillRect(t-i/2-3,o-s-15,i+6,20),l.strokeStyle="#166534",l.lineWidth=2,l.strokeRect(t-i/2-3,o-s-15,i+6,20),l.fillStyle="#fff",l.font="bold 14px sans-serif",l.textAlign="center",l.fillText("START",t,o-s-1)}else if(n.type==="finish"){l.strokeStyle="#444",l.lineWidth=6,l.beginPath(),l.moveTo(t-80/2,o),l.lineTo(t-80/2,o-70),l.stroke(),l.beginPath(),l.moveTo(t+80/2,o),l.lineTo(t+80/2,o-70),l.stroke();const s=o-70-15,c=20,d=8;l.fillStyle=n.reached?"#fbbf24":"#111",l.fillRect(t-80/2-3,s,86,c);for(let u=0;u<Math.ceil(86/d);u++)for(let f=0;f<Math.ceil(c/d);f++)(u+f)%2===0&&(l.fillStyle="#fff",l.fillRect(t-80/2-3+u*d,s+f*d,d,Math.min(d,c-f*d)));l.strokeStyle="#444",l.lineWidth=2,l.strokeRect(t-80/2-3,s,86,c),l.fillStyle="#fff",l.font="bold 11px sans-serif",l.textAlign="center",l.fillText("FINISH",t,o+15)}else if(n.type==="spawn"){if(Ue!=="build"){l.restore();return}const r="#a855f7";l.fillStyle=r,l.beginPath(),l.moveTo(t,o-20),l.lineTo(t-10,o-35),l.lineTo(t+10,o-35),l.closePath(),l.fill(),l.strokeStyle=r,l.lineWidth=2,l.beginPath(),l.arc(t,o-55,8,0,Math.PI*2),l.stroke(),l.beginPath(),l.moveTo(t,o-47),l.lineTo(t,o-30),l.stroke(),l.beginPath(),l.moveTo(t-10,o-42),l.lineTo(t+10,o-42),l.stroke(),l.beginPath(),l.moveTo(t,o-30),l.lineTo(t-8,o-15),l.moveTo(t,o-30),l.lineTo(t+8,o-15),l.stroke(),l.fillStyle="#fff",l.font="bold 10px sans-serif",l.textAlign="center",l.fillText("SPAWN",t,o+5)}else if(n.type==="trampoline"){const r=n.width||60,i=n.height||20;l.fillStyle="#f97316",l.fillRect(t-r/2,o-i,r,i),l.strokeStyle="#c2410c",l.lineWidth=2,l.strokeRect(t-r/2,o-i,r,i),l.strokeStyle="#c2410c",l.lineWidth=2;const s=3,c=r/s;for(let d=0;d<s;d++){const u=t-r/2+c/2+d*c;l.beginPath(),l.moveTo(u,o),l.lineTo(u-4,o-i/3),l.lineTo(u+4,o-i*2/3),l.lineTo(u,o-i),l.stroke()}}else if(n.type==="speedBoost"){const r=n.width||60,i=n.height||20,s=performance.now()<Ed;l.fillStyle=s?"#60a5fa":"#3b82f6",l.fillRect(t-r/2,o-i,r,i),l.strokeStyle="#1d4ed8",l.lineWidth=2,l.strokeRect(t-r/2,o-i,r,i),l.fillStyle="#fff",l.font="bold 14px sans-serif",l.textAlign="center",l.textBaseline="middle",l.fillText(">>",t,o-i/2)}else if(n.type==="highJump"){const r=n.width||60,i=n.height||20,s=Ja;l.fillStyle=s?"#86efac":"#22c55e",l.fillRect(t-r/2,o-i,r,i),l.strokeStyle="#15803d",l.lineWidth=2,l.strokeRect(t-r/2,o-i,r,i),l.fillStyle="#fff",l.font="bold 16px sans-serif",l.textAlign="center",l.textBaseline="middle",l.fillText("^",t,o-i/2)}else if(n.type==="spike"){const r=n.width||60,i=n.height||30,s=4,c=r/s;l.fillStyle="#ef4444";for(let d=0;d<s;d++){const u=t-r/2+d*c;l.beginPath(),l.moveTo(u,o),l.lineTo(u+c/2,o-i),l.lineTo(u+c,o),l.closePath(),l.fill()}l.strokeStyle="#991b1b",l.lineWidth=1;for(let d=0;d<s;d++){const u=t-r/2+d*c;l.beginPath(),l.moveTo(u,o),l.lineTo(u+c/2,o-i),l.lineTo(u+c,o),l.closePath(),l.stroke()}}else if(n.type==="checkpoint"){const r=n.reached?"#fbbf24":"#3b82f6";l.strokeStyle="#444",l.lineWidth=4,l.beginPath(),l.moveTo(t,o),l.lineTo(t,o-50),l.stroke(),l.fillStyle=r,l.beginPath(),l.moveTo(t,o-50),l.lineTo(t+35,o-40),l.lineTo(t,o-30),l.closePath(),l.fill(),l.fillStyle="#fff",l.font="bold 12px sans-serif",l.textAlign="center",l.textBaseline="middle",l.fillText(String(n.order),t+15,o-40)}l.restore()}function OS(){if(l)for(const[n,e]of Bt){const t=`logged_${n}`;window[t]||(window[t]=!0,console.log("[OpenOverlay] Remote player data:",n,JSON.stringify({isGirlMode:e.isGirlMode,playerHat:e.playerHat,playerColor:e.playerColor,displayName:e.displayName,playerAccessory:e.playerAccessory,isIt:e.isIt}))),MS(n,e)}}function MS(n,e){if(!l||e.isDead)return;const t=eo.get(n),o=t?t.x:e.x,r=t?t.y:e.y,i=30,s=41,c=o,d=r-s;l.save(),l.globalAlpha=.85,e.facingRight||(l.translate(c+i/2,0),l.scale(-1,1),l.translate(-(c+i/2),0));const u=7,f=13,g=11,m=c+i/2,v=d+u+3,O=v+u,C=O+f,L=e.playerColor||"#ffffff";l.strokeStyle=L,l.lineWidth=3,l.lineCap="round",l.lineJoin="round",l.shadowColor="rgba(0,0,0,0.3)",l.shadowBlur=4,l.shadowOffsetX=2,l.shadowOffsetY=2;const H=e.isMoving??Math.abs(e.vx)>.5,z=e.animFrame||0;if(e.isGirlMode){const j=Math.sin(z*Math.PI*2)*3;if(l.fillStyle=L,l.beginPath(),H?(l.moveTo(m,v-u-3),l.quadraticCurveTo(m-u+2,v-u-4,m-u-1,v-2),l.lineTo(m-u-2,v+4),l.quadraticCurveTo(m-u-4-j,v+8,m-u-3-j,v+12),l.quadraticCurveTo(m-u,v+11,m-u+3,v+10),l.lineTo(m-2,v+u),l.closePath(),l.fill()):(l.moveTo(m-u-2,v+8),l.lineTo(m-u-1,v-2),l.quadraticCurveTo(m-u+2,v-u-4,m,v-u-3),l.quadraticCurveTo(m+u-2,v-u-4,m+u+1,v-2),l.lineTo(m+u+2,v+8),l.quadraticCurveTo(m+u,v+10,m+u-2,v+10),l.lineTo(m-u+2,v+10),l.quadraticCurveTo(m-u,v+10,m-u-2,v+8),l.closePath(),l.fill()),l.fillStyle="#fff",l.beginPath(),l.arc(m,v,u-1,0,Math.PI*2),l.fill(),l.fillStyle=L,l.beginPath(),l.moveTo(m-u+2,v-2),l.quadraticCurveTo(m-2,v-u-2,m,v-u+1),l.quadraticCurveTo(m+2,v-u-2,m+u-2,v-2),l.quadraticCurveTo(m,v-1,m-u+2,v-2),l.closePath(),l.fill(),(e.faceStyle||"smudgy")==="smudgy"){const w=e.vx>.5?1:e.vx<-.5?-1:0;Za(l,m,v,u,w,e.vy,e.onGround!==!1)}else l.fillStyle=L,H?(l.beginPath(),l.arc(m+2,v,1.5,0,Math.PI*2),l.fill(),l.lineWidth=2,l.beginPath(),l.moveTo(m,v+4),l.lineTo(m+4,v+4),l.stroke(),l.lineWidth=3):(l.beginPath(),l.arc(m-3,v,1.5,0,Math.PI*2),l.fill(),l.beginPath(),l.arc(m+3,v,1.5,0,Math.PI*2),l.fill(),l.lineWidth=1.5,l.beginPath(),l.arc(m,v+3,2.5,.2*Math.PI,.8*Math.PI),l.stroke(),l.lineWidth=3);l.fillStyle=L,l.beginPath(),l.moveTo(m,O),l.lineTo(m-8,C+1),l.lineTo(m+8,C+1),l.closePath(),l.fill();const E=H?Math.sin(z*Math.PI)*6:0;l.strokeStyle="#000",l.lineWidth=2.5,l.beginPath(),l.moveTo(m-3,C),l.lineTo(m-5+E,C+g),l.moveTo(m+3,C),l.lineTo(m+5-E,C+g),l.stroke(),l.strokeStyle="#fff",l.lineWidth=2,l.beginPath(),l.moveTo(m-3,C),l.lineTo(m-5+E,C+g),l.moveTo(m+3,C),l.lineTo(m+5-E,C+g),l.stroke(),l.lineWidth=3,l.strokeStyle=L}else{const j=e.faceStyle||"smudgy",D=v-u;if(j==="smudgy"){const Z=e.animFrame||0;l.strokeStyle=L,l.lineWidth=2.5,l.lineCap="round";const ue=Math.sin(Z*Math.PI*2)*2;H?(l.beginPath(),l.moveTo(m+2,D+2),l.bezierCurveTo(m+2,D-6,m-6,D-4,m-12+ue,D-2),l.stroke(),l.beginPath(),l.moveTo(m-1,D+2),l.bezierCurveTo(m-1,D-4,m-5,D-2,m-9+ue*.7,D),l.stroke()):(l.beginPath(),l.moveTo(m+1,D+1),l.quadraticCurveTo(m+1,D-5,m,D-9),l.stroke(),l.beginPath(),l.moveTo(m-2,D+2),l.quadraticCurveTo(m-2,D-2,m-2,D-5),l.stroke()),l.strokeStyle=L,l.lineWidth=3,l.beginPath(),l.arc(m,v,u,0,Math.PI*2),l.stroke();const me=e.vx>.5?1:e.vx<-.5?-1:0;Za(l,m,v,u,me,e.vy,e.onGround!==!1)}else l.beginPath(),l.arc(m,v,u,0,Math.PI*2),l.stroke(),l.fillStyle=L,l.beginPath(),l.moveTo(m-6,v-u+1),l.lineTo(m-3,v-u-4),l.lineTo(m+8,v-u+3),l.quadraticCurveTo(m,v-u-1,m-6,v-u+1),l.closePath(),l.fill(),l.stroke(),l.fillStyle=L,H?(l.beginPath(),l.arc(m+3,v-1,2,0,Math.PI*2),l.fill(),l.beginPath(),l.moveTo(m+1,v+4),l.lineTo(m+5,v+4),l.stroke()):(l.beginPath(),l.arc(m-3,v-1,1.5,0,Math.PI*2),l.fill(),l.beginPath(),l.arc(m+3,v-1,1.5,0,Math.PI*2),l.fill(),l.lineWidth=1.5,l.beginPath(),l.arc(m,v+3,3,.2*Math.PI,.8*Math.PI),l.stroke(),l.lineWidth=3);l.beginPath(),l.moveTo(m,O),l.lineTo(m,C),l.stroke();const E=(Z,ue,me,Re,Se,_e)=>{const Ee=Z+Math.sin(me)*Re*(_e?-1:1),ae=ue+Math.cos(me)*Re,Te=me+(_e?-1.2:1.2),le=Ee+Math.sin(Te)*Se*(_e?-1:1),we=ae+Math.cos(Te)*Se;l.beginPath(),l.moveTo(Z,ue),l.lineTo(Ee,ae),l.lineTo(le,we),l.stroke()},w=O+3,b=C,I=Math.sin(z*Math.PI),_=6,x=6;if(H){const Z=I*.8;E(m,w,-Z*.6,_,x,!0),E(m,w,Z*.6,_,x,!1)}else E(m,w,.2,_,x,!0),E(m,w,.2,_,x,!1);const T=H?Math.sin(z*Math.PI)*8:0;l.beginPath(),l.moveTo(m,b),l.lineTo(m-4+T,b+g),l.stroke(),l.beginPath(),l.moveTo(m,b),l.lineTo(m+4-T,b+g),l.stroke()}if(e.playerHat&&e.playerHat!=="none"&&NS(m,v,u,e.playerHat,L),l.restore(),l.save(),l.globalAlpha=.9,e.displayName){l.shadowColor="transparent",l.fillStyle="rgba(0,0,0,0.7)",l.font='bold 11px "Comic Sans MS", "Chalkboard SE", cursive';const j=l.measureText(e.displayName).width;l.fillRect(m-j/2-5,v-u-22,j+10,16),l.fillStyle=e.playerColor||"#fff",l.textAlign="center",l.textBaseline="middle",l.fillText(e.displayName,m,v-u-14)}l.restore(),He&&e.isIt&&(l.save(),l.shadowColor="#ff0000",l.shadowBlur=15,l.fillStyle="#ff0000",l.font="bold 16px sans-serif",l.textAlign="center",l.textBaseline="middle",l.fillText("IT",m,v-u-25),l.restore());const $=Date.now();He&&e.tagCooldownUntil&&e.tagCooldownUntil>$&&qy(m,d+s/2,e.tagCooldownUntil,$)}function NS(n,e,t,o,r){if(!l)return;const i=e-t;switch(o){case"cap":l.fillStyle="#ef4444",l.beginPath(),l.ellipse(n,i-2,t+2,5,0,0,Math.PI*2),l.fill(),l.fillRect(n-2,i-4,t+8,4);break;case"tophat":l.fillStyle="#1a1a1a",l.fillRect(n-12,i-2,24,4),l.fillRect(n-8,i-18,16,16),l.fillStyle=r,l.fillRect(n-8,i-6,16,3);break;case"crown":l.fillStyle="#fbbf24",l.beginPath(),l.moveTo(n-10,i),l.lineTo(n-10,i-8),l.lineTo(n-6,i-4),l.lineTo(n-3,i-12),l.lineTo(n,i-6),l.lineTo(n+3,i-12),l.lineTo(n+6,i-4),l.lineTo(n+10,i-8),l.lineTo(n+10,i),l.closePath(),l.fill(),l.fillStyle="#dc2626",l.beginPath(),l.arc(n,i-5,2,0,Math.PI*2),l.fill();break;case"beanie":l.fillStyle="#3b82f6",l.beginPath(),l.arc(n,i,t+1,Math.PI,0),l.fill(),l.fillStyle="#fff",l.beginPath(),l.arc(n,i-t-3,4,0,Math.PI*2),l.fill();break;case"party":l.fillStyle="#ec4899",l.beginPath(),l.moveTo(n,i-20),l.lineTo(n-10,i),l.lineTo(n+10,i),l.closePath(),l.fill(),l.strokeStyle="#fbbf24",l.lineWidth=2,l.beginPath(),l.moveTo(n-8,i-4),l.lineTo(n+8,i-4),l.moveTo(n-5,i-10),l.lineTo(n+5,i-10),l.stroke(),l.lineWidth=3;break}}function Za(n,e,t,o,r,i,s,c){n.save(),n.shadowColor="transparent",n.shadowBlur=0,n.shadowOffsetX=0,n.shadowOffsetY=0,n.fillStyle=jc,n.beginPath(),n.arc(e,t,o-1,0,Math.PI*2),n.fill();const d=uS(jc,.2);n.strokeStyle=d,n.lineWidth=1,n.beginPath(),n.arc(e,t,o-1,0,Math.PI*2),n.stroke();const u=o-3,f=r*u;let g=0,m=1;s?Math.abs(r)>.3&&(g=1):i<-2?(g=-4,m=.3):i>2&&(g=1);const v=o-4,O=f*m;n.globalCompositeOperation="destination-out",n.beginPath(),n.arc(e+O,t+g,v,0,Math.PI*2),n.fill(),n.restore()}function LS(){if(!l)return;const n=A.x,e=A.y,t=A.width,o=A.height;l.save();const r=Math.abs(A.vx)>.5;r&&!A.facingRight&&(l.translate(n+t/2,0),l.scale(-1,1),l.translate(-(n+t/2),0));const s=r?.17:0;if(s!==0){const b=n+t/2,I=e+o-5;l.translate(b,I),l.rotate(s),l.translate(-b,-I)}const c=7,d=13,u=11,f=n+t/2,g=e+c+3,m=g+c,v=m+d;if(l.strokeStyle=Kn,l.lineWidth=3,l.lineCap="round",l.lineJoin="round",l.shadowColor="rgba(0,0,0,0.3)",l.shadowBlur=4,l.shadowOffsetX=2,l.shadowOffsetY=2,yr){const b=Math.sin(A.animFrame*Math.PI*2)*3;l.fillStyle=zi,l.beginPath(),r?(l.moveTo(f,g-c-3),l.quadraticCurveTo(f-c+2,g-c-4,f-c-1,g-2),l.lineTo(f-c-2,g+4),l.quadraticCurveTo(f-c-4-b,g+8,f-c-3-b,g+12),l.quadraticCurveTo(f-c,g+11,f-c+3,g+10),l.lineTo(f-2,g+c),l.closePath(),l.fill()):(l.moveTo(f-c-2,g+8),l.lineTo(f-c-1,g-2),l.quadraticCurveTo(f-c+2,g-c-4,f,g-c-3),l.quadraticCurveTo(f+c-2,g-c-4,f+c+1,g-2),l.lineTo(f+c+2,g+8),l.quadraticCurveTo(f+c,g+10,f+c-2,g+10),l.lineTo(f-c+2,g+10),l.quadraticCurveTo(f-c,g+10,f-c-2,g+8),l.closePath(),l.fill()),l.strokeStyle="#000",l.lineWidth=.5,l.beginPath(),l.arc(f,g,c-.5,0,Math.PI*2),l.stroke(),l.fillStyle=$c,l.beginPath(),l.arc(f,g,c-1,0,Math.PI*2),l.fill(),l.fillStyle=zi,l.beginPath(),l.moveTo(f-c+2,g-2),l.quadraticCurveTo(f-2,g-c-2,f,g-c+1),l.quadraticCurveTo(f+2,g-c-2,f+c-2,g-2),l.quadraticCurveTo(f,g-1,f-c+2,g-2),l.closePath(),l.fill(),ys==="smudgy"?Za(l,f,g,c,_n,A.vy,A.onGround):(l.fillStyle=Kn,r?(l.beginPath(),l.arc(f+2,g,1.5,0,Math.PI*2),l.fill(),l.lineWidth=2,l.beginPath(),l.moveTo(f,g+4),l.lineTo(f+4,g+4),l.stroke(),l.lineWidth=3):(l.beginPath(),l.arc(f-3,g,1.5,0,Math.PI*2),l.fill(),l.beginPath(),l.arc(f+3,g,1.5,0,Math.PI*2),l.fill(),l.lineWidth=1.5,l.beginPath(),l.arc(f,g+3,2.5,.2*Math.PI,.8*Math.PI),l.stroke(),l.lineWidth=3))}else{const b=g-c;if(ys==="smudgy"){l.lineCap="round";const I=Math.sin(A.animFrame*Math.PI*2)*2,_=x=>{l.strokeStyle="#fff",l.lineWidth=3.1,x(),l.stroke(),l.strokeStyle="#000",l.lineWidth=2.8,x(),l.stroke(),l.strokeStyle=zi,l.lineWidth=2.5,x(),l.stroke()};r?(_(()=>{l.beginPath(),l.moveTo(f+2,b+1),l.bezierCurveTo(f+1,b-8,f-3,b-9,f-6+I*.5,b-7)}),_(()=>{l.beginPath(),l.moveTo(f-2,b+1),l.bezierCurveTo(f-2,b-5,f-4,b-6,f-7+I*.4,b-4)})):(_(()=>{l.beginPath(),l.moveTo(f+1,b+1),l.quadraticCurveTo(f+1,b-5,f,b-9)}),_(()=>{l.beginPath(),l.moveTo(f-2,b+2),l.quadraticCurveTo(f-2,b-2,f-2,b-5)})),Za(l,f,g,c,_n,A.vy,A.onGround),l.strokeStyle=$c,l.lineWidth=2,l.beginPath(),l.arc(f,g,c,0,Math.PI*2),l.stroke()}else l.beginPath(),l.arc(f,g,c,0,Math.PI*2),l.stroke(),l.fillStyle=zi,l.beginPath(),l.moveTo(f-6,g-c+1),l.lineTo(f-3,g-c-4),l.lineTo(f+8,g-c+3),l.quadraticCurveTo(f,g-c-1,f-6,g-c+1),l.closePath(),l.fill(),l.stroke(),l.fillStyle=Kn,r?(l.beginPath(),l.arc(f+3,g-1,2,0,Math.PI*2),l.fill(),l.beginPath(),l.moveTo(f+1,g+4),l.lineTo(f+5,g+4),l.stroke()):(l.beginPath(),l.arc(f-3,g-1,1.5,0,Math.PI*2),l.fill(),l.beginPath(),l.arc(f+3,g-1,1.5,0,Math.PI*2),l.fill(),l.beginPath(),l.arc(f,g+3,3,.1*Math.PI,.9*Math.PI),l.stroke());l.strokeStyle="#fff",l.lineWidth=3.6,l.beginPath(),l.moveTo(f,m),l.lineTo(f,v),l.stroke(),l.strokeStyle="#000",l.lineWidth=3.3,l.beginPath(),l.moveTo(f,m),l.lineTo(f,v),l.stroke(),l.strokeStyle=Kn,l.lineWidth=3,l.beginPath(),l.moveTo(f,m),l.lineTo(f,v),l.stroke()}const O=Math.sin(A.animFrame*Math.PI),C=Math.abs(A.vx)>.5,L=C||Ki<dp,H=(b,I,_,x,T,Z)=>{const ue=_,me=b+Math.sin(ue)*x*(Z?-1:1),Re=I+Math.cos(ue)*x,Se=ue+(Z?-1.2:1.2),_e=me+Math.sin(Se)*T*(Z?-1:1),Ee=Re+Math.cos(Se)*T;l.strokeStyle="#fff",l.lineWidth=3.6,l.beginPath(),l.moveTo(b,I),l.lineTo(me,Re),l.lineTo(_e,Ee),l.stroke(),l.strokeStyle="#000",l.lineWidth=3.3,l.beginPath(),l.moveTo(b,I),l.lineTo(me,Re),l.lineTo(_e,Ee),l.stroke(),l.strokeStyle=Kn,l.lineWidth=3,l.beginPath(),l.moveTo(b,I),l.lineTo(me,Re),l.lineTo(_e,Ee),l.stroke()},z=m+4,N=v,$=6,j=6;if(bn){const b=Math.sin(Ea*4)*.4;H(f,z,-1.5+b,$,j,!0),H(f,z,.3,$,j,!1)}else if(L){const b=C?O*1.2:O*1.2*(1-Ki/dp);H(f,z,-b,$,j,!0),H(f,z,b,$,j,!1)}else{const b=Math.sin(Fo*2)*.5+.5,I=_=>{if(!(_.length<2)){l.strokeStyle="#fff",l.lineWidth=3.6,l.beginPath(),l.moveTo(_[0].x,_[0].y);for(let x=1;x<_.length;x++)l.lineTo(_[x].x,_[x].y);l.stroke(),l.strokeStyle="#000",l.lineWidth=3.3,l.beginPath(),l.moveTo(_[0].x,_[0].y);for(let x=1;x<_.length;x++)l.lineTo(_[x].x,_[x].y);l.stroke(),l.strokeStyle=Kn,l.lineWidth=3,l.beginPath(),l.moveTo(_[0].x,_[0].y);for(let x=1;x<_.length;x++)l.lineTo(_[x].x,_[x].y);l.stroke()}};if(xn==="headScratch"){const _=g-c+b*3;I([{x:f,y:z},{x:f+4,y:z-4},{x:f+2,y:_}]),I([{x:f,y:z},{x:f-6,y:z+6},{x:f-4,y:z+12}])}else if(xn==="buttScratch"){const _=f-3+b*2;I([{x:f,y:z},{x:f+2,y:z+8},{x:_,y:v+2}]),I([{x:f,y:z},{x:f-6,y:z+6},{x:f-4,y:z+12}])}else if(xn==="weightShift"){const _=Math.sin(Fo)*2;if(yr)I([{x:f,y:z},{x:f-u+_,y:z+2}]),I([{x:f,y:z},{x:f+u+_,y:z+2}]);else{const x=v-2;I([{x:f,y:z},{x:f-7+_,y:z+5},{x:f-4,y:x}]),I([{x:f,y:z},{x:f+7+_,y:z+5},{x:f+4,y:x}])}}else if(yr)I([{x:f,y:z},{x:f-u,y:z+2}]),I([{x:f,y:z},{x:f+u,y:z+2}]);else{const _=v-2,x=7,T=z+5,Z=4;I([{x:f,y:z},{x:f-x,y:T},{x:f-Z,y:_}]),I([{x:f,y:z},{x:f+x,y:T},{x:f+Z,y:_}])}}const D=(b,I,_,x)=>{l.strokeStyle="#fff",l.lineWidth=3.6,l.beginPath(),l.moveTo(b,I),l.lineTo(_,x),l.stroke(),l.strokeStyle="#000",l.lineWidth=3.3,l.beginPath(),l.moveTo(b,I),l.lineTo(_,x),l.stroke(),l.strokeStyle=Kn,l.lineWidth=3,l.beginPath(),l.moveTo(b,I),l.lineTo(_,x),l.stroke()},E=C?Math.sin(A.animFrame*Math.PI)*8:0;if(!A.onGround&&A.vy<0)D(f,N,f-3,N+u*.7),D(f,N,f+3,N+u*.7);else if(!A.onGround)D(f,N,f-7,N+u),D(f,N,f+7,N+u);else if(C)D(f,N,f-4+E,N+u),D(f,N,f+4-E,N+u);else if(xn==="weightShift"){const b=Math.sin(Fo)*2;D(f,N,f-4+b,N+u),D(f,N,f+5+b*.5,N+u-2)}else D(f,N,f-4,N+u),D(f,N,f+4,N+u);yr&&(l.fillStyle=ky,l.beginPath(),l.moveTo(f,m),l.lineTo(f-10,v+5),l.lineTo(f+10,v+5),l.closePath(),l.fill()),DS(f,g,c),l.restore(),He&&jr()&&(l.save(),l.shadowColor="#ff0000",l.shadowBlur=15,l.fillStyle="#ff0000",l.font="bold 16px sans-serif",l.textAlign="center",l.textBaseline="middle",l.fillText("IT",f,g-c-20),l.restore());const w=Date.now();He&&Rn>w&&qy(f,A.y+A.height/2,Rn,w)}function qy(n,e,t,o){if(!l)return;const r=t-o;if(r<=0)return;const i=6,s=Qa/i,c=Math.ceil(r/s),d=35,u=Math.PI*2/i;l.save();for(let f=0;f<c;f++){const g=-Math.PI/2+f*u,m=g+u-.05;l.fillStyle="rgba(0, 200, 255, 0.3)",l.strokeStyle="rgba(0, 200, 255, 0.7)",l.lineWidth=2,l.beginPath(),l.moveTo(n,e),l.arc(n,e,d,g,m),l.closePath(),l.fill(),l.stroke()}l.strokeStyle="rgba(0, 200, 255, 0.5)",l.lineWidth=3,l.beginPath(),l.arc(n,e,d,0,Math.PI*2),l.stroke(),l.restore()}function DS(n,e,t){l&&(l.shadowBlur=0,gs!=="none"&&VS(n,e,t),ms!=="none"&&FS(n,e,t))}function VS(n,e,t){if(!l)return;const o=e-t;switch(gs){case"cap":l.fillStyle="#ef4444",l.beginPath(),l.ellipse(n,o-2,t+2,5,0,0,Math.PI*2),l.fill(),l.fillRect(n-2,o-4,t+8,4);break;case"tophat":l.fillStyle="#1a1a1a",l.fillRect(n-7,o-18,14,16),l.fillRect(n-12,o-2,24,4);break;case"crown":l.fillStyle="#fbbf24",l.beginPath(),l.moveTo(n-10,o),l.lineTo(n-10,o-8),l.lineTo(n-6,o-4),l.lineTo(n-3,o-12),l.lineTo(n,o-6),l.lineTo(n+3,o-12),l.lineTo(n+6,o-4),l.lineTo(n+10,o-8),l.lineTo(n+10,o),l.closePath(),l.fill(),l.fillStyle="#dc2626",l.beginPath(),l.arc(n,o-5,2,0,Math.PI*2),l.fill();break;case"beanie":l.fillStyle="#3b82f6",l.beginPath(),l.arc(n,o,t+1,Math.PI,0),l.fill(),l.fillStyle="#fff",l.beginPath(),l.arc(n,o-t-3,4,0,Math.PI*2),l.fill();break;case"party":l.fillStyle="#ec4899",l.beginPath(),l.moveTo(n,o-20),l.lineTo(n-10,o),l.lineTo(n+10,o),l.closePath(),l.fill(),l.strokeStyle="#fbbf24",l.lineWidth=2,l.beginPath(),l.moveTo(n-8,o-4),l.lineTo(n+8,o-4),l.moveTo(n-5,o-10),l.lineTo(n+5,o-10),l.stroke(),l.lineWidth=3;break}}function FS(n,e,t){if(l)switch(ms){case"glasses":l.strokeStyle="#333",l.lineWidth=1.5,l.beginPath(),l.arc(n-4,e-1,4,0,Math.PI*2),l.arc(n+4,e-1,4,0,Math.PI*2),l.stroke(),l.beginPath(),l.moveTo(n-1,e-1),l.lineTo(n+1,e-1),l.stroke(),l.lineWidth=3;break;case"sunglasses":l.fillStyle="#1a1a1a",l.fillRect(n-9,e-3,7,5),l.fillRect(n+2,e-3,7,5),l.fillRect(n-2,e-2,4,2);break;case"mustache":l.fillStyle="#4a3728",l.beginPath(),l.moveTo(n-8,e+3),l.quadraticCurveTo(n-4,e+6,n,e+4),l.quadraticCurveTo(n+4,e+6,n+8,e+3),l.quadraticCurveTo(n+4,e+4,n,e+3),l.quadraticCurveTo(n-4,e+4,n-8,e+3),l.fill();break;case"beard":l.fillStyle="#4a3728",l.beginPath(),l.moveTo(n-t+2,e+2),l.quadraticCurveTo(n-t,e+10,n,e+14),l.quadraticCurveTo(n+t,e+10,n+t-2,e+2),l.quadraticCurveTo(n,e+6,n-t+2,e+2),l.fill();break;case"mask":l.fillStyle="#1a1a1a",l.beginPath(),l.ellipse(n,e-1,t-1,4,0,0,Math.PI*2),l.fill(),l.fillStyle="#fff",l.beginPath(),l.ellipse(n-4,e-1,2.5,2,0,0,Math.PI*2),l.ellipse(n+4,e-1,2.5,2,0,0,Math.PI*2),l.fill();break}}function US(){if(!l)return;const n=window.scrollX,e=window.scrollY,o=performance.now()<Oy;if(l.save(),o){const r=Tt==="race"?260:180;l.fillStyle="rgba(0,0,0,0.8)",l.fillRect(n+10,e+10,r,70);let i="EXPLORE MODE",s="#22c55e";He?(i="TAG MODE",s="#f97316"):Tt==="race"&&(i="RACE MODE",s="#ef4444"),l.fillStyle=s,l.font="bold 11px sans-serif",l.fillText(i,n+20,e+25)}if(Tt==="race"){o||(l.fillStyle="rgba(0,0,0,0.7)",l.fillRect(n+10,e+10,250,50));const r=(ni/1e3).toFixed(2);l.fillStyle="#fff",l.font="bold 20px monospace";const i=On?"Ready...":_t?`${r}s`:uo<=0?"GAME OVER":`${r}s`;l.fillText(i,n+20,e+(o?48:38));const s=o?48:38;l.font="14px sans-serif",l.fillStyle="#888",l.fillText("Lives:",n+155,e+s);for(let c=0;c<Td;c++){const d=n+200+c*20,u=e+(o?40:30);c<uo?(l.strokeStyle="#22c55e",l.lineWidth=2,l.beginPath(),l.arc(d,u-6,4,0,Math.PI*2),l.stroke(),l.beginPath(),l.moveTo(d,u-2),l.lineTo(d,u+6),l.stroke(),l.beginPath(),l.moveTo(d-4,u+1),l.lineTo(d+4,u+1),l.stroke(),l.beginPath(),l.moveTo(d,u+6),l.lineTo(d-3,u+12),l.moveTo(d,u+6),l.lineTo(d+3,u+12),l.stroke()):(l.strokeStyle="#ef4444",l.lineWidth=2,l.beginPath(),l.moveTo(d-5,u-8),l.lineTo(d+5,u+8),l.moveTo(d+5,u-8),l.lineTo(d-5,u+8),l.stroke())}o&&ve.bestTime&&(l.fillStyle="#fbbf24",l.font="12px monospace",l.fillText(`Best: ${(ve.bestTime/1e3).toFixed(2)}s`,n+20,e+66)),uo<=0&&(l.fillStyle="#ef4444",l.font="bold 14px sans-serif",l.fillText("GAME OVER - Press Play to retry",n+20,e+(o?100:70)))}else if(He){o||(l.fillStyle="rgba(0,0,0,0.7)",l.fillRect(n+10,e+10,200,30));const r=jr(),i=o?48:32;if(r)l.fillStyle="#ff4444",l.font="bold 16px sans-serif",l.fillText("You're IT! Tag someone!",n+20,e+i);else{let s="",c=!1;if(gt!=null&&gt.itPlayerId){c=!0;for(const[d,u]of Bt)if(d===gt.itPlayerId){s=u.displayName||"Another player";break}}if(!s){for(const[,d]of Bt)if(d.isIt){s=d.displayName||"Another player",c=!0;break}}!c&&Me&&(c=!0),s?(l.fillStyle="#22c55e",l.font="bold 16px sans-serif",l.fillText("Run! "+s+" is IT!",n+20,e+i)):c?(l.fillStyle="#22c55e",l.font="bold 16px sans-serif",l.fillText("Run! Someone is IT!",n+20,e+i)):(l.fillStyle="#fff",l.font="16px sans-serif",l.fillText("Waiting for IT player...",n+20,e+i))}o&&(l.fillStyle="#888",l.font="12px sans-serif",l.fillText("Touch another player to tag them",n+20,e+66))}else o&&(l.fillStyle="#fff",l.font="16px sans-serif",l.fillText("Explore freely!",n+20,e+48),l.fillStyle="#888",l.font="12px sans-serif",l.fillText("No timer, unlimited respawns",n+20,e+66));if(o&&(l.fillStyle="#666",l.font="11px sans-serif",l.fillText("WASD/Arrows, Space=jump, L=leaderboard",n+10,e+95)),qS(),zS(),BS(),On&&J){const r=performance.now()-Id,s=Ny-r>1e3?"2":"1";J.fillStyle="rgba(0, 0, 0, 0.5)",J.fillRect(n,e,window.innerWidth,window.innerHeight),J.fillStyle="#fff",J.font="bold 120px sans-serif",J.textAlign="center",J.textBaseline="middle",J.fillText(s,n+window.innerWidth/2,e+window.innerHeight/2),J.textBaseline="alphabetic",J.textAlign="left"}l.restore()}function qS(){if(!J||!De)return;const n=window.scrollX,e=window.scrollY,t=200,o=De.subtext?60:40,r=n+20,i=e+window.innerHeight-o-20;J.fillStyle="rgba(0, 0, 0, 0.9)",J.fillRect(r,i,t,o),J.strokeStyle=De.text==="GO!"?"#22c55e":De.text==="GAME OVER"?"#ef4444":De.text==="You fell!"?"#f59e0b":"#3b82f6",J.lineWidth=2,J.strokeRect(r,i,t,o),J.fillStyle="#fff",J.font="bold 16px sans-serif",J.textAlign="center";const s=De.subtext?i+22:i+26;J.fillText(De.text,r+t/2,s),De.subtext&&(J.fillStyle="#888",J.font="13px sans-serif",J.fillText(De.subtext,r+t/2,i+44)),J.textAlign="left"}function zS(){if(!J||!wn)return;const n=performance.now();if(n>wn.endTime){wn=null;return}const e=window.scrollX,t=window.scrollY,o=e+window.innerWidth/2,r=t+window.innerHeight/2,i=wn.endTime-wn.startTime,c=(n-wn.startTime)/i;let d=1;c<.1?d=c/.1:c>.8&&(d=(1-c)/.2),J.save(),J.globalAlpha=d,J.font="bold 36px sans-serif",J.textAlign="center",J.textBaseline="middle",J.fillStyle="rgba(0, 0, 0, 0.5)",J.fillText(wn.text,o+2,r+2),J.fillStyle="#ffffff",J.fillText(wn.text,o,r),J.restore()}function BS(){if(!J||performance.now()>Hc)return;const n=window.scrollX,e=window.scrollY,t=window.innerWidth,o=window.innerHeight,i=(Hc-performance.now())/Ry,s=Math.min(.7,i*.9);J.save(),J.fillStyle=`rgba(220, 38, 38, ${s*.3})`,J.fillRect(n,e,t,o);const c=Math.min(1,i*1.5);J.font="bold 72px sans-serif",J.textAlign="center",J.textBaseline="middle",J.shadowColor="#ff0000",J.shadowBlur=30,J.fillStyle=`rgba(255, 255, 255, ${c})`,J.fillText("NO TAG BACKS",n+t/2,e+o/2),J.shadowBlur=15,J.fillText("NO TAG BACKS",n+t/2,e+o/2),J.restore()}function $S(){if(!l)return;const n=window.scrollX,e=window.scrollY;l.save(),l.fillStyle="rgba(0,0,0,0.8)",l.fillRect(n+10,e+10,200,35),l.fillStyle="#22c55e",l.font="bold 14px sans-serif",l.fillText("BUILD MODE",n+20,e+32),l.fillStyle="#888",l.font="12px sans-serif";const t=ps.charAt(0).toUpperCase()+ps.slice(1);l.fillText(`Tool: ${t}`,n+115,e+32),l.restore()}function jS(n){var o;if(Ue!=="play"||Or)return;let e=document.activeElement;for(;(o=e==null?void 0:e.shadowRoot)!=null&&o.activeElement;)e=e.shadowRoot.activeElement;if(!(e&&(e.tagName==="INPUT"||e.tagName==="TEXTAREA"||e.isContentEditable))){if(Ft[n.code]=!0,n.code==="Tab"||n.code==="KeyL"){n.preventDefault(),nt();return}["ArrowUp","ArrowDown","ArrowLeft","ArrowRight","Space"].includes(n.code)&&n.preventDefault()}}function WS(n){Ft[n.code]=!1}let Mr=null;function HS(n,e){for(const t of ve.checkpoints)if(t.width&&t.height){const o=t.x-t.width/2,r=t.x+t.width/2,i=t.y-t.height,s=t.y;if(n>=o&&n<=r&&e>=i&&e<=s)return t}else if(Math.hypot(n-t.x,e-t.y)<40)return t;return null}function GS(n){if(Ue!=="build")return;const e=n.pageX,t=n.pageY,o=HS(e,t);if(o){if(n.button===2||n.shiftKey){ve.checkpoints=ve.checkpoints.filter(c=>c.id!==o.id),Hr(),nt();return}Mr=o,Oe&&(Oe.style.cursor="grabbing");return}if(ps==="select")return;const r=ps;(r==="start"||r==="finish"||r==="spawn")&&(ve.checkpoints=ve.checkpoints.filter(c=>c.type!==r));const i=r==="start"?0:r==="finish"?999:r==="spawn"?-1:r==="checkpoint"?ve.checkpoints.filter(c=>c.type==="checkpoint").length+1:0,s={id:zy(),type:r,x:e,y:t,order:i,reached:!1};r==="trampoline"||r==="speedBoost"||r==="highJump"?(s.width=60,s.height=20):r==="spike"&&(s.width=60,s.height=30),ve.checkpoints.push(s),Hr(),nt()}function YS(n){Ue==="build"&&Mr&&(Mr.x=n.pageX,Mr.y=n.pageY,nt())}function KS(n){Mr&&(Hr(),Mr=null,Oe&&(Oe.style.cursor="crosshair"))}function zy(){return Math.random().toString(36).substr(2,9)}async function Hr(){const n=Fn();localStorage.setItem(`oo_course_${n}`,JSON.stringify(ve)),ja()&&await zI(n,ve),console.log("[OpenOverlay] Course saved")}function XS(){const n=Fn();or()&&BI(n,t=>{t.myCourse&&(ve=t.myCourse,ve.checkpoints.forEach(o=>o.reached=!1),localStorage.setItem(`oo_course_${n}`,JSON.stringify(ve))),Wr=t.otherCourses.map(o=>({...o,checkpoints:(o.checkpoints||[]).map(r=>({...r,reached:!1}))})),console.log("[OpenOverlay] Course sync: mine=",ve.checkpoints.length,"elements, others=",Wr.length,"courses"),yp(),Ue!=="none"&&nt()});const e=localStorage.getItem(`oo_course_${n}`);if(e)try{ve=JSON.parse(e),ve.checkpoints.forEach(t=>t.reached=!1),console.log("[OpenOverlay] Course loaded from localStorage:",ve.checkpoints.length,"checkpoints"),yp()}catch{console.warn("[OpenOverlay] Failed to load course")}}function Fn(){return btoa(window.location.href).slice(0,32)}function By(){return`oo_scores_${Fn()}`}function QS(){const n=new Date;return new Date(n.getFullYear(),n.getMonth(),n.getDate()).getTime()}function $y(){const n=localStorage.getItem(By());if(!n)return[];try{const e=JSON.parse(n),t=QS();return e.filter(o=>o.timestamp>=t)}catch{return[]}}function la(n,e){const t=$y();t.push({name:n,time:e,timestamp:Date.now()}),t.sort((o,r)=>o.time-r.time),localStorage.setItem(By(),JSON.stringify(t)),localStorage.setItem("oo_player_name",n),Ji=n}function JS(){const n=$y(),e=n.slice(0,10);let t=null,o=-1;if(Ji){const r=n.filter(i=>i.name===Ji);r.length>0&&(t=r[0],o=n.findIndex(i=>i.name===Ji&&i.time===t.time)+1)}return{top10:e,playerBest:t,playerRank:o}}function ZS(){if(console.log("[OpenOverlay] toggleTagMode called, current isTagMode:",He),He)He=!1,Gc(),Me=!1,Tn=null,no=null,$o=0,console.log("[OpenOverlay] Left tag mode"),document.dispatchEvent(new CustomEvent("oo:tagstatechange",{detail:{isTagMode:!1,isIt:!1,gameActive:!1}})),Ht("Left tag game","",1500);else{He=!0,Gc();const n=Fn();console.log("[OpenOverlay] Starting/joining tag game on page:",n);let e=!1;for(const[,t]of Bt)if(t.isIt){e=!0;break}Me=!e,console.log("[OpenOverlay] localIsIt:",Me,"someoneElseIsIt:",e),document.dispatchEvent(new CustomEvent("oo:tagstatechange",{detail:{isTagMode:!0,isIt:Me,gameActive:!0}})),vs(),console.log("[OpenOverlay] Forced sync with isIt:",Me),Me?Ht("You're IT!","Tag another player!",2e3):Ht("Tag Mode!","Avoid being tagged!",2e3),FI(n).then(t=>{console.log("[OpenOverlay] startTagGame returned:",t),t&&!Me&&(Me=!0,document.dispatchEvent(new CustomEvent("oo:tagstatechange",{detail:{isTagMode:!0,isIt:!0,gameActive:!0}})))}).catch(t=>{console.log("[OpenOverlay] Firebase unavailable, using local tag state:",Me)})}}function eA(n){const e=Os();if(!e)return;const t=e.querySelector(".fab");t&&(t.style.background="",t.style.boxShadow="",t.style.transform="")}function tA(n){const e=Os();if(!e)return;const t=e.querySelectorAll(".mini");t.forEach(o=>{o.classList.remove("active"),o.style.background="",o.style.boxShadow="",o.style.transform=""}),t[n]&&(t[n].classList.add("active"),t[n].style.background="#22c55e",t[n].style.boxShadow="0 0 15px #22c55e, 0 0 30px #22c55e",t[n].style.transform="scale(1.15)")}function jy(){const n=Os();if(!n)return;n.querySelectorAll(".mini").forEach(t=>{t.classList.remove("active"),t.style.background="",t.style.boxShadow="",t.style.transform=""}),eA(),qc(!1)}const eu="oo_onboarding_complete",tu="oo_onboarding_skipped",nu="oo_onboarding_reminder_month";let ou=!1,xd=!1,Sd=!1,Ad="";async function nA(){try{const n=await chrome.storage.local.get([eu,tu,nu]);xd=n[eu]===!0,Sd=n[tu]===!0,Ad=n[nu]||"",ou=!0}catch(n){console.error("[Smudgy] Failed to load onboarding state:",n),ou=!0}}function Wy(){xd=!0,chrome.storage.local.set({[eu]:!0}).catch(console.error)}function oA(){Sd=!0,chrome.storage.local.set({[tu]:!0}).catch(console.error)}function rA(n){Ad=n,chrome.storage.local.set({[nu]:n}).catch(console.error)}const iA=5,sA=.6,lc=-12,aA=100,ru=2500,xl="#ff69b4",lA="#d45a9d",kt="#ffffff",cc="#000000";let V={step:0,smudgyX:-50,smudgyY:0,smudgyVx:0,smudgyVy:0,onGround:!0,facingRight:!0,animFrame:0,speechBubble:null,speechTimer:0,isComplete:!1,isSkipped:!1,stepTimer:0,eyeLookDirection:1},Ct=null,R=null,At=null,iu=0,el=0,Oi=[],kd=1,su=!1,qt=null;function cA(){if(!ou)return!1;if(!xd&&!Sd)return!0;const n=new Date;if(n.getDate()!==10||ce())return!1;const o=`${n.getFullYear()}-${String(n.getMonth()+1).padStart(2,"0")}`;return Ad===o?!1:(rA(o),!0)}function uA(){console.log("[Smudgy] Starting onboarding..."),el=window.innerHeight-aA,V={step:0,smudgyX:window.innerWidth/2,smudgyY:-50,smudgyVx:0,smudgyVy:2,onGround:!1,facingRight:!0,animFrame:0,speechBubble:null,speechTimer:0,drawnLine:[],isComplete:!1,isSkipped:!1,stepTimer:0,eyeLookDirection:0},En=[],$i=0,Jt=[],kd=1,su=!1,qt&&(qt.remove(),qt=null),dA(),hA();const n=()=>{V.step>0&&!V.isComplete&&!V.isSkipped&&(console.log("[Smudgy] Menu closed - onboarding complete!"),Wy(),Cd(),window.removeEventListener("oo:menuClosed",n))};window.addEventListener("oo:menuClosed",n),iu=performance.now(),requestAnimationFrame(Hy)}function dA(){Ct=document.createElement("canvas"),Ct.id="smudgy-onboarding-canvas",Ct.style.cssText=`
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    pointer-events: none;
    z-index: 2147483648;
  `,Ct.width=window.innerWidth,Ct.height=window.innerHeight,document.body.appendChild(Ct),R=Ct.getContext("2d")}function hA(){At=document.createElement("div"),At.id="smudgy-skip",At.textContent="skip intro",At.style.cssText=`
    position: fixed;
    top: 20px;
    right: 20px;
    padding: 8px 16px;
    background: rgba(0, 0, 0, 0.5);
    color: white;
    font-family: sans-serif;
    font-size: 12px;
    border-radius: 20px;
    cursor: pointer;
    z-index: 2147483649;
    opacity: 0.7;
    transition: opacity 0.2s;
  `,At.addEventListener("mouseenter",()=>{At.style.opacity="1"}),At.addEventListener("mouseleave",()=>{At.style.opacity="0.7"}),At.addEventListener("click",()=>{V.isSkipped=!0,oA(),Cd()}),document.body.appendChild(At)}function Cd(){Ct&&(Ct.remove(),Ct=null,R=null),At&&(At.remove(),At=null),jy(),V.isComplete=!0,rS(),document.dispatchEvent(new CustomEvent("oo:gamemode",{detail:{mode:"none"}})),pA()}function fA(){qt=document.createElement("div"),qt.style.cssText=`
    position: fixed;
    top: 30%;
    left: 50%;
    transform: translateX(-50%);
    background: linear-gradient(135deg, #ff69b4, #d45a9d);
    color: white;
    padding: 16px 32px;
    border-radius: 12px;
    font-family: "Comic Sans MS", "Chalkboard SE", cursive;
    font-size: 20px;
    font-weight: bold;
    z-index: 2147483647;
    box-shadow: 0 8px 32px rgba(0,0,0,0.3);
    text-align: center;
    animation: popIn 0.3s ease;
  `,qt.innerHTML=`
    <div>Demo over in <span id="countdown-num">3</span>...</div>
    <div style="font-size: 13px; margin-top: 6px; opacity: 0.9;">Your turn next!</div>
  `,document.body.appendChild(qt);const n=qt.querySelector("#countdown-num");setTimeout(()=>{n&&(n.textContent="2")},1e3),setTimeout(()=>{n&&(n.textContent="1")},2e3)}function pA(){qt&&(qt.remove(),qt=null);const n=document.createElement("div");n.style.cssText=`
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: linear-gradient(135deg, #ff69b4, #d45a9d);
    color: white;
    padding: 20px 40px;
    border-radius: 16px;
    font-family: "Comic Sans MS", "Chalkboard SE", cursive;
    font-size: 24px;
    font-weight: bold;
    z-index: 2147483647;
    box-shadow: 0 8px 32px rgba(0,0,0,0.3);
    text-align: center;
    animation: popIn 0.3s ease;
  `,n.innerHTML=`
    <div>Your turn!</div>
    <div style="font-size: 14px; margin-top: 8px; opacity: 0.9;">✏️ Pencil to draw &nbsp;|&nbsp; 🏃 Pink button to run</div>
  `,document.body.appendChild(n);const e=document.createElement("style");e.textContent=`
    @keyframes popIn {
      0% { transform: translate(-50%, -50%) scale(0.5); opacity: 0; }
      100% { transform: translate(-50%, -50%) scale(1); opacity: 1; }
    }
  `,document.head.appendChild(e),setTimeout(()=>{n.style.transition="opacity 0.5s, transform 0.5s",n.style.opacity="0",n.style.transform="translate(-50%, -50%) scale(0.9)",setTimeout(()=>{n.remove(),e.remove()},500)},2500)}function Hy(n){if(V.isComplete||V.isSkipped)return;const e=Math.min((n-iu)/16.67,3);iu=n,gA(e),vA(e),bA(),!V.isComplete&&!V.isSkipped&&requestAnimationFrame(Hy)}function gA(n){V.onGround||(V.smudgyVy+=sA*n),V.smudgyX+=V.smudgyVx*n,V.smudgyY+=V.smudgyVy*n,V.step<=2&&V.smudgyY>=el&&(V.smudgyY=el,V.smudgyVy=0,V.onGround=!0),V.smudgyVx>.5?V.facingRight=!0:V.smudgyVx<-.5&&(V.facingRight=!1),Math.abs(V.smudgyVx)>.5?V.eyeLookDirection=1:(Math.abs(V.eyeLookDirection)===1&&(V.eyeLookDirection=V.facingRight?1:-1),Math.abs(V.eyeLookDirection)>.1?V.eyeLookDirection*=.98:V.eyeLookDirection=0),Math.abs(V.smudgyVx)>.5?V.animFrame=(V.animFrame+.2*n)%4:V.animFrame=0,Math.abs(V.smudgyVx)>2?(Oi.unshift({x:V.smudgyX,y:V.smudgyY-25}),Oi.length>8&&Oi.pop()):Oi.length>0&&Oi.pop(),V.speechTimer>0&&(V.speechTimer-=n*16.67,V.speechTimer<=0&&(V.speechBubble=null))}function ca(n){V.speechBubble=n,V.speechTimer=ru}function mA(){const n=Os();if(!n)return{x:window.innerWidth-40,y:window.innerHeight-40};const e=n.querySelector(".fab");if(!e)return{x:window.innerWidth-40,y:window.innerHeight-40};const t=e.getBoundingClientRect();return{x:t.left+t.width/2,y:t.top+t.height/2}}function yA(n){const e=Os();if(!e)return{x:window.innerWidth-40,y:window.innerHeight-100-n*50};const t=e.querySelectorAll(".mini");if(!t[n])return{x:window.innerWidth-40,y:window.innerHeight-100-n*50};const o=t[n].getBoundingClientRect();return{x:o.left+o.width/2,y:o.top+o.height/2}}let En=[],$i=0,Jt=[];function vA(n){V.stepTimer+=n*16.67;const e=mA(),t=yA(0);switch(V.step){case 0:V.onGround&&V.stepTimer>500&&(V.smudgyVx=0,V.step=1,V.stepTimer=0,ca("hi! i'm smudgy!"));break;case 1:V.stepTimer>ru&&(V.step=2,V.stepTimer=0,V.smudgyVx=iA);break;case 2:V.smudgyX>=e.x-80&&(V.smudgyVx=0,Mx(),V.smudgyVy=lc*.8,V.onGround=!1,V.step=6,V.stepTimer=0);break;case 6:const o=t.x-V.smudgyX;if(Math.abs(o)>5&&(V.smudgyVx=o*.15),V.smudgyVy>0&&V.stepTimer>300){V.smudgyX=t.x,V.smudgyY=t.y-25,V.smudgyVx=0,V.smudgyVy=0,V.onGround=!0,V.step=7,V.stepTimer=0,ca("draw here!"),tA(0),Zf("draw"),$i=0,En=[],Jt=[];const C=80,L=e.x-60,H=50;for(let z=0;z<=H;z++)Jt.push({x:C+(L-C)*(z/H),y:el})}break;case 7:$i+=n*.025;const r=Math.floor(Jt.length*Math.min($i,1));En=Jt.slice(0,r+1),V.stepTimer>ru&&$i>=1&&(Jt.length>1&&oS(Jt,xl,4),Zf("none"),jy(),V.smudgyVy=lc*.5,V.onGround=!1,V.step=8,V.stepTimer=0);break;case 8:const i=Lx(),s=i?i.x:e.x,c=i?i.y:e.y,d=s-V.smudgyX;Math.abs(d)>5&&(V.smudgyVx=d*.08),V.smudgyVy>0&&V.smudgyY>=c-60&&(V.smudgyX=s,V.smudgyY=c-40,V.smudgyVx=0,V.smudgyVy=0,V.onGround=!0,V.step=9,V.stepTimer=0,qc(!0),ca("sign in for TONS more!"),console.log("[Smudgy] Landed on profile button!"));break;case 9:V.stepTimer>2e3&&(qc(!1),V.smudgyVy=lc*.5,V.onGround=!1,V.step=10,V.stepTimer=0);break;case 10:const u=Nx(),f=u?u.x:e.x,g=u?u.y:e.y-20,m=f-V.smudgyX;if(Math.abs(m)>5&&(V.smudgyVx=m*.08),V.smudgyVy>0&&V.smudgyY>=g-60){V.smudgyX=f,V.smudgyY=g-40,V.smudgyVx=0,V.smudgyVy=0,V.onGround=!0,V.step=11,V.stepTimer=0,ca("explore with me!"),console.log("[Smudgy] Landed on explore button!");const C=Jt.length>0?Jt[Math.floor(Jt.length/2)].x:window.innerWidth/2;document.dispatchEvent(new CustomEvent("oo:gamemode",{detail:{mode:"play",playmode:"explore",spawnPos:{x:C,y:-50},fromOnboarding:!0}}))}break;case 11:const v=6e3,O=3e3;if(V.stepTimer>O&&!su&&(su=!0,fA()),V.stepTimer>O){const C=(V.stepTimer-O)/(v-O);kd=Math.max(0,1-C)}V.stepTimer>v&&(Wy(),Cd());break}}function bA(){if(!(!R||!Ct)){if(R.clearRect(0,0,Ct.width,Ct.height),R.save(),R.globalAlpha=kd,En.length>1){R.save(),R.strokeStyle=xl,R.lineWidth=4,R.lineCap="round",R.lineJoin="round",R.beginPath(),R.moveTo(En[0].x,En[0].y);for(let n=1;n<En.length;n++)R.lineTo(En[n].x,En[n].y);R.stroke(),R.restore()}wA(V.smudgyX,V.smudgyY,V.facingRight,V.animFrame,V.step===1),V.speechBubble&&_A(V.smudgyX,V.smudgyY-60,V.speechBubble),R.restore()}}function wA(n,e,t,o,r){if(!R)return;R.save();const i=Math.abs(V.smudgyVx)>.5;i&&!t&&(R.translate(n,0),R.scale(-1,1),R.translate(-n,0));const s=7,c=13,d=11,u=n,f=e-38+s+3,g=f+s,m=g+c;R.strokeStyle=kt,R.lineWidth=3,R.lineCap="round",R.lineJoin="round",R.shadowColor="rgba(0,0,0,0.3)",R.shadowBlur=4,R.shadowOffsetX=2,R.shadowOffsetY=2;const v=f-s,O=Math.sin(V.animFrame*Math.PI*2)*2,C=Z=>{R.strokeStyle=kt,R.lineWidth=3.1,Z(),R.stroke(),R.strokeStyle=cc,R.lineWidth=2.8,Z(),R.stroke(),R.strokeStyle=kt,R.lineWidth=2.5,Z(),R.stroke()};R.lineCap="round",i?(C(()=>{R.beginPath(),R.moveTo(u+2,v+1),R.bezierCurveTo(u+1,v-8,u-3,v-9,u-6+O*.5,v-7)}),C(()=>{R.beginPath(),R.moveTo(u-2,v+1),R.bezierCurveTo(u-2,v-5,u-4,v-6,u-7+O*.4,v-4)})):(C(()=>{R.beginPath(),R.moveTo(u+1,v+1),R.quadraticCurveTo(u+1,v-5,u,v-9)}),C(()=>{R.beginPath(),R.moveTo(u-2,v+2),R.quadraticCurveTo(u-2,v-2,u-2,v-5)})),R.strokeStyle=kt,R.lineWidth=3,R.beginPath(),R.arc(u,f,s,0,Math.PI*2),R.stroke(),R.shadowColor="transparent",R.shadowBlur=0,R.shadowOffsetX=0,R.shadowOffsetY=0,R.fillStyle=xl,R.beginPath(),R.arc(u,f,s-1,0,Math.PI*2),R.fill(),R.strokeStyle=lA,R.lineWidth=1,R.beginPath(),R.arc(u,f,s-1,0,Math.PI*2),R.stroke();const L=s-3;let H=V.eyeLookDirection*L,z=0,N=1;V.onGround?Math.abs(V.eyeLookDirection)>.3&&(z=1):V.smudgyVy<-2?(z=-4,N=.3):V.smudgyVy>2&&(z=1);const $=s-4;R.save(),R.globalCompositeOperation="destination-out",R.beginPath(),R.arc(u+H*N,f+z,$,0,Math.PI*2),R.fill(),R.restore(),R.strokeStyle=kt,R.lineWidth=2,R.beginPath(),R.arc(u,f,s,0,Math.PI*2),R.stroke();const j=(Z,ue,me,Re)=>{R.strokeStyle=kt,R.lineWidth=3.6,R.beginPath(),R.moveTo(Z,ue),R.lineTo(me,Re),R.stroke(),R.strokeStyle=cc,R.lineWidth=3.3,R.beginPath(),R.moveTo(Z,ue),R.lineTo(me,Re),R.stroke(),R.strokeStyle=kt,R.lineWidth=3,R.beginPath(),R.moveTo(Z,ue),R.lineTo(me,Re),R.stroke()};j(u,g,u,m);const D=Math.sin(o*Math.PI),E=i,w=(Z,ue,me,Re,Se,_e)=>{const Ee=Z+Math.sin(me)*Re*(_e?-1:1),ae=ue+Math.cos(me)*Re,Te=me+(_e?-1.2:1.2),le=Ee+Math.sin(Te)*Se*(_e?-1:1),we=ae+Math.cos(Te)*Se;R.strokeStyle=kt,R.lineWidth=3.6,R.beginPath(),R.moveTo(Z,ue),R.lineTo(Ee,ae),R.lineTo(le,we),R.stroke(),R.strokeStyle=cc,R.lineWidth=3.3,R.beginPath(),R.moveTo(Z,ue),R.lineTo(Ee,ae),R.lineTo(le,we),R.stroke(),R.strokeStyle=kt,R.lineWidth=3,R.beginPath(),R.moveTo(Z,ue),R.lineTo(Ee,ae),R.lineTo(le,we),R.stroke()},b=g+4,I=m,_=6,x=6;if(r){const Z=Math.sin(o*4)*.4;w(u,b,-1.5+Z,_,x,!0),w(u,b,.3,_,x,!1)}else if(E){const Z=D*.8;w(u,b,-Z*.6,_,x,!0),w(u,b,Z*.6,_,x,!1)}else w(u,b,.1,_,x,!0),w(u,b,.1,_,x,!1);const T=E?Math.sin(o*Math.PI)*8:0;!V.onGround&&V.smudgyVy<0?(j(u,I,u-3,I+d*.7),j(u,I,u+3,I+d*.7)):V.onGround?(j(u,I,u-4+T,I+d),j(u,I,u+4-T,I+d)):(j(u,I,u-7,I+d),j(u,I,u+7,I+d)),R.restore()}function _A(n,e,t){if(!R)return;R.save();const o=12,r=14;R.font=`bold ${r}px -apple-system, BlinkMacSystemFont, sans-serif`;const s=R.measureText(t).width+o*2,c=28,d=n-s/2,u=e-c;R.fillStyle=kt,R.strokeStyle="#333",R.lineWidth=2,R.beginPath(),R.roundRect(d,u,s,c,8),R.fill(),R.stroke(),R.fillStyle=kt,R.beginPath(),R.moveTo(n-8,u+c-1),R.lineTo(n,u+c+10),R.lineTo(n+8,u+c-1),R.fill(),R.strokeStyle="#333",R.beginPath(),R.moveTo(n-8,u+c),R.lineTo(n,u+c+10),R.lineTo(n+8,u+c),R.stroke(),R.fillStyle=kt,R.fillRect(n-9,u+c-2,18,4),R.fillStyle="#333",R.textAlign="center",R.textBaseline="middle",R.fillText(t,n,u+c/2),R.restore()}function TA(){if(sessionStorage.getItem(SESSION_KEY)==="true")return;sessionStorage.setItem(SESSION_KEY,"true"),console.log("[Smudgy] Welcome back wave");const n=document.createElement("canvas");n.style.cssText=`
    position: fixed;
    bottom: 60px;
    right: 60px;
    width: 80px;
    height: 80px;
    pointer-events: none;
    z-index: 2147483645;
  `,n.width=80,n.height=80,document.body.appendChild(n);const e=n.getContext("2d");if(!e)return;let t=0;const o=()=>{t++,e.clearRect(0,0,80,80);const r=t<30?t/30:t>90?(120-t)/30:1;e.globalAlpha=r;const i=Math.sin(t*.15)*.5;e.strokeStyle=kt,e.lineWidth=2.5,e.lineCap="round",e.lineJoin="round",e.shadowColor="rgba(0,0,0,0.3)",e.shadowBlur=3,e.shadowOffsetX=1,e.shadowOffsetY=1,e.beginPath(),e.arc(40,25,8,0,Math.PI*2),e.stroke(),e.fillStyle=xl,e.beginPath(),e.arc(40,25,7,0,Math.PI*2),e.fill(),e.save(),e.globalCompositeOperation="destination-out",e.beginPath(),e.arc(40,25,4,0,Math.PI*2),e.fill(),e.restore(),e.beginPath(),e.moveTo(40,33),e.lineTo(40,48),e.stroke();const s=40-10*Math.cos(-.8+i),c=37+10*Math.sin(-.8+i);e.beginPath(),e.moveTo(40,37),e.lineTo(s,c),e.stroke(),e.beginPath(),e.moveTo(40,37),e.lineTo(48,44),e.stroke(),e.beginPath(),e.moveTo(40,48),e.lineTo(36,60),e.stroke(),e.beginPath(),e.moveTo(40,48),e.lineTo(44,60),e.stroke(),t<120?requestAnimationFrame(o):n.remove()};requestAnimationFrame(o)}if(window.__OPENOVERLAY_V2__)console.log("[OpenOverlay] Already injected, skipping");else{let n=function(){console.log("[OpenOverlay] init() called"),console.log("[OpenOverlay] document.body exists:",!!document.body);try{yI(),$I()}catch(e){console.warn("[OpenOverlay] Firebase init failed (may be incognito):",e)}try{wx(),Dx(),GI(),TS(),console.log("[OpenOverlay] Ready!"),setTimeout(async()=>{await nA(),cA()?uA():TA()},1500)}catch(e){console.error("[OpenOverlay] UI init error:",e)}};window.__OPENOVERLAY_V2__=!0,console.log("[OpenOverlay] v2.0.0 starting..."),document.body?n():document.readyState==="loading"?document.addEventListener("DOMContentLoaded",n):setTimeout(n,100)}
})()
