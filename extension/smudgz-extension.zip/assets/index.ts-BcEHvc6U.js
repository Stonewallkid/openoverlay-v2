(function(){const Um=()=>{};var eh={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Kd=function(n){const e=[];let t=0;for(let r=0;r<n.length;r++){let i=n.charCodeAt(r);i<128?e[t++]=i:i<2048?(e[t++]=i>>6|192,e[t++]=i&63|128):(i&64512)===55296&&r+1<n.length&&(n.charCodeAt(r+1)&64512)===56320?(i=65536+((i&1023)<<10)+(n.charCodeAt(++r)&1023),e[t++]=i>>18|240,e[t++]=i>>12&63|128,e[t++]=i>>6&63|128,e[t++]=i&63|128):(e[t++]=i>>12|224,e[t++]=i>>6&63|128,e[t++]=i&63|128)}return e},qm=function(n){const e=[];let t=0,r=0;for(;t<n.length;){const i=n[t++];if(i<128)e[r++]=String.fromCharCode(i);else if(i>191&&i<224){const o=n[t++];e[r++]=String.fromCharCode((i&31)<<6|o&63)}else if(i>239&&i<365){const o=n[t++],s=n[t++],l=n[t++],u=((i&7)<<18|(o&63)<<12|(s&63)<<6|l&63)-65536;e[r++]=String.fromCharCode(55296+(u>>10)),e[r++]=String.fromCharCode(56320+(u&1023))}else{const o=n[t++],s=n[t++];e[r++]=String.fromCharCode((i&15)<<12|(o&63)<<6|s&63)}}return e.join("")},Yd={byteToCharMap_:null,charToByteMap_:null,byteToCharMapWebSafe_:null,charToByteMapWebSafe_:null,ENCODED_VALS_BASE:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",get ENCODED_VALS(){return this.ENCODED_VALS_BASE+"+/="},get ENCODED_VALS_WEBSAFE(){return this.ENCODED_VALS_BASE+"-_."},HAS_NATIVE_SUPPORT:typeof atob=="function",encodeByteArray(n,e){if(!Array.isArray(n))throw Error("encodeByteArray takes an array as a parameter");this.init_();const t=e?this.byteToCharMapWebSafe_:this.byteToCharMap_,r=[];for(let i=0;i<n.length;i+=3){const o=n[i],s=i+1<n.length,l=s?n[i+1]:0,u=i+2<n.length,d=u?n[i+2]:0,p=o>>2,m=(o&3)<<4|l>>4;let g=(l&15)<<2|d>>6,b=d&63;u||(b=64,s||(g=64)),r.push(t[p],t[m],t[g],t[b])}return r.join("")},encodeString(n,e){return this.HAS_NATIVE_SUPPORT&&!e?btoa(n):this.encodeByteArray(Kd(n),e)},decodeString(n,e){return this.HAS_NATIVE_SUPPORT&&!e?atob(n):qm(this.decodeStringToByteArray(n,e))},decodeStringToByteArray(n,e){this.init_();const t=e?this.charToByteMapWebSafe_:this.charToByteMap_,r=[];for(let i=0;i<n.length;){const o=t[n.charAt(i++)],l=i<n.length?t[n.charAt(i)]:0;++i;const d=i<n.length?t[n.charAt(i)]:64;++i;const m=i<n.length?t[n.charAt(i)]:64;if(++i,o==null||l==null||d==null||m==null)throw new $m;const g=o<<2|l>>4;if(r.push(g),d!==64){const b=l<<4&240|d>>2;if(r.push(b),m!==64){const O=d<<6&192|m;r.push(O)}}}return r},init_(){if(!this.byteToCharMap_){this.byteToCharMap_={},this.charToByteMap_={},this.byteToCharMapWebSafe_={},this.charToByteMapWebSafe_={};for(let n=0;n<this.ENCODED_VALS.length;n++)this.byteToCharMap_[n]=this.ENCODED_VALS.charAt(n),this.charToByteMap_[this.byteToCharMap_[n]]=n,this.byteToCharMapWebSafe_[n]=this.ENCODED_VALS_WEBSAFE.charAt(n),this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[n]]=n,n>=this.ENCODED_VALS_BASE.length&&(this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(n)]=n,this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(n)]=n)}}};class $m extends Error{constructor(){super(...arguments),this.name="DecodeBase64StringError"}}const Bm=function(n){const e=Kd(n);return Yd.encodeByteArray(e,!0)},xs=function(n){return Bm(n).replace(/\./g,"")},Qd=function(n){try{return Yd.decodeString(n,!0)}catch(e){console.error("base64Decode failed: ",e)}return null};/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function jm(){if(typeof self<"u")return self;if(typeof window<"u")return window;if(typeof global<"u")return global;throw new Error("Unable to locate global object.")}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const zm=()=>jm().__FIREBASE_DEFAULTS__,Wm=()=>{if(typeof process>"u"||typeof eh>"u")return;const n=eh.__FIREBASE_DEFAULTS__;if(n)return JSON.parse(n)},Hm=()=>{if(typeof document>"u")return;let n;try{n=document.cookie.match(/__FIREBASE_DEFAULTS__=([^;]+)/)}catch{return}const e=n&&Qd(n[1]);return e&&JSON.parse(e)},Zs=()=>{try{return Um()||zm()||Wm()||Hm()}catch(n){console.info(`Unable to get __FIREBASE_DEFAULTS__ due to: ${n}`);return}},Jd=n=>{var e,t;return(t=(e=Zs())==null?void 0:e.emulatorHosts)==null?void 0:t[n]},Gm=n=>{const e=Jd(n);if(!e)return;const t=e.lastIndexOf(":");if(t<=0||t+1===e.length)throw new Error(`Invalid host ${e} with no separate hostname and port!`);const r=parseInt(e.substring(t+1),10);return e[0]==="["?[e.substring(1,t-1),r]:[e.substring(0,t),r]},Xd=()=>{var n;return(n=Zs())==null?void 0:n.config},Zd=n=>{var e;return(e=Zs())==null?void 0:e[`_${n}`]};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Km{constructor(){this.reject=()=>{},this.resolve=()=>{},this.promise=new Promise((e,t)=>{this.resolve=e,this.reject=t})}wrapCallback(e){return(t,r)=>{t?this.reject(t):this.resolve(r),typeof e=="function"&&(this.promise.catch(()=>{}),e.length===1?e(t):e(t,r))}}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ym(n,e){if(n.uid)throw new Error('The "uid" field is no longer supported by mockUserToken. Please use "sub" instead for Firebase Auth User ID.');const t={alg:"none",type:"JWT"},r=e||"demo-project",i=n.iat||0,o=n.sub||n.user_id;if(!o)throw new Error("mockUserToken must contain 'sub' or 'user_id' field!");const s={iss:`https://securetoken.google.com/${r}`,aud:r,iat:i,exp:i+3600,auth_time:i,sub:o,user_id:o,firebase:{sign_in_provider:"custom",identities:{}},...n};return[xs(JSON.stringify(t)),xs(JSON.stringify(s)),""].join(".")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ye(){return typeof navigator<"u"&&typeof navigator.userAgent=="string"?navigator.userAgent:""}function Qm(){return typeof window<"u"&&!!(window.cordova||window.phonegap||window.PhoneGap)&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i.test(Ye())}function Jm(){var e;const n=(e=Zs())==null?void 0:e.forceEnvironment;if(n==="node")return!0;if(n==="browser")return!1;try{return Object.prototype.toString.call(global.process)==="[object process]"}catch{return!1}}function Xm(){return typeof navigator<"u"&&navigator.userAgent==="Cloudflare-Workers"}function Zm(){const n=typeof chrome=="object"?chrome.runtime:typeof browser=="object"?browser.runtime:void 0;return typeof n=="object"&&n.id!==void 0}function ey(){return typeof navigator=="object"&&navigator.product==="ReactNative"}function ty(){const n=Ye();return n.indexOf("MSIE ")>=0||n.indexOf("Trident/")>=0}function ny(){return!Jm()&&!!navigator.userAgent&&navigator.userAgent.includes("Safari")&&!navigator.userAgent.includes("Chrome")}function ry(){try{return typeof indexedDB=="object"}catch{return!1}}function iy(){return new Promise((n,e)=>{try{let t=!0;const r="validate-browser-context-for-indexeddb-analytics-module",i=self.indexedDB.open(r);i.onsuccess=()=>{i.result.close(),t||self.indexedDB.deleteDatabase(r),n(!0)},i.onupgradeneeded=()=>{t=!1},i.onerror=()=>{var o;e(((o=i.error)==null?void 0:o.message)||"")}}catch(t){e(t)}})}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const oy="FirebaseError";class mn extends Error{constructor(e,t,r){super(t),this.code=e,this.customData=r,this.name=oy,Object.setPrototypeOf(this,mn.prototype),Error.captureStackTrace&&Error.captureStackTrace(this,Ao.prototype.create)}}class Ao{constructor(e,t,r){this.service=e,this.serviceName=t,this.errors=r}create(e,...t){const r=t[0]||{},i=`${this.service}/${e}`,o=this.errors[e],s=o?sy(o,r):"Error",l=`${this.serviceName}: ${s} (${i}).`;return new mn(i,l,r)}}function sy(n,e){return n.replace(ay,(t,r)=>{const i=e[r];return i!=null?String(i):`<${r}?>`})}const ay=/\{\$([^}]+)}/g;function ly(n){for(const e in n)if(Object.prototype.hasOwnProperty.call(n,e))return!1;return!0}function gr(n,e){if(n===e)return!0;const t=Object.keys(n),r=Object.keys(e);for(const i of t){if(!r.includes(i))return!1;const o=n[i],s=e[i];if(th(o)&&th(s)){if(!gr(o,s))return!1}else if(o!==s)return!1}for(const i of r)if(!t.includes(i))return!1;return!0}function th(n){return n!==null&&typeof n=="object"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function So(n){const e=[];for(const[t,r]of Object.entries(n))Array.isArray(r)?r.forEach(i=>{e.push(encodeURIComponent(t)+"="+encodeURIComponent(i))}):e.push(encodeURIComponent(t)+"="+encodeURIComponent(r));return e.length?"&"+e.join("&"):""}function cy(n,e){const t=new uy(n,e);return t.subscribe.bind(t)}class uy{constructor(e,t){this.observers=[],this.unsubscribes=[],this.observerCount=0,this.task=Promise.resolve(),this.finalized=!1,this.onNoObservers=t,this.task.then(()=>{e(this)}).catch(r=>{this.error(r)})}next(e){this.forEachObserver(t=>{t.next(e)})}error(e){this.forEachObserver(t=>{t.error(e)}),this.close(e)}complete(){this.forEachObserver(e=>{e.complete()}),this.close()}subscribe(e,t,r){let i;if(e===void 0&&t===void 0&&r===void 0)throw new Error("Missing Observer.");hy(e,["next","error","complete"])?i=e:i={next:e,error:t,complete:r},i.next===void 0&&(i.next=ja),i.error===void 0&&(i.error=ja),i.complete===void 0&&(i.complete=ja);const o=this.unsubscribeOne.bind(this,this.observers.length);return this.finalized&&this.task.then(()=>{try{this.finalError?i.error(this.finalError):i.complete()}catch{}}),this.observers.push(i),o}unsubscribeOne(e){this.observers===void 0||this.observers[e]===void 0||(delete this.observers[e],this.observerCount-=1,this.observerCount===0&&this.onNoObservers!==void 0&&this.onNoObservers(this))}forEachObserver(e){if(!this.finalized)for(let t=0;t<this.observers.length;t++)this.sendOne(t,e)}sendOne(e,t){this.task.then(()=>{if(this.observers!==void 0&&this.observers[e]!==void 0)try{t(this.observers[e])}catch(r){typeof console<"u"&&console.error&&console.error(r)}})}close(e){this.finalized||(this.finalized=!0,e!==void 0&&(this.finalError=e),this.task.then(()=>{this.observers=void 0,this.onNoObservers=void 0}))}}function hy(n,e){if(typeof n!="object"||n===null)return!1;for(const t of e)if(t in n&&typeof n[t]=="function")return!0;return!1}function ja(){}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function qe(n){return n&&n._delegate?n._delegate:n}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function xo(n){try{return(n.startsWith("http://")||n.startsWith("https://")?new URL(n).hostname:n).endsWith(".cloudworkstations.dev")}catch{return!1}}async function ef(n){return(await fetch(n,{credentials:"include"})).ok}class mr{constructor(e,t,r){this.name=e,this.instanceFactory=t,this.type=r,this.multipleInstances=!1,this.serviceProps={},this.instantiationMode="LAZY",this.onInstanceCreated=null}setInstantiationMode(e){return this.instantiationMode=e,this}setMultipleInstances(e){return this.multipleInstances=e,this}setServiceProps(e){return this.serviceProps=e,this}setInstanceCreatedCallback(e){return this.onInstanceCreated=e,this}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const rr="[DEFAULT]";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class dy{constructor(e,t){this.name=e,this.container=t,this.component=null,this.instances=new Map,this.instancesDeferred=new Map,this.instancesOptions=new Map,this.onInitCallbacks=new Map}get(e){const t=this.normalizeInstanceIdentifier(e);if(!this.instancesDeferred.has(t)){const r=new Km;if(this.instancesDeferred.set(t,r),this.isInitialized(t)||this.shouldAutoInitialize())try{const i=this.getOrInitializeService({instanceIdentifier:t});i&&r.resolve(i)}catch{}}return this.instancesDeferred.get(t).promise}getImmediate(e){const t=this.normalizeInstanceIdentifier(e==null?void 0:e.identifier),r=(e==null?void 0:e.optional)??!1;if(this.isInitialized(t)||this.shouldAutoInitialize())try{return this.getOrInitializeService({instanceIdentifier:t})}catch(i){if(r)return null;throw i}else{if(r)return null;throw Error(`Service ${this.name} is not available`)}}getComponent(){return this.component}setComponent(e){if(e.name!==this.name)throw Error(`Mismatching Component ${e.name} for Provider ${this.name}.`);if(this.component)throw Error(`Component for ${this.name} has already been provided`);if(this.component=e,!!this.shouldAutoInitialize()){if(py(e))try{this.getOrInitializeService({instanceIdentifier:rr})}catch{}for(const[t,r]of this.instancesDeferred.entries()){const i=this.normalizeInstanceIdentifier(t);try{const o=this.getOrInitializeService({instanceIdentifier:i});r.resolve(o)}catch{}}}}clearInstance(e=rr){this.instancesDeferred.delete(e),this.instancesOptions.delete(e),this.instances.delete(e)}async delete(){const e=Array.from(this.instances.values());await Promise.all([...e.filter(t=>"INTERNAL"in t).map(t=>t.INTERNAL.delete()),...e.filter(t=>"_delete"in t).map(t=>t._delete())])}isComponentSet(){return this.component!=null}isInitialized(e=rr){return this.instances.has(e)}getOptions(e=rr){return this.instancesOptions.get(e)||{}}initialize(e={}){const{options:t={}}=e,r=this.normalizeInstanceIdentifier(e.instanceIdentifier);if(this.isInitialized(r))throw Error(`${this.name}(${r}) has already been initialized`);if(!this.isComponentSet())throw Error(`Component ${this.name} has not been registered yet`);const i=this.getOrInitializeService({instanceIdentifier:r,options:t});for(const[o,s]of this.instancesDeferred.entries()){const l=this.normalizeInstanceIdentifier(o);r===l&&s.resolve(i)}return i}onInit(e,t){const r=this.normalizeInstanceIdentifier(t),i=this.onInitCallbacks.get(r)??new Set;i.add(e),this.onInitCallbacks.set(r,i);const o=this.instances.get(r);return o&&e(o,r),()=>{i.delete(e)}}invokeOnInitCallbacks(e,t){const r=this.onInitCallbacks.get(t);if(r)for(const i of r)try{i(e,t)}catch{}}getOrInitializeService({instanceIdentifier:e,options:t={}}){let r=this.instances.get(e);if(!r&&this.component&&(r=this.component.instanceFactory(this.container,{instanceIdentifier:fy(e),options:t}),this.instances.set(e,r),this.instancesOptions.set(e,t),this.invokeOnInitCallbacks(r,e),this.component.onInstanceCreated))try{this.component.onInstanceCreated(this.container,e,r)}catch{}return r||null}normalizeInstanceIdentifier(e=rr){return this.component?this.component.multipleInstances?e:rr:e}shouldAutoInitialize(){return!!this.component&&this.component.instantiationMode!=="EXPLICIT"}}function fy(n){return n===rr?void 0:n}function py(n){return n.instantiationMode==="EAGER"}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class gy{constructor(e){this.name=e,this.providers=new Map}addComponent(e){const t=this.getProvider(e.name);if(t.isComponentSet())throw new Error(`Component ${e.name} has already been registered with ${this.name}`);t.setComponent(e)}addOrOverwriteComponent(e){this.getProvider(e.name).isComponentSet()&&this.providers.delete(e.name),this.addComponent(e)}getProvider(e){if(this.providers.has(e))return this.providers.get(e);const t=new dy(e,this);return this.providers.set(e,t),t}getProviders(){return Array.from(this.providers.values())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var ne;(function(n){n[n.DEBUG=0]="DEBUG",n[n.VERBOSE=1]="VERBOSE",n[n.INFO=2]="INFO",n[n.WARN=3]="WARN",n[n.ERROR=4]="ERROR",n[n.SILENT=5]="SILENT"})(ne||(ne={}));const my={debug:ne.DEBUG,verbose:ne.VERBOSE,info:ne.INFO,warn:ne.WARN,error:ne.ERROR,silent:ne.SILENT},yy=ne.INFO,vy={[ne.DEBUG]:"log",[ne.VERBOSE]:"log",[ne.INFO]:"info",[ne.WARN]:"warn",[ne.ERROR]:"error"},_y=(n,e,...t)=>{if(e<n.logLevel)return;const r=new Date().toISOString(),i=vy[e];if(i)console[i](`[${r}]  ${n.name}:`,...t);else throw new Error(`Attempted to log a message with an invalid logType (value: ${e})`)};class Wl{constructor(e){this.name=e,this._logLevel=yy,this._logHandler=_y,this._userLogHandler=null}get logLevel(){return this._logLevel}set logLevel(e){if(!(e in ne))throw new TypeError(`Invalid value "${e}" assigned to \`logLevel\``);this._logLevel=e}setLogLevel(e){this._logLevel=typeof e=="string"?my[e]:e}get logHandler(){return this._logHandler}set logHandler(e){if(typeof e!="function")throw new TypeError("Value assigned to `logHandler` must be a function");this._logHandler=e}get userLogHandler(){return this._userLogHandler}set userLogHandler(e){this._userLogHandler=e}debug(...e){this._userLogHandler&&this._userLogHandler(this,ne.DEBUG,...e),this._logHandler(this,ne.DEBUG,...e)}log(...e){this._userLogHandler&&this._userLogHandler(this,ne.VERBOSE,...e),this._logHandler(this,ne.VERBOSE,...e)}info(...e){this._userLogHandler&&this._userLogHandler(this,ne.INFO,...e),this._logHandler(this,ne.INFO,...e)}warn(...e){this._userLogHandler&&this._userLogHandler(this,ne.WARN,...e),this._logHandler(this,ne.WARN,...e)}error(...e){this._userLogHandler&&this._userLogHandler(this,ne.ERROR,...e),this._logHandler(this,ne.ERROR,...e)}}const wy=(n,e)=>e.some(t=>n instanceof t);let nh,rh;function by(){return nh||(nh=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction])}function Ty(){return rh||(rh=[IDBCursor.prototype.advance,IDBCursor.prototype.continue,IDBCursor.prototype.continuePrimaryKey])}const tf=new WeakMap,cl=new WeakMap,nf=new WeakMap,za=new WeakMap,Hl=new WeakMap;function Ey(n){const e=new Promise((t,r)=>{const i=()=>{n.removeEventListener("success",o),n.removeEventListener("error",s)},o=()=>{t(Ln(n.result)),i()},s=()=>{r(n.error),i()};n.addEventListener("success",o),n.addEventListener("error",s)});return e.then(t=>{t instanceof IDBCursor&&tf.set(t,n)}).catch(()=>{}),Hl.set(e,n),e}function Iy(n){if(cl.has(n))return;const e=new Promise((t,r)=>{const i=()=>{n.removeEventListener("complete",o),n.removeEventListener("error",s),n.removeEventListener("abort",s)},o=()=>{t(),i()},s=()=>{r(n.error||new DOMException("AbortError","AbortError")),i()};n.addEventListener("complete",o),n.addEventListener("error",s),n.addEventListener("abort",s)});cl.set(n,e)}let ul={get(n,e,t){if(n instanceof IDBTransaction){if(e==="done")return cl.get(n);if(e==="objectStoreNames")return n.objectStoreNames||nf.get(n);if(e==="store")return t.objectStoreNames[1]?void 0:t.objectStore(t.objectStoreNames[0])}return Ln(n[e])},set(n,e,t){return n[e]=t,!0},has(n,e){return n instanceof IDBTransaction&&(e==="done"||e==="store")?!0:e in n}};function Ay(n){ul=n(ul)}function Sy(n){return n===IDBDatabase.prototype.transaction&&!("objectStoreNames"in IDBTransaction.prototype)?function(e,...t){const r=n.call(Wa(this),e,...t);return nf.set(r,e.sort?e.sort():[e]),Ln(r)}:Ty().includes(n)?function(...e){return n.apply(Wa(this),e),Ln(tf.get(this))}:function(...e){return Ln(n.apply(Wa(this),e))}}function xy(n){return typeof n=="function"?Sy(n):(n instanceof IDBTransaction&&Iy(n),wy(n,by())?new Proxy(n,ul):n)}function Ln(n){if(n instanceof IDBRequest)return Ey(n);if(za.has(n))return za.get(n);const e=xy(n);return e!==n&&(za.set(n,e),Hl.set(e,n)),e}const Wa=n=>Hl.get(n);function ky(n,e,{blocked:t,upgrade:r,blocking:i,terminated:o}={}){const s=indexedDB.open(n,e),l=Ln(s);return r&&s.addEventListener("upgradeneeded",u=>{r(Ln(s.result),u.oldVersion,u.newVersion,Ln(s.transaction),u)}),t&&s.addEventListener("blocked",u=>t(u.oldVersion,u.newVersion,u)),l.then(u=>{o&&u.addEventListener("close",()=>o()),i&&u.addEventListener("versionchange",d=>i(d.oldVersion,d.newVersion,d))}).catch(()=>{}),l}const Py=["get","getKey","getAll","getAllKeys","count"],Cy=["put","add","delete","clear"],Ha=new Map;function ih(n,e){if(!(n instanceof IDBDatabase&&!(e in n)&&typeof e=="string"))return;if(Ha.get(e))return Ha.get(e);const t=e.replace(/FromIndex$/,""),r=e!==t,i=Cy.includes(t);if(!(t in(r?IDBIndex:IDBObjectStore).prototype)||!(i||Py.includes(t)))return;const o=async function(s,...l){const u=this.transaction(s,i?"readwrite":"readonly");let d=u.store;return r&&(d=d.index(l.shift())),(await Promise.all([d[t](...l),i&&u.done]))[0]};return Ha.set(e,o),o}Ay(n=>({...n,get:(e,t,r)=>ih(e,t)||n.get(e,t,r),has:(e,t)=>!!ih(e,t)||n.has(e,t)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ry{constructor(e){this.container=e}getPlatformInfoString(){return this.container.getProviders().map(t=>{if(Oy(t)){const r=t.getImmediate();return`${r.library}/${r.version}`}else return null}).filter(t=>t).join(" ")}}function Oy(n){const e=n.getComponent();return(e==null?void 0:e.type)==="VERSION"}const hl="@firebase/app",oh="0.14.11";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const cn=new Wl("@firebase/app"),Ny="@firebase/app-compat",Dy="@firebase/analytics-compat",Ly="@firebase/analytics",My="@firebase/app-check-compat",Vy="@firebase/app-check",Fy="@firebase/auth",Uy="@firebase/auth-compat",qy="@firebase/database",$y="@firebase/data-connect",By="@firebase/database-compat",jy="@firebase/functions",zy="@firebase/functions-compat",Wy="@firebase/installations",Hy="@firebase/installations-compat",Gy="@firebase/messaging",Ky="@firebase/messaging-compat",Yy="@firebase/performance",Qy="@firebase/performance-compat",Jy="@firebase/remote-config",Xy="@firebase/remote-config-compat",Zy="@firebase/storage",ev="@firebase/storage-compat",tv="@firebase/firestore",nv="@firebase/ai",rv="@firebase/firestore-compat",iv="firebase",ov="12.12.0";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const dl="[DEFAULT]",sv={[hl]:"fire-core",[Ny]:"fire-core-compat",[Ly]:"fire-analytics",[Dy]:"fire-analytics-compat",[Vy]:"fire-app-check",[My]:"fire-app-check-compat",[Fy]:"fire-auth",[Uy]:"fire-auth-compat",[qy]:"fire-rtdb",[$y]:"fire-data-connect",[By]:"fire-rtdb-compat",[jy]:"fire-fn",[zy]:"fire-fn-compat",[Wy]:"fire-iid",[Hy]:"fire-iid-compat",[Gy]:"fire-fcm",[Ky]:"fire-fcm-compat",[Yy]:"fire-perf",[Qy]:"fire-perf-compat",[Jy]:"fire-rc",[Xy]:"fire-rc-compat",[Zy]:"fire-gcs",[ev]:"fire-gcs-compat",[tv]:"fire-fst",[rv]:"fire-fst-compat",[nv]:"fire-vertex","fire-js":"fire-js",[iv]:"fire-js-all"};/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ao=new Map,av=new Map,fl=new Map;function sh(n,e){try{n.container.addComponent(e)}catch(t){cn.debug(`Component ${e.name} failed to register with FirebaseApp ${n.name}`,t)}}function Zr(n){const e=n.name;if(fl.has(e))return cn.debug(`There were multiple attempts to register component ${e}.`),!1;fl.set(e,n);for(const t of ao.values())sh(t,n);for(const t of av.values())sh(t,n);return!0}function Gl(n,e){const t=n.container.getProvider("heartbeat").getImmediate({optional:!0});return t&&t.triggerHeartbeat(),n.container.getProvider(e)}function Nt(n){return n==null?!1:n.settings!==void 0}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const lv={"no-app":"No Firebase App '{$appName}' has been created - call initializeApp() first","bad-app-name":"Illegal App name: '{$appName}'","duplicate-app":"Firebase App named '{$appName}' already exists with different options or config","app-deleted":"Firebase App named '{$appName}' already deleted","server-app-deleted":"Firebase Server App has been deleted","no-options":"Need to provide options, when not being deployed to hosting via source.","invalid-app-argument":"firebase.{$appName}() takes either no argument or a Firebase App instance.","invalid-log-argument":"First argument to `onLog` must be null or a function.","idb-open":"Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.","idb-get":"Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.","idb-set":"Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.","idb-delete":"Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}.","finalization-registry-not-supported":"FirebaseServerApp deleteOnDeref field defined but the JS runtime does not support FinalizationRegistry.","invalid-server-app-environment":"FirebaseServerApp is not for use in browser environments."},Mn=new Ao("app","Firebase",lv);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class cv{constructor(e,t,r){this._isDeleted=!1,this._options={...e},this._config={...t},this._name=t.name,this._automaticDataCollectionEnabled=t.automaticDataCollectionEnabled,this._container=r,this.container.addComponent(new mr("app",()=>this,"PUBLIC"))}get automaticDataCollectionEnabled(){return this.checkDestroyed(),this._automaticDataCollectionEnabled}set automaticDataCollectionEnabled(e){this.checkDestroyed(),this._automaticDataCollectionEnabled=e}get name(){return this.checkDestroyed(),this._name}get options(){return this.checkDestroyed(),this._options}get config(){return this.checkDestroyed(),this._config}get container(){return this._container}get isDeleted(){return this._isDeleted}set isDeleted(e){this._isDeleted=e}checkDestroyed(){if(this.isDeleted)throw Mn.create("app-deleted",{appName:this._name})}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const pi=ov;function Kl(n,e={}){let t=n;typeof e!="object"&&(e={name:e});const r={name:dl,automaticDataCollectionEnabled:!0,...e},i=r.name;if(typeof i!="string"||!i)throw Mn.create("bad-app-name",{appName:String(i)});if(t||(t=Xd()),!t)throw Mn.create("no-options");const o=ao.get(i);if(o){if(gr(t,o.options)&&gr(r,o.config))return o;throw Mn.create("duplicate-app",{appName:i})}const s=new gy(i);for(const u of fl.values())s.addComponent(u);const l=new cv(t,r,s);return ao.set(i,l),l}function rf(n=dl){const e=ao.get(n);if(!e&&n===dl&&Xd())return Kl();if(!e)throw Mn.create("no-app",{appName:n});return e}function ks(){return Array.from(ao.values())}function Vn(n,e,t){let r=sv[n]??n;t&&(r+=`-${t}`);const i=r.match(/\s|\//),o=e.match(/\s|\//);if(i||o){const s=[`Unable to register library "${r}" with version "${e}":`];i&&s.push(`library name "${r}" contains illegal characters (whitespace or "/")`),i&&o&&s.push("and"),o&&s.push(`version name "${e}" contains illegal characters (whitespace or "/")`),cn.warn(s.join(" "));return}Zr(new mr(`${r}-version`,()=>({library:r,version:e}),"VERSION"))}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const uv="firebase-heartbeat-database",hv=1,lo="firebase-heartbeat-store";let Ga=null;function of(){return Ga||(Ga=ky(uv,hv,{upgrade:(n,e)=>{switch(e){case 0:try{n.createObjectStore(lo)}catch(t){console.warn(t)}}}}).catch(n=>{throw Mn.create("idb-open",{originalErrorMessage:n.message})})),Ga}async function dv(n){try{const t=(await of()).transaction(lo),r=await t.objectStore(lo).get(sf(n));return await t.done,r}catch(e){if(e instanceof mn)cn.warn(e.message);else{const t=Mn.create("idb-get",{originalErrorMessage:e==null?void 0:e.message});cn.warn(t.message)}}}async function ah(n,e){try{const r=(await of()).transaction(lo,"readwrite");await r.objectStore(lo).put(e,sf(n)),await r.done}catch(t){if(t instanceof mn)cn.warn(t.message);else{const r=Mn.create("idb-set",{originalErrorMessage:t==null?void 0:t.message});cn.warn(r.message)}}}function sf(n){return`${n.name}!${n.options.appId}`}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const fv=1024,pv=30;class gv{constructor(e){this.container=e,this._heartbeatsCache=null;const t=this.container.getProvider("app").getImmediate();this._storage=new yv(t),this._heartbeatsCachePromise=this._storage.read().then(r=>(this._heartbeatsCache=r,r))}async triggerHeartbeat(){var e,t;try{const i=this.container.getProvider("platform-logger").getImmediate().getPlatformInfoString(),o=lh();if(((e=this._heartbeatsCache)==null?void 0:e.heartbeats)==null&&(this._heartbeatsCache=await this._heartbeatsCachePromise,((t=this._heartbeatsCache)==null?void 0:t.heartbeats)==null)||this._heartbeatsCache.lastSentHeartbeatDate===o||this._heartbeatsCache.heartbeats.some(s=>s.date===o))return;if(this._heartbeatsCache.heartbeats.push({date:o,agent:i}),this._heartbeatsCache.heartbeats.length>pv){const s=vv(this._heartbeatsCache.heartbeats);this._heartbeatsCache.heartbeats.splice(s,1)}return this._storage.overwrite(this._heartbeatsCache)}catch(r){cn.warn(r)}}async getHeartbeatsHeader(){var e;try{if(this._heartbeatsCache===null&&await this._heartbeatsCachePromise,((e=this._heartbeatsCache)==null?void 0:e.heartbeats)==null||this._heartbeatsCache.heartbeats.length===0)return"";const t=lh(),{heartbeatsToSend:r,unsentEntries:i}=mv(this._heartbeatsCache.heartbeats),o=xs(JSON.stringify({version:2,heartbeats:r}));return this._heartbeatsCache.lastSentHeartbeatDate=t,i.length>0?(this._heartbeatsCache.heartbeats=i,await this._storage.overwrite(this._heartbeatsCache)):(this._heartbeatsCache.heartbeats=[],this._storage.overwrite(this._heartbeatsCache)),o}catch(t){return cn.warn(t),""}}}function lh(){return new Date().toISOString().substring(0,10)}function mv(n,e=fv){const t=[];let r=n.slice();for(const i of n){const o=t.find(s=>s.agent===i.agent);if(o){if(o.dates.push(i.date),ch(t)>e){o.dates.pop();break}}else if(t.push({agent:i.agent,dates:[i.date]}),ch(t)>e){t.pop();break}r=r.slice(1)}return{heartbeatsToSend:t,unsentEntries:r}}class yv{constructor(e){this.app=e,this._canUseIndexedDBPromise=this.runIndexedDBEnvironmentCheck()}async runIndexedDBEnvironmentCheck(){return ry()?iy().then(()=>!0).catch(()=>!1):!1}async read(){if(await this._canUseIndexedDBPromise){const t=await dv(this.app);return t!=null&&t.heartbeats?t:{heartbeats:[]}}else return{heartbeats:[]}}async overwrite(e){if(await this._canUseIndexedDBPromise){const r=await this.read();return ah(this.app,{lastSentHeartbeatDate:e.lastSentHeartbeatDate??r.lastSentHeartbeatDate,heartbeats:e.heartbeats})}else return}async add(e){if(await this._canUseIndexedDBPromise){const r=await this.read();return ah(this.app,{lastSentHeartbeatDate:e.lastSentHeartbeatDate??r.lastSentHeartbeatDate,heartbeats:[...r.heartbeats,...e.heartbeats]})}else return}}function ch(n){return xs(JSON.stringify({version:2,heartbeats:n})).length}function vv(n){if(n.length===0)return-1;let e=0,t=n[0].date;for(let r=1;r<n.length;r++)n[r].date<t&&(t=n[r].date,e=r);return e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function _v(n){Zr(new mr("platform-logger",e=>new Ry(e),"PRIVATE")),Zr(new mr("heartbeat",e=>new gv(e),"PRIVATE")),Vn(hl,oh,n),Vn(hl,oh,"esm2020"),Vn("fire-js","")}_v("");var wv="firebase",bv="12.12.1";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */Vn(wv,bv,"app");function af(){return{"dependent-sdk-initialized-before-auth":"Another Firebase SDK was initialized and is trying to use Auth before Auth is initialized. Please be sure to call `initializeAuth` or `getAuth` before starting any other Firebase SDK."}}const Tv=af,lf=new Ao("auth","Firebase",af());/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ps=new Wl("@firebase/auth");function Ev(n,...e){Ps.logLevel<=ne.WARN&&Ps.warn(`Auth (${pi}): ${n}`,...e)}function fs(n,...e){Ps.logLevel<=ne.ERROR&&Ps.error(`Auth (${pi}): ${n}`,...e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function un(n,...e){throw Yl(n,...e)}function Ut(n,...e){return Yl(n,...e)}function cf(n,e,t){const r={...Tv(),[e]:t};return new Ao("auth","Firebase",r).create(e,{appName:n.name})}function ur(n){return cf(n,"operation-not-supported-in-this-environment","Operations that alter the current user are not supported in conjunction with FirebaseServerApp")}function Yl(n,...e){if(typeof n!="string"){const t=e[0],r=[...e.slice(1)];return r[0]&&(r[0].appName=n.name),n._errorFactory.create(t,...r)}return lf.create(n,...e)}function Y(n,e,...t){if(!n)throw Yl(e,...t)}function en(n){const e="INTERNAL ASSERTION FAILED: "+n;throw fs(e),new Error(e)}function hn(n,e){n||en(e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function pl(){var n;return typeof self<"u"&&((n=self.location)==null?void 0:n.href)||""}function Iv(){return uh()==="http:"||uh()==="https:"}function uh(){var n;return typeof self<"u"&&((n=self.location)==null?void 0:n.protocol)||null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Av(){return typeof navigator<"u"&&navigator&&"onLine"in navigator&&typeof navigator.onLine=="boolean"&&(Iv()||Zm()||"connection"in navigator)?navigator.onLine:!0}function Sv(){if(typeof navigator>"u")return null;const n=navigator;return n.languages&&n.languages[0]||n.language||null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ko{constructor(e,t){this.shortDelay=e,this.longDelay=t,hn(t>e,"Short delay should be less than long delay!"),this.isMobile=Qm()||ey()}get(){return Av()?this.isMobile?this.longDelay:this.shortDelay:Math.min(5e3,this.shortDelay)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ql(n,e){hn(n.emulator,"Emulator should always be set here");const{url:t}=n.emulator;return e?`${t}${e.startsWith("/")?e.slice(1):e}`:t}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class uf{static initialize(e,t,r){this.fetchImpl=e,t&&(this.headersImpl=t),r&&(this.responseImpl=r)}static fetch(){if(this.fetchImpl)return this.fetchImpl;if(typeof self<"u"&&"fetch"in self)return self.fetch;if(typeof globalThis<"u"&&globalThis.fetch)return globalThis.fetch;if(typeof fetch<"u")return fetch;en("Could not find fetch implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static headers(){if(this.headersImpl)return this.headersImpl;if(typeof self<"u"&&"Headers"in self)return self.Headers;if(typeof globalThis<"u"&&globalThis.Headers)return globalThis.Headers;if(typeof Headers<"u")return Headers;en("Could not find Headers implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static response(){if(this.responseImpl)return this.responseImpl;if(typeof self<"u"&&"Response"in self)return self.Response;if(typeof globalThis<"u"&&globalThis.Response)return globalThis.Response;if(typeof Response<"u")return Response;en("Could not find Response implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const xv={CREDENTIAL_MISMATCH:"custom-token-mismatch",MISSING_CUSTOM_TOKEN:"internal-error",INVALID_IDENTIFIER:"invalid-email",MISSING_CONTINUE_URI:"internal-error",INVALID_PASSWORD:"wrong-password",MISSING_PASSWORD:"missing-password",INVALID_LOGIN_CREDENTIALS:"invalid-credential",EMAIL_EXISTS:"email-already-in-use",PASSWORD_LOGIN_DISABLED:"operation-not-allowed",INVALID_IDP_RESPONSE:"invalid-credential",INVALID_PENDING_TOKEN:"invalid-credential",FEDERATED_USER_ID_ALREADY_LINKED:"credential-already-in-use",MISSING_REQ_TYPE:"internal-error",EMAIL_NOT_FOUND:"user-not-found",RESET_PASSWORD_EXCEED_LIMIT:"too-many-requests",EXPIRED_OOB_CODE:"expired-action-code",INVALID_OOB_CODE:"invalid-action-code",MISSING_OOB_CODE:"internal-error",CREDENTIAL_TOO_OLD_LOGIN_AGAIN:"requires-recent-login",INVALID_ID_TOKEN:"invalid-user-token",TOKEN_EXPIRED:"user-token-expired",USER_NOT_FOUND:"user-token-expired",TOO_MANY_ATTEMPTS_TRY_LATER:"too-many-requests",PASSWORD_DOES_NOT_MEET_REQUIREMENTS:"password-does-not-meet-requirements",INVALID_CODE:"invalid-verification-code",INVALID_SESSION_INFO:"invalid-verification-id",INVALID_TEMPORARY_PROOF:"invalid-credential",MISSING_SESSION_INFO:"missing-verification-id",SESSION_EXPIRED:"code-expired",MISSING_ANDROID_PACKAGE_NAME:"missing-android-pkg-name",UNAUTHORIZED_DOMAIN:"unauthorized-continue-uri",INVALID_OAUTH_CLIENT_ID:"invalid-oauth-client-id",ADMIN_ONLY_OPERATION:"admin-restricted-operation",INVALID_MFA_PENDING_CREDENTIAL:"invalid-multi-factor-session",MFA_ENROLLMENT_NOT_FOUND:"multi-factor-info-not-found",MISSING_MFA_ENROLLMENT_ID:"missing-multi-factor-info",MISSING_MFA_PENDING_CREDENTIAL:"missing-multi-factor-session",SECOND_FACTOR_EXISTS:"second-factor-already-in-use",SECOND_FACTOR_LIMIT_EXCEEDED:"maximum-second-factor-count-exceeded",BLOCKING_FUNCTION_ERROR_RESPONSE:"internal-error",RECAPTCHA_NOT_ENABLED:"recaptcha-not-enabled",MISSING_RECAPTCHA_TOKEN:"missing-recaptcha-token",INVALID_RECAPTCHA_TOKEN:"invalid-recaptcha-token",INVALID_RECAPTCHA_ACTION:"invalid-recaptcha-action",MISSING_CLIENT_TYPE:"missing-client-type",MISSING_RECAPTCHA_VERSION:"missing-recaptcha-version",INVALID_RECAPTCHA_VERSION:"invalid-recaptcha-version",INVALID_REQ_TYPE:"invalid-req-type"};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const kv=["/v1/accounts:signInWithCustomToken","/v1/accounts:signInWithEmailLink","/v1/accounts:signInWithIdp","/v1/accounts:signInWithPassword","/v1/accounts:signInWithPhoneNumber","/v1/token"],Pv=new ko(3e4,6e4);function Jl(n,e){return n.tenantId&&!e.tenantId?{...e,tenantId:n.tenantId}:e}async function gi(n,e,t,r,i={}){return hf(n,i,async()=>{let o={},s={};r&&(e==="GET"?s=r:o={body:JSON.stringify(r)});const l=So({key:n.config.apiKey,...s}).slice(1),u=await n._getAdditionalHeaders();u["Content-Type"]="application/json",n.languageCode&&(u["X-Firebase-Locale"]=n.languageCode);const d={method:e,headers:u,...o};return Xm()||(d.referrerPolicy="no-referrer"),n.emulatorConfig&&xo(n.emulatorConfig.host)&&(d.credentials="include"),uf.fetch()(await df(n,n.config.apiHost,t,l),d)})}async function hf(n,e,t){n._canInitEmulator=!1;const r={...xv,...e};try{const i=new Rv(n),o=await Promise.race([t(),i.promise]);i.clearNetworkTimeout();const s=await o.json();if("needConfirmation"in s)throw Xo(n,"account-exists-with-different-credential",s);if(o.ok&&!("errorMessage"in s))return s;{const l=o.ok?s.errorMessage:s.error.message,[u,d]=l.split(" : ");if(u==="FEDERATED_USER_ID_ALREADY_LINKED")throw Xo(n,"credential-already-in-use",s);if(u==="EMAIL_EXISTS")throw Xo(n,"email-already-in-use",s);if(u==="USER_DISABLED")throw Xo(n,"user-disabled",s);const p=r[u]||u.toLowerCase().replace(/[_\s]+/g,"-");if(d)throw cf(n,p,d);un(n,p)}}catch(i){if(i instanceof mn)throw i;un(n,"network-request-failed",{message:String(i)})}}async function Cv(n,e,t,r,i={}){const o=await gi(n,e,t,r,i);return"mfaPendingCredential"in o&&un(n,"multi-factor-auth-required",{_serverResponse:o}),o}async function df(n,e,t,r){const i=`${e}${t}?${r}`,o=n,s=o.config.emulator?Ql(n.config,i):`${n.config.apiScheme}://${i}`;return kv.includes(t)&&(await o._persistenceManagerAvailable,o._getPersistenceType()==="COOKIE")?o._getPersistence()._getFinalTarget(s).toString():s}class Rv{clearNetworkTimeout(){clearTimeout(this.timer)}constructor(e){this.auth=e,this.timer=null,this.promise=new Promise((t,r)=>{this.timer=setTimeout(()=>r(Ut(this.auth,"network-request-failed")),Pv.get())})}}function Xo(n,e,t){const r={appName:n.name};t.email&&(r.email=t.email),t.phoneNumber&&(r.phoneNumber=t.phoneNumber);const i=Ut(n,e,r);return i.customData._tokenResponse=t,i}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Ov(n,e){return gi(n,"POST","/v1/accounts:delete",e)}async function Cs(n,e){return gi(n,"POST","/v1/accounts:lookup",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Zi(n){if(n)try{const e=new Date(Number(n));if(!isNaN(e.getTime()))return e.toUTCString()}catch{}}async function Nv(n,e=!1){const t=qe(n),r=await t.getIdToken(e),i=Xl(r);Y(i&&i.exp&&i.auth_time&&i.iat,t.auth,"internal-error");const o=typeof i.firebase=="object"?i.firebase:void 0,s=o==null?void 0:o.sign_in_provider;return{claims:i,token:r,authTime:Zi(Ka(i.auth_time)),issuedAtTime:Zi(Ka(i.iat)),expirationTime:Zi(Ka(i.exp)),signInProvider:s||null,signInSecondFactor:(o==null?void 0:o.sign_in_second_factor)||null}}function Ka(n){return Number(n)*1e3}function Xl(n){const[e,t,r]=n.split(".");if(e===void 0||t===void 0||r===void 0)return fs("JWT malformed, contained fewer than 3 sections"),null;try{const i=Qd(t);return i?JSON.parse(i):(fs("Failed to decode base64 JWT payload"),null)}catch(i){return fs("Caught error parsing JWT payload as JSON",i==null?void 0:i.toString()),null}}function hh(n){const e=Xl(n);return Y(e,"internal-error"),Y(typeof e.exp<"u","internal-error"),Y(typeof e.iat<"u","internal-error"),Number(e.exp)-Number(e.iat)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function co(n,e,t=!1){if(t)return e;try{return await e}catch(r){throw r instanceof mn&&Dv(r)&&n.auth.currentUser===n&&await n.auth.signOut(),r}}function Dv({code:n}){return n==="auth/user-disabled"||n==="auth/user-token-expired"}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Lv{constructor(e){this.user=e,this.isRunning=!1,this.timerId=null,this.errorBackoff=3e4}_start(){this.isRunning||(this.isRunning=!0,this.schedule())}_stop(){this.isRunning&&(this.isRunning=!1,this.timerId!==null&&clearTimeout(this.timerId))}getInterval(e){if(e){const t=this.errorBackoff;return this.errorBackoff=Math.min(this.errorBackoff*2,96e4),t}else{this.errorBackoff=3e4;const r=(this.user.stsTokenManager.expirationTime??0)-Date.now()-3e5;return Math.max(0,r)}}schedule(e=!1){if(!this.isRunning)return;const t=this.getInterval(e);this.timerId=setTimeout(async()=>{await this.iteration()},t)}async iteration(){try{await this.user.getIdToken(!0)}catch(e){(e==null?void 0:e.code)==="auth/network-request-failed"&&this.schedule(!0);return}this.schedule()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class gl{constructor(e,t){this.createdAt=e,this.lastLoginAt=t,this._initializeTime()}_initializeTime(){this.lastSignInTime=Zi(this.lastLoginAt),this.creationTime=Zi(this.createdAt)}_copy(e){this.createdAt=e.createdAt,this.lastLoginAt=e.lastLoginAt,this._initializeTime()}toJSON(){return{createdAt:this.createdAt,lastLoginAt:this.lastLoginAt}}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Rs(n){var m;const e=n.auth,t=await n.getIdToken(),r=await co(n,Cs(e,{idToken:t}));Y(r==null?void 0:r.users.length,e,"internal-error");const i=r.users[0];n._notifyReloadListener(i);const o=(m=i.providerUserInfo)!=null&&m.length?ff(i.providerUserInfo):[],s=Vv(n.providerData,o),l=n.isAnonymous,u=!(n.email&&i.passwordHash)&&!(s!=null&&s.length),d=l?u:!1,p={uid:i.localId,displayName:i.displayName||null,photoURL:i.photoUrl||null,email:i.email||null,emailVerified:i.emailVerified||!1,phoneNumber:i.phoneNumber||null,tenantId:i.tenantId||null,providerData:s,metadata:new gl(i.createdAt,i.lastLoginAt),isAnonymous:d};Object.assign(n,p)}async function Mv(n){const e=qe(n);await Rs(e),await e.auth._persistUserIfCurrent(e),e.auth._notifyListenersIfCurrent(e)}function Vv(n,e){return[...n.filter(r=>!e.some(i=>i.providerId===r.providerId)),...e]}function ff(n){return n.map(({providerId:e,...t})=>({providerId:e,uid:t.rawId||"",displayName:t.displayName||null,email:t.email||null,phoneNumber:t.phoneNumber||null,photoURL:t.photoUrl||null}))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Fv(n,e){const t=await hf(n,{},async()=>{const r=So({grant_type:"refresh_token",refresh_token:e}).slice(1),{tokenApiHost:i,apiKey:o}=n.config,s=await df(n,i,"/v1/token",`key=${o}`),l=await n._getAdditionalHeaders();l["Content-Type"]="application/x-www-form-urlencoded";const u={method:"POST",headers:l,body:r};return n.emulatorConfig&&xo(n.emulatorConfig.host)&&(u.credentials="include"),uf.fetch()(s,u)});return{accessToken:t.access_token,expiresIn:t.expires_in,refreshToken:t.refresh_token}}async function Uv(n,e){return gi(n,"POST","/v2/accounts:revokeToken",Jl(n,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ur{constructor(){this.refreshToken=null,this.accessToken=null,this.expirationTime=null}get isExpired(){return!this.expirationTime||Date.now()>this.expirationTime-3e4}updateFromServerResponse(e){Y(e.idToken,"internal-error"),Y(typeof e.idToken<"u","internal-error"),Y(typeof e.refreshToken<"u","internal-error");const t="expiresIn"in e&&typeof e.expiresIn<"u"?Number(e.expiresIn):hh(e.idToken);this.updateTokensAndExpiration(e.idToken,e.refreshToken,t)}updateFromIdToken(e){Y(e.length!==0,"internal-error");const t=hh(e);this.updateTokensAndExpiration(e,null,t)}async getToken(e,t=!1){return!t&&this.accessToken&&!this.isExpired?this.accessToken:(Y(this.refreshToken,e,"user-token-expired"),this.refreshToken?(await this.refresh(e,this.refreshToken),this.accessToken):null)}clearRefreshToken(){this.refreshToken=null}async refresh(e,t){const{accessToken:r,refreshToken:i,expiresIn:o}=await Fv(e,t);this.updateTokensAndExpiration(r,i,Number(o))}updateTokensAndExpiration(e,t,r){this.refreshToken=t||null,this.accessToken=e||null,this.expirationTime=Date.now()+r*1e3}static fromJSON(e,t){const{refreshToken:r,accessToken:i,expirationTime:o}=t,s=new Ur;return r&&(Y(typeof r=="string","internal-error",{appName:e}),s.refreshToken=r),i&&(Y(typeof i=="string","internal-error",{appName:e}),s.accessToken=i),o&&(Y(typeof o=="number","internal-error",{appName:e}),s.expirationTime=o),s}toJSON(){return{refreshToken:this.refreshToken,accessToken:this.accessToken,expirationTime:this.expirationTime}}_assign(e){this.accessToken=e.accessToken,this.refreshToken=e.refreshToken,this.expirationTime=e.expirationTime}_clone(){return Object.assign(new Ur,this.toJSON())}_performRefresh(){return en("not implemented")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function An(n,e){Y(typeof n=="string"||typeof n>"u","internal-error",{appName:e})}class Tt{constructor({uid:e,auth:t,stsTokenManager:r,...i}){this.providerId="firebase",this.proactiveRefresh=new Lv(this),this.reloadUserInfo=null,this.reloadListener=null,this.uid=e,this.auth=t,this.stsTokenManager=r,this.accessToken=r.accessToken,this.displayName=i.displayName||null,this.email=i.email||null,this.emailVerified=i.emailVerified||!1,this.phoneNumber=i.phoneNumber||null,this.photoURL=i.photoURL||null,this.isAnonymous=i.isAnonymous||!1,this.tenantId=i.tenantId||null,this.providerData=i.providerData?[...i.providerData]:[],this.metadata=new gl(i.createdAt||void 0,i.lastLoginAt||void 0)}async getIdToken(e){const t=await co(this,this.stsTokenManager.getToken(this.auth,e));return Y(t,this.auth,"internal-error"),this.accessToken!==t&&(this.accessToken=t,await this.auth._persistUserIfCurrent(this),this.auth._notifyListenersIfCurrent(this)),t}getIdTokenResult(e){return Nv(this,e)}reload(){return Mv(this)}_assign(e){this!==e&&(Y(this.uid===e.uid,this.auth,"internal-error"),this.displayName=e.displayName,this.photoURL=e.photoURL,this.email=e.email,this.emailVerified=e.emailVerified,this.phoneNumber=e.phoneNumber,this.isAnonymous=e.isAnonymous,this.tenantId=e.tenantId,this.providerData=e.providerData.map(t=>({...t})),this.metadata._copy(e.metadata),this.stsTokenManager._assign(e.stsTokenManager))}_clone(e){const t=new Tt({...this,auth:e,stsTokenManager:this.stsTokenManager._clone()});return t.metadata._copy(this.metadata),t}_onReload(e){Y(!this.reloadListener,this.auth,"internal-error"),this.reloadListener=e,this.reloadUserInfo&&(this._notifyReloadListener(this.reloadUserInfo),this.reloadUserInfo=null)}_notifyReloadListener(e){this.reloadListener?this.reloadListener(e):this.reloadUserInfo=e}_startProactiveRefresh(){this.proactiveRefresh._start()}_stopProactiveRefresh(){this.proactiveRefresh._stop()}async _updateTokensIfNecessary(e,t=!1){let r=!1;e.idToken&&e.idToken!==this.stsTokenManager.accessToken&&(this.stsTokenManager.updateFromServerResponse(e),r=!0),t&&await Rs(this),await this.auth._persistUserIfCurrent(this),r&&this.auth._notifyListenersIfCurrent(this)}async delete(){if(Nt(this.auth.app))return Promise.reject(ur(this.auth));const e=await this.getIdToken();return await co(this,Ov(this.auth,{idToken:e})),this.stsTokenManager.clearRefreshToken(),this.auth.signOut()}toJSON(){return{uid:this.uid,email:this.email||void 0,emailVerified:this.emailVerified,displayName:this.displayName||void 0,isAnonymous:this.isAnonymous,photoURL:this.photoURL||void 0,phoneNumber:this.phoneNumber||void 0,tenantId:this.tenantId||void 0,providerData:this.providerData.map(e=>({...e})),stsTokenManager:this.stsTokenManager.toJSON(),_redirectEventId:this._redirectEventId,...this.metadata.toJSON(),apiKey:this.auth.config.apiKey,appName:this.auth.name}}get refreshToken(){return this.stsTokenManager.refreshToken||""}static _fromJSON(e,t){const r=t.displayName??void 0,i=t.email??void 0,o=t.phoneNumber??void 0,s=t.photoURL??void 0,l=t.tenantId??void 0,u=t._redirectEventId??void 0,d=t.createdAt??void 0,p=t.lastLoginAt??void 0,{uid:m,emailVerified:g,isAnonymous:b,providerData:O,stsTokenManager:A}=t;Y(m&&A,e,"internal-error");const P=Ur.fromJSON(this.name,A);Y(typeof m=="string",e,"internal-error"),An(r,e.name),An(i,e.name),Y(typeof g=="boolean",e,"internal-error"),Y(typeof b=="boolean",e,"internal-error"),An(o,e.name),An(s,e.name),An(l,e.name),An(u,e.name),An(d,e.name),An(p,e.name);const V=new Tt({uid:m,auth:e,email:i,emailVerified:g,displayName:r,isAnonymous:b,photoURL:s,phoneNumber:o,tenantId:l,stsTokenManager:P,createdAt:d,lastLoginAt:p});return O&&Array.isArray(O)&&(V.providerData=O.map($=>({...$}))),u&&(V._redirectEventId=u),V}static async _fromIdTokenResponse(e,t,r=!1){const i=new Ur;i.updateFromServerResponse(t);const o=new Tt({uid:t.localId,auth:e,stsTokenManager:i,isAnonymous:r});return await Rs(o),o}static async _fromGetAccountInfoResponse(e,t,r){const i=t.users[0];Y(i.localId!==void 0,"internal-error");const o=i.providerUserInfo!==void 0?ff(i.providerUserInfo):[],s=!(i.email&&i.passwordHash)&&!(o!=null&&o.length),l=new Ur;l.updateFromIdToken(r);const u=new Tt({uid:i.localId,auth:e,stsTokenManager:l,isAnonymous:s}),d={uid:i.localId,displayName:i.displayName||null,photoURL:i.photoUrl||null,email:i.email||null,emailVerified:i.emailVerified||!1,phoneNumber:i.phoneNumber||null,tenantId:i.tenantId||null,providerData:o,metadata:new gl(i.createdAt,i.lastLoginAt),isAnonymous:!(i.email&&i.passwordHash)&&!(o!=null&&o.length)};return Object.assign(u,d),u}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const dh=new Map;function tn(n){hn(n instanceof Function,"Expected a class definition");let e=dh.get(n);return e?(hn(e instanceof n,"Instance stored in cache mismatched with class"),e):(e=new n,dh.set(n,e),e)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class pf{constructor(){this.type="NONE",this.storage={}}async _isAvailable(){return!0}async _set(e,t){this.storage[e]=t}async _get(e){const t=this.storage[e];return t===void 0?null:t}async _remove(e){delete this.storage[e]}_addListener(e,t){}_removeListener(e,t){}}pf.type="NONE";const fh=pf;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ps(n,e,t){return`firebase:${n}:${e}:${t}`}class qr{constructor(e,t,r){this.persistence=e,this.auth=t,this.userKey=r;const{config:i,name:o}=this.auth;this.fullUserKey=ps(this.userKey,i.apiKey,o),this.fullPersistenceKey=ps("persistence",i.apiKey,o),this.boundEventHandler=t._onStorageEvent.bind(t),this.persistence._addListener(this.fullUserKey,this.boundEventHandler)}setCurrentUser(e){return this.persistence._set(this.fullUserKey,e.toJSON())}async getCurrentUser(){const e=await this.persistence._get(this.fullUserKey);if(!e)return null;if(typeof e=="string"){const t=await Cs(this.auth,{idToken:e}).catch(()=>{});return t?Tt._fromGetAccountInfoResponse(this.auth,t,e):null}return Tt._fromJSON(this.auth,e)}removeCurrentUser(){return this.persistence._remove(this.fullUserKey)}savePersistenceForRedirect(){return this.persistence._set(this.fullPersistenceKey,this.persistence.type)}async setPersistence(e){if(this.persistence===e)return;const t=await this.getCurrentUser();if(await this.removeCurrentUser(),this.persistence=e,t)return this.setCurrentUser(t)}delete(){this.persistence._removeListener(this.fullUserKey,this.boundEventHandler)}static async create(e,t,r="authUser"){if(!t.length)return new qr(tn(fh),e,r);const i=(await Promise.all(t.map(async d=>{if(await d._isAvailable())return d}))).filter(d=>d);let o=i[0]||tn(fh);const s=ps(r,e.config.apiKey,e.name);let l=null;for(const d of t)try{const p=await d._get(s);if(p){let m;if(typeof p=="string"){const g=await Cs(e,{idToken:p}).catch(()=>{});if(!g)break;m=await Tt._fromGetAccountInfoResponse(e,g,p)}else m=Tt._fromJSON(e,p);d!==o&&(l=m),o=d;break}}catch{}const u=i.filter(d=>d._shouldAllowMigration);return!o._shouldAllowMigration||!u.length?new qr(o,e,r):(o=u[0],l&&await o._set(s,l.toJSON()),await Promise.all(t.map(async d=>{if(d!==o)try{await d._remove(s)}catch{}})),new qr(o,e,r))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ph(n){const e=n.toLowerCase();if(e.includes("opera/")||e.includes("opr/")||e.includes("opios/"))return"Opera";if(vf(e))return"IEMobile";if(e.includes("msie")||e.includes("trident/"))return"IE";if(e.includes("edge/"))return"Edge";if(gf(e))return"Firefox";if(e.includes("silk/"))return"Silk";if(wf(e))return"Blackberry";if(bf(e))return"Webos";if(mf(e))return"Safari";if((e.includes("chrome/")||yf(e))&&!e.includes("edge/"))return"Chrome";if(_f(e))return"Android";{const t=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,r=n.match(t);if((r==null?void 0:r.length)===2)return r[1]}return"Other"}function gf(n=Ye()){return/firefox\//i.test(n)}function mf(n=Ye()){const e=n.toLowerCase();return e.includes("safari/")&&!e.includes("chrome/")&&!e.includes("crios/")&&!e.includes("android")}function yf(n=Ye()){return/crios\//i.test(n)}function vf(n=Ye()){return/iemobile/i.test(n)}function _f(n=Ye()){return/android/i.test(n)}function wf(n=Ye()){return/blackberry/i.test(n)}function bf(n=Ye()){return/webos/i.test(n)}function Zl(n=Ye()){return/iphone|ipad|ipod/i.test(n)||/macintosh/i.test(n)&&/mobile/i.test(n)}function qv(n=Ye()){var e;return Zl(n)&&!!((e=window.navigator)!=null&&e.standalone)}function $v(){return ty()&&document.documentMode===10}function Tf(n=Ye()){return Zl(n)||_f(n)||bf(n)||wf(n)||/windows phone/i.test(n)||vf(n)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ef(n,e=[]){let t;switch(n){case"Browser":t=ph(Ye());break;case"Worker":t=`${ph(Ye())}-${n}`;break;default:t=n}const r=e.length?e.join(","):"FirebaseCore-web";return`${t}/JsCore/${pi}/${r}`}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Bv{constructor(e){this.auth=e,this.queue=[]}pushCallback(e,t){const r=o=>new Promise((s,l)=>{try{const u=e(o);s(u)}catch(u){l(u)}});r.onAbort=t,this.queue.push(r);const i=this.queue.length-1;return()=>{this.queue[i]=()=>Promise.resolve()}}async runMiddleware(e){if(this.auth.currentUser===e)return;const t=[];try{for(const r of this.queue)await r(e),r.onAbort&&t.push(r.onAbort)}catch(r){t.reverse();for(const i of t)try{i()}catch{}throw this.auth._errorFactory.create("login-blocked",{originalMessage:r==null?void 0:r.message})}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function jv(n,e={}){return gi(n,"GET","/v2/passwordPolicy",Jl(n,e))}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const zv=6;class Wv{constructor(e){var r;const t=e.customStrengthOptions;this.customStrengthOptions={},this.customStrengthOptions.minPasswordLength=t.minPasswordLength??zv,t.maxPasswordLength&&(this.customStrengthOptions.maxPasswordLength=t.maxPasswordLength),t.containsLowercaseCharacter!==void 0&&(this.customStrengthOptions.containsLowercaseLetter=t.containsLowercaseCharacter),t.containsUppercaseCharacter!==void 0&&(this.customStrengthOptions.containsUppercaseLetter=t.containsUppercaseCharacter),t.containsNumericCharacter!==void 0&&(this.customStrengthOptions.containsNumericCharacter=t.containsNumericCharacter),t.containsNonAlphanumericCharacter!==void 0&&(this.customStrengthOptions.containsNonAlphanumericCharacter=t.containsNonAlphanumericCharacter),this.enforcementState=e.enforcementState,this.enforcementState==="ENFORCEMENT_STATE_UNSPECIFIED"&&(this.enforcementState="OFF"),this.allowedNonAlphanumericCharacters=((r=e.allowedNonAlphanumericCharacters)==null?void 0:r.join(""))??"",this.forceUpgradeOnSignin=e.forceUpgradeOnSignin??!1,this.schemaVersion=e.schemaVersion}validatePassword(e){const t={isValid:!0,passwordPolicy:this};return this.validatePasswordLengthOptions(e,t),this.validatePasswordCharacterOptions(e,t),t.isValid&&(t.isValid=t.meetsMinPasswordLength??!0),t.isValid&&(t.isValid=t.meetsMaxPasswordLength??!0),t.isValid&&(t.isValid=t.containsLowercaseLetter??!0),t.isValid&&(t.isValid=t.containsUppercaseLetter??!0),t.isValid&&(t.isValid=t.containsNumericCharacter??!0),t.isValid&&(t.isValid=t.containsNonAlphanumericCharacter??!0),t}validatePasswordLengthOptions(e,t){const r=this.customStrengthOptions.minPasswordLength,i=this.customStrengthOptions.maxPasswordLength;r&&(t.meetsMinPasswordLength=e.length>=r),i&&(t.meetsMaxPasswordLength=e.length<=i)}validatePasswordCharacterOptions(e,t){this.updatePasswordCharacterOptionsStatuses(t,!1,!1,!1,!1);let r;for(let i=0;i<e.length;i++)r=e.charAt(i),this.updatePasswordCharacterOptionsStatuses(t,r>="a"&&r<="z",r>="A"&&r<="Z",r>="0"&&r<="9",this.allowedNonAlphanumericCharacters.includes(r))}updatePasswordCharacterOptionsStatuses(e,t,r,i,o){this.customStrengthOptions.containsLowercaseLetter&&(e.containsLowercaseLetter||(e.containsLowercaseLetter=t)),this.customStrengthOptions.containsUppercaseLetter&&(e.containsUppercaseLetter||(e.containsUppercaseLetter=r)),this.customStrengthOptions.containsNumericCharacter&&(e.containsNumericCharacter||(e.containsNumericCharacter=i)),this.customStrengthOptions.containsNonAlphanumericCharacter&&(e.containsNonAlphanumericCharacter||(e.containsNonAlphanumericCharacter=o))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Hv{constructor(e,t,r,i){this.app=e,this.heartbeatServiceProvider=t,this.appCheckServiceProvider=r,this.config=i,this.currentUser=null,this.emulatorConfig=null,this.operations=Promise.resolve(),this.authStateSubscription=new gh(this),this.idTokenSubscription=new gh(this),this.beforeStateQueue=new Bv(this),this.redirectUser=null,this.isProactiveRefreshEnabled=!1,this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION=1,this._canInitEmulator=!0,this._isInitialized=!1,this._deleted=!1,this._initializationPromise=null,this._popupRedirectResolver=null,this._errorFactory=lf,this._agentRecaptchaConfig=null,this._tenantRecaptchaConfigs={},this._projectPasswordPolicy=null,this._tenantPasswordPolicies={},this._resolvePersistenceManagerAvailable=void 0,this.lastNotifiedUid=void 0,this.languageCode=null,this.tenantId=null,this.settings={appVerificationDisabledForTesting:!1},this.frameworks=[],this.name=e.name,this.clientVersion=i.sdkClientVersion,this._persistenceManagerAvailable=new Promise(o=>this._resolvePersistenceManagerAvailable=o)}_initializeWithPersistence(e,t){return t&&(this._popupRedirectResolver=tn(t)),this._initializationPromise=this.queue(async()=>{var r,i,o;if(!this._deleted&&(this.persistenceManager=await qr.create(this,e),(r=this._resolvePersistenceManagerAvailable)==null||r.call(this),!this._deleted)){if((i=this._popupRedirectResolver)!=null&&i._shouldInitProactively)try{await this._popupRedirectResolver._initialize(this)}catch{}await this.initializeCurrentUser(t),this.lastNotifiedUid=((o=this.currentUser)==null?void 0:o.uid)||null,!this._deleted&&(this._isInitialized=!0)}}),this._initializationPromise}async _onStorageEvent(){if(this._deleted)return;const e=await this.assertedPersistence.getCurrentUser();if(!(!this.currentUser&&!e)){if(this.currentUser&&e&&this.currentUser.uid===e.uid){this._currentUser._assign(e),await this.currentUser.getIdToken();return}await this._updateCurrentUser(e,!0)}}async initializeCurrentUserFromIdToken(e){try{const t=await Cs(this,{idToken:e}),r=await Tt._fromGetAccountInfoResponse(this,t,e);await this.directlySetCurrentUser(r)}catch(t){console.warn("FirebaseServerApp could not login user with provided authIdToken: ",t),await this.directlySetCurrentUser(null)}}async initializeCurrentUser(e){var o;if(Nt(this.app)){const s=this.app.settings.authIdToken;return s?new Promise(l=>{setTimeout(()=>this.initializeCurrentUserFromIdToken(s).then(l,l))}):this.directlySetCurrentUser(null)}const t=await this.assertedPersistence.getCurrentUser();let r=t,i=!1;if(e&&this.config.authDomain){await this.getOrInitRedirectPersistenceManager();const s=(o=this.redirectUser)==null?void 0:o._redirectEventId,l=r==null?void 0:r._redirectEventId,u=await this.tryRedirectSignIn(e);(!s||s===l)&&(u!=null&&u.user)&&(r=u.user,i=!0)}if(!r)return this.directlySetCurrentUser(null);if(!r._redirectEventId){if(i)try{await this.beforeStateQueue.runMiddleware(r)}catch(s){r=t,this._popupRedirectResolver._overrideRedirectResult(this,()=>Promise.reject(s))}return r?this.reloadAndSetCurrentUserOrClear(r):this.directlySetCurrentUser(null)}return Y(this._popupRedirectResolver,this,"argument-error"),await this.getOrInitRedirectPersistenceManager(),this.redirectUser&&this.redirectUser._redirectEventId===r._redirectEventId?this.directlySetCurrentUser(r):this.reloadAndSetCurrentUserOrClear(r)}async tryRedirectSignIn(e){let t=null;try{t=await this._popupRedirectResolver._completeRedirectFn(this,e,!0)}catch{await this._setRedirectUser(null)}return t}async reloadAndSetCurrentUserOrClear(e){try{await Rs(e)}catch(t){if((t==null?void 0:t.code)!=="auth/network-request-failed")return this.directlySetCurrentUser(null)}return this.directlySetCurrentUser(e)}useDeviceLanguage(){this.languageCode=Sv()}async _delete(){this._deleted=!0}async updateCurrentUser(e){if(Nt(this.app))return Promise.reject(ur(this));const t=e?qe(e):null;return t&&Y(t.auth.config.apiKey===this.config.apiKey,this,"invalid-user-token"),this._updateCurrentUser(t&&t._clone(this))}async _updateCurrentUser(e,t=!1){if(!this._deleted)return e&&Y(this.tenantId===e.tenantId,this,"tenant-id-mismatch"),t||await this.beforeStateQueue.runMiddleware(e),this.queue(async()=>{await this.directlySetCurrentUser(e),this.notifyAuthListeners()})}async signOut(){return Nt(this.app)?Promise.reject(ur(this)):(await this.beforeStateQueue.runMiddleware(null),(this.redirectPersistenceManager||this._popupRedirectResolver)&&await this._setRedirectUser(null),this._updateCurrentUser(null,!0))}setPersistence(e){return Nt(this.app)?Promise.reject(ur(this)):this.queue(async()=>{await this.assertedPersistence.setPersistence(tn(e))})}_getRecaptchaConfig(){return this.tenantId==null?this._agentRecaptchaConfig:this._tenantRecaptchaConfigs[this.tenantId]}async validatePassword(e){this._getPasswordPolicyInternal()||await this._updatePasswordPolicy();const t=this._getPasswordPolicyInternal();return t.schemaVersion!==this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION?Promise.reject(this._errorFactory.create("unsupported-password-policy-schema-version",{})):t.validatePassword(e)}_getPasswordPolicyInternal(){return this.tenantId===null?this._projectPasswordPolicy:this._tenantPasswordPolicies[this.tenantId]}async _updatePasswordPolicy(){const e=await jv(this),t=new Wv(e);this.tenantId===null?this._projectPasswordPolicy=t:this._tenantPasswordPolicies[this.tenantId]=t}_getPersistenceType(){return this.assertedPersistence.persistence.type}_getPersistence(){return this.assertedPersistence.persistence}_updateErrorMap(e){this._errorFactory=new Ao("auth","Firebase",e())}onAuthStateChanged(e,t,r){return this.registerStateListener(this.authStateSubscription,e,t,r)}beforeAuthStateChanged(e,t){return this.beforeStateQueue.pushCallback(e,t)}onIdTokenChanged(e,t,r){return this.registerStateListener(this.idTokenSubscription,e,t,r)}authStateReady(){return new Promise((e,t)=>{if(this.currentUser)e();else{const r=this.onAuthStateChanged(()=>{r(),e()},t)}})}async revokeAccessToken(e){if(this.currentUser){const t=await this.currentUser.getIdToken(),r={providerId:"apple.com",tokenType:"ACCESS_TOKEN",token:e,idToken:t};this.tenantId!=null&&(r.tenantId=this.tenantId),await Uv(this,r)}}toJSON(){var e;return{apiKey:this.config.apiKey,authDomain:this.config.authDomain,appName:this.name,currentUser:(e=this._currentUser)==null?void 0:e.toJSON()}}async _setRedirectUser(e,t){const r=await this.getOrInitRedirectPersistenceManager(t);return e===null?r.removeCurrentUser():r.setCurrentUser(e)}async getOrInitRedirectPersistenceManager(e){if(!this.redirectPersistenceManager){const t=e&&tn(e)||this._popupRedirectResolver;Y(t,this,"argument-error"),this.redirectPersistenceManager=await qr.create(this,[tn(t._redirectPersistence)],"redirectUser"),this.redirectUser=await this.redirectPersistenceManager.getCurrentUser()}return this.redirectPersistenceManager}async _redirectUserForId(e){var t,r;return this._isInitialized&&await this.queue(async()=>{}),((t=this._currentUser)==null?void 0:t._redirectEventId)===e?this._currentUser:((r=this.redirectUser)==null?void 0:r._redirectEventId)===e?this.redirectUser:null}async _persistUserIfCurrent(e){if(e===this.currentUser)return this.queue(async()=>this.directlySetCurrentUser(e))}_notifyListenersIfCurrent(e){e===this.currentUser&&this.notifyAuthListeners()}_key(){return`${this.config.authDomain}:${this.config.apiKey}:${this.name}`}_startProactiveRefresh(){this.isProactiveRefreshEnabled=!0,this.currentUser&&this._currentUser._startProactiveRefresh()}_stopProactiveRefresh(){this.isProactiveRefreshEnabled=!1,this.currentUser&&this._currentUser._stopProactiveRefresh()}get _currentUser(){return this.currentUser}notifyAuthListeners(){var t;if(!this._isInitialized)return;this.idTokenSubscription.next(this.currentUser);const e=((t=this.currentUser)==null?void 0:t.uid)??null;this.lastNotifiedUid!==e&&(this.lastNotifiedUid=e,this.authStateSubscription.next(this.currentUser))}registerStateListener(e,t,r,i){if(this._deleted)return()=>{};const o=typeof t=="function"?t:t.next.bind(t);let s=!1;const l=this._isInitialized?Promise.resolve():this._initializationPromise;if(Y(l,this,"internal-error"),l.then(()=>{s||o(this.currentUser)}),typeof t=="function"){const u=e.addObserver(t,r,i);return()=>{s=!0,u()}}else{const u=e.addObserver(t);return()=>{s=!0,u()}}}async directlySetCurrentUser(e){this.currentUser&&this.currentUser!==e&&this._currentUser._stopProactiveRefresh(),e&&this.isProactiveRefreshEnabled&&e._startProactiveRefresh(),this.currentUser=e,e?await this.assertedPersistence.setCurrentUser(e):await this.assertedPersistence.removeCurrentUser()}queue(e){return this.operations=this.operations.then(e,e),this.operations}get assertedPersistence(){return Y(this.persistenceManager,this,"internal-error"),this.persistenceManager}_logFramework(e){!e||this.frameworks.includes(e)||(this.frameworks.push(e),this.frameworks.sort(),this.clientVersion=Ef(this.config.clientPlatform,this._getFrameworks()))}_getFrameworks(){return this.frameworks}async _getAdditionalHeaders(){var i;const e={"X-Client-Version":this.clientVersion};this.app.options.appId&&(e["X-Firebase-gmpid"]=this.app.options.appId);const t=await((i=this.heartbeatServiceProvider.getImmediate({optional:!0}))==null?void 0:i.getHeartbeatsHeader());t&&(e["X-Firebase-Client"]=t);const r=await this._getAppCheckToken();return r&&(e["X-Firebase-AppCheck"]=r),e}async _getAppCheckToken(){var t;if(Nt(this.app)&&this.app.settings.appCheckToken)return this.app.settings.appCheckToken;const e=await((t=this.appCheckServiceProvider.getImmediate({optional:!0}))==null?void 0:t.getToken());return e!=null&&e.error&&Ev(`Error while retrieving App Check token: ${e.error}`),e==null?void 0:e.token}}function ea(n){return qe(n)}class gh{constructor(e){this.auth=e,this.observer=null,this.addObserver=cy(t=>this.observer=t)}get next(){return Y(this.observer,this.auth,"internal-error"),this.observer.next.bind(this.observer)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let ec={async loadJS(){throw new Error("Unable to load external scripts")},recaptchaV2Script:"",recaptchaEnterpriseScript:"",gapiScript:""};function Gv(n){ec=n}function Kv(n){return ec.loadJS(n)}function Yv(){return ec.gapiScript}function Qv(n){return`__${n}${Math.floor(Math.random()*1e6)}`}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Jv(n,e){const t=Gl(n,"auth");if(t.isInitialized()){const i=t.getImmediate(),o=t.getOptions();if(gr(o,e??{}))return i;un(i,"already-initialized")}return t.initialize({options:e})}function Xv(n,e){const t=(e==null?void 0:e.persistence)||[],r=(Array.isArray(t)?t:[t]).map(tn);e!=null&&e.errorMap&&n._updateErrorMap(e.errorMap),n._initializeWithPersistence(r,e==null?void 0:e.popupRedirectResolver)}function Zv(n,e,t){const r=ea(n);Y(/^https?:\/\//.test(e),r,"invalid-emulator-scheme");const i=!1,o=If(e),{host:s,port:l}=e_(e),u=l===null?"":`:${l}`,d={url:`${o}//${s}${u}/`},p=Object.freeze({host:s,port:l,protocol:o.replace(":",""),options:Object.freeze({disableWarnings:i})});if(!r._canInitEmulator){Y(r.config.emulator&&r.emulatorConfig,r,"emulator-config-failed"),Y(gr(d,r.config.emulator)&&gr(p,r.emulatorConfig),r,"emulator-config-failed");return}r.config.emulator=d,r.emulatorConfig=p,r.settings.appVerificationDisabledForTesting=!0,xo(s)?ef(`${o}//${s}${u}`):t_()}function If(n){const e=n.indexOf(":");return e<0?"":n.substr(0,e+1)}function e_(n){const e=If(n),t=/(\/\/)?([^?#/]+)/.exec(n.substr(e.length));if(!t)return{host:"",port:null};const r=t[2].split("@").pop()||"",i=/^(\[[^\]]+\])(:|$)/.exec(r);if(i){const o=i[1];return{host:o,port:mh(r.substr(o.length+1))}}else{const[o,s]=r.split(":");return{host:o,port:mh(s)}}}function mh(n){if(!n)return null;const e=Number(n);return isNaN(e)?null:e}function t_(){function n(){const e=document.createElement("p"),t=e.style;e.innerText="Running in emulator mode. Do not use with production credentials.",t.position="fixed",t.width="100%",t.backgroundColor="#ffffff",t.border=".1em solid #000000",t.color="#b50000",t.bottom="0px",t.left="0px",t.margin="0px",t.zIndex="10000",t.textAlign="center",e.classList.add("firebase-emulator-warning"),document.body.appendChild(e)}typeof console<"u"&&typeof console.info=="function"&&console.info("WARNING: You are using the Auth Emulator, which is intended for local testing only.  Do not use with production credentials."),typeof window<"u"&&typeof document<"u"&&(document.readyState==="loading"?window.addEventListener("DOMContentLoaded",n):n())}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Af{constructor(e,t){this.providerId=e,this.signInMethod=t}toJSON(){return en("not implemented")}_getIdTokenResponse(e){return en("not implemented")}_linkToIdToken(e,t){return en("not implemented")}_getReauthenticationResolver(e){return en("not implemented")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function $r(n,e){return Cv(n,"POST","/v1/accounts:signInWithIdp",Jl(n,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const n_="http://localhost";class yr extends Af{constructor(){super(...arguments),this.pendingToken=null}static _fromParams(e){const t=new yr(e.providerId,e.signInMethod);return e.idToken||e.accessToken?(e.idToken&&(t.idToken=e.idToken),e.accessToken&&(t.accessToken=e.accessToken),e.nonce&&!e.pendingToken&&(t.nonce=e.nonce),e.pendingToken&&(t.pendingToken=e.pendingToken)):e.oauthToken&&e.oauthTokenSecret?(t.accessToken=e.oauthToken,t.secret=e.oauthTokenSecret):un("argument-error"),t}toJSON(){return{idToken:this.idToken,accessToken:this.accessToken,secret:this.secret,nonce:this.nonce,pendingToken:this.pendingToken,providerId:this.providerId,signInMethod:this.signInMethod}}static fromJSON(e){const t=typeof e=="string"?JSON.parse(e):e,{providerId:r,signInMethod:i,...o}=t;if(!r||!i)return null;const s=new yr(r,i);return s.idToken=o.idToken||void 0,s.accessToken=o.accessToken||void 0,s.secret=o.secret,s.nonce=o.nonce,s.pendingToken=o.pendingToken||null,s}_getIdTokenResponse(e){const t=this.buildRequest();return $r(e,t)}_linkToIdToken(e,t){const r=this.buildRequest();return r.idToken=t,$r(e,r)}_getReauthenticationResolver(e){const t=this.buildRequest();return t.autoCreate=!1,$r(e,t)}buildRequest(){const e={requestUri:n_,returnSecureToken:!0};if(this.pendingToken)e.pendingToken=this.pendingToken;else{const t={};this.idToken&&(t.id_token=this.idToken),this.accessToken&&(t.access_token=this.accessToken),this.secret&&(t.oauth_token_secret=this.secret),t.providerId=this.providerId,this.nonce&&!this.pendingToken&&(t.nonce=this.nonce),e.postBody=So(t)}return e}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Sf{constructor(e){this.providerId=e,this.defaultLanguageCode=null,this.customParameters={}}setDefaultLanguage(e){this.defaultLanguageCode=e}setCustomParameters(e){return this.customParameters=e,this}getCustomParameters(){return this.customParameters}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Po extends Sf{constructor(){super(...arguments),this.scopes=[]}addScope(e){return this.scopes.includes(e)||this.scopes.push(e),this}getScopes(){return[...this.scopes]}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Sn extends Po{constructor(){super("facebook.com")}static credential(e){return yr._fromParams({providerId:Sn.PROVIDER_ID,signInMethod:Sn.FACEBOOK_SIGN_IN_METHOD,accessToken:e})}static credentialFromResult(e){return Sn.credentialFromTaggedObject(e)}static credentialFromError(e){return Sn.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e||!("oauthAccessToken"in e)||!e.oauthAccessToken)return null;try{return Sn.credential(e.oauthAccessToken)}catch{return null}}}Sn.FACEBOOK_SIGN_IN_METHOD="facebook.com";Sn.PROVIDER_ID="facebook.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Xt extends Po{constructor(){super("google.com"),this.addScope("profile")}static credential(e,t){return yr._fromParams({providerId:Xt.PROVIDER_ID,signInMethod:Xt.GOOGLE_SIGN_IN_METHOD,idToken:e,accessToken:t})}static credentialFromResult(e){return Xt.credentialFromTaggedObject(e)}static credentialFromError(e){return Xt.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e)return null;const{oauthIdToken:t,oauthAccessToken:r}=e;if(!t&&!r)return null;try{return Xt.credential(t,r)}catch{return null}}}Xt.GOOGLE_SIGN_IN_METHOD="google.com";Xt.PROVIDER_ID="google.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xn extends Po{constructor(){super("github.com")}static credential(e){return yr._fromParams({providerId:xn.PROVIDER_ID,signInMethod:xn.GITHUB_SIGN_IN_METHOD,accessToken:e})}static credentialFromResult(e){return xn.credentialFromTaggedObject(e)}static credentialFromError(e){return xn.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e||!("oauthAccessToken"in e)||!e.oauthAccessToken)return null;try{return xn.credential(e.oauthAccessToken)}catch{return null}}}xn.GITHUB_SIGN_IN_METHOD="github.com";xn.PROVIDER_ID="github.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class kn extends Po{constructor(){super("twitter.com")}static credential(e,t){return yr._fromParams({providerId:kn.PROVIDER_ID,signInMethod:kn.TWITTER_SIGN_IN_METHOD,oauthToken:e,oauthTokenSecret:t})}static credentialFromResult(e){return kn.credentialFromTaggedObject(e)}static credentialFromError(e){return kn.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e)return null;const{oauthAccessToken:t,oauthTokenSecret:r}=e;if(!t||!r)return null;try{return kn.credential(t,r)}catch{return null}}}kn.TWITTER_SIGN_IN_METHOD="twitter.com";kn.PROVIDER_ID="twitter.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ei{constructor(e){this.user=e.user,this.providerId=e.providerId,this._tokenResponse=e._tokenResponse,this.operationType=e.operationType}static async _fromIdTokenResponse(e,t,r,i=!1){const o=await Tt._fromIdTokenResponse(e,r,i),s=yh(r);return new ei({user:o,providerId:s,_tokenResponse:r,operationType:t})}static async _forOperation(e,t,r){await e._updateTokensIfNecessary(r,!0);const i=yh(r);return new ei({user:e,providerId:i,_tokenResponse:r,operationType:t})}}function yh(n){return n.providerId?n.providerId:"phoneNumber"in n?"phone":null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Os extends mn{constructor(e,t,r,i){super(t.code,t.message),this.operationType=r,this.user=i,Object.setPrototypeOf(this,Os.prototype),this.customData={appName:e.name,tenantId:e.tenantId??void 0,_serverResponse:t.customData._serverResponse,operationType:r}}static _fromErrorAndOperation(e,t,r,i){return new Os(e,t,r,i)}}function xf(n,e,t,r){return(e==="reauthenticate"?t._getReauthenticationResolver(n):t._getIdTokenResponse(n)).catch(o=>{throw o.code==="auth/multi-factor-auth-required"?Os._fromErrorAndOperation(n,o,e,r):o})}async function r_(n,e,t=!1){const r=await co(n,e._linkToIdToken(n.auth,await n.getIdToken()),t);return ei._forOperation(n,"link",r)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function i_(n,e,t=!1){const{auth:r}=n;if(Nt(r.app))return Promise.reject(ur(r));const i="reauthenticate";try{const o=await co(n,xf(r,i,e,n),t);Y(o.idToken,r,"internal-error");const s=Xl(o.idToken);Y(s,r,"internal-error");const{sub:l}=s;return Y(n.uid===l,r,"user-mismatch"),ei._forOperation(n,i,o)}catch(o){throw(o==null?void 0:o.code)==="auth/user-not-found"&&un(r,"user-mismatch"),o}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function kf(n,e,t=!1){if(Nt(n.app))return Promise.reject(ur(n));const r="signIn",i=await xf(n,r,e),o=await ei._fromIdTokenResponse(n,r,i);return t||await n._updateCurrentUser(o.user),o}async function o_(n,e){return kf(ea(n),e)}function s_(n,e,t,r){return qe(n).onIdTokenChanged(e,t,r)}function a_(n,e,t){return qe(n).beforeAuthStateChanged(e,t)}function l_(n,e,t,r){return qe(n).onAuthStateChanged(e,t,r)}function c_(n){return qe(n).signOut()}const Ns="__sak";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Pf{constructor(e,t){this.storageRetriever=e,this.type=t}_isAvailable(){try{return this.storage?(this.storage.setItem(Ns,"1"),this.storage.removeItem(Ns),Promise.resolve(!0)):Promise.resolve(!1)}catch{return Promise.resolve(!1)}}_set(e,t){return this.storage.setItem(e,JSON.stringify(t)),Promise.resolve()}_get(e){const t=this.storage.getItem(e);return Promise.resolve(t?JSON.parse(t):null)}_remove(e){return this.storage.removeItem(e),Promise.resolve()}get storage(){return this.storageRetriever()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const u_=1e3,h_=10;class Cf extends Pf{constructor(){super(()=>window.localStorage,"LOCAL"),this.boundEventHandler=(e,t)=>this.onStorageEvent(e,t),this.listeners={},this.localCache={},this.pollTimer=null,this.fallbackToPolling=Tf(),this._shouldAllowMigration=!0}forAllChangedKeys(e){for(const t of Object.keys(this.listeners)){const r=this.storage.getItem(t),i=this.localCache[t];r!==i&&e(t,i,r)}}onStorageEvent(e,t=!1){if(!e.key){this.forAllChangedKeys((s,l,u)=>{this.notifyListeners(s,u)});return}const r=e.key;t?this.detachListener():this.stopPolling();const i=()=>{const s=this.storage.getItem(r);!t&&this.localCache[r]===s||this.notifyListeners(r,s)},o=this.storage.getItem(r);$v()&&o!==e.newValue&&e.newValue!==e.oldValue?setTimeout(i,h_):i()}notifyListeners(e,t){this.localCache[e]=t;const r=this.listeners[e];if(r)for(const i of Array.from(r))i(t&&JSON.parse(t))}startPolling(){this.stopPolling(),this.pollTimer=setInterval(()=>{this.forAllChangedKeys((e,t,r)=>{this.onStorageEvent(new StorageEvent("storage",{key:e,oldValue:t,newValue:r}),!0)})},u_)}stopPolling(){this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}attachListener(){window.addEventListener("storage",this.boundEventHandler)}detachListener(){window.removeEventListener("storage",this.boundEventHandler)}_addListener(e,t){Object.keys(this.listeners).length===0&&(this.fallbackToPolling?this.startPolling():this.attachListener()),this.listeners[e]||(this.listeners[e]=new Set,this.localCache[e]=this.storage.getItem(e)),this.listeners[e].add(t)}_removeListener(e,t){this.listeners[e]&&(this.listeners[e].delete(t),this.listeners[e].size===0&&delete this.listeners[e]),Object.keys(this.listeners).length===0&&(this.detachListener(),this.stopPolling())}async _set(e,t){await super._set(e,t),this.localCache[e]=JSON.stringify(t)}async _get(e){const t=await super._get(e);return this.localCache[e]=JSON.stringify(t),t}async _remove(e){await super._remove(e),delete this.localCache[e]}}Cf.type="LOCAL";const d_=Cf;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Rf extends Pf{constructor(){super(()=>window.sessionStorage,"SESSION")}_addListener(e,t){}_removeListener(e,t){}}Rf.type="SESSION";const Of=Rf;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function f_(n){return Promise.all(n.map(async e=>{try{return{fulfilled:!0,value:await e}}catch(t){return{fulfilled:!1,reason:t}}}))}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ta{constructor(e){this.eventTarget=e,this.handlersMap={},this.boundEventHandler=this.handleEvent.bind(this)}static _getInstance(e){const t=this.receivers.find(i=>i.isListeningto(e));if(t)return t;const r=new ta(e);return this.receivers.push(r),r}isListeningto(e){return this.eventTarget===e}async handleEvent(e){const t=e,{eventId:r,eventType:i,data:o}=t.data,s=this.handlersMap[i];if(!(s!=null&&s.size))return;t.ports[0].postMessage({status:"ack",eventId:r,eventType:i});const l=Array.from(s).map(async d=>d(t.origin,o)),u=await f_(l);t.ports[0].postMessage({status:"done",eventId:r,eventType:i,response:u})}_subscribe(e,t){Object.keys(this.handlersMap).length===0&&this.eventTarget.addEventListener("message",this.boundEventHandler),this.handlersMap[e]||(this.handlersMap[e]=new Set),this.handlersMap[e].add(t)}_unsubscribe(e,t){this.handlersMap[e]&&t&&this.handlersMap[e].delete(t),(!t||this.handlersMap[e].size===0)&&delete this.handlersMap[e],Object.keys(this.handlersMap).length===0&&this.eventTarget.removeEventListener("message",this.boundEventHandler)}}ta.receivers=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function tc(n="",e=10){let t="";for(let r=0;r<e;r++)t+=Math.floor(Math.random()*10);return n+t}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class p_{constructor(e){this.target=e,this.handlers=new Set}removeMessageHandler(e){e.messageChannel&&(e.messageChannel.port1.removeEventListener("message",e.onMessage),e.messageChannel.port1.close()),this.handlers.delete(e)}async _send(e,t,r=50){const i=typeof MessageChannel<"u"?new MessageChannel:null;if(!i)throw new Error("connection_unavailable");let o,s;return new Promise((l,u)=>{const d=tc("",20);i.port1.start();const p=setTimeout(()=>{u(new Error("unsupported_event"))},r);s={messageChannel:i,onMessage(m){const g=m;if(g.data.eventId===d)switch(g.data.status){case"ack":clearTimeout(p),o=setTimeout(()=>{u(new Error("timeout"))},3e3);break;case"done":clearTimeout(o),l(g.data.response);break;default:clearTimeout(p),clearTimeout(o),u(new Error("invalid_response"));break}}},this.handlers.add(s),i.port1.addEventListener("message",s.onMessage),this.target.postMessage({eventType:e,eventId:d,data:t},[i.port2])}).finally(()=>{s&&this.removeMessageHandler(s)})}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function qt(){return window}function g_(n){qt().location.href=n}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Nf(){return typeof qt().WorkerGlobalScope<"u"&&typeof qt().importScripts=="function"}async function m_(){if(!(navigator!=null&&navigator.serviceWorker))return null;try{return(await navigator.serviceWorker.ready).active}catch{return null}}function y_(){var n;return((n=navigator==null?void 0:navigator.serviceWorker)==null?void 0:n.controller)||null}function v_(){return Nf()?self:null}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Df="firebaseLocalStorageDb",__=1,Ds="firebaseLocalStorage",Lf="fbase_key";class Co{constructor(e){this.request=e}toPromise(){return new Promise((e,t)=>{this.request.addEventListener("success",()=>{e(this.request.result)}),this.request.addEventListener("error",()=>{t(this.request.error)})})}}function na(n,e){return n.transaction([Ds],e?"readwrite":"readonly").objectStore(Ds)}function w_(){const n=indexedDB.deleteDatabase(Df);return new Co(n).toPromise()}function ml(){const n=indexedDB.open(Df,__);return new Promise((e,t)=>{n.addEventListener("error",()=>{t(n.error)}),n.addEventListener("upgradeneeded",()=>{const r=n.result;try{r.createObjectStore(Ds,{keyPath:Lf})}catch(i){t(i)}}),n.addEventListener("success",async()=>{const r=n.result;r.objectStoreNames.contains(Ds)?e(r):(r.close(),await w_(),e(await ml()))})})}async function vh(n,e,t){const r=na(n,!0).put({[Lf]:e,value:t});return new Co(r).toPromise()}async function b_(n,e){const t=na(n,!1).get(e),r=await new Co(t).toPromise();return r===void 0?null:r.value}function _h(n,e){const t=na(n,!0).delete(e);return new Co(t).toPromise()}const T_=800,E_=3;class Mf{constructor(){this.type="LOCAL",this._shouldAllowMigration=!0,this.listeners={},this.localCache={},this.pollTimer=null,this.pendingWrites=0,this.receiver=null,this.sender=null,this.serviceWorkerReceiverAvailable=!1,this.activeServiceWorker=null,this._workerInitializationPromise=this.initializeServiceWorkerMessaging().then(()=>{},()=>{})}async _openDb(){return this.db?this.db:(this.db=await ml(),this.db)}async _withRetries(e){let t=0;for(;;)try{const r=await this._openDb();return await e(r)}catch(r){if(t++>E_)throw r;this.db&&(this.db.close(),this.db=void 0)}}async initializeServiceWorkerMessaging(){return Nf()?this.initializeReceiver():this.initializeSender()}async initializeReceiver(){this.receiver=ta._getInstance(v_()),this.receiver._subscribe("keyChanged",async(e,t)=>({keyProcessed:(await this._poll()).includes(t.key)})),this.receiver._subscribe("ping",async(e,t)=>["keyChanged"])}async initializeSender(){var t,r;if(this.activeServiceWorker=await m_(),!this.activeServiceWorker)return;this.sender=new p_(this.activeServiceWorker);const e=await this.sender._send("ping",{},800);e&&(t=e[0])!=null&&t.fulfilled&&(r=e[0])!=null&&r.value.includes("keyChanged")&&(this.serviceWorkerReceiverAvailable=!0)}async notifyServiceWorker(e){if(!(!this.sender||!this.activeServiceWorker||y_()!==this.activeServiceWorker))try{await this.sender._send("keyChanged",{key:e},this.serviceWorkerReceiverAvailable?800:50)}catch{}}async _isAvailable(){try{if(!indexedDB)return!1;const e=await ml();return await vh(e,Ns,"1"),await _h(e,Ns),!0}catch{}return!1}async _withPendingWrite(e){this.pendingWrites++;try{await e()}finally{this.pendingWrites--}}async _set(e,t){return this._withPendingWrite(async()=>(await this._withRetries(r=>vh(r,e,t)),this.localCache[e]=t,this.notifyServiceWorker(e)))}async _get(e){const t=await this._withRetries(r=>b_(r,e));return this.localCache[e]=t,t}async _remove(e){return this._withPendingWrite(async()=>(await this._withRetries(t=>_h(t,e)),delete this.localCache[e],this.notifyServiceWorker(e)))}async _poll(){const e=await this._withRetries(i=>{const o=na(i,!1).getAll();return new Co(o).toPromise()});if(!e)return[];if(this.pendingWrites!==0)return[];const t=[],r=new Set;if(e.length!==0)for(const{fbase_key:i,value:o}of e)r.add(i),JSON.stringify(this.localCache[i])!==JSON.stringify(o)&&(this.notifyListeners(i,o),t.push(i));for(const i of Object.keys(this.localCache))this.localCache[i]&&!r.has(i)&&(this.notifyListeners(i,null),t.push(i));return t}notifyListeners(e,t){this.localCache[e]=t;const r=this.listeners[e];if(r)for(const i of Array.from(r))i(t)}startPolling(){this.stopPolling(),this.pollTimer=setInterval(async()=>this._poll(),T_)}stopPolling(){this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}_addListener(e,t){Object.keys(this.listeners).length===0&&this.startPolling(),this.listeners[e]||(this.listeners[e]=new Set,this._get(e)),this.listeners[e].add(t)}_removeListener(e,t){this.listeners[e]&&(this.listeners[e].delete(t),this.listeners[e].size===0&&delete this.listeners[e]),Object.keys(this.listeners).length===0&&this.stopPolling()}}Mf.type="LOCAL";const I_=Mf;new ko(3e4,6e4);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function A_(n,e){return e?tn(e):(Y(n._popupRedirectResolver,n,"argument-error"),n._popupRedirectResolver)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class nc extends Af{constructor(e){super("custom","custom"),this.params=e}_getIdTokenResponse(e){return $r(e,this._buildIdpRequest())}_linkToIdToken(e,t){return $r(e,this._buildIdpRequest(t))}_getReauthenticationResolver(e){return $r(e,this._buildIdpRequest())}_buildIdpRequest(e){const t={requestUri:this.params.requestUri,sessionId:this.params.sessionId,postBody:this.params.postBody,tenantId:this.params.tenantId,pendingToken:this.params.pendingToken,returnSecureToken:!0,returnIdpCredential:!0};return e&&(t.idToken=e),t}}function S_(n){return kf(n.auth,new nc(n),n.bypassAuthState)}function x_(n){const{auth:e,user:t}=n;return Y(t,e,"internal-error"),i_(t,new nc(n),n.bypassAuthState)}async function k_(n){const{auth:e,user:t}=n;return Y(t,e,"internal-error"),r_(t,new nc(n),n.bypassAuthState)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Vf{constructor(e,t,r,i,o=!1){this.auth=e,this.resolver=r,this.user=i,this.bypassAuthState=o,this.pendingPromise=null,this.eventManager=null,this.filter=Array.isArray(t)?t:[t]}execute(){return new Promise(async(e,t)=>{this.pendingPromise={resolve:e,reject:t};try{this.eventManager=await this.resolver._initialize(this.auth),await this.onExecution(),this.eventManager.registerConsumer(this)}catch(r){this.reject(r)}})}async onAuthEvent(e){const{urlResponse:t,sessionId:r,postBody:i,tenantId:o,error:s,type:l}=e;if(s){this.reject(s);return}const u={auth:this.auth,requestUri:t,sessionId:r,tenantId:o||void 0,postBody:i||void 0,user:this.user,bypassAuthState:this.bypassAuthState};try{this.resolve(await this.getIdpTask(l)(u))}catch(d){this.reject(d)}}onError(e){this.reject(e)}getIdpTask(e){switch(e){case"signInViaPopup":case"signInViaRedirect":return S_;case"linkViaPopup":case"linkViaRedirect":return k_;case"reauthViaPopup":case"reauthViaRedirect":return x_;default:un(this.auth,"internal-error")}}resolve(e){hn(this.pendingPromise,"Pending promise was never set"),this.pendingPromise.resolve(e),this.unregisterAndCleanUp()}reject(e){hn(this.pendingPromise,"Pending promise was never set"),this.pendingPromise.reject(e),this.unregisterAndCleanUp()}unregisterAndCleanUp(){this.eventManager&&this.eventManager.unregisterConsumer(this),this.pendingPromise=null,this.cleanUp()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const P_=new ko(2e3,1e4);class Mr extends Vf{constructor(e,t,r,i,o){super(e,t,i,o),this.provider=r,this.authWindow=null,this.pollId=null,Mr.currentPopupAction&&Mr.currentPopupAction.cancel(),Mr.currentPopupAction=this}async executeNotNull(){const e=await this.execute();return Y(e,this.auth,"internal-error"),e}async onExecution(){hn(this.filter.length===1,"Popup operations only handle one event");const e=tc();this.authWindow=await this.resolver._openPopup(this.auth,this.provider,this.filter[0],e),this.authWindow.associatedEvent=e,this.resolver._originValidation(this.auth).catch(t=>{this.reject(t)}),this.resolver._isIframeWebStorageSupported(this.auth,t=>{t||this.reject(Ut(this.auth,"web-storage-unsupported"))}),this.pollUserCancellation()}get eventId(){var e;return((e=this.authWindow)==null?void 0:e.associatedEvent)||null}cancel(){this.reject(Ut(this.auth,"cancelled-popup-request"))}cleanUp(){this.authWindow&&this.authWindow.close(),this.pollId&&window.clearTimeout(this.pollId),this.authWindow=null,this.pollId=null,Mr.currentPopupAction=null}pollUserCancellation(){const e=()=>{var t,r;if((r=(t=this.authWindow)==null?void 0:t.window)!=null&&r.closed){this.pollId=window.setTimeout(()=>{this.pollId=null,this.reject(Ut(this.auth,"popup-closed-by-user"))},8e3);return}this.pollId=window.setTimeout(e,P_.get())};e()}}Mr.currentPopupAction=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const C_="pendingRedirect",gs=new Map;class R_ extends Vf{constructor(e,t,r=!1){super(e,["signInViaRedirect","linkViaRedirect","reauthViaRedirect","unknown"],t,void 0,r),this.eventId=null}async execute(){let e=gs.get(this.auth._key());if(!e){try{const r=await O_(this.resolver,this.auth)?await super.execute():null;e=()=>Promise.resolve(r)}catch(t){e=()=>Promise.reject(t)}gs.set(this.auth._key(),e)}return this.bypassAuthState||gs.set(this.auth._key(),()=>Promise.resolve(null)),e()}async onAuthEvent(e){if(e.type==="signInViaRedirect")return super.onAuthEvent(e);if(e.type==="unknown"){this.resolve(null);return}if(e.eventId){const t=await this.auth._redirectUserForId(e.eventId);if(t)return this.user=t,super.onAuthEvent(e);this.resolve(null)}}async onExecution(){}cleanUp(){}}async function O_(n,e){const t=L_(e),r=D_(n);if(!await r._isAvailable())return!1;const i=await r._get(t)==="true";return await r._remove(t),i}function N_(n,e){gs.set(n._key(),e)}function D_(n){return tn(n._redirectPersistence)}function L_(n){return ps(C_,n.config.apiKey,n.name)}async function M_(n,e,t=!1){if(Nt(n.app))return Promise.reject(ur(n));const r=ea(n),i=A_(r,e),s=await new R_(r,i,t).execute();return s&&!t&&(delete s.user._redirectEventId,await r._persistUserIfCurrent(s.user),await r._setRedirectUser(null,e)),s}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const V_=10*60*1e3;class F_{constructor(e){this.auth=e,this.cachedEventUids=new Set,this.consumers=new Set,this.queuedRedirectEvent=null,this.hasHandledPotentialRedirect=!1,this.lastProcessedEventTime=Date.now()}registerConsumer(e){this.consumers.add(e),this.queuedRedirectEvent&&this.isEventForConsumer(this.queuedRedirectEvent,e)&&(this.sendToConsumer(this.queuedRedirectEvent,e),this.saveEventToCache(this.queuedRedirectEvent),this.queuedRedirectEvent=null)}unregisterConsumer(e){this.consumers.delete(e)}onEvent(e){if(this.hasEventBeenHandled(e))return!1;let t=!1;return this.consumers.forEach(r=>{this.isEventForConsumer(e,r)&&(t=!0,this.sendToConsumer(e,r),this.saveEventToCache(e))}),this.hasHandledPotentialRedirect||!U_(e)||(this.hasHandledPotentialRedirect=!0,t||(this.queuedRedirectEvent=e,t=!0)),t}sendToConsumer(e,t){var r;if(e.error&&!Ff(e)){const i=((r=e.error.code)==null?void 0:r.split("auth/")[1])||"internal-error";t.onError(Ut(this.auth,i))}else t.onAuthEvent(e)}isEventForConsumer(e,t){const r=t.eventId===null||!!e.eventId&&e.eventId===t.eventId;return t.filter.includes(e.type)&&r}hasEventBeenHandled(e){return Date.now()-this.lastProcessedEventTime>=V_&&this.cachedEventUids.clear(),this.cachedEventUids.has(wh(e))}saveEventToCache(e){this.cachedEventUids.add(wh(e)),this.lastProcessedEventTime=Date.now()}}function wh(n){return[n.type,n.eventId,n.sessionId,n.tenantId].filter(e=>e).join("-")}function Ff({type:n,error:e}){return n==="unknown"&&(e==null?void 0:e.code)==="auth/no-auth-event"}function U_(n){switch(n.type){case"signInViaRedirect":case"linkViaRedirect":case"reauthViaRedirect":return!0;case"unknown":return Ff(n);default:return!1}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function q_(n,e={}){return gi(n,"GET","/v1/projects",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const $_=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,B_=/^https?/;async function j_(n){if(n.config.emulator)return;const{authorizedDomains:e}=await q_(n);for(const t of e)try{if(z_(t))return}catch{}un(n,"unauthorized-domain")}function z_(n){const e=pl(),{protocol:t,hostname:r}=new URL(e);if(n.startsWith("chrome-extension://")){const s=new URL(n);return s.hostname===""&&r===""?t==="chrome-extension:"&&n.replace("chrome-extension://","")===e.replace("chrome-extension://",""):t==="chrome-extension:"&&s.hostname===r}if(!B_.test(t))return!1;if($_.test(n))return r===n;const i=n.replace(/\./g,"\\.");return new RegExp("^(.+\\."+i+"|"+i+")$","i").test(r)}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const W_=new ko(3e4,6e4);function bh(){const n=qt().___jsl;if(n!=null&&n.H){for(const e of Object.keys(n.H))if(n.H[e].r=n.H[e].r||[],n.H[e].L=n.H[e].L||[],n.H[e].r=[...n.H[e].L],n.CP)for(let t=0;t<n.CP.length;t++)n.CP[t]=null}}function H_(n){return new Promise((e,t)=>{var i,o,s;function r(){bh(),gapi.load("gapi.iframes",{callback:()=>{e(gapi.iframes.getContext())},ontimeout:()=>{bh(),t(Ut(n,"network-request-failed"))},timeout:W_.get()})}if((o=(i=qt().gapi)==null?void 0:i.iframes)!=null&&o.Iframe)e(gapi.iframes.getContext());else if((s=qt().gapi)!=null&&s.load)r();else{const l=Qv("iframefcb");return qt()[l]=()=>{gapi.load?r():t(Ut(n,"network-request-failed"))},Kv(`${Yv()}?onload=${l}`).catch(u=>t(u))}}).catch(e=>{throw ms=null,e})}let ms=null;function G_(n){return ms=ms||H_(n),ms}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const K_=new ko(5e3,15e3),Y_="__/auth/iframe",Q_="emulator/auth/iframe",J_={style:{position:"absolute",top:"-100px",width:"1px",height:"1px"},"aria-hidden":"true",tabindex:"-1"},X_=new Map([["identitytoolkit.googleapis.com","p"],["staging-identitytoolkit.sandbox.googleapis.com","s"],["test-identitytoolkit.sandbox.googleapis.com","t"]]);function Z_(n){const e=n.config;Y(e.authDomain,n,"auth-domain-config-required");const t=e.emulator?Ql(e,Q_):`https://${n.config.authDomain}/${Y_}`,r={apiKey:e.apiKey,appName:n.name,v:pi},i=X_.get(n.config.apiHost);i&&(r.eid=i);const o=n._getFrameworks();return o.length&&(r.fw=o.join(",")),`${t}?${So(r).slice(1)}`}async function ew(n){const e=await G_(n),t=qt().gapi;return Y(t,n,"internal-error"),e.open({where:document.body,url:Z_(n),messageHandlersFilter:t.iframes.CROSS_ORIGIN_IFRAMES_FILTER,attributes:J_,dontclear:!0},r=>new Promise(async(i,o)=>{await r.restyle({setHideOnLeave:!1});const s=Ut(n,"network-request-failed"),l=qt().setTimeout(()=>{o(s)},K_.get());function u(){qt().clearTimeout(l),i(r)}r.ping(u).then(u,()=>{o(s)})}))}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const tw={location:"yes",resizable:"yes",statusbar:"yes",toolbar:"no"},nw=500,rw=600,iw="_blank",ow="http://localhost";class Th{constructor(e){this.window=e,this.associatedEvent=null}close(){if(this.window)try{this.window.close()}catch{}}}function sw(n,e,t,r=nw,i=rw){const o=Math.max((window.screen.availHeight-i)/2,0).toString(),s=Math.max((window.screen.availWidth-r)/2,0).toString();let l="";const u={...tw,width:r.toString(),height:i.toString(),top:o,left:s},d=Ye().toLowerCase();t&&(l=yf(d)?iw:t),gf(d)&&(e=e||ow,u.scrollbars="yes");const p=Object.entries(u).reduce((g,[b,O])=>`${g}${b}=${O},`,"");if(qv(d)&&l!=="_self")return aw(e||"",l),new Th(null);const m=window.open(e||"",l,p);Y(m,n,"popup-blocked");try{m.focus()}catch{}return new Th(m)}function aw(n,e){const t=document.createElement("a");t.href=n,t.target=e;const r=document.createEvent("MouseEvent");r.initMouseEvent("click",!0,!0,window,1,0,0,0,0,!1,!1,!1,!1,1,null),t.dispatchEvent(r)}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const lw="__/auth/handler",cw="emulator/auth/handler",uw=encodeURIComponent("fac");async function Eh(n,e,t,r,i,o){Y(n.config.authDomain,n,"auth-domain-config-required"),Y(n.config.apiKey,n,"invalid-api-key");const s={apiKey:n.config.apiKey,appName:n.name,authType:t,redirectUrl:r,v:pi,eventId:i};if(e instanceof Sf){e.setDefaultLanguage(n.languageCode),s.providerId=e.providerId||"",ly(e.getCustomParameters())||(s.customParameters=JSON.stringify(e.getCustomParameters()));for(const[p,m]of Object.entries({}))s[p]=m}if(e instanceof Po){const p=e.getScopes().filter(m=>m!=="");p.length>0&&(s.scopes=p.join(","))}n.tenantId&&(s.tid=n.tenantId);const l=s;for(const p of Object.keys(l))l[p]===void 0&&delete l[p];const u=await n._getAppCheckToken(),d=u?`#${uw}=${encodeURIComponent(u)}`:"";return`${hw(n)}?${So(l).slice(1)}${d}`}function hw({config:n}){return n.emulator?Ql(n,cw):`https://${n.authDomain}/${lw}`}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ya="webStorageSupport";class dw{constructor(){this.eventManagers={},this.iframes={},this.originValidationPromises={},this._redirectPersistence=Of,this._completeRedirectFn=M_,this._overrideRedirectResult=N_}async _openPopup(e,t,r,i){var s;hn((s=this.eventManagers[e._key()])==null?void 0:s.manager,"_initialize() not called before _openPopup()");const o=await Eh(e,t,r,pl(),i);return sw(e,o,tc())}async _openRedirect(e,t,r,i){await this._originValidation(e);const o=await Eh(e,t,r,pl(),i);return g_(o),new Promise(()=>{})}_initialize(e){const t=e._key();if(this.eventManagers[t]){const{manager:i,promise:o}=this.eventManagers[t];return i?Promise.resolve(i):(hn(o,"If manager is not set, promise should be"),o)}const r=this.initAndGetManager(e);return this.eventManagers[t]={promise:r},r.catch(()=>{delete this.eventManagers[t]}),r}async initAndGetManager(e){const t=await ew(e),r=new F_(e);return t.register("authEvent",i=>(Y(i==null?void 0:i.authEvent,e,"invalid-auth-event"),{status:r.onEvent(i.authEvent)?"ACK":"ERROR"}),gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER),this.eventManagers[e._key()]={manager:r},this.iframes[e._key()]=t,r}_isIframeWebStorageSupported(e,t){this.iframes[e._key()].send(Ya,{type:Ya},i=>{var s;const o=(s=i==null?void 0:i[0])==null?void 0:s[Ya];o!==void 0&&t(!!o),un(e,"internal-error")},gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER)}_originValidation(e){const t=e._key();return this.originValidationPromises[t]||(this.originValidationPromises[t]=j_(e)),this.originValidationPromises[t]}get _shouldInitProactively(){return Tf()||mf()||Zl()}}const fw=dw;var Ih="@firebase/auth",Ah="1.13.0";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class pw{constructor(e){this.auth=e,this.internalListeners=new Map}getUid(){var e;return this.assertAuthConfigured(),((e=this.auth.currentUser)==null?void 0:e.uid)||null}async getToken(e){return this.assertAuthConfigured(),await this.auth._initializationPromise,this.auth.currentUser?{accessToken:await this.auth.currentUser.getIdToken(e)}:null}addAuthTokenListener(e){if(this.assertAuthConfigured(),this.internalListeners.has(e))return;const t=this.auth.onIdTokenChanged(r=>{e((r==null?void 0:r.stsTokenManager.accessToken)||null)});this.internalListeners.set(e,t),this.updateProactiveRefresh()}removeAuthTokenListener(e){this.assertAuthConfigured();const t=this.internalListeners.get(e);t&&(this.internalListeners.delete(e),t(),this.updateProactiveRefresh())}assertAuthConfigured(){Y(this.auth._initializationPromise,"dependent-sdk-initialized-before-auth")}updateProactiveRefresh(){this.internalListeners.size>0?this.auth._startProactiveRefresh():this.auth._stopProactiveRefresh()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function gw(n){switch(n){case"Node":return"node";case"ReactNative":return"rn";case"Worker":return"webworker";case"Cordova":return"cordova";case"WebExtension":return"web-extension";default:return}}function mw(n){Zr(new mr("auth",(e,{options:t})=>{const r=e.getProvider("app").getImmediate(),i=e.getProvider("heartbeat"),o=e.getProvider("app-check-internal"),{apiKey:s,authDomain:l}=r.options;Y(s&&!s.includes(":"),"invalid-api-key",{appName:r.name});const u={apiKey:s,authDomain:l,clientPlatform:n,apiHost:"identitytoolkit.googleapis.com",tokenApiHost:"securetoken.googleapis.com",apiScheme:"https",sdkClientVersion:Ef(n)},d=new Hv(r,i,o,u);return Xv(d,t),d},"PUBLIC").setInstantiationMode("EXPLICIT").setInstanceCreatedCallback((e,t,r)=>{e.getProvider("auth-internal").initialize()})),Zr(new mr("auth-internal",e=>{const t=ea(e.getProvider("auth").getImmediate());return(r=>new pw(r))(t)},"PRIVATE").setInstantiationMode("EXPLICIT")),Vn(Ih,Ah,gw(n)),Vn(Ih,Ah,"esm2020")}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const yw=5*60,vw=Zd("authIdTokenMaxAge")||yw;let Sh=null;const _w=n=>async e=>{const t=e&&await e.getIdTokenResult(),r=t&&(new Date().getTime()-Date.parse(t.issuedAtTime))/1e3;if(r&&r>vw)return;const i=t==null?void 0:t.token;Sh!==i&&(Sh=i,await fetch(n,{method:i?"POST":"DELETE",headers:i?{Authorization:`Bearer ${i}`}:{}}))};function ww(n=rf()){const e=Gl(n,"auth");if(e.isInitialized())return e.getImmediate();const t=Jv(n,{popupRedirectResolver:fw,persistence:[I_,d_,Of]}),r=Zd("authTokenSyncURL");if(r&&typeof isSecureContext=="boolean"&&isSecureContext){const o=new URL(r,location.origin);if(location.origin===o.origin){const s=_w(o.toString());a_(t,s,()=>s(t.currentUser)),s_(t,l=>s(l))}}const i=Jd("auth");return i&&Zv(t,`http://${i}`),t}function bw(){var n;return((n=document.getElementsByTagName("head"))==null?void 0:n[0])??document}Gv({loadJS(n){return new Promise((e,t)=>{const r=document.createElement("script");r.setAttribute("src",n),r.onload=e,r.onerror=i=>{const o=Ut("internal-error");o.customData=i,t(o)},r.type="text/javascript",r.charset="UTF-8",bw().appendChild(r)})},gapiScript:"https://apis.google.com/js/api.js",recaptchaV2Script:"https://www.google.com/recaptcha/api.js",recaptchaEnterpriseScript:"https://www.google.com/recaptcha/enterprise.js?render="});mw("Browser");const Uf={apiKey:"AIzaSyDgeMII4vDFmjXVKnrBYV8ane76eSzyUN8",authDomain:"overlay-runner.firebaseapp.com",databaseURL:"https://overlay-runner-default-rtdb.firebaseio.com",projectId:"overlay-runner",storageBucket:"overlay-runner.firebasestorage.app",messagingSenderId:"951272023115",appId:"1:951272023115:web:0f75edb7fb291a118119ce"};var xh=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/var Fn,qf;(function(){var n;/** @license

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/function e(E,v){function w(){}w.prototype=v.prototype,E.F=v.prototype,E.prototype=new w,E.prototype.constructor=E,E.D=function(I,T,S){for(var _=Array(arguments.length-2),Se=2;Se<arguments.length;Se++)_[Se-2]=arguments[Se];return v.prototype[T].apply(I,_)}}function t(){this.blockSize=-1}function r(){this.blockSize=-1,this.blockSize=64,this.g=Array(4),this.C=Array(this.blockSize),this.o=this.h=0,this.u()}e(r,t),r.prototype.u=function(){this.g[0]=1732584193,this.g[1]=4023233417,this.g[2]=2562383102,this.g[3]=271733878,this.o=this.h=0};function i(E,v,w){w||(w=0);const I=Array(16);if(typeof v=="string")for(var T=0;T<16;++T)I[T]=v.charCodeAt(w++)|v.charCodeAt(w++)<<8|v.charCodeAt(w++)<<16|v.charCodeAt(w++)<<24;else for(T=0;T<16;++T)I[T]=v[w++]|v[w++]<<8|v[w++]<<16|v[w++]<<24;v=E.g[0],w=E.g[1],T=E.g[2];let S=E.g[3],_;_=v+(S^w&(T^S))+I[0]+3614090360&4294967295,v=w+(_<<7&4294967295|_>>>25),_=S+(T^v&(w^T))+I[1]+3905402710&4294967295,S=v+(_<<12&4294967295|_>>>20),_=T+(w^S&(v^w))+I[2]+606105819&4294967295,T=S+(_<<17&4294967295|_>>>15),_=w+(v^T&(S^v))+I[3]+3250441966&4294967295,w=T+(_<<22&4294967295|_>>>10),_=v+(S^w&(T^S))+I[4]+4118548399&4294967295,v=w+(_<<7&4294967295|_>>>25),_=S+(T^v&(w^T))+I[5]+1200080426&4294967295,S=v+(_<<12&4294967295|_>>>20),_=T+(w^S&(v^w))+I[6]+2821735955&4294967295,T=S+(_<<17&4294967295|_>>>15),_=w+(v^T&(S^v))+I[7]+4249261313&4294967295,w=T+(_<<22&4294967295|_>>>10),_=v+(S^w&(T^S))+I[8]+1770035416&4294967295,v=w+(_<<7&4294967295|_>>>25),_=S+(T^v&(w^T))+I[9]+2336552879&4294967295,S=v+(_<<12&4294967295|_>>>20),_=T+(w^S&(v^w))+I[10]+4294925233&4294967295,T=S+(_<<17&4294967295|_>>>15),_=w+(v^T&(S^v))+I[11]+2304563134&4294967295,w=T+(_<<22&4294967295|_>>>10),_=v+(S^w&(T^S))+I[12]+1804603682&4294967295,v=w+(_<<7&4294967295|_>>>25),_=S+(T^v&(w^T))+I[13]+4254626195&4294967295,S=v+(_<<12&4294967295|_>>>20),_=T+(w^S&(v^w))+I[14]+2792965006&4294967295,T=S+(_<<17&4294967295|_>>>15),_=w+(v^T&(S^v))+I[15]+1236535329&4294967295,w=T+(_<<22&4294967295|_>>>10),_=v+(T^S&(w^T))+I[1]+4129170786&4294967295,v=w+(_<<5&4294967295|_>>>27),_=S+(w^T&(v^w))+I[6]+3225465664&4294967295,S=v+(_<<9&4294967295|_>>>23),_=T+(v^w&(S^v))+I[11]+643717713&4294967295,T=S+(_<<14&4294967295|_>>>18),_=w+(S^v&(T^S))+I[0]+3921069994&4294967295,w=T+(_<<20&4294967295|_>>>12),_=v+(T^S&(w^T))+I[5]+3593408605&4294967295,v=w+(_<<5&4294967295|_>>>27),_=S+(w^T&(v^w))+I[10]+38016083&4294967295,S=v+(_<<9&4294967295|_>>>23),_=T+(v^w&(S^v))+I[15]+3634488961&4294967295,T=S+(_<<14&4294967295|_>>>18),_=w+(S^v&(T^S))+I[4]+3889429448&4294967295,w=T+(_<<20&4294967295|_>>>12),_=v+(T^S&(w^T))+I[9]+568446438&4294967295,v=w+(_<<5&4294967295|_>>>27),_=S+(w^T&(v^w))+I[14]+3275163606&4294967295,S=v+(_<<9&4294967295|_>>>23),_=T+(v^w&(S^v))+I[3]+4107603335&4294967295,T=S+(_<<14&4294967295|_>>>18),_=w+(S^v&(T^S))+I[8]+1163531501&4294967295,w=T+(_<<20&4294967295|_>>>12),_=v+(T^S&(w^T))+I[13]+2850285829&4294967295,v=w+(_<<5&4294967295|_>>>27),_=S+(w^T&(v^w))+I[2]+4243563512&4294967295,S=v+(_<<9&4294967295|_>>>23),_=T+(v^w&(S^v))+I[7]+1735328473&4294967295,T=S+(_<<14&4294967295|_>>>18),_=w+(S^v&(T^S))+I[12]+2368359562&4294967295,w=T+(_<<20&4294967295|_>>>12),_=v+(w^T^S)+I[5]+4294588738&4294967295,v=w+(_<<4&4294967295|_>>>28),_=S+(v^w^T)+I[8]+2272392833&4294967295,S=v+(_<<11&4294967295|_>>>21),_=T+(S^v^w)+I[11]+1839030562&4294967295,T=S+(_<<16&4294967295|_>>>16),_=w+(T^S^v)+I[14]+4259657740&4294967295,w=T+(_<<23&4294967295|_>>>9),_=v+(w^T^S)+I[1]+2763975236&4294967295,v=w+(_<<4&4294967295|_>>>28),_=S+(v^w^T)+I[4]+1272893353&4294967295,S=v+(_<<11&4294967295|_>>>21),_=T+(S^v^w)+I[7]+4139469664&4294967295,T=S+(_<<16&4294967295|_>>>16),_=w+(T^S^v)+I[10]+3200236656&4294967295,w=T+(_<<23&4294967295|_>>>9),_=v+(w^T^S)+I[13]+681279174&4294967295,v=w+(_<<4&4294967295|_>>>28),_=S+(v^w^T)+I[0]+3936430074&4294967295,S=v+(_<<11&4294967295|_>>>21),_=T+(S^v^w)+I[3]+3572445317&4294967295,T=S+(_<<16&4294967295|_>>>16),_=w+(T^S^v)+I[6]+76029189&4294967295,w=T+(_<<23&4294967295|_>>>9),_=v+(w^T^S)+I[9]+3654602809&4294967295,v=w+(_<<4&4294967295|_>>>28),_=S+(v^w^T)+I[12]+3873151461&4294967295,S=v+(_<<11&4294967295|_>>>21),_=T+(S^v^w)+I[15]+530742520&4294967295,T=S+(_<<16&4294967295|_>>>16),_=w+(T^S^v)+I[2]+3299628645&4294967295,w=T+(_<<23&4294967295|_>>>9),_=v+(T^(w|~S))+I[0]+4096336452&4294967295,v=w+(_<<6&4294967295|_>>>26),_=S+(w^(v|~T))+I[7]+1126891415&4294967295,S=v+(_<<10&4294967295|_>>>22),_=T+(v^(S|~w))+I[14]+2878612391&4294967295,T=S+(_<<15&4294967295|_>>>17),_=w+(S^(T|~v))+I[5]+4237533241&4294967295,w=T+(_<<21&4294967295|_>>>11),_=v+(T^(w|~S))+I[12]+1700485571&4294967295,v=w+(_<<6&4294967295|_>>>26),_=S+(w^(v|~T))+I[3]+2399980690&4294967295,S=v+(_<<10&4294967295|_>>>22),_=T+(v^(S|~w))+I[10]+4293915773&4294967295,T=S+(_<<15&4294967295|_>>>17),_=w+(S^(T|~v))+I[1]+2240044497&4294967295,w=T+(_<<21&4294967295|_>>>11),_=v+(T^(w|~S))+I[8]+1873313359&4294967295,v=w+(_<<6&4294967295|_>>>26),_=S+(w^(v|~T))+I[15]+4264355552&4294967295,S=v+(_<<10&4294967295|_>>>22),_=T+(v^(S|~w))+I[6]+2734768916&4294967295,T=S+(_<<15&4294967295|_>>>17),_=w+(S^(T|~v))+I[13]+1309151649&4294967295,w=T+(_<<21&4294967295|_>>>11),_=v+(T^(w|~S))+I[4]+4149444226&4294967295,v=w+(_<<6&4294967295|_>>>26),_=S+(w^(v|~T))+I[11]+3174756917&4294967295,S=v+(_<<10&4294967295|_>>>22),_=T+(v^(S|~w))+I[2]+718787259&4294967295,T=S+(_<<15&4294967295|_>>>17),_=w+(S^(T|~v))+I[9]+3951481745&4294967295,E.g[0]=E.g[0]+v&4294967295,E.g[1]=E.g[1]+(T+(_<<21&4294967295|_>>>11))&4294967295,E.g[2]=E.g[2]+T&4294967295,E.g[3]=E.g[3]+S&4294967295}r.prototype.v=function(E,v){v===void 0&&(v=E.length);const w=v-this.blockSize,I=this.C;let T=this.h,S=0;for(;S<v;){if(T==0)for(;S<=w;)i(this,E,S),S+=this.blockSize;if(typeof E=="string"){for(;S<v;)if(I[T++]=E.charCodeAt(S++),T==this.blockSize){i(this,I),T=0;break}}else for(;S<v;)if(I[T++]=E[S++],T==this.blockSize){i(this,I),T=0;break}}this.h=T,this.o+=v},r.prototype.A=function(){var E=Array((this.h<56?this.blockSize:this.blockSize*2)-this.h);E[0]=128;for(var v=1;v<E.length-8;++v)E[v]=0;v=this.o*8;for(var w=E.length-8;w<E.length;++w)E[w]=v&255,v/=256;for(this.v(E),E=Array(16),v=0,w=0;w<4;++w)for(let I=0;I<32;I+=8)E[v++]=this.g[w]>>>I&255;return E};function o(E,v){var w=l;return Object.prototype.hasOwnProperty.call(w,E)?w[E]:w[E]=v(E)}function s(E,v){this.h=v;const w=[];let I=!0;for(let T=E.length-1;T>=0;T--){const S=E[T]|0;I&&S==v||(w[T]=S,I=!1)}this.g=w}var l={};function u(E){return-128<=E&&E<128?o(E,function(v){return new s([v|0],v<0?-1:0)}):new s([E|0],E<0?-1:0)}function d(E){if(isNaN(E)||!isFinite(E))return m;if(E<0)return P(d(-E));const v=[];let w=1;for(let I=0;E>=w;I++)v[I]=E/w|0,w*=4294967296;return new s(v,0)}function p(E,v){if(E.length==0)throw Error("number format error: empty string");if(v=v||10,v<2||36<v)throw Error("radix out of range: "+v);if(E.charAt(0)=="-")return P(p(E.substring(1),v));if(E.indexOf("-")>=0)throw Error('number format error: interior "-" character');const w=d(Math.pow(v,8));let I=m;for(let S=0;S<E.length;S+=8){var T=Math.min(8,E.length-S);const _=parseInt(E.substring(S,S+T),v);T<8?(T=d(Math.pow(v,T)),I=I.j(T).add(d(_))):(I=I.j(w),I=I.add(d(_)))}return I}var m=u(0),g=u(1),b=u(16777216);n=s.prototype,n.m=function(){if(A(this))return-P(this).m();let E=0,v=1;for(let w=0;w<this.g.length;w++){const I=this.i(w);E+=(I>=0?I:4294967296+I)*v,v*=4294967296}return E},n.toString=function(E){if(E=E||10,E<2||36<E)throw Error("radix out of range: "+E);if(O(this))return"0";if(A(this))return"-"+P(this).toString(E);const v=d(Math.pow(E,6));var w=this;let I="";for(;;){const T=G(w,v).g;w=V(w,T.j(v));let S=((w.g.length>0?w.g[0]:w.h)>>>0).toString(E);if(w=T,O(w))return S+I;for(;S.length<6;)S="0"+S;I=S+I}},n.i=function(E){return E<0?0:E<this.g.length?this.g[E]:this.h};function O(E){if(E.h!=0)return!1;for(let v=0;v<E.g.length;v++)if(E.g[v]!=0)return!1;return!0}function A(E){return E.h==-1}n.l=function(E){return E=V(this,E),A(E)?-1:O(E)?0:1};function P(E){const v=E.g.length,w=[];for(let I=0;I<v;I++)w[I]=~E.g[I];return new s(w,~E.h).add(g)}n.abs=function(){return A(this)?P(this):this},n.add=function(E){const v=Math.max(this.g.length,E.g.length),w=[];let I=0;for(let T=0;T<=v;T++){let S=I+(this.i(T)&65535)+(E.i(T)&65535),_=(S>>>16)+(this.i(T)>>>16)+(E.i(T)>>>16);I=_>>>16,S&=65535,_&=65535,w[T]=_<<16|S}return new s(w,w[w.length-1]&-2147483648?-1:0)};function V(E,v){return E.add(P(v))}n.j=function(E){if(O(this)||O(E))return m;if(A(this))return A(E)?P(this).j(P(E)):P(P(this).j(E));if(A(E))return P(this.j(P(E)));if(this.l(b)<0&&E.l(b)<0)return d(this.m()*E.m());const v=this.g.length+E.g.length,w=[];for(var I=0;I<2*v;I++)w[I]=0;for(I=0;I<this.g.length;I++)for(let T=0;T<E.g.length;T++){const S=this.i(I)>>>16,_=this.i(I)&65535,Se=E.i(T)>>>16,et=E.i(T)&65535;w[2*I+2*T]+=_*et,$(w,2*I+2*T),w[2*I+2*T+1]+=S*et,$(w,2*I+2*T+1),w[2*I+2*T+1]+=_*Se,$(w,2*I+2*T+1),w[2*I+2*T+2]+=S*Se,$(w,2*I+2*T+2)}for(E=0;E<v;E++)w[E]=w[2*E+1]<<16|w[2*E];for(E=v;E<2*v;E++)w[E]=0;return new s(w,0)};function $(E,v){for(;(E[v]&65535)!=E[v];)E[v+1]+=E[v]>>>16,E[v]&=65535,v++}function U(E,v){this.g=E,this.h=v}function G(E,v){if(O(v))throw Error("division by zero");if(O(E))return new U(m,m);if(A(E))return v=G(P(E),v),new U(P(v.g),P(v.h));if(A(v))return v=G(E,P(v)),new U(P(v.g),v.h);if(E.g.length>30){if(A(E)||A(v))throw Error("slowDivide_ only works with positive integers.");for(var w=g,I=v;I.l(E)<=0;)w=z(w),I=z(I);var T=J(w,1),S=J(I,1);for(I=J(I,2),w=J(w,2);!O(I);){var _=S.add(I);_.l(E)<=0&&(T=T.add(w),S=_),I=J(I,1),w=J(w,1)}return v=V(E,T.j(v)),new U(T,v)}for(T=m;E.l(v)>=0;){for(w=Math.max(1,Math.floor(E.m()/v.m())),I=Math.ceil(Math.log(w)/Math.LN2),I=I<=48?1:Math.pow(2,I-48),S=d(w),_=S.j(v);A(_)||_.l(E)>0;)w-=I,S=d(w),_=S.j(v);O(S)&&(S=g),T=T.add(S),E=V(E,_)}return new U(T,E)}n.B=function(E){return G(this,E).h},n.and=function(E){const v=Math.max(this.g.length,E.g.length),w=[];for(let I=0;I<v;I++)w[I]=this.i(I)&E.i(I);return new s(w,this.h&E.h)},n.or=function(E){const v=Math.max(this.g.length,E.g.length),w=[];for(let I=0;I<v;I++)w[I]=this.i(I)|E.i(I);return new s(w,this.h|E.h)},n.xor=function(E){const v=Math.max(this.g.length,E.g.length),w=[];for(let I=0;I<v;I++)w[I]=this.i(I)^E.i(I);return new s(w,this.h^E.h)};function z(E){const v=E.g.length+1,w=[];for(let I=0;I<v;I++)w[I]=E.i(I)<<1|E.i(I-1)>>>31;return new s(w,E.h)}function J(E,v){const w=v>>5;v%=32;const I=E.g.length-w,T=[];for(let S=0;S<I;S++)T[S]=v>0?E.i(S+w)>>>v|E.i(S+w+1)<<32-v:E.i(S+w);return new s(T,E.h)}r.prototype.digest=r.prototype.A,r.prototype.reset=r.prototype.u,r.prototype.update=r.prototype.v,qf=r,s.prototype.add=s.prototype.add,s.prototype.multiply=s.prototype.j,s.prototype.modulo=s.prototype.B,s.prototype.compare=s.prototype.l,s.prototype.toNumber=s.prototype.m,s.prototype.toString=s.prototype.toString,s.prototype.getBits=s.prototype.i,s.fromNumber=d,s.fromString=p,Fn=s}).apply(typeof xh<"u"?xh:typeof self<"u"?self:typeof window<"u"?window:{});var Zo=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/var $f,Hi,Bf,ys,yl,jf,zf,Wf;(function(){var n,e=Object.defineProperty;function t(a){a=[typeof globalThis=="object"&&globalThis,a,typeof window=="object"&&window,typeof self=="object"&&self,typeof Zo=="object"&&Zo];for(var h=0;h<a.length;++h){var f=a[h];if(f&&f.Math==Math)return f}throw Error("Cannot find global object")}var r=t(this);function i(a,h){if(h)e:{var f=r;a=a.split(".");for(var y=0;y<a.length-1;y++){var x=a[y];if(!(x in f))break e;f=f[x]}a=a[a.length-1],y=f[a],h=h(y),h!=y&&h!=null&&e(f,a,{configurable:!0,writable:!0,value:h})}}i("Symbol.dispose",function(a){return a||Symbol("Symbol.dispose")}),i("Array.prototype.values",function(a){return a||function(){return this[Symbol.iterator]()}}),i("Object.entries",function(a){return a||function(h){var f=[],y;for(y in h)Object.prototype.hasOwnProperty.call(h,y)&&f.push([y,h[y]]);return f}});/** @license

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/var o=o||{},s=this||self;function l(a){var h=typeof a;return h=="object"&&a!=null||h=="function"}function u(a,h,f){return a.call.apply(a.bind,arguments)}function d(a,h,f){return d=u,d.apply(null,arguments)}function p(a,h){var f=Array.prototype.slice.call(arguments,1);return function(){var y=f.slice();return y.push.apply(y,arguments),a.apply(this,y)}}function m(a,h){function f(){}f.prototype=h.prototype,a.Z=h.prototype,a.prototype=new f,a.prototype.constructor=a,a.Ob=function(y,x,R){for(var F=Array(arguments.length-2),ee=2;ee<arguments.length;ee++)F[ee-2]=arguments[ee];return h.prototype[x].apply(y,F)}}var g=typeof AsyncContext<"u"&&typeof AsyncContext.Snapshot=="function"?a=>a&&AsyncContext.Snapshot.wrap(a):a=>a;function b(a){const h=a.length;if(h>0){const f=Array(h);for(let y=0;y<h;y++)f[y]=a[y];return f}return[]}function O(a,h){for(let y=1;y<arguments.length;y++){const x=arguments[y];var f=typeof x;if(f=f!="object"?f:x?Array.isArray(x)?"array":f:"null",f=="array"||f=="object"&&typeof x.length=="number"){f=a.length||0;const R=x.length||0;a.length=f+R;for(let F=0;F<R;F++)a[f+F]=x[F]}else a.push(x)}}class A{constructor(h,f){this.i=h,this.j=f,this.h=0,this.g=null}get(){let h;return this.h>0?(this.h--,h=this.g,this.g=h.next,h.next=null):h=this.i(),h}}function P(a){s.setTimeout(()=>{throw a},0)}function V(){var a=E;let h=null;return a.g&&(h=a.g,a.g=a.g.next,a.g||(a.h=null),h.next=null),h}class ${constructor(){this.h=this.g=null}add(h,f){const y=U.get();y.set(h,f),this.h?this.h.next=y:this.g=y,this.h=y}}var U=new A(()=>new G,a=>a.reset());class G{constructor(){this.next=this.g=this.h=null}set(h,f){this.h=h,this.g=f,this.next=null}reset(){this.next=this.g=this.h=null}}let z,J=!1,E=new $,v=()=>{const a=Promise.resolve(void 0);z=()=>{a.then(w)}};function w(){for(var a;a=V();){try{a.h.call(a.g)}catch(f){P(f)}var h=U;h.j(a),h.h<100&&(h.h++,a.next=h.g,h.g=a)}J=!1}function I(){this.u=this.u,this.C=this.C}I.prototype.u=!1,I.prototype.dispose=function(){this.u||(this.u=!0,this.N())},I.prototype[Symbol.dispose]=function(){this.dispose()},I.prototype.N=function(){if(this.C)for(;this.C.length;)this.C.shift()()};function T(a,h){this.type=a,this.g=this.target=h,this.defaultPrevented=!1}T.prototype.h=function(){this.defaultPrevented=!0};var S=function(){if(!s.addEventListener||!Object.defineProperty)return!1;var a=!1,h=Object.defineProperty({},"passive",{get:function(){a=!0}});try{const f=()=>{};s.addEventListener("test",f,h),s.removeEventListener("test",f,h)}catch{}return a}();function _(a){return/^[\s\xa0]*$/.test(a)}function Se(a,h){T.call(this,a?a.type:""),this.relatedTarget=this.g=this.target=null,this.button=this.screenY=this.screenX=this.clientY=this.clientX=0,this.key="",this.metaKey=this.shiftKey=this.altKey=this.ctrlKey=!1,this.state=null,this.pointerId=0,this.pointerType="",this.i=null,a&&this.init(a,h)}m(Se,T),Se.prototype.init=function(a,h){const f=this.type=a.type,y=a.changedTouches&&a.changedTouches.length?a.changedTouches[0]:null;this.target=a.target||a.srcElement,this.g=h,h=a.relatedTarget,h||(f=="mouseover"?h=a.fromElement:f=="mouseout"&&(h=a.toElement)),this.relatedTarget=h,y?(this.clientX=y.clientX!==void 0?y.clientX:y.pageX,this.clientY=y.clientY!==void 0?y.clientY:y.pageY,this.screenX=y.screenX||0,this.screenY=y.screenY||0):(this.clientX=a.clientX!==void 0?a.clientX:a.pageX,this.clientY=a.clientY!==void 0?a.clientY:a.pageY,this.screenX=a.screenX||0,this.screenY=a.screenY||0),this.button=a.button,this.key=a.key||"",this.ctrlKey=a.ctrlKey,this.altKey=a.altKey,this.shiftKey=a.shiftKey,this.metaKey=a.metaKey,this.pointerId=a.pointerId||0,this.pointerType=a.pointerType,this.state=a.state,this.i=a,a.defaultPrevented&&Se.Z.h.call(this)},Se.prototype.h=function(){Se.Z.h.call(this);const a=this.i;a.preventDefault?a.preventDefault():a.returnValue=!1};var et="closure_listenable_"+(Math.random()*1e6|0),xr=0;function vn(a,h,f,y,x){this.listener=a,this.proxy=null,this.src=h,this.type=f,this.capture=!!y,this.ha=x,this.key=++xr,this.da=this.fa=!1}function vt(a){a.da=!0,a.listener=null,a.proxy=null,a.src=null,a.ha=null}function wt(a,h,f){for(const y in a)h.call(f,a[y],y,a)}function tt(a,h){for(const f in a)h.call(void 0,a[f],f,a)}function le(a){const h={};for(const f in a)h[f]=a[f];return h}const xe="constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");function ye(a,h){let f,y;for(let x=1;x<arguments.length;x++){y=arguments[x];for(f in y)a[f]=y[f];for(let R=0;R<xe.length;R++)f=xe[R],Object.prototype.hasOwnProperty.call(y,f)&&(a[f]=y[f])}}function Qe(a){this.src=a,this.g={},this.h=0}Qe.prototype.add=function(a,h,f,y,x){const R=a.toString();a=this.g[R],a||(a=this.g[R]=[],this.h++);const F=L(a,h,y,x);return F>-1?(h=a[F],f||(h.fa=!1)):(h=new vn(h,this.src,R,!!y,x),h.fa=f,a.push(h)),h};function Ht(a,h){const f=h.type;if(f in a.g){var y=a.g[f],x=Array.prototype.indexOf.call(y,h,void 0),R;(R=x>=0)&&Array.prototype.splice.call(y,x,1),R&&(vt(h),a.g[f].length==0&&(delete a.g[f],a.h--))}}function L(a,h,f,y){for(let x=0;x<a.length;++x){const R=a[x];if(!R.da&&R.listener==h&&R.capture==!!f&&R.ha==y)return x}return-1}var j="closure_lm_"+(Math.random()*1e6|0),te={};function Je(a,h,f,y,x){if(Array.isArray(h)){for(let R=0;R<h.length;R++)Je(a,h[R],f,y,x);return null}return f=ou(f),a&&a[et]?a.J(h,f,l(y)?!!y.capture:!1,x):Ei(a,h,f,!1,y,x)}function Ei(a,h,f,y,x,R){if(!h)throw Error("Invalid event type");const F=l(x)?!!x.capture:!!x;let ee=Ia(a);if(ee||(a[j]=ee=new Qe(a)),f=ee.add(h,f,y,F,R),f.proxy)return f;if(y=Fo(),f.proxy=y,y.src=a,y.listener=f,a.addEventListener)S||(x=F),x===void 0&&(x=!1),a.addEventListener(h.toString(),y,x);else if(a.attachEvent)a.attachEvent(Ii(h.toString()),y);else if(a.addListener&&a.removeListener)a.addListener(y);else throw Error("addEventListener and attachEvent are unavailable.");return f}function Fo(){function a(f){return h.call(a.src,a.listener,f)}const h=dm;return a}function Gt(a,h,f,y,x){if(Array.isArray(h))for(var R=0;R<h.length;R++)Gt(a,h[R],f,y,x);else y=l(y)?!!y.capture:!!y,f=ou(f),a&&a[et]?(a=a.i,R=String(h).toString(),R in a.g&&(h=a.g[R],f=L(h,f,y,x),f>-1&&(vt(h[f]),Array.prototype.splice.call(h,f,1),h.length==0&&(delete a.g[R],a.h--)))):a&&(a=Ia(a))&&(h=a.g[h.toString()],a=-1,h&&(a=L(h,f,y,x)),(f=a>-1?h[a]:null)&&Uo(f))}function Uo(a){if(typeof a!="number"&&a&&!a.da){var h=a.src;if(h&&h[et])Ht(h.i,a);else{var f=a.type,y=a.proxy;h.removeEventListener?h.removeEventListener(f,y,a.capture):h.detachEvent?h.detachEvent(Ii(f),y):h.addListener&&h.removeListener&&h.removeListener(y),(f=Ia(h))?(Ht(f,a),f.h==0&&(f.src=null,h[j]=null)):vt(a)}}}function Ii(a){return a in te?te[a]:te[a]="on"+a}function dm(a,h){if(a.da)a=!0;else{h=new Se(h,this);const f=a.listener,y=a.ha||a.src;a.fa&&Uo(a),a=f.call(y,h)}return a}function Ia(a){return a=a[j],a instanceof Qe?a:null}var Aa="__closure_events_fn_"+(Math.random()*1e9>>>0);function ou(a){return typeof a=="function"?a:(a[Aa]||(a[Aa]=function(h){return a.handleEvent(h)}),a[Aa])}function We(){I.call(this),this.i=new Qe(this),this.M=this,this.G=null}m(We,I),We.prototype[et]=!0,We.prototype.removeEventListener=function(a,h,f,y){Gt(this,a,h,f,y)};function Xe(a,h){var f,y=a.G;if(y)for(f=[];y;y=y.G)f.push(y);if(a=a.M,y=h.type||h,typeof h=="string")h=new T(h,a);else if(h instanceof T)h.target=h.target||a;else{var x=h;h=new T(y,a),ye(h,x)}x=!0;let R,F;if(f)for(F=f.length-1;F>=0;F--)R=h.g=f[F],x=qo(R,y,!0,h)&&x;if(R=h.g=a,x=qo(R,y,!0,h)&&x,x=qo(R,y,!1,h)&&x,f)for(F=0;F<f.length;F++)R=h.g=f[F],x=qo(R,y,!1,h)&&x}We.prototype.N=function(){if(We.Z.N.call(this),this.i){var a=this.i;for(const h in a.g){const f=a.g[h];for(let y=0;y<f.length;y++)vt(f[y]);delete a.g[h],a.h--}}this.G=null},We.prototype.J=function(a,h,f,y){return this.i.add(String(a),h,!1,f,y)},We.prototype.K=function(a,h,f,y){return this.i.add(String(a),h,!0,f,y)};function qo(a,h,f,y){if(h=a.i.g[String(h)],!h)return!0;h=h.concat();let x=!0;for(let R=0;R<h.length;++R){const F=h[R];if(F&&!F.da&&F.capture==f){const ee=F.listener,Ne=F.ha||F.src;F.fa&&Ht(a.i,F),x=ee.call(Ne,y)!==!1&&x}}return x&&!y.defaultPrevented}function fm(a,h){if(typeof a!="function")if(a&&typeof a.handleEvent=="function")a=d(a.handleEvent,a);else throw Error("Invalid listener argument");return Number(h)>2147483647?-1:s.setTimeout(a,h||0)}function su(a){a.g=fm(()=>{a.g=null,a.i&&(a.i=!1,su(a))},a.l);const h=a.h;a.h=null,a.m.apply(null,h)}class pm extends I{constructor(h,f){super(),this.m=h,this.l=f,this.h=null,this.i=!1,this.g=null}j(h){this.h=arguments,this.g?this.i=!0:su(this)}N(){super.N(),this.g&&(s.clearTimeout(this.g),this.g=null,this.i=!1,this.h=null)}}function Ai(a){I.call(this),this.h=a,this.g={}}m(Ai,I);var au=[];function lu(a){wt(a.g,function(h,f){this.g.hasOwnProperty(f)&&Uo(h)},a),a.g={}}Ai.prototype.N=function(){Ai.Z.N.call(this),lu(this)},Ai.prototype.handleEvent=function(){throw Error("EventHandler.handleEvent not implemented")};var Sa=s.JSON.stringify,gm=s.JSON.parse,mm=class{stringify(a){return s.JSON.stringify(a,void 0)}parse(a){return s.JSON.parse(a,void 0)}};function cu(){}function uu(){}var Si={OPEN:"a",hb:"b",ERROR:"c",tb:"d"};function xa(){T.call(this,"d")}m(xa,T);function ka(){T.call(this,"c")}m(ka,T);var Xn={},hu=null;function $o(){return hu=hu||new We}Xn.Ia="serverreachability";function du(a){T.call(this,Xn.Ia,a)}m(du,T);function xi(a){const h=$o();Xe(h,new du(h))}Xn.STAT_EVENT="statevent";function fu(a,h){T.call(this,Xn.STAT_EVENT,a),this.stat=h}m(fu,T);function Ze(a){const h=$o();Xe(h,new fu(h,a))}Xn.Ja="timingevent";function pu(a,h){T.call(this,Xn.Ja,a),this.size=h}m(pu,T);function ki(a,h){if(typeof a!="function")throw Error("Fn must not be null and must be a function");return s.setTimeout(function(){a()},h)}function Pi(){this.g=!0}Pi.prototype.ua=function(){this.g=!1};function ym(a,h,f,y,x,R){a.info(function(){if(a.g)if(R){var F="",ee=R.split("&");for(let de=0;de<ee.length;de++){var Ne=ee[de].split("=");if(Ne.length>1){const Fe=Ne[0];Ne=Ne[1];const Ct=Fe.split("_");F=Ct.length>=2&&Ct[1]=="type"?F+(Fe+"="+Ne+"&"):F+(Fe+"=redacted&")}}}else F=null;else F=R;return"XMLHTTP REQ ("+y+") [attempt "+x+"]: "+h+`
`+f+`
`+F})}function vm(a,h,f,y,x,R,F){a.info(function(){return"XMLHTTP RESP ("+y+") [ attempt "+x+"]: "+h+`
`+f+`
`+R+" "+F})}function kr(a,h,f,y){a.info(function(){return"XMLHTTP TEXT ("+h+"): "+wm(a,f)+(y?" "+y:"")})}function _m(a,h){a.info(function(){return"TIMEOUT: "+h})}Pi.prototype.info=function(){};function wm(a,h){if(!a.g)return h;if(!h)return null;try{const R=JSON.parse(h);if(R){for(a=0;a<R.length;a++)if(Array.isArray(R[a])){var f=R[a];if(!(f.length<2)){var y=f[1];if(Array.isArray(y)&&!(y.length<1)){var x=y[0];if(x!="noop"&&x!="stop"&&x!="close")for(let F=1;F<y.length;F++)y[F]=""}}}}return Sa(R)}catch{return h}}var Bo={NO_ERROR:0,cb:1,qb:2,pb:3,kb:4,ob:5,rb:6,Ga:7,TIMEOUT:8,ub:9},gu={ib:"complete",Fb:"success",ERROR:"error",Ga:"abort",xb:"ready",yb:"readystatechange",TIMEOUT:"timeout",sb:"incrementaldata",wb:"progress",lb:"downloadprogress",Nb:"uploadprogress"},mu;function Pa(){}m(Pa,cu),Pa.prototype.g=function(){return new XMLHttpRequest},mu=new Pa;function Ci(a){return encodeURIComponent(String(a))}function bm(a){var h=1;a=a.split(":");const f=[];for(;h>0&&a.length;)f.push(a.shift()),h--;return a.length&&f.push(a.join(":")),f}function _n(a,h,f,y){this.j=a,this.i=h,this.l=f,this.S=y||1,this.V=new Ai(this),this.H=45e3,this.J=null,this.o=!1,this.u=this.B=this.A=this.M=this.F=this.T=this.D=null,this.G=[],this.g=null,this.C=0,this.m=this.v=null,this.X=-1,this.K=!1,this.P=0,this.O=null,this.W=this.L=this.U=this.R=!1,this.h=new yu}function yu(){this.i=null,this.g="",this.h=!1}var vu={},Ca={};function Ra(a,h,f){a.M=1,a.A=zo(Pt(h)),a.u=f,a.R=!0,_u(a,null)}function _u(a,h){a.F=Date.now(),jo(a),a.B=Pt(a.A);var f=a.B,y=a.S;Array.isArray(y)||(y=[String(y)]),Ou(f.i,"t",y),a.C=0,f=a.j.L,a.h=new yu,a.g=Qu(a.j,f?h:null,!a.u),a.P>0&&(a.O=new pm(d(a.Y,a,a.g),a.P)),h=a.V,f=a.g,y=a.ba;var x="readystatechange";Array.isArray(x)||(x&&(au[0]=x.toString()),x=au);for(let R=0;R<x.length;R++){const F=Je(f,x[R],y||h.handleEvent,!1,h.h||h);if(!F)break;h.g[F.key]=F}h=a.J?le(a.J):{},a.u?(a.v||(a.v="POST"),h["Content-Type"]="application/x-www-form-urlencoded",a.g.ea(a.B,a.v,a.u,h)):(a.v="GET",a.g.ea(a.B,a.v,null,h)),xi(),ym(a.i,a.v,a.B,a.l,a.S,a.u)}_n.prototype.ba=function(a){a=a.target;const h=this.O;h&&Tn(a)==3?h.j():this.Y(a)},_n.prototype.Y=function(a){try{if(a==this.g)e:{const ee=Tn(this.g),Ne=this.g.ya(),de=this.g.ca();if(!(ee<3)&&(ee!=3||this.g&&(this.h.h||this.g.la()||Uu(this.g)))){this.K||ee!=4||Ne==7||(Ne==8||de<=0?xi(3):xi(2)),Oa(this);var h=this.g.ca();this.X=h;var f=Tm(this);if(this.o=h==200,vm(this.i,this.v,this.B,this.l,this.S,ee,h),this.o){if(this.U&&!this.L){t:{if(this.g){var y,x=this.g;if((y=x.g?x.g.getResponseHeader("X-HTTP-Initial-Response"):null)&&!_(y)){var R=y;break t}}R=null}if(a=R)kr(this.i,this.l,a,"Initial handshake response via X-HTTP-Initial-Response"),this.L=!0,Na(this,a);else{this.o=!1,this.m=3,Ze(12),Zn(this),Ri(this);break e}}if(this.R){a=!0;let Fe;for(;!this.K&&this.C<f.length;)if(Fe=Em(this,f),Fe==Ca){ee==4&&(this.m=4,Ze(14),a=!1),kr(this.i,this.l,null,"[Incomplete Response]");break}else if(Fe==vu){this.m=4,Ze(15),kr(this.i,this.l,f,"[Invalid Chunk]"),a=!1;break}else kr(this.i,this.l,Fe,null),Na(this,Fe);if(wu(this)&&this.C!=0&&(this.h.g=this.h.g.slice(this.C),this.C=0),ee!=4||f.length!=0||this.h.h||(this.m=1,Ze(16),a=!1),this.o=this.o&&a,!a)kr(this.i,this.l,f,"[Invalid Chunked Response]"),Zn(this),Ri(this);else if(f.length>0&&!this.W){this.W=!0;var F=this.j;F.g==this&&F.aa&&!F.P&&(F.j.info("Great, no buffering proxy detected. Bytes received: "+f.length),$a(F),F.P=!0,Ze(11))}}else kr(this.i,this.l,f,null),Na(this,f);ee==4&&Zn(this),this.o&&!this.K&&(ee==4?Hu(this.j,this):(this.o=!1,jo(this)))}else Vm(this.g),h==400&&f.indexOf("Unknown SID")>0?(this.m=3,Ze(12)):(this.m=0,Ze(13)),Zn(this),Ri(this)}}}catch{}finally{}};function Tm(a){if(!wu(a))return a.g.la();const h=Uu(a.g);if(h==="")return"";let f="";const y=h.length,x=Tn(a.g)==4;if(!a.h.i){if(typeof TextDecoder>"u")return Zn(a),Ri(a),"";a.h.i=new s.TextDecoder}for(let R=0;R<y;R++)a.h.h=!0,f+=a.h.i.decode(h[R],{stream:!(x&&R==y-1)});return h.length=0,a.h.g+=f,a.C=0,a.h.g}function wu(a){return a.g?a.v=="GET"&&a.M!=2&&a.j.Aa:!1}function Em(a,h){var f=a.C,y=h.indexOf(`
`,f);return y==-1?Ca:(f=Number(h.substring(f,y)),isNaN(f)?vu:(y+=1,y+f>h.length?Ca:(h=h.slice(y,y+f),a.C=y+f,h)))}_n.prototype.cancel=function(){this.K=!0,Zn(this)};function jo(a){a.T=Date.now()+a.H,bu(a,a.H)}function bu(a,h){if(a.D!=null)throw Error("WatchDog timer not null");a.D=ki(d(a.aa,a),h)}function Oa(a){a.D&&(s.clearTimeout(a.D),a.D=null)}_n.prototype.aa=function(){this.D=null;const a=Date.now();a-this.T>=0?(_m(this.i,this.B),this.M!=2&&(xi(),Ze(17)),Zn(this),this.m=2,Ri(this)):bu(this,this.T-a)};function Ri(a){a.j.I==0||a.K||Hu(a.j,a)}function Zn(a){Oa(a);var h=a.O;h&&typeof h.dispose=="function"&&h.dispose(),a.O=null,lu(a.V),a.g&&(h=a.g,a.g=null,h.abort(),h.dispose())}function Na(a,h){try{var f=a.j;if(f.I!=0&&(f.g==a||Da(f.h,a))){if(!a.L&&Da(f.h,a)&&f.I==3){try{var y=f.Ba.g.parse(h)}catch{y=null}if(Array.isArray(y)&&y.length==3){var x=y;if(x[0]==0){e:if(!f.v){if(f.g)if(f.g.F+3e3<a.F)Yo(f),Go(f);else break e;qa(f),Ze(18)}}else f.xa=x[1],0<f.xa-f.K&&x[2]<37500&&f.F&&f.A==0&&!f.C&&(f.C=ki(d(f.Va,f),6e3));Iu(f.h)<=1&&f.ta&&(f.ta=void 0)}else tr(f,11)}else if((a.L||f.g==a)&&Yo(f),!_(h))for(x=f.Ba.g.parse(h),h=0;h<x.length;h++){let de=x[h];const Fe=de[0];if(!(Fe<=f.K))if(f.K=Fe,de=de[1],f.I==2)if(de[0]=="c"){f.M=de[1],f.ba=de[2];const Ct=de[3];Ct!=null&&(f.ka=Ct,f.j.info("VER="+f.ka));const nr=de[4];nr!=null&&(f.za=nr,f.j.info("SVER="+f.za));const En=de[5];En!=null&&typeof En=="number"&&En>0&&(y=1.5*En,f.O=y,f.j.info("backChannelRequestTimeoutMs_="+y)),y=f;const In=a.g;if(In){const Jo=In.g?In.g.getResponseHeader("X-Client-Wire-Protocol"):null;if(Jo){var R=y.h;R.g||Jo.indexOf("spdy")==-1&&Jo.indexOf("quic")==-1&&Jo.indexOf("h2")==-1||(R.j=R.l,R.g=new Set,R.h&&(La(R,R.h),R.h=null))}if(y.G){const Ba=In.g?In.g.getResponseHeader("X-HTTP-Session-Id"):null;Ba&&(y.wa=Ba,pe(y.J,y.G,Ba))}}f.I=3,f.l&&f.l.ra(),f.aa&&(f.T=Date.now()-a.F,f.j.info("Handshake RTT: "+f.T+"ms")),y=f;var F=a;if(y.na=Yu(y,y.L?y.ba:null,y.W),F.L){Au(y.h,F);var ee=F,Ne=y.O;Ne&&(ee.H=Ne),ee.D&&(Oa(ee),jo(ee)),y.g=F}else zu(y);f.i.length>0&&Ko(f)}else de[0]!="stop"&&de[0]!="close"||tr(f,7);else f.I==3&&(de[0]=="stop"||de[0]=="close"?de[0]=="stop"?tr(f,7):Ua(f):de[0]!="noop"&&f.l&&f.l.qa(de),f.A=0)}}xi(4)}catch{}}var Im=class{constructor(a,h){this.g=a,this.map=h}};function Tu(a){this.l=a||10,s.PerformanceNavigationTiming?(a=s.performance.getEntriesByType("navigation"),a=a.length>0&&(a[0].nextHopProtocol=="hq"||a[0].nextHopProtocol=="h2")):a=!!(s.chrome&&s.chrome.loadTimes&&s.chrome.loadTimes()&&s.chrome.loadTimes().wasFetchedViaSpdy),this.j=a?this.l:1,this.g=null,this.j>1&&(this.g=new Set),this.h=null,this.i=[]}function Eu(a){return a.h?!0:a.g?a.g.size>=a.j:!1}function Iu(a){return a.h?1:a.g?a.g.size:0}function Da(a,h){return a.h?a.h==h:a.g?a.g.has(h):!1}function La(a,h){a.g?a.g.add(h):a.h=h}function Au(a,h){a.h&&a.h==h?a.h=null:a.g&&a.g.has(h)&&a.g.delete(h)}Tu.prototype.cancel=function(){if(this.i=Su(this),this.h)this.h.cancel(),this.h=null;else if(this.g&&this.g.size!==0){for(const a of this.g.values())a.cancel();this.g.clear()}};function Su(a){if(a.h!=null)return a.i.concat(a.h.G);if(a.g!=null&&a.g.size!==0){let h=a.i;for(const f of a.g.values())h=h.concat(f.G);return h}return b(a.i)}var xu=RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");function Am(a,h){if(a){a=a.split("&");for(let f=0;f<a.length;f++){const y=a[f].indexOf("=");let x,R=null;y>=0?(x=a[f].substring(0,y),R=a[f].substring(y+1)):x=a[f],h(x,R?decodeURIComponent(R.replace(/\+/g," ")):"")}}}function wn(a){this.g=this.o=this.j="",this.u=null,this.m=this.h="",this.l=!1;let h;a instanceof wn?(this.l=a.l,Oi(this,a.j),this.o=a.o,this.g=a.g,Ni(this,a.u),this.h=a.h,Ma(this,Nu(a.i)),this.m=a.m):a&&(h=String(a).match(xu))?(this.l=!1,Oi(this,h[1]||"",!0),this.o=Di(h[2]||""),this.g=Di(h[3]||"",!0),Ni(this,h[4]),this.h=Di(h[5]||"",!0),Ma(this,h[6]||"",!0),this.m=Di(h[7]||"")):(this.l=!1,this.i=new Mi(null,this.l))}wn.prototype.toString=function(){const a=[];var h=this.j;h&&a.push(Li(h,ku,!0),":");var f=this.g;return(f||h=="file")&&(a.push("//"),(h=this.o)&&a.push(Li(h,ku,!0),"@"),a.push(Ci(f).replace(/%25([0-9a-fA-F]{2})/g,"%$1")),f=this.u,f!=null&&a.push(":",String(f))),(f=this.h)&&(this.g&&f.charAt(0)!="/"&&a.push("/"),a.push(Li(f,f.charAt(0)=="/"?km:xm,!0))),(f=this.i.toString())&&a.push("?",f),(f=this.m)&&a.push("#",Li(f,Cm)),a.join("")},wn.prototype.resolve=function(a){const h=Pt(this);let f=!!a.j;f?Oi(h,a.j):f=!!a.o,f?h.o=a.o:f=!!a.g,f?h.g=a.g:f=a.u!=null;var y=a.h;if(f)Ni(h,a.u);else if(f=!!a.h){if(y.charAt(0)!="/")if(this.g&&!this.h)y="/"+y;else{var x=h.h.lastIndexOf("/");x!=-1&&(y=h.h.slice(0,x+1)+y)}if(x=y,x==".."||x==".")y="";else if(x.indexOf("./")!=-1||x.indexOf("/.")!=-1){y=x.lastIndexOf("/",0)==0,x=x.split("/");const R=[];for(let F=0;F<x.length;){const ee=x[F++];ee=="."?y&&F==x.length&&R.push(""):ee==".."?((R.length>1||R.length==1&&R[0]!="")&&R.pop(),y&&F==x.length&&R.push("")):(R.push(ee),y=!0)}y=R.join("/")}else y=x}return f?h.h=y:f=a.i.toString()!=="",f?Ma(h,Nu(a.i)):f=!!a.m,f&&(h.m=a.m),h};function Pt(a){return new wn(a)}function Oi(a,h,f){a.j=f?Di(h,!0):h,a.j&&(a.j=a.j.replace(/:$/,""))}function Ni(a,h){if(h){if(h=Number(h),isNaN(h)||h<0)throw Error("Bad port number "+h);a.u=h}else a.u=null}function Ma(a,h,f){h instanceof Mi?(a.i=h,Rm(a.i,a.l)):(f||(h=Li(h,Pm)),a.i=new Mi(h,a.l))}function pe(a,h,f){a.i.set(h,f)}function zo(a){return pe(a,"zx",Math.floor(Math.random()*2147483648).toString(36)+Math.abs(Math.floor(Math.random()*2147483648)^Date.now()).toString(36)),a}function Di(a,h){return a?h?decodeURI(a.replace(/%25/g,"%2525")):decodeURIComponent(a):""}function Li(a,h,f){return typeof a=="string"?(a=encodeURI(a).replace(h,Sm),f&&(a=a.replace(/%25([0-9a-fA-F]{2})/g,"%$1")),a):null}function Sm(a){return a=a.charCodeAt(0),"%"+(a>>4&15).toString(16)+(a&15).toString(16)}var ku=/[#\/\?@]/g,xm=/[#\?:]/g,km=/[#\?]/g,Pm=/[#\?@]/g,Cm=/#/g;function Mi(a,h){this.h=this.g=null,this.i=a||null,this.j=!!h}function er(a){a.g||(a.g=new Map,a.h=0,a.i&&Am(a.i,function(h,f){a.add(decodeURIComponent(h.replace(/\+/g," ")),f)}))}n=Mi.prototype,n.add=function(a,h){er(this),this.i=null,a=Pr(this,a);let f=this.g.get(a);return f||this.g.set(a,f=[]),f.push(h),this.h+=1,this};function Pu(a,h){er(a),h=Pr(a,h),a.g.has(h)&&(a.i=null,a.h-=a.g.get(h).length,a.g.delete(h))}function Cu(a,h){return er(a),h=Pr(a,h),a.g.has(h)}n.forEach=function(a,h){er(this),this.g.forEach(function(f,y){f.forEach(function(x){a.call(h,x,y,this)},this)},this)};function Ru(a,h){er(a);let f=[];if(typeof h=="string")Cu(a,h)&&(f=f.concat(a.g.get(Pr(a,h))));else for(a=Array.from(a.g.values()),h=0;h<a.length;h++)f=f.concat(a[h]);return f}n.set=function(a,h){return er(this),this.i=null,a=Pr(this,a),Cu(this,a)&&(this.h-=this.g.get(a).length),this.g.set(a,[h]),this.h+=1,this},n.get=function(a,h){return a?(a=Ru(this,a),a.length>0?String(a[0]):h):h};function Ou(a,h,f){Pu(a,h),f.length>0&&(a.i=null,a.g.set(Pr(a,h),b(f)),a.h+=f.length)}n.toString=function(){if(this.i)return this.i;if(!this.g)return"";const a=[],h=Array.from(this.g.keys());for(let y=0;y<h.length;y++){var f=h[y];const x=Ci(f);f=Ru(this,f);for(let R=0;R<f.length;R++){let F=x;f[R]!==""&&(F+="="+Ci(f[R])),a.push(F)}}return this.i=a.join("&")};function Nu(a){const h=new Mi;return h.i=a.i,a.g&&(h.g=new Map(a.g),h.h=a.h),h}function Pr(a,h){return h=String(h),a.j&&(h=h.toLowerCase()),h}function Rm(a,h){h&&!a.j&&(er(a),a.i=null,a.g.forEach(function(f,y){const x=y.toLowerCase();y!=x&&(Pu(this,y),Ou(this,x,f))},a)),a.j=h}function Om(a,h){const f=new Pi;if(s.Image){const y=new Image;y.onload=p(bn,f,"TestLoadImage: loaded",!0,h,y),y.onerror=p(bn,f,"TestLoadImage: error",!1,h,y),y.onabort=p(bn,f,"TestLoadImage: abort",!1,h,y),y.ontimeout=p(bn,f,"TestLoadImage: timeout",!1,h,y),s.setTimeout(function(){y.ontimeout&&y.ontimeout()},1e4),y.src=a}else h(!1)}function Nm(a,h){const f=new Pi,y=new AbortController,x=setTimeout(()=>{y.abort(),bn(f,"TestPingServer: timeout",!1,h)},1e4);fetch(a,{signal:y.signal}).then(R=>{clearTimeout(x),R.ok?bn(f,"TestPingServer: ok",!0,h):bn(f,"TestPingServer: server error",!1,h)}).catch(()=>{clearTimeout(x),bn(f,"TestPingServer: error",!1,h)})}function bn(a,h,f,y,x){try{x&&(x.onload=null,x.onerror=null,x.onabort=null,x.ontimeout=null),y(f)}catch{}}function Dm(){this.g=new mm}function Va(a){this.i=a.Sb||null,this.h=a.ab||!1}m(Va,cu),Va.prototype.g=function(){return new Wo(this.i,this.h)};function Wo(a,h){We.call(this),this.H=a,this.o=h,this.m=void 0,this.status=this.readyState=0,this.responseType=this.responseText=this.response=this.statusText="",this.onreadystatechange=null,this.A=new Headers,this.h=null,this.F="GET",this.D="",this.g=!1,this.B=this.j=this.l=null,this.v=new AbortController}m(Wo,We),n=Wo.prototype,n.open=function(a,h){if(this.readyState!=0)throw this.abort(),Error("Error reopening a connection");this.F=a,this.D=h,this.readyState=1,Fi(this)},n.send=function(a){if(this.readyState!=1)throw this.abort(),Error("need to call open() first. ");if(this.v.signal.aborted)throw this.abort(),Error("Request was aborted.");this.g=!0;const h={headers:this.A,method:this.F,credentials:this.m,cache:void 0,signal:this.v.signal};a&&(h.body=a),(this.H||s).fetch(new Request(this.D,h)).then(this.Pa.bind(this),this.ga.bind(this))},n.abort=function(){this.response=this.responseText="",this.A=new Headers,this.status=0,this.v.abort(),this.j&&this.j.cancel("Request was aborted.").catch(()=>{}),this.readyState>=1&&this.g&&this.readyState!=4&&(this.g=!1,Vi(this)),this.readyState=0},n.Pa=function(a){if(this.g&&(this.l=a,this.h||(this.status=this.l.status,this.statusText=this.l.statusText,this.h=a.headers,this.readyState=2,Fi(this)),this.g&&(this.readyState=3,Fi(this),this.g)))if(this.responseType==="arraybuffer")a.arrayBuffer().then(this.Na.bind(this),this.ga.bind(this));else if(typeof s.ReadableStream<"u"&&"body"in a){if(this.j=a.body.getReader(),this.o){if(this.responseType)throw Error('responseType must be empty for "streamBinaryChunks" mode responses.');this.response=[]}else this.response=this.responseText="",this.B=new TextDecoder;Du(this)}else a.text().then(this.Oa.bind(this),this.ga.bind(this))};function Du(a){a.j.read().then(a.Ma.bind(a)).catch(a.ga.bind(a))}n.Ma=function(a){if(this.g){if(this.o&&a.value)this.response.push(a.value);else if(!this.o){var h=a.value?a.value:new Uint8Array(0);(h=this.B.decode(h,{stream:!a.done}))&&(this.response=this.responseText+=h)}a.done?Vi(this):Fi(this),this.readyState==3&&Du(this)}},n.Oa=function(a){this.g&&(this.response=this.responseText=a,Vi(this))},n.Na=function(a){this.g&&(this.response=a,Vi(this))},n.ga=function(){this.g&&Vi(this)};function Vi(a){a.readyState=4,a.l=null,a.j=null,a.B=null,Fi(a)}n.setRequestHeader=function(a,h){this.A.append(a,h)},n.getResponseHeader=function(a){return this.h&&this.h.get(a.toLowerCase())||""},n.getAllResponseHeaders=function(){if(!this.h)return"";const a=[],h=this.h.entries();for(var f=h.next();!f.done;)f=f.value,a.push(f[0]+": "+f[1]),f=h.next();return a.join(`\r
`)};function Fi(a){a.onreadystatechange&&a.onreadystatechange.call(a)}Object.defineProperty(Wo.prototype,"withCredentials",{get:function(){return this.m==="include"},set:function(a){this.m=a?"include":"same-origin"}});function Lu(a){let h="";return wt(a,function(f,y){h+=y,h+=":",h+=f,h+=`\r
`}),h}function Fa(a,h,f){e:{for(y in f){var y=!1;break e}y=!0}y||(f=Lu(f),typeof a=="string"?f!=null&&Ci(f):pe(a,h,f))}function be(a){We.call(this),this.headers=new Map,this.L=a||null,this.h=!1,this.g=null,this.D="",this.o=0,this.l="",this.j=this.B=this.v=this.A=!1,this.m=null,this.F="",this.H=!1}m(be,We);var Lm=/^https?$/i,Mm=["POST","PUT"];n=be.prototype,n.Fa=function(a){this.H=a},n.ea=function(a,h,f,y){if(this.g)throw Error("[goog.net.XhrIo] Object is active with another request="+this.D+"; newUri="+a);h=h?h.toUpperCase():"GET",this.D=a,this.l="",this.o=0,this.A=!1,this.h=!0,this.g=this.L?this.L.g():mu.g(),this.g.onreadystatechange=g(d(this.Ca,this));try{this.B=!0,this.g.open(h,String(a),!0),this.B=!1}catch(R){Mu(this,R);return}if(a=f||"",f=new Map(this.headers),y)if(Object.getPrototypeOf(y)===Object.prototype)for(var x in y)f.set(x,y[x]);else if(typeof y.keys=="function"&&typeof y.get=="function")for(const R of y.keys())f.set(R,y.get(R));else throw Error("Unknown input type for opt_headers: "+String(y));y=Array.from(f.keys()).find(R=>R.toLowerCase()=="content-type"),x=s.FormData&&a instanceof s.FormData,!(Array.prototype.indexOf.call(Mm,h,void 0)>=0)||y||x||f.set("Content-Type","application/x-www-form-urlencoded;charset=utf-8");for(const[R,F]of f)this.g.setRequestHeader(R,F);this.F&&(this.g.responseType=this.F),"withCredentials"in this.g&&this.g.withCredentials!==this.H&&(this.g.withCredentials=this.H);try{this.m&&(clearTimeout(this.m),this.m=null),this.v=!0,this.g.send(a),this.v=!1}catch(R){Mu(this,R)}};function Mu(a,h){a.h=!1,a.g&&(a.j=!0,a.g.abort(),a.j=!1),a.l=h,a.o=5,Vu(a),Ho(a)}function Vu(a){a.A||(a.A=!0,Xe(a,"complete"),Xe(a,"error"))}n.abort=function(a){this.g&&this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1,this.o=a||7,Xe(this,"complete"),Xe(this,"abort"),Ho(this))},n.N=function(){this.g&&(this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1),Ho(this,!0)),be.Z.N.call(this)},n.Ca=function(){this.u||(this.B||this.v||this.j?Fu(this):this.Xa())},n.Xa=function(){Fu(this)};function Fu(a){if(a.h&&typeof o<"u"){if(a.v&&Tn(a)==4)setTimeout(a.Ca.bind(a),0);else if(Xe(a,"readystatechange"),Tn(a)==4){a.h=!1;try{const R=a.ca();e:switch(R){case 200:case 201:case 202:case 204:case 206:case 304:case 1223:var h=!0;break e;default:h=!1}var f;if(!(f=h)){var y;if(y=R===0){let F=String(a.D).match(xu)[1]||null;!F&&s.self&&s.self.location&&(F=s.self.location.protocol.slice(0,-1)),y=!Lm.test(F?F.toLowerCase():"")}f=y}if(f)Xe(a,"complete"),Xe(a,"success");else{a.o=6;try{var x=Tn(a)>2?a.g.statusText:""}catch{x=""}a.l=x+" ["+a.ca()+"]",Vu(a)}}finally{Ho(a)}}}}function Ho(a,h){if(a.g){a.m&&(clearTimeout(a.m),a.m=null);const f=a.g;a.g=null,h||Xe(a,"ready");try{f.onreadystatechange=null}catch{}}}n.isActive=function(){return!!this.g};function Tn(a){return a.g?a.g.readyState:0}n.ca=function(){try{return Tn(this)>2?this.g.status:-1}catch{return-1}},n.la=function(){try{return this.g?this.g.responseText:""}catch{return""}},n.La=function(a){if(this.g){var h=this.g.responseText;return a&&h.indexOf(a)==0&&(h=h.substring(a.length)),gm(h)}};function Uu(a){try{if(!a.g)return null;if("response"in a.g)return a.g.response;switch(a.F){case"":case"text":return a.g.responseText;case"arraybuffer":if("mozResponseArrayBuffer"in a.g)return a.g.mozResponseArrayBuffer}return null}catch{return null}}function Vm(a){const h={};a=(a.g&&Tn(a)>=2&&a.g.getAllResponseHeaders()||"").split(`\r
`);for(let y=0;y<a.length;y++){if(_(a[y]))continue;var f=bm(a[y]);const x=f[0];if(f=f[1],typeof f!="string")continue;f=f.trim();const R=h[x]||[];h[x]=R,R.push(f)}tt(h,function(y){return y.join(", ")})}n.ya=function(){return this.o},n.Ha=function(){return typeof this.l=="string"?this.l:String(this.l)};function Ui(a,h,f){return f&&f.internalChannelParams&&f.internalChannelParams[a]||h}function qu(a){this.za=0,this.i=[],this.j=new Pi,this.ba=this.na=this.J=this.W=this.g=this.wa=this.G=this.H=this.u=this.U=this.o=null,this.Ya=this.V=0,this.Sa=Ui("failFast",!1,a),this.F=this.C=this.v=this.m=this.l=null,this.X=!0,this.xa=this.K=-1,this.Y=this.A=this.D=0,this.Qa=Ui("baseRetryDelayMs",5e3,a),this.Za=Ui("retryDelaySeedMs",1e4,a),this.Ta=Ui("forwardChannelMaxRetries",2,a),this.va=Ui("forwardChannelRequestTimeoutMs",2e4,a),this.ma=a&&a.xmlHttpFactory||void 0,this.Ua=a&&a.Rb||void 0,this.Aa=a&&a.useFetchStreams||!1,this.O=void 0,this.L=a&&a.supportsCrossDomainXhr||!1,this.M="",this.h=new Tu(a&&a.concurrentRequestLimit),this.Ba=new Dm,this.S=a&&a.fastHandshake||!1,this.R=a&&a.encodeInitMessageHeaders||!1,this.S&&this.R&&(this.R=!1),this.Ra=a&&a.Pb||!1,a&&a.ua&&this.j.ua(),a&&a.forceLongPolling&&(this.X=!1),this.aa=!this.S&&this.X&&a&&a.detectBufferingProxy||!1,this.ia=void 0,a&&a.longPollingTimeout&&a.longPollingTimeout>0&&(this.ia=a.longPollingTimeout),this.ta=void 0,this.T=0,this.P=!1,this.ja=this.B=null}n=qu.prototype,n.ka=8,n.I=1,n.connect=function(a,h,f,y){Ze(0),this.W=a,this.H=h||{},f&&y!==void 0&&(this.H.OSID=f,this.H.OAID=y),this.F=this.X,this.J=Yu(this,null,this.W),Ko(this)};function Ua(a){if($u(a),a.I==3){var h=a.V++,f=Pt(a.J);if(pe(f,"SID",a.M),pe(f,"RID",h),pe(f,"TYPE","terminate"),qi(a,f),h=new _n(a,a.j,h),h.M=2,h.A=zo(Pt(f)),f=!1,s.navigator&&s.navigator.sendBeacon)try{f=s.navigator.sendBeacon(h.A.toString(),"")}catch{}!f&&s.Image&&(new Image().src=h.A,f=!0),f||(h.g=Qu(h.j,null),h.g.ea(h.A)),h.F=Date.now(),jo(h)}Ku(a)}function Go(a){a.g&&($a(a),a.g.cancel(),a.g=null)}function $u(a){Go(a),a.v&&(s.clearTimeout(a.v),a.v=null),Yo(a),a.h.cancel(),a.m&&(typeof a.m=="number"&&s.clearTimeout(a.m),a.m=null)}function Ko(a){if(!Eu(a.h)&&!a.m){a.m=!0;var h=a.Ea;z||v(),J||(z(),J=!0),E.add(h,a),a.D=0}}function Fm(a,h){return Iu(a.h)>=a.h.j-(a.m?1:0)?!1:a.m?(a.i=h.G.concat(a.i),!0):a.I==1||a.I==2||a.D>=(a.Sa?0:a.Ta)?!1:(a.m=ki(d(a.Ea,a,h),Gu(a,a.D)),a.D++,!0)}n.Ea=function(a){if(this.m)if(this.m=null,this.I==1){if(!a){this.V=Math.floor(Math.random()*1e5),a=this.V++;const x=new _n(this,this.j,a);let R=this.o;if(this.U&&(R?(R=le(R),ye(R,this.U)):R=this.U),this.u!==null||this.R||(x.J=R,R=null),this.S)e:{for(var h=0,f=0;f<this.i.length;f++){t:{var y=this.i[f];if("__data__"in y.map&&(y=y.map.__data__,typeof y=="string")){y=y.length;break t}y=void 0}if(y===void 0)break;if(h+=y,h>4096){h=f;break e}if(h===4096||f===this.i.length-1){h=f+1;break e}}h=1e3}else h=1e3;h=ju(this,x,h),f=Pt(this.J),pe(f,"RID",a),pe(f,"CVER",22),this.G&&pe(f,"X-HTTP-Session-Id",this.G),qi(this,f),R&&(this.R?h="headers="+Ci(Lu(R))+"&"+h:this.u&&Fa(f,this.u,R)),La(this.h,x),this.Ra&&pe(f,"TYPE","init"),this.S?(pe(f,"$req",h),pe(f,"SID","null"),x.U=!0,Ra(x,f,null)):Ra(x,f,h),this.I=2}}else this.I==3&&(a?Bu(this,a):this.i.length==0||Eu(this.h)||Bu(this))};function Bu(a,h){var f;h?f=h.l:f=a.V++;const y=Pt(a.J);pe(y,"SID",a.M),pe(y,"RID",f),pe(y,"AID",a.K),qi(a,y),a.u&&a.o&&Fa(y,a.u,a.o),f=new _n(a,a.j,f,a.D+1),a.u===null&&(f.J=a.o),h&&(a.i=h.G.concat(a.i)),h=ju(a,f,1e3),f.H=Math.round(a.va*.5)+Math.round(a.va*.5*Math.random()),La(a.h,f),Ra(f,y,h)}function qi(a,h){a.H&&wt(a.H,function(f,y){pe(h,y,f)}),a.l&&wt({},function(f,y){pe(h,y,f)})}function ju(a,h,f){f=Math.min(a.i.length,f);const y=a.l?d(a.l.Ka,a.l,a):null;e:{var x=a.i;let ee=-1;for(;;){const Ne=["count="+f];ee==-1?f>0?(ee=x[0].g,Ne.push("ofs="+ee)):ee=0:Ne.push("ofs="+ee);let de=!0;for(let Fe=0;Fe<f;Fe++){var R=x[Fe].g;const Ct=x[Fe].map;if(R-=ee,R<0)ee=Math.max(0,x[Fe].g-100),de=!1;else try{R="req"+R+"_"||"";try{var F=Ct instanceof Map?Ct:Object.entries(Ct);for(const[nr,En]of F){let In=En;l(En)&&(In=Sa(En)),Ne.push(R+nr+"="+encodeURIComponent(In))}}catch(nr){throw Ne.push(R+"type="+encodeURIComponent("_badmap")),nr}}catch{y&&y(Ct)}}if(de){F=Ne.join("&");break e}}F=void 0}return a=a.i.splice(0,f),h.G=a,F}function zu(a){if(!a.g&&!a.v){a.Y=1;var h=a.Da;z||v(),J||(z(),J=!0),E.add(h,a),a.A=0}}function qa(a){return a.g||a.v||a.A>=3?!1:(a.Y++,a.v=ki(d(a.Da,a),Gu(a,a.A)),a.A++,!0)}n.Da=function(){if(this.v=null,Wu(this),this.aa&&!(this.P||this.g==null||this.T<=0)){var a=4*this.T;this.j.info("BP detection timer enabled: "+a),this.B=ki(d(this.Wa,this),a)}},n.Wa=function(){this.B&&(this.B=null,this.j.info("BP detection timeout reached."),this.j.info("Buffering proxy detected and switch to long-polling!"),this.F=!1,this.P=!0,Ze(10),Go(this),Wu(this))};function $a(a){a.B!=null&&(s.clearTimeout(a.B),a.B=null)}function Wu(a){a.g=new _n(a,a.j,"rpc",a.Y),a.u===null&&(a.g.J=a.o),a.g.P=0;var h=Pt(a.na);pe(h,"RID","rpc"),pe(h,"SID",a.M),pe(h,"AID",a.K),pe(h,"CI",a.F?"0":"1"),!a.F&&a.ia&&pe(h,"TO",a.ia),pe(h,"TYPE","xmlhttp"),qi(a,h),a.u&&a.o&&Fa(h,a.u,a.o),a.O&&(a.g.H=a.O);var f=a.g;a=a.ba,f.M=1,f.A=zo(Pt(h)),f.u=null,f.R=!0,_u(f,a)}n.Va=function(){this.C!=null&&(this.C=null,Go(this),qa(this),Ze(19))};function Yo(a){a.C!=null&&(s.clearTimeout(a.C),a.C=null)}function Hu(a,h){var f=null;if(a.g==h){Yo(a),$a(a),a.g=null;var y=2}else if(Da(a.h,h))f=h.G,Au(a.h,h),y=1;else return;if(a.I!=0){if(h.o)if(y==1){f=h.u?h.u.length:0,h=Date.now()-h.F;var x=a.D;y=$o(),Xe(y,new pu(y,f)),Ko(a)}else zu(a);else if(x=h.m,x==3||x==0&&h.X>0||!(y==1&&Fm(a,h)||y==2&&qa(a)))switch(f&&f.length>0&&(h=a.h,h.i=h.i.concat(f)),x){case 1:tr(a,5);break;case 4:tr(a,10);break;case 3:tr(a,6);break;default:tr(a,2)}}}function Gu(a,h){let f=a.Qa+Math.floor(Math.random()*a.Za);return a.isActive()||(f*=2),f*h}function tr(a,h){if(a.j.info("Error code "+h),h==2){var f=d(a.bb,a),y=a.Ua;const x=!y;y=new wn(y||"//www.google.com/images/cleardot.gif"),s.location&&s.location.protocol=="http"||Oi(y,"https"),zo(y),x?Om(y.toString(),f):Nm(y.toString(),f)}else Ze(2);a.I=0,a.l&&a.l.pa(h),Ku(a),$u(a)}n.bb=function(a){a?(this.j.info("Successfully pinged google.com"),Ze(2)):(this.j.info("Failed to ping google.com"),Ze(1))};function Ku(a){if(a.I=0,a.ja=[],a.l){const h=Su(a.h);(h.length!=0||a.i.length!=0)&&(O(a.ja,h),O(a.ja,a.i),a.h.i.length=0,b(a.i),a.i.length=0),a.l.oa()}}function Yu(a,h,f){var y=f instanceof wn?Pt(f):new wn(f);if(y.g!="")h&&(y.g=h+"."+y.g),Ni(y,y.u);else{var x=s.location;y=x.protocol,h=h?h+"."+x.hostname:x.hostname,x=+x.port;const R=new wn(null);y&&Oi(R,y),h&&(R.g=h),x&&Ni(R,x),f&&(R.h=f),y=R}return f=a.G,h=a.wa,f&&h&&pe(y,f,h),pe(y,"VER",a.ka),qi(a,y),y}function Qu(a,h,f){if(h&&!a.L)throw Error("Can't create secondary domain capable XhrIo object.");return h=a.Aa&&!a.ma?new be(new Va({ab:f})):new be(a.ma),h.Fa(a.L),h}n.isActive=function(){return!!this.l&&this.l.isActive(this)};function Ju(){}n=Ju.prototype,n.ra=function(){},n.qa=function(){},n.pa=function(){},n.oa=function(){},n.isActive=function(){return!0},n.Ka=function(){};function Qo(){}Qo.prototype.g=function(a,h){return new ht(a,h)};function ht(a,h){We.call(this),this.g=new qu(h),this.l=a,this.h=h&&h.messageUrlParams||null,a=h&&h.messageHeaders||null,h&&h.clientProtocolHeaderRequired&&(a?a["X-Client-Protocol"]="webchannel":a={"X-Client-Protocol":"webchannel"}),this.g.o=a,a=h&&h.initMessageHeaders||null,h&&h.messageContentType&&(a?a["X-WebChannel-Content-Type"]=h.messageContentType:a={"X-WebChannel-Content-Type":h.messageContentType}),h&&h.sa&&(a?a["X-WebChannel-Client-Profile"]=h.sa:a={"X-WebChannel-Client-Profile":h.sa}),this.g.U=a,(a=h&&h.Qb)&&!_(a)&&(this.g.u=a),this.A=h&&h.supportsCrossDomainXhr||!1,this.v=h&&h.sendRawJson||!1,(h=h&&h.httpSessionIdParam)&&!_(h)&&(this.g.G=h,a=this.h,a!==null&&h in a&&(a=this.h,h in a&&delete a[h])),this.j=new Cr(this)}m(ht,We),ht.prototype.m=function(){this.g.l=this.j,this.A&&(this.g.L=!0),this.g.connect(this.l,this.h||void 0)},ht.prototype.close=function(){Ua(this.g)},ht.prototype.o=function(a){var h=this.g;if(typeof a=="string"){var f={};f.__data__=a,a=f}else this.v&&(f={},f.__data__=Sa(a),a=f);h.i.push(new Im(h.Ya++,a)),h.I==3&&Ko(h)},ht.prototype.N=function(){this.g.l=null,delete this.j,Ua(this.g),delete this.g,ht.Z.N.call(this)};function Xu(a){xa.call(this),a.__headers__&&(this.headers=a.__headers__,this.statusCode=a.__status__,delete a.__headers__,delete a.__status__);var h=a.__sm__;if(h){e:{for(const f in h){a=f;break e}a=void 0}(this.i=a)&&(a=this.i,h=h!==null&&a in h?h[a]:void 0),this.data=h}else this.data=a}m(Xu,xa);function Zu(){ka.call(this),this.status=1}m(Zu,ka);function Cr(a){this.g=a}m(Cr,Ju),Cr.prototype.ra=function(){Xe(this.g,"a")},Cr.prototype.qa=function(a){Xe(this.g,new Xu(a))},Cr.prototype.pa=function(a){Xe(this.g,new Zu)},Cr.prototype.oa=function(){Xe(this.g,"b")},Qo.prototype.createWebChannel=Qo.prototype.g,ht.prototype.send=ht.prototype.o,ht.prototype.open=ht.prototype.m,ht.prototype.close=ht.prototype.close,Wf=function(){return new Qo},zf=function(){return $o()},jf=Xn,yl={jb:0,mb:1,nb:2,Hb:3,Mb:4,Jb:5,Kb:6,Ib:7,Gb:8,Lb:9,PROXY:10,NOPROXY:11,Eb:12,Ab:13,Bb:14,zb:15,Cb:16,Db:17,fb:18,eb:19,gb:20},Bo.NO_ERROR=0,Bo.TIMEOUT=8,Bo.HTTP_ERROR=6,ys=Bo,gu.COMPLETE="complete",Bf=gu,uu.EventType=Si,Si.OPEN="a",Si.CLOSE="b",Si.ERROR="c",Si.MESSAGE="d",We.prototype.listen=We.prototype.J,Hi=uu,be.prototype.listenOnce=be.prototype.K,be.prototype.getLastError=be.prototype.Ha,be.prototype.getLastErrorCode=be.prototype.ya,be.prototype.getStatus=be.prototype.ca,be.prototype.getResponseJson=be.prototype.La,be.prototype.getResponseText=be.prototype.la,be.prototype.send=be.prototype.ea,be.prototype.setWithCredentials=be.prototype.Fa,$f=be}).apply(typeof Zo<"u"?Zo:typeof self<"u"?self:typeof window<"u"?window:{});/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ge{constructor(e){this.uid=e}isAuthenticated(){return this.uid!=null}toKey(){return this.isAuthenticated()?"uid:"+this.uid:"anonymous-user"}isEqual(e){return e.uid===this.uid}}Ge.UNAUTHENTICATED=new Ge(null),Ge.GOOGLE_CREDENTIALS=new Ge("google-credentials-uid"),Ge.FIRST_PARTY=new Ge("first-party-uid"),Ge.MOCK_USER=new Ge("mock-user");/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let mi="12.12.0";function Tw(n){mi=n}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const vr=new Wl("@firebase/firestore");function Rr(){return vr.logLevel}function B(n,...e){if(vr.logLevel<=ne.DEBUG){const t=e.map(rc);vr.debug(`Firestore (${mi}): ${n}`,...t)}}function dn(n,...e){if(vr.logLevel<=ne.ERROR){const t=e.map(rc);vr.error(`Firestore (${mi}): ${n}`,...t)}}function _r(n,...e){if(vr.logLevel<=ne.WARN){const t=e.map(rc);vr.warn(`Firestore (${mi}): ${n}`,...t)}}function rc(n){if(typeof n=="string")return n;try{return function(t){return JSON.stringify(t)}(n)}catch{return n}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function K(n,e,t){let r="Unexpected state";typeof e=="string"?r=e:t=e,Hf(n,r,t)}function Hf(n,e,t){let r=`FIRESTORE (${mi}) INTERNAL ASSERTION FAILED: ${e} (ID: ${n.toString(16)})`;if(t!==void 0)try{r+=" CONTEXT: "+JSON.stringify(t)}catch{r+=" CONTEXT: "+t}throw dn(r),new Error(r)}function ce(n,e,t,r){let i="Unexpected state";typeof t=="string"?i=t:r=t,n||Hf(e,i,r)}function X(n,e){return n}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const N={OK:"ok",CANCELLED:"cancelled",UNKNOWN:"unknown",INVALID_ARGUMENT:"invalid-argument",DEADLINE_EXCEEDED:"deadline-exceeded",NOT_FOUND:"not-found",ALREADY_EXISTS:"already-exists",PERMISSION_DENIED:"permission-denied",UNAUTHENTICATED:"unauthenticated",RESOURCE_EXHAUSTED:"resource-exhausted",FAILED_PRECONDITION:"failed-precondition",ABORTED:"aborted",OUT_OF_RANGE:"out-of-range",UNIMPLEMENTED:"unimplemented",INTERNAL:"internal",UNAVAILABLE:"unavailable",DATA_LOSS:"data-loss"};class q extends mn{constructor(e,t){super(e,t),this.code=e,this.message=t,this.toString=()=>`${this.name}: [code=${this.code}]: ${this.message}`}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class on{constructor(){this.promise=new Promise((e,t)=>{this.resolve=e,this.reject=t})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Gf{constructor(e,t){this.user=t,this.type="OAuth",this.headers=new Map,this.headers.set("Authorization",`Bearer ${e}`)}}class Ew{getToken(){return Promise.resolve(null)}invalidateToken(){}start(e,t){e.enqueueRetryable(()=>t(Ge.UNAUTHENTICATED))}shutdown(){}}class Iw{constructor(e){this.token=e,this.changeListener=null}getToken(){return Promise.resolve(this.token)}invalidateToken(){}start(e,t){this.changeListener=t,e.enqueueRetryable(()=>t(this.token.user))}shutdown(){this.changeListener=null}}class Aw{constructor(e){this.t=e,this.currentUser=Ge.UNAUTHENTICATED,this.i=0,this.forceRefresh=!1,this.auth=null}start(e,t){ce(this.o===void 0,42304);let r=this.i;const i=u=>this.i!==r?(r=this.i,t(u)):Promise.resolve();let o=new on;this.o=()=>{this.i++,this.currentUser=this.u(),o.resolve(),o=new on,e.enqueueRetryable(()=>i(this.currentUser))};const s=()=>{const u=o;e.enqueueRetryable(async()=>{await u.promise,await i(this.currentUser)})},l=u=>{B("FirebaseAuthCredentialsProvider","Auth detected"),this.auth=u,this.o&&(this.auth.addAuthTokenListener(this.o),s())};this.t.onInit(u=>l(u)),setTimeout(()=>{if(!this.auth){const u=this.t.getImmediate({optional:!0});u?l(u):(B("FirebaseAuthCredentialsProvider","Auth not yet detected"),o.resolve(),o=new on)}},0),s()}getToken(){const e=this.i,t=this.forceRefresh;return this.forceRefresh=!1,this.auth?this.auth.getToken(t).then(r=>this.i!==e?(B("FirebaseAuthCredentialsProvider","getToken aborted due to token change."),this.getToken()):r?(ce(typeof r.accessToken=="string",31837,{l:r}),new Gf(r.accessToken,this.currentUser)):null):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.auth&&this.o&&this.auth.removeAuthTokenListener(this.o),this.o=void 0}u(){const e=this.auth&&this.auth.getUid();return ce(e===null||typeof e=="string",2055,{h:e}),new Ge(e)}}class Sw{constructor(e,t,r){this.P=e,this.T=t,this.I=r,this.type="FirstParty",this.user=Ge.FIRST_PARTY,this.R=new Map}A(){return this.I?this.I():null}get headers(){this.R.set("X-Goog-AuthUser",this.P);const e=this.A();return e&&this.R.set("Authorization",e),this.T&&this.R.set("X-Goog-Iam-Authorization-Token",this.T),this.R}}class xw{constructor(e,t,r){this.P=e,this.T=t,this.I=r}getToken(){return Promise.resolve(new Sw(this.P,this.T,this.I))}start(e,t){e.enqueueRetryable(()=>t(Ge.FIRST_PARTY))}shutdown(){}invalidateToken(){}}class kh{constructor(e){this.value=e,this.type="AppCheck",this.headers=new Map,e&&e.length>0&&this.headers.set("x-firebase-appcheck",this.value)}}class kw{constructor(e,t){this.V=t,this.forceRefresh=!1,this.appCheck=null,this.m=null,this.p=null,Nt(e)&&e.settings.appCheckToken&&(this.p=e.settings.appCheckToken)}start(e,t){ce(this.o===void 0,3512);const r=o=>{o.error!=null&&B("FirebaseAppCheckTokenProvider",`Error getting App Check token; using placeholder token instead. Error: ${o.error.message}`);const s=o.token!==this.m;return this.m=o.token,B("FirebaseAppCheckTokenProvider",`Received ${s?"new":"existing"} token.`),s?t(o.token):Promise.resolve()};this.o=o=>{e.enqueueRetryable(()=>r(o))};const i=o=>{B("FirebaseAppCheckTokenProvider","AppCheck detected"),this.appCheck=o,this.o&&this.appCheck.addTokenListener(this.o)};this.V.onInit(o=>i(o)),setTimeout(()=>{if(!this.appCheck){const o=this.V.getImmediate({optional:!0});o?i(o):B("FirebaseAppCheckTokenProvider","AppCheck not yet detected")}},0)}getToken(){if(this.p)return Promise.resolve(new kh(this.p));const e=this.forceRefresh;return this.forceRefresh=!1,this.appCheck?this.appCheck.getToken(e).then(t=>t?(ce(typeof t.token=="string",44558,{tokenResult:t}),this.m=t.token,new kh(t.token)):null):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.appCheck&&this.o&&this.appCheck.removeTokenListener(this.o),this.o=void 0}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Pw(n){const e=typeof self<"u"&&(self.crypto||self.msCrypto),t=new Uint8Array(n);if(e&&typeof e.getRandomValues=="function")e.getRandomValues(t);else for(let r=0;r<n;r++)t[r]=Math.floor(256*Math.random());return t}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ic{static newId(){const e="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",t=62*Math.floor(4.129032258064516);let r="";for(;r.length<20;){const i=Pw(40);for(let o=0;o<i.length;++o)r.length<20&&i[o]<t&&(r+=e.charAt(i[o]%62))}return r}}function re(n,e){return n<e?-1:n>e?1:0}function vl(n,e){const t=Math.min(n.length,e.length);for(let r=0;r<t;r++){const i=n.charAt(r),o=e.charAt(r);if(i!==o)return Qa(i)===Qa(o)?re(i,o):Qa(i)?1:-1}return re(n.length,e.length)}const Cw=55296,Rw=57343;function Qa(n){const e=n.charCodeAt(0);return e>=Cw&&e<=Rw}function ti(n,e,t){return n.length===e.length&&n.every((r,i)=>t(r,e[i]))}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ph="__name__";class Rt{constructor(e,t,r){t===void 0?t=0:t>e.length&&K(637,{offset:t,range:e.length}),r===void 0?r=e.length-t:r>e.length-t&&K(1746,{length:r,range:e.length-t}),this.segments=e,this.offset=t,this.len=r}get length(){return this.len}isEqual(e){return Rt.comparator(this,e)===0}child(e){const t=this.segments.slice(this.offset,this.limit());return e instanceof Rt?e.forEach(r=>{t.push(r)}):t.push(e),this.construct(t)}limit(){return this.offset+this.length}popFirst(e){return e=e===void 0?1:e,this.construct(this.segments,this.offset+e,this.length-e)}popLast(){return this.construct(this.segments,this.offset,this.length-1)}firstSegment(){return this.segments[this.offset]}lastSegment(){return this.get(this.length-1)}get(e){return this.segments[this.offset+e]}isEmpty(){return this.length===0}isPrefixOf(e){if(e.length<this.length)return!1;for(let t=0;t<this.length;t++)if(this.get(t)!==e.get(t))return!1;return!0}isImmediateParentOf(e){if(this.length+1!==e.length)return!1;for(let t=0;t<this.length;t++)if(this.get(t)!==e.get(t))return!1;return!0}forEach(e){for(let t=this.offset,r=this.limit();t<r;t++)e(this.segments[t])}toArray(){return this.segments.slice(this.offset,this.limit())}static comparator(e,t){const r=Math.min(e.length,t.length);for(let i=0;i<r;i++){const o=Rt.compareSegments(e.get(i),t.get(i));if(o!==0)return o}return re(e.length,t.length)}static compareSegments(e,t){const r=Rt.isNumericId(e),i=Rt.isNumericId(t);return r&&!i?-1:!r&&i?1:r&&i?Rt.extractNumericId(e).compare(Rt.extractNumericId(t)):vl(e,t)}static isNumericId(e){return e.startsWith("__id")&&e.endsWith("__")}static extractNumericId(e){return Fn.fromString(e.substring(4,e.length-2))}}class fe extends Rt{construct(e,t,r){return new fe(e,t,r)}canonicalString(){return this.toArray().join("/")}toString(){return this.canonicalString()}toUriEncodedString(){return this.toArray().map(encodeURIComponent).join("/")}static fromString(...e){const t=[];for(const r of e){if(r.indexOf("//")>=0)throw new q(N.INVALID_ARGUMENT,`Invalid segment (${r}). Paths must not contain // in them.`);t.push(...r.split("/").filter(i=>i.length>0))}return new fe(t)}static emptyPath(){return new fe([])}}const Ow=/^[_a-zA-Z][_a-zA-Z0-9]*$/;class Be extends Rt{construct(e,t,r){return new Be(e,t,r)}static isValidIdentifier(e){return Ow.test(e)}canonicalString(){return this.toArray().map(e=>(e=e.replace(/\\/g,"\\\\").replace(/`/g,"\\`"),Be.isValidIdentifier(e)||(e="`"+e+"`"),e)).join(".")}toString(){return this.canonicalString()}isKeyField(){return this.length===1&&this.get(0)===Ph}static keyField(){return new Be([Ph])}static fromServerFormat(e){const t=[];let r="",i=0;const o=()=>{if(r.length===0)throw new q(N.INVALID_ARGUMENT,`Invalid field path (${e}). Paths must not be empty, begin with '.', end with '.', or contain '..'`);t.push(r),r=""};let s=!1;for(;i<e.length;){const l=e[i];if(l==="\\"){if(i+1===e.length)throw new q(N.INVALID_ARGUMENT,"Path has trailing escape character: "+e);const u=e[i+1];if(u!=="\\"&&u!=="."&&u!=="`")throw new q(N.INVALID_ARGUMENT,"Path has invalid escape sequence: "+e);r+=u,i+=2}else l==="`"?(s=!s,i++):l!=="."||s?(r+=l,i++):(o(),i++)}if(o(),s)throw new q(N.INVALID_ARGUMENT,"Unterminated ` in path: "+e);return new Be(t)}static emptyPath(){return new Be([])}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class H{constructor(e){this.path=e}static fromPath(e){return new H(fe.fromString(e))}static fromName(e){return new H(fe.fromString(e).popFirst(5))}static empty(){return new H(fe.emptyPath())}get collectionGroup(){return this.path.popLast().lastSegment()}hasCollectionId(e){return this.path.length>=2&&this.path.get(this.path.length-2)===e}getCollectionGroup(){return this.path.get(this.path.length-2)}getCollectionPath(){return this.path.popLast()}isEqual(e){return e!==null&&fe.comparator(this.path,e.path)===0}toString(){return this.path.toString()}static comparator(e,t){return fe.comparator(e.path,t.path)}static isDocumentKey(e){return e.length%2==0}static fromSegments(e){return new H(new fe(e.slice()))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Kf(n,e,t){if(!t)throw new q(N.INVALID_ARGUMENT,`Function ${n}() cannot be called with an empty ${e}.`)}function Nw(n,e,t,r){if(e===!0&&r===!0)throw new q(N.INVALID_ARGUMENT,`${n} and ${t} cannot be used together.`)}function Ch(n){if(!H.isDocumentKey(n))throw new q(N.INVALID_ARGUMENT,`Invalid document reference. Document references must have an even number of segments, but ${n} has ${n.length}.`)}function Rh(n){if(H.isDocumentKey(n))throw new q(N.INVALID_ARGUMENT,`Invalid collection reference. Collection references must have an odd number of segments, but ${n} has ${n.length}.`)}function Yf(n){return typeof n=="object"&&n!==null&&(Object.getPrototypeOf(n)===Object.prototype||Object.getPrototypeOf(n)===null)}function ra(n){if(n===void 0)return"undefined";if(n===null)return"null";if(typeof n=="string")return n.length>20&&(n=`${n.substring(0,20)}...`),JSON.stringify(n);if(typeof n=="number"||typeof n=="boolean")return""+n;if(typeof n=="object"){if(n instanceof Array)return"an array";{const e=function(r){return r.constructor?r.constructor.name:null}(n);return e?`a custom ${e} object`:"an object"}}return typeof n=="function"?"a function":K(12329,{type:typeof n})}function yt(n,e){if("_delegate"in n&&(n=n._delegate),!(n instanceof e)){if(e.name===n.constructor.name)throw new q(N.INVALID_ARGUMENT,"Type does not match the expected instance. Did you pass a reference from a different Firestore SDK?");{const t=ra(n);throw new q(N.INVALID_ARGUMENT,`Expected type '${e.name}', but it was: ${t}`)}}return n}function Dw(n,e){if(e<=0)throw new q(N.INVALID_ARGUMENT,`Function ${n}() requires a positive number, but it was: ${e}.`)}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Re(n,e){const t={typeString:n};return e&&(t.value=e),t}function Ro(n,e){if(!Yf(n))throw new q(N.INVALID_ARGUMENT,"JSON must be an object");let t;for(const r in e)if(e[r]){const i=e[r].typeString,o="value"in e[r]?{value:e[r].value}:void 0;if(!(r in n)){t=`JSON missing required field: '${r}'`;break}const s=n[r];if(i&&typeof s!==i){t=`JSON field '${r}' must be a ${i}.`;break}if(o!==void 0&&s!==o.value){t=`Expected '${r}' field to equal '${o.value}'`;break}}if(t)throw new q(N.INVALID_ARGUMENT,t);return!0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Oh=-62135596800,Nh=1e6;class me{static now(){return me.fromMillis(Date.now())}static fromDate(e){return me.fromMillis(e.getTime())}static fromMillis(e){const t=Math.floor(e/1e3),r=Math.floor((e-1e3*t)*Nh);return new me(t,r)}constructor(e,t){if(this.seconds=e,this.nanoseconds=t,t<0)throw new q(N.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+t);if(t>=1e9)throw new q(N.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+t);if(e<Oh)throw new q(N.INVALID_ARGUMENT,"Timestamp seconds out of range: "+e);if(e>=253402300800)throw new q(N.INVALID_ARGUMENT,"Timestamp seconds out of range: "+e)}toDate(){return new Date(this.toMillis())}toMillis(){return 1e3*this.seconds+this.nanoseconds/Nh}_compareTo(e){return this.seconds===e.seconds?re(this.nanoseconds,e.nanoseconds):re(this.seconds,e.seconds)}isEqual(e){return e.seconds===this.seconds&&e.nanoseconds===this.nanoseconds}toString(){return"Timestamp(seconds="+this.seconds+", nanoseconds="+this.nanoseconds+")"}toJSON(){return{type:me._jsonSchemaVersion,seconds:this.seconds,nanoseconds:this.nanoseconds}}static fromJSON(e){if(Ro(e,me._jsonSchema))return new me(e.seconds,e.nanoseconds)}valueOf(){const e=this.seconds-Oh;return String(e).padStart(12,"0")+"."+String(this.nanoseconds).padStart(9,"0")}}me._jsonSchemaVersion="firestore/timestamp/1.0",me._jsonSchema={type:Re("string",me._jsonSchemaVersion),seconds:Re("number"),nanoseconds:Re("number")};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Q{static fromTimestamp(e){return new Q(e)}static min(){return new Q(new me(0,0))}static max(){return new Q(new me(253402300799,999999999))}constructor(e){this.timestamp=e}compareTo(e){return this.timestamp._compareTo(e.timestamp)}isEqual(e){return this.timestamp.isEqual(e.timestamp)}toMicroseconds(){return 1e6*this.timestamp.seconds+this.timestamp.nanoseconds/1e3}toString(){return"SnapshotVersion("+this.timestamp.toString()+")"}toTimestamp(){return this.timestamp}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const uo=-1;function Lw(n,e){const t=n.toTimestamp().seconds,r=n.toTimestamp().nanoseconds+1,i=Q.fromTimestamp(r===1e9?new me(t+1,0):new me(t,r));return new Bn(i,H.empty(),e)}function Mw(n){return new Bn(n.readTime,n.key,uo)}class Bn{constructor(e,t,r){this.readTime=e,this.documentKey=t,this.largestBatchId=r}static min(){return new Bn(Q.min(),H.empty(),uo)}static max(){return new Bn(Q.max(),H.empty(),uo)}}function Vw(n,e){let t=n.readTime.compareTo(e.readTime);return t!==0?t:(t=H.comparator(n.documentKey,e.documentKey),t!==0?t:re(n.largestBatchId,e.largestBatchId))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Fw="The current tab is not in the required state to perform this operation. It might be necessary to refresh the browser tab.";class Uw{constructor(){this.onCommittedListeners=[]}addOnCommittedListener(e){this.onCommittedListeners.push(e)}raiseOnCommittedEvent(){this.onCommittedListeners.forEach(e=>e())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function yi(n){if(n.code!==N.FAILED_PRECONDITION||n.message!==Fw)throw n;B("LocalStore","Unexpectedly lost primary lease")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class D{constructor(e){this.nextCallback=null,this.catchCallback=null,this.result=void 0,this.error=void 0,this.isDone=!1,this.callbackAttached=!1,e(t=>{this.isDone=!0,this.result=t,this.nextCallback&&this.nextCallback(t)},t=>{this.isDone=!0,this.error=t,this.catchCallback&&this.catchCallback(t)})}catch(e){return this.next(void 0,e)}next(e,t){return this.callbackAttached&&K(59440),this.callbackAttached=!0,this.isDone?this.error?this.wrapFailure(t,this.error):this.wrapSuccess(e,this.result):new D((r,i)=>{this.nextCallback=o=>{this.wrapSuccess(e,o).next(r,i)},this.catchCallback=o=>{this.wrapFailure(t,o).next(r,i)}})}toPromise(){return new Promise((e,t)=>{this.next(e,t)})}wrapUserFunction(e){try{const t=e();return t instanceof D?t:D.resolve(t)}catch(t){return D.reject(t)}}wrapSuccess(e,t){return e?this.wrapUserFunction(()=>e(t)):D.resolve(t)}wrapFailure(e,t){return e?this.wrapUserFunction(()=>e(t)):D.reject(t)}static resolve(e){return new D((t,r)=>{t(e)})}static reject(e){return new D((t,r)=>{r(e)})}static waitFor(e){return new D((t,r)=>{let i=0,o=0,s=!1;e.forEach(l=>{++i,l.next(()=>{++o,s&&o===i&&t()},u=>r(u))}),s=!0,o===i&&t()})}static or(e){let t=D.resolve(!1);for(const r of e)t=t.next(i=>i?D.resolve(i):r());return t}static forEach(e,t){const r=[];return e.forEach((i,o)=>{r.push(t.call(this,i,o))}),this.waitFor(r)}static mapArray(e,t){return new D((r,i)=>{const o=e.length,s=new Array(o);let l=0;for(let u=0;u<o;u++){const d=u;t(e[d]).next(p=>{s[d]=p,++l,l===o&&r(s)},p=>i(p))}})}static doWhile(e,t){return new D((r,i)=>{const o=()=>{e()===!0?t().next(()=>{o()},i):r()};o()})}}function qw(n){const e=n.match(/Android ([\d.]+)/i),t=e?e[1].split(".").slice(0,2).join("."):"-1";return Number(t)}function vi(n){return n.name==="IndexedDbTransactionError"}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ia{constructor(e,t){this.previousValue=e,t&&(t.sequenceNumberHandler=r=>this.ae(r),this.ue=r=>t.writeSequenceNumber(r))}ae(e){return this.previousValue=Math.max(e,this.previousValue),this.previousValue}next(){const e=++this.previousValue;return this.ue&&this.ue(e),e}}ia.ce=-1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const oc=-1;function oa(n){return n==null}function Ls(n){return n===0&&1/n==-1/0}function $w(n){return typeof n=="number"&&Number.isInteger(n)&&!Ls(n)&&n<=Number.MAX_SAFE_INTEGER&&n>=Number.MIN_SAFE_INTEGER}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Qf="";function Bw(n){let e="";for(let t=0;t<n.length;t++)e.length>0&&(e=Dh(e)),e=jw(n.get(t),e);return Dh(e)}function jw(n,e){let t=e;const r=n.length;for(let i=0;i<r;i++){const o=n.charAt(i);switch(o){case"\0":t+="";break;case Qf:t+="";break;default:t+=o}}return t}function Dh(n){return n+Qf+""}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Lh(n){let e=0;for(const t in n)Object.prototype.hasOwnProperty.call(n,t)&&e++;return e}function Yn(n,e){for(const t in n)Object.prototype.hasOwnProperty.call(n,t)&&e(t,n[t])}function Jf(n){for(const e in n)if(Object.prototype.hasOwnProperty.call(n,e))return!1;return!0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class we{constructor(e,t){this.comparator=e,this.root=t||$e.EMPTY}insert(e,t){return new we(this.comparator,this.root.insert(e,t,this.comparator).copy(null,null,$e.BLACK,null,null))}remove(e){return new we(this.comparator,this.root.remove(e,this.comparator).copy(null,null,$e.BLACK,null,null))}get(e){let t=this.root;for(;!t.isEmpty();){const r=this.comparator(e,t.key);if(r===0)return t.value;r<0?t=t.left:r>0&&(t=t.right)}return null}indexOf(e){let t=0,r=this.root;for(;!r.isEmpty();){const i=this.comparator(e,r.key);if(i===0)return t+r.left.size;i<0?r=r.left:(t+=r.left.size+1,r=r.right)}return-1}isEmpty(){return this.root.isEmpty()}get size(){return this.root.size}minKey(){return this.root.minKey()}maxKey(){return this.root.maxKey()}inorderTraversal(e){return this.root.inorderTraversal(e)}forEach(e){this.inorderTraversal((t,r)=>(e(t,r),!1))}toString(){const e=[];return this.inorderTraversal((t,r)=>(e.push(`${t}:${r}`),!1)),`{${e.join(", ")}}`}reverseTraversal(e){return this.root.reverseTraversal(e)}getIterator(){return new es(this.root,null,this.comparator,!1)}getIteratorFrom(e){return new es(this.root,e,this.comparator,!1)}getReverseIterator(){return new es(this.root,null,this.comparator,!0)}getReverseIteratorFrom(e){return new es(this.root,e,this.comparator,!0)}}class es{constructor(e,t,r,i){this.isReverse=i,this.nodeStack=[];let o=1;for(;!e.isEmpty();)if(o=t?r(e.key,t):1,t&&i&&(o*=-1),o<0)e=this.isReverse?e.left:e.right;else{if(o===0){this.nodeStack.push(e);break}this.nodeStack.push(e),e=this.isReverse?e.right:e.left}}getNext(){let e=this.nodeStack.pop();const t={key:e.key,value:e.value};if(this.isReverse)for(e=e.left;!e.isEmpty();)this.nodeStack.push(e),e=e.right;else for(e=e.right;!e.isEmpty();)this.nodeStack.push(e),e=e.left;return t}hasNext(){return this.nodeStack.length>0}peek(){if(this.nodeStack.length===0)return null;const e=this.nodeStack[this.nodeStack.length-1];return{key:e.key,value:e.value}}}class $e{constructor(e,t,r,i,o){this.key=e,this.value=t,this.color=r??$e.RED,this.left=i??$e.EMPTY,this.right=o??$e.EMPTY,this.size=this.left.size+1+this.right.size}copy(e,t,r,i,o){return new $e(e??this.key,t??this.value,r??this.color,i??this.left,o??this.right)}isEmpty(){return!1}inorderTraversal(e){return this.left.inorderTraversal(e)||e(this.key,this.value)||this.right.inorderTraversal(e)}reverseTraversal(e){return this.right.reverseTraversal(e)||e(this.key,this.value)||this.left.reverseTraversal(e)}min(){return this.left.isEmpty()?this:this.left.min()}minKey(){return this.min().key}maxKey(){return this.right.isEmpty()?this.key:this.right.maxKey()}insert(e,t,r){let i=this;const o=r(e,i.key);return i=o<0?i.copy(null,null,null,i.left.insert(e,t,r),null):o===0?i.copy(null,t,null,null,null):i.copy(null,null,null,null,i.right.insert(e,t,r)),i.fixUp()}removeMin(){if(this.left.isEmpty())return $e.EMPTY;let e=this;return e.left.isRed()||e.left.left.isRed()||(e=e.moveRedLeft()),e=e.copy(null,null,null,e.left.removeMin(),null),e.fixUp()}remove(e,t){let r,i=this;if(t(e,i.key)<0)i.left.isEmpty()||i.left.isRed()||i.left.left.isRed()||(i=i.moveRedLeft()),i=i.copy(null,null,null,i.left.remove(e,t),null);else{if(i.left.isRed()&&(i=i.rotateRight()),i.right.isEmpty()||i.right.isRed()||i.right.left.isRed()||(i=i.moveRedRight()),t(e,i.key)===0){if(i.right.isEmpty())return $e.EMPTY;r=i.right.min(),i=i.copy(r.key,r.value,null,null,i.right.removeMin())}i=i.copy(null,null,null,null,i.right.remove(e,t))}return i.fixUp()}isRed(){return this.color}fixUp(){let e=this;return e.right.isRed()&&!e.left.isRed()&&(e=e.rotateLeft()),e.left.isRed()&&e.left.left.isRed()&&(e=e.rotateRight()),e.left.isRed()&&e.right.isRed()&&(e=e.colorFlip()),e}moveRedLeft(){let e=this.colorFlip();return e.right.left.isRed()&&(e=e.copy(null,null,null,null,e.right.rotateRight()),e=e.rotateLeft(),e=e.colorFlip()),e}moveRedRight(){let e=this.colorFlip();return e.left.left.isRed()&&(e=e.rotateRight(),e=e.colorFlip()),e}rotateLeft(){const e=this.copy(null,null,$e.RED,null,this.right.left);return this.right.copy(null,null,this.color,e,null)}rotateRight(){const e=this.copy(null,null,$e.RED,this.left.right,null);return this.left.copy(null,null,this.color,null,e)}colorFlip(){const e=this.left.copy(null,null,!this.left.color,null,null),t=this.right.copy(null,null,!this.right.color,null,null);return this.copy(null,null,!this.color,e,t)}checkMaxDepth(){const e=this.check();return Math.pow(2,e)<=this.size+1}check(){if(this.isRed()&&this.left.isRed())throw K(43730,{key:this.key,value:this.value});if(this.right.isRed())throw K(14113,{key:this.key,value:this.value});const e=this.left.check();if(e!==this.right.check())throw K(27949);return e+(this.isRed()?0:1)}}$e.EMPTY=null,$e.RED=!0,$e.BLACK=!1;$e.EMPTY=new class{constructor(){this.size=0}get key(){throw K(57766)}get value(){throw K(16141)}get color(){throw K(16727)}get left(){throw K(29726)}get right(){throw K(36894)}copy(e,t,r,i,o){return this}insert(e,t,r){return new $e(e,t)}remove(e,t){return this}isEmpty(){return!0}inorderTraversal(e){return!1}reverseTraversal(e){return!1}minKey(){return null}maxKey(){return null}isRed(){return!1}checkMaxDepth(){return!0}check(){return 0}};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ve{constructor(e){this.comparator=e,this.data=new we(this.comparator)}has(e){return this.data.get(e)!==null}first(){return this.data.minKey()}last(){return this.data.maxKey()}get size(){return this.data.size}indexOf(e){return this.data.indexOf(e)}forEach(e){this.data.inorderTraversal((t,r)=>(e(t),!1))}forEachInRange(e,t){const r=this.data.getIteratorFrom(e[0]);for(;r.hasNext();){const i=r.getNext();if(this.comparator(i.key,e[1])>=0)return;t(i.key)}}forEachWhile(e,t){let r;for(r=t!==void 0?this.data.getIteratorFrom(t):this.data.getIterator();r.hasNext();)if(!e(r.getNext().key))return}firstAfterOrEqual(e){const t=this.data.getIteratorFrom(e);return t.hasNext()?t.getNext().key:null}getIterator(){return new Mh(this.data.getIterator())}getIteratorFrom(e){return new Mh(this.data.getIteratorFrom(e))}add(e){return this.copy(this.data.remove(e).insert(e,!0))}delete(e){return this.has(e)?this.copy(this.data.remove(e)):this}isEmpty(){return this.data.isEmpty()}unionWith(e){let t=this;return t.size<e.size&&(t=e,e=this),e.forEach(r=>{t=t.add(r)}),t}isEqual(e){if(!(e instanceof Ve)||this.size!==e.size)return!1;const t=this.data.getIterator(),r=e.data.getIterator();for(;t.hasNext();){const i=t.getNext().key,o=r.getNext().key;if(this.comparator(i,o)!==0)return!1}return!0}toArray(){const e=[];return this.forEach(t=>{e.push(t)}),e}toString(){const e=[];return this.forEach(t=>e.push(t)),"SortedSet("+e.toString()+")"}copy(e){const t=new Ve(this.comparator);return t.data=e,t}}class Mh{constructor(e){this.iter=e}getNext(){return this.iter.getNext().key}hasNext(){return this.iter.hasNext()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class mt{constructor(e){this.fields=e,e.sort(Be.comparator)}static empty(){return new mt([])}unionWith(e){let t=new Ve(Be.comparator);for(const r of this.fields)t=t.add(r);for(const r of e)t=t.add(r);return new mt(t.toArray())}covers(e){for(const t of this.fields)if(t.isPrefixOf(e))return!0;return!1}isEqual(e){return ti(this.fields,e.fields,(t,r)=>t.isEqual(r))}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Xf extends Error{constructor(){super(...arguments),this.name="Base64DecodeError"}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ze{constructor(e){this.binaryString=e}static fromBase64String(e){const t=function(i){try{return atob(i)}catch(o){throw typeof DOMException<"u"&&o instanceof DOMException?new Xf("Invalid base64 string: "+o):o}}(e);return new ze(t)}static fromUint8Array(e){const t=function(i){let o="";for(let s=0;s<i.length;++s)o+=String.fromCharCode(i[s]);return o}(e);return new ze(t)}[Symbol.iterator](){let e=0;return{next:()=>e<this.binaryString.length?{value:this.binaryString.charCodeAt(e++),done:!1}:{value:void 0,done:!0}}}toBase64(){return function(t){return btoa(t)}(this.binaryString)}toUint8Array(){return function(t){const r=new Uint8Array(t.length);for(let i=0;i<t.length;i++)r[i]=t.charCodeAt(i);return r}(this.binaryString)}approximateByteSize(){return 2*this.binaryString.length}compareTo(e){return re(this.binaryString,e.binaryString)}isEqual(e){return this.binaryString===e.binaryString}}ze.EMPTY_BYTE_STRING=new ze("");const zw=new RegExp(/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.(\d+))?Z$/);function jn(n){if(ce(!!n,39018),typeof n=="string"){let e=0;const t=zw.exec(n);if(ce(!!t,46558,{timestamp:n}),t[1]){let i=t[1];i=(i+"000000000").substr(0,9),e=Number(i)}const r=new Date(n);return{seconds:Math.floor(r.getTime()/1e3),nanos:e}}return{seconds:Ae(n.seconds),nanos:Ae(n.nanos)}}function Ae(n){return typeof n=="number"?n:typeof n=="string"?Number(n):0}function zn(n){return typeof n=="string"?ze.fromBase64String(n):ze.fromUint8Array(n)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Zf="server_timestamp",ep="__type__",tp="__previous_value__",np="__local_write_time__";function sc(n){var t,r;return((r=(((t=n==null?void 0:n.mapValue)==null?void 0:t.fields)||{})[ep])==null?void 0:r.stringValue)===Zf}function sa(n){const e=n.mapValue.fields[tp];return sc(e)?sa(e):e}function ho(n){const e=jn(n.mapValue.fields[np].timestampValue);return new me(e.seconds,e.nanos)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ww{constructor(e,t,r,i,o,s,l,u,d,p,m){this.databaseId=e,this.appId=t,this.persistenceKey=r,this.host=i,this.ssl=o,this.forceLongPolling=s,this.autoDetectLongPolling=l,this.longPollingOptions=u,this.useFetchStreams=d,this.isUsingEmulator=p,this.apiKey=m}}const Ms="(default)";class fo{constructor(e,t){this.projectId=e,this.database=t||Ms}static empty(){return new fo("","")}get isDefaultDatabase(){return this.database===Ms}isEqual(e){return e instanceof fo&&e.projectId===this.projectId&&e.database===this.database}}function Hw(n,e){if(!Object.prototype.hasOwnProperty.apply(n.options,["projectId"]))throw new q(N.INVALID_ARGUMENT,'"projectId" not provided in firebase.initializeApp.');return new fo(n.options.projectId,e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const rp="__type__",Gw="__max__",ts={mapValue:{}},ip="__vector__",Vs="value";function Wn(n){return"nullValue"in n?0:"booleanValue"in n?1:"integerValue"in n||"doubleValue"in n?2:"timestampValue"in n?3:"stringValue"in n?5:"bytesValue"in n?6:"referenceValue"in n?7:"geoPointValue"in n?8:"arrayValue"in n?9:"mapValue"in n?sc(n)?4:Yw(n)?9007199254740991:Kw(n)?10:11:K(28295,{value:n})}function Wt(n,e){if(n===e)return!0;const t=Wn(n);if(t!==Wn(e))return!1;switch(t){case 0:case 9007199254740991:return!0;case 1:return n.booleanValue===e.booleanValue;case 4:return ho(n).isEqual(ho(e));case 3:return function(i,o){if(typeof i.timestampValue=="string"&&typeof o.timestampValue=="string"&&i.timestampValue.length===o.timestampValue.length)return i.timestampValue===o.timestampValue;const s=jn(i.timestampValue),l=jn(o.timestampValue);return s.seconds===l.seconds&&s.nanos===l.nanos}(n,e);case 5:return n.stringValue===e.stringValue;case 6:return function(i,o){return zn(i.bytesValue).isEqual(zn(o.bytesValue))}(n,e);case 7:return n.referenceValue===e.referenceValue;case 8:return function(i,o){return Ae(i.geoPointValue.latitude)===Ae(o.geoPointValue.latitude)&&Ae(i.geoPointValue.longitude)===Ae(o.geoPointValue.longitude)}(n,e);case 2:return function(i,o){if("integerValue"in i&&"integerValue"in o)return Ae(i.integerValue)===Ae(o.integerValue);if("doubleValue"in i&&"doubleValue"in o){const s=Ae(i.doubleValue),l=Ae(o.doubleValue);return s===l?Ls(s)===Ls(l):isNaN(s)&&isNaN(l)}return!1}(n,e);case 9:return ti(n.arrayValue.values||[],e.arrayValue.values||[],Wt);case 10:case 11:return function(i,o){const s=i.mapValue.fields||{},l=o.mapValue.fields||{};if(Lh(s)!==Lh(l))return!1;for(const u in s)if(s.hasOwnProperty(u)&&(l[u]===void 0||!Wt(s[u],l[u])))return!1;return!0}(n,e);default:return K(52216,{left:n})}}function po(n,e){return(n.values||[]).find(t=>Wt(t,e))!==void 0}function ni(n,e){if(n===e)return 0;const t=Wn(n),r=Wn(e);if(t!==r)return re(t,r);switch(t){case 0:case 9007199254740991:return 0;case 1:return re(n.booleanValue,e.booleanValue);case 2:return function(o,s){const l=Ae(o.integerValue||o.doubleValue),u=Ae(s.integerValue||s.doubleValue);return l<u?-1:l>u?1:l===u?0:isNaN(l)?isNaN(u)?0:-1:1}(n,e);case 3:return Vh(n.timestampValue,e.timestampValue);case 4:return Vh(ho(n),ho(e));case 5:return vl(n.stringValue,e.stringValue);case 6:return function(o,s){const l=zn(o),u=zn(s);return l.compareTo(u)}(n.bytesValue,e.bytesValue);case 7:return function(o,s){const l=o.split("/"),u=s.split("/");for(let d=0;d<l.length&&d<u.length;d++){const p=re(l[d],u[d]);if(p!==0)return p}return re(l.length,u.length)}(n.referenceValue,e.referenceValue);case 8:return function(o,s){const l=re(Ae(o.latitude),Ae(s.latitude));return l!==0?l:re(Ae(o.longitude),Ae(s.longitude))}(n.geoPointValue,e.geoPointValue);case 9:return Fh(n.arrayValue,e.arrayValue);case 10:return function(o,s){var g,b,O,A;const l=o.fields||{},u=s.fields||{},d=(g=l[Vs])==null?void 0:g.arrayValue,p=(b=u[Vs])==null?void 0:b.arrayValue,m=re(((O=d==null?void 0:d.values)==null?void 0:O.length)||0,((A=p==null?void 0:p.values)==null?void 0:A.length)||0);return m!==0?m:Fh(d,p)}(n.mapValue,e.mapValue);case 11:return function(o,s){if(o===ts.mapValue&&s===ts.mapValue)return 0;if(o===ts.mapValue)return 1;if(s===ts.mapValue)return-1;const l=o.fields||{},u=Object.keys(l),d=s.fields||{},p=Object.keys(d);u.sort(),p.sort();for(let m=0;m<u.length&&m<p.length;++m){const g=vl(u[m],p[m]);if(g!==0)return g;const b=ni(l[u[m]],d[p[m]]);if(b!==0)return b}return re(u.length,p.length)}(n.mapValue,e.mapValue);default:throw K(23264,{he:t})}}function Vh(n,e){if(typeof n=="string"&&typeof e=="string"&&n.length===e.length)return re(n,e);const t=jn(n),r=jn(e),i=re(t.seconds,r.seconds);return i!==0?i:re(t.nanos,r.nanos)}function Fh(n,e){const t=n.values||[],r=e.values||[];for(let i=0;i<t.length&&i<r.length;++i){const o=ni(t[i],r[i]);if(o)return o}return re(t.length,r.length)}function ri(n){return _l(n)}function _l(n){return"nullValue"in n?"null":"booleanValue"in n?""+n.booleanValue:"integerValue"in n?""+n.integerValue:"doubleValue"in n?""+n.doubleValue:"timestampValue"in n?function(t){const r=jn(t);return`time(${r.seconds},${r.nanos})`}(n.timestampValue):"stringValue"in n?n.stringValue:"bytesValue"in n?function(t){return zn(t).toBase64()}(n.bytesValue):"referenceValue"in n?function(t){return H.fromName(t).toString()}(n.referenceValue):"geoPointValue"in n?function(t){return`geo(${t.latitude},${t.longitude})`}(n.geoPointValue):"arrayValue"in n?function(t){let r="[",i=!0;for(const o of t.values||[])i?i=!1:r+=",",r+=_l(o);return r+"]"}(n.arrayValue):"mapValue"in n?function(t){const r=Object.keys(t.fields||{}).sort();let i="{",o=!0;for(const s of r)o?o=!1:i+=",",i+=`${s}:${_l(t.fields[s])}`;return i+"}"}(n.mapValue):K(61005,{value:n})}function vs(n){switch(Wn(n)){case 0:case 1:return 4;case 2:return 8;case 3:case 8:return 16;case 4:const e=sa(n);return e?16+vs(e):16;case 5:return 2*n.stringValue.length;case 6:return zn(n.bytesValue).approximateByteSize();case 7:return n.referenceValue.length;case 9:return function(r){return(r.values||[]).reduce((i,o)=>i+vs(o),0)}(n.arrayValue);case 10:case 11:return function(r){let i=0;return Yn(r.fields,(o,s)=>{i+=o.length+vs(s)}),i}(n.mapValue);default:throw K(13486,{value:n})}}function Uh(n,e){return{referenceValue:`projects/${n.projectId}/databases/${n.database}/documents/${e.path.canonicalString()}`}}function wl(n){return!!n&&"integerValue"in n}function ac(n){return!!n&&"arrayValue"in n}function qh(n){return!!n&&"nullValue"in n}function $h(n){return!!n&&"doubleValue"in n&&isNaN(Number(n.doubleValue))}function _s(n){return!!n&&"mapValue"in n}function Kw(n){var t,r;return((r=(((t=n==null?void 0:n.mapValue)==null?void 0:t.fields)||{})[rp])==null?void 0:r.stringValue)===ip}function eo(n){if(n.geoPointValue)return{geoPointValue:{...n.geoPointValue}};if(n.timestampValue&&typeof n.timestampValue=="object")return{timestampValue:{...n.timestampValue}};if(n.mapValue){const e={mapValue:{fields:{}}};return Yn(n.mapValue.fields,(t,r)=>e.mapValue.fields[t]=eo(r)),e}if(n.arrayValue){const e={arrayValue:{values:[]}};for(let t=0;t<(n.arrayValue.values||[]).length;++t)e.arrayValue.values[t]=eo(n.arrayValue.values[t]);return e}return{...n}}function Yw(n){return(((n.mapValue||{}).fields||{}).__type__||{}).stringValue===Gw}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class lt{constructor(e){this.value=e}static empty(){return new lt({mapValue:{}})}field(e){if(e.isEmpty())return this.value;{let t=this.value;for(let r=0;r<e.length-1;++r)if(t=(t.mapValue.fields||{})[e.get(r)],!_s(t))return null;return t=(t.mapValue.fields||{})[e.lastSegment()],t||null}}set(e,t){this.getFieldsMap(e.popLast())[e.lastSegment()]=eo(t)}setAll(e){let t=Be.emptyPath(),r={},i=[];e.forEach((s,l)=>{if(!t.isImmediateParentOf(l)){const u=this.getFieldsMap(t);this.applyChanges(u,r,i),r={},i=[],t=l.popLast()}s?r[l.lastSegment()]=eo(s):i.push(l.lastSegment())});const o=this.getFieldsMap(t);this.applyChanges(o,r,i)}delete(e){const t=this.field(e.popLast());_s(t)&&t.mapValue.fields&&delete t.mapValue.fields[e.lastSegment()]}isEqual(e){return Wt(this.value,e.value)}getFieldsMap(e){let t=this.value;t.mapValue.fields||(t.mapValue={fields:{}});for(let r=0;r<e.length;++r){let i=t.mapValue.fields[e.get(r)];_s(i)&&i.mapValue.fields||(i={mapValue:{fields:{}}},t.mapValue.fields[e.get(r)]=i),t=i}return t.mapValue.fields}applyChanges(e,t,r){Yn(t,(i,o)=>e[i]=o);for(const i of r)delete e[i]}clone(){return new lt(eo(this.value))}}function op(n){const e=[];return Yn(n.fields,(t,r)=>{const i=new Be([t]);if(_s(r)){const o=op(r.mapValue).fields;if(o.length===0)e.push(i);else for(const s of o)e.push(i.child(s))}else e.push(i)}),new mt(e)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ke{constructor(e,t,r,i,o,s,l){this.key=e,this.documentType=t,this.version=r,this.readTime=i,this.createTime=o,this.data=s,this.documentState=l}static newInvalidDocument(e){return new Ke(e,0,Q.min(),Q.min(),Q.min(),lt.empty(),0)}static newFoundDocument(e,t,r,i){return new Ke(e,1,t,Q.min(),r,i,0)}static newNoDocument(e,t){return new Ke(e,2,t,Q.min(),Q.min(),lt.empty(),0)}static newUnknownDocument(e,t){return new Ke(e,3,t,Q.min(),Q.min(),lt.empty(),2)}convertToFoundDocument(e,t){return!this.createTime.isEqual(Q.min())||this.documentType!==2&&this.documentType!==0||(this.createTime=e),this.version=e,this.documentType=1,this.data=t,this.documentState=0,this}convertToNoDocument(e){return this.version=e,this.documentType=2,this.data=lt.empty(),this.documentState=0,this}convertToUnknownDocument(e){return this.version=e,this.documentType=3,this.data=lt.empty(),this.documentState=2,this}setHasCommittedMutations(){return this.documentState=2,this}setHasLocalMutations(){return this.documentState=1,this.version=Q.min(),this}setReadTime(e){return this.readTime=e,this}get hasLocalMutations(){return this.documentState===1}get hasCommittedMutations(){return this.documentState===2}get hasPendingWrites(){return this.hasLocalMutations||this.hasCommittedMutations}isValidDocument(){return this.documentType!==0}isFoundDocument(){return this.documentType===1}isNoDocument(){return this.documentType===2}isUnknownDocument(){return this.documentType===3}isEqual(e){return e instanceof Ke&&this.key.isEqual(e.key)&&this.version.isEqual(e.version)&&this.documentType===e.documentType&&this.documentState===e.documentState&&this.data.isEqual(e.data)}mutableCopy(){return new Ke(this.key,this.documentType,this.version,this.readTime,this.createTime,this.data.clone(),this.documentState)}toString(){return`Document(${this.key}, ${this.version}, ${JSON.stringify(this.data.value)}, {createTime: ${this.createTime}}), {documentType: ${this.documentType}}), {documentState: ${this.documentState}})`}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Fs{constructor(e,t){this.position=e,this.inclusive=t}}function Bh(n,e,t){let r=0;for(let i=0;i<n.position.length;i++){const o=e[i],s=n.position[i];if(o.field.isKeyField()?r=H.comparator(H.fromName(s.referenceValue),t.key):r=ni(s,t.data.field(o.field)),o.dir==="desc"&&(r*=-1),r!==0)break}return r}function jh(n,e){if(n===null)return e===null;if(e===null||n.inclusive!==e.inclusive||n.position.length!==e.position.length)return!1;for(let t=0;t<n.position.length;t++)if(!Wt(n.position[t],e.position[t]))return!1;return!0}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class go{constructor(e,t="asc"){this.field=e,this.dir=t}}function Qw(n,e){return n.dir===e.dir&&n.field.isEqual(e.field)}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class sp{}class Ce extends sp{constructor(e,t,r){super(),this.field=e,this.op=t,this.value=r}static create(e,t,r){return e.isKeyField()?t==="in"||t==="not-in"?this.createKeyFieldInFilter(e,t,r):new Xw(e,t,r):t==="array-contains"?new tb(e,r):t==="in"?new nb(e,r):t==="not-in"?new rb(e,r):t==="array-contains-any"?new ib(e,r):new Ce(e,t,r)}static createKeyFieldInFilter(e,t,r){return t==="in"?new Zw(e,r):new eb(e,r)}matches(e){const t=e.data.field(this.field);return this.op==="!="?t!==null&&t.nullValue===void 0&&this.matchesComparison(ni(t,this.value)):t!==null&&Wn(this.value)===Wn(t)&&this.matchesComparison(ni(t,this.value))}matchesComparison(e){switch(this.op){case"<":return e<0;case"<=":return e<=0;case"==":return e===0;case"!=":return e!==0;case">":return e>0;case">=":return e>=0;default:return K(47266,{operator:this.op})}}isInequality(){return["<","<=",">",">=","!=","not-in"].indexOf(this.op)>=0}getFlattenedFilters(){return[this]}getFilters(){return[this]}}class kt extends sp{constructor(e,t){super(),this.filters=e,this.op=t,this.Pe=null}static create(e,t){return new kt(e,t)}matches(e){return ap(this)?this.filters.find(t=>!t.matches(e))===void 0:this.filters.find(t=>t.matches(e))!==void 0}getFlattenedFilters(){return this.Pe!==null||(this.Pe=this.filters.reduce((e,t)=>e.concat(t.getFlattenedFilters()),[])),this.Pe}getFilters(){return Object.assign([],this.filters)}}function ap(n){return n.op==="and"}function lp(n){return Jw(n)&&ap(n)}function Jw(n){for(const e of n.filters)if(e instanceof kt)return!1;return!0}function bl(n){if(n instanceof Ce)return n.field.canonicalString()+n.op.toString()+ri(n.value);if(lp(n))return n.filters.map(e=>bl(e)).join(",");{const e=n.filters.map(t=>bl(t)).join(",");return`${n.op}(${e})`}}function cp(n,e){return n instanceof Ce?function(r,i){return i instanceof Ce&&r.op===i.op&&r.field.isEqual(i.field)&&Wt(r.value,i.value)}(n,e):n instanceof kt?function(r,i){return i instanceof kt&&r.op===i.op&&r.filters.length===i.filters.length?r.filters.reduce((o,s,l)=>o&&cp(s,i.filters[l]),!0):!1}(n,e):void K(19439)}function up(n){return n instanceof Ce?function(t){return`${t.field.canonicalString()} ${t.op} ${ri(t.value)}`}(n):n instanceof kt?function(t){return t.op.toString()+" {"+t.getFilters().map(up).join(" ,")+"}"}(n):"Filter"}class Xw extends Ce{constructor(e,t,r){super(e,t,r),this.key=H.fromName(r.referenceValue)}matches(e){const t=H.comparator(e.key,this.key);return this.matchesComparison(t)}}class Zw extends Ce{constructor(e,t){super(e,"in",t),this.keys=hp("in",t)}matches(e){return this.keys.some(t=>t.isEqual(e.key))}}class eb extends Ce{constructor(e,t){super(e,"not-in",t),this.keys=hp("not-in",t)}matches(e){return!this.keys.some(t=>t.isEqual(e.key))}}function hp(n,e){var t;return(((t=e.arrayValue)==null?void 0:t.values)||[]).map(r=>H.fromName(r.referenceValue))}class tb extends Ce{constructor(e,t){super(e,"array-contains",t)}matches(e){const t=e.data.field(this.field);return ac(t)&&po(t.arrayValue,this.value)}}class nb extends Ce{constructor(e,t){super(e,"in",t)}matches(e){const t=e.data.field(this.field);return t!==null&&po(this.value.arrayValue,t)}}class rb extends Ce{constructor(e,t){super(e,"not-in",t)}matches(e){if(po(this.value.arrayValue,{nullValue:"NULL_VALUE"}))return!1;const t=e.data.field(this.field);return t!==null&&t.nullValue===void 0&&!po(this.value.arrayValue,t)}}class ib extends Ce{constructor(e,t){super(e,"array-contains-any",t)}matches(e){const t=e.data.field(this.field);return!(!ac(t)||!t.arrayValue.values)&&t.arrayValue.values.some(r=>po(this.value.arrayValue,r))}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ob{constructor(e,t=null,r=[],i=[],o=null,s=null,l=null){this.path=e,this.collectionGroup=t,this.orderBy=r,this.filters=i,this.limit=o,this.startAt=s,this.endAt=l,this.Te=null}}function zh(n,e=null,t=[],r=[],i=null,o=null,s=null){return new ob(n,e,t,r,i,o,s)}function lc(n){const e=X(n);if(e.Te===null){let t=e.path.canonicalString();e.collectionGroup!==null&&(t+="|cg:"+e.collectionGroup),t+="|f:",t+=e.filters.map(r=>bl(r)).join(","),t+="|ob:",t+=e.orderBy.map(r=>function(o){return o.field.canonicalString()+o.dir}(r)).join(","),oa(e.limit)||(t+="|l:",t+=e.limit),e.startAt&&(t+="|lb:",t+=e.startAt.inclusive?"b:":"a:",t+=e.startAt.position.map(r=>ri(r)).join(",")),e.endAt&&(t+="|ub:",t+=e.endAt.inclusive?"a:":"b:",t+=e.endAt.position.map(r=>ri(r)).join(",")),e.Te=t}return e.Te}function cc(n,e){if(n.limit!==e.limit||n.orderBy.length!==e.orderBy.length)return!1;for(let t=0;t<n.orderBy.length;t++)if(!Qw(n.orderBy[t],e.orderBy[t]))return!1;if(n.filters.length!==e.filters.length)return!1;for(let t=0;t<n.filters.length;t++)if(!cp(n.filters[t],e.filters[t]))return!1;return n.collectionGroup===e.collectionGroup&&!!n.path.isEqual(e.path)&&!!jh(n.startAt,e.startAt)&&jh(n.endAt,e.endAt)}function Tl(n){return H.isDocumentKey(n.path)&&n.collectionGroup===null&&n.filters.length===0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _i{constructor(e,t=null,r=[],i=[],o=null,s="F",l=null,u=null){this.path=e,this.collectionGroup=t,this.explicitOrderBy=r,this.filters=i,this.limit=o,this.limitType=s,this.startAt=l,this.endAt=u,this.Ee=null,this.Ie=null,this.Re=null,this.startAt,this.endAt}}function sb(n,e,t,r,i,o,s,l){return new _i(n,e,t,r,i,o,s,l)}function aa(n){return new _i(n)}function Wh(n){return n.filters.length===0&&n.limit===null&&n.startAt==null&&n.endAt==null&&(n.explicitOrderBy.length===0||n.explicitOrderBy.length===1&&n.explicitOrderBy[0].field.isKeyField())}function ab(n){return H.isDocumentKey(n.path)&&n.collectionGroup===null&&n.filters.length===0}function dp(n){return n.collectionGroup!==null}function to(n){const e=X(n);if(e.Ee===null){e.Ee=[];const t=new Set;for(const o of e.explicitOrderBy)e.Ee.push(o),t.add(o.field.canonicalString());const r=e.explicitOrderBy.length>0?e.explicitOrderBy[e.explicitOrderBy.length-1].dir:"asc";(function(s){let l=new Ve(Be.comparator);return s.filters.forEach(u=>{u.getFlattenedFilters().forEach(d=>{d.isInequality()&&(l=l.add(d.field))})}),l})(e).forEach(o=>{t.has(o.canonicalString())||o.isKeyField()||e.Ee.push(new go(o,r))}),t.has(Be.keyField().canonicalString())||e.Ee.push(new go(Be.keyField(),r))}return e.Ee}function $t(n){const e=X(n);return e.Ie||(e.Ie=lb(e,to(n))),e.Ie}function lb(n,e){if(n.limitType==="F")return zh(n.path,n.collectionGroup,e,n.filters,n.limit,n.startAt,n.endAt);{e=e.map(i=>{const o=i.dir==="desc"?"asc":"desc";return new go(i.field,o)});const t=n.endAt?new Fs(n.endAt.position,n.endAt.inclusive):null,r=n.startAt?new Fs(n.startAt.position,n.startAt.inclusive):null;return zh(n.path,n.collectionGroup,e,n.filters,n.limit,t,r)}}function El(n,e){const t=n.filters.concat([e]);return new _i(n.path,n.collectionGroup,n.explicitOrderBy.slice(),t,n.limit,n.limitType,n.startAt,n.endAt)}function cb(n,e){const t=n.explicitOrderBy.concat([e]);return new _i(n.path,n.collectionGroup,t,n.filters.slice(),n.limit,n.limitType,n.startAt,n.endAt)}function Us(n,e,t){return new _i(n.path,n.collectionGroup,n.explicitOrderBy.slice(),n.filters.slice(),e,t,n.startAt,n.endAt)}function la(n,e){return cc($t(n),$t(e))&&n.limitType===e.limitType}function fp(n){return`${lc($t(n))}|lt:${n.limitType}`}function Or(n){return`Query(target=${function(t){let r=t.path.canonicalString();return t.collectionGroup!==null&&(r+=" collectionGroup="+t.collectionGroup),t.filters.length>0&&(r+=`, filters: [${t.filters.map(i=>up(i)).join(", ")}]`),oa(t.limit)||(r+=", limit: "+t.limit),t.orderBy.length>0&&(r+=`, orderBy: [${t.orderBy.map(i=>function(s){return`${s.field.canonicalString()} (${s.dir})`}(i)).join(", ")}]`),t.startAt&&(r+=", startAt: ",r+=t.startAt.inclusive?"b:":"a:",r+=t.startAt.position.map(i=>ri(i)).join(",")),t.endAt&&(r+=", endAt: ",r+=t.endAt.inclusive?"a:":"b:",r+=t.endAt.position.map(i=>ri(i)).join(",")),`Target(${r})`}($t(n))}; limitType=${n.limitType})`}function ca(n,e){return e.isFoundDocument()&&function(r,i){const o=i.key.path;return r.collectionGroup!==null?i.key.hasCollectionId(r.collectionGroup)&&r.path.isPrefixOf(o):H.isDocumentKey(r.path)?r.path.isEqual(o):r.path.isImmediateParentOf(o)}(n,e)&&function(r,i){for(const o of to(r))if(!o.field.isKeyField()&&i.data.field(o.field)===null)return!1;return!0}(n,e)&&function(r,i){for(const o of r.filters)if(!o.matches(i))return!1;return!0}(n,e)&&function(r,i){return!(r.startAt&&!function(s,l,u){const d=Bh(s,l,u);return s.inclusive?d<=0:d<0}(r.startAt,to(r),i)||r.endAt&&!function(s,l,u){const d=Bh(s,l,u);return s.inclusive?d>=0:d>0}(r.endAt,to(r),i))}(n,e)}function ub(n){return n.collectionGroup||(n.path.length%2==1?n.path.lastSegment():n.path.get(n.path.length-2))}function pp(n){return(e,t)=>{let r=!1;for(const i of to(n)){const o=hb(i,e,t);if(o!==0)return o;r=r||i.field.isKeyField()}return 0}}function hb(n,e,t){const r=n.field.isKeyField()?H.comparator(e.key,t.key):function(o,s,l){const u=s.data.field(o),d=l.data.field(o);return u!==null&&d!==null?ni(u,d):K(42886)}(n.field,e,t);switch(n.dir){case"asc":return r;case"desc":return-1*r;default:return K(19790,{direction:n.dir})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Er{constructor(e,t){this.mapKeyFn=e,this.equalsFn=t,this.inner={},this.innerSize=0}get(e){const t=this.mapKeyFn(e),r=this.inner[t];if(r!==void 0){for(const[i,o]of r)if(this.equalsFn(i,e))return o}}has(e){return this.get(e)!==void 0}set(e,t){const r=this.mapKeyFn(e),i=this.inner[r];if(i===void 0)return this.inner[r]=[[e,t]],void this.innerSize++;for(let o=0;o<i.length;o++)if(this.equalsFn(i[o][0],e))return void(i[o]=[e,t]);i.push([e,t]),this.innerSize++}delete(e){const t=this.mapKeyFn(e),r=this.inner[t];if(r===void 0)return!1;for(let i=0;i<r.length;i++)if(this.equalsFn(r[i][0],e))return r.length===1?delete this.inner[t]:r.splice(i,1),this.innerSize--,!0;return!1}forEach(e){Yn(this.inner,(t,r)=>{for(const[i,o]of r)e(i,o)})}isEmpty(){return Jf(this.inner)}size(){return this.innerSize}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const db=new we(H.comparator);function fn(){return db}const gp=new we(H.comparator);function Gi(...n){let e=gp;for(const t of n)e=e.insert(t.key,t);return e}function mp(n){let e=gp;return n.forEach((t,r)=>e=e.insert(t,r.overlayedDocument)),e}function or(){return no()}function yp(){return no()}function no(){return new Er(n=>n.toString(),(n,e)=>n.isEqual(e))}const fb=new we(H.comparator),pb=new Ve(H.comparator);function ie(...n){let e=pb;for(const t of n)e=e.add(t);return e}const gb=new Ve(re);function mb(){return gb}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function uc(n,e){if(n.useProto3Json){if(isNaN(e))return{doubleValue:"NaN"};if(e===1/0)return{doubleValue:"Infinity"};if(e===-1/0)return{doubleValue:"-Infinity"}}return{doubleValue:Ls(e)?"-0":e}}function vp(n){return{integerValue:""+n}}function _p(n,e){return $w(e)?vp(e):uc(n,e)}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ua{constructor(){this._=void 0}}function yb(n,e,t){return n instanceof mo?function(i,o){const s={fields:{[ep]:{stringValue:Zf},[np]:{timestampValue:{seconds:i.seconds,nanos:i.nanoseconds}}}};return o&&sc(o)&&(o=sa(o)),o&&(s.fields[tp]=o),{mapValue:s}}(t,e):n instanceof yo?bp(n,e):n instanceof vo?Tp(n,e):function(i,o){const s=wp(i,o),l=Hh(s)+Hh(i.Ae);return wl(s)&&wl(i.Ae)?vp(l):uc(i.serializer,l)}(n,e)}function vb(n,e,t){return n instanceof yo?bp(n,e):n instanceof vo?Tp(n,e):t}function wp(n,e){return n instanceof _o?function(r){return wl(r)||function(o){return!!o&&"doubleValue"in o}(r)}(e)?e:{integerValue:0}:null}class mo extends ua{}class yo extends ua{constructor(e){super(),this.elements=e}}function bp(n,e){const t=Ep(e);for(const r of n.elements)t.some(i=>Wt(i,r))||t.push(r);return{arrayValue:{values:t}}}class vo extends ua{constructor(e){super(),this.elements=e}}function Tp(n,e){let t=Ep(e);for(const r of n.elements)t=t.filter(i=>!Wt(i,r));return{arrayValue:{values:t}}}class _o extends ua{constructor(e,t){super(),this.serializer=e,this.Ae=t}}function Hh(n){return Ae(n.integerValue||n.doubleValue)}function Ep(n){return ac(n)&&n.arrayValue.values?n.arrayValue.values.slice():[]}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ip{constructor(e,t){this.field=e,this.transform=t}}function _b(n,e){return n.field.isEqual(e.field)&&function(r,i){return r instanceof yo&&i instanceof yo||r instanceof vo&&i instanceof vo?ti(r.elements,i.elements,Wt):r instanceof _o&&i instanceof _o?Wt(r.Ae,i.Ae):r instanceof mo&&i instanceof mo}(n.transform,e.transform)}class wb{constructor(e,t){this.version=e,this.transformResults=t}}class Et{constructor(e,t){this.updateTime=e,this.exists=t}static none(){return new Et}static exists(e){return new Et(void 0,e)}static updateTime(e){return new Et(e)}get isNone(){return this.updateTime===void 0&&this.exists===void 0}isEqual(e){return this.exists===e.exists&&(this.updateTime?!!e.updateTime&&this.updateTime.isEqual(e.updateTime):!e.updateTime)}}function ws(n,e){return n.updateTime!==void 0?e.isFoundDocument()&&e.version.isEqual(n.updateTime):n.exists===void 0||n.exists===e.isFoundDocument()}class ha{}function Ap(n,e){if(!n.hasLocalMutations||e&&e.fields.length===0)return null;if(e===null)return n.isNoDocument()?new hc(n.key,Et.none()):new Oo(n.key,n.data,Et.none());{const t=n.data,r=lt.empty();let i=new Ve(Be.comparator);for(let o of e.fields)if(!i.has(o)){let s=t.field(o);s===null&&o.length>1&&(o=o.popLast(),s=t.field(o)),s===null?r.delete(o):r.set(o,s),i=i.add(o)}return new Qn(n.key,r,new mt(i.toArray()),Et.none())}}function bb(n,e,t){n instanceof Oo?function(i,o,s){const l=i.value.clone(),u=Kh(i.fieldTransforms,o,s.transformResults);l.setAll(u),o.convertToFoundDocument(s.version,l).setHasCommittedMutations()}(n,e,t):n instanceof Qn?function(i,o,s){if(!ws(i.precondition,o))return void o.convertToUnknownDocument(s.version);const l=Kh(i.fieldTransforms,o,s.transformResults),u=o.data;u.setAll(Sp(i)),u.setAll(l),o.convertToFoundDocument(s.version,u).setHasCommittedMutations()}(n,e,t):function(i,o,s){o.convertToNoDocument(s.version).setHasCommittedMutations()}(0,e,t)}function ro(n,e,t,r){return n instanceof Oo?function(o,s,l,u){if(!ws(o.precondition,s))return l;const d=o.value.clone(),p=Yh(o.fieldTransforms,u,s);return d.setAll(p),s.convertToFoundDocument(s.version,d).setHasLocalMutations(),null}(n,e,t,r):n instanceof Qn?function(o,s,l,u){if(!ws(o.precondition,s))return l;const d=Yh(o.fieldTransforms,u,s),p=s.data;return p.setAll(Sp(o)),p.setAll(d),s.convertToFoundDocument(s.version,p).setHasLocalMutations(),l===null?null:l.unionWith(o.fieldMask.fields).unionWith(o.fieldTransforms.map(m=>m.field))}(n,e,t,r):function(o,s,l){return ws(o.precondition,s)?(s.convertToNoDocument(s.version).setHasLocalMutations(),null):l}(n,e,t)}function Tb(n,e){let t=null;for(const r of n.fieldTransforms){const i=e.data.field(r.field),o=wp(r.transform,i||null);o!=null&&(t===null&&(t=lt.empty()),t.set(r.field,o))}return t||null}function Gh(n,e){return n.type===e.type&&!!n.key.isEqual(e.key)&&!!n.precondition.isEqual(e.precondition)&&!!function(r,i){return r===void 0&&i===void 0||!(!r||!i)&&ti(r,i,(o,s)=>_b(o,s))}(n.fieldTransforms,e.fieldTransforms)&&(n.type===0?n.value.isEqual(e.value):n.type!==1||n.data.isEqual(e.data)&&n.fieldMask.isEqual(e.fieldMask))}class Oo extends ha{constructor(e,t,r,i=[]){super(),this.key=e,this.value=t,this.precondition=r,this.fieldTransforms=i,this.type=0}getFieldMask(){return null}}class Qn extends ha{constructor(e,t,r,i,o=[]){super(),this.key=e,this.data=t,this.fieldMask=r,this.precondition=i,this.fieldTransforms=o,this.type=1}getFieldMask(){return this.fieldMask}}function Sp(n){const e=new Map;return n.fieldMask.fields.forEach(t=>{if(!t.isEmpty()){const r=n.data.field(t);e.set(t,r)}}),e}function Kh(n,e,t){const r=new Map;ce(n.length===t.length,32656,{Ve:t.length,de:n.length});for(let i=0;i<t.length;i++){const o=n[i],s=o.transform,l=e.data.field(o.field);r.set(o.field,vb(s,l,t[i]))}return r}function Yh(n,e,t){const r=new Map;for(const i of n){const o=i.transform,s=t.data.field(i.field);r.set(i.field,yb(o,s,e))}return r}class hc extends ha{constructor(e,t){super(),this.key=e,this.precondition=t,this.type=2,this.fieldTransforms=[]}getFieldMask(){return null}}class Eb extends ha{constructor(e,t){super(),this.key=e,this.precondition=t,this.type=3,this.fieldTransforms=[]}getFieldMask(){return null}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ib{constructor(e,t,r,i){this.batchId=e,this.localWriteTime=t,this.baseMutations=r,this.mutations=i}applyToRemoteDocument(e,t){const r=t.mutationResults;for(let i=0;i<this.mutations.length;i++){const o=this.mutations[i];o.key.isEqual(e.key)&&bb(o,e,r[i])}}applyToLocalView(e,t){for(const r of this.baseMutations)r.key.isEqual(e.key)&&(t=ro(r,e,t,this.localWriteTime));for(const r of this.mutations)r.key.isEqual(e.key)&&(t=ro(r,e,t,this.localWriteTime));return t}applyToLocalDocumentSet(e,t){const r=yp();return this.mutations.forEach(i=>{const o=e.get(i.key),s=o.overlayedDocument;let l=this.applyToLocalView(s,o.mutatedFields);l=t.has(i.key)?null:l;const u=Ap(s,l);u!==null&&r.set(i.key,u),s.isValidDocument()||s.convertToNoDocument(Q.min())}),r}keys(){return this.mutations.reduce((e,t)=>e.add(t.key),ie())}isEqual(e){return this.batchId===e.batchId&&ti(this.mutations,e.mutations,(t,r)=>Gh(t,r))&&ti(this.baseMutations,e.baseMutations,(t,r)=>Gh(t,r))}}class dc{constructor(e,t,r,i){this.batch=e,this.commitVersion=t,this.mutationResults=r,this.docVersions=i}static from(e,t,r){ce(e.mutations.length===r.length,58842,{me:e.mutations.length,fe:r.length});let i=function(){return fb}();const o=e.mutations;for(let s=0;s<o.length;s++)i=i.insert(o[s].key,r[s].version);return new dc(e,t,r,i)}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ab{constructor(e,t){this.largestBatchId=e,this.mutation=t}getKey(){return this.mutation.key}isEqual(e){return e!==null&&this.mutation===e.mutation}toString(){return`Overlay{
      largestBatchId: ${this.largestBatchId},
      mutation: ${this.mutation.toString()}
    }`}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Sb{constructor(e,t){this.count=e,this.unchangedNames=t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var ke,oe;function xb(n){switch(n){case N.OK:return K(64938);case N.CANCELLED:case N.UNKNOWN:case N.DEADLINE_EXCEEDED:case N.RESOURCE_EXHAUSTED:case N.INTERNAL:case N.UNAVAILABLE:case N.UNAUTHENTICATED:return!1;case N.INVALID_ARGUMENT:case N.NOT_FOUND:case N.ALREADY_EXISTS:case N.PERMISSION_DENIED:case N.FAILED_PRECONDITION:case N.ABORTED:case N.OUT_OF_RANGE:case N.UNIMPLEMENTED:case N.DATA_LOSS:return!0;default:return K(15467,{code:n})}}function xp(n){if(n===void 0)return dn("GRPC error has no .code"),N.UNKNOWN;switch(n){case ke.OK:return N.OK;case ke.CANCELLED:return N.CANCELLED;case ke.UNKNOWN:return N.UNKNOWN;case ke.DEADLINE_EXCEEDED:return N.DEADLINE_EXCEEDED;case ke.RESOURCE_EXHAUSTED:return N.RESOURCE_EXHAUSTED;case ke.INTERNAL:return N.INTERNAL;case ke.UNAVAILABLE:return N.UNAVAILABLE;case ke.UNAUTHENTICATED:return N.UNAUTHENTICATED;case ke.INVALID_ARGUMENT:return N.INVALID_ARGUMENT;case ke.NOT_FOUND:return N.NOT_FOUND;case ke.ALREADY_EXISTS:return N.ALREADY_EXISTS;case ke.PERMISSION_DENIED:return N.PERMISSION_DENIED;case ke.FAILED_PRECONDITION:return N.FAILED_PRECONDITION;case ke.ABORTED:return N.ABORTED;case ke.OUT_OF_RANGE:return N.OUT_OF_RANGE;case ke.UNIMPLEMENTED:return N.UNIMPLEMENTED;case ke.DATA_LOSS:return N.DATA_LOSS;default:return K(39323,{code:n})}}(oe=ke||(ke={}))[oe.OK=0]="OK",oe[oe.CANCELLED=1]="CANCELLED",oe[oe.UNKNOWN=2]="UNKNOWN",oe[oe.INVALID_ARGUMENT=3]="INVALID_ARGUMENT",oe[oe.DEADLINE_EXCEEDED=4]="DEADLINE_EXCEEDED",oe[oe.NOT_FOUND=5]="NOT_FOUND",oe[oe.ALREADY_EXISTS=6]="ALREADY_EXISTS",oe[oe.PERMISSION_DENIED=7]="PERMISSION_DENIED",oe[oe.UNAUTHENTICATED=16]="UNAUTHENTICATED",oe[oe.RESOURCE_EXHAUSTED=8]="RESOURCE_EXHAUSTED",oe[oe.FAILED_PRECONDITION=9]="FAILED_PRECONDITION",oe[oe.ABORTED=10]="ABORTED",oe[oe.OUT_OF_RANGE=11]="OUT_OF_RANGE",oe[oe.UNIMPLEMENTED=12]="UNIMPLEMENTED",oe[oe.INTERNAL=13]="INTERNAL",oe[oe.UNAVAILABLE=14]="UNAVAILABLE",oe[oe.DATA_LOSS=15]="DATA_LOSS";/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function kb(){return new TextEncoder}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Pb=new Fn([4294967295,4294967295],0);function Qh(n){const e=kb().encode(n),t=new qf;return t.update(e),new Uint8Array(t.digest())}function Jh(n){const e=new DataView(n.buffer),t=e.getUint32(0,!0),r=e.getUint32(4,!0),i=e.getUint32(8,!0),o=e.getUint32(12,!0);return[new Fn([t,r],0),new Fn([i,o],0)]}class fc{constructor(e,t,r){if(this.bitmap=e,this.padding=t,this.hashCount=r,t<0||t>=8)throw new Ki(`Invalid padding: ${t}`);if(r<0)throw new Ki(`Invalid hash count: ${r}`);if(e.length>0&&this.hashCount===0)throw new Ki(`Invalid hash count: ${r}`);if(e.length===0&&t!==0)throw new Ki(`Invalid padding when bitmap length is 0: ${t}`);this.ge=8*e.length-t,this.pe=Fn.fromNumber(this.ge)}ye(e,t,r){let i=e.add(t.multiply(Fn.fromNumber(r)));return i.compare(Pb)===1&&(i=new Fn([i.getBits(0),i.getBits(1)],0)),i.modulo(this.pe).toNumber()}we(e){return!!(this.bitmap[Math.floor(e/8)]&1<<e%8)}mightContain(e){if(this.ge===0)return!1;const t=Qh(e),[r,i]=Jh(t);for(let o=0;o<this.hashCount;o++){const s=this.ye(r,i,o);if(!this.we(s))return!1}return!0}static create(e,t,r){const i=e%8==0?0:8-e%8,o=new Uint8Array(Math.ceil(e/8)),s=new fc(o,i,t);return r.forEach(l=>s.insert(l)),s}insert(e){if(this.ge===0)return;const t=Qh(e),[r,i]=Jh(t);for(let o=0;o<this.hashCount;o++){const s=this.ye(r,i,o);this.Se(s)}}Se(e){const t=Math.floor(e/8),r=e%8;this.bitmap[t]|=1<<r}}class Ki extends Error{constructor(){super(...arguments),this.name="BloomFilterError"}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class da{constructor(e,t,r,i,o){this.snapshotVersion=e,this.targetChanges=t,this.targetMismatches=r,this.documentUpdates=i,this.resolvedLimboDocuments=o}static createSynthesizedRemoteEventForCurrentChange(e,t,r){const i=new Map;return i.set(e,No.createSynthesizedTargetChangeForCurrentChange(e,t,r)),new da(Q.min(),i,new we(re),fn(),ie())}}class No{constructor(e,t,r,i,o){this.resumeToken=e,this.current=t,this.addedDocuments=r,this.modifiedDocuments=i,this.removedDocuments=o}static createSynthesizedTargetChangeForCurrentChange(e,t,r){return new No(r,t,ie(),ie(),ie())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class bs{constructor(e,t,r,i){this.be=e,this.removedTargetIds=t,this.key=r,this.De=i}}class kp{constructor(e,t){this.targetId=e,this.Ce=t}}class Pp{constructor(e,t,r=ze.EMPTY_BYTE_STRING,i=null){this.state=e,this.targetIds=t,this.resumeToken=r,this.cause=i}}class Xh{constructor(){this.ve=0,this.Fe=Zh(),this.Me=ze.EMPTY_BYTE_STRING,this.xe=!1,this.Oe=!0}get current(){return this.xe}get resumeToken(){return this.Me}get Ne(){return this.ve!==0}get Be(){return this.Oe}Le(e){e.approximateByteSize()>0&&(this.Oe=!0,this.Me=e)}ke(){let e=ie(),t=ie(),r=ie();return this.Fe.forEach((i,o)=>{switch(o){case 0:e=e.add(i);break;case 2:t=t.add(i);break;case 1:r=r.add(i);break;default:K(38017,{changeType:o})}}),new No(this.Me,this.xe,e,t,r)}qe(){this.Oe=!1,this.Fe=Zh()}Ke(e,t){this.Oe=!0,this.Fe=this.Fe.insert(e,t)}Ue(e){this.Oe=!0,this.Fe=this.Fe.remove(e)}$e(){this.ve+=1}We(){this.ve-=1,ce(this.ve>=0,3241,{ve:this.ve})}Qe(){this.Oe=!0,this.xe=!0}}class Cb{constructor(e){this.Ge=e,this.ze=new Map,this.je=fn(),this.Je=ns(),this.He=ns(),this.Ze=new we(re)}Xe(e){for(const t of e.be)e.De&&e.De.isFoundDocument()?this.Ye(t,e.De):this.et(t,e.key,e.De);for(const t of e.removedTargetIds)this.et(t,e.key,e.De)}tt(e){this.forEachTarget(e,t=>{const r=this.nt(t);switch(e.state){case 0:this.rt(t)&&r.Le(e.resumeToken);break;case 1:r.We(),r.Ne||r.qe(),r.Le(e.resumeToken);break;case 2:r.We(),r.Ne||this.removeTarget(t);break;case 3:this.rt(t)&&(r.Qe(),r.Le(e.resumeToken));break;case 4:this.rt(t)&&(this.it(t),r.Le(e.resumeToken));break;default:K(56790,{state:e.state})}})}forEachTarget(e,t){e.targetIds.length>0?e.targetIds.forEach(t):this.ze.forEach((r,i)=>{this.rt(i)&&t(i)})}st(e){const t=e.targetId,r=e.Ce.count,i=this.ot(t);if(i){const o=i.target;if(Tl(o))if(r===0){const s=new H(o.path);this.et(t,s,Ke.newNoDocument(s,Q.min()))}else ce(r===1,20013,{expectedCount:r});else{const s=this._t(t);if(s!==r){const l=this.ut(e),u=l?this.ct(l,e,s):1;if(u!==0){this.it(t);const d=u===2?"TargetPurposeExistenceFilterMismatchBloom":"TargetPurposeExistenceFilterMismatch";this.Ze=this.Ze.insert(t,d)}}}}}ut(e){const t=e.Ce.unchangedNames;if(!t||!t.bits)return null;const{bits:{bitmap:r="",padding:i=0},hashCount:o=0}=t;let s,l;try{s=zn(r).toUint8Array()}catch(u){if(u instanceof Xf)return _r("Decoding the base64 bloom filter in existence filter failed ("+u.message+"); ignoring the bloom filter and falling back to full re-query."),null;throw u}try{l=new fc(s,i,o)}catch(u){return _r(u instanceof Ki?"BloomFilter error: ":"Applying bloom filter failed: ",u),null}return l.ge===0?null:l}ct(e,t,r){return t.Ce.count===r-this.Pt(e,t.targetId)?0:2}Pt(e,t){const r=this.Ge.getRemoteKeysForTarget(t);let i=0;return r.forEach(o=>{const s=this.Ge.ht(),l=`projects/${s.projectId}/databases/${s.database}/documents/${o.path.canonicalString()}`;e.mightContain(l)||(this.et(t,o,null),i++)}),i}Tt(e){const t=new Map;this.ze.forEach((o,s)=>{const l=this.ot(s);if(l){if(o.current&&Tl(l.target)){const u=new H(l.target.path);this.Et(u).has(s)||this.It(s,u)||this.et(s,u,Ke.newNoDocument(u,e))}o.Be&&(t.set(s,o.ke()),o.qe())}});let r=ie();this.He.forEach((o,s)=>{let l=!0;s.forEachWhile(u=>{const d=this.ot(u);return!d||d.purpose==="TargetPurposeLimboResolution"||(l=!1,!1)}),l&&(r=r.add(o))}),this.je.forEach((o,s)=>s.setReadTime(e));const i=new da(e,t,this.Ze,this.je,r);return this.je=fn(),this.Je=ns(),this.He=ns(),this.Ze=new we(re),i}Ye(e,t){if(!this.rt(e))return;const r=this.It(e,t.key)?2:0;this.nt(e).Ke(t.key,r),this.je=this.je.insert(t.key,t),this.Je=this.Je.insert(t.key,this.Et(t.key).add(e)),this.He=this.He.insert(t.key,this.Rt(t.key).add(e))}et(e,t,r){if(!this.rt(e))return;const i=this.nt(e);this.It(e,t)?i.Ke(t,1):i.Ue(t),this.He=this.He.insert(t,this.Rt(t).delete(e)),this.He=this.He.insert(t,this.Rt(t).add(e)),r&&(this.je=this.je.insert(t,r))}removeTarget(e){this.ze.delete(e)}_t(e){const t=this.nt(e).ke();return this.Ge.getRemoteKeysForTarget(e).size+t.addedDocuments.size-t.removedDocuments.size}$e(e){this.nt(e).$e()}nt(e){let t=this.ze.get(e);return t||(t=new Xh,this.ze.set(e,t)),t}Rt(e){let t=this.He.get(e);return t||(t=new Ve(re),this.He=this.He.insert(e,t)),t}Et(e){let t=this.Je.get(e);return t||(t=new Ve(re),this.Je=this.Je.insert(e,t)),t}rt(e){const t=this.ot(e)!==null;return t||B("WatchChangeAggregator","Detected inactive target",e),t}ot(e){const t=this.ze.get(e);return t&&t.Ne?null:this.Ge.At(e)}it(e){this.ze.set(e,new Xh),this.Ge.getRemoteKeysForTarget(e).forEach(t=>{this.et(e,t,null)})}It(e,t){return this.Ge.getRemoteKeysForTarget(e).has(t)}}function ns(){return new we(H.comparator)}function Zh(){return new we(H.comparator)}const Rb={asc:"ASCENDING",desc:"DESCENDING"},Ob={"<":"LESS_THAN","<=":"LESS_THAN_OR_EQUAL",">":"GREATER_THAN",">=":"GREATER_THAN_OR_EQUAL","==":"EQUAL","!=":"NOT_EQUAL","array-contains":"ARRAY_CONTAINS",in:"IN","not-in":"NOT_IN","array-contains-any":"ARRAY_CONTAINS_ANY"},Nb={and:"AND",or:"OR"};class Db{constructor(e,t){this.databaseId=e,this.useProto3Json=t}}function Il(n,e){return n.useProto3Json||oa(e)?e:{value:e}}function qs(n,e){return n.useProto3Json?`${new Date(1e3*e.seconds).toISOString().replace(/\.\d*/,"").replace("Z","")}.${("000000000"+e.nanoseconds).slice(-9)}Z`:{seconds:""+e.seconds,nanos:e.nanoseconds}}function Cp(n,e){return n.useProto3Json?e.toBase64():e.toUint8Array()}function Lb(n,e){return qs(n,e.toTimestamp())}function Bt(n){return ce(!!n,49232),Q.fromTimestamp(function(t){const r=jn(t);return new me(r.seconds,r.nanos)}(n))}function pc(n,e){return Al(n,e).canonicalString()}function Al(n,e){const t=function(i){return new fe(["projects",i.projectId,"databases",i.database])}(n).child("documents");return e===void 0?t:t.child(e)}function Rp(n){const e=fe.fromString(n);return ce(Mp(e),10190,{key:e.toString()}),e}function Sl(n,e){return pc(n.databaseId,e.path)}function Ja(n,e){const t=Rp(e);if(t.get(1)!==n.databaseId.projectId)throw new q(N.INVALID_ARGUMENT,"Tried to deserialize key from different project: "+t.get(1)+" vs "+n.databaseId.projectId);if(t.get(3)!==n.databaseId.database)throw new q(N.INVALID_ARGUMENT,"Tried to deserialize key from different database: "+t.get(3)+" vs "+n.databaseId.database);return new H(Np(t))}function Op(n,e){return pc(n.databaseId,e)}function Mb(n){const e=Rp(n);return e.length===4?fe.emptyPath():Np(e)}function xl(n){return new fe(["projects",n.databaseId.projectId,"databases",n.databaseId.database]).canonicalString()}function Np(n){return ce(n.length>4&&n.get(4)==="documents",29091,{key:n.toString()}),n.popFirst(5)}function ed(n,e,t){return{name:Sl(n,e),fields:t.value.mapValue.fields}}function Vb(n,e){let t;if("targetChange"in e){e.targetChange;const r=function(d){return d==="NO_CHANGE"?0:d==="ADD"?1:d==="REMOVE"?2:d==="CURRENT"?3:d==="RESET"?4:K(39313,{state:d})}(e.targetChange.targetChangeType||"NO_CHANGE"),i=e.targetChange.targetIds||[],o=function(d,p){return d.useProto3Json?(ce(p===void 0||typeof p=="string",58123),ze.fromBase64String(p||"")):(ce(p===void 0||p instanceof Buffer||p instanceof Uint8Array,16193),ze.fromUint8Array(p||new Uint8Array))}(n,e.targetChange.resumeToken),s=e.targetChange.cause,l=s&&function(d){const p=d.code===void 0?N.UNKNOWN:xp(d.code);return new q(p,d.message||"")}(s);t=new Pp(r,i,o,l||null)}else if("documentChange"in e){e.documentChange;const r=e.documentChange;r.document,r.document.name,r.document.updateTime;const i=Ja(n,r.document.name),o=Bt(r.document.updateTime),s=r.document.createTime?Bt(r.document.createTime):Q.min(),l=new lt({mapValue:{fields:r.document.fields}}),u=Ke.newFoundDocument(i,o,s,l),d=r.targetIds||[],p=r.removedTargetIds||[];t=new bs(d,p,u.key,u)}else if("documentDelete"in e){e.documentDelete;const r=e.documentDelete;r.document;const i=Ja(n,r.document),o=r.readTime?Bt(r.readTime):Q.min(),s=Ke.newNoDocument(i,o),l=r.removedTargetIds||[];t=new bs([],l,s.key,s)}else if("documentRemove"in e){e.documentRemove;const r=e.documentRemove;r.document;const i=Ja(n,r.document),o=r.removedTargetIds||[];t=new bs([],o,i,null)}else{if(!("filter"in e))return K(11601,{Vt:e});{e.filter;const r=e.filter;r.targetId;const{count:i=0,unchangedNames:o}=r,s=new Sb(i,o),l=r.targetId;t=new kp(l,s)}}return t}function Fb(n,e){let t;if(e instanceof Oo)t={update:ed(n,e.key,e.value)};else if(e instanceof hc)t={delete:Sl(n,e.key)};else if(e instanceof Qn)t={update:ed(n,e.key,e.data),updateMask:Gb(e.fieldMask)};else{if(!(e instanceof Eb))return K(16599,{dt:e.type});t={verify:Sl(n,e.key)}}return e.fieldTransforms.length>0&&(t.updateTransforms=e.fieldTransforms.map(r=>function(o,s){const l=s.transform;if(l instanceof mo)return{fieldPath:s.field.canonicalString(),setToServerValue:"REQUEST_TIME"};if(l instanceof yo)return{fieldPath:s.field.canonicalString(),appendMissingElements:{values:l.elements}};if(l instanceof vo)return{fieldPath:s.field.canonicalString(),removeAllFromArray:{values:l.elements}};if(l instanceof _o)return{fieldPath:s.field.canonicalString(),increment:l.Ae};throw K(20930,{transform:s.transform})}(0,r))),e.precondition.isNone||(t.currentDocument=function(i,o){return o.updateTime!==void 0?{updateTime:Lb(i,o.updateTime)}:o.exists!==void 0?{exists:o.exists}:K(27497)}(n,e.precondition)),t}function Ub(n,e){return n&&n.length>0?(ce(e!==void 0,14353),n.map(t=>function(i,o){let s=i.updateTime?Bt(i.updateTime):Bt(o);return s.isEqual(Q.min())&&(s=Bt(o)),new wb(s,i.transformResults||[])}(t,e))):[]}function qb(n,e){return{documents:[Op(n,e.path)]}}function $b(n,e){const t={structuredQuery:{}},r=e.path;let i;e.collectionGroup!==null?(i=r,t.structuredQuery.from=[{collectionId:e.collectionGroup,allDescendants:!0}]):(i=r.popLast(),t.structuredQuery.from=[{collectionId:r.lastSegment()}]),t.parent=Op(n,i);const o=function(d){if(d.length!==0)return Lp(kt.create(d,"and"))}(e.filters);o&&(t.structuredQuery.where=o);const s=function(d){if(d.length!==0)return d.map(p=>function(g){return{field:Nr(g.field),direction:zb(g.dir)}}(p))}(e.orderBy);s&&(t.structuredQuery.orderBy=s);const l=Il(n,e.limit);return l!==null&&(t.structuredQuery.limit=l),e.startAt&&(t.structuredQuery.startAt=function(d){return{before:d.inclusive,values:d.position}}(e.startAt)),e.endAt&&(t.structuredQuery.endAt=function(d){return{before:!d.inclusive,values:d.position}}(e.endAt)),{ft:t,parent:i}}function Bb(n){let e=Mb(n.parent);const t=n.structuredQuery,r=t.from?t.from.length:0;let i=null;if(r>0){ce(r===1,65062);const p=t.from[0];p.allDescendants?i=p.collectionId:e=e.child(p.collectionId)}let o=[];t.where&&(o=function(m){const g=Dp(m);return g instanceof kt&&lp(g)?g.getFilters():[g]}(t.where));let s=[];t.orderBy&&(s=function(m){return m.map(g=>function(O){return new go(Dr(O.field),function(P){switch(P){case"ASCENDING":return"asc";case"DESCENDING":return"desc";default:return}}(O.direction))}(g))}(t.orderBy));let l=null;t.limit&&(l=function(m){let g;return g=typeof m=="object"?m.value:m,oa(g)?null:g}(t.limit));let u=null;t.startAt&&(u=function(m){const g=!!m.before,b=m.values||[];return new Fs(b,g)}(t.startAt));let d=null;return t.endAt&&(d=function(m){const g=!m.before,b=m.values||[];return new Fs(b,g)}(t.endAt)),sb(e,i,s,o,l,"F",u,d)}function jb(n,e){const t=function(i){switch(i){case"TargetPurposeListen":return null;case"TargetPurposeExistenceFilterMismatch":return"existence-filter-mismatch";case"TargetPurposeExistenceFilterMismatchBloom":return"existence-filter-mismatch-bloom";case"TargetPurposeLimboResolution":return"limbo-document";default:return K(28987,{purpose:i})}}(e.purpose);return t==null?null:{"goog-listen-tags":t}}function Dp(n){return n.unaryFilter!==void 0?function(t){switch(t.unaryFilter.op){case"IS_NAN":const r=Dr(t.unaryFilter.field);return Ce.create(r,"==",{doubleValue:NaN});case"IS_NULL":const i=Dr(t.unaryFilter.field);return Ce.create(i,"==",{nullValue:"NULL_VALUE"});case"IS_NOT_NAN":const o=Dr(t.unaryFilter.field);return Ce.create(o,"!=",{doubleValue:NaN});case"IS_NOT_NULL":const s=Dr(t.unaryFilter.field);return Ce.create(s,"!=",{nullValue:"NULL_VALUE"});case"OPERATOR_UNSPECIFIED":return K(61313);default:return K(60726)}}(n):n.fieldFilter!==void 0?function(t){return Ce.create(Dr(t.fieldFilter.field),function(i){switch(i){case"EQUAL":return"==";case"NOT_EQUAL":return"!=";case"GREATER_THAN":return">";case"GREATER_THAN_OR_EQUAL":return">=";case"LESS_THAN":return"<";case"LESS_THAN_OR_EQUAL":return"<=";case"ARRAY_CONTAINS":return"array-contains";case"IN":return"in";case"NOT_IN":return"not-in";case"ARRAY_CONTAINS_ANY":return"array-contains-any";case"OPERATOR_UNSPECIFIED":return K(58110);default:return K(50506)}}(t.fieldFilter.op),t.fieldFilter.value)}(n):n.compositeFilter!==void 0?function(t){return kt.create(t.compositeFilter.filters.map(r=>Dp(r)),function(i){switch(i){case"AND":return"and";case"OR":return"or";default:return K(1026)}}(t.compositeFilter.op))}(n):K(30097,{filter:n})}function zb(n){return Rb[n]}function Wb(n){return Ob[n]}function Hb(n){return Nb[n]}function Nr(n){return{fieldPath:n.canonicalString()}}function Dr(n){return Be.fromServerFormat(n.fieldPath)}function Lp(n){return n instanceof Ce?function(t){if(t.op==="=="){if($h(t.value))return{unaryFilter:{field:Nr(t.field),op:"IS_NAN"}};if(qh(t.value))return{unaryFilter:{field:Nr(t.field),op:"IS_NULL"}}}else if(t.op==="!="){if($h(t.value))return{unaryFilter:{field:Nr(t.field),op:"IS_NOT_NAN"}};if(qh(t.value))return{unaryFilter:{field:Nr(t.field),op:"IS_NOT_NULL"}}}return{fieldFilter:{field:Nr(t.field),op:Wb(t.op),value:t.value}}}(n):n instanceof kt?function(t){const r=t.getFilters().map(i=>Lp(i));return r.length===1?r[0]:{compositeFilter:{op:Hb(t.op),filters:r}}}(n):K(54877,{filter:n})}function Gb(n){const e=[];return n.fields.forEach(t=>e.push(t.canonicalString())),{fieldPaths:e}}function Mp(n){return n.length>=4&&n.get(0)==="projects"&&n.get(2)==="databases"}function Vp(n){return!!n&&typeof n._toProto=="function"&&n._protoValueType==="ProtoValue"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Rn{constructor(e,t,r,i,o=Q.min(),s=Q.min(),l=ze.EMPTY_BYTE_STRING,u=null){this.target=e,this.targetId=t,this.purpose=r,this.sequenceNumber=i,this.snapshotVersion=o,this.lastLimboFreeSnapshotVersion=s,this.resumeToken=l,this.expectedCount=u}withSequenceNumber(e){return new Rn(this.target,this.targetId,this.purpose,e,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,this.expectedCount)}withResumeToken(e,t){return new Rn(this.target,this.targetId,this.purpose,this.sequenceNumber,t,this.lastLimboFreeSnapshotVersion,e,null)}withExpectedCount(e){return new Rn(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,e)}withLastLimboFreeSnapshotVersion(e){return new Rn(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,e,this.resumeToken,this.expectedCount)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Kb{constructor(e){this.yt=e}}function Yb(n){const e=Bb({parent:n.parent,structuredQuery:n.structuredQuery});return n.limitType==="LAST"?Us(e,e.limit,"L"):e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Qb{constructor(){this.bn=new Jb}addToCollectionParentIndex(e,t){return this.bn.add(t),D.resolve()}getCollectionParents(e,t){return D.resolve(this.bn.getEntries(t))}addFieldIndex(e,t){return D.resolve()}deleteFieldIndex(e,t){return D.resolve()}deleteAllFieldIndexes(e){return D.resolve()}createTargetIndexes(e,t){return D.resolve()}getDocumentsMatchingTarget(e,t){return D.resolve(null)}getIndexType(e,t){return D.resolve(0)}getFieldIndexes(e,t){return D.resolve([])}getNextCollectionGroupToUpdate(e){return D.resolve(null)}getMinOffset(e,t){return D.resolve(Bn.min())}getMinOffsetFromCollectionGroup(e,t){return D.resolve(Bn.min())}updateCollectionGroup(e,t,r){return D.resolve()}updateIndexEntries(e,t){return D.resolve()}}class Jb{constructor(){this.index={}}add(e){const t=e.lastSegment(),r=e.popLast(),i=this.index[t]||new Ve(fe.comparator),o=!i.has(r);return this.index[t]=i.add(r),o}has(e){const t=e.lastSegment(),r=e.popLast(),i=this.index[t];return i&&i.has(r)}getEntries(e){return(this.index[e]||new Ve(fe.comparator)).toArray()}}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const td={didRun:!1,sequenceNumbersCollected:0,targetsRemoved:0,documentsRemoved:0},Fp=41943040;class it{static withCacheSize(e){return new it(e,it.DEFAULT_COLLECTION_PERCENTILE,it.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT)}constructor(e,t,r){this.cacheSizeCollectionThreshold=e,this.percentileToCollect=t,this.maximumSequenceNumbersToCollect=r}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */it.DEFAULT_COLLECTION_PERCENTILE=10,it.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT=1e3,it.DEFAULT=new it(Fp,it.DEFAULT_COLLECTION_PERCENTILE,it.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT),it.DISABLED=new it(-1,0,0);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ii{constructor(e){this.sr=e}next(){return this.sr+=2,this.sr}static _r(){return new ii(0)}static ar(){return new ii(-1)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const nd="LruGarbageCollector",Xb=1048576;function rd([n,e],[t,r]){const i=re(n,t);return i===0?re(e,r):i}class Zb{constructor(e){this.Pr=e,this.buffer=new Ve(rd),this.Tr=0}Er(){return++this.Tr}Ir(e){const t=[e,this.Er()];if(this.buffer.size<this.Pr)this.buffer=this.buffer.add(t);else{const r=this.buffer.last();rd(t,r)<0&&(this.buffer=this.buffer.delete(r).add(t))}}get maxValue(){return this.buffer.last()[0]}}class eT{constructor(e,t,r){this.garbageCollector=e,this.asyncQueue=t,this.localStore=r,this.Rr=null}start(){this.garbageCollector.params.cacheSizeCollectionThreshold!==-1&&this.Ar(6e4)}stop(){this.Rr&&(this.Rr.cancel(),this.Rr=null)}get started(){return this.Rr!==null}Ar(e){B(nd,`Garbage collection scheduled in ${e}ms`),this.Rr=this.asyncQueue.enqueueAfterDelay("lru_garbage_collection",e,async()=>{this.Rr=null;try{await this.localStore.collectGarbage(this.garbageCollector)}catch(t){vi(t)?B(nd,"Ignoring IndexedDB error during garbage collection: ",t):await yi(t)}await this.Ar(3e5)})}}class tT{constructor(e,t){this.Vr=e,this.params=t}calculateTargetCount(e,t){return this.Vr.dr(e).next(r=>Math.floor(t/100*r))}nthSequenceNumber(e,t){if(t===0)return D.resolve(ia.ce);const r=new Zb(t);return this.Vr.forEachTarget(e,i=>r.Ir(i.sequenceNumber)).next(()=>this.Vr.mr(e,i=>r.Ir(i))).next(()=>r.maxValue)}removeTargets(e,t,r){return this.Vr.removeTargets(e,t,r)}removeOrphanedDocuments(e,t){return this.Vr.removeOrphanedDocuments(e,t)}collect(e,t){return this.params.cacheSizeCollectionThreshold===-1?(B("LruGarbageCollector","Garbage collection skipped; disabled"),D.resolve(td)):this.getCacheSize(e).next(r=>r<this.params.cacheSizeCollectionThreshold?(B("LruGarbageCollector",`Garbage collection skipped; Cache size ${r} is lower than threshold ${this.params.cacheSizeCollectionThreshold}`),td):this.gr(e,t))}getCacheSize(e){return this.Vr.getCacheSize(e)}gr(e,t){let r,i,o,s,l,u,d;const p=Date.now();return this.calculateTargetCount(e,this.params.percentileToCollect).next(m=>(m>this.params.maximumSequenceNumbersToCollect?(B("LruGarbageCollector",`Capping sequence numbers to collect down to the maximum of ${this.params.maximumSequenceNumbersToCollect} from ${m}`),i=this.params.maximumSequenceNumbersToCollect):i=m,s=Date.now(),this.nthSequenceNumber(e,i))).next(m=>(r=m,l=Date.now(),this.removeTargets(e,r,t))).next(m=>(o=m,u=Date.now(),this.removeOrphanedDocuments(e,r))).next(m=>(d=Date.now(),Rr()<=ne.DEBUG&&B("LruGarbageCollector",`LRU Garbage Collection
	Counted targets in ${s-p}ms
	Determined least recently used ${i} in `+(l-s)+`ms
	Removed ${o} targets in `+(u-l)+`ms
	Removed ${m} documents in `+(d-u)+`ms
Total Duration: ${d-p}ms`),D.resolve({didRun:!0,sequenceNumbersCollected:i,targetsRemoved:o,documentsRemoved:m})))}}function nT(n,e){return new tT(n,e)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class rT{constructor(){this.changes=new Er(e=>e.toString(),(e,t)=>e.isEqual(t)),this.changesApplied=!1}addEntry(e){this.assertNotApplied(),this.changes.set(e.key,e)}removeEntry(e,t){this.assertNotApplied(),this.changes.set(e,Ke.newInvalidDocument(e).setReadTime(t))}getEntry(e,t){this.assertNotApplied();const r=this.changes.get(t);return r!==void 0?D.resolve(r):this.getFromCache(e,t)}getEntries(e,t){return this.getAllFromCache(e,t)}apply(e){return this.assertNotApplied(),this.changesApplied=!0,this.applyChanges(e)}assertNotApplied(){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class iT{constructor(e,t){this.overlayedDocument=e,this.mutatedFields=t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class oT{constructor(e,t,r,i){this.remoteDocumentCache=e,this.mutationQueue=t,this.documentOverlayCache=r,this.indexManager=i}getDocument(e,t){let r=null;return this.documentOverlayCache.getOverlay(e,t).next(i=>(r=i,this.remoteDocumentCache.getEntry(e,t))).next(i=>(r!==null&&ro(r.mutation,i,mt.empty(),me.now()),i))}getDocuments(e,t){return this.remoteDocumentCache.getEntries(e,t).next(r=>this.getLocalViewOfDocuments(e,r,ie()).next(()=>r))}getLocalViewOfDocuments(e,t,r=ie()){const i=or();return this.populateOverlays(e,i,t).next(()=>this.computeViews(e,t,i,r).next(o=>{let s=Gi();return o.forEach((l,u)=>{s=s.insert(l,u.overlayedDocument)}),s}))}getOverlayedDocuments(e,t){const r=or();return this.populateOverlays(e,r,t).next(()=>this.computeViews(e,t,r,ie()))}populateOverlays(e,t,r){const i=[];return r.forEach(o=>{t.has(o)||i.push(o)}),this.documentOverlayCache.getOverlays(e,i).next(o=>{o.forEach((s,l)=>{t.set(s,l)})})}computeViews(e,t,r,i){let o=fn();const s=no(),l=function(){return no()}();return t.forEach((u,d)=>{const p=r.get(d.key);i.has(d.key)&&(p===void 0||p.mutation instanceof Qn)?o=o.insert(d.key,d):p!==void 0?(s.set(d.key,p.mutation.getFieldMask()),ro(p.mutation,d,p.mutation.getFieldMask(),me.now())):s.set(d.key,mt.empty())}),this.recalculateAndSaveOverlays(e,o).next(u=>(u.forEach((d,p)=>s.set(d,p)),t.forEach((d,p)=>l.set(d,new iT(p,s.get(d)??null))),l))}recalculateAndSaveOverlays(e,t){const r=no();let i=new we((s,l)=>s-l),o=ie();return this.mutationQueue.getAllMutationBatchesAffectingDocumentKeys(e,t).next(s=>{for(const l of s)l.keys().forEach(u=>{const d=t.get(u);if(d===null)return;let p=r.get(u)||mt.empty();p=l.applyToLocalView(d,p),r.set(u,p);const m=(i.get(l.batchId)||ie()).add(u);i=i.insert(l.batchId,m)})}).next(()=>{const s=[],l=i.getReverseIterator();for(;l.hasNext();){const u=l.getNext(),d=u.key,p=u.value,m=yp();p.forEach(g=>{if(!o.has(g)){const b=Ap(t.get(g),r.get(g));b!==null&&m.set(g,b),o=o.add(g)}}),s.push(this.documentOverlayCache.saveOverlays(e,d,m))}return D.waitFor(s)}).next(()=>r)}recalculateAndSaveOverlaysForDocumentKeys(e,t){return this.remoteDocumentCache.getEntries(e,t).next(r=>this.recalculateAndSaveOverlays(e,r))}getDocumentsMatchingQuery(e,t,r,i){return ab(t)?this.getDocumentsMatchingDocumentQuery(e,t.path):dp(t)?this.getDocumentsMatchingCollectionGroupQuery(e,t,r,i):this.getDocumentsMatchingCollectionQuery(e,t,r,i)}getNextDocuments(e,t,r,i){return this.remoteDocumentCache.getAllFromCollectionGroup(e,t,r,i).next(o=>{const s=i-o.size>0?this.documentOverlayCache.getOverlaysForCollectionGroup(e,t,r.largestBatchId,i-o.size):D.resolve(or());let l=uo,u=o;return s.next(d=>D.forEach(d,(p,m)=>(l<m.largestBatchId&&(l=m.largestBatchId),o.get(p)?D.resolve():this.remoteDocumentCache.getEntry(e,p).next(g=>{u=u.insert(p,g)}))).next(()=>this.populateOverlays(e,d,o)).next(()=>this.computeViews(e,u,d,ie())).next(p=>({batchId:l,changes:mp(p)})))})}getDocumentsMatchingDocumentQuery(e,t){return this.getDocument(e,new H(t)).next(r=>{let i=Gi();return r.isFoundDocument()&&(i=i.insert(r.key,r)),i})}getDocumentsMatchingCollectionGroupQuery(e,t,r,i){const o=t.collectionGroup;let s=Gi();return this.indexManager.getCollectionParents(e,o).next(l=>D.forEach(l,u=>{const d=function(m,g){return new _i(g,null,m.explicitOrderBy.slice(),m.filters.slice(),m.limit,m.limitType,m.startAt,m.endAt)}(t,u.child(o));return this.getDocumentsMatchingCollectionQuery(e,d,r,i).next(p=>{p.forEach((m,g)=>{s=s.insert(m,g)})})}).next(()=>s))}getDocumentsMatchingCollectionQuery(e,t,r,i){let o;return this.documentOverlayCache.getOverlaysForCollection(e,t.path,r.largestBatchId).next(s=>(o=s,this.remoteDocumentCache.getDocumentsMatchingQuery(e,t,r,o,i))).next(s=>{o.forEach((u,d)=>{const p=d.getKey();s.get(p)===null&&(s=s.insert(p,Ke.newInvalidDocument(p)))});let l=Gi();return s.forEach((u,d)=>{const p=o.get(u);p!==void 0&&ro(p.mutation,d,mt.empty(),me.now()),ca(t,d)&&(l=l.insert(u,d))}),l})}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class sT{constructor(e){this.serializer=e,this.Nr=new Map,this.Br=new Map}getBundleMetadata(e,t){return D.resolve(this.Nr.get(t))}saveBundleMetadata(e,t){return this.Nr.set(t.id,function(i){return{id:i.id,version:i.version,createTime:Bt(i.createTime)}}(t)),D.resolve()}getNamedQuery(e,t){return D.resolve(this.Br.get(t))}saveNamedQuery(e,t){return this.Br.set(t.name,function(i){return{name:i.name,query:Yb(i.bundledQuery),readTime:Bt(i.readTime)}}(t)),D.resolve()}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class aT{constructor(){this.overlays=new we(H.comparator),this.Lr=new Map}getOverlay(e,t){return D.resolve(this.overlays.get(t))}getOverlays(e,t){const r=or();return D.forEach(t,i=>this.getOverlay(e,i).next(o=>{o!==null&&r.set(i,o)})).next(()=>r)}saveOverlays(e,t,r){return r.forEach((i,o)=>{this.St(e,t,o)}),D.resolve()}removeOverlaysForBatchId(e,t,r){const i=this.Lr.get(r);return i!==void 0&&(i.forEach(o=>this.overlays=this.overlays.remove(o)),this.Lr.delete(r)),D.resolve()}getOverlaysForCollection(e,t,r){const i=or(),o=t.length+1,s=new H(t.child("")),l=this.overlays.getIteratorFrom(s);for(;l.hasNext();){const u=l.getNext().value,d=u.getKey();if(!t.isPrefixOf(d.path))break;d.path.length===o&&u.largestBatchId>r&&i.set(u.getKey(),u)}return D.resolve(i)}getOverlaysForCollectionGroup(e,t,r,i){let o=new we((d,p)=>d-p);const s=this.overlays.getIterator();for(;s.hasNext();){const d=s.getNext().value;if(d.getKey().getCollectionGroup()===t&&d.largestBatchId>r){let p=o.get(d.largestBatchId);p===null&&(p=or(),o=o.insert(d.largestBatchId,p)),p.set(d.getKey(),d)}}const l=or(),u=o.getIterator();for(;u.hasNext()&&(u.getNext().value.forEach((d,p)=>l.set(d,p)),!(l.size()>=i)););return D.resolve(l)}St(e,t,r){const i=this.overlays.get(r.key);if(i!==null){const s=this.Lr.get(i.largestBatchId).delete(r.key);this.Lr.set(i.largestBatchId,s)}this.overlays=this.overlays.insert(r.key,new Ab(t,r));let o=this.Lr.get(t);o===void 0&&(o=ie(),this.Lr.set(t,o)),this.Lr.set(t,o.add(r.key))}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class lT{constructor(){this.sessionToken=ze.EMPTY_BYTE_STRING}getSessionToken(e){return D.resolve(this.sessionToken)}setSessionToken(e,t){return this.sessionToken=t,D.resolve()}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class gc{constructor(){this.kr=new Ve(Ue.qr),this.Kr=new Ve(Ue.Ur)}isEmpty(){return this.kr.isEmpty()}addReference(e,t){const r=new Ue(e,t);this.kr=this.kr.add(r),this.Kr=this.Kr.add(r)}$r(e,t){e.forEach(r=>this.addReference(r,t))}removeReference(e,t){this.Wr(new Ue(e,t))}Qr(e,t){e.forEach(r=>this.removeReference(r,t))}Gr(e){const t=new H(new fe([])),r=new Ue(t,e),i=new Ue(t,e+1),o=[];return this.Kr.forEachInRange([r,i],s=>{this.Wr(s),o.push(s.key)}),o}zr(){this.kr.forEach(e=>this.Wr(e))}Wr(e){this.kr=this.kr.delete(e),this.Kr=this.Kr.delete(e)}jr(e){const t=new H(new fe([])),r=new Ue(t,e),i=new Ue(t,e+1);let o=ie();return this.Kr.forEachInRange([r,i],s=>{o=o.add(s.key)}),o}containsKey(e){const t=new Ue(e,0),r=this.kr.firstAfterOrEqual(t);return r!==null&&e.isEqual(r.key)}}class Ue{constructor(e,t){this.key=e,this.Jr=t}static qr(e,t){return H.comparator(e.key,t.key)||re(e.Jr,t.Jr)}static Ur(e,t){return re(e.Jr,t.Jr)||H.comparator(e.key,t.key)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class cT{constructor(e,t){this.indexManager=e,this.referenceDelegate=t,this.mutationQueue=[],this.Yn=1,this.Hr=new Ve(Ue.qr)}checkEmpty(e){return D.resolve(this.mutationQueue.length===0)}addMutationBatch(e,t,r,i){const o=this.Yn;this.Yn++,this.mutationQueue.length>0&&this.mutationQueue[this.mutationQueue.length-1];const s=new Ib(o,t,r,i);this.mutationQueue.push(s);for(const l of i)this.Hr=this.Hr.add(new Ue(l.key,o)),this.indexManager.addToCollectionParentIndex(e,l.key.path.popLast());return D.resolve(s)}lookupMutationBatch(e,t){return D.resolve(this.Zr(t))}getNextMutationBatchAfterBatchId(e,t){const r=t+1,i=this.Xr(r),o=i<0?0:i;return D.resolve(this.mutationQueue.length>o?this.mutationQueue[o]:null)}getHighestUnacknowledgedBatchId(){return D.resolve(this.mutationQueue.length===0?oc:this.Yn-1)}getAllMutationBatches(e){return D.resolve(this.mutationQueue.slice())}getAllMutationBatchesAffectingDocumentKey(e,t){const r=new Ue(t,0),i=new Ue(t,Number.POSITIVE_INFINITY),o=[];return this.Hr.forEachInRange([r,i],s=>{const l=this.Zr(s.Jr);o.push(l)}),D.resolve(o)}getAllMutationBatchesAffectingDocumentKeys(e,t){let r=new Ve(re);return t.forEach(i=>{const o=new Ue(i,0),s=new Ue(i,Number.POSITIVE_INFINITY);this.Hr.forEachInRange([o,s],l=>{r=r.add(l.Jr)})}),D.resolve(this.Yr(r))}getAllMutationBatchesAffectingQuery(e,t){const r=t.path,i=r.length+1;let o=r;H.isDocumentKey(o)||(o=o.child(""));const s=new Ue(new H(o),0);let l=new Ve(re);return this.Hr.forEachWhile(u=>{const d=u.key.path;return!!r.isPrefixOf(d)&&(d.length===i&&(l=l.add(u.Jr)),!0)},s),D.resolve(this.Yr(l))}Yr(e){const t=[];return e.forEach(r=>{const i=this.Zr(r);i!==null&&t.push(i)}),t}removeMutationBatch(e,t){ce(this.ei(t.batchId,"removed")===0,55003),this.mutationQueue.shift();let r=this.Hr;return D.forEach(t.mutations,i=>{const o=new Ue(i.key,t.batchId);return r=r.delete(o),this.referenceDelegate.markPotentiallyOrphaned(e,i.key)}).next(()=>{this.Hr=r})}nr(e){}containsKey(e,t){const r=new Ue(t,0),i=this.Hr.firstAfterOrEqual(r);return D.resolve(t.isEqual(i&&i.key))}performConsistencyCheck(e){return this.mutationQueue.length,D.resolve()}ei(e,t){return this.Xr(e)}Xr(e){return this.mutationQueue.length===0?0:e-this.mutationQueue[0].batchId}Zr(e){const t=this.Xr(e);return t<0||t>=this.mutationQueue.length?null:this.mutationQueue[t]}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class uT{constructor(e){this.ti=e,this.docs=function(){return new we(H.comparator)}(),this.size=0}setIndexManager(e){this.indexManager=e}addEntry(e,t){const r=t.key,i=this.docs.get(r),o=i?i.size:0,s=this.ti(t);return this.docs=this.docs.insert(r,{document:t.mutableCopy(),size:s}),this.size+=s-o,this.indexManager.addToCollectionParentIndex(e,r.path.popLast())}removeEntry(e){const t=this.docs.get(e);t&&(this.docs=this.docs.remove(e),this.size-=t.size)}getEntry(e,t){const r=this.docs.get(t);return D.resolve(r?r.document.mutableCopy():Ke.newInvalidDocument(t))}getEntries(e,t){let r=fn();return t.forEach(i=>{const o=this.docs.get(i);r=r.insert(i,o?o.document.mutableCopy():Ke.newInvalidDocument(i))}),D.resolve(r)}getDocumentsMatchingQuery(e,t,r,i){let o=fn();const s=t.path,l=new H(s.child("__id-9223372036854775808__")),u=this.docs.getIteratorFrom(l);for(;u.hasNext();){const{key:d,value:{document:p}}=u.getNext();if(!s.isPrefixOf(d.path))break;d.path.length>s.length+1||Vw(Mw(p),r)<=0||(i.has(p.key)||ca(t,p))&&(o=o.insert(p.key,p.mutableCopy()))}return D.resolve(o)}getAllFromCollectionGroup(e,t,r,i){K(9500)}ni(e,t){return D.forEach(this.docs,r=>t(r))}newChangeBuffer(e){return new hT(this)}getSize(e){return D.resolve(this.size)}}class hT extends rT{constructor(e){super(),this.Mr=e}applyChanges(e){const t=[];return this.changes.forEach((r,i)=>{i.isValidDocument()?t.push(this.Mr.addEntry(e,i)):this.Mr.removeEntry(r)}),D.waitFor(t)}getFromCache(e,t){return this.Mr.getEntry(e,t)}getAllFromCache(e,t){return this.Mr.getEntries(e,t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class dT{constructor(e){this.persistence=e,this.ri=new Er(t=>lc(t),cc),this.lastRemoteSnapshotVersion=Q.min(),this.highestTargetId=0,this.ii=0,this.si=new gc,this.targetCount=0,this.oi=ii._r()}forEachTarget(e,t){return this.ri.forEach((r,i)=>t(i)),D.resolve()}getLastRemoteSnapshotVersion(e){return D.resolve(this.lastRemoteSnapshotVersion)}getHighestSequenceNumber(e){return D.resolve(this.ii)}allocateTargetId(e){return this.highestTargetId=this.oi.next(),D.resolve(this.highestTargetId)}setTargetsMetadata(e,t,r){return r&&(this.lastRemoteSnapshotVersion=r),t>this.ii&&(this.ii=t),D.resolve()}lr(e){this.ri.set(e.target,e);const t=e.targetId;t>this.highestTargetId&&(this.oi=new ii(t),this.highestTargetId=t),e.sequenceNumber>this.ii&&(this.ii=e.sequenceNumber)}addTargetData(e,t){return this.lr(t),this.targetCount+=1,D.resolve()}updateTargetData(e,t){return this.lr(t),D.resolve()}removeTargetData(e,t){return this.ri.delete(t.target),this.si.Gr(t.targetId),this.targetCount-=1,D.resolve()}removeTargets(e,t,r){let i=0;const o=[];return this.ri.forEach((s,l)=>{l.sequenceNumber<=t&&r.get(l.targetId)===null&&(this.ri.delete(s),o.push(this.removeMatchingKeysForTargetId(e,l.targetId)),i++)}),D.waitFor(o).next(()=>i)}getTargetCount(e){return D.resolve(this.targetCount)}getTargetData(e,t){const r=this.ri.get(t)||null;return D.resolve(r)}addMatchingKeys(e,t,r){return this.si.$r(t,r),D.resolve()}removeMatchingKeys(e,t,r){this.si.Qr(t,r);const i=this.persistence.referenceDelegate,o=[];return i&&t.forEach(s=>{o.push(i.markPotentiallyOrphaned(e,s))}),D.waitFor(o)}removeMatchingKeysForTargetId(e,t){return this.si.Gr(t),D.resolve()}getMatchingKeysForTargetId(e,t){const r=this.si.jr(t);return D.resolve(r)}containsKey(e,t){return D.resolve(this.si.containsKey(t))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Up{constructor(e,t){this._i={},this.overlays={},this.ai=new ia(0),this.ui=!1,this.ui=!0,this.ci=new lT,this.referenceDelegate=e(this),this.li=new dT(this),this.indexManager=new Qb,this.remoteDocumentCache=function(i){return new uT(i)}(r=>this.referenceDelegate.hi(r)),this.serializer=new Kb(t),this.Pi=new sT(this.serializer)}start(){return Promise.resolve()}shutdown(){return this.ui=!1,Promise.resolve()}get started(){return this.ui}setDatabaseDeletedListener(){}setNetworkEnabled(){}getIndexManager(e){return this.indexManager}getDocumentOverlayCache(e){let t=this.overlays[e.toKey()];return t||(t=new aT,this.overlays[e.toKey()]=t),t}getMutationQueue(e,t){let r=this._i[e.toKey()];return r||(r=new cT(t,this.referenceDelegate),this._i[e.toKey()]=r),r}getGlobalsCache(){return this.ci}getTargetCache(){return this.li}getRemoteDocumentCache(){return this.remoteDocumentCache}getBundleCache(){return this.Pi}runTransaction(e,t,r){B("MemoryPersistence","Starting transaction:",e);const i=new fT(this.ai.next());return this.referenceDelegate.Ti(),r(i).next(o=>this.referenceDelegate.Ei(i).next(()=>o)).toPromise().then(o=>(i.raiseOnCommittedEvent(),o))}Ii(e,t){return D.or(Object.values(this._i).map(r=>()=>r.containsKey(e,t)))}}class fT extends Uw{constructor(e){super(),this.currentSequenceNumber=e}}class mc{constructor(e){this.persistence=e,this.Ri=new gc,this.Ai=null}static Vi(e){return new mc(e)}get di(){if(this.Ai)return this.Ai;throw K(60996)}addReference(e,t,r){return this.Ri.addReference(r,t),this.di.delete(r.toString()),D.resolve()}removeReference(e,t,r){return this.Ri.removeReference(r,t),this.di.add(r.toString()),D.resolve()}markPotentiallyOrphaned(e,t){return this.di.add(t.toString()),D.resolve()}removeTarget(e,t){this.Ri.Gr(t.targetId).forEach(i=>this.di.add(i.toString()));const r=this.persistence.getTargetCache();return r.getMatchingKeysForTargetId(e,t.targetId).next(i=>{i.forEach(o=>this.di.add(o.toString()))}).next(()=>r.removeTargetData(e,t))}Ti(){this.Ai=new Set}Ei(e){const t=this.persistence.getRemoteDocumentCache().newChangeBuffer();return D.forEach(this.di,r=>{const i=H.fromPath(r);return this.mi(e,i).next(o=>{o||t.removeEntry(i,Q.min())})}).next(()=>(this.Ai=null,t.apply(e)))}updateLimboDocument(e,t){return this.mi(e,t).next(r=>{r?this.di.delete(t.toString()):this.di.add(t.toString())})}hi(e){return 0}mi(e,t){return D.or([()=>D.resolve(this.Ri.containsKey(t)),()=>this.persistence.getTargetCache().containsKey(e,t),()=>this.persistence.Ii(e,t)])}}class $s{constructor(e,t){this.persistence=e,this.fi=new Er(r=>Bw(r.path),(r,i)=>r.isEqual(i)),this.garbageCollector=nT(this,t)}static Vi(e,t){return new $s(e,t)}Ti(){}Ei(e){return D.resolve()}forEachTarget(e,t){return this.persistence.getTargetCache().forEachTarget(e,t)}dr(e){const t=this.pr(e);return this.persistence.getTargetCache().getTargetCount(e).next(r=>t.next(i=>r+i))}pr(e){let t=0;return this.mr(e,r=>{t++}).next(()=>t)}mr(e,t){return D.forEach(this.fi,(r,i)=>this.wr(e,r,i).next(o=>o?D.resolve():t(i)))}removeTargets(e,t,r){return this.persistence.getTargetCache().removeTargets(e,t,r)}removeOrphanedDocuments(e,t){let r=0;const i=this.persistence.getRemoteDocumentCache(),o=i.newChangeBuffer();return i.ni(e,s=>this.wr(e,s,t).next(l=>{l||(r++,o.removeEntry(s,Q.min()))})).next(()=>o.apply(e)).next(()=>r)}markPotentiallyOrphaned(e,t){return this.fi.set(t,e.currentSequenceNumber),D.resolve()}removeTarget(e,t){const r=t.withSequenceNumber(e.currentSequenceNumber);return this.persistence.getTargetCache().updateTargetData(e,r)}addReference(e,t,r){return this.fi.set(r,e.currentSequenceNumber),D.resolve()}removeReference(e,t,r){return this.fi.set(r,e.currentSequenceNumber),D.resolve()}updateLimboDocument(e,t){return this.fi.set(t,e.currentSequenceNumber),D.resolve()}hi(e){let t=e.key.toString().length;return e.isFoundDocument()&&(t+=vs(e.data.value)),t}wr(e,t,r){return D.or([()=>this.persistence.Ii(e,t),()=>this.persistence.getTargetCache().containsKey(e,t),()=>{const i=this.fi.get(t);return D.resolve(i!==void 0&&i>r)}])}getCacheSize(e){return this.persistence.getRemoteDocumentCache().getSize(e)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class yc{constructor(e,t,r,i){this.targetId=e,this.fromCache=t,this.Ts=r,this.Es=i}static Is(e,t){let r=ie(),i=ie();for(const o of t.docChanges)switch(o.type){case 0:r=r.add(o.doc.key);break;case 1:i=i.add(o.doc.key)}return new yc(e,t.fromCache,r,i)}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class pT{constructor(){this._documentReadCount=0}get documentReadCount(){return this._documentReadCount}incrementDocumentReadCount(e){this._documentReadCount+=e}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class gT{constructor(){this.Rs=!1,this.As=!1,this.Vs=100,this.ds=function(){return ny()?8:qw(Ye())>0?6:4}()}initialize(e,t){this.fs=e,this.indexManager=t,this.Rs=!0}getDocumentsMatchingQuery(e,t,r,i){const o={result:null};return this.gs(e,t).next(s=>{o.result=s}).next(()=>{if(!o.result)return this.ps(e,t,i,r).next(s=>{o.result=s})}).next(()=>{if(o.result)return;const s=new pT;return this.ys(e,t,s).next(l=>{if(o.result=l,this.As)return this.ws(e,t,s,l.size)})}).next(()=>o.result)}ws(e,t,r,i){return r.documentReadCount<this.Vs?(Rr()<=ne.DEBUG&&B("QueryEngine","SDK will not create cache indexes for query:",Or(t),"since it only creates cache indexes for collection contains","more than or equal to",this.Vs,"documents"),D.resolve()):(Rr()<=ne.DEBUG&&B("QueryEngine","Query:",Or(t),"scans",r.documentReadCount,"local documents and returns",i,"documents as results."),r.documentReadCount>this.ds*i?(Rr()<=ne.DEBUG&&B("QueryEngine","The SDK decides to create cache indexes for query:",Or(t),"as using cache indexes may help improve performance."),this.indexManager.createTargetIndexes(e,$t(t))):D.resolve())}gs(e,t){if(Wh(t))return D.resolve(null);let r=$t(t);return this.indexManager.getIndexType(e,r).next(i=>i===0?null:(t.limit!==null&&i===1&&(t=Us(t,null,"F"),r=$t(t)),this.indexManager.getDocumentsMatchingTarget(e,r).next(o=>{const s=ie(...o);return this.fs.getDocuments(e,s).next(l=>this.indexManager.getMinOffset(e,r).next(u=>{const d=this.Ss(t,l);return this.bs(t,d,s,u.readTime)?this.gs(e,Us(t,null,"F")):this.Ds(e,d,t,u)}))})))}ps(e,t,r,i){return Wh(t)||i.isEqual(Q.min())?D.resolve(null):this.fs.getDocuments(e,r).next(o=>{const s=this.Ss(t,o);return this.bs(t,s,r,i)?D.resolve(null):(Rr()<=ne.DEBUG&&B("QueryEngine","Re-using previous result from %s to execute query: %s",i.toString(),Or(t)),this.Ds(e,s,t,Lw(i,uo)).next(l=>l))})}Ss(e,t){let r=new Ve(pp(e));return t.forEach((i,o)=>{ca(e,o)&&(r=r.add(o))}),r}bs(e,t,r,i){if(e.limit===null)return!1;if(r.size!==t.size)return!0;const o=e.limitType==="F"?t.last():t.first();return!!o&&(o.hasPendingWrites||o.version.compareTo(i)>0)}ys(e,t,r){return Rr()<=ne.DEBUG&&B("QueryEngine","Using full collection scan to execute query:",Or(t)),this.fs.getDocumentsMatchingQuery(e,t,Bn.min(),r)}Ds(e,t,r,i){return this.fs.getDocumentsMatchingQuery(e,r,i).next(o=>(t.forEach(s=>{o=o.insert(s.key,s)}),o))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const vc="LocalStore",mT=3e8;class yT{constructor(e,t,r,i){this.persistence=e,this.Cs=t,this.serializer=i,this.vs=new we(re),this.Fs=new Er(o=>lc(o),cc),this.Ms=new Map,this.xs=e.getRemoteDocumentCache(),this.li=e.getTargetCache(),this.Pi=e.getBundleCache(),this.Os(r)}Os(e){this.documentOverlayCache=this.persistence.getDocumentOverlayCache(e),this.indexManager=this.persistence.getIndexManager(e),this.mutationQueue=this.persistence.getMutationQueue(e,this.indexManager),this.localDocuments=new oT(this.xs,this.mutationQueue,this.documentOverlayCache,this.indexManager),this.xs.setIndexManager(this.indexManager),this.Cs.initialize(this.localDocuments,this.indexManager)}collectGarbage(e){return this.persistence.runTransaction("Collect garbage","readwrite-primary",t=>e.collect(t,this.vs))}}function vT(n,e,t,r){return new yT(n,e,t,r)}async function qp(n,e){const t=X(n);return await t.persistence.runTransaction("Handle user change","readonly",r=>{let i;return t.mutationQueue.getAllMutationBatches(r).next(o=>(i=o,t.Os(e),t.mutationQueue.getAllMutationBatches(r))).next(o=>{const s=[],l=[];let u=ie();for(const d of i){s.push(d.batchId);for(const p of d.mutations)u=u.add(p.key)}for(const d of o){l.push(d.batchId);for(const p of d.mutations)u=u.add(p.key)}return t.localDocuments.getDocuments(r,u).next(d=>({Ns:d,removedBatchIds:s,addedBatchIds:l}))})})}function _T(n,e){const t=X(n);return t.persistence.runTransaction("Acknowledge batch","readwrite-primary",r=>{const i=e.batch.keys(),o=t.xs.newChangeBuffer({trackRemovals:!0});return function(l,u,d,p){const m=d.batch,g=m.keys();let b=D.resolve();return g.forEach(O=>{b=b.next(()=>p.getEntry(u,O)).next(A=>{const P=d.docVersions.get(O);ce(P!==null,48541),A.version.compareTo(P)<0&&(m.applyToRemoteDocument(A,d),A.isValidDocument()&&(A.setReadTime(d.commitVersion),p.addEntry(A)))})}),b.next(()=>l.mutationQueue.removeMutationBatch(u,m))}(t,r,e,o).next(()=>o.apply(r)).next(()=>t.mutationQueue.performConsistencyCheck(r)).next(()=>t.documentOverlayCache.removeOverlaysForBatchId(r,i,e.batch.batchId)).next(()=>t.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(r,function(l){let u=ie();for(let d=0;d<l.mutationResults.length;++d)l.mutationResults[d].transformResults.length>0&&(u=u.add(l.batch.mutations[d].key));return u}(e))).next(()=>t.localDocuments.getDocuments(r,i))})}function $p(n){const e=X(n);return e.persistence.runTransaction("Get last remote snapshot version","readonly",t=>e.li.getLastRemoteSnapshotVersion(t))}function wT(n,e){const t=X(n),r=e.snapshotVersion;let i=t.vs;return t.persistence.runTransaction("Apply remote event","readwrite-primary",o=>{const s=t.xs.newChangeBuffer({trackRemovals:!0});i=t.vs;const l=[];e.targetChanges.forEach((p,m)=>{const g=i.get(m);if(!g)return;l.push(t.li.removeMatchingKeys(o,p.removedDocuments,m).next(()=>t.li.addMatchingKeys(o,p.addedDocuments,m)));let b=g.withSequenceNumber(o.currentSequenceNumber);e.targetMismatches.get(m)!==null?b=b.withResumeToken(ze.EMPTY_BYTE_STRING,Q.min()).withLastLimboFreeSnapshotVersion(Q.min()):p.resumeToken.approximateByteSize()>0&&(b=b.withResumeToken(p.resumeToken,r)),i=i.insert(m,b),function(A,P,V){return A.resumeToken.approximateByteSize()===0||P.snapshotVersion.toMicroseconds()-A.snapshotVersion.toMicroseconds()>=mT?!0:V.addedDocuments.size+V.modifiedDocuments.size+V.removedDocuments.size>0}(g,b,p)&&l.push(t.li.updateTargetData(o,b))});let u=fn(),d=ie();if(e.documentUpdates.forEach(p=>{e.resolvedLimboDocuments.has(p)&&l.push(t.persistence.referenceDelegate.updateLimboDocument(o,p))}),l.push(bT(o,s,e.documentUpdates).next(p=>{u=p.Bs,d=p.Ls})),!r.isEqual(Q.min())){const p=t.li.getLastRemoteSnapshotVersion(o).next(m=>t.li.setTargetsMetadata(o,o.currentSequenceNumber,r));l.push(p)}return D.waitFor(l).next(()=>s.apply(o)).next(()=>t.localDocuments.getLocalViewOfDocuments(o,u,d)).next(()=>u)}).then(o=>(t.vs=i,o))}function bT(n,e,t){let r=ie(),i=ie();return t.forEach(o=>r=r.add(o)),e.getEntries(n,r).next(o=>{let s=fn();return t.forEach((l,u)=>{const d=o.get(l);u.isFoundDocument()!==d.isFoundDocument()&&(i=i.add(l)),u.isNoDocument()&&u.version.isEqual(Q.min())?(e.removeEntry(l,u.readTime),s=s.insert(l,u)):!d.isValidDocument()||u.version.compareTo(d.version)>0||u.version.compareTo(d.version)===0&&d.hasPendingWrites?(e.addEntry(u),s=s.insert(l,u)):B(vc,"Ignoring outdated watch update for ",l,". Current version:",d.version," Watch version:",u.version)}),{Bs:s,Ls:i}})}function TT(n,e){const t=X(n);return t.persistence.runTransaction("Get next mutation batch","readonly",r=>(e===void 0&&(e=oc),t.mutationQueue.getNextMutationBatchAfterBatchId(r,e)))}function ET(n,e){const t=X(n);return t.persistence.runTransaction("Allocate target","readwrite",r=>{let i;return t.li.getTargetData(r,e).next(o=>o?(i=o,D.resolve(i)):t.li.allocateTargetId(r).next(s=>(i=new Rn(e,s,"TargetPurposeListen",r.currentSequenceNumber),t.li.addTargetData(r,i).next(()=>i))))}).then(r=>{const i=t.vs.get(r.targetId);return(i===null||r.snapshotVersion.compareTo(i.snapshotVersion)>0)&&(t.vs=t.vs.insert(r.targetId,r),t.Fs.set(e,r.targetId)),r})}async function kl(n,e,t){const r=X(n),i=r.vs.get(e),o=t?"readwrite":"readwrite-primary";try{t||await r.persistence.runTransaction("Release target",o,s=>r.persistence.referenceDelegate.removeTarget(s,i))}catch(s){if(!vi(s))throw s;B(vc,`Failed to update sequence numbers for target ${e}: ${s}`)}r.vs=r.vs.remove(e),r.Fs.delete(i.target)}function id(n,e,t){const r=X(n);let i=Q.min(),o=ie();return r.persistence.runTransaction("Execute query","readwrite",s=>function(u,d,p){const m=X(u),g=m.Fs.get(p);return g!==void 0?D.resolve(m.vs.get(g)):m.li.getTargetData(d,p)}(r,s,$t(e)).next(l=>{if(l)return i=l.lastLimboFreeSnapshotVersion,r.li.getMatchingKeysForTargetId(s,l.targetId).next(u=>{o=u})}).next(()=>r.Cs.getDocumentsMatchingQuery(s,e,t?i:Q.min(),t?o:ie())).next(l=>(IT(r,ub(e),l),{documents:l,ks:o})))}function IT(n,e,t){let r=n.Ms.get(e)||Q.min();t.forEach((i,o)=>{o.readTime.compareTo(r)>0&&(r=o.readTime)}),n.Ms.set(e,r)}class od{constructor(){this.activeTargetIds=mb()}Qs(e){this.activeTargetIds=this.activeTargetIds.add(e)}Gs(e){this.activeTargetIds=this.activeTargetIds.delete(e)}Ws(){const e={activeTargetIds:this.activeTargetIds.toArray(),updateTimeMs:Date.now()};return JSON.stringify(e)}}class AT{constructor(){this.vo=new od,this.Fo={},this.onlineStateHandler=null,this.sequenceNumberHandler=null}addPendingMutation(e){}updateMutationState(e,t,r){}addLocalQueryTarget(e,t=!0){return t&&this.vo.Qs(e),this.Fo[e]||"not-current"}updateQueryState(e,t,r){this.Fo[e]=t}removeLocalQueryTarget(e){this.vo.Gs(e)}isLocalQueryTarget(e){return this.vo.activeTargetIds.has(e)}clearQueryState(e){delete this.Fo[e]}getAllActiveQueryTargets(){return this.vo.activeTargetIds}isActiveQueryTarget(e){return this.vo.activeTargetIds.has(e)}start(){return this.vo=new od,Promise.resolve()}handleUserChange(e,t,r){}setOnlineState(e){}shutdown(){}writeSequenceNumber(e){}notifyBundleLoaded(e){}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ST{Mo(e){}shutdown(){}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const sd="ConnectivityMonitor";class ad{constructor(){this.xo=()=>this.Oo(),this.No=()=>this.Bo(),this.Lo=[],this.ko()}Mo(e){this.Lo.push(e)}shutdown(){window.removeEventListener("online",this.xo),window.removeEventListener("offline",this.No)}ko(){window.addEventListener("online",this.xo),window.addEventListener("offline",this.No)}Oo(){B(sd,"Network connectivity changed: AVAILABLE");for(const e of this.Lo)e(0)}Bo(){B(sd,"Network connectivity changed: UNAVAILABLE");for(const e of this.Lo)e(1)}static v(){return typeof window<"u"&&window.addEventListener!==void 0&&window.removeEventListener!==void 0}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let rs=null;function Pl(){return rs===null?rs=function(){return 268435456+Math.round(2147483648*Math.random())}():rs++,"0x"+rs.toString(16)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Xa="RestConnection",xT={BatchGetDocuments:"batchGet",Commit:"commit",RunQuery:"runQuery",RunAggregationQuery:"runAggregationQuery",ExecutePipeline:"executePipeline"};class kT{get qo(){return!1}constructor(e){this.databaseInfo=e,this.databaseId=e.databaseId;const t=e.ssl?"https":"http",r=encodeURIComponent(this.databaseId.projectId),i=encodeURIComponent(this.databaseId.database);this.Ko=t+"://"+e.host,this.Uo=`projects/${r}/databases/${i}`,this.$o=this.databaseId.database===Ms?`project_id=${r}`:`project_id=${r}&database_id=${i}`}Wo(e,t,r,i,o){const s=Pl(),l=this.Qo(e,t.toUriEncodedString());B(Xa,`Sending RPC '${e}' ${s}:`,l,r);const u={"google-cloud-resource-prefix":this.Uo,"x-goog-request-params":this.$o};this.Go(u,i,o);const{host:d}=new URL(l),p=xo(d);return this.zo(e,l,u,r,p).then(m=>(B(Xa,`Received RPC '${e}' ${s}: `,m),m),m=>{throw _r(Xa,`RPC '${e}' ${s} failed with error: `,m,"url: ",l,"request:",r),m})}jo(e,t,r,i,o,s){return this.Wo(e,t,r,i,o)}Go(e,t,r){e["X-Goog-Api-Client"]=function(){return"gl-js/ fire/"+mi}(),e["Content-Type"]="text/plain",this.databaseInfo.appId&&(e["X-Firebase-GMPID"]=this.databaseInfo.appId),t&&t.headers.forEach((i,o)=>e[o]=i),r&&r.headers.forEach((i,o)=>e[o]=i)}Qo(e,t){const r=xT[e];let i=`${this.Ko}/v1/${t}:${r}`;return this.databaseInfo.apiKey&&(i=`${i}?key=${encodeURIComponent(this.databaseInfo.apiKey)}`),i}terminate(){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class PT{constructor(e){this.Jo=e.Jo,this.Ho=e.Ho}Zo(e){this.Xo=e}Yo(e){this.e_=e}t_(e){this.n_=e}onMessage(e){this.r_=e}close(){this.Ho()}send(e){this.Jo(e)}i_(){this.Xo()}s_(){this.e_()}o_(e){this.n_(e)}__(e){this.r_(e)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const He="WebChannelConnection",$i=(n,e,t)=>{n.listen(e,r=>{try{t(r)}catch(i){setTimeout(()=>{throw i},0)}})};class Br extends kT{constructor(e){super(e),this.a_=[],this.forceLongPolling=e.forceLongPolling,this.autoDetectLongPolling=e.autoDetectLongPolling,this.useFetchStreams=e.useFetchStreams,this.longPollingOptions=e.longPollingOptions}static u_(){if(!Br.c_){const e=zf();$i(e,jf.STAT_EVENT,t=>{t.stat===yl.PROXY?B(He,"STAT_EVENT: detected buffering proxy"):t.stat===yl.NOPROXY&&B(He,"STAT_EVENT: detected no buffering proxy")}),Br.c_=!0}}zo(e,t,r,i,o){const s=Pl();return new Promise((l,u)=>{const d=new $f;d.setWithCredentials(!0),d.listenOnce(Bf.COMPLETE,()=>{try{switch(d.getLastErrorCode()){case ys.NO_ERROR:const m=d.getResponseJson();B(He,`XHR for RPC '${e}' ${s} received:`,JSON.stringify(m)),l(m);break;case ys.TIMEOUT:B(He,`RPC '${e}' ${s} timed out`),u(new q(N.DEADLINE_EXCEEDED,"Request time out"));break;case ys.HTTP_ERROR:const g=d.getStatus();if(B(He,`RPC '${e}' ${s} failed with status:`,g,"response text:",d.getResponseText()),g>0){let b=d.getResponseJson();Array.isArray(b)&&(b=b[0]);const O=b==null?void 0:b.error;if(O&&O.status&&O.message){const A=function(V){const $=V.toLowerCase().replace(/_/g,"-");return Object.values(N).indexOf($)>=0?$:N.UNKNOWN}(O.status);u(new q(A,O.message))}else u(new q(N.UNKNOWN,"Server responded with status "+d.getStatus()))}else u(new q(N.UNAVAILABLE,"Connection failed."));break;default:K(9055,{l_:e,streamId:s,h_:d.getLastErrorCode(),P_:d.getLastError()})}}finally{B(He,`RPC '${e}' ${s} completed.`)}});const p=JSON.stringify(i);B(He,`RPC '${e}' ${s} sending request:`,i),d.send(t,"POST",p,r,15)})}T_(e,t,r){const i=Pl(),o=[this.Ko,"/","google.firestore.v1.Firestore","/",e,"/channel"],s=this.createWebChannelTransport(),l={httpSessionIdParam:"gsessionid",initMessageHeaders:{},messageUrlParams:{database:`projects/${this.databaseId.projectId}/databases/${this.databaseId.database}`},sendRawJson:!0,supportsCrossDomainXhr:!0,internalChannelParams:{forwardChannelRequestTimeoutMs:6e5},forceLongPolling:this.forceLongPolling,detectBufferingProxy:this.autoDetectLongPolling},u=this.longPollingOptions.timeoutSeconds;u!==void 0&&(l.longPollingTimeout=Math.round(1e3*u)),this.useFetchStreams&&(l.useFetchStreams=!0),this.Go(l.initMessageHeaders,t,r),l.encodeInitMessageHeaders=!0;const d=o.join("");B(He,`Creating RPC '${e}' stream ${i}: ${d}`,l);const p=s.createWebChannel(d,l);this.E_(p);let m=!1,g=!1;const b=new PT({Jo:O=>{g?B(He,`Not sending because RPC '${e}' stream ${i} is closed:`,O):(m||(B(He,`Opening RPC '${e}' stream ${i} transport.`),p.open(),m=!0),B(He,`RPC '${e}' stream ${i} sending:`,O),p.send(O))},Ho:()=>p.close()});return $i(p,Hi.EventType.OPEN,()=>{g||(B(He,`RPC '${e}' stream ${i} transport opened.`),b.i_())}),$i(p,Hi.EventType.CLOSE,()=>{g||(g=!0,B(He,`RPC '${e}' stream ${i} transport closed`),b.o_(),this.I_(p))}),$i(p,Hi.EventType.ERROR,O=>{g||(g=!0,_r(He,`RPC '${e}' stream ${i} transport errored. Name:`,O.name,"Message:",O.message),b.o_(new q(N.UNAVAILABLE,"The operation could not be completed")))}),$i(p,Hi.EventType.MESSAGE,O=>{var A;if(!g){const P=O.data[0];ce(!!P,16349);const V=P,$=(V==null?void 0:V.error)||((A=V[0])==null?void 0:A.error);if($){B(He,`RPC '${e}' stream ${i} received error:`,$);const U=$.status;let G=function(E){const v=ke[E];if(v!==void 0)return xp(v)}(U),z=$.message;U==="NOT_FOUND"&&z.includes("database")&&z.includes("does not exist")&&z.includes(this.databaseId.database)&&_r(`Database '${this.databaseId.database}' not found. Please check your project configuration.`),G===void 0&&(G=N.INTERNAL,z="Unknown error status: "+U+" with message "+$.message),g=!0,b.o_(new q(G,z)),p.close()}else B(He,`RPC '${e}' stream ${i} received:`,P),b.__(P)}}),Br.u_(),setTimeout(()=>{b.s_()},0),b}terminate(){this.a_.forEach(e=>e.close()),this.a_=[]}E_(e){this.a_.push(e)}I_(e){this.a_=this.a_.filter(t=>t===e)}Go(e,t,r){super.Go(e,t,r),this.databaseInfo.apiKey&&(e["x-goog-api-key"]=this.databaseInfo.apiKey)}createWebChannelTransport(){return Wf()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function CT(n){return new Br(n)}function Za(){return typeof document<"u"?document:null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function fa(n){return new Db(n,!0)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */Br.c_=!1;class Bp{constructor(e,t,r=1e3,i=1.5,o=6e4){this.Ci=e,this.timerId=t,this.R_=r,this.A_=i,this.V_=o,this.d_=0,this.m_=null,this.f_=Date.now(),this.reset()}reset(){this.d_=0}g_(){this.d_=this.V_}p_(e){this.cancel();const t=Math.floor(this.d_+this.y_()),r=Math.max(0,Date.now()-this.f_),i=Math.max(0,t-r);i>0&&B("ExponentialBackoff",`Backing off for ${i} ms (base delay: ${this.d_} ms, delay with jitter: ${t} ms, last attempt: ${r} ms ago)`),this.m_=this.Ci.enqueueAfterDelay(this.timerId,i,()=>(this.f_=Date.now(),e())),this.d_*=this.A_,this.d_<this.R_&&(this.d_=this.R_),this.d_>this.V_&&(this.d_=this.V_)}w_(){this.m_!==null&&(this.m_.skipDelay(),this.m_=null)}cancel(){this.m_!==null&&(this.m_.cancel(),this.m_=null)}y_(){return(Math.random()-.5)*this.d_}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ld="PersistentStream";class jp{constructor(e,t,r,i,o,s,l,u){this.Ci=e,this.S_=r,this.b_=i,this.connection=o,this.authCredentialsProvider=s,this.appCheckCredentialsProvider=l,this.listener=u,this.state=0,this.D_=0,this.C_=null,this.v_=null,this.stream=null,this.F_=0,this.M_=new Bp(e,t)}x_(){return this.state===1||this.state===5||this.O_()}O_(){return this.state===2||this.state===3}start(){this.F_=0,this.state!==4?this.auth():this.N_()}async stop(){this.x_()&&await this.close(0)}B_(){this.state=0,this.M_.reset()}L_(){this.O_()&&this.C_===null&&(this.C_=this.Ci.enqueueAfterDelay(this.S_,6e4,()=>this.k_()))}q_(e){this.K_(),this.stream.send(e)}async k_(){if(this.O_())return this.close(0)}K_(){this.C_&&(this.C_.cancel(),this.C_=null)}U_(){this.v_&&(this.v_.cancel(),this.v_=null)}async close(e,t){this.K_(),this.U_(),this.M_.cancel(),this.D_++,e!==4?this.M_.reset():t&&t.code===N.RESOURCE_EXHAUSTED?(dn(t.toString()),dn("Using maximum backoff delay to prevent overloading the backend."),this.M_.g_()):t&&t.code===N.UNAUTHENTICATED&&this.state!==3&&(this.authCredentialsProvider.invalidateToken(),this.appCheckCredentialsProvider.invalidateToken()),this.stream!==null&&(this.W_(),this.stream.close(),this.stream=null),this.state=e,await this.listener.t_(t)}W_(){}auth(){this.state=1;const e=this.Q_(this.D_),t=this.D_;Promise.all([this.authCredentialsProvider.getToken(),this.appCheckCredentialsProvider.getToken()]).then(([r,i])=>{this.D_===t&&this.G_(r,i)},r=>{e(()=>{const i=new q(N.UNKNOWN,"Fetching auth token failed: "+r.message);return this.z_(i)})})}G_(e,t){const r=this.Q_(this.D_);this.stream=this.j_(e,t),this.stream.Zo(()=>{r(()=>this.listener.Zo())}),this.stream.Yo(()=>{r(()=>(this.state=2,this.v_=this.Ci.enqueueAfterDelay(this.b_,1e4,()=>(this.O_()&&(this.state=3),Promise.resolve())),this.listener.Yo()))}),this.stream.t_(i=>{r(()=>this.z_(i))}),this.stream.onMessage(i=>{r(()=>++this.F_==1?this.J_(i):this.onNext(i))})}N_(){this.state=5,this.M_.p_(async()=>{this.state=0,this.start()})}z_(e){return B(ld,`close with error: ${e}`),this.stream=null,this.close(4,e)}Q_(e){return t=>{this.Ci.enqueueAndForget(()=>this.D_===e?t():(B(ld,"stream callback skipped by getCloseGuardedDispatcher."),Promise.resolve()))}}}class RT extends jp{constructor(e,t,r,i,o,s){super(e,"listen_stream_connection_backoff","listen_stream_idle","health_check_timeout",t,r,i,s),this.serializer=o}j_(e,t){return this.connection.T_("Listen",e,t)}J_(e){return this.onNext(e)}onNext(e){this.M_.reset();const t=Vb(this.serializer,e),r=function(o){if(!("targetChange"in o))return Q.min();const s=o.targetChange;return s.targetIds&&s.targetIds.length?Q.min():s.readTime?Bt(s.readTime):Q.min()}(e);return this.listener.H_(t,r)}Z_(e){const t={};t.database=xl(this.serializer),t.addTarget=function(o,s){let l;const u=s.target;if(l=Tl(u)?{documents:qb(o,u)}:{query:$b(o,u).ft},l.targetId=s.targetId,s.resumeToken.approximateByteSize()>0){l.resumeToken=Cp(o,s.resumeToken);const d=Il(o,s.expectedCount);d!==null&&(l.expectedCount=d)}else if(s.snapshotVersion.compareTo(Q.min())>0){l.readTime=qs(o,s.snapshotVersion.toTimestamp());const d=Il(o,s.expectedCount);d!==null&&(l.expectedCount=d)}return l}(this.serializer,e);const r=jb(this.serializer,e);r&&(t.labels=r),this.q_(t)}X_(e){const t={};t.database=xl(this.serializer),t.removeTarget=e,this.q_(t)}}class OT extends jp{constructor(e,t,r,i,o,s){super(e,"write_stream_connection_backoff","write_stream_idle","health_check_timeout",t,r,i,s),this.serializer=o}get Y_(){return this.F_>0}start(){this.lastStreamToken=void 0,super.start()}W_(){this.Y_&&this.ea([])}j_(e,t){return this.connection.T_("Write",e,t)}J_(e){return ce(!!e.streamToken,31322),this.lastStreamToken=e.streamToken,ce(!e.writeResults||e.writeResults.length===0,55816),this.listener.ta()}onNext(e){ce(!!e.streamToken,12678),this.lastStreamToken=e.streamToken,this.M_.reset();const t=Ub(e.writeResults,e.commitTime),r=Bt(e.commitTime);return this.listener.na(r,t)}ra(){const e={};e.database=xl(this.serializer),this.q_(e)}ea(e){const t={streamToken:this.lastStreamToken,writes:e.map(r=>Fb(this.serializer,r))};this.q_(t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class NT{}class DT extends NT{constructor(e,t,r,i){super(),this.authCredentials=e,this.appCheckCredentials=t,this.connection=r,this.serializer=i,this.ia=!1}sa(){if(this.ia)throw new q(N.FAILED_PRECONDITION,"The client has already been terminated.")}Wo(e,t,r,i){return this.sa(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then(([o,s])=>this.connection.Wo(e,Al(t,r),i,o,s)).catch(o=>{throw o.name==="FirebaseError"?(o.code===N.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),o):new q(N.UNKNOWN,o.toString())})}jo(e,t,r,i,o){return this.sa(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then(([s,l])=>this.connection.jo(e,Al(t,r),i,s,l,o)).catch(s=>{throw s.name==="FirebaseError"?(s.code===N.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),s):new q(N.UNKNOWN,s.toString())})}terminate(){this.ia=!0,this.connection.terminate()}}function LT(n,e,t,r){return new DT(n,e,t,r)}class MT{constructor(e,t){this.asyncQueue=e,this.onlineStateHandler=t,this.state="Unknown",this.oa=0,this._a=null,this.aa=!0}ua(){this.oa===0&&(this.ca("Unknown"),this._a=this.asyncQueue.enqueueAfterDelay("online_state_timeout",1e4,()=>(this._a=null,this.la("Backend didn't respond within 10 seconds."),this.ca("Offline"),Promise.resolve())))}ha(e){this.state==="Online"?this.ca("Unknown"):(this.oa++,this.oa>=1&&(this.Pa(),this.la(`Connection failed 1 times. Most recent error: ${e.toString()}`),this.ca("Offline")))}set(e){this.Pa(),this.oa=0,e==="Online"&&(this.aa=!1),this.ca(e)}ca(e){e!==this.state&&(this.state=e,this.onlineStateHandler(e))}la(e){const t=`Could not reach Cloud Firestore backend. ${e}
This typically indicates that your device does not have a healthy Internet connection at the moment. The client will operate in offline mode until it is able to successfully connect to the backend.`;this.aa?(dn(t),this.aa=!1):B("OnlineStateTracker",t)}Pa(){this._a!==null&&(this._a.cancel(),this._a=null)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const wr="RemoteStore";class VT{constructor(e,t,r,i,o){this.localStore=e,this.datastore=t,this.asyncQueue=r,this.remoteSyncer={},this.Ta=[],this.Ea=new Map,this.Ia=new Set,this.Ra=[],this.Aa=o,this.Aa.Mo(s=>{r.enqueueAndForget(async()=>{Ir(this)&&(B(wr,"Restarting streams for network reachability change."),await async function(u){const d=X(u);d.Ia.add(4),await Do(d),d.Va.set("Unknown"),d.Ia.delete(4),await pa(d)}(this))})}),this.Va=new MT(r,i)}}async function pa(n){if(Ir(n))for(const e of n.Ra)await e(!0)}async function Do(n){for(const e of n.Ra)await e(!1)}function zp(n,e){const t=X(n);t.Ea.has(e.targetId)||(t.Ea.set(e.targetId,e),Tc(t)?bc(t):wi(t).O_()&&wc(t,e))}function _c(n,e){const t=X(n),r=wi(t);t.Ea.delete(e),r.O_()&&Wp(t,e),t.Ea.size===0&&(r.O_()?r.L_():Ir(t)&&t.Va.set("Unknown"))}function wc(n,e){if(n.da.$e(e.targetId),e.resumeToken.approximateByteSize()>0||e.snapshotVersion.compareTo(Q.min())>0){const t=n.remoteSyncer.getRemoteKeysForTarget(e.targetId).size;e=e.withExpectedCount(t)}wi(n).Z_(e)}function Wp(n,e){n.da.$e(e),wi(n).X_(e)}function bc(n){n.da=new Cb({getRemoteKeysForTarget:e=>n.remoteSyncer.getRemoteKeysForTarget(e),At:e=>n.Ea.get(e)||null,ht:()=>n.datastore.serializer.databaseId}),wi(n).start(),n.Va.ua()}function Tc(n){return Ir(n)&&!wi(n).x_()&&n.Ea.size>0}function Ir(n){return X(n).Ia.size===0}function Hp(n){n.da=void 0}async function FT(n){n.Va.set("Online")}async function UT(n){n.Ea.forEach((e,t)=>{wc(n,e)})}async function qT(n,e){Hp(n),Tc(n)?(n.Va.ha(e),bc(n)):n.Va.set("Unknown")}async function $T(n,e,t){if(n.Va.set("Online"),e instanceof Pp&&e.state===2&&e.cause)try{await async function(i,o){const s=o.cause;for(const l of o.targetIds)i.Ea.has(l)&&(await i.remoteSyncer.rejectListen(l,s),i.Ea.delete(l),i.da.removeTarget(l))}(n,e)}catch(r){B(wr,"Failed to remove targets %s: %s ",e.targetIds.join(","),r),await Bs(n,r)}else if(e instanceof bs?n.da.Xe(e):e instanceof kp?n.da.st(e):n.da.tt(e),!t.isEqual(Q.min()))try{const r=await $p(n.localStore);t.compareTo(r)>=0&&await function(o,s){const l=o.da.Tt(s);return l.targetChanges.forEach((u,d)=>{if(u.resumeToken.approximateByteSize()>0){const p=o.Ea.get(d);p&&o.Ea.set(d,p.withResumeToken(u.resumeToken,s))}}),l.targetMismatches.forEach((u,d)=>{const p=o.Ea.get(u);if(!p)return;o.Ea.set(u,p.withResumeToken(ze.EMPTY_BYTE_STRING,p.snapshotVersion)),Wp(o,u);const m=new Rn(p.target,u,d,p.sequenceNumber);wc(o,m)}),o.remoteSyncer.applyRemoteEvent(l)}(n,t)}catch(r){B(wr,"Failed to raise snapshot:",r),await Bs(n,r)}}async function Bs(n,e,t){if(!vi(e))throw e;n.Ia.add(1),await Do(n),n.Va.set("Offline"),t||(t=()=>$p(n.localStore)),n.asyncQueue.enqueueRetryable(async()=>{B(wr,"Retrying IndexedDB access"),await t(),n.Ia.delete(1),await pa(n)})}function Gp(n,e){return e().catch(t=>Bs(n,t,e))}async function ga(n){const e=X(n),t=Hn(e);let r=e.Ta.length>0?e.Ta[e.Ta.length-1].batchId:oc;for(;BT(e);)try{const i=await TT(e.localStore,r);if(i===null){e.Ta.length===0&&t.L_();break}r=i.batchId,jT(e,i)}catch(i){await Bs(e,i)}Kp(e)&&Yp(e)}function BT(n){return Ir(n)&&n.Ta.length<10}function jT(n,e){n.Ta.push(e);const t=Hn(n);t.O_()&&t.Y_&&t.ea(e.mutations)}function Kp(n){return Ir(n)&&!Hn(n).x_()&&n.Ta.length>0}function Yp(n){Hn(n).start()}async function zT(n){Hn(n).ra()}async function WT(n){const e=Hn(n);for(const t of n.Ta)e.ea(t.mutations)}async function HT(n,e,t){const r=n.Ta.shift(),i=dc.from(r,e,t);await Gp(n,()=>n.remoteSyncer.applySuccessfulWrite(i)),await ga(n)}async function GT(n,e){e&&Hn(n).Y_&&await async function(r,i){if(function(s){return xb(s)&&s!==N.ABORTED}(i.code)){const o=r.Ta.shift();Hn(r).B_(),await Gp(r,()=>r.remoteSyncer.rejectFailedWrite(o.batchId,i)),await ga(r)}}(n,e),Kp(n)&&Yp(n)}async function cd(n,e){const t=X(n);t.asyncQueue.verifyOperationInProgress(),B(wr,"RemoteStore received new credentials");const r=Ir(t);t.Ia.add(3),await Do(t),r&&t.Va.set("Unknown"),await t.remoteSyncer.handleCredentialChange(e),t.Ia.delete(3),await pa(t)}async function KT(n,e){const t=X(n);e?(t.Ia.delete(2),await pa(t)):e||(t.Ia.add(2),await Do(t),t.Va.set("Unknown"))}function wi(n){return n.ma||(n.ma=function(t,r,i){const o=X(t);return o.sa(),new RT(r,o.connection,o.authCredentials,o.appCheckCredentials,o.serializer,i)}(n.datastore,n.asyncQueue,{Zo:FT.bind(null,n),Yo:UT.bind(null,n),t_:qT.bind(null,n),H_:$T.bind(null,n)}),n.Ra.push(async e=>{e?(n.ma.B_(),Tc(n)?bc(n):n.Va.set("Unknown")):(await n.ma.stop(),Hp(n))})),n.ma}function Hn(n){return n.fa||(n.fa=function(t,r,i){const o=X(t);return o.sa(),new OT(r,o.connection,o.authCredentials,o.appCheckCredentials,o.serializer,i)}(n.datastore,n.asyncQueue,{Zo:()=>Promise.resolve(),Yo:zT.bind(null,n),t_:GT.bind(null,n),ta:WT.bind(null,n),na:HT.bind(null,n)}),n.Ra.push(async e=>{e?(n.fa.B_(),await ga(n)):(await n.fa.stop(),n.Ta.length>0&&(B(wr,`Stopping write stream with ${n.Ta.length} pending writes`),n.Ta=[]))})),n.fa}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ec{constructor(e,t,r,i,o){this.asyncQueue=e,this.timerId=t,this.targetTimeMs=r,this.op=i,this.removalCallback=o,this.deferred=new on,this.then=this.deferred.promise.then.bind(this.deferred.promise),this.deferred.promise.catch(s=>{})}get promise(){return this.deferred.promise}static createAndSchedule(e,t,r,i,o){const s=Date.now()+r,l=new Ec(e,t,s,i,o);return l.start(r),l}start(e){this.timerHandle=setTimeout(()=>this.handleDelayElapsed(),e)}skipDelay(){return this.handleDelayElapsed()}cancel(e){this.timerHandle!==null&&(this.clearTimeout(),this.deferred.reject(new q(N.CANCELLED,"Operation cancelled"+(e?": "+e:""))))}handleDelayElapsed(){this.asyncQueue.enqueueAndForget(()=>this.timerHandle!==null?(this.clearTimeout(),this.op().then(e=>this.deferred.resolve(e))):Promise.resolve())}clearTimeout(){this.timerHandle!==null&&(this.removalCallback(this),clearTimeout(this.timerHandle),this.timerHandle=null)}}function Ic(n,e){if(dn("AsyncQueue",`${e}: ${n}`),vi(n))return new q(N.UNAVAILABLE,`${e}: ${n}`);throw n}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class jr{static emptySet(e){return new jr(e.comparator)}constructor(e){this.comparator=e?(t,r)=>e(t,r)||H.comparator(t.key,r.key):(t,r)=>H.comparator(t.key,r.key),this.keyedMap=Gi(),this.sortedSet=new we(this.comparator)}has(e){return this.keyedMap.get(e)!=null}get(e){return this.keyedMap.get(e)}first(){return this.sortedSet.minKey()}last(){return this.sortedSet.maxKey()}isEmpty(){return this.sortedSet.isEmpty()}indexOf(e){const t=this.keyedMap.get(e);return t?this.sortedSet.indexOf(t):-1}get size(){return this.sortedSet.size}forEach(e){this.sortedSet.inorderTraversal((t,r)=>(e(t),!1))}add(e){const t=this.delete(e.key);return t.copy(t.keyedMap.insert(e.key,e),t.sortedSet.insert(e,null))}delete(e){const t=this.get(e);return t?this.copy(this.keyedMap.remove(e),this.sortedSet.remove(t)):this}isEqual(e){if(!(e instanceof jr)||this.size!==e.size)return!1;const t=this.sortedSet.getIterator(),r=e.sortedSet.getIterator();for(;t.hasNext();){const i=t.getNext().key,o=r.getNext().key;if(!i.isEqual(o))return!1}return!0}toString(){const e=[];return this.forEach(t=>{e.push(t.toString())}),e.length===0?"DocumentSet ()":`DocumentSet (
  `+e.join(`  
`)+`
)`}copy(e,t){const r=new jr;return r.comparator=this.comparator,r.keyedMap=e,r.sortedSet=t,r}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ud{constructor(){this.ga=new we(H.comparator)}track(e){const t=e.doc.key,r=this.ga.get(t);r?e.type!==0&&r.type===3?this.ga=this.ga.insert(t,e):e.type===3&&r.type!==1?this.ga=this.ga.insert(t,{type:r.type,doc:e.doc}):e.type===2&&r.type===2?this.ga=this.ga.insert(t,{type:2,doc:e.doc}):e.type===2&&r.type===0?this.ga=this.ga.insert(t,{type:0,doc:e.doc}):e.type===1&&r.type===0?this.ga=this.ga.remove(t):e.type===1&&r.type===2?this.ga=this.ga.insert(t,{type:1,doc:r.doc}):e.type===0&&r.type===1?this.ga=this.ga.insert(t,{type:2,doc:e.doc}):K(63341,{Vt:e,pa:r}):this.ga=this.ga.insert(t,e)}ya(){const e=[];return this.ga.inorderTraversal((t,r)=>{e.push(r)}),e}}class oi{constructor(e,t,r,i,o,s,l,u,d){this.query=e,this.docs=t,this.oldDocs=r,this.docChanges=i,this.mutatedKeys=o,this.fromCache=s,this.syncStateChanged=l,this.excludesMetadataChanges=u,this.hasCachedResults=d}static fromInitialDocuments(e,t,r,i,o){const s=[];return t.forEach(l=>{s.push({type:0,doc:l})}),new oi(e,t,jr.emptySet(t),s,r,i,!0,!1,o)}get hasPendingWrites(){return!this.mutatedKeys.isEmpty()}isEqual(e){if(!(this.fromCache===e.fromCache&&this.hasCachedResults===e.hasCachedResults&&this.syncStateChanged===e.syncStateChanged&&this.mutatedKeys.isEqual(e.mutatedKeys)&&la(this.query,e.query)&&this.docs.isEqual(e.docs)&&this.oldDocs.isEqual(e.oldDocs)))return!1;const t=this.docChanges,r=e.docChanges;if(t.length!==r.length)return!1;for(let i=0;i<t.length;i++)if(t[i].type!==r[i].type||!t[i].doc.isEqual(r[i].doc))return!1;return!0}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class YT{constructor(){this.wa=void 0,this.Sa=[]}ba(){return this.Sa.some(e=>e.Da())}}class QT{constructor(){this.queries=hd(),this.onlineState="Unknown",this.Ca=new Set}terminate(){(function(t,r){const i=X(t),o=i.queries;i.queries=hd(),o.forEach((s,l)=>{for(const u of l.Sa)u.onError(r)})})(this,new q(N.ABORTED,"Firestore shutting down"))}}function hd(){return new Er(n=>fp(n),la)}async function Ac(n,e){const t=X(n);let r=3;const i=e.query;let o=t.queries.get(i);o?!o.ba()&&e.Da()&&(r=2):(o=new YT,r=e.Da()?0:1);try{switch(r){case 0:o.wa=await t.onListen(i,!0);break;case 1:o.wa=await t.onListen(i,!1);break;case 2:await t.onFirstRemoteStoreListen(i)}}catch(s){const l=Ic(s,`Initialization of query '${Or(e.query)}' failed`);return void e.onError(l)}t.queries.set(i,o),o.Sa.push(e),e.va(t.onlineState),o.wa&&e.Fa(o.wa)&&xc(t)}async function Sc(n,e){const t=X(n),r=e.query;let i=3;const o=t.queries.get(r);if(o){const s=o.Sa.indexOf(e);s>=0&&(o.Sa.splice(s,1),o.Sa.length===0?i=e.Da()?0:1:!o.ba()&&e.Da()&&(i=2))}switch(i){case 0:return t.queries.delete(r),t.onUnlisten(r,!0);case 1:return t.queries.delete(r),t.onUnlisten(r,!1);case 2:return t.onLastRemoteStoreUnlisten(r);default:return}}function JT(n,e){const t=X(n);let r=!1;for(const i of e){const o=i.query,s=t.queries.get(o);if(s){for(const l of s.Sa)l.Fa(i)&&(r=!0);s.wa=i}}r&&xc(t)}function XT(n,e,t){const r=X(n),i=r.queries.get(e);if(i)for(const o of i.Sa)o.onError(t);r.queries.delete(e)}function xc(n){n.Ca.forEach(e=>{e.next()})}var Cl,dd;(dd=Cl||(Cl={})).Ma="default",dd.Cache="cache";class kc{constructor(e,t,r){this.query=e,this.xa=t,this.Oa=!1,this.Na=null,this.onlineState="Unknown",this.options=r||{}}Fa(e){if(!this.options.includeMetadataChanges){const r=[];for(const i of e.docChanges)i.type!==3&&r.push(i);e=new oi(e.query,e.docs,e.oldDocs,r,e.mutatedKeys,e.fromCache,e.syncStateChanged,!0,e.hasCachedResults)}let t=!1;return this.Oa?this.Ba(e)&&(this.xa.next(e),t=!0):this.La(e,this.onlineState)&&(this.ka(e),t=!0),this.Na=e,t}onError(e){this.xa.error(e)}va(e){this.onlineState=e;let t=!1;return this.Na&&!this.Oa&&this.La(this.Na,e)&&(this.ka(this.Na),t=!0),t}La(e,t){if(!e.fromCache||!this.Da())return!0;const r=t!=="Offline";return(!this.options.qa||!r)&&(!e.docs.isEmpty()||e.hasCachedResults||t==="Offline")}Ba(e){if(e.docChanges.length>0)return!0;const t=this.Na&&this.Na.hasPendingWrites!==e.hasPendingWrites;return!(!e.syncStateChanged&&!t)&&this.options.includeMetadataChanges===!0}ka(e){e=oi.fromInitialDocuments(e.query,e.docs,e.mutatedKeys,e.fromCache,e.hasCachedResults),this.Oa=!0,this.xa.next(e)}Da(){return this.options.source!==Cl.Cache}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Qp{constructor(e){this.key=e}}class Jp{constructor(e){this.key=e}}class ZT{constructor(e,t){this.query=e,this.Za=t,this.Xa=null,this.hasCachedResults=!1,this.current=!1,this.Ya=ie(),this.mutatedKeys=ie(),this.eu=pp(e),this.tu=new jr(this.eu)}get nu(){return this.Za}ru(e,t){const r=t?t.iu:new ud,i=t?t.tu:this.tu;let o=t?t.mutatedKeys:this.mutatedKeys,s=i,l=!1;const u=this.query.limitType==="F"&&i.size===this.query.limit?i.last():null,d=this.query.limitType==="L"&&i.size===this.query.limit?i.first():null;if(e.inorderTraversal((p,m)=>{const g=i.get(p),b=ca(this.query,m)?m:null,O=!!g&&this.mutatedKeys.has(g.key),A=!!b&&(b.hasLocalMutations||this.mutatedKeys.has(b.key)&&b.hasCommittedMutations);let P=!1;g&&b?g.data.isEqual(b.data)?O!==A&&(r.track({type:3,doc:b}),P=!0):this.su(g,b)||(r.track({type:2,doc:b}),P=!0,(u&&this.eu(b,u)>0||d&&this.eu(b,d)<0)&&(l=!0)):!g&&b?(r.track({type:0,doc:b}),P=!0):g&&!b&&(r.track({type:1,doc:g}),P=!0,(u||d)&&(l=!0)),P&&(b?(s=s.add(b),o=A?o.add(p):o.delete(p)):(s=s.delete(p),o=o.delete(p)))}),this.query.limit!==null)for(;s.size>this.query.limit;){const p=this.query.limitType==="F"?s.last():s.first();s=s.delete(p.key),o=o.delete(p.key),r.track({type:1,doc:p})}return{tu:s,iu:r,bs:l,mutatedKeys:o}}su(e,t){return e.hasLocalMutations&&t.hasCommittedMutations&&!t.hasLocalMutations}applyChanges(e,t,r,i){const o=this.tu;this.tu=e.tu,this.mutatedKeys=e.mutatedKeys;const s=e.iu.ya();s.sort((p,m)=>function(b,O){const A=P=>{switch(P){case 0:return 1;case 2:case 3:return 2;case 1:return 0;default:return K(20277,{Vt:P})}};return A(b)-A(O)}(p.type,m.type)||this.eu(p.doc,m.doc)),this.ou(r),i=i??!1;const l=t&&!i?this._u():[],u=this.Ya.size===0&&this.current&&!i?1:0,d=u!==this.Xa;return this.Xa=u,s.length!==0||d?{snapshot:new oi(this.query,e.tu,o,s,e.mutatedKeys,u===0,d,!1,!!r&&r.resumeToken.approximateByteSize()>0),au:l}:{au:l}}va(e){return this.current&&e==="Offline"?(this.current=!1,this.applyChanges({tu:this.tu,iu:new ud,mutatedKeys:this.mutatedKeys,bs:!1},!1)):{au:[]}}uu(e){return!this.Za.has(e)&&!!this.tu.has(e)&&!this.tu.get(e).hasLocalMutations}ou(e){e&&(e.addedDocuments.forEach(t=>this.Za=this.Za.add(t)),e.modifiedDocuments.forEach(t=>{}),e.removedDocuments.forEach(t=>this.Za=this.Za.delete(t)),this.current=e.current)}_u(){if(!this.current)return[];const e=this.Ya;this.Ya=ie(),this.tu.forEach(r=>{this.uu(r.key)&&(this.Ya=this.Ya.add(r.key))});const t=[];return e.forEach(r=>{this.Ya.has(r)||t.push(new Jp(r))}),this.Ya.forEach(r=>{e.has(r)||t.push(new Qp(r))}),t}cu(e){this.Za=e.ks,this.Ya=ie();const t=this.ru(e.documents);return this.applyChanges(t,!0)}lu(){return oi.fromInitialDocuments(this.query,this.tu,this.mutatedKeys,this.Xa===0,this.hasCachedResults)}}const Pc="SyncEngine";class eE{constructor(e,t,r){this.query=e,this.targetId=t,this.view=r}}class tE{constructor(e){this.key=e,this.hu=!1}}class nE{constructor(e,t,r,i,o,s){this.localStore=e,this.remoteStore=t,this.eventManager=r,this.sharedClientState=i,this.currentUser=o,this.maxConcurrentLimboResolutions=s,this.Pu={},this.Tu=new Er(l=>fp(l),la),this.Eu=new Map,this.Iu=new Set,this.Ru=new we(H.comparator),this.Au=new Map,this.Vu=new gc,this.du={},this.mu=new Map,this.fu=ii.ar(),this.onlineState="Unknown",this.gu=void 0}get isPrimaryClient(){return this.gu===!0}}async function rE(n,e,t=!0){const r=rg(n);let i;const o=r.Tu.get(e);return o?(r.sharedClientState.addLocalQueryTarget(o.targetId),i=o.view.lu()):i=await Xp(r,e,t,!0),i}async function iE(n,e){const t=rg(n);await Xp(t,e,!0,!1)}async function Xp(n,e,t,r){const i=await ET(n.localStore,$t(e)),o=i.targetId,s=n.sharedClientState.addLocalQueryTarget(o,t);let l;return r&&(l=await oE(n,e,o,s==="current",i.resumeToken)),n.isPrimaryClient&&t&&zp(n.remoteStore,i),l}async function oE(n,e,t,r,i){n.pu=(m,g,b)=>async function(A,P,V,$){let U=P.view.ru(V);U.bs&&(U=await id(A.localStore,P.query,!1).then(({documents:E})=>P.view.ru(E,U)));const G=$&&$.targetChanges.get(P.targetId),z=$&&$.targetMismatches.get(P.targetId)!=null,J=P.view.applyChanges(U,A.isPrimaryClient,G,z);return pd(A,P.targetId,J.au),J.snapshot}(n,m,g,b);const o=await id(n.localStore,e,!0),s=new ZT(e,o.ks),l=s.ru(o.documents),u=No.createSynthesizedTargetChangeForCurrentChange(t,r&&n.onlineState!=="Offline",i),d=s.applyChanges(l,n.isPrimaryClient,u);pd(n,t,d.au);const p=new eE(e,t,s);return n.Tu.set(e,p),n.Eu.has(t)?n.Eu.get(t).push(e):n.Eu.set(t,[e]),d.snapshot}async function sE(n,e,t){const r=X(n),i=r.Tu.get(e),o=r.Eu.get(i.targetId);if(o.length>1)return r.Eu.set(i.targetId,o.filter(s=>!la(s,e))),void r.Tu.delete(e);r.isPrimaryClient?(r.sharedClientState.removeLocalQueryTarget(i.targetId),r.sharedClientState.isActiveQueryTarget(i.targetId)||await kl(r.localStore,i.targetId,!1).then(()=>{r.sharedClientState.clearQueryState(i.targetId),t&&_c(r.remoteStore,i.targetId),Rl(r,i.targetId)}).catch(yi)):(Rl(r,i.targetId),await kl(r.localStore,i.targetId,!0))}async function aE(n,e){const t=X(n),r=t.Tu.get(e),i=t.Eu.get(r.targetId);t.isPrimaryClient&&i.length===1&&(t.sharedClientState.removeLocalQueryTarget(r.targetId),_c(t.remoteStore,r.targetId))}async function lE(n,e,t){const r=gE(n);try{const i=await function(s,l){const u=X(s),d=me.now(),p=l.reduce((b,O)=>b.add(O.key),ie());let m,g;return u.persistence.runTransaction("Locally write mutations","readwrite",b=>{let O=fn(),A=ie();return u.xs.getEntries(b,p).next(P=>{O=P,O.forEach((V,$)=>{$.isValidDocument()||(A=A.add(V))})}).next(()=>u.localDocuments.getOverlayedDocuments(b,O)).next(P=>{m=P;const V=[];for(const $ of l){const U=Tb($,m.get($.key).overlayedDocument);U!=null&&V.push(new Qn($.key,U,op(U.value.mapValue),Et.exists(!0)))}return u.mutationQueue.addMutationBatch(b,d,V,l)}).next(P=>{g=P;const V=P.applyToLocalDocumentSet(m,A);return u.documentOverlayCache.saveOverlays(b,P.batchId,V)})}).then(()=>({batchId:g.batchId,changes:mp(m)}))}(r.localStore,e);r.sharedClientState.addPendingMutation(i.batchId),function(s,l,u){let d=s.du[s.currentUser.toKey()];d||(d=new we(re)),d=d.insert(l,u),s.du[s.currentUser.toKey()]=d}(r,i.batchId,t),await Lo(r,i.changes),await ga(r.remoteStore)}catch(i){const o=Ic(i,"Failed to persist write");t.reject(o)}}async function Zp(n,e){const t=X(n);try{const r=await wT(t.localStore,e);e.targetChanges.forEach((i,o)=>{const s=t.Au.get(o);s&&(ce(i.addedDocuments.size+i.modifiedDocuments.size+i.removedDocuments.size<=1,22616),i.addedDocuments.size>0?s.hu=!0:i.modifiedDocuments.size>0?ce(s.hu,14607):i.removedDocuments.size>0&&(ce(s.hu,42227),s.hu=!1))}),await Lo(t,r,e)}catch(r){await yi(r)}}function fd(n,e,t){const r=X(n);if(r.isPrimaryClient&&t===0||!r.isPrimaryClient&&t===1){const i=[];r.Tu.forEach((o,s)=>{const l=s.view.va(e);l.snapshot&&i.push(l.snapshot)}),function(s,l){const u=X(s);u.onlineState=l;let d=!1;u.queries.forEach((p,m)=>{for(const g of m.Sa)g.va(l)&&(d=!0)}),d&&xc(u)}(r.eventManager,e),i.length&&r.Pu.H_(i),r.onlineState=e,r.isPrimaryClient&&r.sharedClientState.setOnlineState(e)}}async function cE(n,e,t){const r=X(n);r.sharedClientState.updateQueryState(e,"rejected",t);const i=r.Au.get(e),o=i&&i.key;if(o){let s=new we(H.comparator);s=s.insert(o,Ke.newNoDocument(o,Q.min()));const l=ie().add(o),u=new da(Q.min(),new Map,new we(re),s,l);await Zp(r,u),r.Ru=r.Ru.remove(o),r.Au.delete(e),Cc(r)}else await kl(r.localStore,e,!1).then(()=>Rl(r,e,t)).catch(yi)}async function uE(n,e){const t=X(n),r=e.batch.batchId;try{const i=await _T(t.localStore,e);tg(t,r,null),eg(t,r),t.sharedClientState.updateMutationState(r,"acknowledged"),await Lo(t,i)}catch(i){await yi(i)}}async function hE(n,e,t){const r=X(n);try{const i=await function(s,l){const u=X(s);return u.persistence.runTransaction("Reject batch","readwrite-primary",d=>{let p;return u.mutationQueue.lookupMutationBatch(d,l).next(m=>(ce(m!==null,37113),p=m.keys(),u.mutationQueue.removeMutationBatch(d,m))).next(()=>u.mutationQueue.performConsistencyCheck(d)).next(()=>u.documentOverlayCache.removeOverlaysForBatchId(d,p,l)).next(()=>u.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(d,p)).next(()=>u.localDocuments.getDocuments(d,p))})}(r.localStore,e);tg(r,e,t),eg(r,e),r.sharedClientState.updateMutationState(e,"rejected",t),await Lo(r,i)}catch(i){await yi(i)}}function eg(n,e){(n.mu.get(e)||[]).forEach(t=>{t.resolve()}),n.mu.delete(e)}function tg(n,e,t){const r=X(n);let i=r.du[r.currentUser.toKey()];if(i){const o=i.get(e);o&&(t?o.reject(t):o.resolve(),i=i.remove(e)),r.du[r.currentUser.toKey()]=i}}function Rl(n,e,t=null){n.sharedClientState.removeLocalQueryTarget(e);for(const r of n.Eu.get(e))n.Tu.delete(r),t&&n.Pu.yu(r,t);n.Eu.delete(e),n.isPrimaryClient&&n.Vu.Gr(e).forEach(r=>{n.Vu.containsKey(r)||ng(n,r)})}function ng(n,e){n.Iu.delete(e.path.canonicalString());const t=n.Ru.get(e);t!==null&&(_c(n.remoteStore,t),n.Ru=n.Ru.remove(e),n.Au.delete(t),Cc(n))}function pd(n,e,t){for(const r of t)r instanceof Qp?(n.Vu.addReference(r.key,e),dE(n,r)):r instanceof Jp?(B(Pc,"Document no longer in limbo: "+r.key),n.Vu.removeReference(r.key,e),n.Vu.containsKey(r.key)||ng(n,r.key)):K(19791,{wu:r})}function dE(n,e){const t=e.key,r=t.path.canonicalString();n.Ru.get(t)||n.Iu.has(r)||(B(Pc,"New document in limbo: "+t),n.Iu.add(r),Cc(n))}function Cc(n){for(;n.Iu.size>0&&n.Ru.size<n.maxConcurrentLimboResolutions;){const e=n.Iu.values().next().value;n.Iu.delete(e);const t=new H(fe.fromString(e)),r=n.fu.next();n.Au.set(r,new tE(t)),n.Ru=n.Ru.insert(t,r),zp(n.remoteStore,new Rn($t(aa(t.path)),r,"TargetPurposeLimboResolution",ia.ce))}}async function Lo(n,e,t){const r=X(n),i=[],o=[],s=[];r.Tu.isEmpty()||(r.Tu.forEach((l,u)=>{s.push(r.pu(u,e,t).then(d=>{var p;if((d||t)&&r.isPrimaryClient){const m=d?!d.fromCache:(p=t==null?void 0:t.targetChanges.get(u.targetId))==null?void 0:p.current;r.sharedClientState.updateQueryState(u.targetId,m?"current":"not-current")}if(d){i.push(d);const m=yc.Is(u.targetId,d);o.push(m)}}))}),await Promise.all(s),r.Pu.H_(i),await async function(u,d){const p=X(u);try{await p.persistence.runTransaction("notifyLocalViewChanges","readwrite",m=>D.forEach(d,g=>D.forEach(g.Ts,b=>p.persistence.referenceDelegate.addReference(m,g.targetId,b)).next(()=>D.forEach(g.Es,b=>p.persistence.referenceDelegate.removeReference(m,g.targetId,b)))))}catch(m){if(!vi(m))throw m;B(vc,"Failed to update sequence numbers: "+m)}for(const m of d){const g=m.targetId;if(!m.fromCache){const b=p.vs.get(g),O=b.snapshotVersion,A=b.withLastLimboFreeSnapshotVersion(O);p.vs=p.vs.insert(g,A)}}}(r.localStore,o))}async function fE(n,e){const t=X(n);if(!t.currentUser.isEqual(e)){B(Pc,"User change. New user:",e.toKey());const r=await qp(t.localStore,e);t.currentUser=e,function(o,s){o.mu.forEach(l=>{l.forEach(u=>{u.reject(new q(N.CANCELLED,s))})}),o.mu.clear()}(t,"'waitForPendingWrites' promise is rejected due to a user change."),t.sharedClientState.handleUserChange(e,r.removedBatchIds,r.addedBatchIds),await Lo(t,r.Ns)}}function pE(n,e){const t=X(n),r=t.Au.get(e);if(r&&r.hu)return ie().add(r.key);{let i=ie();const o=t.Eu.get(e);if(!o)return i;for(const s of o){const l=t.Tu.get(s);i=i.unionWith(l.view.nu)}return i}}function rg(n){const e=X(n);return e.remoteStore.remoteSyncer.applyRemoteEvent=Zp.bind(null,e),e.remoteStore.remoteSyncer.getRemoteKeysForTarget=pE.bind(null,e),e.remoteStore.remoteSyncer.rejectListen=cE.bind(null,e),e.Pu.H_=JT.bind(null,e.eventManager),e.Pu.yu=XT.bind(null,e.eventManager),e}function gE(n){const e=X(n);return e.remoteStore.remoteSyncer.applySuccessfulWrite=uE.bind(null,e),e.remoteStore.remoteSyncer.rejectFailedWrite=hE.bind(null,e),e}class js{constructor(){this.kind="memory",this.synchronizeTabs=!1}async initialize(e){this.serializer=fa(e.databaseInfo.databaseId),this.sharedClientState=this.Du(e),this.persistence=this.Cu(e),await this.persistence.start(),this.localStore=this.vu(e),this.gcScheduler=this.Fu(e,this.localStore),this.indexBackfillerScheduler=this.Mu(e,this.localStore)}Fu(e,t){return null}Mu(e,t){return null}vu(e){return vT(this.persistence,new gT,e.initialUser,this.serializer)}Cu(e){return new Up(mc.Vi,this.serializer)}Du(e){return new AT}async terminate(){var e,t;(e=this.gcScheduler)==null||e.stop(),(t=this.indexBackfillerScheduler)==null||t.stop(),this.sharedClientState.shutdown(),await this.persistence.shutdown()}}js.provider={build:()=>new js};class mE extends js{constructor(e){super(),this.cacheSizeBytes=e}Fu(e,t){ce(this.persistence.referenceDelegate instanceof $s,46915);const r=this.persistence.referenceDelegate.garbageCollector;return new eT(r,e.asyncQueue,t)}Cu(e){const t=this.cacheSizeBytes!==void 0?it.withCacheSize(this.cacheSizeBytes):it.DEFAULT;return new Up(r=>$s.Vi(r,t),this.serializer)}}class Ol{async initialize(e,t){this.localStore||(this.localStore=e.localStore,this.sharedClientState=e.sharedClientState,this.datastore=this.createDatastore(t),this.remoteStore=this.createRemoteStore(t),this.eventManager=this.createEventManager(t),this.syncEngine=this.createSyncEngine(t,!e.synchronizeTabs),this.sharedClientState.onlineStateHandler=r=>fd(this.syncEngine,r,1),this.remoteStore.remoteSyncer.handleCredentialChange=fE.bind(null,this.syncEngine),await KT(this.remoteStore,this.syncEngine.isPrimaryClient))}createEventManager(e){return function(){return new QT}()}createDatastore(e){const t=fa(e.databaseInfo.databaseId),r=CT(e.databaseInfo);return LT(e.authCredentials,e.appCheckCredentials,r,t)}createRemoteStore(e){return function(r,i,o,s,l){return new VT(r,i,o,s,l)}(this.localStore,this.datastore,e.asyncQueue,t=>fd(this.syncEngine,t,0),function(){return ad.v()?new ad:new ST}())}createSyncEngine(e,t){return function(i,o,s,l,u,d,p){const m=new nE(i,o,s,l,u,d);return p&&(m.gu=!0),m}(this.localStore,this.remoteStore,this.eventManager,this.sharedClientState,e.initialUser,e.maxConcurrentLimboResolutions,t)}async terminate(){var e,t;await async function(i){const o=X(i);B(wr,"RemoteStore shutting down."),o.Ia.add(5),await Do(o),o.Aa.shutdown(),o.Va.set("Unknown")}(this.remoteStore),(e=this.datastore)==null||e.terminate(),(t=this.eventManager)==null||t.terminate()}}Ol.provider={build:()=>new Ol};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Rc{constructor(e){this.observer=e,this.muted=!1}next(e){this.muted||this.observer.next&&this.Ou(this.observer.next,e)}error(e){this.muted||(this.observer.error?this.Ou(this.observer.error,e):dn("Uncaught Error in snapshot listener:",e.toString()))}Nu(){this.muted=!0}Ou(e,t){setTimeout(()=>{this.muted||e(t)},0)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Gn="FirestoreClient";class yE{constructor(e,t,r,i,o){this.authCredentials=e,this.appCheckCredentials=t,this.asyncQueue=r,this._databaseInfo=i,this.user=Ge.UNAUTHENTICATED,this.clientId=ic.newId(),this.authCredentialListener=()=>Promise.resolve(),this.appCheckCredentialListener=()=>Promise.resolve(),this._uninitializedComponentsProvider=o,this.authCredentials.start(r,async s=>{B(Gn,"Received user=",s.uid),await this.authCredentialListener(s),this.user=s}),this.appCheckCredentials.start(r,s=>(B(Gn,"Received new app check token=",s),this.appCheckCredentialListener(s,this.user)))}get configuration(){return{asyncQueue:this.asyncQueue,databaseInfo:this._databaseInfo,clientId:this.clientId,authCredentials:this.authCredentials,appCheckCredentials:this.appCheckCredentials,initialUser:this.user,maxConcurrentLimboResolutions:100}}setCredentialChangeListener(e){this.authCredentialListener=e}setAppCheckTokenChangeListener(e){this.appCheckCredentialListener=e}terminate(){this.asyncQueue.enterRestrictedMode();const e=new on;return this.asyncQueue.enqueueAndForgetEvenWhileRestricted(async()=>{try{this._onlineComponents&&await this._onlineComponents.terminate(),this._offlineComponents&&await this._offlineComponents.terminate(),this.authCredentials.shutdown(),this.appCheckCredentials.shutdown(),e.resolve()}catch(t){const r=Ic(t,"Failed to shutdown persistence");e.reject(r)}}),e.promise}}async function el(n,e){n.asyncQueue.verifyOperationInProgress(),B(Gn,"Initializing OfflineComponentProvider");const t=n.configuration;await e.initialize(t);let r=t.initialUser;n.setCredentialChangeListener(async i=>{r.isEqual(i)||(await qp(e.localStore,i),r=i)}),e.persistence.setDatabaseDeletedListener(()=>n.terminate()),n._offlineComponents=e}async function gd(n,e){n.asyncQueue.verifyOperationInProgress();const t=await vE(n);B(Gn,"Initializing OnlineComponentProvider"),await e.initialize(t,n.configuration),n.setCredentialChangeListener(r=>cd(e.remoteStore,r)),n.setAppCheckTokenChangeListener((r,i)=>cd(e.remoteStore,i)),n._onlineComponents=e}async function vE(n){if(!n._offlineComponents)if(n._uninitializedComponentsProvider){B(Gn,"Using user provided OfflineComponentProvider");try{await el(n,n._uninitializedComponentsProvider._offline)}catch(e){const t=e;if(!function(i){return i.name==="FirebaseError"?i.code===N.FAILED_PRECONDITION||i.code===N.UNIMPLEMENTED:!(typeof DOMException<"u"&&i instanceof DOMException)||i.code===22||i.code===20||i.code===11}(t))throw t;_r("Error using user provided cache. Falling back to memory cache: "+t),await el(n,new js)}}else B(Gn,"Using default OfflineComponentProvider"),await el(n,new mE(void 0));return n._offlineComponents}async function ig(n){return n._onlineComponents||(n._uninitializedComponentsProvider?(B(Gn,"Using user provided OnlineComponentProvider"),await gd(n,n._uninitializedComponentsProvider._online)):(B(Gn,"Using default OnlineComponentProvider"),await gd(n,new Ol))),n._onlineComponents}function _E(n){return ig(n).then(e=>e.syncEngine)}async function zs(n){const e=await ig(n),t=e.eventManager;return t.onListen=rE.bind(null,e.syncEngine),t.onUnlisten=sE.bind(null,e.syncEngine),t.onFirstRemoteStoreListen=iE.bind(null,e.syncEngine),t.onLastRemoteStoreUnlisten=aE.bind(null,e.syncEngine),t}function wE(n,e,t,r){const i=new Rc(r),o=new kc(e,i,t);return n.asyncQueue.enqueueAndForget(async()=>Ac(await zs(n),o)),()=>{i.Nu(),n.asyncQueue.enqueueAndForget(async()=>Sc(await zs(n),o))}}function bE(n,e,t={}){const r=new on;return n.asyncQueue.enqueueAndForget(async()=>function(o,s,l,u,d){const p=new Rc({next:g=>{p.Nu(),s.enqueueAndForget(()=>Sc(o,m));const b=g.docs.has(l);!b&&g.fromCache?d.reject(new q(N.UNAVAILABLE,"Failed to get document because the client is offline.")):b&&g.fromCache&&u&&u.source==="server"?d.reject(new q(N.UNAVAILABLE,'Failed to get document from server. (However, this document does exist in the local cache. Run again without setting source to "server" to retrieve the cached document.)')):d.resolve(g)},error:g=>d.reject(g)}),m=new kc(aa(l.path),p,{includeMetadataChanges:!0,qa:!0});return Ac(o,m)}(await zs(n),n.asyncQueue,e,t,r)),r.promise}function TE(n,e,t={}){const r=new on;return n.asyncQueue.enqueueAndForget(async()=>function(o,s,l,u,d){const p=new Rc({next:g=>{p.Nu(),s.enqueueAndForget(()=>Sc(o,m)),g.fromCache&&u.source==="server"?d.reject(new q(N.UNAVAILABLE,'Failed to get documents from server. (However, these documents may exist in the local cache. Run again without setting source to "server" to retrieve the cached documents.)')):d.resolve(g)},error:g=>d.reject(g)}),m=new kc(l,p,{includeMetadataChanges:!0,qa:!0});return Ac(o,m)}(await zs(n),n.asyncQueue,e,t,r)),r.promise}function EE(n,e){const t=new on;return n.asyncQueue.enqueueAndForget(async()=>lE(await _E(n),e,t)),t.promise}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function og(n){const e={};return n.timeoutSeconds!==void 0&&(e.timeoutSeconds=n.timeoutSeconds),e}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const IE="ComponentProvider",md=new Map;function AE(n,e,t,r,i){return new Ww(n,e,t,i.host,i.ssl,i.experimentalForceLongPolling,i.experimentalAutoDetectLongPolling,og(i.experimentalLongPollingOptions),i.useFetchStreams,i.isUsingEmulator,r)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const sg="firestore.googleapis.com",yd=!0;class vd{constructor(e){if(e.host===void 0){if(e.ssl!==void 0)throw new q(N.INVALID_ARGUMENT,"Can't provide ssl option if host option is not set");this.host=sg,this.ssl=yd}else this.host=e.host,this.ssl=e.ssl??yd;if(this.isUsingEmulator=e.emulatorOptions!==void 0,this.credentials=e.credentials,this.ignoreUndefinedProperties=!!e.ignoreUndefinedProperties,this.localCache=e.localCache,e.cacheSizeBytes===void 0)this.cacheSizeBytes=Fp;else{if(e.cacheSizeBytes!==-1&&e.cacheSizeBytes<Xb)throw new q(N.INVALID_ARGUMENT,"cacheSizeBytes must be at least 1048576");this.cacheSizeBytes=e.cacheSizeBytes}Nw("experimentalForceLongPolling",e.experimentalForceLongPolling,"experimentalAutoDetectLongPolling",e.experimentalAutoDetectLongPolling),this.experimentalForceLongPolling=!!e.experimentalForceLongPolling,this.experimentalForceLongPolling?this.experimentalAutoDetectLongPolling=!1:e.experimentalAutoDetectLongPolling===void 0?this.experimentalAutoDetectLongPolling=!0:this.experimentalAutoDetectLongPolling=!!e.experimentalAutoDetectLongPolling,this.experimentalLongPollingOptions=og(e.experimentalLongPollingOptions??{}),function(r){if(r.timeoutSeconds!==void 0){if(isNaN(r.timeoutSeconds))throw new q(N.INVALID_ARGUMENT,`invalid long polling timeout: ${r.timeoutSeconds} (must not be NaN)`);if(r.timeoutSeconds<5)throw new q(N.INVALID_ARGUMENT,`invalid long polling timeout: ${r.timeoutSeconds} (minimum allowed value is 5)`);if(r.timeoutSeconds>30)throw new q(N.INVALID_ARGUMENT,`invalid long polling timeout: ${r.timeoutSeconds} (maximum allowed value is 30)`)}}(this.experimentalLongPollingOptions),this.useFetchStreams=!!e.useFetchStreams}isEqual(e){return this.host===e.host&&this.ssl===e.ssl&&this.credentials===e.credentials&&this.cacheSizeBytes===e.cacheSizeBytes&&this.experimentalForceLongPolling===e.experimentalForceLongPolling&&this.experimentalAutoDetectLongPolling===e.experimentalAutoDetectLongPolling&&function(r,i){return r.timeoutSeconds===i.timeoutSeconds}(this.experimentalLongPollingOptions,e.experimentalLongPollingOptions)&&this.ignoreUndefinedProperties===e.ignoreUndefinedProperties&&this.useFetchStreams===e.useFetchStreams}}class ma{constructor(e,t,r,i){this._authCredentials=e,this._appCheckCredentials=t,this._databaseId=r,this._app=i,this.type="firestore-lite",this._persistenceKey="(lite)",this._settings=new vd({}),this._settingsFrozen=!1,this._emulatorOptions={},this._terminateTask="notTerminated"}get app(){if(!this._app)throw new q(N.FAILED_PRECONDITION,"Firestore was not initialized using the Firebase SDK. 'app' is not available");return this._app}get _initialized(){return this._settingsFrozen}get _terminated(){return this._terminateTask!=="notTerminated"}_setSettings(e){if(this._settingsFrozen)throw new q(N.FAILED_PRECONDITION,"Firestore has already been started and its settings can no longer be changed. You can only modify settings before calling any other methods on a Firestore object.");this._settings=new vd(e),this._emulatorOptions=e.emulatorOptions||{},e.credentials!==void 0&&(this._authCredentials=function(r){if(!r)return new Ew;switch(r.type){case"firstParty":return new xw(r.sessionIndex||"0",r.iamToken||null,r.authTokenFactory||null);case"provider":return r.client;default:throw new q(N.INVALID_ARGUMENT,"makeAuthCredentialsProvider failed due to invalid credential type")}}(e.credentials))}_getSettings(){return this._settings}_getEmulatorOptions(){return this._emulatorOptions}_freezeSettings(){return this._settingsFrozen=!0,this._settings}_delete(){return this._terminateTask==="notTerminated"&&(this._terminateTask=this._terminate()),this._terminateTask}async _restart(){this._terminateTask==="notTerminated"?await this._terminate():this._terminateTask="notTerminated"}toJSON(){return{app:this._app,databaseId:this._databaseId,settings:this._settings}}_terminate(){return function(t){const r=md.get(t);r&&(B(IE,"Removing Datastore"),md.delete(t),r.terminate())}(this),Promise.resolve()}}function SE(n,e,t,r={}){var d;n=yt(n,ma);const i=xo(e),o=n._getSettings(),s={...o,emulatorOptions:n._getEmulatorOptions()},l=`${e}:${t}`;i&&ef(`https://${l}`),o.host!==sg&&o.host!==l&&_r("Host has been set in both settings() and connectFirestoreEmulator(), emulator host will be used.");const u={...o,host:l,ssl:i,emulatorOptions:r};if(!gr(u,s)&&(n._setSettings(u),r.mockUserToken)){let p,m;if(typeof r.mockUserToken=="string")p=r.mockUserToken,m=Ge.MOCK_USER;else{p=Ym(r.mockUserToken,(d=n._app)==null?void 0:d.options.projectId);const g=r.mockUserToken.sub||r.mockUserToken.user_id;if(!g)throw new q(N.INVALID_ARGUMENT,"mockUserToken must contain 'sub' or 'user_id' field!");m=new Ge(g)}n._authCredentials=new Iw(new Gf(p,m))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class yn{constructor(e,t,r){this.converter=t,this._query=r,this.type="query",this.firestore=e}withConverter(e){return new yn(this.firestore,e,this._query)}}class Ee{constructor(e,t,r){this.converter=t,this._key=r,this.type="document",this.firestore=e}get _path(){return this._key.path}get id(){return this._key.path.lastSegment()}get path(){return this._key.path.canonicalString()}get parent(){return new Un(this.firestore,this.converter,this._key.path.popLast())}withConverter(e){return new Ee(this.firestore,e,this._key)}toJSON(){return{type:Ee._jsonSchemaVersion,referencePath:this._key.toString()}}static fromJSON(e,t,r){if(Ro(t,Ee._jsonSchema))return new Ee(e,r||null,new H(fe.fromString(t.referencePath)))}}Ee._jsonSchemaVersion="firestore/documentReference/1.0",Ee._jsonSchema={type:Re("string",Ee._jsonSchemaVersion),referencePath:Re("string")};class Un extends yn{constructor(e,t,r){super(e,t,aa(r)),this._path=r,this.type="collection"}get id(){return this._query.path.lastSegment()}get path(){return this._query.path.canonicalString()}get parent(){const e=this._path.popLast();return e.isEmpty()?null:new Ee(this.firestore,null,new H(e))}withConverter(e){return new Un(this.firestore,e,this._path)}}function Ar(n,e,...t){if(n=qe(n),Kf("collection","path",e),n instanceof ma){const r=fe.fromString(e,...t);return Rh(r),new Un(n,null,r)}{if(!(n instanceof Ee||n instanceof Un))throw new q(N.INVALID_ARGUMENT,"Expected first argument to collection() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const r=n._path.child(fe.fromString(e,...t));return Rh(r),new Un(n.firestore,null,r)}}function _e(n,e,...t){if(n=qe(n),arguments.length===1&&(e=ic.newId()),Kf("doc","path",e),n instanceof ma){const r=fe.fromString(e,...t);return Ch(r),new Ee(n,null,new H(r))}{if(!(n instanceof Ee||n instanceof Un))throw new q(N.INVALID_ARGUMENT,"Expected first argument to doc() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const r=n._path.child(fe.fromString(e,...t));return Ch(r),new Ee(n.firestore,n instanceof Un?n.converter:null,new H(r))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const _d="AsyncQueue";class wd{constructor(e=Promise.resolve()){this.Yu=[],this.ec=!1,this.tc=[],this.nc=null,this.rc=!1,this.sc=!1,this.oc=[],this.M_=new Bp(this,"async_queue_retry"),this._c=()=>{const r=Za();r&&B(_d,"Visibility state changed to "+r.visibilityState),this.M_.w_()},this.ac=e;const t=Za();t&&typeof t.addEventListener=="function"&&t.addEventListener("visibilitychange",this._c)}get isShuttingDown(){return this.ec}enqueueAndForget(e){this.enqueue(e)}enqueueAndForgetEvenWhileRestricted(e){this.uc(),this.cc(e)}enterRestrictedMode(e){if(!this.ec){this.ec=!0,this.sc=e||!1;const t=Za();t&&typeof t.removeEventListener=="function"&&t.removeEventListener("visibilitychange",this._c)}}enqueue(e){if(this.uc(),this.ec)return new Promise(()=>{});const t=new on;return this.cc(()=>this.ec&&this.sc?Promise.resolve():(e().then(t.resolve,t.reject),t.promise)).then(()=>t.promise)}enqueueRetryable(e){this.enqueueAndForget(()=>(this.Yu.push(e),this.lc()))}async lc(){if(this.Yu.length!==0){try{await this.Yu[0](),this.Yu.shift(),this.M_.reset()}catch(e){if(!vi(e))throw e;B(_d,"Operation failed with retryable error: "+e)}this.Yu.length>0&&this.M_.p_(()=>this.lc())}}cc(e){const t=this.ac.then(()=>(this.rc=!0,e().catch(r=>{throw this.nc=r,this.rc=!1,dn("INTERNAL UNHANDLED ERROR: ",bd(r)),r}).then(r=>(this.rc=!1,r))));return this.ac=t,t}enqueueAfterDelay(e,t,r){this.uc(),this.oc.indexOf(e)>-1&&(t=0);const i=Ec.createAndSchedule(this,e,t,r,o=>this.hc(o));return this.tc.push(i),i}uc(){this.nc&&K(47125,{Pc:bd(this.nc)})}verifyOperationInProgress(){}async Tc(){let e;do e=this.ac,await e;while(e!==this.ac)}Ec(e){for(const t of this.tc)if(t.timerId===e)return!0;return!1}Ic(e){return this.Tc().then(()=>{this.tc.sort((t,r)=>t.targetTimeMs-r.targetTimeMs);for(const t of this.tc)if(t.skipDelay(),e!=="all"&&t.timerId===e)break;return this.Tc()})}Rc(e){this.oc.push(e)}hc(e){const t=this.tc.indexOf(e);this.tc.splice(t,1)}}function bd(n){let e=n.message||"";return n.stack&&(e=n.stack.includes(n.message)?n.stack:n.message+`
`+n.stack),e}class Kn extends ma{constructor(e,t,r,i){super(e,t,r,i),this.type="firestore",this._queue=new wd,this._persistenceKey=(i==null?void 0:i.name)||"[DEFAULT]"}async _terminate(){if(this._firestoreClient){const e=this._firestoreClient.terminate();this._queue=new wd(e),this._firestoreClient=void 0,await e}}}function xE(n,e){const t=typeof n=="object"?n:rf(),r=typeof n=="string"?n:Ms,i=Gl(t,"firestore").getImmediate({identifier:r});if(!i._initialized){const o=Gm("firestore");o&&SE(i,...o)}return i}function ya(n){if(n._terminated)throw new q(N.FAILED_PRECONDITION,"The client has already been terminated.");return n._firestoreClient||kE(n),n._firestoreClient}function kE(n){var r,i,o,s;const e=n._freezeSettings(),t=AE(n._databaseId,((r=n._app)==null?void 0:r.options.appId)||"",n._persistenceKey,(i=n._app)==null?void 0:i.options.apiKey,e);n._componentsProvider||(o=e.localCache)!=null&&o._offlineComponentProvider&&((s=e.localCache)!=null&&s._onlineComponentProvider)&&(n._componentsProvider={_offline:e.localCache._offlineComponentProvider,_online:e.localCache._onlineComponentProvider}),n._firestoreClient=new yE(n._authCredentials,n._appCheckCredentials,n._queue,t,n._componentsProvider&&function(u){const d=u==null?void 0:u._online.build();return{_offline:u==null?void 0:u._offline.build(d),_online:d}}(n._componentsProvider))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _t{constructor(e){this._byteString=e}static fromBase64String(e){try{return new _t(ze.fromBase64String(e))}catch(t){throw new q(N.INVALID_ARGUMENT,"Failed to construct data from Base64 string: "+t)}}static fromUint8Array(e){return new _t(ze.fromUint8Array(e))}toBase64(){return this._byteString.toBase64()}toUint8Array(){return this._byteString.toUint8Array()}toString(){return"Bytes(base64: "+this.toBase64()+")"}isEqual(e){return this._byteString.isEqual(e._byteString)}toJSON(){return{type:_t._jsonSchemaVersion,bytes:this.toBase64()}}static fromJSON(e){if(Ro(e,_t._jsonSchema))return _t.fromBase64String(e.bytes)}}_t._jsonSchemaVersion="firestore/bytes/1.0",_t._jsonSchema={type:Re("string",_t._jsonSchemaVersion),bytes:Re("string")};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Oc{constructor(...e){for(let t=0;t<e.length;++t)if(e[t].length===0)throw new q(N.INVALID_ARGUMENT,"Invalid field name at argument $(i + 1). Field names must not be empty.");this._internalPath=new Be(e)}isEqual(e){return this._internalPath.isEqual(e._internalPath)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Mo{constructor(e){this._methodName=e}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class jt{constructor(e,t){if(!isFinite(e)||e<-90||e>90)throw new q(N.INVALID_ARGUMENT,"Latitude must be a number between -90 and 90, but was: "+e);if(!isFinite(t)||t<-180||t>180)throw new q(N.INVALID_ARGUMENT,"Longitude must be a number between -180 and 180, but was: "+t);this._lat=e,this._long=t}get latitude(){return this._lat}get longitude(){return this._long}isEqual(e){return this._lat===e._lat&&this._long===e._long}_compareTo(e){return re(this._lat,e._lat)||re(this._long,e._long)}toJSON(){return{latitude:this._lat,longitude:this._long,type:jt._jsonSchemaVersion}}static fromJSON(e){if(Ro(e,jt._jsonSchema))return new jt(e.latitude,e.longitude)}}jt._jsonSchemaVersion="firestore/geoPoint/1.0",jt._jsonSchema={type:Re("string",jt._jsonSchemaVersion),latitude:Re("number"),longitude:Re("number")};/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class It{constructor(e){this._values=(e||[]).map(t=>t)}toArray(){return this._values.map(e=>e)}isEqual(e){return function(r,i){if(r.length!==i.length)return!1;for(let o=0;o<r.length;++o)if(r[o]!==i[o])return!1;return!0}(this._values,e._values)}toJSON(){return{type:It._jsonSchemaVersion,vectorValues:this._values}}static fromJSON(e){if(Ro(e,It._jsonSchema)){if(Array.isArray(e.vectorValues)&&e.vectorValues.every(t=>typeof t=="number"))return new It(e.vectorValues);throw new q(N.INVALID_ARGUMENT,"Expected 'vectorValues' field to be a number array")}}}It._jsonSchemaVersion="firestore/vectorValue/1.0",It._jsonSchema={type:Re("string",It._jsonSchemaVersion),vectorValues:Re("object")};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const PE=/^__.*__$/;class CE{constructor(e,t,r){this.data=e,this.fieldMask=t,this.fieldTransforms=r}toMutation(e,t){return this.fieldMask!==null?new Qn(e,this.data,this.fieldMask,t,this.fieldTransforms):new Oo(e,this.data,t,this.fieldTransforms)}}class ag{constructor(e,t,r){this.data=e,this.fieldMask=t,this.fieldTransforms=r}toMutation(e,t){return new Qn(e,this.data,this.fieldMask,t,this.fieldTransforms)}}function lg(n){switch(n){case 0:case 2:case 1:return!0;case 3:case 4:return!1;default:throw K(40011,{dataSource:n})}}class Nc{constructor(e,t,r,i,o,s){this.settings=e,this.databaseId=t,this.serializer=r,this.ignoreUndefinedProperties=i,o===void 0&&this.Ac(),this.fieldTransforms=o||[],this.fieldMask=s||[]}get path(){return this.settings.path}get dataSource(){return this.settings.dataSource}i(e){return new Nc({...this.settings,...e},this.databaseId,this.serializer,this.ignoreUndefinedProperties,this.fieldTransforms,this.fieldMask)}dc(e){var i;const t=(i=this.path)==null?void 0:i.child(e),r=this.i({path:t,arrayElement:!1});return r.mc(e),r}fc(e){var i;const t=(i=this.path)==null?void 0:i.child(e),r=this.i({path:t,arrayElement:!1});return r.Ac(),r}gc(e){return this.i({path:void 0,arrayElement:!0})}yc(e){return Ws(e,this.settings.methodName,this.settings.hasConverter||!1,this.path,this.settings.targetDoc)}contains(e){return this.fieldMask.find(t=>e.isPrefixOf(t))!==void 0||this.fieldTransforms.find(t=>e.isPrefixOf(t.field))!==void 0}Ac(){if(this.path)for(let e=0;e<this.path.length;e++)this.mc(this.path.get(e))}mc(e){if(e.length===0)throw this.yc("Document fields must not be empty");if(lg(this.dataSource)&&PE.test(e))throw this.yc('Document fields cannot begin and end with "__"')}}class RE{constructor(e,t,r){this.databaseId=e,this.ignoreUndefinedProperties=t,this.serializer=r||fa(e)}I(e,t,r,i=!1){return new Nc({dataSource:e,methodName:t,targetDoc:r,path:Be.emptyPath(),arrayElement:!1,hasConverter:i},this.databaseId,this.serializer,this.ignoreUndefinedProperties)}}function Dc(n){const e=n._freezeSettings(),t=fa(n._databaseId);return new RE(n._databaseId,!!e.ignoreUndefinedProperties,t)}function OE(n,e,t,r,i,o={}){const s=n.I(o.merge||o.mergeFields?2:0,e,t,i);Vc("Data must be an object, but it was:",s,r);const l=cg(r,s);let u,d;if(o.merge)u=new mt(s.fieldMask),d=s.fieldTransforms;else if(o.mergeFields){const p=[];for(const m of o.mergeFields){const g=si(e,m,t);if(!s.contains(g))throw new q(N.INVALID_ARGUMENT,`Field '${g}' is specified in your field mask but missing from your input data.`);dg(p,g)||p.push(g)}u=new mt(p),d=s.fieldTransforms.filter(m=>u.covers(m.field))}else u=null,d=s.fieldTransforms;return new CE(new lt(l),u,d)}class va extends Mo{_toFieldTransform(e){if(e.dataSource!==2)throw e.dataSource===1?e.yc(`${this._methodName}() can only appear at the top level of your update data`):e.yc(`${this._methodName}() cannot be used with set() unless you pass {merge:true}`);return e.fieldMask.push(e.path),null}isEqual(e){return e instanceof va}}class Lc extends Mo{_toFieldTransform(e){return new Ip(e.path,new mo)}isEqual(e){return e instanceof Lc}}class Mc extends Mo{constructor(e,t){super(e),this.bc=t}_toFieldTransform(e){const t=new _o(e.serializer,_p(e.serializer,this.bc));return new Ip(e.path,t)}isEqual(e){return e instanceof Mc&&this.bc===e.bc}}function NE(n,e,t,r){const i=n.I(1,e,t);Vc("Data must be an object, but it was:",i,r);const o=[],s=lt.empty();Yn(r,(u,d)=>{const p=hg(e,u,t);d=qe(d);const m=i.fc(p);if(d instanceof va)o.push(p);else{const g=Vo(d,m);g!=null&&(o.push(p),s.set(p,g))}});const l=new mt(o);return new ag(s,l,i.fieldTransforms)}function DE(n,e,t,r,i,o){const s=n.I(1,e,t),l=[si(e,r,t)],u=[i];if(o.length%2!=0)throw new q(N.INVALID_ARGUMENT,`Function ${e}() needs to be called with an even number of arguments that alternate between field names and values.`);for(let g=0;g<o.length;g+=2)l.push(si(e,o[g])),u.push(o[g+1]);const d=[],p=lt.empty();for(let g=l.length-1;g>=0;--g)if(!dg(d,l[g])){const b=l[g];let O=u[g];O=qe(O);const A=s.fc(b);if(O instanceof va)d.push(b);else{const P=Vo(O,A);P!=null&&(d.push(b),p.set(b,P))}}const m=new mt(d);return new ag(p,m,s.fieldTransforms)}function LE(n,e,t,r=!1){return Vo(t,n.I(r?4:3,e))}function Vo(n,e){if(ug(n=qe(n)))return Vc("Unsupported field value:",e,n),cg(n,e);if(n instanceof Mo)return function(r,i){if(!lg(i.dataSource))throw i.yc(`${r._methodName}() can only be used with update() and set()`);if(!i.path)throw i.yc(`${r._methodName}() is not currently supported inside arrays`);const o=r._toFieldTransform(i);o&&i.fieldTransforms.push(o)}(n,e),null;if(n===void 0&&e.ignoreUndefinedProperties)return null;if(e.path&&e.fieldMask.push(e.path),n instanceof Array){if(e.settings.arrayElement&&e.dataSource!==4)throw e.yc("Nested arrays are not supported");return function(r,i){const o=[];let s=0;for(const l of r){let u=Vo(l,i.gc(s));u==null&&(u={nullValue:"NULL_VALUE"}),o.push(u),s++}return{arrayValue:{values:o}}}(n,e)}return function(r,i){if((r=qe(r))===null)return{nullValue:"NULL_VALUE"};if(typeof r=="number")return _p(i.serializer,r);if(typeof r=="boolean")return{booleanValue:r};if(typeof r=="string")return{stringValue:r};if(r instanceof Date){const o=me.fromDate(r);return{timestampValue:qs(i.serializer,o)}}if(r instanceof me){const o=new me(r.seconds,1e3*Math.floor(r.nanoseconds/1e3));return{timestampValue:qs(i.serializer,o)}}if(r instanceof jt)return{geoPointValue:{latitude:r.latitude,longitude:r.longitude}};if(r instanceof _t)return{bytesValue:Cp(i.serializer,r._byteString)};if(r instanceof Ee){const o=i.databaseId,s=r.firestore._databaseId;if(!s.isEqual(o))throw i.yc(`Document reference is for database ${s.projectId}/${s.database} but should be for database ${o.projectId}/${o.database}`);return{referenceValue:pc(r.firestore._databaseId||i.databaseId,r._key.path)}}if(r instanceof It)return function(s,l){const u=s instanceof It?s.toArray():s;return{mapValue:{fields:{[rp]:{stringValue:ip},[Vs]:{arrayValue:{values:u.map(p=>{if(typeof p!="number")throw l.yc("VectorValues must only contain numeric values.");return uc(l.serializer,p)})}}}}}}(r,i);if(Vp(r))return r._toProto(i.serializer);throw i.yc(`Unsupported field value: ${ra(r)}`)}(n,e)}function cg(n,e){const t={};return Jf(n)?e.path&&e.path.length>0&&e.fieldMask.push(e.path):Yn(n,(r,i)=>{const o=Vo(i,e.dc(r));o!=null&&(t[r]=o)}),{mapValue:{fields:t}}}function ug(n){return!(typeof n!="object"||n===null||n instanceof Array||n instanceof Date||n instanceof me||n instanceof jt||n instanceof _t||n instanceof Ee||n instanceof Mo||n instanceof It||Vp(n))}function Vc(n,e,t){if(!ug(t)||!Yf(t)){const r=ra(t);throw r==="an object"?e.yc(n+" a custom object"):e.yc(n+" "+r)}}function si(n,e,t){if((e=qe(e))instanceof Oc)return e._internalPath;if(typeof e=="string")return hg(n,e);throw Ws("Field path arguments must be of type string or ",n,!1,void 0,t)}const ME=new RegExp("[~\\*/\\[\\]]");function hg(n,e,t){if(e.search(ME)>=0)throw Ws(`Invalid field path (${e}). Paths must not contain '~', '*', '/', '[', or ']'`,n,!1,void 0,t);try{return new Oc(...e.split("."))._internalPath}catch{throw Ws(`Invalid field path (${e}). Paths must not be empty, begin with '.', end with '.', or contain '..'`,n,!1,void 0,t)}}function Ws(n,e,t,r,i){const o=r&&!r.isEmpty(),s=i!==void 0;let l=`Function ${e}() called with invalid data`;t&&(l+=" (via `toFirestore()`)"),l+=". ";let u="";return(o||s)&&(u+=" (found",o&&(u+=` in field ${r}`),s&&(u+=` in document ${i}`),u+=")"),new q(N.INVALID_ARGUMENT,l+n+u)}function dg(n,e){return n.some(t=>t.isEqual(e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class VE{convertValue(e,t="none"){switch(Wn(e)){case 0:return null;case 1:return e.booleanValue;case 2:return Ae(e.integerValue||e.doubleValue);case 3:return this.convertTimestamp(e.timestampValue);case 4:return this.convertServerTimestamp(e,t);case 5:return e.stringValue;case 6:return this.convertBytes(zn(e.bytesValue));case 7:return this.convertReference(e.referenceValue);case 8:return this.convertGeoPoint(e.geoPointValue);case 9:return this.convertArray(e.arrayValue,t);case 11:return this.convertObject(e.mapValue,t);case 10:return this.convertVectorValue(e.mapValue);default:throw K(62114,{value:e})}}convertObject(e,t){return this.convertObjectMap(e.fields,t)}convertObjectMap(e,t="none"){const r={};return Yn(e,(i,o)=>{r[i]=this.convertValue(o,t)}),r}convertVectorValue(e){var r,i,o;const t=(o=(i=(r=e.fields)==null?void 0:r[Vs].arrayValue)==null?void 0:i.values)==null?void 0:o.map(s=>Ae(s.doubleValue));return new It(t)}convertGeoPoint(e){return new jt(Ae(e.latitude),Ae(e.longitude))}convertArray(e,t){return(e.values||[]).map(r=>this.convertValue(r,t))}convertServerTimestamp(e,t){switch(t){case"previous":const r=sa(e);return r==null?null:this.convertValue(r,t);case"estimate":return this.convertTimestamp(ho(e));default:return null}}convertTimestamp(e){const t=jn(e);return new me(t.seconds,t.nanos)}convertDocumentKey(e,t){const r=fe.fromString(e);ce(Mp(r),9688,{name:e});const i=new fo(r.get(1),r.get(3)),o=new H(r.popFirst(5));return i.isEqual(t)||dn(`Document ${o} contains a document reference within a different database (${i.projectId}/${i.database}) which is not supported. It will be treated as a reference in the current database (${t.projectId}/${t.database}) instead.`),o}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Fc extends VE{constructor(e){super(),this.firestore=e}convertBytes(e){return new _t(e)}convertReference(e){const t=this.convertDocumentKey(e,this.firestore._databaseId);return new Ee(this.firestore,null,t)}}function ai(){return new Lc("serverTimestamp")}function Hs(n){return new Mc("increment",n)}const Td="@firebase/firestore",Ed="4.14.0";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Id(n){return function(t,r){if(typeof t!="object"||t===null)return!1;const i=t;for(const o of r)if(o in i&&typeof i[o]=="function")return!0;return!1}(n,["next","error","complete"])}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fg{constructor(e,t,r,i,o){this._firestore=e,this._userDataWriter=t,this._key=r,this._document=i,this._converter=o}get id(){return this._key.path.lastSegment()}get ref(){return new Ee(this._firestore,this._converter,this._key)}exists(){return this._document!==null}data(){if(this._document){if(this._converter){const e=new FE(this._firestore,this._userDataWriter,this._key,this._document,null);return this._converter.fromFirestore(e)}return this._userDataWriter.convertValue(this._document.data.value)}}_fieldsProto(){var e;return((e=this._document)==null?void 0:e.data.clone().value.mapValue.fields)??void 0}get(e){if(this._document){const t=this._document.data.field(si("DocumentSnapshot.get",e));if(t!==null)return this._userDataWriter.convertValue(t)}}}class FE extends fg{data(){return super.data()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function pg(n){if(n.limitType==="L"&&n.explicitOrderBy.length===0)throw new q(N.UNIMPLEMENTED,"limitToLast() queries require specifying at least one orderBy() clause")}class Uc{}class qc extends Uc{}function UE(n,e,...t){let r=[];e instanceof Uc&&r.push(e),r=r.concat(t),function(o){const s=o.filter(u=>u instanceof Bc).length,l=o.filter(u=>u instanceof $c).length;if(s>1||s>0&&l>0)throw new q(N.INVALID_ARGUMENT,"InvalidQuery. When using composite filters, you cannot use more than one filter at the top level. Consider nesting the multiple filters within an `and(...)` statement. For example: change `query(query, where(...), or(...))` to `query(query, and(where(...), or(...)))`.")}(r);for(const i of r)n=i._apply(n);return n}class $c extends qc{constructor(e,t,r){super(),this._field=e,this._op=t,this._value=r,this.type="where"}static _create(e,t,r){return new $c(e,t,r)}_apply(e){const t=this._parse(e);return gg(e._query,t),new yn(e.firestore,e.converter,El(e._query,t))}_parse(e){const t=Dc(e.firestore);return function(o,s,l,u,d,p,m){let g;if(d.isKeyField()){if(p==="array-contains"||p==="array-contains-any")throw new q(N.INVALID_ARGUMENT,`Invalid Query. You can't perform '${p}' queries on documentId().`);if(p==="in"||p==="not-in"){Sd(m,p);const O=[];for(const A of m)O.push(Ad(u,o,A));g={arrayValue:{values:O}}}else g=Ad(u,o,m)}else p!=="in"&&p!=="not-in"&&p!=="array-contains-any"||Sd(m,p),g=LE(l,s,m,p==="in"||p==="not-in");return Ce.create(d,p,g)}(e._query,"where",t,e.firestore._databaseId,this._field,this._op,this._value)}}class Bc extends Uc{constructor(e,t){super(),this.type=e,this._queryConstraints=t}static _create(e,t){return new Bc(e,t)}_parse(e){const t=this._queryConstraints.map(r=>r._parse(e)).filter(r=>r.getFilters().length>0);return t.length===1?t[0]:kt.create(t,this._getOperator())}_apply(e){const t=this._parse(e);return t.getFilters().length===0?e:(function(i,o){let s=i;const l=o.getFlattenedFilters();for(const u of l)gg(s,u),s=El(s,u)}(e._query,t),new yn(e.firestore,e.converter,El(e._query,t)))}_getQueryConstraints(){return this._queryConstraints}_getOperator(){return this.type==="and"?"and":"or"}}class jc extends qc{constructor(e,t){super(),this._field=e,this._direction=t,this.type="orderBy"}static _create(e,t){return new jc(e,t)}_apply(e){const t=function(i,o,s){if(i.startAt!==null)throw new q(N.INVALID_ARGUMENT,"Invalid query. You must not call startAt() or startAfter() before calling orderBy().");if(i.endAt!==null)throw new q(N.INVALID_ARGUMENT,"Invalid query. You must not call endAt() or endBefore() before calling orderBy().");return new go(o,s)}(e._query,this._field,this._direction);return new yn(e.firestore,e.converter,cb(e._query,t))}}function qE(n,e="asc"){const t=e,r=si("orderBy",n);return jc._create(r,t)}class zc extends qc{constructor(e,t,r){super(),this.type=e,this._limit=t,this._limitType=r}static _create(e,t,r){return new zc(e,t,r)}_apply(e){return new yn(e.firestore,e.converter,Us(e._query,this._limit,this._limitType))}}function $E(n){return Dw("limit",n),zc._create("limit",n,"F")}function Ad(n,e,t){if(typeof(t=qe(t))=="string"){if(t==="")throw new q(N.INVALID_ARGUMENT,"Invalid query. When querying with documentId(), you must provide a valid document ID, but it was an empty string.");if(!dp(e)&&t.indexOf("/")!==-1)throw new q(N.INVALID_ARGUMENT,`Invalid query. When querying a collection by documentId(), you must provide a plain document ID, but '${t}' contains a '/' character.`);const r=e.path.child(fe.fromString(t));if(!H.isDocumentKey(r))throw new q(N.INVALID_ARGUMENT,`Invalid query. When querying a collection group by documentId(), the value provided must result in a valid document path, but '${r}' is not because it has an odd number of segments (${r.length}).`);return Uh(n,new H(r))}if(t instanceof Ee)return Uh(n,t._key);throw new q(N.INVALID_ARGUMENT,`Invalid query. When querying with documentId(), you must provide a valid string or a DocumentReference, but it was: ${ra(t)}.`)}function Sd(n,e){if(!Array.isArray(n)||n.length===0)throw new q(N.INVALID_ARGUMENT,`Invalid Query. A non-empty array is required for '${e.toString()}' filters.`)}function gg(n,e){const t=function(i,o){for(const s of i)for(const l of s.getFlattenedFilters())if(o.indexOf(l.op)>=0)return l.op;return null}(n.filters,function(i){switch(i){case"!=":return["!=","not-in"];case"array-contains-any":case"in":return["not-in"];case"not-in":return["array-contains-any","in","not-in","!="];default:return[]}}(e.op));if(t!==null)throw t===e.op?new q(N.INVALID_ARGUMENT,`Invalid query. You cannot use more than one '${e.op.toString()}' filter.`):new q(N.INVALID_ARGUMENT,`Invalid query. You cannot use '${e.op.toString()}' filters with '${t.toString()}' filters.`)}function BE(n,e,t){let r;return r=n?t&&(t.merge||t.mergeFields)?n.toFirestore(e,t):n.toFirestore(e):e,r}class Yi{constructor(e,t){this.hasPendingWrites=e,this.fromCache=t}isEqual(e){return this.hasPendingWrites===e.hasPendingWrites&&this.fromCache===e.fromCache}}class hr extends fg{constructor(e,t,r,i,o,s){super(e,t,r,i,s),this._firestore=e,this._firestoreImpl=e,this.metadata=o}exists(){return super.exists()}data(e={}){if(this._document){if(this._converter){const t=new Ts(this._firestore,this._userDataWriter,this._key,this._document,this.metadata,null);return this._converter.fromFirestore(t,e)}return this._userDataWriter.convertValue(this._document.data.value,e.serverTimestamps)}}get(e,t={}){if(this._document){const r=this._document.data.field(si("DocumentSnapshot.get",e));if(r!==null)return this._userDataWriter.convertValue(r,t.serverTimestamps)}}toJSON(){if(this.metadata.hasPendingWrites)throw new q(N.FAILED_PRECONDITION,"DocumentSnapshot.toJSON() attempted to serialize a document with pending writes. Await waitForPendingWrites() before invoking toJSON().");const e=this._document,t={};return t.type=hr._jsonSchemaVersion,t.bundle="",t.bundleSource="DocumentSnapshot",t.bundleName=this._key.toString(),!e||!e.isValidDocument()||!e.isFoundDocument()?t:(this._userDataWriter.convertObjectMap(e.data.value.mapValue.fields,"previous"),t.bundle=(this._firestore,this.ref.path,"NOT SUPPORTED"),t)}}hr._jsonSchemaVersion="firestore/documentSnapshot/1.0",hr._jsonSchema={type:Re("string",hr._jsonSchemaVersion),bundleSource:Re("string","DocumentSnapshot"),bundleName:Re("string"),bundle:Re("string")};class Ts extends hr{data(e={}){return super.data(e)}}class dr{constructor(e,t,r,i){this._firestore=e,this._userDataWriter=t,this._snapshot=i,this.metadata=new Yi(i.hasPendingWrites,i.fromCache),this.query=r}get docs(){const e=[];return this.forEach(t=>e.push(t)),e}get size(){return this._snapshot.docs.size}get empty(){return this.size===0}forEach(e,t){this._snapshot.docs.forEach(r=>{e.call(t,new Ts(this._firestore,this._userDataWriter,r.key,r,new Yi(this._snapshot.mutatedKeys.has(r.key),this._snapshot.fromCache),this.query.converter))})}docChanges(e={}){const t=!!e.includeMetadataChanges;if(t&&this._snapshot.excludesMetadataChanges)throw new q(N.INVALID_ARGUMENT,"To include metadata changes with your document changes, you must also pass { includeMetadataChanges:true } to onSnapshot().");return this._cachedChanges&&this._cachedChangesIncludeMetadataChanges===t||(this._cachedChanges=function(i,o){if(i._snapshot.oldDocs.isEmpty()){let s=0;return i._snapshot.docChanges.map(l=>{const u=new Ts(i._firestore,i._userDataWriter,l.doc.key,l.doc,new Yi(i._snapshot.mutatedKeys.has(l.doc.key),i._snapshot.fromCache),i.query.converter);return l.doc,{type:"added",doc:u,oldIndex:-1,newIndex:s++}})}{let s=i._snapshot.oldDocs;return i._snapshot.docChanges.filter(l=>o||l.type!==3).map(l=>{const u=new Ts(i._firestore,i._userDataWriter,l.doc.key,l.doc,new Yi(i._snapshot.mutatedKeys.has(l.doc.key),i._snapshot.fromCache),i.query.converter);let d=-1,p=-1;return l.type!==0&&(d=s.indexOf(l.doc.key),s=s.delete(l.doc.key)),l.type!==1&&(s=s.add(l.doc),p=s.indexOf(l.doc.key)),{type:jE(l.type),doc:u,oldIndex:d,newIndex:p}})}}(this,t),this._cachedChangesIncludeMetadataChanges=t),this._cachedChanges}toJSON(){if(this.metadata.hasPendingWrites)throw new q(N.FAILED_PRECONDITION,"QuerySnapshot.toJSON() attempted to serialize a document with pending writes. Await waitForPendingWrites() before invoking toJSON().");const e={};e.type=dr._jsonSchemaVersion,e.bundleSource="QuerySnapshot",e.bundleName=ic.newId(),this._firestore._databaseId.database,this._firestore._databaseId.projectId;const t=[],r=[],i=[];return this.docs.forEach(o=>{o._document!==null&&(t.push(o._document),r.push(this._userDataWriter.convertObjectMap(o._document.data.value.mapValue.fields,"previous")),i.push(o.ref.path))}),e.bundle=(this._firestore,this.query._query,e.bundleName,"NOT SUPPORTED"),e}}function jE(n){switch(n){case 0:return"added";case 2:case 3:return"modified";case 1:return"removed";default:return K(61501,{type:n})}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */dr._jsonSchemaVersion="firestore/querySnapshot/1.0",dr._jsonSchema={type:Re("string",dr._jsonSchemaVersion),bundleSource:Re("string","QuerySnapshot"),bundleName:Re("string"),bundle:Re("string")};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Sr(n){n=yt(n,Ee);const e=yt(n.firestore,Kn),t=ya(e);return bE(t,n._key).then(r=>mg(e,n,r))}function Wc(n){n=yt(n,yn);const e=yt(n.firestore,Kn),t=ya(e),r=new Fc(e);return pg(n._query),TE(t,n._query).then(i=>new dr(e,r,n,i))}function pn(n,e,t){n=yt(n,Ee);const r=yt(n.firestore,Kn),i=BE(n.converter,e,t),o=Dc(r);return Hc(r,[OE(o,"setDoc",n._key,i,n.converter!==null,t).toMutation(n._key,Et.none())])}function br(n,e,t,...r){n=yt(n,Ee);const i=yt(n.firestore,Kn),o=Dc(i);let s;return s=typeof(e=qe(e))=="string"||e instanceof Oc?DE(o,"updateDoc",n._key,e,t,r):NE(o,"updateDoc",n._key,e),Hc(i,[s.toMutation(n._key,Et.exists(!0))])}function wo(n){return Hc(yt(n.firestore,Kn),[new hc(n._key,Et.none())])}function _a(n,...e){var d,p,m;n=qe(n);let t={includeMetadataChanges:!1,source:"default"},r=0;typeof e[r]!="object"||Id(e[r])||(t=e[r++]);const i={includeMetadataChanges:t.includeMetadataChanges,source:t.source};if(Id(e[r])){const g=e[r];e[r]=(d=g.next)==null?void 0:d.bind(g),e[r+1]=(p=g.error)==null?void 0:p.bind(g),e[r+2]=(m=g.complete)==null?void 0:m.bind(g)}let o,s,l;if(n instanceof Ee)s=yt(n.firestore,Kn),l=aa(n._key.path),o={next:g=>{e[r]&&e[r](mg(s,n,g))},error:e[r+1],complete:e[r+2]};else{const g=yt(n,yn);s=yt(g.firestore,Kn),l=g._query;const b=new Fc(s);o={next:O=>{e[r]&&e[r](new dr(s,b,g,O))},error:e[r+1],complete:e[r+2]},pg(n._query)}const u=ya(s);return wE(u,l,i,o)}function Hc(n,e){const t=ya(n);return EE(t,e)}function mg(n,e,t){const r=t.docs.get(e._key),i=new Fc(n);return new hr(n,i,e._key,r,new Yi(t.hasPendingWrites,t.fromCache),e.converter)}(function(e,t=!0){Tw(pi),Zr(new mr("firestore",(r,{instanceIdentifier:i,options:o})=>{const s=r.getProvider("app").getImmediate(),l=new Kn(new Aw(r.getProvider("auth-internal")),new kw(s,r.getProvider("app-check-internal")),Hw(s,i),s);return o={useFetchStreams:t,...o},l._setSettings(o),l},"PUBLIC").setMultipleInstances(!0)),Vn(Td,Ed,e),Vn(Td,Ed,"esm2020")})();let W=null;function zE(){let n;ks().length===0?n=Kl(Uf):n=ks()[0],W=xE(n),console.log("[OpenOverlay] Firestore initialized")}async function WE(n){if(!W){console.error("[OpenOverlay] Firestore not initialized");return}const e=_e(W,"users",n.uid);(await Sr(e)).exists()?(await br(e,{displayName:n.displayName||"Anonymous",photoURL:n.photoURL||"",email:n.email||""}),console.log("[OpenOverlay] User profile updated")):(await pn(e,{uid:n.uid,displayName:n.displayName||"Anonymous",email:n.email||"",photoURL:n.photoURL||"",bio:"",createdAt:ai(),followersCount:0,followingCount:0}),console.log("[OpenOverlay] User profile created"))}async function yg(n){if(!W)return null;const e=_e(W,"users",n),t=await Sr(e);return t.exists()?t.data():null}async function HE(n){const e=ue();if(!W||!e||e.uid===n)return;const t=_e(W,"users",e.uid,"following",n);await pn(t,{followedAt:ai()});const r=_e(W,"users",n,"followers",e.uid);await pn(r,{followedAt:ai()});const i=_e(W,"users",e.uid),o=_e(W,"users",n);await br(i,{followingCount:Hs(1)}),await br(o,{followersCount:Hs(1)}),console.log("[OpenOverlay] Followed user:",n)}async function GE(n){const e=ue();if(!W||!e||e.uid===n)return;const t=_e(W,"users",e.uid,"following",n);await wo(t);const r=_e(W,"users",n,"followers",e.uid);await wo(r);const i=_e(W,"users",e.uid),o=_e(W,"users",n);await br(i,{followingCount:Hs(-1)}),await br(o,{followersCount:Hs(-1)}),console.log("[OpenOverlay] Unfollowed user:",n)}async function KE(n){const e=ue();if(!W||!e)return!1;const t=_e(W,"users",e.uid,"following",n);return(await Sr(t)).exists()}async function YE(n,e=50){if(!W)return[];const t=Ar(W,"users",n,"following"),r=UE(t,qE("followedAt","desc"),$E(e)),i=await Wc(r),o=[];for(const s of i.docs){const l=await yg(s.id);l&&o.push(l)}return o}async function vg(n,e,t){const r=ue();if(!W||!r)return console.log("[OpenOverlay] Not logged in, skipping cloud save"),!1;try{const i=_e(W,"pageDrawings",n,"contributors",r.uid);return await pn(i,{userId:r.uid,userDisplayName:r.displayName||"Anonymous",userPhotoURL:r.photoURL||"",pageUrl:e,items:JSON.stringify(t),updatedAt:ai()}),console.log("[OpenOverlay] Drawing saved to cloud (public)"),!0}catch(i){return console.error("[OpenOverlay] Failed to save drawing to cloud:",i),!1}}async function QE(n){if(!W)return null;const e=ue();try{const t=Ar(W,"pageDrawings",n,"contributors"),r=await Wc(t),i=[],o=[],s=[];return r.docs.forEach(l=>{const u=l.data(),d=JSON.parse(u.items||"[]");s.push({userId:u.userId,displayName:u.userDisplayName,photoURL:u.userPhotoURL}),e&&u.userId===e.uid?i.push(...d):d.forEach(p=>{o.push({...p,_ownerId:u.userId,_ownerName:u.userDisplayName,_readOnly:!0})})}),console.log("[OpenOverlay] Loaded drawings:",i.length,"mine,",o.length,"from others"),{myItems:i,otherItems:o,contributors:s}}catch(t){return console.error("[OpenOverlay] Failed to load drawings from cloud:",t),null}}async function JE(n){const e=ue();if(!W||!e)return!1;try{const t=_e(W,"pageDrawings",n,"contributors",e.uid);return await wo(t),console.log("[OpenOverlay] Drawing deleted from cloud"),!0}catch(t){return console.error("[OpenOverlay] Failed to delete drawing from cloud:",t),!1}}let is=null;function XE(n,e){if(!W)return console.log("[OpenOverlay] Cannot subscribe to drawings: Firestore not initialized"),null;is&&is();const t=ue(),r=Ar(W,"pageDrawings",n,"contributors");return is=_a(r,i=>{const o=[],s=[],l=[];i.docs.forEach(u=>{const d=u.data(),p=JSON.parse(d.items||"[]");l.push({userId:d.userId,displayName:d.userDisplayName,photoURL:d.userPhotoURL}),t&&d.userId===t.uid?o.push(...p):p.forEach(m=>{s.push({...m,_ownerId:d.userId,_ownerName:d.userDisplayName,_readOnly:!0})})}),console.log("[OpenOverlay] Real-time drawing update:",o.length,"mine,",s.length,"from others"),e({myItems:o,otherItems:s,contributors:l})},i=>{console.error("[OpenOverlay] Drawing subscription error:",i)}),console.log("[OpenOverlay] Subscribed to drawings on page:",n),is}function bi(){return W!==null}function Nl(){return ue()!==null}let os=null;async function ZE(n,e){if(!W)return console.log("[OpenOverlay] Cannot save annotation: Firestore not initialized"),!1;try{const t=_e(W,"pageAnnotations",n,"annotations",e.id),r={...e,reactions:e.reactions||[],replies:e.replies||[],updatedAt:ai()};return console.log("[OpenOverlay] Saving to Firestore:",t.path),await pn(t,r,{merge:!0}),console.log("[OpenOverlay] Annotation saved to cloud successfully"),!0}catch(t){return console.error("[OpenOverlay] Failed to save annotation:",(t==null?void 0:t.message)||t),(t==null?void 0:t.code)==="permission-denied"&&console.error("[OpenOverlay] Firestore security rules may need to be updated"),!1}}async function eI(n,e){if(!W)return!1;try{const t=_e(W,"pageAnnotations",n,"annotations",e);return await wo(t),console.log("[OpenOverlay] Annotation deleted from cloud"),!0}catch(t){return console.error("[OpenOverlay] Failed to delete annotation:",t),!1}}async function _g(n){if(!W)return[];try{const e=Ar(W,"pageAnnotations",n,"annotations"),t=await Wc(e),r=[];return t.forEach(i=>{r.push({id:i.id,...i.data()})}),r.sort((i,o)=>(o.createdAt||0)-(i.createdAt||0)),console.log("[OpenOverlay] Fetched",r.length,"annotations from cloud"),r}catch(e){return console.error("[OpenOverlay] Failed to fetch annotations:",e),[]}}function tI(n,e){if(!W)return console.log("[OpenOverlay] Cannot subscribe to annotations: Firestore not initialized"),null;os&&os();const t=Ar(W,"pageAnnotations",n,"annotations");return os=_a(t,r=>{const i=[];r.forEach(o=>{i.push({id:o.id,...o.data()})}),i.sort((o,s)=>(s.createdAt||0)-(o.createdAt||0)),console.log("[OpenOverlay] Real-time update:",i.length,"annotations"),e(i)},r=>{console.error("[OpenOverlay] Annotation subscription error:",r),_g(n).then(e)}),os}async function nI(n,e,t){if(!W)return!1;try{const r=_e(W,"pageAnnotations",n,"annotations",e),i=await Sr(r);if(!i.exists())return!1;const s=i.data().replies||[];return s.push(t),await br(r,{replies:s}),console.log("[OpenOverlay] Reply added"),!0}catch(r){return console.error("[OpenOverlay] Failed to add reply:",r),!1}}async function rI(n,e,t,r){if(!W)return!1;try{const i=_e(W,"pageAnnotations",n,"annotations",e),o=await Sr(i);if(!o.exists())return!1;let l=o.data().reactions||[];const u=l.find(d=>d.emoji===t);return u?u.users.includes(r)?(u.users=u.users.filter(d=>d!==r),u.count=u.users.length,u.count===0&&(l=l.filter(d=>d.emoji!==t))):(u.users.push(r),u.count=u.users.length):l.push({emoji:t,count:1,users:[r]}),await br(i,{reactions:l}),!0}catch(i){return console.error("[OpenOverlay] Failed to toggle reaction:",i),!1}}let sr=null,xd=0;async function iI(n,e){const t=ue();if(!W||!t){console.log("[OpenOverlay] Cannot sync position: db=",!!W,"user=",!!t);return}try{const r=_e(W,"pageGames",n,"players",t.uid);await pn(r,{...e,odlPlayerId:t.uid,displayName:t.displayName||"Player",updatedAt:Date.now()},{merge:!0})}catch(r){const i=Date.now();i-xd>1e4&&(xd=i,console.error("[OpenOverlay] Position sync error:",(r==null?void 0:r.message)||r))}}function oI(n,e){if(!W)return console.log("[OpenOverlay] Cannot subscribe to players: Firestore not initialized"),null;const t=ue();console.log("[OpenOverlay] Subscribing to players for page:",n,"currentUser:",t==null?void 0:t.uid),sr&&sr();const r=Ar(W,"pageGames",n,"players");return sr=_a(r,i=>{const o=new Map,s=Date.now(),l=3e4;i.forEach(u=>{const d=u.data(),p=s-d.updatedAt;t&&u.id===t.uid||p>l||o.set(u.id,d)}),o.size>0&&console.log("[OpenOverlay] Got",o.size,"other players from snapshot"),e(o)},i=>{console.error("[OpenOverlay] Player subscription error:",i)}),console.log("[OpenOverlay] Subscribed to players on page:",n),sr}async function wg(n){const e=ue();if(!(!W||!e))try{const t=_e(W,"pageGames",n,"players",e.uid);await wo(t),console.log("[OpenOverlay] Player removed from page")}catch(t){console.error("[OpenOverlay] Failed to remove player:",t)}}function bg(){sr&&(sr(),sr=null)}let ar=null;function sI(n,e){if(!W)return console.log("[OpenOverlay] Cannot subscribe to tag game: Firestore not initialized"),null;ar&&ar();const t=_e(W,"pageGames",n,"gameState","tag");return ar=_a(t,r=>{r.exists()?e(r.data()):e(null)},r=>{console.error("[OpenOverlay] Tag game subscription error:",r),e(null)}),console.log("[OpenOverlay] Subscribed to tag game"),ar}function aI(){ar&&(ar(),ar=null)}async function lI(n){const e=ue();if(!W||!e)return!1;try{const t=_e(W,"pageGames",n,"gameState","tag"),r=await Sr(t);if(r.exists()){const i=r.data();return console.log("[OpenOverlay] Joined existing tag game, IT is:",i.itPlayerId),i.itPlayerId===e.uid}return await pn(t,{itPlayerId:e.uid,lastTagTime:Date.now(),gameActive:!0}),console.log("[OpenOverlay] Started new tag game - you are IT!"),!0}catch(t){return console.error("[OpenOverlay] Failed to start tag game:",t),!1}}async function cI(n,e){const t=ue();if(!W||!t)return!1;try{const r=_e(W,"pageGames",n,"gameState","tag"),i=await Sr(r);return i.exists()?i.data().itPlayerId!==t.uid?(console.log("[OpenOverlay] Cannot tag - you are not IT"),!1):(await pn(r,{itPlayerId:e,lastTagTime:Date.now(),gameActive:!0}),console.log("[OpenOverlay] Tagged player:",e),!0):!1}catch(r){return console.error("[OpenOverlay] Failed to tag player:",r),!1}}async function uI(n,e){if(!W)return console.error("[OpenOverlay] Cannot submit feedback: Firestore not initialized"),!1;const t=ue();try{const r=Ar(W,"feedback"),i=_e(r);return await pn(i,{type:n,message:e,userId:(t==null?void 0:t.uid)||null,userEmail:(t==null?void 0:t.email)||null,userName:(t==null?void 0:t.displayName)||null,pageUrl:window.location.href,userAgent:navigator.userAgent,timestamp:ai()}),console.log("[OpenOverlay] Feedback submitted successfully"),!0}catch(r){return console.error("[OpenOverlay] Failed to submit feedback:",r),!1}}let tl=null,li=null,Gc=null;const Es=[];function hI(){ks().length===0?tl=Kl(Uf):tl=ks()[0],li=ww(tl),l_(li,async n=>{Gc=n,console.log("[OpenOverlay] Auth state changed:",(n==null?void 0:n.displayName)||"signed out"),n&&await WE(n),Es.forEach(e=>e(n))}),console.log("[OpenOverlay] Auth initialized")}async function dI(){if(!li)return console.error("[OpenOverlay] Auth not initialized"),null;const n=await new Promise(e=>{chrome.runtime.sendMessage({type:"GOOGLE_SIGN_IN"},e)});if(!n.success||!n.token)throw new Error(n.error||"Failed to get auth token");try{const e=Xt.credential(null,n.token),t=await o_(li,e);return console.log("[OpenOverlay] Signed in as:",t.user.displayName),t.user}catch(e){throw console.error("[OpenOverlay] Sign in error:",e),(e==null?void 0:e.code)==="auth/invalid-credential"&&await new Promise(t=>{chrome.runtime.sendMessage({type:"GOOGLE_SIGN_OUT"},()=>t())}),e}}async function fI(){li&&(await new Promise(n=>{chrome.runtime.sendMessage({type:"GOOGLE_SIGN_OUT"},()=>n())}),await c_(li),console.log("[OpenOverlay] Signed out"))}function ue(){return Gc}function Tg(n){return Es.push(n),n(Gc),()=>{const e=Es.indexOf(n);e>-1&&Es.splice(e,1)}}let je=[],Qi=null,Bi=null,ut=null,lr=null,qn=new Set;const nl=["#ffeb3b","#ff9800","#4caf50","#2196f3","#e91e63"],Kc=["👍","❤️","😂","😮","😢","😡","🔥","👀","💯","🎉"],pI=`
  .oo-annotate-btn {
    position: absolute;
    background: #22c55e;
    color: white;
    border: none;
    padding: 6px 12px;
    border-radius: 6px;
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
    box-shadow: 0 2px 8px rgba(0,0,0,0.2);
    z-index: 2147483646;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    transition: transform 0.1s;
  }

  .oo-annotate-btn:hover {
    transform: scale(1.05);
  }

  .oo-annotation-form {
    position: absolute;
    background: #1a1a1a;
    border-radius: 12px;
    padding: 16px;
    box-shadow: 0 8px 32px rgba(0,0,0,0.3);
    z-index: 2147483646;
    width: 300px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  }

  .oo-annotation-form textarea {
    width: 100%;
    height: 80px;
    background: #2a2a2a;
    border: 1px solid #333;
    border-radius: 8px;
    color: #fff;
    padding: 10px;
    font-size: 14px;
    resize: none;
    font-family: inherit;
  }

  .oo-annotation-form textarea:focus {
    outline: none;
    border-color: #22c55e;
  }

  .oo-annotation-form .colors {
    display: flex;
    gap: 6px;
    margin: 12px 0;
  }

  .oo-annotation-form .color-btn {
    width: 24px;
    height: 24px;
    border-radius: 50%;
    border: 2px solid transparent;
    cursor: pointer;
    transition: transform 0.1s;
  }

  .oo-annotation-form .color-btn:hover {
    transform: scale(1.2);
  }

  .oo-annotation-form .color-btn.active {
    border-color: #fff;
  }

  .oo-annotation-form .actions {
    display: flex;
    justify-content: flex-end;
    gap: 8px;
    margin-top: 12px;
  }

  .oo-annotation-form button {
    padding: 8px 16px;
    border: none;
    border-radius: 6px;
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
    font-family: inherit;
  }

  .oo-annotation-form .cancel-btn {
    background: #333;
    color: #fff;
  }

  .oo-annotation-form .save-btn {
    background: #22c55e;
    color: #fff;
  }

  .oo-popup {
    position: absolute;
    background: #1a1a1a;
    border-radius: 12px;
    box-shadow: 0 8px 32px rgba(0,0,0,0.4);
    z-index: 2147483646;
    max-width: 320px;
    min-width: 200px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    pointer-events: auto;
    padding: 14px;
  }

  .oo-popup .popup-quote {
    font-size: 18px;
    font-weight: 700;
    color: #fff;
    line-height: 1.3;
    margin-bottom: 8px;
  }

  .oo-popup .popup-author {
    text-align: right;
    color: #888;
    font-size: 12px;
    margin-bottom: 10px;
  }

  .oo-popup .popup-footer {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
  }

  .oo-popup .popup-reactions {
    display: flex;
    gap: 4px;
    flex-wrap: wrap;
    flex: 1;
  }

  .oo-popup .reaction {
    background: #222;
    border: 1px solid #333;
    border-radius: 12px;
    padding: 2px 6px;
    font-size: 12px;
    cursor: pointer;
    transition: background 0.1s;
    display: flex;
    align-items: center;
    gap: 2px;
  }

  .oo-popup .reaction:hover {
    background: #333;
  }

  .oo-popup .reaction .count {
    color: #888;
    font-size: 11px;
  }

  .oo-popup .reaction.active {
    background: #22c55e33;
    border-color: #22c55e;
  }

  .oo-popup .popup-actions {
    display: flex;
    gap: 6px;
    align-items: center;
  }

  .oo-popup .comment-btn {
    background: #222;
    border: 1px solid #333;
    border-radius: 12px;
    padding: 2px 8px;
    font-size: 12px;
    cursor: pointer;
    color: #888;
    display: flex;
    align-items: center;
    gap: 4px;
  }

  .oo-popup .comment-btn:hover {
    background: #333;
    color: #fff;
  }

  .oo-popup .add-reaction {
    background: #222;
    border: 1px solid #333;
    border-radius: 12px;
    padding: 2px 6px;
    font-size: 14px;
    cursor: pointer;
    color: #888;
  }

  .oo-popup .add-reaction:hover {
    background: #333;
    border-color: #22c55e;
    color: #22c55e;
  }

  .oo-popup .maximize-btn {
    background: none;
    border: none;
    color: #666;
    font-size: 14px;
    cursor: pointer;
    padding: 2px 4px;
  }

  .oo-popup .maximize-btn:hover {
    color: #fff;
  }

  .oo-popup .bookmark-btn {
    background: transparent;
    border: none;
    padding: 2px 4px;
    cursor: pointer;
    font-size: 14px;
    color: #888;
    transition: color 0.15s;
  }

  .oo-popup .bookmark-btn:hover {
    color: #fff;
  }

  .oo-popup .bookmark-btn.active {
    color: #f59e0b;
  }

  .oo-popup .delete-btn {
    background: transparent;
    border: none;
    padding: 2px 4px;
    cursor: pointer;
    font-size: 14px;
    color: #666;
    transition: color 0.15s;
  }

  .oo-popup .delete-btn:hover {
    color: #ef4444;
  }

  .oo-comment-panel .delete-btn {
    background: #ef4444;
    color: white;
    border: none;
    padding: 8px 16px;
    border-radius: 6px;
    cursor: pointer;
    font-size: 13px;
    margin-top: 12px;
  }

  .oo-comment-panel .delete-btn:hover {
    background: #dc2626;
  }

  .oo-popup .popup-reply-section {
    margin-top: 10px;
    padding-top: 10px;
    border-top: 1px solid #333;
    display: none;
  }

  .oo-popup .popup-reply-section.open {
    display: block;
  }

  .oo-popup .popup-reply-input {
    display: flex;
    gap: 6px;
  }

  .oo-popup .popup-reply-input input {
    flex: 1;
    background: #222;
    border: 1px solid #333;
    border-radius: 14px;
    padding: 6px 10px;
    color: #fff;
    font-size: 12px;
  }

  .oo-popup .popup-reply-input input:focus {
    outline: none;
    border-color: #22c55e;
  }

  .oo-popup .popup-reply-input button {
    background: #22c55e;
    border: none;
    border-radius: 50%;
    width: 26px;
    height: 26px;
    color: white;
    font-size: 12px;
    cursor: pointer;
  }

  .oo-popup .quick-emojis {
    display: flex;
    gap: 2px;
    margin-top: 8px;
  }

  .oo-popup .quick-emoji {
    background: none;
    border: none;
    font-size: 16px;
    cursor: pointer;
    padding: 2px;
    border-radius: 4px;
    opacity: 0.6;
    transition: opacity 0.1s, transform 0.1s;
  }

  .oo-popup .quick-emoji:hover {
    opacity: 1;
    transform: scale(1.2);
  }

  .oo-popup-emoji-picker {
    position: absolute;
    background: #222;
    border-radius: 10px;
    padding: 6px;
    box-shadow: 0 4px 16px rgba(0,0,0,0.4);
    display: flex;
    flex-wrap: wrap;
    gap: 2px;
    width: 180px;
    bottom: 100%;
    left: 0;
    margin-bottom: 4px;
  }

  .oo-popup-emoji-picker .emoji-btn {
    width: 28px;
    height: 28px;
    border: none;
    background: transparent;
    border-radius: 4px;
    font-size: 16px;
    cursor: pointer;
  }

  .oo-popup-emoji-picker .emoji-btn:hover {
    background: #333;
  }

  .oo-comment-panel {
    position: fixed;
    right: 0;
    top: 0;
    width: 360px;
    height: 100vh;
    background: #111;
    box-shadow: -4px 0 24px rgba(0,0,0,0.3);
    z-index: 2147483646;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    display: flex;
    flex-direction: column;
    transform: translateX(100%);
    transition: transform 0.2s ease-out;
  }

  .oo-comment-panel.open {
    transform: translateX(0);
  }

  .oo-comment-panel .header {
    padding: 16px;
    border-bottom: 1px solid #222;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .oo-comment-panel .header h3 {
    margin: 0;
    color: #fff;
    font-size: 16px;
  }

  .oo-comment-panel .close-btn {
    background: none;
    border: none;
    color: #888;
    font-size: 24px;
    cursor: pointer;
    padding: 0;
    line-height: 1;
  }

  .oo-comment-panel .highlighted-text {
    padding: 16px;
    background: #1a1a1a;
    border-bottom: 1px solid #222;
  }

  .oo-comment-panel .highlighted-text blockquote {
    margin: 0;
    padding-left: 12px;
    border-left: 3px solid #22c55e;
    color: #aaa;
    font-style: italic;
  }

  .oo-comment-panel .main-comment {
    padding: 16px;
    border-bottom: 1px solid #222;
  }

  .oo-comment-panel .author-info {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 8px;
  }

  .oo-comment-panel .avatar {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    background: #333;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #888;
    font-size: 14px;
  }

  .oo-comment-panel .author-name {
    color: #fff;
    font-weight: 600;
    font-size: 14px;
  }

  .oo-comment-panel .timestamp {
    color: #666;
    font-size: 12px;
  }

  .oo-comment-panel .comment-text {
    color: #ddd;
    font-size: 14px;
    line-height: 1.5;
  }

  .oo-comment-panel .reactions {
    display: flex;
    gap: 8px;
    margin-top: 12px;
    flex-wrap: wrap;
  }

  .oo-comment-panel .reaction {
    background: #222;
    border: 1px solid #333;
    border-radius: 16px;
    padding: 4px 10px;
    font-size: 13px;
    cursor: pointer;
    transition: background 0.1s;
  }

  .oo-comment-panel .reaction:hover {
    background: #333;
  }

  .oo-comment-panel .reaction .emoji {
    margin-right: 4px;
  }

  .oo-comment-panel .reaction .count {
    color: #888;
  }

  .oo-comment-panel .add-reaction {
    background: #1a1a1a;
    border: 1px dashed #444;
    color: #888;
    font-size: 16px;
    min-width: 36px;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .oo-comment-panel .add-reaction:hover {
    border-color: #22c55e;
    color: #22c55e;
  }

  .oo-comment-panel .reaction.active {
    background: #22c55e33;
    border-color: #22c55e;
  }

  .oo-emoji-picker {
    position: absolute;
    background: #222;
    border-radius: 12px;
    padding: 8px;
    box-shadow: 0 4px 16px rgba(0,0,0,0.4);
    display: flex;
    flex-wrap: wrap;
    gap: 4px;
    width: 200px;
    z-index: 10;
  }

  .oo-emoji-picker .emoji-btn {
    width: 32px;
    height: 32px;
    border: none;
    background: transparent;
    border-radius: 6px;
    font-size: 18px;
    cursor: pointer;
    transition: background 0.1s, transform 0.1s;
  }

  .oo-emoji-picker .emoji-btn:hover {
    background: #333;
    transform: scale(1.2);
  }

  .oo-comment-panel .replies-section {
    flex: 1;
    overflow-y: auto;
    padding: 16px;
  }

  .oo-comment-panel .reply {
    margin-bottom: 16px;
    padding-bottom: 16px;
    border-bottom: 1px solid #222;
  }

  .oo-comment-panel .reply:last-child {
    border-bottom: none;
  }

  .oo-comment-panel .reply-input {
    padding: 16px;
    border-top: 1px solid #222;
    display: flex;
    gap: 8px;
  }

  .oo-comment-panel .reply-input input {
    flex: 1;
    background: #222;
    border: 1px solid #333;
    border-radius: 20px;
    padding: 10px 16px;
    color: #fff;
    font-size: 14px;
  }

  .oo-comment-panel .reply-input input:focus {
    outline: none;
    border-color: #22c55e;
  }

  .oo-comment-panel .reply-input button {
    background: #22c55e;
    border: none;
    border-radius: 50%;
    width: 40px;
    height: 40px;
    color: white;
    font-size: 18px;
    cursor: pointer;
  }
`;function gI(){console.log("[OpenOverlay] initAnnotations starting..."),Bi=document.createElement("div"),Bi.id="openoverlay-annotations",Bi.style.cssText=`
    position: fixed;
    top: 0;
    left: 0;
    width: 0;
    height: 0;
    z-index: 2147483646;
    pointer-events: none;
  `,ut=Bi.attachShadow({mode:"open"});const n=document.createElement("style");n.textContent=pI,ut.appendChild(n),document.body.appendChild(Bi),document.addEventListener("mouseup",yI),document.addEventListener("selectionchange",mI),xI(),NI(),wa(),console.log("[OpenOverlay] Annotations initialized")}let rl=null;function mI(){rl&&clearTimeout(rl),rl=window.setTimeout(()=>{Eg()},100)}function yI(n){var e,t;(e=n.target)!=null&&e.closest("#openoverlay-annotations")||(t=n.target)!=null&&t.closest("#openoverlay-ui")||setTimeout(Eg,10)}function Eg(){const n=window.getSelection();if(!n||n.isCollapsed||!n.toString().trim()){Gs();return}if(n.toString().trim().length<3){Gs();return}const r=n.getRangeAt(0).getBoundingClientRect();vI(r,n)}function vI(n,e){if(Gs(),!ut)return;const t=document.createElement("button");t.className="oo-annotate-btn",t.textContent="+ Annotate",t.style.pointerEvents="auto",t.style.left=`${n.left+window.scrollX+n.width/2-50}px`,t.style.top=`${n.bottom+window.scrollY+8}px`,t.onclick=r=>{r.preventDefault(),r.stopPropagation(),_I(n,e)},ut.appendChild(t),Qi=t}function Gs(){Qi&&(ut!=null&&ut.contains(Qi))&&Qi.remove(),Qi=null}function _I(n,e){var u,d;if(Gs(),!ut)return;const t=e.toString().trim(),r=e.getRangeAt(0),i=e.anchorNode,o=e.focusNode,s=document.createElement("div");s.className="oo-annotation-form",s.style.pointerEvents="auto",s.style.left=`${Math.max(10,n.left+window.scrollX-50)}px`,s.style.top=`${n.bottom+window.scrollY+8}px`;let l=nl[0];s.innerHTML=`
    <textarea placeholder="Add your annotation..." autofocus></textarea>
    <div class="colors">
      ${nl.map((p,m)=>`
        <div class="color-btn ${m===0?"active":""}"
             data-color="${p}"
             style="background: ${p}"></div>
      `).join("")}
    </div>
    <div class="actions">
      <button class="cancel-btn">Cancel</button>
      <button class="save-btn">Save</button>
    </div>
  `,s.querySelectorAll(".color-btn").forEach(p=>{p.addEventListener("click",()=>{s.querySelectorAll(".color-btn").forEach(m=>m.classList.remove("active")),p.classList.add("active"),l=p.dataset.color||nl[0]})}),(u=s.querySelector(".cancel-btn"))==null||u.addEventListener("click",()=>{var p;s.remove(),(p=window.getSelection())==null||p.removeAllRanges()}),(d=s.querySelector(".save-btn"))==null||d.addEventListener("click",()=>{var A;const p=s.querySelector("textarea"),m=p.value.trim();if(!m){p.focus();return}const{contextBefore:g,contextAfter:b}=bI(r,t),O={id:wI(),text:t,contextBefore:g,contextAfter:b,anchorSelector:kd(i),anchorOffset:e.anchorOffset,focusSelector:kd(o),focusOffset:e.focusOffset,comment:m,color:l,authorId:"local-user",authorName:"You",createdAt:Date.now(),reactions:[],replies:[]};je.push(O),At(),wa(),SI(O),s.remove(),(A=window.getSelection())==null||A.removeAllRanges(),console.log("[OpenOverlay] Annotation created:",O.id)}),ut.appendChild(s),setTimeout(()=>{var p;(p=s.querySelector("textarea"))==null||p.focus()},10)}function kd(n){if(!n)return"body";const e=n.nodeType===Node.TEXT_NODE?n.parentElement:n;if(!e)return"body";const t=[];let r=e;for(;r&&r!==document.body&&r!==document.documentElement;){let i=r.tagName.toLowerCase();if(r.id){t.unshift(`#${CSS.escape(r.id)}`);break}const o=r.parentElement;if(o){const l=Array.from(o.children).indexOf(r)+1;i+=`:nth-child(${l})`}t.unshift(i),r=r.parentElement}return t.join(" > ")||"body"}function wI(){return Math.random().toString(36).substr(2,9)}function bI(n,e){var r;try{const i=n.commonAncestorContainer,o=i.nodeType===Node.TEXT_NODE?i.parentElement:i;if(!o)return{contextBefore:"",contextAfter:""};const s=o.textContent||"",l=((r=n.startContainer.textContent)==null?void 0:r.substring(0,n.startOffset))||"";let u="";const d=document.createTreeWalker(o,NodeFilter.SHOW_TEXT,null);let p;for(;p=d.nextNode();){if(p===n.startContainer){u+=l;break}u+=p.textContent||""}const m=u.slice(-30),g=u.length+e.length,b=s.substring(g,g+30);return{contextBefore:m,contextAfter:b}}catch(i){return console.warn("[OpenOverlay] Failed to get selection context:",i),{contextBefore:"",contextAfter:""}}}function Yc(){document.querySelectorAll(".oo-highlight").forEach(n=>{const e=n.parentNode;e&&(e.replaceChild(document.createTextNode(n.textContent||""),n),e.normalize())})}function wa(){Yc();for(const n of je)try{TI(n)}catch(e){console.warn("[OpenOverlay] Failed to highlight annotation:",n.id,e)}}function TI(n){(n.contextBefore||"")+n.text+(n.contextAfter||"");const e=n.text,t=[],r=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,null);let i="",o;for(;o=r.nextNode();){const d=o.textContent||"";t.push({node:o,start:i.length,end:i.length+d.length}),i+=d}let s=-1;if(n.contextBefore||n.contextAfter){const d=n.contextBefore||"",p=n.contextAfter||"";let m=0;for(;m<i.length;){const g=i.indexOf(e,m);if(g===-1)break;const b=d===""||i.substring(Math.max(0,g-d.length),g).endsWith(d),O=p===""||i.substring(g+e.length,g+e.length+p.length).startsWith(p);if(b&&O){s=g;break}m=g+1}}if(s===-1&&(s=i.indexOf(e)),s===-1)return;let l=null,u=0;for(const d of t)if(s>=d.start&&s<d.end){l=d.node,u=s-d.start;break}if(l)try{const d=document.createRange();d.setStart(l,u),d.setEnd(l,u+e.length);const p=document.createElement("span");p.className="oo-highlight",p.dataset.annotationId=n.id,p.style.cssText=`
      background: ${n.color}40;
      border-bottom: 2px solid ${n.color};
      cursor: pointer;
      transition: background 0.15s;
    `,p.addEventListener("mouseenter",m=>{p.style.background=`${n.color}60`,Dl(n,m,p)}),p.addEventListener("mouseleave",m=>{p.style.background=`${n.color}40`,Ig()}),d.surroundContents(p)}catch(d){console.warn("[OpenOverlay] Failed to highlight annotation:",n.id,d)}}let fr=null,Dt=null,zr=null,Wr=!1;function Ig(){Wr||(zr&&clearTimeout(zr),zr=window.setTimeout(()=>{Pn()},150))}function Ji(){zr&&(clearTimeout(zr),zr=null)}function Dl(n,e,t){var A,P,V,$;if(zt)return;if(fr&&(Dt==null?void 0:Dt.id)===n.id){Ji();return}if(Ji(),Pn(),Wr=!1,!ut)return;Dt=n;const r=document.createElement("div");r.className="oo-popup";let i=e.pageX-100,o=e.pageY+15;i<10&&(i=10),i+320>window.innerWidth&&(i=window.innerWidth-330),r.style.left=`${i}px`,r.style.top=`${o}px`;const s=n.reactions.filter(U=>U.count>0),l=n.replies.length,u=ue(),d=u?n.authorId===u.uid:n.authorId==="local-user";r.innerHTML=`
    <div class="popup-quote">"${bt(n.comment)}"</div>
    <div class="popup-author">— ${bt(n.authorName)}</div>
    <div class="popup-footer">
      <div class="popup-reactions" id="popup-reactions">
        ${s.map(U=>`
          <div class="reaction ${U.userReacted?"active":""}" data-emoji="${U.emoji}">
            <span class="emoji">${U.emoji}</span>
            <span class="count">${U.count}</span>
          </div>
        `).join("")}
      </div>
      <div class="popup-actions">
        <button class="comment-btn" id="popup-comment-btn" title="Comments">
          💬 ${l>0?l:""}
        </button>
        <button class="add-reaction" id="popup-add-reaction" title="React">+</button>
        <button class="bookmark-btn ${qn.has(n.id)?"active":""}" id="popup-bookmark-btn" title="Bookmark">🔖</button>
        <button class="maximize-btn" title="Open in sidebar">⛶</button>
        ${d?'<button class="delete-btn" id="popup-delete-btn" title="Delete annotation">🗑️</button>':""}
      </div>
    </div>
    <div class="popup-reply-section" id="popup-reply-section">
      <div class="popup-reply-input">
        <input type="text" placeholder="Add a comment..." />
        <button>➤</button>
      </div>
      <div class="quick-emojis">
        ${Kc.slice(0,6).map(U=>`
          <button class="quick-emoji" data-emoji="${U}">${U}</button>
        `).join("")}
      </div>
    </div>
  `,r.addEventListener("mouseenter",()=>{Ji()}),r.addEventListener("mouseleave",()=>{Ig()}),r.addEventListener("click",U=>{U.stopPropagation(),Wr=!0,Ji()}),(A=r.querySelector(".maximize-btn"))==null||A.addEventListener("click",U=>{U.stopPropagation(),Wr=!1,Pn(),AI(n)}),(P=r.querySelector("#popup-bookmark-btn"))==null||P.addEventListener("click",U=>{U.stopPropagation(),RI(n.id);const G=r.querySelector("#popup-bookmark-btn");G==null||G.classList.toggle("active",qn.has(n.id))}),(V=r.querySelector("#popup-delete-btn"))==null||V.addEventListener("click",U=>{U.stopPropagation(),confirm("Delete this annotation and all its comments?")&&(Ng(n.id),Pn())});const p=r.querySelector("#popup-comment-btn"),m=r.querySelector("#popup-reply-section");p==null||p.addEventListener("click",U=>{if(U.stopPropagation(),m==null||m.classList.toggle("open"),m!=null&&m.classList.contains("open")){const G=r.querySelector(".popup-reply-input input");G==null||G.focus()}}),r.querySelectorAll(".reaction").forEach(U=>{U.addEventListener("click",G=>{G.stopPropagation();const z=U.dataset.emoji;if(!z)return;const J=n.reactions.find(E=>E.emoji===z);J&&(J.userReacted?(J.count--,J.userReacted=!1,J.count<=0&&(n.reactions=n.reactions.filter(E=>E.emoji!==z))):(J.count++,J.userReacted=!0),At(),Tr(n,z),Pn(),Dl(n,G))})}),($=r.querySelector("#popup-add-reaction"))==null||$.addEventListener("click",U=>{U.stopPropagation();const G=r.querySelector("#popup-reactions");Sg(r,n,G)}),r.querySelectorAll(".quick-emoji").forEach(U=>{U.addEventListener("click",G=>{G.stopPropagation();const z=U.dataset.emoji;if(!z)return;let J=n.reactions.find(E=>E.emoji===z);J?J.userReacted||(J.count++,J.userReacted=!0):n.reactions.push({emoji:z,count:1,userReacted:!0}),At(),Tr(n,z),Pn(),Dl(n,G)})});const g=r.querySelector(".popup-reply-input input"),b=r.querySelector(".popup-reply-input button"),O=()=>{const U=g.value.trim();if(!U)return;const G=ue(),z={authorName:(G==null?void 0:G.displayName)||"You",text:U,createdAt:Date.now()};n.replies.push(z),At(),Og(n,z),g.value="";const J=r.querySelector("#popup-comment-btn");J&&(J.innerHTML=`💬 ${n.replies.length}`)};b==null||b.addEventListener("click",U=>{U.stopPropagation(),O()}),g==null||g.addEventListener("keypress",U=>{U.key==="Enter"&&(U.stopPropagation(),O())}),ut.appendChild(r),fr=r,setTimeout(()=>{document.addEventListener("click",kg)},10)}function EI(n){return`
    ${n.reactions.map(e=>`
      <div class="reaction ${e.userReacted?"active":""}" data-emoji="${e.emoji}">
        <span class="emoji">${e.emoji}</span>
        <span class="count">${e.count}</span>
      </div>
    `).join("")}
    <div class="reaction add-reaction" id="popup-add-reaction">😀+</div>
  `}function II(n,e){var r;const t=n.querySelector("#popup-reactions");t&&(t.querySelectorAll(".reaction:not(.add-reaction)").forEach(i=>{i.addEventListener("click",o=>{o.stopPropagation();const s=i.dataset.emoji;if(!s)return;const l=e.reactions.find(u=>u.emoji===s);l&&(l.userReacted?(l.count--,l.userReacted=!1,l.count<=0&&(e.reactions=e.reactions.filter(u=>u.emoji!==s))):(l.count++,l.userReacted=!0),At(),Tr(e,s),Ag(n,e))})}),(r=t.querySelector("#popup-add-reaction"))==null||r.addEventListener("click",i=>{i.stopPropagation(),Sg(n,e,t)}))}function Ag(n,e){const t=n.querySelector("#popup-reactions");t&&(t.innerHTML=EI(e),II(n,e))}let Hr=null;function Sg(n,e,t){Ks();const r=document.createElement("div");r.className="oo-popup-emoji-picker",r.innerHTML=Kc.map(i=>`
    <button class="emoji-btn" data-emoji="${i}">${i}</button>
  `).join(""),r.querySelectorAll(".emoji-btn").forEach(i=>{i.addEventListener("click",o=>{o.stopPropagation();const s=i.dataset.emoji;if(!s)return;let l=e.reactions.find(u=>u.emoji===s);l?l.userReacted||(l.count++,l.userReacted=!0):e.reactions.push({emoji:s,count:1,userReacted:!0}),At(),Tr(e,s),Ag(n,e),Ks()})}),t.appendChild(r),Hr=r,setTimeout(()=>{document.addEventListener("click",xg)},10)}function xg(n){Hr&&!Hr.contains(n.target)&&Ks()}function Ks(){document.removeEventListener("click",xg),Hr&&(Hr.remove(),Hr=null)}function kg(n){Wr&&fr&&!fr.contains(n.target)&&Pn()}function Pn(){Ji(),document.removeEventListener("click",kg),Ks(),fr&&(fr.remove(),fr=null),Dt=null,Wr=!1}let zt=null;function AI(n){var d,p,m;if(Pn(),Is(),!ut)return;const e=document.createElement("div");e.className="oo-comment-panel open",e.style.pointerEvents="auto";const t=Ml(n.createdAt),r=ue(),i=r?n.authorId===r.uid:n.authorId==="local-user";e.innerHTML=`
    <div class="header">
      <h3>Annotation</h3>
      <button class="close-btn">&times;</button>
    </div>
    <div class="highlighted-text">
      <blockquote>"${bt(n.text)}"</blockquote>
    </div>
    <div class="main-comment">
      <div class="author-info">
        <div class="avatar">${n.authorName.charAt(0).toUpperCase()}</div>
        <div>
          <div class="author-name">${bt(n.authorName)}</div>
          <div class="timestamp">${t}</div>
        </div>
      </div>
      <div class="comment-text">${bt(n.comment)}</div>
      <div class="reactions" id="reactions-container">
        ${n.reactions.map(g=>`
          <div class="reaction ${g.userReacted?"active":""}" data-emoji="${g.emoji}">
            <span class="emoji">${g.emoji}</span>
            <span class="count">${g.count}</span>
          </div>
        `).join("")}
        <div class="reaction add-reaction" id="add-reaction-btn">😀+</div>
      </div>
      ${i?'<button class="delete-btn" id="panel-delete-btn">🗑️ Delete Annotation</button>':""}
    </div>
    <div class="replies-section">
      ${n.replies.map(g=>`
        <div class="reply">
          <div class="author-info">
            <div class="avatar">${g.authorName.charAt(0).toUpperCase()}</div>
            <div>
              <div class="author-name">${bt(g.authorName)}</div>
              <div class="timestamp">${Ml(g.createdAt)}</div>
            </div>
          </div>
          <div class="comment-text">${bt(g.text)}</div>
        </div>
      `).join("")}
    </div>
    <div class="reply-input">
      <input type="text" placeholder="Add a reply..." />
      <button>➤</button>
    </div>
  `,e.addEventListener("click",g=>{g.stopPropagation()}),(d=e.querySelector(".close-btn"))==null||d.addEventListener("click",g=>{g.stopPropagation(),Is()}),(p=e.querySelector("#panel-delete-btn"))==null||p.addEventListener("click",g=>{g.stopPropagation(),confirm("Delete this annotation and all its comments?")&&(Ng(n.id),Is())});const o=e.querySelector(".reply-input input"),s=e.querySelector(".reply-input button"),l=()=>{const g=o.value.trim();if(!g)return;const b=ue(),O=(b==null?void 0:b.displayName)||"You",A={authorName:O,text:g,createdAt:Date.now()};n.replies.push(A),At(),Og(n,A);const P=e.querySelector(".replies-section");if(P){const V=`
        <div class="reply">
          <div class="author-info">
            <div class="avatar">${O.charAt(0).toUpperCase()}</div>
            <div>
              <div class="author-name">${bt(O)}</div>
              <div class="timestamp">just now</div>
            </div>
          </div>
          <div class="comment-text">${bt(g)}</div>
        </div>
      `;P.insertAdjacentHTML("beforeend",V)}o.value="",o.focus()};s==null||s.addEventListener("click",g=>{g.stopPropagation(),l()}),o==null||o.addEventListener("keypress",g=>{g.key==="Enter"&&(g.stopPropagation(),l())});const u=e.querySelector("#reactions-container");e.querySelectorAll(".reaction:not(.add-reaction)").forEach(g=>{g.addEventListener("click",b=>{b.stopPropagation();const O=g.dataset.emoji;if(!O)return;const A=n.reactions.find(P=>P.emoji===O);A&&(A.userReacted?(A.count--,A.userReacted=!1,A.count<=0&&(n.reactions=n.reactions.filter(P=>P.emoji!==O))):(A.count++,A.userReacted=!0),At(),Tr(n,O),Qc(n,u))})}),(m=e.querySelector("#add-reaction-btn"))==null||m.addEventListener("click",g=>{g.stopPropagation(),Pg(n,g.target,u)}),ut.appendChild(e),zt=e,lr=n,setTimeout(()=>o==null?void 0:o.focus(),100),setTimeout(()=>{document.addEventListener("click",Rg)},50)}let Gr=null;function Pg(n,e,t){Ll();const r=document.createElement("div");r.className="oo-emoji-picker",e.getBoundingClientRect(),r.style.bottom="40px",r.style.left="0",r.innerHTML=Kc.map(i=>`
    <button class="emoji-btn" data-emoji="${i}">${i}</button>
  `).join(""),r.querySelectorAll(".emoji-btn").forEach(i=>{i.addEventListener("click",o=>{o.stopPropagation();const s=i.dataset.emoji;if(!s)return;let l=n.reactions.find(u=>u.emoji===s);l?l.userReacted||(l.count++,l.userReacted=!0):n.reactions.push({emoji:s,count:1,userReacted:!0}),At(),Tr(n,s),Qc(n,t),Ll()})}),t.style.position="relative",t.appendChild(r),Gr=r,setTimeout(()=>{document.addEventListener("click",Cg)},10)}function Cg(n){Gr&&!Gr.contains(n.target)&&Ll()}function Ll(){document.removeEventListener("click",Cg),Gr&&(Gr.remove(),Gr=null)}function Qc(n,e){var t;e&&(e.innerHTML=`
    ${n.reactions.map(r=>`
      <div class="reaction ${r.userReacted?"active":""}" data-emoji="${r.emoji}">
        <span class="emoji">${r.emoji}</span>
        <span class="count">${r.count}</span>
      </div>
    `).join("")}
    <div class="reaction add-reaction" id="add-reaction-btn">😀+</div>
  `,e.querySelectorAll(".reaction:not(.add-reaction)").forEach(r=>{r.addEventListener("click",i=>{i.stopPropagation();const o=r.dataset.emoji;if(!o)return;const s=n.reactions.find(l=>l.emoji===o);s&&(s.userReacted?(s.count--,s.userReacted=!1,s.count<=0&&(n.reactions=n.reactions.filter(l=>l.emoji!==o))):(s.count++,s.userReacted=!0),At(),Tr(n,o),Qc(n,e))})}),(t=e.querySelector("#add-reaction-btn"))==null||t.addEventListener("click",r=>{r.stopPropagation(),Pg(n,r.target,e)}))}function Rg(n){zt&&!zt.contains(n.target)&&Is()}function Is(){document.removeEventListener("click",Rg),zt&&(zt.remove(),zt=null),lr=null}function bt(n){const e=document.createElement("div");return e.textContent=n,e.innerHTML}function Ml(n){const e=Math.floor((Date.now()-n)/1e3);return e<60?"just now":e<3600?`${Math.floor(e/60)}m ago`:e<86400?`${Math.floor(e/3600)}h ago`:e<604800?`${Math.floor(e/86400)}d ago`:new Date(n).toLocaleDateString()}function At(){const n=Jn();localStorage.setItem(`oo_annotations_${n}`,JSON.stringify(je)),console.log("[OpenOverlay] Saved",je.length,"annotations locally")}async function SI(n){if(!bi()){console.log("[OpenOverlay] Firestore not available, skipping cloud save");return}const e=ue(),t=Jn();console.log("[OpenOverlay] Saving annotation to cloud:",n.id,"pageKey:",t);const r={id:n.id,pageKey:t,text:n.text,contextBefore:n.contextBefore||"",contextAfter:n.contextAfter||"",anchorSelector:n.anchorSelector,anchorOffset:n.anchorOffset,focusSelector:n.focusSelector,focusOffset:n.focusOffset,comment:n.comment,color:n.color,authorId:(e==null?void 0:e.uid)||n.authorId,authorName:(e==null?void 0:e.displayName)||n.authorName,createdAt:n.createdAt,reactions:n.reactions.map(i=>({emoji:i.emoji,count:i.count,users:i.userReacted&&e?[e.uid]:[]})),replies:n.replies.map(i=>({authorId:"",authorName:i.authorName,text:i.text,createdAt:i.createdAt}))};await ZE(t,r)}async function Tr(n,e){if(!bi())return;const t=ue();if(!t)return;const r=Jn();await rI(r,n.id,e,t.uid)}async function Og(n,e){if(!bi())return;const t=ue(),r=Jn();await nI(r,n.id,{authorId:(t==null?void 0:t.uid)||"",authorName:(t==null?void 0:t.displayName)||e.authorName,text:e.text,createdAt:e.createdAt})}function xI(){const n=Jn(),e=localStorage.getItem(`oo_annotations_${n}`);if(e)try{je=JSON.parse(e),console.log("[OpenOverlay] Loaded",je.length,"annotations from localStorage")}catch{console.warn("[OpenOverlay] Failed to load annotations"),je=[]}kI()}async function kI(){if(!bi()){console.log("[OpenOverlay] Firestore not available, skipping real-time sync");return}const n=Jn();if(console.log("[OpenOverlay] Setting up real-time sync for page:",n),!tI(n,t=>{Pd(t)})){console.log("[OpenOverlay] Real-time subscription failed, trying one-time fetch");const t=await _g(n);Pd(t)}}function Pd(n){const e=ue();if(console.log("[OpenOverlay] Processing",n.length,"cloud annotations"),n.length===0){console.log("[OpenOverlay] No cloud annotations found");return}const t=new Map;for(const i of je)t.set(i.id,i);for(const i of n){const o=t.get(i.id),s={id:i.id,text:i.text,contextBefore:i.contextBefore||"",contextAfter:i.contextAfter||"",anchorSelector:i.anchorSelector,anchorOffset:i.anchorOffset,focusSelector:i.focusSelector,focusOffset:i.focusOffset,comment:i.comment,color:i.color,authorId:i.authorId,authorName:i.authorName,createdAt:i.createdAt,reactions:(i.reactions||[]).map(l=>({emoji:l.emoji,count:l.count,userReacted:e?l.users.includes(e.uid):!1})),replies:(i.replies||[]).map(l=>({authorName:l.authorName,text:l.text,createdAt:l.createdAt}))};(!o||i.createdAt>=o.createdAt)&&t.set(i.id,s)}je=Array.from(t.values()),console.log("[OpenOverlay] Merged to",je.length,"total annotations");const r=Jn();localStorage.setItem(`oo_annotations_${r}`,JSON.stringify(je)),Yc(),wa(),PI()}function PI(){if(Dt){const n=je.find(e=>e.id===(Dt==null?void 0:Dt.id));n&&(Dt=n)}if(zt&&lr){const n=je.find(e=>e.id===(lr==null?void 0:lr.id));n&&CI(n)}}function CI(n){if(!zt||!ut)return;const e=zt.querySelector(".replies-section");e&&(e.innerHTML=n.replies.map(t=>`
    <div class="reply">
      <div class="author-info">
        <div class="avatar">${t.authorName.charAt(0).toUpperCase()}</div>
        <div>
          <div class="author-name">${bt(t.authorName)}</div>
          <div class="timestamp">${Ml(t.createdAt)}</div>
        </div>
      </div>
      <div class="comment-text">${bt(t.text)}</div>
    </div>
  `).join(""),lr=n,console.log("[OpenOverlay] Comment panel refreshed with",n.replies.length,"replies"))}async function Ng(n){const e=je.find(i=>i.id===n);if(!e)return;const t=ue();if(!(t?e.authorId===t.uid:e.authorId==="local-user")){console.warn("[OpenOverlay] Cannot delete: not the author");return}if(je=je.filter(i=>i.id!==n),At(),bi()){const i=Jn();await eI(i,n)}qn.has(n)&&(qn.delete(n),Dg(n)),Yc(),wa(),console.log("[OpenOverlay] Annotation deleted:",n)}function RI(n){if(qn.has(n))qn.delete(n),Dg(n),console.log("[OpenOverlay] Removed bookmark");else{qn.add(n);const e=je.find(t=>t.id===n);e&&(OI(e),console.log("[OpenOverlay] Added bookmark"))}}function OI(n){const e=ba();e.some(t=>t.id===n.id)||(e.push({id:n.id,pageUrl:window.location.href,pageTitle:document.title,text:n.text,comment:n.comment,authorName:n.authorName,bookmarkedAt:Date.now()}),localStorage.setItem("oo_bookmarks",JSON.stringify(e)))}function Dg(n){const e=ba().filter(t=>t.id!==n);localStorage.setItem("oo_bookmarks",JSON.stringify(e))}function ba(){try{return JSON.parse(localStorage.getItem("oo_bookmarks")||"[]")}catch{return[]}}function NI(){const n=ba();qn=new Set(n.map(e=>e.id))}function Jn(){return btoa(window.location.href).slice(0,32)}let ji=null,C=null,ss=!1,Zt="none",Lg="solid",Mg="normal",Vg="none",Xi=!1,Kr=!1,De="normal",Ta="",Ys="play",Cd="spawn",Vl=!1,Vt=!1;const DI=["#ff3366","#ff6b35","#f59e0b","#22c55e","#06b6d4","#3b82f6","#8b5cf6","#ec4899","#ef4444","#000000","#ffffff","#6b7280"],LI=[{id:"solid",label:"━",title:"Solid"},{id:"spray",label:"░",title:"Spray"},{id:"dots",label:"•••",title:"Dots"},{id:"square",label:"▬",title:"Square"},{id:"rainbow",label:"🌈",title:"Rainbow"},{id:"glow",label:"✦",title:"Glow"}],MI=[{id:"normal",label:"A",title:"Normal"},{id:"rainbow",label:"🌈",title:"Rainbow"},{id:"aged",label:"🏚️",title:"Aged"}],VI=[{id:"none",label:"✏️",title:"Freehand"},{id:"line",label:"╱",title:"Line"},{id:"rectangle",label:"▢",title:"Rectangle"},{id:"circle",label:"○",title:"Circle"},{id:"triangle",label:"△",title:"Triangle"},{id:"star",label:"☆",title:"Star"}],FI=`
  * {
    box-sizing: border-box;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  }

  .fab-container {
    position: fixed;
    right: 18px;
    bottom: 18px;
    z-index: 2147483647;
    display: flex;
    flex-direction: column-reverse;
    align-items: center;
    gap: 8px;
    pointer-events: auto;
    touch-action: none;
  }

  .fab-container.dragging {
    opacity: 0.8;
  }

  .fab-container.dragging .fab {
    cursor: grabbing;
  }

  .fab {
    width: 56px;
    height: 56px;
    border-radius: 50%;
    border: none;
    background: rgba(255, 255, 255, 0.95);
    color: #222;
    font-size: 20px;
    cursor: pointer;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    transition: transform 0.15s, background 0.15s;
  }

  .fab:hover {
    transform: scale(1.05);
  }

  .fab.open {
    background: #22c55e;
    color: white;
  }

  .mini {
    width: 44px;
    height: 44px;
    border-radius: 50%;
    border: none;
    background: #fff;
    color: #222;
    font-size: 18px;
    cursor: pointer;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.12);
    transition: transform 0.15s, opacity 0.15s;
    opacity: 0;
    transform: scale(0.5);
    pointer-events: none;
  }

  .mini.show {
    opacity: 1;
    transform: scale(1);
    pointer-events: auto;
  }

  .mini:hover {
    transform: scale(1.1);
  }

  .mini.active {
    background: #22c55e;
    color: white;
  }

  .toolbar {
    position: fixed;
    right: 90px;
    bottom: 18px;
    background: #111;
    color: #fff;
    padding: 10px;
    border-radius: 10px;
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.3);
    display: none;
    flex-direction: column;
    gap: 8px;
    align-items: stretch;
    pointer-events: auto;
    z-index: 2147483647;
    max-width: 320px;
  }

  .toolbar.game-mode {
    flex-direction: column;
    align-items: stretch;
  }

  .toolbar-drag-handle {
    cursor: grab;
    padding: 2px 8px;
    color: #666;
    font-size: 12px;
    user-select: none;
    text-align: center;
  }

  .toolbar-drag-handle:hover {
    color: #999;
  }

  .toolbar-drag-handle:active {
    cursor: grabbing;
  }

  .toolbar.game-mode .toolbar-drag-handle {
    align-self: center;
    margin-bottom: -4px;
  }

  .toolbar.show {
    display: flex;
  }

  .toolbar-row {
    display: flex;
    align-items: center;
    gap: 6px;
    flex-wrap: wrap;
  }

  .toolbar-section {
    display: flex;
    align-items: center;
    gap: 4px;
  }

  .toolbar-divider {
    display: none;
  }

  .toolbar label {
    font-size: 11px;
    color: #888;
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }

  .toolbar input[type="color"] {
    width: 24px;
    height: 24px;
    border: 2px solid #333;
    border-radius: 50%;
    cursor: pointer;
    padding: 0;
    background: none;
    flex-shrink: 0;
  }

  .toolbar input[type="color"]::-webkit-color-swatch-wrapper {
    padding: 0;
  }

  .toolbar input[type="color"]::-webkit-color-swatch {
    border: none;
    border-radius: 50%;
  }

  .toolbar input[type="range"] {
    height: 6px;
    -webkit-appearance: none;
    background: #333;
    border-radius: 3px;
  }

  .toolbar input[type="range"]::-webkit-slider-thumb {
    -webkit-appearance: none;
    width: 18px;
    height: 18px;
    background: #fff;
    border-radius: 50%;
    cursor: pointer;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
  }

  .quick-colors {
    display: grid;
    grid-template-columns: repeat(4, 14px);
    gap: 2px;
  }

  .quick-color {
    width: 14px;
    height: 14px;
    border-radius: 50%;
    border: 2px solid transparent;
    cursor: pointer;
    transition: transform 0.1s;
  }

  .quick-color:hover {
    transform: scale(1.15);
  }

  .quick-color.active {
    border-color: #fff;
    box-shadow: 0 0 0 1px #000;
  }

  .quick-color[data-color="#ffffff"] {
    border-color: #ccc;
  }

  .quick-color[data-color="#000000"] {
    border-color: #333;
  }

  .toolbar.game-mode .quick-colors {
    grid-template-columns: repeat(4, 14px);
  }

  .brush-styles {
    display: flex;
    gap: 2px;
  }

  .brush-btn {
    width: 28px;
    height: 28px;
    border: none;
    background: #222;
    color: #aaa;
    border-radius: 6px;
    cursor: pointer;
    font-size: 14px;
    transition: background 0.1s;
  }

  .brush-btn:hover {
    background: #333;
  }

  .brush-btn.active {
    background: #22c55e;
    color: white;
  }

  .tool-btn {
    width: 32px;
    height: 32px;
    border: none;
    background: #222;
    color: #aaa;
    border-radius: 8px;
    cursor: pointer;
    font-size: 16px;
    transition: background 0.1s;
  }

  .tool-btn:hover {
    background: #333;
  }

  .tool-btn.active {
    background: #ef4444;
    color: white;
  }

  .shape-tools {
    display: flex;
    gap: 2px;
  }

  .shape-btn {
    width: 28px;
    height: 28px;
    border: none;
    background: #222;
    color: #aaa;
    border-radius: 6px;
    cursor: pointer;
    font-size: 14px;
    transition: background 0.1s;
  }

  .shape-btn:hover {
    background: #333;
  }

  .shape-btn.active {
    background: #8b5cf6;
    color: white;
  }

  .fill-btn {
    width: 28px;
    height: 28px;
    border: none;
    background: #222;
    color: #aaa;
    border-radius: 6px;
    cursor: pointer;
    font-size: 16px;
    margin-left: 4px;
  }

  .fill-btn:hover {
    background: #333;
  }

  .fill-btn.active {
    background: #f59e0b;
    color: white;
  }

  .toolbar button.action-btn {
    padding: 5px 10px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 11px;
    font-weight: 600;
    transition: background 0.1s;
  }

  .btn-undo {
    background: #333;
    color: #fff;
  }

  .btn-undo:hover {
    background: #444;
  }

  .btn-clear {
    background: #333;
    color: #fff;
  }

  .btn-clear:hover {
    background: #444;
  }

  .btn-save {
    background: #22c55e;
    color: white;
  }

  .btn-save:hover {
    background: #16a34a;
  }

  .btn-cancel {
    background: #333;
    color: white;
  }

  .btn-cancel:hover {
    background: #444;
  }

  .size-display {
    font-size: 11px;
    color: #888;
    min-width: 20px;
    text-align: center;
  }

  .opacity-display {
    font-size: 11px;
    color: #888;
    min-width: 28px;
    text-align: center;
  }

  .draw-controls, .text-controls {
    display: none;
    flex-direction: column;
    gap: 6px;
  }

  .draw-controls.active, .text-controls.active {
    display: flex;
  }

  .text-input {
    background: #222;
    border: 1px solid #333;
    border-radius: 6px;
    color: #fff;
    padding: 6px 10px;
    font-size: 13px;
    flex: 1;
    min-width: 100px;
    font-family: inherit;
  }

  .text-input:focus {
    outline: none;
    border-color: #22c55e;
  }

  .text-input::placeholder {
    color: #666;
  }

  .text-styles {
    display: flex;
    gap: 2px;
  }

  .text-style-btn {
    width: 32px;
    height: 32px;
    border: none;
    background: #222;
    color: #aaa;
    border-radius: 6px;
    cursor: pointer;
    font-size: 14px;
    transition: background 0.1s;
  }

  .text-style-btn:hover {
    background: #333;
  }

  .text-style-btn.active {
    background: #22c55e;
    color: white;
  }

  .place-hint {
    font-size: 11px;
    color: #666;
    font-style: italic;
  }

  .game-controls {
    display: none;
    flex-direction: column;
    gap: 8px;
  }

  .game-controls.active {
    display: flex;
  }

  .game-row {
    display: flex;
    align-items: center;
    gap: 6px;
    justify-content: center;
  }

  .game-actions {
    display: flex;
    gap: 4px;
    margin-left: auto;
  }

  .game-colors {
    display: flex;
    gap: 3px;
  }

  .toolbar.game-mode .drawing-only {
    display: none !important;
  }

  .toolbar.game-mode > .toolbar-row,
  .toolbar.game-mode > .toolbar-section,
  .toolbar.game-mode > .toolbar-divider {
    display: none !important;
  }

  .toolbar.game-mode > .toolbar-drag-handle,
  .toolbar.game-mode > .game-controls {
    display: flex !important;
  }

  .char-style-toggle {
    display: flex;
    background: #222;
    border-radius: 4px;
    padding: 2px;
  }

  .char-style-btn {
    padding: 3px 6px;
    border: none;
    background: transparent;
    border-radius: 3px;
    cursor: pointer;
    font-size: 14px;
    transition: background 0.1s;
  }

  .char-style-btn:hover {
    background: #333;
  }

  .char-style-btn.active {
    background: #22c55e;
  }

  .char-customize-select {
    background: #222;
    color: #fff;
    border: 1px solid #333;
    border-radius: 4px;
    padding: 3px 4px;
    font-size: 14px;
    cursor: pointer;
    min-width: 36px;
    text-align: center;
  }

  .char-customize-select:hover {
    border-color: #555;
  }

  .char-customize-select:focus {
    outline: none;
    border-color: #22c55e;
  }

  .game-mode-toggle {
    display: flex;
    background: #222;
    border-radius: 6px;
    padding: 2px;
  }

  .game-mode-btn {
    padding: 4px 8px;
    border: none;
    background: transparent;
    color: #888;
    border-radius: 4px;
    cursor: pointer;
    font-size: 14px;
    transition: background 0.1s, color 0.1s;
  }

  .game-mode-btn:hover {
    color: #fff;
  }

  .game-mode-btn.active {
    background: #22c55e;
    color: white;
  }

  .build-tools-section {
    display: flex;
    align-items: center;
  }

  .game-tools {
    display: flex;
    gap: 2px;
  }

  .game-tool-btn {
    width: 28px;
    height: 28px;
    padding: 0;
    border: none;
    background: #222;
    color: #aaa;
    border-radius: 4px;
    cursor: pointer;
    font-size: 13px;
    transition: background 0.1s;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .game-tool-btn:hover {
    background: #333;
  }

  .game-tool-btn.active {
    background: #3b82f6;
    color: white;
  }

  .multiplayer-btn {
    padding: 4px 8px;
    border: none;
    background: #7c3aed;
    color: #fff;
    border-radius: 4px;
    cursor: pointer;
    font-size: 11px;
    font-weight: 600;
    transition: background 0.1s;
  }

  .multiplayer-btn:hover {
    background: #6d28d9;
  }

  .multiplayer-btn.active {
    background: #22c55e;
  }

  .mini.game-btn {
    background: #8b5cf6;
    color: white;
  }

  .mini.game-btn.active {
    background: #22c55e;
  }

  /* Profile button */
  .mini.profile-btn {
    padding: 0;
    overflow: hidden;
  }

  .mini.profile-btn img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    border-radius: 50%;
  }

  /* Profile modal */
  .profile-modal {
    position: fixed;
    bottom: 80px;
    right: 20px;
    width: 320px;
    max-height: calc(100vh - 100px);
    background: #111;
    border-radius: 16px;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
    display: none;
    flex-direction: column;
    overflow-y: auto;
    z-index: 2147483647;
    pointer-events: auto;
  }

  .profile-modal.show {
    display: flex;
  }

  .profile-close {
    position: absolute;
    top: 10px;
    right: 10px;
    width: 28px;
    height: 28px;
    border: none;
    background: #333;
    color: #fff;
    border-radius: 50%;
    font-size: 18px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 10;
  }

  .profile-close:hover {
    background: #444;
  }

  .profile-header {
    padding: 20px;
    display: flex;
    align-items: center;
    gap: 16px;
    border-bottom: 1px solid #333;
  }

  .profile-avatar {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    object-fit: cover;
    border: 2px solid #3b82f6;
  }

  .profile-info {
    flex: 1;
  }

  .profile-name {
    font-size: 18px;
    font-weight: bold;
    color: #fff;
    margin: 0 0 4px 0;
  }

  .profile-email {
    font-size: 12px;
    color: #888;
    margin: 0;
  }

  .profile-stats {
    display: flex;
    gap: 20px;
    padding: 16px 20px;
    border-bottom: 1px solid #333;
  }

  .profile-stat {
    text-align: center;
    cursor: pointer;
  }

  .profile-stat:hover {
    opacity: 0.8;
  }

  .profile-stat-value {
    font-size: 20px;
    font-weight: bold;
    color: #fff;
  }

  .profile-stat-label {
    font-size: 11px;
    color: #888;
    text-transform: uppercase;
  }

  .profile-bio {
    padding: 16px 20px;
    color: #ccc;
    font-size: 14px;
    border-bottom: 1px solid #333;
  }

  .profile-bio-empty {
    color: #666;
    font-style: italic;
  }

  .profile-actions {
    padding: 16px 20px;
    display: flex;
    gap: 10px;
  }

  .feedback-section {
    padding: 12px 20px;
    border-bottom: 1px solid #333;
    background: linear-gradient(135deg, rgba(34, 197, 94, 0.1) 0%, rgba(59, 130, 246, 0.1) 100%);
  }

  .feedback-header {
    color: #fff;
    font-size: 13px;
    font-weight: 600;
    margin-bottom: 10px;
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .beta-badge {
    background: linear-gradient(135deg, #22c55e, #3b82f6);
    color: white;
    font-size: 9px;
    font-weight: 700;
    padding: 2px 6px;
    border-radius: 4px;
    letter-spacing: 0.5px;
  }

  .feedback-form {
    display: flex;
    flex-direction: column;
    gap: 8px;
  }

  .feedback-select {
    background: #222;
    border: 1px solid #333;
    border-radius: 6px;
    color: #fff;
    padding: 8px 10px;
    font-size: 13px;
    cursor: pointer;
  }

  .feedback-select:focus {
    outline: none;
    border-color: #22c55e;
  }

  .feedback-textarea {
    background: #222;
    border: 1px solid #333;
    border-radius: 6px;
    color: #fff;
    padding: 8px 10px;
    font-size: 13px;
    resize: none;
    font-family: inherit;
  }

  .feedback-textarea:focus {
    outline: none;
    border-color: #22c55e;
  }

  .feedback-textarea::placeholder {
    color: #666;
  }

  .feedback-submit {
    background: #22c55e;
    color: white;
    border: none;
    border-radius: 6px;
    padding: 8px 16px;
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
    transition: background 0.2s;
  }

  .feedback-submit:hover {
    background: #16a34a;
  }

  .feedback-submit:disabled {
    background: #333;
    color: #666;
    cursor: not-allowed;
  }

  .feedback-success {
    color: #22c55e;
    font-size: 13px;
    text-align: center;
    padding: 10px;
  }

  .profile-settings {
    padding: 12px 20px;
    border-bottom: 1px solid #333;
  }

  .profile-settings-header {
    color: #888;
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 8px;
  }

  .profile-setting-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 8px 0;
  }

  .profile-setting-label {
    color: #ccc;
    font-size: 14px;
  }

  .profile-contributors {
    margin-top: 16px;
    padding-top: 12px;
    border-top: 1px solid #333;
  }

  .profile-contributors-header {
    color: #888;
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 8px;
  }

  .contributors-list {
    max-height: 150px;
    overflow-y: auto;
  }

  .no-contributors {
    color: #666;
    font-size: 13px;
    font-style: italic;
    padding: 8px 0;
  }

  .contributor-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 6px 0;
    gap: 10px;
  }

  .contributor-info {
    display: flex;
    align-items: center;
    gap: 8px;
    flex: 1;
    min-width: 0;
  }

  .contributor-avatar {
    width: 24px;
    height: 24px;
    border-radius: 50%;
    background: #333;
    object-fit: cover;
    flex-shrink: 0;
  }

  .contributor-name {
    color: #ddd;
    font-size: 13px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .contributor-toggle {
    flex-shrink: 0;
  }

  .contributor-actions {
    display: flex;
    align-items: center;
    gap: 8px;
    flex-shrink: 0;
  }

  .follow-btn {
    padding: 4px 10px;
    border-radius: 12px;
    border: none;
    font-size: 11px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s;
  }

  .follow-btn.follow {
    background: #3b82f6;
    color: white;
  }

  .follow-btn.follow:hover {
    background: #2563eb;
  }

  .follow-btn.following {
    background: #333;
    color: #aaa;
  }

  .follow-btn.following:hover {
    background: #ef4444;
    color: white;
  }

  .toggle-switch {
    position: relative;
    width: 44px;
    height: 24px;
    background: #333;
    border-radius: 12px;
    cursor: pointer;
    transition: background 0.2s;
  }

  .toggle-switch.active {
    background: #22c55e;
  }

  .toggle-switch::after {
    content: '';
    position: absolute;
    top: 2px;
    left: 2px;
    width: 20px;
    height: 20px;
    background: #fff;
    border-radius: 50%;
    transition: transform 0.2s;
  }

  .toggle-switch.active::after {
    transform: translateX(20px);
  }

  .toggle-switch.small {
    width: 32px;
    height: 18px;
    border-radius: 9px;
  }

  .toggle-switch.small::after {
    width: 14px;
    height: 14px;
  }

  .toggle-switch.small.active::after {
    transform: translateX(14px);
  }

  .profile-bookmarks {
    padding: 12px 20px;
    border-bottom: 1px solid #333;
    max-height: 200px;
    overflow-y: auto;
  }

  .profile-bookmarks-header {
    color: #888;
    font-size: 12px;
    text-transform: uppercase;
    margin-bottom: 10px;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .profile-bookmarks-count {
    background: #333;
    padding: 2px 8px;
    border-radius: 10px;
    font-size: 11px;
  }

  .bookmark-item {
    background: #222;
    border-radius: 8px;
    padding: 10px;
    margin-bottom: 8px;
    cursor: pointer;
    transition: background 0.15s;
  }

  .bookmark-item:hover {
    background: #333;
  }

  .bookmark-quote {
    color: #fff;
    font-size: 13px;
    margin-bottom: 4px;
    font-style: italic;
  }

  .bookmark-meta {
    color: #888;
    font-size: 11px;
  }

  .no-bookmarks {
    color: #666;
    font-size: 13px;
    font-style: italic;
    text-align: center;
    padding: 20px;
  }

  .profile-btn {
    flex: 1;
    padding: 10px 16px;
    border: none;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    transition: background 0.15s;
  }

  .profile-btn.primary {
    background: #3b82f6;
    color: white;
  }

  .profile-btn.primary:hover {
    background: #2563eb;
  }

  .profile-btn.secondary {
    background: #333;
    color: #fff;
  }

  .profile-btn.secondary:hover {
    background: #444;
  }

  .profile-btn.danger {
    background: #ef4444;
    color: white;
  }

  .profile-btn.danger:hover {
    background: #dc2626;
  }

  .login-prompt {
    padding: 40px 20px;
    text-align: center;
  }

  .login-prompt p {
    color: #888;
    margin: 0 0 20px 0;
  }

  .login-btn {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    padding: 12px 24px;
    background: #fff;
    color: #333;
    border: none;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
  }

  .login-btn:hover {
    background: #f0f0f0;
  }

  .login-btn img {
    width: 20px;
    height: 20px;
  }
`;function UI(){if(console.log("[OpenOverlay] initUI starting..."),!document.body){console.error("[OpenOverlay] No document.body!");return}ji=document.createElement("div"),ji.id="openoverlay-ui",ji.style.cssText=`
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    z-index: 2147483647;
    pointer-events: none;
  `,C=ji.attachShadow({mode:"open"});const n=document.createElement("style");n.textContent=FI,C.appendChild(n);const e=document.createElement("div");e.className="fab-container";const t=document.createElement("button");t.className="fab",t.textContent="•••",t.title="OpenOverlay",t.onclick=()=>{var A;Vt&&(Vt=!1,(A=C==null?void 0:C.querySelector("#oo-profile-modal"))==null||A.classList.remove("show")),GI()},e.appendChild(t);const r=document.createElement("button");r.className="mini",r.textContent="✏️",r.title="Draw",r.onclick=()=>il("draw"),e.appendChild(r);const i=document.createElement("button");i.className="mini",i.textContent="T",i.title="Text",i.onclick=()=>il("text"),e.appendChild(i);const o=document.createElement("button");o.className="mini game-btn",o.textContent="🎮",o.title="Game",o.onclick=()=>il("game"),e.appendChild(o);const s=document.createElement("button");s.className="mini profile-btn",s.id="oo-profile-btn",s.textContent="⚙️",s.title="Settings & Profile",s.onclick=WI,e.appendChild(s),C.appendChild(e);let l=!1,u=0,d=0,p=18,m=18;const g=localStorage.getItem("oo_fab_position");if(g)try{const A=JSON.parse(g);e.style.right=A.right+"px",e.style.bottom=A.bottom+"px",p=A.right,m=A.bottom}catch{}t.addEventListener("pointerdown",A=>{if(A.shiftKey){A.preventDefault(),l=!0,u=A.clientX,d=A.clientY;const P=getComputedStyle(e);p=parseInt(P.right)||18,m=parseInt(P.bottom)||18,e.classList.add("dragging"),t.setPointerCapture(A.pointerId)}}),t.addEventListener("pointermove",A=>{if(!l)return;A.preventDefault();const P=u-A.clientX,V=d-A.clientY,$=Math.max(10,Math.min(window.innerWidth-70,p+P)),U=Math.max(10,Math.min(window.innerHeight-70,m+V));e.style.right=$+"px",e.style.bottom=U+"px"}),t.addEventListener("pointerup",A=>{if(l){l=!1,e.classList.remove("dragging"),t.releasePointerCapture(A.pointerId);const P=getComputedStyle(e);localStorage.setItem("oo_fab_position",JSON.stringify({right:parseInt(P.right)||18,bottom:parseInt(P.bottom)||18}))}});const b=document.createElement("div");b.className="profile-modal",b.id="oo-profile-modal",b.innerHTML=`
    <button class="profile-close" id="profile-close-btn">&times;</button>
    <div class="login-prompt" id="login-prompt">
      <p>Sign in to save your drawings and follow other users</p>
      <button class="login-btn" id="google-login-btn">
        <svg width="20" height="20" viewBox="0 0 24 24">
          <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
          <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
          <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
          <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
        </svg>
        Sign in with Google
      </button>
    </div>
    <div class="profile-content" id="profile-content" style="display: none;">
      <div class="profile-header">
        <img class="profile-avatar" id="profile-avatar" src="" alt="Profile">
        <div class="profile-info">
          <h3 class="profile-name" id="profile-name">User Name</h3>
          <p class="profile-email" id="profile-email">email@example.com</p>
        </div>
      </div>
      <div class="profile-stats">
        <div class="profile-stat" id="followers-stat">
          <div class="profile-stat-value" id="followers-count">0</div>
          <div class="profile-stat-label">Followers</div>
        </div>
        <div class="profile-stat" id="following-stat">
          <div class="profile-stat-value" id="following-count">0</div>
          <div class="profile-stat-label">Following</div>
        </div>
      </div>
      <div class="profile-bio" id="profile-bio">
        <span class="profile-bio-empty">No bio yet</span>
      </div>
      <div class="profile-settings">
        <div class="profile-settings-header">Drawing Visibility</div>
        <div class="profile-setting-row">
          <span class="profile-setting-label">Show all drawings</span>
          <div class="toggle-switch active" id="toggle-all-drawings" title="Master toggle - hide all drawings"></div>
        </div>
        <div class="profile-setting-row">
          <span class="profile-setting-label">My drawings</span>
          <div class="toggle-switch active" id="toggle-my-drawings" title="Show or hide your own drawings"></div>
        </div>
        <div class="profile-setting-row">
          <span class="profile-setting-label">Only people I follow</span>
          <div class="toggle-switch" id="toggle-following-only" title="Show only drawings from users you follow"></div>
        </div>
        <div class="profile-contributors" id="contributors-section">
          <div class="profile-contributors-header">Contributors on this page</div>
          <div id="contributors-list" class="contributors-list">
            <div class="no-contributors">No other contributors yet</div>
          </div>
        </div>
      </div>
      <div class="profile-bookmarks" id="profile-bookmarks">
        <div class="profile-bookmarks-header">
          Bookmarks <span class="profile-bookmarks-count" id="bookmarks-count">0</span>
        </div>
        <div id="bookmarks-list"></div>
      </div>
      <div class="feedback-section">
        <div class="feedback-header">
          <span class="beta-badge">BETA</span>
          Send Feedback
        </div>
        <div class="feedback-form" id="feedback-form">
          <select id="feedback-type" class="feedback-select">
            <option value="bug">🐛 Bug Report</option>
            <option value="feature">💡 Feature Request</option>
            <option value="other">💬 Other Feedback</option>
          </select>
          <textarea id="feedback-text" class="feedback-textarea" placeholder="Describe the issue or suggestion..." rows="3"></textarea>
          <button class="feedback-submit" id="feedback-submit">Send Feedback</button>
        </div>
        <div class="feedback-success" id="feedback-success" style="display:none;">
          ✓ Thanks for your feedback!
        </div>
      </div>
      <div class="profile-actions">
        <button class="profile-btn danger" id="signout-btn">Sign Out</button>
      </div>
    </div>
  `,C.appendChild(b);const O=document.createElement("div");O.className="toolbar",O.id="oo-toolbar",O.innerHTML=`
    <!-- DRAG HANDLE -->
    <div class="toolbar-drag-handle" id="oo-drag-handle" title="Drag to move">⠿</div>

    <!-- DRAW MODE CONTROLS -->
    <div class="draw-controls active" id="draw-controls">
      <!-- Row 1: Brushes + Tools -->
      <div class="toolbar-row">
        <div class="brush-styles" id="oo-brushes">
          ${LI.map(A=>`
            <button class="brush-btn ${A.id==="solid"?"active":""}"
                    data-brush="${A.id}" title="${A.title}">${A.label}</button>
          `).join("")}
        </div>
        <button class="tool-btn" id="oo-eraser" title="Eraser">🧹</button>
        <button class="tool-btn" id="oo-layer-bg" title="Background">⬇️</button>
        <button class="tool-btn" id="oo-layer-fg" title="Foreground">⬆️</button>
      </div>
      <!-- Row 2: Shapes -->
      <div class="toolbar-row">
        <div class="shape-tools" id="oo-shapes">
          ${VI.map(A=>`
            <button class="shape-btn ${A.id==="none"?"active":""}"
                    data-shape="${A.id}" title="${A.title}">${A.label}</button>
          `).join("")}
        </div>
        <button class="fill-btn" id="oo-fill-toggle" title="Toggle fill">◧</button>
      </div>
    </div>

    <!-- TEXT MODE CONTROLS -->
    <div class="text-controls" id="text-controls">
      <div class="toolbar-row">
        <input type="text" class="text-input" id="oo-text-input" placeholder="Type text...">
        <div class="text-styles" id="oo-text-styles">
          ${MI.map(A=>`
            <button class="text-style-btn ${A.id==="normal"?"active":""}"
                    data-style="${A.id}" title="${A.title}">${A.label}</button>
          `).join("")}
        </div>
        <button class="tool-btn" id="oo-text-layer-bg" title="Background (behind character)">⬇️</button>
        <button class="tool-btn" id="oo-text-layer-fg" title="Foreground (in front of character)">⬆️</button>
      </div>
      <span class="place-hint">Click page to place (default: regular layer)</span>
    </div>

    <!-- GAME MODE CONTROLS -->
    <div class="game-controls" id="game-controls">
      <!-- Row 1: Mode + Character + Multiplayer -->
      <div class="game-row">
        <div class="game-mode-toggle">
          <button class="game-mode-btn active" data-mode="play" data-playmode="explore" title="Explore">🚶</button>
          <button class="game-mode-btn" data-mode="play" data-playmode="race" title="Race">🏃</button>
          <button class="game-mode-btn" data-mode="build" title="Build">🔨</button>
        </div>
        <button class="multiplayer-btn" id="oo-multiplayer-setup" title="Setup for multiplayer (resize window)">👥 MP</button>
        <button class="multiplayer-btn" id="oo-tag-game" title="Start or join tag game">🏷️ Tag</button>
        <div class="char-style-toggle">
          <button class="char-style-btn active" id="oo-char-boy" title="Boy">👦</button>
          <button class="char-style-btn" id="oo-char-girl" title="Girl">👧</button>
        </div>
        <select class="char-customize-select" id="oo-hat-select" title="Hat">
          <option value="none">🎩</option>
          <option value="cap">🧢</option>
          <option value="tophat">🎩</option>
          <option value="crown">👑</option>
          <option value="beanie">🧶</option>
          <option value="party">🎉</option>
        </select>
        <select class="char-customize-select" id="oo-accessory-select" title="Face">
          <option value="none">😊</option>
          <option value="glasses">👓</option>
          <option value="sunglasses">🕶️</option>
          <option value="mustache">🥸</option>
          <option value="beard">🧔</option>
          <option value="mask">🦸</option>
        </select>
      </div>

      <!-- Row 2: Build Tools (hidden by default, shown when build mode selected) -->
      <div class="game-row build-tools-section" style="display: none;">
        <div class="game-tools" id="game-tools">
          <button class="game-tool-btn" data-tool="select" title="Select">✋</button>
          <button class="game-tool-btn active" data-tool="spawn" title="Spawn">👤</button>
          <button class="game-tool-btn" data-tool="start" title="Start">🏁</button>
          <button class="game-tool-btn" data-tool="finish" title="Finish">🏆</button>
          <button class="game-tool-btn" data-tool="checkpoint" title="Checkpoint">🚩</button>
          <button class="game-tool-btn" data-tool="trampoline" title="Bounce">🔶</button>
          <button class="game-tool-btn" data-tool="speedBoost" title="Speed">💨</button>
          <button class="game-tool-btn" data-tool="highJump" title="Jump">🦘</button>
          <button class="game-tool-btn" data-tool="spike" title="Spike">🔺</button>
        </div>
      </div>

      <!-- Row 3: Colors + Actions -->
      <div class="game-row">
        <input type="color" id="oo-game-color" value="#ff3366" title="Color">
        <div class="quick-colors game-colors" id="oo-game-quick-colors"></div>
        <div class="game-actions">
          <button class="action-btn btn-undo" id="oo-game-undo" title="Undo">↩</button>
          <button class="action-btn btn-clear" id="oo-game-clear" title="Clear">🗑</button>
          <button class="action-btn btn-cancel" id="oo-game-cancel">✕</button>
          <button class="action-btn btn-save" id="oo-game-save">✓</button>
        </div>
      </div>
    </div>

    <!-- SHARED CONTROLS -->
    <!-- Color Row -->
    <div class="toolbar-row">
      <input type="color" id="oo-color" value="#ff3366" title="Color">
      <div class="quick-colors" id="oo-quick-colors">
        ${DI.map((A,P)=>`
          <div class="quick-color ${P===0?"active":""}"
               data-color="${A}"
               style="background: ${A}"
               title="${A}"></div>
        `).join("")}
      </div>
    </div>

    <!-- Size/Opacity Row (hidden in game mode) -->
    <div class="toolbar-row drawing-only">
      <label>Size</label>
      <input type="range" id="oo-size" min="1" max="150" value="24" style="width: 80px;">
      <span class="size-display" id="oo-size-display">24</span>
      <label style="margin-left: 8px;">Op</label>
      <input type="range" id="oo-opacity" min="10" max="100" value="100" style="width: 60px;">
      <span class="opacity-display" id="oo-opacity-display">100%</span>
    </div>

    <!-- Actions Row -->
    <div class="toolbar-row">
      <button class="action-btn btn-undo" id="oo-undo" title="Undo">↩</button>
      <button class="action-btn btn-clear" id="oo-clear" title="Clear All">🗑</button>
      <div style="flex: 1;"></div>
      <button class="action-btn btn-cancel" id="oo-cancel">Cancel</button>
      <button class="action-btn btn-save" id="oo-save">Save</button>
    </div>
  `,C.appendChild(O),qI(O),document.body.appendChild(ji),document.addEventListener("oo:hidetoolbar",()=>{const A=C==null?void 0:C.querySelector(".toolbar");A==null||A.classList.remove("show"),Zt="none",Ys="play";const P=C==null?void 0:C.querySelectorAll(".mini");P==null||P.forEach(V=>V.classList.remove("active"))}),console.log("[OpenOverlay] UI initialized")}function qI(n){var S,_,Se,et,xr,vn,vt,wt,tt,le,xe,ye,Qe,Ht;n.querySelectorAll(".brush-btn").forEach(L=>{L.addEventListener("click",()=>{Lg=L.dataset.brush||"solid",n.querySelectorAll(".brush-btn").forEach(te=>te.classList.remove("active")),L.classList.add("active"),nt()})}),n.querySelectorAll(".text-style-btn").forEach(L=>{L.addEventListener("click",()=>{Mg=L.dataset.style||"normal",n.querySelectorAll(".text-style-btn").forEach(te=>te.classList.remove("active")),L.classList.add("active"),nt()})}),n.querySelectorAll(".shape-btn").forEach(L=>{L.addEventListener("click",()=>{Vg=L.dataset.shape||"none",n.querySelectorAll(".shape-btn").forEach(te=>te.classList.remove("active")),L.classList.add("active"),nt()})});const e=n.querySelector("#oo-fill-toggle");e==null||e.addEventListener("click",()=>{Xi=!Xi,e.classList.toggle("active",Xi),e.textContent=Xi?"◼":"◧",nt()});const t=n.querySelector("#oo-text-input");t==null||t.addEventListener("input",()=>{Ta=t.value,nt()}),n.querySelectorAll(".quick-color").forEach(L=>{L.addEventListener("click",()=>{const j=L.dataset.color||"#ff3366",te=n.querySelector("#oo-color");te&&(te.value=j),n.querySelectorAll(".quick-color").forEach(Je=>Je.classList.remove("active")),L.classList.add("active"),nt(),Zt==="game"&&document.dispatchEvent(new CustomEvent("oo:playercolor",{detail:{color:j}}))})}),(S=n.querySelector("#oo-color"))==null||S.addEventListener("input",()=>{const L=n.querySelector("#oo-color");n.querySelectorAll(".quick-color").forEach(j=>j.classList.remove("active")),nt(),Zt==="game"&&L&&document.dispatchEvent(new CustomEvent("oo:playercolor",{detail:{color:L.value}}))});const r=n.querySelector("#oo-size"),i=n.querySelector("#oo-size-display");r==null||r.addEventListener("input",()=>{i&&(i.textContent=r.value),nt()});const o=n.querySelector("#oo-opacity"),s=n.querySelector("#oo-opacity-display");o==null||o.addEventListener("input",()=>{s&&(s.textContent=o.value+"%"),nt()}),(_=n.querySelector("#oo-eraser"))==null||_.addEventListener("click",()=>{var L;Kr=!Kr,(L=n.querySelector("#oo-eraser"))==null||L.classList.toggle("active",Kr),nt()}),(Se=n.querySelector("#oo-layer-bg"))==null||Se.addEventListener("click",()=>{var L,j;De==="background"?De="normal":De="background",(L=n.querySelector("#oo-layer-bg"))==null||L.classList.toggle("active",De==="background"),(j=n.querySelector("#oo-layer-fg"))==null||j.classList.remove("active"),nt()}),(et=n.querySelector("#oo-layer-fg"))==null||et.addEventListener("click",()=>{var L,j;De==="foreground"?De="normal":De="foreground",(L=n.querySelector("#oo-layer-fg"))==null||L.classList.toggle("active",De==="foreground"),(j=n.querySelector("#oo-layer-bg"))==null||j.classList.remove("active"),nt()}),(xr=n.querySelector("#oo-text-layer-bg"))==null||xr.addEventListener("click",()=>{var L,j;De==="background"?De="normal":De="background",(L=n.querySelector("#oo-text-layer-bg"))==null||L.classList.toggle("active",De==="background"),(j=n.querySelector("#oo-text-layer-fg"))==null||j.classList.remove("active"),nt()}),(vn=n.querySelector("#oo-text-layer-fg"))==null||vn.addEventListener("click",()=>{var L,j;De==="foreground"?De="normal":De="foreground",(L=n.querySelector("#oo-text-layer-fg"))==null||L.classList.toggle("active",De==="foreground"),(j=n.querySelector("#oo-text-layer-bg"))==null||j.classList.remove("active"),nt()}),(vt=n.querySelector("#oo-undo"))==null||vt.addEventListener("click",()=>{document.dispatchEvent(new CustomEvent("oo:undo"))}),(wt=n.querySelector("#oo-clear"))==null||wt.addEventListener("click",()=>{document.dispatchEvent(new CustomEvent("oo:clear"))}),(tt=n.querySelector("#oo-cancel"))==null||tt.addEventListener("click",()=>{io("none"),document.dispatchEvent(new CustomEvent("oo:cancel"))}),(le=n.querySelector("#oo-save"))==null||le.addEventListener("click",()=>{io("none"),document.dispatchEvent(new CustomEvent("oo:save"))}),n.querySelectorAll(".game-mode-btn").forEach(L=>{L.addEventListener("click",()=>{const j=L.dataset.mode,te=L.dataset.playmode;Ys=j,n.querySelectorAll(".game-mode-btn").forEach(Ei=>Ei.classList.remove("active")),L.classList.add("active");const Je=n.querySelector(".build-tools-section");Je&&(Je.style.display=j==="build"?"flex":"none"),document.dispatchEvent(new CustomEvent("oo:gamemode",{detail:{mode:j,tool:Cd,playmode:te||"explore"}}))})}),n.querySelectorAll(".game-tool-btn[data-tool]").forEach(L=>{L.addEventListener("click",()=>{const j=L.dataset.tool||"platform";Cd=j,n.querySelectorAll(".game-tool-btn[data-tool]").forEach(te=>te.classList.remove("active")),L.classList.add("active"),document.dispatchEvent(new CustomEvent("oo:gamemode",{detail:{mode:Ys,tool:j}}))})});const l=n.querySelector("#oo-char-boy"),u=n.querySelector("#oo-char-girl");l==null||l.addEventListener("click",()=>{l.classList.add("active"),u==null||u.classList.remove("active"),document.dispatchEvent(new CustomEvent("oo:playerstyle",{detail:{isGirl:!1}})),localStorage.setItem("oo_player_girl","false")}),u==null||u.addEventListener("click",()=>{u.classList.add("active"),l==null||l.classList.remove("active"),document.dispatchEvent(new CustomEvent("oo:playerstyle",{detail:{isGirl:!0}})),localStorage.setItem("oo_player_girl","true")}),localStorage.getItem("oo_player_girl")==="true"&&(l==null||l.classList.remove("active"),u==null||u.classList.add("active"));const d=n.querySelector("#oo-hat-select");d==null||d.addEventListener("change",()=>{const L=d.value;document.dispatchEvent(new CustomEvent("oo:playerhat",{detail:{hat:L}}))});const p=localStorage.getItem("oo_player_hat");p&&d&&(d.value=p);const m=n.querySelector("#oo-accessory-select");m==null||m.addEventListener("change",()=>{const L=m.value;document.dispatchEvent(new CustomEvent("oo:playeraccessory",{detail:{accessory:L}}))});const g=localStorage.getItem("oo_player_accessory");g&&m&&(m.value=g);const b=n.querySelector("#oo-game-color");b==null||b.addEventListener("input",()=>{document.dispatchEvent(new CustomEvent("oo:playercolor",{detail:{color:b.value}}))});const O=n.querySelector("#oo-game-quick-colors");if(O){const L=["#ff3366","#22c55e","#3b82f6","#f59e0b","#8b5cf6","#fff","#000"];O.innerHTML=L.map((j,te)=>`
      <div class="quick-color ${te===0?"active":""}" data-color="${j}" style="background: ${j}" title="${j}"></div>
    `).join(""),O.querySelectorAll(".quick-color").forEach(j=>{j.addEventListener("click",()=>{const te=j.dataset.color||"#ff3366";b&&(b.value=te),O.querySelectorAll(".quick-color").forEach(Je=>Je.classList.remove("active")),j.classList.add("active"),document.dispatchEvent(new CustomEvent("oo:playercolor",{detail:{color:te}}))})})}(xe=n.querySelector("#oo-game-undo"))==null||xe.addEventListener("click",()=>{document.dispatchEvent(new CustomEvent("oo:undo"))}),(ye=n.querySelector("#oo-game-clear"))==null||ye.addEventListener("click",()=>{document.dispatchEvent(new CustomEvent("oo:clear"))}),(Qe=n.querySelector("#oo-game-cancel"))==null||Qe.addEventListener("click",()=>{io("none"),document.dispatchEvent(new CustomEvent("oo:cancel"))}),(Ht=n.querySelector("#oo-game-save"))==null||Ht.addEventListener("click",()=>{document.dispatchEvent(new CustomEvent("oo:save")),document.dispatchEvent(new CustomEvent("oo:gamemode",{detail:{mode:"play",playmode:"explore"}})),n.classList.remove("show"),Zt="none"}),document.addEventListener("click",L=>{if(Vl){Vl=!1;return}if(Zt!=="game"||!n.classList.contains("show"))return;const j=L.composedPath(),te=C==null?void 0:C.host;te&&j.includes(te)||(document.dispatchEvent(new CustomEvent("oo:save")),document.dispatchEvent(new CustomEvent("oo:gamemode",{detail:{mode:"play",playmode:"explore"}})),n.classList.remove("show"),Zt="none")}),document.addEventListener("click",L=>{var Je;if(!Vt)return;const j=L.composedPath(),te=C==null?void 0:C.host;te&&j.includes(te)||(Vt=!1,(Je=C==null?void 0:C.querySelector("#oo-profile-modal"))==null||Je.classList.remove("show"))});const A=n.querySelector("#oo-multiplayer-setup");A==null||A.addEventListener("click",async()=>{const L=A;L.textContent="⏳",L.disabled=!0;try{const j=await chrome.runtime.sendMessage({type:"SETUP_MULTIPLAYER"});j!=null&&j.success?(L.textContent="✓ Ready",L.classList.add("active"),setTimeout(()=>{L.textContent="👥 MP",L.disabled=!1},2e3)):(L.textContent="❌ Error",setTimeout(()=>{L.textContent="👥 MP",L.disabled=!1,L.classList.remove("active")},2e3))}catch(j){console.error("[OpenOverlay] Multiplayer setup error:",j),L.textContent="👥 MP",L.disabled=!1}});const P=n.querySelector("#oo-tag-game");let V=!1;P==null||P.addEventListener("click",async()=>{if(V){document.dispatchEvent(new CustomEvent("oo:toggletag"));return}P.textContent="⏳",P.disabled=!0;try{const L=await chrome.runtime.sendMessage({type:"SETUP_MULTIPLAYER"});L!=null&&L.success?(console.log("[OpenOverlay UI] Multiplayer setup complete, starting tag game"),document.dispatchEvent(new CustomEvent("oo:toggletag"))):(console.error("[OpenOverlay UI] Multiplayer setup failed:",L==null?void 0:L.error),P.textContent="❌",setTimeout(()=>{P.textContent="🏷️ Tag",P.disabled=!1},1500))}catch(L){console.error("[OpenOverlay UI] Error setting up multiplayer:",L),P.textContent="❌",setTimeout(()=>{P.textContent="🏷️ Tag",P.disabled=!1},1500)}}),document.addEventListener("oo:tagstatechange",L=>{const{isTagMode:j,isIt:te}=L.detail;V=j,P.disabled=!1,j?te?(P.textContent="🏷️ IT!",P.classList.add("active")):(P.textContent="🏷️ Run!",P.classList.add("active")):(P.textContent="🏷️ Tag",P.classList.remove("active"))});const $=n.querySelector("#oo-drag-handle");let U=!1,G=0,z=0,J=0,E=0;$==null||$.addEventListener("pointerdown",L=>{const j=L;U=!0,G=j.clientX,z=j.clientY;const te=n.getBoundingClientRect();J=te.left,E=te.top,n.style.right="auto",n.style.bottom="auto",n.style.left=`${te.left}px`,n.style.top=`${te.top}px`,$.style.cursor="grabbing",j.preventDefault()}),document.addEventListener("pointermove",L=>{if(!U)return;const j=L.clientX-G,te=L.clientY-z;n.style.left=`${J+j}px`,n.style.top=`${E+te}px`}),document.addEventListener("pointerup",()=>{U&&(U=!1,$&&($.style.cursor="grab"))});const v=C.querySelector("#google-login-btn"),w=C.querySelector("#signout-btn"),I=C.querySelector("#profile-close-btn");I==null||I.addEventListener("click",()=>{Vt=!1;const L=C==null?void 0:C.querySelector("#oo-profile-modal");L==null||L.classList.remove("show")}),v==null||v.addEventListener("click",async()=>{try{await dI()}catch(L){console.error("[OpenOverlay] Login failed:",L)}}),w==null||w.addEventListener("click",async()=>{try{await fI(),Vt=!1;const L=C==null?void 0:C.querySelector("#oo-profile-modal");L==null||L.classList.remove("show")}catch(L){console.error("[OpenOverlay] Sign out failed:",L)}});const T=C.querySelector("#feedback-submit");T==null||T.addEventListener("click",async()=>{var Ii;const L=C==null?void 0:C.querySelector("#feedback-type"),j=C==null?void 0:C.querySelector("#feedback-text"),te=C==null?void 0:C.querySelector("#feedback-form"),Je=C==null?void 0:C.querySelector("#feedback-success"),Ei=L==null?void 0:L.value,Fo=(Ii=j==null?void 0:j.value)==null?void 0:Ii.trim();if(!Fo){j==null||j.focus();return}const Gt=T;Gt.disabled=!0,Gt.textContent="Sending...",await uI(Ei,Fo)?(te.style.display="none",Je.style.display="block",setTimeout(()=>{j.value="",L.selectedIndex=0,te.style.display="block",Je.style.display="none",Gt.disabled=!1,Gt.textContent="Send Feedback"},3e3)):(Gt.disabled=!1,Gt.textContent="Send Feedback",alert("Failed to send feedback. Please try again."))}),$I(C),document.addEventListener("oo:contributors",L=>{jI(C,L.detail.contributors)}),Tg(L=>{zI(L)})}let Le={showAll:!0,showMine:!0,showFollowing:!1,hiddenUsers:new Set};function $I(n){BI();const e=n.querySelector("#toggle-all-drawings"),t=n.querySelector("#toggle-my-drawings"),r=n.querySelector("#toggle-following-only");e==null||e.classList.toggle("active",Le.showAll),t==null||t.classList.toggle("active",Le.showMine),r==null||r.classList.toggle("active",Le.showFollowing),e==null||e.addEventListener("click",()=>{Le.showAll=!Le.showAll,e.classList.toggle("active",Le.showAll),document.dispatchEvent(new CustomEvent("oo:visibility:all",{detail:{show:Le.showAll}}))}),t==null||t.addEventListener("click",()=>{Le.showMine=!Le.showMine,t.classList.toggle("active",Le.showMine),document.dispatchEvent(new CustomEvent("oo:visibility:mine",{detail:{show:Le.showMine}}))}),r==null||r.addEventListener("click",()=>{Le.showFollowing=!Le.showFollowing,r.classList.toggle("active",Le.showFollowing),document.dispatchEvent(new CustomEvent("oo:visibility:following",{detail:{show:Le.showFollowing}}))})}function BI(){try{const n=localStorage.getItem("oo_visibility_prefs");if(n){const e=JSON.parse(n);Le={showAll:e.showAll??!0,showMine:e.showMine??!0,showFollowing:e.showFollowing??!1,hiddenUsers:new Set(e.hiddenUsers??[])}}}catch{}}async function jI(n,e){const t=n.querySelector("#contributors-list");if(!t)return;const r=ue(),i=e.filter(s=>s.userId!==(r==null?void 0:r.uid));if(i.length===0){t.innerHTML='<div class="no-contributors">No other contributors yet</div>';return}const o=new Map;r&&await Promise.all(i.map(async s=>{const l=await KE(r.uid,s.userId);o.set(s.userId,l)})),t.innerHTML=i.map(s=>{var m;const l=!Le.hiddenUsers.has(s.userId),u=s.photoURL||"",d=((m=s.displayName)==null?void 0:m.charAt(0).toUpperCase())||"?",p=o.get(s.userId)||!1;return`
      <div class="contributor-row" data-user-id="${s.userId}">
        <div class="contributor-info">
          ${u?`<img src="${u}" class="contributor-avatar" alt="${s.displayName}">`:`<div class="contributor-avatar" style="display:flex;align-items:center;justify-content:center;color:#888;font-size:12px;">${d}</div>`}
          <span class="contributor-name">${Vr(s.displayName)}</span>
        </div>
        <div class="contributor-actions">
          ${r?`
            <button class="follow-btn ${p?"following":"follow"}"
                    data-follow-user="${s.userId}"
                    data-user-name="${Vr(s.displayName)}"
                    data-user-photo="${u}">
              ${p?"Following":"Follow"}
            </button>
          `:""}
          <div class="toggle-switch small ${l?"active":""}" data-toggle-user="${s.userId}" title="Show/hide this user's drawings"></div>
        </div>
      </div>
    `}).join(""),t.querySelectorAll("[data-toggle-user]").forEach(s=>{s.addEventListener("click",()=>{const l=s.getAttribute("data-toggle-user");if(!l)return;const u=s.classList.toggle("active");u?Le.hiddenUsers.delete(l):Le.hiddenUsers.add(l),document.dispatchEvent(new CustomEvent("oo:visibility:user",{detail:{userId:l,show:u}}))})}),t.querySelectorAll("[data-follow-user]").forEach(s=>{s.addEventListener("click",async()=>{const l=s.getAttribute("data-follow-user"),u=s.getAttribute("data-user-name")||"",d=s.getAttribute("data-user-photo")||"";if(!l||!r)return;const p=s,m=p.classList.contains("following");p.disabled=!0;try{m?(await GE(r.uid,l),p.classList.remove("following"),p.classList.add("follow"),p.textContent="Follow"):(await HE(r.uid,l,u,d),p.classList.remove("follow"),p.classList.add("following"),p.textContent="Following")}catch(g){console.error("[OpenOverlay] Follow action failed:",g),m?(p.classList.add("following"),p.classList.remove("follow"),p.textContent="Following"):(p.classList.add("follow"),p.classList.remove("following"),p.textContent="Follow")}finally{p.disabled=!1}})})}function zI(n){var i;const e=C==null?void 0:C.querySelector("#oo-profile-btn"),t=C==null?void 0:C.querySelector("#login-prompt"),r=C==null?void 0:C.querySelector("#profile-content");if(!(!e||!t||!r))if(n){n.photoURL?e.innerHTML=`<img src="${n.photoURL}" alt="Profile">`:e.textContent=((i=n.displayName)==null?void 0:i.charAt(0).toUpperCase())||"👤",t.style.display="none",r.style.display="block";const o=C==null?void 0:C.querySelector("#profile-avatar"),s=C==null?void 0:C.querySelector("#profile-name"),l=C==null?void 0:C.querySelector("#profile-email");o&&(o.src=n.photoURL||""),s&&(s.textContent=n.displayName||"Anonymous"),l&&(l.textContent=n.email||""),yg(n.uid).then(u=>{if(u){const d=C==null?void 0:C.querySelector("#followers-count"),p=C==null?void 0:C.querySelector("#following-count"),m=C==null?void 0:C.querySelector("#profile-bio");d&&(d.textContent=String(u.followersCount||0)),p&&(p.textContent=String(u.followingCount||0)),m&&(m.innerHTML=u.bio?u.bio:'<span class="profile-bio-empty">No bio yet</span>')}})}else e.textContent="👤",t.style.display="block",r.style.display="none"}function WI(){Vt=!Vt;const n=C==null?void 0:C.querySelector("#oo-profile-modal");n==null||n.classList.toggle("show",Vt),Vt&&HI()}function HI(){const n=C==null?void 0:C.querySelector("#bookmarks-list"),e=C==null?void 0:C.querySelector("#bookmarks-count");if(!n)return;const t=ba();if(e&&(e.textContent=String(t.length)),t.length===0){n.innerHTML='<div class="no-bookmarks">No bookmarks yet</div>';return}n.innerHTML=t.slice(0,10).map(r=>`
    <div class="bookmark-item" data-url="${Vr(r.pageUrl)}">
      <div class="bookmark-quote">"${Vr(Rd(r.comment,50))}"</div>
      <div class="bookmark-meta">${Vr(Rd(r.pageTitle,30))} • ${Vr(r.authorName)}</div>
    </div>
  `).join(""),n.querySelectorAll(".bookmark-item").forEach(r=>{r.addEventListener("click",()=>{const i=r.dataset.url;i&&window.open(i,"_blank")})})}function Vr(n){const e=document.createElement("div");return e.textContent=n,e.innerHTML}function Rd(n,e){return n.length<=e?n:n.slice(0,e)+"..."}function nt(){document.dispatchEvent(new CustomEvent("oo:settings",{detail:{color:ci(),size:ui(),opacity:hi(),brush:Jc(),textStyle:Ug(),eraser:Kr,layer:De}}))}function GI(){ss=!ss;const n=C==null?void 0:C.querySelector(".fab"),e=C==null?void 0:C.querySelectorAll(".mini");n==null||n.classList.toggle("open",ss),e==null||e.forEach(t=>t.classList.toggle("show",ss))}function il(n){io(Zt===n?"none":n)}function io(n){var d,p,m,g,b;const e=Zt;Zt=n;const t=C==null?void 0:C.querySelectorAll(".mini");t==null||t.forEach((O,A)=>{A===0&&O.classList.toggle("active",n==="draw"),A===1&&O.classList.toggle("active",n==="text"),A===2&&O.classList.toggle("active",n==="game")});const r=C==null?void 0:C.querySelector(".toolbar");r==null||r.classList.toggle("show",n!=="none"),r==null||r.classList.toggle("game-mode",n==="game");const i=C==null?void 0:C.querySelector("#draw-controls"),o=C==null?void 0:C.querySelector("#text-controls"),s=C==null?void 0:C.querySelector("#game-controls");i==null||i.classList.toggle("active",n==="draw"),o==null||o.classList.toggle("active",n==="text"),s==null||s.classList.toggle("active",n==="game");const l=C==null?void 0:C.querySelector("#oo-size"),u=C==null?void 0:C.querySelector("#oo-size-display");if(l&&u&&(n==="text"?(l.value="32",l.max="200",u.textContent="32"):n==="draw"&&(l.value="4",l.max="150",u.textContent="4")),n!=="none"&&(Kr=!1,(d=C==null?void 0:C.querySelector("#oo-eraser"))==null||d.classList.remove("active"),De="normal",(p=C==null?void 0:C.querySelector("#oo-layer-bg"))==null||p.classList.remove("active"),(m=C==null?void 0:C.querySelector("#oo-layer-fg"))==null||m.classList.remove("active"),(g=C==null?void 0:C.querySelector("#oo-text-layer-bg"))==null||g.classList.remove("active"),(b=C==null?void 0:C.querySelector("#oo-text-layer-fg"))==null||b.classList.remove("active")),n!=="text"){Ta="";const O=C==null?void 0:C.querySelector("#oo-text-input");O&&(O.value="")}if(document.dispatchEvent(new CustomEvent("oo:mode",{detail:{mode:n}})),n==="game"){Vl=!0,Ys="play";const O=C==null?void 0:C.querySelectorAll(".game-mode-btn");O==null||O.forEach(P=>{const V=P.dataset.mode,$=P.dataset.playmode;P.classList.toggle("active",V==="play"&&$==="explore")});const A=C==null?void 0:C.querySelector(".build-tools-section");A&&(A.style.display="none"),document.dispatchEvent(new CustomEvent("oo:gamemode",{detail:{mode:"play",playmode:"explore"}}))}else e==="game"&&document.dispatchEvent(new CustomEvent("oo:gamemode",{detail:{mode:"none"}}));console.log("[OpenOverlay] Mode:",n)}function ci(){const n=C==null?void 0:C.querySelector("#oo-color");return(n==null?void 0:n.value)||"#ff3366"}function ui(){const n=C==null?void 0:C.querySelector("#oo-size");return parseInt((n==null?void 0:n.value)||"4",10)}function hi(){const n=C==null?void 0:C.querySelector("#oo-opacity");return parseInt((n==null?void 0:n.value)||"100",10)/100}function Jc(){return Lg}function Fg(){return Kr}function Fl(){return De}function Ug(){return Mg}function KI(){return Vg}function qg(){return Xi}function YI(){return Ta}function QI(){Ta="";const n=C==null?void 0:C.querySelector("#oo-text-input");n&&(n.value="")}let se=null,M=null,Me=null,st=null,pt=null,cr=null,di=!1,dt="none",Xc=!1,ae=[],Lr=[],ft={showAll:!0,showMine:!0,showFollowing:!1,hiddenUsers:new Set},On=null,as=[],Yr=[],Kt=null,Qr="none",nn=null,rn=null,$g=!1,ol=0,at=null,Ul={x:0,y:0},Lt="none",As={x:0,y:0,size:0};const ls=10,Bg=30;function jg(n){if(n===document.body||n===document.documentElement)return"body";if(n.id)return`#${CSS.escape(n.id)}`;const e=[];let t=n;for(;t&&t!==document.body&&t!==document.documentElement;){let r=t.tagName.toLowerCase();if(t.className&&typeof t.className=="string"){const o=t.className.trim().split(/\s+/).slice(0,2);o.length>0&&o[0]&&(r+="."+o.map(s=>CSS.escape(s)).join("."))}const i=t.parentElement;if(i){const o=Array.from(i.children).filter(s=>s.tagName===t.tagName);if(o.length>1){const s=o.indexOf(t)+1;r+=`:nth-of-type(${s})`}}if(e.unshift(r),e.length>=4)break;t=t.parentElement}return e.join(" > ")||"body"}function zg(n,e){se&&(se.style.pointerEvents="none");const t=document.elementsFromPoint(n,e);se&&(se.style.pointerEvents=dt==="draw"?"auto":"none");for(const r of t){if(r.id==="oo-canvas"||r.id==="openoverlay-ui"||r===document.body||r===document.documentElement)continue;const i=r.getBoundingClientRect();if(!(i.width<20||i.height<20))return r}return document.body}function JI(){console.log("[OpenOverlay] initCanvas starting..."),se=document.createElement("canvas"),se.id="oo-canvas",se.style.cssText=`
    position: absolute;
    top: 0;
    left: 0;
    z-index: 2147483640;
    pointer-events: none;
  `,document.body.appendChild(se),M=se.getContext("2d"),Me=document.createElement("canvas"),st=Me.getContext("2d"),pt=document.createElement("canvas"),pt.id="oo-background-canvas",pt.style.cssText=`
    position: absolute;
    top: 0;
    left: 0;
    z-index: 2147483635;
    pointer-events: none;
  `,document.body.appendChild(pt),cr=pt.getContext("2d"),sl(),window.addEventListener("resize",sl);let n=null;window.addEventListener("scroll",()=>{n&&clearTimeout(n),n=window.setTimeout(()=>{di||ge()},50)},{passive:!0}),new ResizeObserver(sl).observe(document.body);let t=null;new MutationObserver(()=>{t&&clearTimeout(t),t=window.setTimeout(()=>{di||ge()},100)}).observe(document.body,{childList:!0,subtree:!0}),document.addEventListener("oo:mode",i=>{dt=i.detail.mode,se&&(se.style.pointerEvents=dt==="draw"||dt==="text"?"auto":"none",se.style.cursor=dt==="draw"?"crosshair":dt==="text"?"text":"default")}),document.addEventListener("oo:save",m0),document.addEventListener("oo:cancel",y0),document.addEventListener("oo:undo",p0),document.addEventListener("oo:clear",g0),document.addEventListener("oo:visibility:all",i=>{ft.showAll=i.detail.show,zi(),ge(),console.log("[OpenOverlay] Visibility - show all:",i.detail.show)}),document.addEventListener("oo:visibility:mine",i=>{ft.showMine=i.detail.show,zi(),ge(),console.log("[OpenOverlay] Visibility - show mine:",i.detail.show)}),document.addEventListener("oo:visibility:following",i=>{ft.showFollowing=i.detail.show,zi(),ge(),console.log("[OpenOverlay] Visibility - following only:",i.detail.show)}),document.addEventListener("oo:visibility:user",i=>{const{userId:o,show:s}=i.detail;s?ft.hiddenUsers.delete(o):ft.hiddenUsers.add(o),zi(),ge(),console.log("[OpenOverlay] Visibility - user",o,":",s?"shown":"hidden")}),document.addEventListener("oo:toggleothers",i=>{ft.showAll=i.detail.show,zi(),ge()}),l0(),document.addEventListener("oo:gamemode",i=>{Xc=i.detail.mode==="build"}),document.addEventListener("oo:settings",i=>{if(at&&dt==="text"){const o=ae.find(s=>s.type==="text"&&s.id===at);o&&(o.size=i.detail.size,o.color=i.detail.color,o.opacity=i.detail.opacity,o.style=i.detail.textStyle,ge())}}),se.addEventListener("pointerdown",XI),se.addEventListener("pointermove",t0),se.addEventListener("pointerup",Od),se.addEventListener("pointerleave",Od),Zc(),v0(),console.log("[OpenOverlay] Canvas initialized")}function sl(){if(!se||!M)return;const n=Math.max(document.body.scrollWidth,document.body.offsetWidth,document.documentElement.scrollWidth,document.documentElement.offsetWidth),e=Math.max(document.body.scrollHeight,document.body.offsetHeight,document.documentElement.scrollHeight,document.documentElement.offsetHeight),t=window.devicePixelRatio||1;se.style.width=`${n}px`,se.style.height=`${e}px`,se.width=n*t,se.height=e*t,M.scale(t,t),Me&&st&&(Me.width=n*t,Me.height=e*t,st.setTransform(1,0,0,1,0,0),st.scale(t,t)),pt&&cr&&(pt.style.width=`${n}px`,pt.style.height=`${e}px`,pt.width=n*t,pt.height=e*t,cr.scale(t,t)),ge()}function XI(n){if(dt==="text"){e0(n);return}if(dt!=="draw")return;di=!0;const e=zg(n.clientX,n.clientY);if(e){const r=e.getBoundingClientRect();Kt={element:e,selector:jg(e),bounds:r}}const t=KI();t!=="none"?(Qr=t,nn={x:n.pageX,y:n.pageY},rn={x:n.pageX,y:n.pageY},$g=qg()):Yr=[{x:n.pageX,y:n.pageY}]}function Qs(n){if(!M)return null;const e=Hg(n);if(!e)return null;M.font=`bold ${n.size||32}px Impact, Arial, sans-serif`;const r=M.measureText(n.text).width,i=n.size;return{x:e.x,y:e.y,width:r,height:i,centerX:e.x+r/2,centerY:e.y+i/2}}function Wg(n,e,t){const r=Qs(t);if(!r)return"none";const i=8,o=t.rotation||0,s=[{x:r.x+r.width+i,y:r.y+r.height+i,mode:"resize"}],l=r.centerX,u=r.y-i-Bg,d=Math.cos(o),p=Math.sin(o),m=l-r.centerX,g=u-r.centerY,b=r.centerX+m*d-g*p,O=r.centerY+m*p+g*d;if(Math.abs(n-b)<ls&&Math.abs(e-O)<ls)return"rotate";const A=s[0].x-r.centerX,P=s[0].y-r.centerY,V=r.centerX+A*d-P*p,$=r.centerY+A*p+P*d;return Math.abs(n-V)<ls&&Math.abs(e-$)<ls?"resize":"none"}function ZI(n){if(!se||dt!=="text")return;if(at){const t=ae.find(r=>r.type==="text"&&r.id===at);if(t){const r=Wg(n.pageX,n.pageY,t);if(r==="resize"){se.style.cursor="nwse-resize";return}else if(r==="rotate"){se.style.cursor="crosshair";return}}}Gg(n.pageX,n.pageY)?se.style.cursor="grab":se.style.cursor="default"}function e0(n){if(at){const g=ae.find(b=>b.type==="text"&&b.id===at);if(g){const b=Wg(n.pageX,n.pageY,g);if(b!=="none"){Lt=b,Qs(g)&&(As={x:n.pageX,y:n.pageY,size:g.size,rotation:g.rotation||0});return}}}const e=Gg(n.pageX,n.pageY);if(e){at=e.id,Lt="move";const g=Hg(e);g&&(Ul={x:n.pageX-g.x,y:n.pageY-g.y}),se&&(se.style.cursor="grabbing"),ge();return}const t=YI();if(!t||!t.trim()){at&&(at=null,Lt="none",ge());return}const r=zg(n.clientX,n.clientY);if(!r)return;const i=r.getBoundingClientRect(),o=window.scrollX,s=window.scrollY,l=i.left+o,u=i.top+s,d=(n.pageX-l)/i.width,p=(n.pageY-u)/i.height,m={type:"text",id:n0(),anchorSelector:jg(r),x:d,y:p,anchorBounds:{x:l,y:u,width:i.width,height:i.height},text:t,color:ci(),size:ui(),opacity:hi(),style:Ug(),rotation:0,layer:Fl()};ae.push(m),at=m.id,QI(),ge()}function Hg(n){let e=null;try{e=document.querySelector(n.anchorSelector)}catch{}if(!e)return null;const t=e.getBoundingClientRect(),r=window.scrollX,i=window.scrollY;return{x:t.left+r+n.x*t.width,y:t.top+i+n.y*t.height}}function t0(n){if(dt==="text"&&Lt==="none"&&ZI(n),at&&dt==="text"&&Lt!=="none"){const e=ae.find(t=>t.type==="text"&&t.id===at);if(!e)return;if(Lt==="move"){let t=null;try{t=document.querySelector(e.anchorSelector)}catch{}if(t){const r=t.getBoundingClientRect(),i=window.scrollX,o=window.scrollY,s=n.pageX-Ul.x,l=n.pageY-Ul.y;e.x=(s-r.left-i)/r.width,e.y=(l-r.top-o)/r.height,ge()}}else if(Lt==="resize"){if(Qs(e)){const r=n.pageX-As.x,i=n.pageY-As.y,o=(r+i)/2,s=Math.max(12,Math.min(200,As.size+o));e.size=s,ge()}}else if(Lt==="rotate"){const t=Qs(e);if(t){const r=Math.atan2(n.pageY-t.centerY,n.pageX-t.centerX);e.rotation=r+Math.PI/2,ge()}}return}if(!(!di||!M)){if(Qr!=="none"&&nn){rn={x:n.pageX,y:n.pageY},ge(),i0();return}Yr.push({x:n.pageX,y:n.pageY}),ge(),r0(Yr,ci(),ui(),hi(),Jc(),Fg())}}function Od(){if(Lt!=="none"){Lt="none",se&&(se.style.cursor="grab");return}if(di){if(di=!1,Qr!=="none"&&nn&&rn&&Kt){const n=Kt.element.getBoundingClientRect(),e=window.scrollX,t=window.scrollY,r=n.left+e,i=n.top+t,o=(nn.x-r)/n.width,s=(nn.y-i)/n.height,l=(rn.x-r)/n.width,u=(rn.y-i)/n.height;ae.push({type:"shape",id:"shape_"+Date.now(),anchorSelector:Kt.selector,x1:o,y1:s,x2:l,y2:u,anchorBounds:{x:r,y:i,width:n.width,height:n.height},shape:Qr,color:ci(),width:ui(),opacity:hi(),filled:$g,layer:Fl()}),nn=null,rn=null,Qr="none",Kt=null,ge();return}if(Yr.length>1&&Kt){const n=Kt.element.getBoundingClientRect(),e=window.scrollX,t=window.scrollY,r=n.left+e,i=n.top+t,o=Yr.map(s=>({x:(s.x-r)/n.width,y:(s.y-i)/n.height}));ae.push({type:"stroke",anchorSelector:Kt.selector,points:o,anchorBounds:{x:r,y:i,width:n.width,height:n.height},color:ci(),width:ui(),opacity:hi(),brush:Jc(),eraser:Fg(),layer:Fl()})}Yr=[],Kt=null,ge()}}function Gg(n,e){const t=window.scrollX,r=window.scrollY;for(let i=ae.length-1;i>=0;i--){const o=ae[i];if(o.type!=="text")continue;let s=null;try{s=document.querySelector(o.anchorSelector)}catch{}if(!s)continue;const l=s.getBoundingClientRect(),u={x:l.left+t,y:l.top+r,width:l.width,height:l.height},d=u.x+o.x*u.width,p=u.y+o.y*u.height,m=o.text.length*o.size*.6,g=o.size,b=10;if(n>=d-b&&n<=d+m+b&&e>=p-b&&e<=p+g+b)return o}return null}function n0(){return Math.random().toString(36).substr(2,9)}function r0(n,e,t,r,i,o){if(!(!M||n.length<2)){switch(M.save(),M.globalAlpha=r,o&&(M.globalCompositeOperation="destination-out",M.globalAlpha=1),i){case"spray":Qg(M,n,e,t);break;case"dots":Jg(M,n,e,t);break;case"square":Xg(M,n,e,t);break;case"rainbow":o0(M,n,t);break;case"glow":Zg(M,n,e,t);break;default:Yg(M,n,e,t)}M.restore()}}function Nd(n,e){if(!M||n.points.length<2)return;const t=n.points.map(r=>({x:e.x+r.x*e.width,y:e.y+r.y*e.height}));switch(M.save(),M.globalAlpha=n.opacity,n.eraser&&(M.globalCompositeOperation="destination-out",M.globalAlpha=1),n.brush){case"spray":Qg(M,t,n.color,n.width);break;case"dots":Jg(M,t,n.color,n.width);break;case"square":Xg(M,t,n.color,n.width);break;case"rainbow":s0(M,t,n.width);break;case"glow":Zg(M,t,n.color,n.width);break;default:Yg(M,t,n.color,n.width)}M.restore()}function i0(){if(!M||!nn||!rn)return;const n=ci(),e=ui(),t=hi(),r=qg();M.save(),M.globalAlpha=t,M.strokeStyle=n,M.fillStyle=n,M.lineWidth=e,M.lineCap="round",M.lineJoin="round";const i=nn.x,o=nn.y,s=rn.x,l=rn.y;Kg(M,Qr,i,o,s,l,r),M.restore()}function Dd(n,e){if(!M)return;const t=e.x+n.x1*e.width,r=e.y+n.y1*e.height,i=e.x+n.x2*e.width,o=e.y+n.y2*e.height;M.save(),M.globalAlpha=n.opacity,M.strokeStyle=n.color,M.fillStyle=n.color,M.lineWidth=n.width,M.lineCap="round",M.lineJoin="round",Kg(M,n.shape,t,r,i,o,n.filled),M.restore()}function Kg(n,e,t,r,i,o,s){const l=Math.min(t,i),u=Math.min(r,o),d=Math.abs(i-t),p=Math.abs(o-r),m=(t+i)/2,g=(r+o)/2;switch(n.beginPath(),e){case"line":n.moveTo(t,r),n.lineTo(i,o),n.stroke();break;case"rectangle":s&&n.fillRect(l,u,d,p),n.strokeRect(l,u,d,p);break;case"circle":const b=Math.sqrt(d*d+p*p)/2;n.arc(m,g,b,0,Math.PI*2),s&&n.fill(),n.stroke();break;case"triangle":n.moveTo(m,u),n.lineTo(l,u+p),n.lineTo(l+d,u+p),n.closePath(),s&&n.fill(),n.stroke();break;case"star":const O=Math.min(d,p)/2,A=O*.4,P=5;for(let V=0;V<P*2;V++){const $=V%2===0?O:A,U=Math.PI/P*V-Math.PI/2,G=m+$*Math.cos(U),z=g+$*Math.sin(U);V===0?n.moveTo(G,z):n.lineTo(G,z)}n.closePath(),s&&n.fill(),n.stroke();break}}function Yg(n,e,t,r){n.beginPath(),n.strokeStyle=t,n.lineWidth=r,n.lineCap="round",n.lineJoin="round",n.moveTo(e[0].x,e[0].y);for(let i=1;i<e.length;i++)n.lineTo(e[i].x,e[i].y);n.stroke()}function Qg(n,e,t,r){n.fillStyle=t;const i=Math.max(10,r*2);for(const o of e)for(let s=0;s<i;s++){const l=Math.random()*Math.PI*2,u=Math.random()*r,d=o.x+Math.cos(l)*u,p=o.y+Math.sin(l)*u;n.beginPath(),n.arc(d,p,.5,0,Math.PI*2),n.fill()}}function Jg(n,e,t,r){n.fillStyle=t;const i=Math.max(r*.8,4);let o=0;for(let s=0;s<e.length;s++){if(s===0){n.beginPath(),n.arc(e[0].x,e[0].y,r/2,0,Math.PI*2),n.fill();continue}const l=e[s].x-e[s-1].x,u=e[s].y-e[s-1].y,d=Math.sqrt(l*l+u*u);o+=d,o>=i&&(n.beginPath(),n.arc(e[s].x,e[s].y,r/2,0,Math.PI*2),n.fill(),o=0)}}function Xg(n,e,t,r){n.beginPath(),n.strokeStyle=t,n.lineWidth=r,n.lineCap="square",n.lineJoin="bevel",n.moveTo(e[0].x,e[0].y);for(let i=1;i<e.length;i++)n.lineTo(e[i].x,e[i].y);n.stroke()}function o0(n,e,t){n.lineWidth=t,n.lineCap="round",n.lineJoin="round";for(let r=1;r<e.length;r++){const i=`hsl(${ol}, 100%, 50%)`;n.beginPath(),n.strokeStyle=i,n.shadowColor=i,n.shadowBlur=t*.8,n.moveTo(e[r-1].x,e[r-1].y),n.lineTo(e[r].x,e[r].y),n.stroke(),ol=(ol+2)%360}n.shadowBlur=0}function s0(n,e,t){n.lineWidth=t,n.lineCap="round",n.lineJoin="round";let r=0;for(let i=1;i<e.length;i++){const o=`hsl(${r}, 100%, 50%)`;n.beginPath(),n.strokeStyle=o,n.shadowColor=o,n.shadowBlur=t*.8,n.moveTo(e[i-1].x,e[i-1].y),n.lineTo(e[i].x,e[i].y),n.stroke(),r=(r+2)%360}n.shadowBlur=0}function Zg(n,e,t,r){const i=r*3;let o=1/0,s=1/0,l=-1/0,u=-1/0;for(const A of e)o=Math.min(o,A.x),s=Math.min(s,A.y),l=Math.max(l,A.x),u=Math.max(u,A.y);const d=Math.ceil(l-o+i*2),p=Math.ceil(u-s+i*2),m=document.createElement("canvas");m.width=d,m.height=p;const g=m.getContext("2d");if(!g)return;const b=o-i,O=s-i;g.strokeStyle=t,g.lineWidth=r,g.lineCap="round",g.lineJoin="round",g.shadowColor=t,g.shadowBlur=r*2.5,g.beginPath(),g.moveTo(e[0].x-b,e[0].y-O);for(let A=1;A<e.length;A++)g.lineTo(e[A].x-b,e[A].y-O);g.stroke(),g.shadowBlur=r,g.stroke(),n.drawImage(m,b,O)}function a0(){const{showAll:n,showMine:e,showFollowing:t,hiddenUsers:r}=ft;if(!n)return[];const i=[];e&&i.push(...ae.map(o=>({item:o,isOtherUser:!1})));for(const o of Lr){const s=o._ownerId;s&&(r.has(s)||t&&!((On==null?void 0:On.has(s))??!1)||i.push({item:o,isOtherUser:!0}))}return i}function zi(){const n={showAll:ft.showAll,showMine:ft.showMine,showFollowing:ft.showFollowing,hiddenUsers:Array.from(ft.hiddenUsers)};localStorage.setItem("oo_visibility_prefs",JSON.stringify(n))}function l0(){try{const n=localStorage.getItem("oo_visibility_prefs");if(n){const e=JSON.parse(n);ft={showAll:e.showAll??!0,showMine:e.showMine??!0,showFollowing:e.showFollowing??!1,hiddenUsers:new Set(e.hiddenUsers??[])},console.log("[OpenOverlay] Loaded visibility prefs:",ft)}}catch{}}async function c0(){const n=ue();if(!n){On=new Set;return}try{const e=await YE(n.uid);On=new Set(e.map(t=>t.uid)),console.log("[OpenOverlay] Loaded following cache:",On.size,"users")}catch(e){console.warn("[OpenOverlay] Failed to load following cache:",e),On=new Set}}function ge(){if(!M||!se)return;M.clearRect(0,0,se.width,se.height),Me&&st&&st.clearRect(0,0,Me.width,Me.height),pt&&cr&&cr.clearRect(0,0,pt.width,pt.height);const n=window.scrollX,e=window.scrollY,t=(u,d,p=!1)=>{let m=null;try{m=document.querySelector(d.anchorSelector)}catch{}if(!m)return;const g=m.getBoundingClientRect();if(g.width===0||g.height===0)return;const b={x:g.left+n,y:g.top+e,width:g.width,height:g.height},O=M;M=u,d.type==="text"?(Ld(d,b),!p&&d.id===at&&u===O&&u0(d,b)):d.type==="shape"?Dd(d,b):Nd(d,b),M=O},r=u=>{if(!st)return;let d=null;try{d=document.querySelector(u.anchorSelector)}catch{return}if(!d)return;const p=d.getBoundingClientRect();if(p.width===0||p.height===0)return;const m={x:p.left+n,y:p.top+e,width:p.width,height:p.height},g=M;M=st,u.type==="text"?Ld(u,m):u.type==="shape"?Dd(u,m):(u.type==="stroke"||!u.type)&&Nd(u,m),M=g},i=a0(),o=i.filter(({item:u})=>u.layer==="background"),s=i.filter(({item:u})=>{const d=u.layer;return!d||d==="normal"}),l=i.filter(({item:u})=>u.layer==="foreground");if(cr)for(const{item:u,isOtherUser:d}of o)t(cr,u,d);console.log("[OpenOverlay] Rendering",s.length,"normal items to collision canvas");for(const{item:u,isOtherUser:d}of s)t(M,u,d),r(u);for(const{item:u,isOtherUser:d}of l)t(M,u,d)}function u0(n,e){if(!M)return;const t=e.x+n.x*e.width,r=e.y+n.y*e.height;M.font=`bold ${n.size||32}px Impact, Arial, sans-serif`;const o=M.measureText(n.text).width,s=n.size,l=8,u=t+o/2,d=r+s/2,p=n.rotation||0;M.save(),M.translate(u,d),M.rotate(p),M.translate(-u,-d),M.strokeStyle="#22c55e",M.lineWidth=2,M.setLineDash([5,3]),M.strokeRect(t-l,r-l,o+l*2,s+l*2),M.setLineDash([]),M.fillStyle="#22c55e";const m=8;M.fillRect(t+o+l-m/2,r+s+l-m/2,m,m);const g=r-l-Bg;M.beginPath(),M.arc(u,g,6,0,Math.PI*2),M.fill(),M.beginPath(),M.strokeStyle="#22c55e",M.setLineDash([]),M.lineWidth=2,M.moveTo(u,r-l),M.lineTo(u,g+6),M.stroke(),M.restore()}function Ld(n,e){if(!M)return;const t=e.x+n.x*e.width,r=e.y+n.y*e.height;M.save(),M.globalAlpha=n.opacity||1,M.font=`bold ${n.size||32}px Impact, Arial, sans-serif`,M.textBaseline="top";const i=n.rotation||0;if(i!==0){const o=M.measureText(n.text),s=t+o.width/2,l=r+n.size/2;M.translate(s,l),M.rotate(i),M.translate(-s,-l)}switch(n.style){case"rainbow":d0(M,n.text,t,r,n.size);break;case"aged":f0(M,n.text,t,r,n.size,n.color);break;default:h0(M,n.text,t,r,n.color)}M.restore()}function h0(n,e,t,r,i){n.strokeStyle="#000",n.lineWidth=3,n.strokeText(e,t,r),n.fillStyle=i,n.fillText(e,t,r)}function d0(n,e,t,r,i){const o=n.measureText(e).width,s=n.createLinearGradient(t,r,t+o,r);s.addColorStop(0,"hsl(0, 100%, 50%)"),s.addColorStop(.17,"hsl(60, 100%, 50%)"),s.addColorStop(.33,"hsl(120, 100%, 50%)"),s.addColorStop(.5,"hsl(180, 100%, 50%)"),s.addColorStop(.67,"hsl(240, 100%, 50%)"),s.addColorStop(.83,"hsl(300, 100%, 50%)"),s.addColorStop(1,"hsl(360, 100%, 50%)");let l=0;for(let u=0;u<e.length;u++){const d=e[u],p=n.measureText(d).width,g=(l+p/2)/o*360;n.shadowColor=`hsl(${g}, 100%, 50%)`,n.shadowBlur=i*.2,n.shadowOffsetX=0,n.shadowOffsetY=0,n.fillStyle=s,n.fillText(d,t+l,r),l+=p}n.shadowBlur=0,n.strokeStyle="#000",n.lineWidth=3,n.strokeText(e,t,r),n.fillStyle=s,n.fillText(e,t,r)}function f0(n,e,t,r,i,o){n.shadowColor="rgba(0,0,0,0.5)",n.shadowBlur=4,n.shadowOffsetX=2,n.shadowOffsetY=2,n.strokeStyle="#222",n.lineWidth=4,n.strokeText(e,t,r),n.shadowBlur=0,n.shadowOffsetX=0,n.shadowOffsetY=0;const s=n.createLinearGradient(t,r,t,r+i);s.addColorStop(0,Md(o,20)),s.addColorStop(.5,o),s.addColorStop(1,Md(o,-30)),n.fillStyle=s,n.fillText(e,t,r),n.globalAlpha=.3,n.strokeStyle="#000",n.lineWidth=1;const l=n.measureText(e).width;for(let u=0;u<5;u++){const d=t+Math.random()*l,p=r+Math.random()*i;n.beginPath(),n.moveTo(d,p),n.lineTo(d+Math.random()*10-5,p+Math.random()*10),n.stroke()}}function Md(n,e){const t=n.replace("#",""),r=Math.max(0,Math.min(255,parseInt(t.substr(0,2),16)+e)),i=Math.max(0,Math.min(255,parseInt(t.substr(2,2),16)+e)),o=Math.max(0,Math.min(255,parseInt(t.substr(4,2),16)+e));return`rgb(${r},${i},${o})`}function p0(){Xc||ae.length>0&&(ae.pop(),ge(),console.log("[OpenOverlay] Undo - items remaining:",ae.length))}async function g0(){if(Xc)return;dt==="text"?(ae=ae.filter(e=>e.type!=="text"),console.log("[OpenOverlay] Cleared text stamps (drawings preserved)")):(ae=ae.filter(e=>e.type==="text"),console.log("[OpenOverlay] Cleared drawings (text stamps preserved)"));const n=eu();ae.length>0?(localStorage.setItem(`oo_drawing_${n}`,JSON.stringify(ae)),Nl()&&await vg(n,window.location.href,ae)):(localStorage.removeItem(`oo_drawing_${n}`),Nl()&&await JE(n)),ge()}async function m0(){console.log("[OpenOverlay] Saving",ae.length,"items"),at=null;const n=eu(),e=JSON.stringify(ae);localStorage.setItem(`oo_drawing_${n}`,e),Nl()&&await vg(n,window.location.href,ae),ge(),console.log("[OpenOverlay] Drawing saved")}function y0(){console.log("[OpenOverlay] Canceling drawing"),Zc()}async function Zc(){const n=eu();if(bi()){if(XE(n,i=>{ae=i.myItems,Lr=i.otherItems,as=i.contributors,localStorage.setItem(`oo_drawing_${n}`,JSON.stringify(ae)),console.log("[OpenOverlay] Real-time update:",ae.length,"mine,",Lr.length,"from others"),i.contributors.length>0&&console.log("[OpenOverlay] Contributors:",i.contributors.map(o=>o.displayName).join(", ")),document.dispatchEvent(new CustomEvent("oo:contributors",{detail:{contributors:as}})),ge()})){console.log("[OpenOverlay] Subscribed to real-time drawing updates");return}console.log("[OpenOverlay] Real-time subscription failed, trying one-time fetch");const r=await QE(n);if(r!==null){ae=r.myItems,Lr=r.otherItems,as=r.contributors,localStorage.setItem(`oo_drawing_${n}`,JSON.stringify(ae)),console.log("[OpenOverlay] Loaded from cloud:",ae.length,"mine,",Lr.length,"from others"),document.dispatchEvent(new CustomEvent("oo:contributors",{detail:{contributors:as}})),ge();return}}Lr=[];const e=localStorage.getItem(`oo_drawing_${n}`);if(e)try{ae=JSON.parse(e),console.log("[OpenOverlay] Loaded",ae.length,"items from localStorage"),ge()}catch{console.warn("[OpenOverlay] Failed to load drawings"),ae=[]}else ae=[]}function eu(){return btoa(window.location.href).slice(0,32)}function v0(){Tg(n=>{n?(console.log("[OpenOverlay] User logged in, reloading drawings from cloud"),c0()):(console.log("[OpenOverlay] User logged out, reloading public drawings"),On=null),Zc()})}function cs(n,e,t,r,i){if(!Me||!st)return{floor:!1,floorY:0,ceiling:!1,ceilingY:0,leftWall:!1,leftWallX:0,rightWall:!1,rightWallX:0,slopeAngle:0,slopeAheadY:0};const o=window.devicePixelRatio||1;let s=!1,l=0,u=!1,d=0,p=!1,m=0,g=!1,b=0,O=0,A=0;const P=Math.max(1,Math.floor(t*.5*o)),V=Math.floor((n+t/2)*o),$=Math.max(0,V-Math.floor(P/2));try{const U=e+r,G=Math.floor((U-5)*o),z=Math.floor(20*o);if($>=0&&G>=0&&$+P<=Me.width&&G+z<=Me.height){const tt=st.getImageData($,G,P,z);for(let le=0;le<z;le++){let xe=!1;for(let ye=0;ye<P;ye++){const Qe=(le*P+ye)*4;if(tt.data[Qe+3]>30){xe=!0;break}}if(xe){const ye=G/o+le/o;ye>=U-8&&(s=!0,l=ye);break}}}const J=e,E=Math.max(0,Math.floor((J-15)*o)),v=Math.floor(15*o);if($>=0&&E>=0&&$+P<=Me.width&&E+v<=Me.height){const tt=st.getImageData($,E,P,v);for(let le=v-1;le>=0;le--){let xe=!1;for(let ye=0;ye<P;ye++){const Qe=(le*P+ye)*4;if(tt.data[Qe+3]>30){xe=!0;break}}if(xe){const ye=E/o+(le+1)/o;ye<=J+5&&(u=!0,d=ye);break}}}const w=Math.floor(e*o),I=Math.floor(r*.85*o),T=Math.floor(10*o),S=Math.max(0,Math.floor(n*o)-T);if(S>=0&&w>=0&&S+T<=Me.width&&w+I<=Me.height){const tt=st.getImageData(S,w,T,I);e:for(let le=T-1;le>=0;le--)for(let xe=0;xe<I;xe++){const ye=(xe*T+le)*4;if(tt.data[ye+3]>30){p=!0,m=(S+le+1)/o;break e}}}const _=Math.floor((n+t)*o);if(_>=0&&w>=0&&_+T<=Me.width&&w+I<=Me.height){const tt=st.getImageData(_,w,T,I);e:for(let le=0;le<T;le++)for(let xe=0;xe<I;xe++){const ye=(xe*T+le)*4;if(tt.data[ye+3]>30){g=!0,b=(_+le)/o;break e}}}const Se=e+r,et=20,xr=i!==!1?n+t+et:n-et,vn=Math.floor(xr*o),vt=Math.floor((Se-30)*o),wt=Math.floor(50*o);if(vn>=0&&vn<Me.width&&vt>=0&&vt+wt<=Me.height){const tt=st.getImageData(vn,vt,1,wt);for(let le=0;le<wt;le++)if(tt.data[le*4+3]>30){A=vt/o+le/o;const Qe=(s?l:Se)-A;O=Math.atan2(Qe,et)*(180/Math.PI);break}}}catch{}return{floor:s,floorY:l,ceiling:u,ceilingY:d,leftWall:p,leftWallX:m,rightWall:g,rightWallX:b,slopeAngle:O,slopeAheadY:A}}let ve=null,c=null,gt=null,Z=null,Pe="none",bo="spawn",k={x:100,y:100,vx:0,vy:0,width:30,height:50,onGround:!1,facingRight:!0,animFrame:0,jumpsRemaining:2,maxJumps:2},Vd=!1,us=0,hs=0,Yt=!1,Ss=0,Fd=0;const _0=12e4,w0=2e3;let Ot=localStorage.getItem("oo_player_color")||"#ffffff",To=localStorage.getItem("oo_player_hat")||"none",Eo=localStorage.getItem("oo_player_accessory")||"none",tu=localStorage.getItem("oo_player_girl")==="true",oo=[],Ft=new Map,Cn=new Map,al=0,Ud=0,qd=0;const b0=80;let Oe=!1,Nn=null,sn=0,Te=!1,Qt=null,Dn=null,pr=0;const Js=3e3,em=5e3,tm=3e3;let ql=0;const T0=5e3;function Io(){const n=ue();return n?Nn!=null&&Nn.gameActive?Nn.itPlayerId===n.uid:Te:!1}let he={id:cm(),name:"New Course",checkpoints:[],authorId:"local-user",authorName:"You",createdAt:Date.now()};const E0=.6,$d=-14,Bd=5,I0=.7,Jt={};let Fr=null,$l=0,ct=!1,Bl=0,Ti=0,ir=0,$n=3,nu=3,an=!1,jl=0;const jd=2e3,A0=2e3;let ru=0,Xs=!1,St="explore",ln=!1,iu=0;const nm=2e3;let Ie=null,rt=null,Jr=!1,Mt=0,so=localStorage.getItem("oo_player_name")||"";function S0(){console.log("[OpenOverlay] initGame starting..."),ve=document.createElement("canvas"),ve.id="oo-game-canvas",ve.style.cssText=`
    position: absolute;
    top: 0;
    left: 0;
    z-index: 2147483638;
    pointer-events: none;
  `,document.body.appendChild(ve),c=ve.getContext("2d"),gt=document.createElement("canvas"),gt.id="oo-overlay-canvas",gt.style.cssText=`
    position: absolute;
    top: 0;
    left: 0;
    z-index: 2147483646;
    pointer-events: none;
  `,document.body.appendChild(gt),Z=gt.getContext("2d"),ll(),window.addEventListener("resize",ll),new ResizeObserver(ll).observe(document.body),document.addEventListener("keydown",H0),document.addEventListener("keyup",G0),document.addEventListener("oo:gamemode",t=>{zd(t.detail.mode,t.detail.tool,t.detail.playmode)}),document.addEventListener("oo:undo",()=>{Pe==="build"&&he.checkpoints.length>0&&(he.checkpoints.pop(),fi(),ot())}),document.addEventListener("oo:clear",()=>{Pe==="build"&&(he.checkpoints=[],fi(),ot())}),document.addEventListener("oo:playercolor",t=>{Ot=t.detail.color,localStorage.setItem("oo_player_color",Ot),ot()}),document.addEventListener("oo:playerstyle",t=>{tu=t.detail.isGirl,ot()}),document.addEventListener("oo:playerhat",t=>{To=t.detail.hat,localStorage.setItem("oo_player_hat",To),ot()}),document.addEventListener("oo:playeraccessory",t=>{Eo=t.detail.accessory,localStorage.setItem("oo_player_accessory",Eo),ot()}),document.addEventListener("oo:toggletag",()=>{console.log("[OpenOverlay] Tag toggle requested, gameMode:",Pe),Pe!=="play"&&(console.log("[OpenOverlay] Auto-switching to play mode for tag"),zd("play","explore")),tA()}),ve.addEventListener("pointerdown",Y0),ve.addEventListener("pointermove",Q0),ve.addEventListener("pointerup",J0),ve.addEventListener("contextmenu",t=>{Pe==="build"&&t.preventDefault()}),X0(),ot();const e=()=>{Pe==="play"&&(bg(),wg(gn()))};window.addEventListener("beforeunload",e),window.addEventListener("pagehide",e),document.addEventListener("visibilitychange",()=>{document.hidden&&Pe==="play"&&Ea()}),console.log("[OpenOverlay] Game initialized")}function ll(){if(!ve||!c)return;const n=Math.max(document.body.scrollWidth,document.body.offsetWidth,document.documentElement.scrollWidth,document.documentElement.offsetWidth),e=Math.max(document.body.scrollHeight,document.body.offsetHeight,document.documentElement.scrollHeight,document.documentElement.offsetHeight),t=window.devicePixelRatio||1;ve.style.width=`${n}px`,ve.style.height=`${e}px`,ve.width=n*t,ve.height=e*t,c.scale(t,t),gt&&Z&&(gt.style.width=`${n}px`,gt.style.height=`${e}px`,gt.width=n*t,gt.height=e*t,Z.scale(t,t)),ot()}function zd(n,e,t){if(Pe=n,e&&(bo=e),t&&(St=t),ve&&(ve.style.pointerEvents=n==="build"?"auto":"none",ve.style.cursor=n==="build"?"crosshair":"default"),n==="play"){ct=!1,Ti=0,ir=0,he.checkpoints.forEach(i=>i.reached=!1),$n=nu,an=!1,ln=!1,Ie=null,Jr=!1;const r=gn();console.log("[OpenOverlay] Subscribing to players on page:",r),oI(r,i=>{if(Ft=i,i.size>0&&(console.log("[OpenOverlay] Received",i.size,"other players"),i.forEach((o,s)=>{console.log("[OpenOverlay] Player",s,"at",o.x,o.y)}),Oe)){const o=ue(),s=Date.now();let l=null;for(const[p,m]of i)m.taggedPlayerId===(o==null?void 0:o.uid)&&m.taggedAt&&s-m.taggedAt<em&&!Te&&s>sn&&(console.log("[OpenOverlay] EXPLICITLY TAGGED by:",p,"via taggedPlayerId"),Te=!0,Qt=p,sn=s+Js,xt("You're IT!","Tag someone!",2e3),zl(),document.dispatchEvent(new CustomEvent("oo:tagstatechange",{detail:{isTagMode:!0,isIt:!0,gameActive:!0}})));for(const[p,m]of i){if(console.log("[OpenOverlay] Checking player",p,"isIt:",m.isIt),m.isIt){l=p,console.log("[OpenOverlay] Found IT player in sync:",m.displayName,"id:",p);break}p===Qt&&!m.isIt&&(console.log("[OpenOverlay] Clearing lastTaggedByPlayerId - sync caught up"),Qt=null)}const u=s<sn,d=l===Qt;l&&Te&&o&&!u&&!d?l<o.uid?(console.log("[OpenOverlay] Tiebreaker: other player wins (lower ID), giving up IT"),Te=!1,Qt=null,document.dispatchEvent(new CustomEvent("oo:tagstatechange",{detail:{isTagMode:!0,isIt:!1,gameActive:!0}}))):console.log("[OpenOverlay] Tiebreaker: we win (lower ID), keeping IT"):l&&Te&&u?console.log("[OpenOverlay] Skipping tiebreaker - in tag cooldown"):l&&Te&&d?console.log("[OpenOverlay] Skipping tiebreaker - was tagged by this player (stale sync)"):l&&!Te&&console.log("[OpenOverlay] Other player is IT, we are not")}}),sI(r,i=>{const o=Nn;Nn=i,console.log("[OpenOverlay] Tag game state changed:",i);const s=ue(),l=(i==null?void 0:i.itPlayerId)===(s==null?void 0:s.uid);document.dispatchEvent(new CustomEvent("oo:tagstatechange",{detail:{isTagMode:Oe,isIt:l,gameActive:(i==null?void 0:i.gameActive)??!1}})),i!=null&&i.gameActive&&(console.log('[OpenOverlay] Tag game active, "it" is:',i.itPlayerId),(o==null?void 0:o.itPlayerId)!==i.itPlayerId&&(l?xt("You're IT!","Tag someone!",2e3):(o==null?void 0:o.itPlayerId)===(s==null?void 0:s.uid)&&xt("You're not IT!","Run away!",2e3)))}),om(),St==="race"&&document.dispatchEvent(new CustomEvent("oo:hidetoolbar")),x0()}else n==="build"?(Jr=!1,ln=!1,Ie=null,Oe=!1,Te=!1,Qt=null,Dn=null,pr=0,Nn=null):(Jr=!1,ln=!1,Ie=null,bg(),aI(),wg(gn()),Ft.clear(),Cn.clear(),Oe=!1,Te=!1,Qt=null,Dn=null,pr=0,Nn=null);ot()}function x0(){Fr&&(cancelAnimationFrame(Fr),Fr=null),$l=performance.now(),Fr=requestAnimationFrame(rm)}function rm(n){const e=Math.min((n-$l)/16.67,3);$l=n,P0(e),ot(),Pe==="play"||Pe==="build"?Fr=requestAnimationFrame(rm):Fr=null}function im(){const n=he.checkpoints.find(r=>r.type==="spawn"),e=he.checkpoints.find(r=>r.type==="start"),t=n||e;t?(k.x=t.x-k.width/2,k.y=t.y-k.height-10):(k.x=window.scrollX+window.innerWidth/2-k.width/2,k.y=window.scrollY+100),k.vx=0,k.vy=0,k.onGround=!1,k.jumpsRemaining=k.maxJumps}function om(){if(im(),St==="explore"){ln=!1,ct=!1,xt("Explore!","No timer, unlimited respawns",2e3);return}ln=!0,iu=performance.now(),xt("Get Ready!","2")}function xt(n,e,t=1e3){Ie={text:n,subtext:e,endTime:performance.now()+t}}function zl(){ql=performance.now()+tm}function sm(n){rt&&Wi();const{top10:e}=eA();rt=document.createElement("div"),rt.id="oo-game-popup",rt.style.cssText=`
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background: rgba(0,0,0,0.7);
    z-index: 2147483647;
    display: flex;
    align-items: center;
    justify-content: center;
    font-family: system-ui, -apple-system, sans-serif;
  `;const t=n==="finish",r=t?"🏆 RACE COMPLETE!":"💀 GAME OVER",i=t?"#22c55e":"#ef4444",o=(Ti/1e3).toFixed(2),s=t&&Mt===he.bestTime;let l="";e.length>0&&(l=`
      <div style="margin-top: 15px; max-height: 200px; overflow-y: auto;">
        <div style="color: #fbbf24; font-weight: bold; margin-bottom: 8px;">🏆 Today's Best</div>
        ${e.slice(0,5).map((g,b)=>`
          <div style="display: flex; justify-content: space-between; color: ${b<3?["#fbbf24","#c0c0c0","#cd7f32"][b]:"#888"}; font-size: 13px; padding: 2px 0;">
            <span>${b+1}. ${g.name.slice(0,10)}</span>
            <span>${(g.time/1e3).toFixed(2)}s</span>
          </div>
        `).join("")}
      </div>
    `);const u=document.createElement("div");u.style.cssText=`
    background: #111;
    border: 3px solid ${i};
    border-radius: 12px;
    padding: 25px 35px;
    text-align: center;
    min-width: 300px;
    max-width: 400px;
    box-shadow: 0 10px 40px rgba(0,0,0,0.8);
  `,u.innerHTML=`
    <div style="color: ${i}; font-size: 24px; font-weight: bold; margin-bottom: 15px;">${r}</div>
    <div style="color: #fff; font-size: 40px; font-weight: bold; font-family: monospace;">${o}s</div>
    ${s?'<div style="color: #fbbf24; font-size: 14px; margin-top: 5px;">⭐ NEW PERSONAL BEST!</div>':""}
    ${t?`
      <div style="margin-top: 15px;">
        <input type="text" id="oo-popup-name" placeholder="Enter name..." value="${so}"
          style="padding: 8px 12px; border-radius: 6px; border: 2px solid #333; background: #222; color: #fff; font-size: 14px; width: 180px; text-align: center;">
      </div>
    `:""}
    ${l}
    <div style="display: flex; gap: 10px; justify-content: center; margin-top: 20px;">
      <button id="oo-popup-retry" style="padding: 10px 25px; background: ${i}; color: white; border: none; border-radius: 8px; font-size: 14px; font-weight: bold; cursor: pointer;">
        🔄 Retry
      </button>
      <button id="oo-popup-close" style="padding: 10px 25px; background: #333; color: white; border: none; border-radius: 8px; font-size: 14px; font-weight: bold; cursor: pointer;">
        ✕ Close
      </button>
    </div>
  `,rt.appendChild(u),document.body.appendChild(rt);const d=rt.querySelector("#oo-popup-retry"),p=rt.querySelector("#oo-popup-close"),m=rt.querySelector("#oo-popup-name");d==null||d.addEventListener("click",()=>{t&&m&&m.value.trim()&&ds(m.value.trim(),Mt),Wi(),Wd()}),p==null||p.addEventListener("click",()=>{t&&m&&m.value.trim()&&ds(m.value.trim(),Mt),Wi(),Hd()}),rt.addEventListener("click",g=>{g.target===rt&&(t&&m&&m.value.trim()&&ds(m.value.trim(),Mt),Wi(),Hd())}),m==null||m.focus(),m==null||m.addEventListener("keydown",g=>{g.key==="Enter"&&m.value.trim()&&(ds(m.value.trim(),Mt),Wi(),Wd())})}function Wi(){rt&&(rt.remove(),rt=null)}function Wd(){ct=!1,Ti=0,ir=0,he.checkpoints.forEach(n=>n.reached=!1),$n=nu,an=!1,Jr=!1,oo=[],om()}function Hd(){document.dispatchEvent(new CustomEvent("oo:gamemode",{detail:{mode:"build"}})),ct=!1,Jr=!1}function am(){an||(an=!0,jl=performance.now(),St==="race"&&ct&&($n--,console.log("[OpenOverlay] Died! Lives remaining:",$n)))}let Gd=!1;function k0(){const n=performance.now();for(const[t,r]of Ft){let i=Cn.get(t);if(!i){i={x:r.x,y:r.y,vx:r.vx,vy:r.vy,lastSyncTime:n,targetX:r.x,targetY:r.y},Cn.set(t,i);continue}const o=Math.abs(r.x-i.targetX)>.1||Math.abs(r.y-i.targetY)>.1,s=Math.abs(r.vx-i.vx)>.1||Math.abs(r.vy-i.vy)>.1;if(o||s){i.vx=r.vx,i.vy=r.vy,i.lastSyncTime=n;const m=5;i.targetX=r.x+r.vx*m,i.targetY=r.y+r.vy*m}i.x+=i.vx*.5,i.y+=i.vy*.5;const l=.12,u=i.targetX-i.x,d=i.targetY-i.y;(Math.abs(u)>1||Math.abs(d)>1)&&(i.x+=u*l,i.y+=d*l),Math.sqrt(u*u+d*d)>150&&(i.x=r.x,i.y=r.y)}for(const t of Cn.keys())Ft.has(t)||Cn.delete(t);const e=Date.now();for(const[t,r]of Ft)r.updatedAt&&e-r.updatedAt>T0&&(console.log("[OpenOverlay] Removing stale player:",t),Ft.delete(t),Cn.delete(t))}function P0(n){if(Pe!=="play")return;if(k0(),ln){const V=performance.now()-iu,$=nm-V;$>1e3?Ie={text:"Get Ready!",subtext:"2",endTime:performance.now()+100}:$>0?Ie={text:"Get Ready!",subtext:"1",endTime:performance.now()+100}:(ln=!1,Ie={text:"GO!",endTime:performance.now()+500},St==="race"&&(ct=!0,Bl=performance.now()));return}if(an){const V=jd-(performance.now()-jl);if(V>0&&(Ie={text:"You fell!",subtext:`Respawning in ${Math.ceil(V/1e3)}...`,endTime:performance.now()+100}),performance.now()-jl>=jd){if(St==="race"&&$n<=0){ct=!1,an=!1,sm("gameover");return}an=!1,im(),Ie=null}return}Ie&&performance.now()>Ie.endTime&&(Ie=null);const t=performance.now()<ru?Bd*2:Bd;if(Jt.ArrowLeft||Jt.KeyA)k.vx=-t,k.facingRight=!1,hs=performance.now(),Yt=!1;else if(Jt.ArrowRight||Jt.KeyD)k.vx=t,k.facingRight=!0,hs=performance.now(),Yt=!1;else{const V=us>0?.92:I0;k.vx*=V,Math.abs(k.vx)<.1&&(k.vx=0)}us>0&&us--,k.onGround&&Math.abs(k.vx)<.1?(performance.now()-hs>_0&&!Yt&&(Yt=!0,Fd=performance.now(),Ss=0),Yt&&(performance.now()-Fd<w0?Ss+=.15:(Yt=!1,hs=performance.now()))):(Yt=!1,Ss=0);const r=Jt.ArrowUp||Jt.KeyW||Jt.Space;if(r&&!Gd&&k.jumpsRemaining>0){const V=Xs?$d*1.5:$d;k.vy=V,k.onGround=!1,k.jumpsRemaining--,Xs=!1}Gd=r,k.vy+=E0*n;const i=50,o=k.x+k.vx*n,s=k.y+k.vy*n,l=k.vx>=0,u=cs(o,k.y,k.width,k.height,l);let d=!0;k.vx<0&&u.leftWall&&(k.x=u.leftWallX,k.vx=0,d=!1),k.vx>0&&u.rightWall&&(k.x=u.rightWallX-k.width,k.vx=0,d=!1),d&&Math.abs(k.vx)>.5&&u.slopeAheadY>0&&u.slopeAngle>i&&(k.vx=0,d=!1);let p=!0;if(k.vy<0){const V=cs(k.x,s,k.width,k.height,l);V.ceiling&&(k.y=V.ceilingY,k.vy=1,p=!1)}d&&(k.x+=k.vx*n),p&&(k.y+=k.vy*n);const m=cs(k.x,k.y,k.width,k.height,l);k.vy<0&&m.ceiling&&(k.y=m.ceilingY,k.vy=1);const g=m.leftWall&&k.x<m.leftWallX,b=m.rightWall&&k.x+k.width>m.rightWallX;if(g&&b){const V=m.leftWallX-k.x,$=k.x+k.width-m.rightWallX;V<$?k.x=m.leftWallX:k.x=m.rightWallX-k.width,k.vx=0}else g?(k.x=m.leftWallX,k.vx=0):b&&(k.x=m.rightWallX-k.width,k.vx=0);if(k.onGround=!1,k.vy>=0&&m.floor){const V=m.floorY-k.height,$=k.y-V,G=k.vy>5?0:8;$<=G&&(!Vd&&Math.abs(k.vx)>.5&&(us=8),k.y=V,k.vy=0,k.onGround=!0,k.jumpsRemaining=k.maxJumps)}if(k.onGround&&Math.abs(k.vx)>.5){const V=Math.abs(k.vx),$=Math.min(3,Math.ceil(V*.3));for(let U=1;U<=$;U++){const G=k.y-U,z=cs(k.x,G,k.width,k.height,l);if(z.floor&&!z.leftWall&&!z.rightWall){const J=z.floorY-k.height,E=k.y-J;if(E>0&&E<=$){k.y=J;break}}}}Vd=k.onGround;const O=Math.max(document.body.scrollHeight,window.innerHeight),A=Math.max(document.body.scrollWidth,window.innerWidth);(k.y>O+A0||k.x<-100||k.x>A+100)&&am(),Math.abs(k.vx)>.5?k.animFrame=(k.animFrame+.15*n)%4:k.animFrame=0,C0(),R0(),Oe&&O0(),ct&&St==="race"&&(Ti=performance.now()-Bl);const P=performance.now();if(Pe==="play"&&P-al>b0){const V=Math.abs(k.x-Ud)>5||Math.abs(k.y-qd)>5,$=P-al>5e3;(V||$)&&(al=P,Ud=k.x,qd=k.y,Ea())}}function Ea(){const n=gn(),e=ue(),t=Oe&&Io();Oe&&console.log("[OpenOverlay] Syncing player with isIt:",t,"isTagMode:",Oe,"localIsIt:",Te);const r=Date.now();Dn&&r-pr>em&&(Dn=null,pr=0);const i={x:k.x,y:k.y+k.height,vx:k.vx,vy:k.vy,facingRight:k.facingRight,animFrame:k.animFrame,onGround:k.onGround,isDead:an,playerColor:Ot,playerHat:To,playerAccessory:Eo,isGirlMode:tu,displayName:(e==null?void 0:e.displayName)||"",updatedAt:r,isIt:Oe&&Io(),tagCooldownUntil:sn};Dn&&(i.taggedPlayerId=Dn,i.taggedAt=pr),iI(n,i)}function C0(){if(St!=="race")return;const n=he.checkpoints.filter(e=>e.type==="checkpoint").length;for(const e of he.checkpoints){if(e.reached)continue;const t=k.x+k.width/2,r=k.y+k.height/2;if(Math.hypot(t-e.x,r-e.y)<50)if(e.type==="start"&&!ct)ct=!0,Bl=performance.now(),e.reached=!0,console.log("[OpenOverlay] Race started!");else if(e.type==="checkpoint"&&ct){const o=ir+1;e.order===o&&(e.reached=!0,ir++,console.log("[OpenOverlay] Checkpoint",ir,"of",n,"reached!"),xt(`Flag ${ir}/${n}`,"",1500))}else e.type==="finish"&&ct&&ir>=n&&(e.reached=!0,ct=!1,Mt=Ti,console.log("[OpenOverlay] Race finished! Time:",(Mt/1e3).toFixed(2)+"s"),(!he.bestTime||Mt<he.bestTime)&&(he.bestTime=Mt,fi()),sm("finish"),document.dispatchEvent(new CustomEvent("oo:racefinish",{detail:{time:Mt,bestTime:he.bestTime}})))}}function R0(){for(const n of he.checkpoints){if(!["trampoline","speedBoost","highJump","spike"].includes(n.type))continue;const e=n.width||60,t=n.height||20,r=n.x-e/2,i=n.x+e/2,o=n.y-t,s=n.y,l=k.x,u=k.x+k.width,d=k.y,p=k.y+k.height;if(u>r&&l<i&&p>o&&d<s)switch(n.type){case"trampoline":k.vy>0&&(k.vy=-20,k.onGround=!1,k.jumpsRemaining=k.maxJumps);break;case"speedBoost":ru=performance.now()+3e3;break;case"highJump":Xs=!0;break;case"spike":an||(oo.push({x:k.x+k.width/2,y:k.y+k.height,createdAt:performance.now()}),am());break}}}function O0(){if(!Oe||!ue())return;const e=Date.now(),t=gn(),r=k.x+k.width/2,i=k.y+k.height,o=Io();for(const[s,l]of Ft){const u=Cn.get(s),d=u?u.x:l.x,p=u?u.y:l.y,m=r-d,g=i-p;if(Math.sqrt(m*m+g*g)<40){const O=e>sn,A=!l.tagCooldownUntil||e>l.tagCooldownUntil;o&&O&&A&&(console.log("[OpenOverlay] TAGGING player:",s),Te=!1,Dn=s,pr=e,cI(t,s).catch(()=>{console.log("[OpenOverlay] Firebase tag update failed, using local state")}),sn=e+Js,xt("Tagged!",l.displayName||"Player",1500),zl(),document.dispatchEvent(new CustomEvent("oo:tagstatechange",{detail:{isTagMode:!0,isIt:!1,gameActive:!0}})),Ea());const P=!l.tagCooldownUntil||e>l.tagCooldownUntil;!o&&l.isIt&&O&&P&&(console.log("[OpenOverlay] GOT TAGGED by:",s),Te=!0,sn=e+Js,Qt=s,xt("You're IT!","Tag someone!",2e3),zl(),document.dispatchEvent(new CustomEvent("oo:tagstatechange",{detail:{isTagMode:!0,isIt:!0,gameActive:!0}})))}}}function ot(){if(!(!c||!ve)){c.clearRect(0,0,ve.width,ve.height),Z&&gt&&Z.clearRect(0,0,gt.width,gt.height),N0();for(const n of he.checkpoints)D0(n);(Pe==="play"||Pe==="build")&&(L0(),F0(),Pe==="play"&&B0()),Pe==="build"&&W0()}}function N0(){if(!c)return;const n=performance.now(),e=5e3;oo=oo.filter(t=>n-t.createdAt<e);for(const t of oo){const r=n-t.createdAt,i=Math.max(0,1-r/e);c.save(),c.globalAlpha=i,c.fillStyle="#dc2626",c.beginPath(),c.arc(t.x,t.y,12,0,Math.PI*2),c.fill(),c.fillStyle="#b91c1c";for(let o=0;o<5;o++){const s=o/5*Math.PI*2+Math.random()*.5,l=15+Math.random()*10,u=Math.cos(s)*l,d=Math.sin(s)*l*.5;c.beginPath(),c.arc(t.x+u,t.y+d,4+Math.random()*3,0,Math.PI*2),c.fill()}c.restore()}}function D0(n){if(!c)return;const e=n.x,t=n.y;if(c.save(),n.type==="start"){const r=n.reached?"#86efac":"#22c55e",i=80,o=70;c.strokeStyle="#444",c.lineWidth=6,c.beginPath(),c.moveTo(e-i/2,t),c.lineTo(e-i/2,t-o),c.stroke(),c.beginPath(),c.moveTo(e+i/2,t),c.lineTo(e+i/2,t-o),c.stroke(),c.fillStyle=r,c.fillRect(e-i/2-3,t-o-15,i+6,20),c.strokeStyle="#166534",c.lineWidth=2,c.strokeRect(e-i/2-3,t-o-15,i+6,20),c.fillStyle="#fff",c.font="bold 14px sans-serif",c.textAlign="center",c.fillText("START",e,t-o-1)}else if(n.type==="finish"){c.strokeStyle="#444",c.lineWidth=6,c.beginPath(),c.moveTo(e-80/2,t),c.lineTo(e-80/2,t-70),c.stroke(),c.beginPath(),c.moveTo(e+80/2,t),c.lineTo(e+80/2,t-70),c.stroke();const o=t-70-15,s=20,l=8;c.fillStyle=n.reached?"#fbbf24":"#111",c.fillRect(e-80/2-3,o,86,s);for(let u=0;u<Math.ceil(86/l);u++)for(let d=0;d<Math.ceil(s/l);d++)(u+d)%2===0&&(c.fillStyle="#fff",c.fillRect(e-80/2-3+u*l,o+d*l,l,Math.min(l,s-d*l)));c.strokeStyle="#444",c.lineWidth=2,c.strokeRect(e-80/2-3,o,86,s),c.fillStyle="#fff",c.font="bold 11px sans-serif",c.textAlign="center",c.fillText("FINISH",e,t+15)}else if(n.type==="spawn"){if(Pe!=="build"){c.restore();return}const r="#a855f7";c.fillStyle=r,c.beginPath(),c.moveTo(e,t-20),c.lineTo(e-10,t-35),c.lineTo(e+10,t-35),c.closePath(),c.fill(),c.strokeStyle=r,c.lineWidth=2,c.beginPath(),c.arc(e,t-55,8,0,Math.PI*2),c.stroke(),c.beginPath(),c.moveTo(e,t-47),c.lineTo(e,t-30),c.stroke(),c.beginPath(),c.moveTo(e-10,t-42),c.lineTo(e+10,t-42),c.stroke(),c.beginPath(),c.moveTo(e,t-30),c.lineTo(e-8,t-15),c.moveTo(e,t-30),c.lineTo(e+8,t-15),c.stroke(),c.fillStyle="#fff",c.font="bold 10px sans-serif",c.textAlign="center",c.fillText("SPAWN",e,t+5)}else if(n.type==="trampoline"){const r=n.width||60,i=n.height||20;c.fillStyle="#f97316",c.fillRect(e-r/2,t-i,r,i),c.strokeStyle="#c2410c",c.lineWidth=2,c.strokeRect(e-r/2,t-i,r,i),c.strokeStyle="#c2410c",c.lineWidth=2;const o=3,s=r/o;for(let l=0;l<o;l++){const u=e-r/2+s/2+l*s;c.beginPath(),c.moveTo(u,t),c.lineTo(u-4,t-i/3),c.lineTo(u+4,t-i*2/3),c.lineTo(u,t-i),c.stroke()}}else if(n.type==="speedBoost"){const r=n.width||60,i=n.height||20,o=performance.now()<ru;c.fillStyle=o?"#60a5fa":"#3b82f6",c.fillRect(e-r/2,t-i,r,i),c.strokeStyle="#1d4ed8",c.lineWidth=2,c.strokeRect(e-r/2,t-i,r,i),c.fillStyle="#fff",c.font="bold 14px sans-serif",c.textAlign="center",c.textBaseline="middle",c.fillText(">>",e,t-i/2)}else if(n.type==="highJump"){const r=n.width||60,i=n.height||20,o=Xs;c.fillStyle=o?"#86efac":"#22c55e",c.fillRect(e-r/2,t-i,r,i),c.strokeStyle="#15803d",c.lineWidth=2,c.strokeRect(e-r/2,t-i,r,i),c.fillStyle="#fff",c.font="bold 16px sans-serif",c.textAlign="center",c.textBaseline="middle",c.fillText("^",e,t-i/2)}else if(n.type==="spike"){const r=n.width||60,i=n.height||30,o=4,s=r/o;c.fillStyle="#ef4444";for(let l=0;l<o;l++){const u=e-r/2+l*s;c.beginPath(),c.moveTo(u,t),c.lineTo(u+s/2,t-i),c.lineTo(u+s,t),c.closePath(),c.fill()}c.strokeStyle="#991b1b",c.lineWidth=1;for(let l=0;l<o;l++){const u=e-r/2+l*s;c.beginPath(),c.moveTo(u,t),c.lineTo(u+s/2,t-i),c.lineTo(u+s,t),c.closePath(),c.stroke()}}else if(n.type==="checkpoint"){const r=n.reached?"#fbbf24":"#3b82f6";c.strokeStyle="#444",c.lineWidth=4,c.beginPath(),c.moveTo(e,t),c.lineTo(e,t-50),c.stroke(),c.fillStyle=r,c.beginPath(),c.moveTo(e,t-50),c.lineTo(e+35,t-40),c.lineTo(e,t-30),c.closePath(),c.fill(),c.fillStyle="#fff",c.font="bold 12px sans-serif",c.textAlign="center",c.textBaseline="middle",c.fillText(String(n.order),e+15,t-40)}c.restore()}function L0(){if(c)for(const[n,e]of Ft){const t=`logged_${n}`;window[t]||(window[t]=!0,console.log("[OpenOverlay] Remote player data:",n,JSON.stringify({isGirlMode:e.isGirlMode,playerHat:e.playerHat,playerColor:e.playerColor,displayName:e.displayName,playerAccessory:e.playerAccessory,isIt:e.isIt}))),M0(n,e)}}function M0(n,e){if(!c||e.isDead)return;const t=Cn.get(n),r=t?t.x:e.x,i=t?t.y:e.y,o=30,s=50,l=r,u=i-s;c.save(),c.globalAlpha=.85,e.facingRight||(c.translate(l+o/2,0),c.scale(-1,1),c.translate(-(l+o/2),0));const d=9,p=18,m=14,g=l+o/2,b=u+d+3,O=b+d,A=O+p,P=e.playerColor||"#ffffff";c.strokeStyle=P,c.lineWidth=3,c.lineCap="round",c.lineJoin="round",c.shadowColor="rgba(0,0,0,0.3)",c.shadowBlur=4,c.shadowOffsetX=2,c.shadowOffsetY=2;const V=Math.abs(e.vx)>.5,$=e.animFrame||0;if(e.isGirlMode){c.fillStyle=P,c.beginPath(),c.moveTo(g-d-2,b+8),c.lineTo(g-d-1,b-2),c.quadraticCurveTo(g-d+2,b-d-4,g,b-d-3),c.quadraticCurveTo(g+d-2,b-d-4,g+d+1,b-2),c.lineTo(g+d+2,b+8),c.quadraticCurveTo(g+d,b+10,g+d-2,b+10),c.lineTo(g-d+2,b+10),c.quadraticCurveTo(g-d,b+10,g-d-2,b+8),c.closePath(),c.fill(),c.fillStyle="#fff",c.beginPath(),c.arc(g,b,d-1,0,Math.PI*2),c.fill(),c.fillStyle=P,c.beginPath(),c.moveTo(g-d+2,b-2),c.quadraticCurveTo(g-2,b-d-2,g,b-d+1),c.quadraticCurveTo(g+2,b-d-2,g+d-2,b-2),c.quadraticCurveTo(g,b-1,g-d+2,b-2),c.closePath(),c.fill(),c.fillStyle=P,V?(c.beginPath(),c.arc(g+2,b,1.5,0,Math.PI*2),c.fill(),c.lineWidth=2,c.beginPath(),c.moveTo(g,b+4),c.lineTo(g+4,b+4),c.stroke(),c.lineWidth=3):(c.beginPath(),c.arc(g-3,b,1.5,0,Math.PI*2),c.fill(),c.beginPath(),c.arc(g+3,b,1.5,0,Math.PI*2),c.fill(),c.lineWidth=1.5,c.beginPath(),c.arc(g,b+3,2.5,.2*Math.PI,.8*Math.PI),c.stroke(),c.lineWidth=3),c.fillStyle=P,c.beginPath(),c.moveTo(g,O),c.lineTo(g-10,A+2),c.lineTo(g+10,A+2),c.closePath(),c.fill(),c.strokeStyle="#fff",c.lineWidth=2;const z=V?Math.sin($*Math.PI)*8:0;c.beginPath(),c.moveTo(g-4,A),c.lineTo(g-6+z,A+m),c.moveTo(g+4,A),c.lineTo(g+6-z,A+m),c.stroke(),c.lineWidth=3,c.strokeStyle=P}else{c.beginPath(),c.arc(g,b,d,0,Math.PI*2),c.stroke(),c.fillStyle=P,c.beginPath(),c.moveTo(g-8,b-d+1),c.lineTo(g-4,b-d-5),c.lineTo(g+10,b-d+4),c.quadraticCurveTo(g,b-d-1,g-8,b-d+1),c.closePath(),c.fill(),c.stroke(),c.fillStyle=P,V?(c.beginPath(),c.arc(g+3,b-1,2,0,Math.PI*2),c.fill(),c.beginPath(),c.moveTo(g+1,b+4),c.lineTo(g+5,b+4),c.stroke()):(c.beginPath(),c.arc(g-3,b-1,1.5,0,Math.PI*2),c.fill(),c.beginPath(),c.arc(g+3,b-1,1.5,0,Math.PI*2),c.fill(),c.lineWidth=1.5,c.beginPath(),c.arc(g,b+3,3,.2*Math.PI,.8*Math.PI),c.stroke(),c.lineWidth=3),c.beginPath(),c.moveTo(g,O),c.lineTo(g,A),c.stroke();const z=O+4,J=V?Math.sin($*Math.PI)*8:0;c.beginPath(),c.moveTo(g,z),c.lineTo(g-m,z+8+J),c.moveTo(g,z),c.lineTo(g+m,z+8-J),c.stroke();const E=V?Math.sin($*Math.PI)*10:0;c.beginPath(),c.moveTo(g,A),c.lineTo(g-8+E,A+m),c.moveTo(g,A),c.lineTo(g+8-E,A+m),c.stroke()}if(e.playerHat&&e.playerHat!=="none"&&V0(g,b,d,e.playerHat,P),c.restore(),c.save(),c.globalAlpha=.85,e.displayName){c.shadowColor="transparent",c.fillStyle="rgba(0,0,0,0.6)",c.font="10px sans-serif";const z=c.measureText(e.displayName).width;c.fillRect(g-z/2-4,b-d-20,z+8,14),c.fillStyle="#fff",c.textAlign="center",c.textBaseline="middle",c.fillText(e.displayName,g,b-d-13)}c.restore(),Oe&&e.isIt&&(c.save(),c.shadowColor="#ff0000",c.shadowBlur=15,c.fillStyle="#ff0000",c.font="bold 16px sans-serif",c.textAlign="center",c.textBaseline="middle",c.fillText("IT",g,b-d-25),c.restore());const G=Date.now();Oe&&e.tagCooldownUntil&&e.tagCooldownUntil>G&&lm(g,u+s/2,e.tagCooldownUntil,G)}function V0(n,e,t,r,i){if(!c)return;const o=e-t;switch(r){case"cap":c.fillStyle="#ef4444",c.beginPath(),c.ellipse(n,o-2,t+2,5,0,0,Math.PI*2),c.fill(),c.fillRect(n-2,o-4,t+8,4);break;case"tophat":c.fillStyle="#1a1a1a",c.fillRect(n-12,o-2,24,4),c.fillRect(n-8,o-18,16,16),c.fillStyle=i,c.fillRect(n-8,o-6,16,3);break;case"crown":c.fillStyle="#fbbf24",c.beginPath(),c.moveTo(n-10,o),c.lineTo(n-10,o-8),c.lineTo(n-6,o-4),c.lineTo(n-3,o-12),c.lineTo(n,o-6),c.lineTo(n+3,o-12),c.lineTo(n+6,o-4),c.lineTo(n+10,o-8),c.lineTo(n+10,o),c.closePath(),c.fill(),c.fillStyle="#dc2626",c.beginPath(),c.arc(n,o-5,2,0,Math.PI*2),c.fill();break;case"beanie":c.fillStyle="#3b82f6",c.beginPath(),c.arc(n,o,t+1,Math.PI,0),c.fill(),c.fillStyle="#fff",c.beginPath(),c.arc(n,o-t-3,4,0,Math.PI*2),c.fill();break;case"party":c.fillStyle="#ec4899",c.beginPath(),c.moveTo(n,o-20),c.lineTo(n-10,o),c.lineTo(n+10,o),c.closePath(),c.fill(),c.strokeStyle="#fbbf24",c.lineWidth=2,c.beginPath(),c.moveTo(n-8,o-4),c.lineTo(n+8,o-4),c.moveTo(n-5,o-10),c.lineTo(n+5,o-10),c.stroke(),c.lineWidth=3;break}}function F0(){if(!c)return;const n=k.x,e=k.y,t=k.width;c.save(),k.facingRight||(c.translate(n+t/2,0),c.scale(-1,1),c.translate(-(n+t/2),0));const r=9,i=18,o=14,s=n+t/2,l=e+r+3,u=l+r,d=u+i;c.strokeStyle=Ot,c.lineWidth=3,c.lineCap="round",c.lineJoin="round",c.shadowColor="rgba(0,0,0,0.3)",c.shadowBlur=4,c.shadowOffsetX=2,c.shadowOffsetY=2;const p=Math.abs(k.vx)>.5;tu?(c.fillStyle=Ot,c.beginPath(),c.moveTo(s-r-2,l+8),c.lineTo(s-r-1,l-2),c.quadraticCurveTo(s-r+2,l-r-4,s,l-r-3),c.quadraticCurveTo(s+r-2,l-r-4,s+r+1,l-2),c.lineTo(s+r+2,l+8),c.quadraticCurveTo(s+r,l+10,s+r-2,l+10),c.lineTo(s-r+2,l+10),c.quadraticCurveTo(s-r,l+10,s-r-2,l+8),c.closePath(),c.fill(),c.fillStyle="#fff",c.beginPath(),c.arc(s,l,r-1,0,Math.PI*2),c.fill(),c.fillStyle=Ot,c.beginPath(),c.moveTo(s-r+2,l-2),c.quadraticCurveTo(s-2,l-r-2,s,l-r+1),c.quadraticCurveTo(s+2,l-r-2,s+r-2,l-2),c.quadraticCurveTo(s,l-1,s-r+2,l-2),c.closePath(),c.fill(),c.fillStyle=Ot,p?(c.beginPath(),c.arc(s+2,l,1.5,0,Math.PI*2),c.fill(),c.lineWidth=2,c.beginPath(),c.moveTo(s,l+4),c.lineTo(s+4,l+4),c.stroke(),c.lineWidth=3):(c.beginPath(),c.arc(s-3,l,1.5,0,Math.PI*2),c.fill(),c.beginPath(),c.arc(s+3,l,1.5,0,Math.PI*2),c.fill(),c.lineWidth=1.5,c.beginPath(),c.arc(s,l+3,2.5,.2*Math.PI,.8*Math.PI),c.stroke(),c.lineWidth=3),c.fillStyle=Ot,c.beginPath(),c.moveTo(s,u),c.lineTo(s-10,d+2),c.lineTo(s+10,d+2),c.closePath(),c.fill()):(c.beginPath(),c.arc(s,l,r,0,Math.PI*2),c.stroke(),c.fillStyle=Ot,c.beginPath(),c.moveTo(s-8,l-r+1),c.lineTo(s-4,l-r-5),c.lineTo(s+10,l-r+4),c.quadraticCurveTo(s,l-r-1,s-8,l-r+1),c.closePath(),c.fill(),c.stroke(),c.fillStyle=Ot,p?(c.beginPath(),c.arc(s+3,l-1,2,0,Math.PI*2),c.fill(),c.beginPath(),c.moveTo(s+1,l+4),c.lineTo(s+5,l+4),c.stroke()):(c.beginPath(),c.arc(s-3,l-1,1.5,0,Math.PI*2),c.fill(),c.beginPath(),c.arc(s+3,l-1,1.5,0,Math.PI*2),c.fill(),c.beginPath(),c.arc(s,l+3,3,.1*Math.PI,.9*Math.PI),c.stroke()),c.beginPath(),c.moveTo(s,u),c.lineTo(s,d),c.stroke());const m=Math.sin(k.animFrame*Math.PI),g=m*.5,b=m*.6,O=Yt?Math.sin(Ss*3)*.5:0;if(c.beginPath(),c.moveTo(s,u+4),Yt){const P=s-o*Math.cos(-.8+O),V=u+4+o*Math.sin(-.8+O);c.lineTo(P,V)}else c.lineTo(s-o*Math.cos(.6+g),u+4+o*Math.sin(.6+g));if(c.stroke(),c.beginPath(),c.moveTo(s,u+4),c.lineTo(s+o*Math.cos(.6-g),u+4+o*Math.sin(.6-g)),c.stroke(),!k.onGround&&k.vy<0)c.beginPath(),c.moveTo(s,d),c.lineTo(s-6,d+o*.7),c.stroke(),c.beginPath(),c.moveTo(s,d),c.lineTo(s+6,d+o*.7),c.stroke();else if(!k.onGround)c.beginPath(),c.moveTo(s,d),c.lineTo(s-10,d+o),c.stroke(),c.beginPath(),c.moveTo(s,d),c.lineTo(s+10,d+o),c.stroke();else{const P=Math.abs(k.vx)>.5;c.beginPath(),c.moveTo(s,d),c.lineTo(s-o*(P?Math.sin(b)*.8:.3),d+o*(P?Math.cos(b*.5):.95)),c.stroke(),c.beginPath(),c.moveTo(s,d),c.lineTo(s+o*(P?Math.sin(b)*.8:.3),d+o*(P?Math.cos(b*.5):.95)),c.stroke()}U0(s,l,r),c.restore(),Oe&&Io()&&(c.save(),c.shadowColor="#ff0000",c.shadowBlur=15,c.fillStyle="#ff0000",c.font="bold 16px sans-serif",c.textAlign="center",c.textBaseline="middle",c.fillText("IT",s,l-r-20),c.restore());const A=Date.now();Oe&&sn>A&&lm(s,k.y+k.height/2,sn,A)}function lm(n,e,t,r){if(!c)return;const i=t-r;if(i<=0)return;const o=6,s=Js/o,l=Math.ceil(i/s),u=35,d=Math.PI*2/o;c.save();for(let p=0;p<l;p++){const m=-Math.PI/2+p*d,g=m+d-.05;c.fillStyle="rgba(0, 200, 255, 0.3)",c.strokeStyle="rgba(0, 200, 255, 0.7)",c.lineWidth=2,c.beginPath(),c.moveTo(n,e),c.arc(n,e,u,m,g),c.closePath(),c.fill(),c.stroke()}c.strokeStyle="rgba(0, 200, 255, 0.5)",c.lineWidth=3,c.beginPath(),c.arc(n,e,u,0,Math.PI*2),c.stroke(),c.restore()}function U0(n,e,t){c&&(c.shadowBlur=0,To!=="none"&&q0(n,e,t),Eo!=="none"&&$0(n,e,t))}function q0(n,e,t){if(!c)return;const r=e-t;switch(To){case"cap":c.fillStyle="#ef4444",c.beginPath(),c.ellipse(n,r-2,t+2,5,0,0,Math.PI*2),c.fill(),c.fillRect(n-2,r-4,t+8,4);break;case"tophat":c.fillStyle="#1a1a1a",c.fillRect(n-7,r-18,14,16),c.fillRect(n-12,r-2,24,4);break;case"crown":c.fillStyle="#fbbf24",c.beginPath(),c.moveTo(n-10,r),c.lineTo(n-10,r-8),c.lineTo(n-6,r-4),c.lineTo(n-3,r-12),c.lineTo(n,r-6),c.lineTo(n+3,r-12),c.lineTo(n+6,r-4),c.lineTo(n+10,r-8),c.lineTo(n+10,r),c.closePath(),c.fill(),c.fillStyle="#dc2626",c.beginPath(),c.arc(n,r-5,2,0,Math.PI*2),c.fill();break;case"beanie":c.fillStyle="#3b82f6",c.beginPath(),c.arc(n,r,t+1,Math.PI,0),c.fill(),c.fillStyle="#fff",c.beginPath(),c.arc(n,r-t-3,4,0,Math.PI*2),c.fill();break;case"party":c.fillStyle="#ec4899",c.beginPath(),c.moveTo(n,r-20),c.lineTo(n-10,r),c.lineTo(n+10,r),c.closePath(),c.fill(),c.strokeStyle="#fbbf24",c.lineWidth=2,c.beginPath(),c.moveTo(n-8,r-4),c.lineTo(n+8,r-4),c.moveTo(n-5,r-10),c.lineTo(n+5,r-10),c.stroke(),c.lineWidth=3;break}}function $0(n,e,t){if(c)switch(Eo){case"glasses":c.strokeStyle="#333",c.lineWidth=1.5,c.beginPath(),c.arc(n-4,e-1,4,0,Math.PI*2),c.arc(n+4,e-1,4,0,Math.PI*2),c.stroke(),c.beginPath(),c.moveTo(n-1,e-1),c.lineTo(n+1,e-1),c.stroke(),c.lineWidth=3;break;case"sunglasses":c.fillStyle="#1a1a1a",c.fillRect(n-9,e-3,7,5),c.fillRect(n+2,e-3,7,5),c.fillRect(n-2,e-2,4,2);break;case"mustache":c.fillStyle="#4a3728",c.beginPath(),c.moveTo(n-8,e+3),c.quadraticCurveTo(n-4,e+6,n,e+4),c.quadraticCurveTo(n+4,e+6,n+8,e+3),c.quadraticCurveTo(n+4,e+4,n,e+3),c.quadraticCurveTo(n-4,e+4,n-8,e+3),c.fill();break;case"beard":c.fillStyle="#4a3728",c.beginPath(),c.moveTo(n-t+2,e+2),c.quadraticCurveTo(n-t,e+10,n,e+14),c.quadraticCurveTo(n+t,e+10,n+t-2,e+2),c.quadraticCurveTo(n,e+6,n-t+2,e+2),c.fill();break;case"mask":c.fillStyle="#1a1a1a",c.beginPath(),c.ellipse(n,e-1,t-1,4,0,0,Math.PI*2),c.fill(),c.fillStyle="#fff",c.beginPath(),c.ellipse(n-4,e-1,2.5,2,0,0,Math.PI*2),c.ellipse(n+4,e-1,2.5,2,0,0,Math.PI*2),c.fill();break}}function B0(){if(!c)return;const n=window.scrollX,e=window.scrollY;c.save();const t=St==="race"?260:180;c.fillStyle="rgba(0,0,0,0.8)",c.fillRect(n+10,e+10,t,70);let r="EXPLORE MODE",i="#22c55e";if(Oe?(r="TAG MODE",i="#f97316"):St==="race"&&(r="RACE MODE",i="#ef4444"),c.fillStyle=i,c.font="bold 11px sans-serif",c.fillText(r,n+20,e+25),St==="race"){const o=(Ti/1e3).toFixed(2);c.fillStyle="#fff",c.font="bold 20px monospace";const s=ln?"Ready...":ct?`${o}s`:$n<=0?"GAME OVER":`${o}s`;c.fillText(s,n+20,e+48),c.font="14px sans-serif",c.fillStyle="#888",c.fillText("Lives:",n+155,e+48);for(let l=0;l<nu;l++){const u=n+200+l*20,d=e+40;l<$n?(c.strokeStyle="#22c55e",c.lineWidth=2,c.beginPath(),c.arc(u,d-6,4,0,Math.PI*2),c.stroke(),c.beginPath(),c.moveTo(u,d-2),c.lineTo(u,d+6),c.stroke(),c.beginPath(),c.moveTo(u-4,d+1),c.lineTo(u+4,d+1),c.stroke(),c.beginPath(),c.moveTo(u,d+6),c.lineTo(u-3,d+12),c.moveTo(u,d+6),c.lineTo(u+3,d+12),c.stroke()):(c.strokeStyle="#ef4444",c.lineWidth=2,c.beginPath(),c.moveTo(u-5,d-8),c.lineTo(u+5,d+8),c.moveTo(u+5,d-8),c.lineTo(u-5,d+8),c.stroke())}he.bestTime&&(c.fillStyle="#fbbf24",c.font="12px monospace",c.fillText(`Best: ${(he.bestTime/1e3).toFixed(2)}s`,n+20,e+66)),$n<=0&&(c.fillStyle="#ef4444",c.font="bold 14px sans-serif",c.fillText("GAME OVER - Press Play to retry",n+20,e+100))}else if(Oe){if(Io())c.fillStyle="#ff4444",c.font="bold 16px sans-serif",c.fillText("You're IT! Tag someone!",n+20,e+48);else{let s="";for(const[,l]of Ft)if(l.isIt){s=l.displayName||"Another player";break}s?(c.fillStyle="#22c55e",c.font="bold 16px sans-serif",c.fillText("Run! "+s+" is IT!",n+20,e+48)):(c.fillStyle="#fff",c.font="16px sans-serif",c.fillText("Waiting for IT player...",n+20,e+48))}c.fillStyle="#888",c.font="12px sans-serif",c.fillText("Touch another player to tag them",n+20,e+66)}else c.fillStyle="#fff",c.font="16px sans-serif",c.fillText("Explore freely!",n+20,e+48),c.fillStyle="#888",c.font="12px sans-serif",c.fillText("No timer, unlimited respawns",n+20,e+66);if(c.fillStyle="#666",c.font="11px sans-serif",c.fillText("WASD/Arrows, Space=jump, L=leaderboard",n+10,e+95),j0(),z0(),ln&&Z){const o=performance.now()-iu,l=nm-o>1e3?"2":"1";Z.fillStyle="rgba(0, 0, 0, 0.5)",Z.fillRect(n,e,window.innerWidth,window.innerHeight),Z.fillStyle="#fff",Z.font="bold 120px sans-serif",Z.textAlign="center",Z.textBaseline="middle",Z.fillText(l,n+window.innerWidth/2,e+window.innerHeight/2),Z.textBaseline="alphabetic",Z.textAlign="left"}c.restore()}function j0(){if(!Z||!Ie)return;const n=window.scrollX,e=window.scrollY,t=200,r=Ie.subtext?60:40,i=n+20,o=e+window.innerHeight-r-20;Z.fillStyle="rgba(0, 0, 0, 0.9)",Z.fillRect(i,o,t,r),Z.strokeStyle=Ie.text==="GO!"?"#22c55e":Ie.text==="GAME OVER"?"#ef4444":Ie.text==="You fell!"?"#f59e0b":"#3b82f6",Z.lineWidth=2,Z.strokeRect(i,o,t,r),Z.fillStyle="#fff",Z.font="bold 16px sans-serif",Z.textAlign="center";const s=Ie.subtext?o+22:o+26;Z.fillText(Ie.text,i+t/2,s),Ie.subtext&&(Z.fillStyle="#888",Z.font="13px sans-serif",Z.fillText(Ie.subtext,i+t/2,o+44)),Z.textAlign="left"}function z0(){if(!Z||performance.now()>ql)return;const n=window.scrollX,e=window.scrollY,t=window.innerWidth,r=window.innerHeight,o=(ql-performance.now())/tm,s=Math.min(.7,o*.9);Z.save(),Z.fillStyle=`rgba(220, 38, 38, ${s*.3})`,Z.fillRect(n,e,t,r);const l=Math.min(1,o*1.5);Z.font="bold 72px sans-serif",Z.textAlign="center",Z.textBaseline="middle",Z.shadowColor="#ff0000",Z.shadowBlur=30,Z.fillStyle=`rgba(255, 255, 255, ${l})`,Z.fillText("NO TAG BACKS",n+t/2,e+r/2),Z.shadowBlur=15,Z.fillText("NO TAG BACKS",n+t/2,e+r/2),Z.restore()}function W0(){if(!c)return;const n=window.scrollX,e=window.scrollY;c.save(),c.fillStyle="rgba(0,0,0,0.8)",c.fillRect(n+10,e+10,200,35),c.fillStyle="#22c55e",c.font="bold 14px sans-serif",c.fillText("BUILD MODE",n+20,e+32),c.fillStyle="#888",c.font="12px sans-serif";const t=bo.charAt(0).toUpperCase()+bo.slice(1);c.fillText(`Tool: ${t}`,n+115,e+32),c.restore()}function H0(n){if(Pe!=="play"||Jr)return;const e=document.activeElement;if(!(e&&(e.tagName==="INPUT"||e.tagName==="TEXTAREA"||e.isContentEditable))){if(Jt[n.code]=!0,n.code==="Tab"||n.code==="KeyL"){n.preventDefault(),ot();return}["ArrowUp","ArrowDown","ArrowLeft","ArrowRight","Space"].includes(n.code)&&n.preventDefault()}}function G0(n){Jt[n.code]=!1}let Xr=null;function K0(n,e){for(const t of he.checkpoints)if(t.width&&t.height){const r=t.x-t.width/2,i=t.x+t.width/2,o=t.y-t.height,s=t.y;if(n>=r&&n<=i&&e>=o&&e<=s)return t}else if(Math.hypot(n-t.x,e-t.y)<40)return t;return null}function Y0(n){if(Pe!=="build")return;const e=n.pageX,t=n.pageY,r=K0(e,t);if(r){if(n.button===2||n.shiftKey){he.checkpoints=he.checkpoints.filter(l=>l.id!==r.id),fi(),ot();return}Xr=r,ve&&(ve.style.cursor="grabbing");return}if(bo==="select")return;const i=bo;(i==="start"||i==="finish"||i==="spawn")&&(he.checkpoints=he.checkpoints.filter(l=>l.type!==i));const o=i==="start"?0:i==="finish"?999:i==="spawn"?-1:i==="checkpoint"?he.checkpoints.filter(l=>l.type==="checkpoint").length+1:0,s={id:cm(),type:i,x:e,y:t,order:o,reached:!1};i==="trampoline"||i==="speedBoost"||i==="highJump"?(s.width=60,s.height=20):i==="spike"&&(s.width=60,s.height=30),he.checkpoints.push(s),fi(),ot()}function Q0(n){Pe==="build"&&Xr&&(Xr.x=n.pageX,Xr.y=n.pageY,ot())}function J0(n){Xr&&(fi(),Xr=null,ve&&(ve.style.cursor="crosshair"))}function cm(){return Math.random().toString(36).substr(2,9)}function fi(){const n=gn();localStorage.setItem(`oo_course_${n}`,JSON.stringify(he)),console.log("[OpenOverlay] Course saved")}function X0(){const n=gn(),e=localStorage.getItem(`oo_course_${n}`);if(e)try{he=JSON.parse(e),he.checkpoints.forEach(t=>t.reached=!1),console.log("[OpenOverlay] Course loaded:",he.checkpoints.length,"checkpoints")}catch{console.warn("[OpenOverlay] Failed to load course")}}function gn(){return btoa(window.location.href).slice(0,32)}function um(){return`oo_scores_${gn()}`}function Z0(){const n=new Date;return new Date(n.getFullYear(),n.getMonth(),n.getDate()).getTime()}function hm(){const n=localStorage.getItem(um());if(!n)return[];try{const e=JSON.parse(n),t=Z0();return e.filter(r=>r.timestamp>=t)}catch{return[]}}function ds(n,e){const t=hm();t.push({name:n,time:e,timestamp:Date.now()}),t.sort((r,i)=>r.time-i.time),localStorage.setItem(um(),JSON.stringify(t)),localStorage.setItem("oo_player_name",n),so=n}function eA(){const n=hm(),e=n.slice(0,10);let t=null,r=-1;if(so){const i=n.filter(o=>o.name===so);i.length>0&&(t=i[0],r=n.findIndex(o=>o.name===so&&o.time===t.time)+1)}return{top10:e,playerBest:t,playerRank:r}}function tA(){if(console.log("[OpenOverlay] toggleTagMode called, current isTagMode:",Oe),Oe)Oe=!1,Te=!1,Qt=null,Dn=null,pr=0,console.log("[OpenOverlay] Left tag mode"),document.dispatchEvent(new CustomEvent("oo:tagstatechange",{detail:{isTagMode:!1,isIt:!1,gameActive:!1}})),xt("Left tag game","",1500);else{Oe=!0;const n=gn();console.log("[OpenOverlay] Starting/joining tag game on page:",n);let e=!1;for(const[,t]of Ft)if(t.isIt){e=!0;break}Te=!e,console.log("[OpenOverlay] localIsIt:",Te,"someoneElseIsIt:",e),document.dispatchEvent(new CustomEvent("oo:tagstatechange",{detail:{isTagMode:!0,isIt:Te,gameActive:!0}})),Ea(),console.log("[OpenOverlay] Forced sync with isIt:",Te),Te?xt("You're IT!","Tag another player!",2e3):xt("Tag Mode!","Avoid being tagged!",2e3),lI(n).then(t=>{console.log("[OpenOverlay] startTagGame returned:",t),t&&!Te&&(Te=!0,document.dispatchEvent(new CustomEvent("oo:tagstatechange",{detail:{isTagMode:!0,isIt:!0,gameActive:!0}})))}).catch(t=>{console.log("[OpenOverlay] Firebase unavailable, using local tag state:",Te)})}}if(window.__OPENOVERLAY_V2__)console.log("[OpenOverlay] Already injected, skipping");else{let n=function(){console.log("[OpenOverlay] init() called"),console.log("[OpenOverlay] document.body exists:",!!document.body);try{zE(),hI()}catch(e){console.warn("[OpenOverlay] Firebase init failed (may be incognito):",e)}try{UI(),JI(),gI(),S0(),console.log("[OpenOverlay] Ready!")}catch(e){console.error("[OpenOverlay] UI init error:",e)}};window.__OPENOVERLAY_V2__=!0,console.log("[OpenOverlay] v2.0.0 starting..."),document.body?n():document.readyState==="loading"?document.addEventListener("DOMContentLoaded",n):setTimeout(n,100)}
})()
