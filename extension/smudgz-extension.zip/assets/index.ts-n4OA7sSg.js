(function(){const ev=()=>{};var ah={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const dp=function(n){const e=[];let t=0;for(let r=0;r<n.length;r++){let o=n.charCodeAt(r);o<128?e[t++]=o:o<2048?(e[t++]=o>>6|192,e[t++]=o&63|128):(o&64512)===55296&&r+1<n.length&&(n.charCodeAt(r+1)&64512)===56320?(o=65536+((o&1023)<<10)+(n.charCodeAt(++r)&1023),e[t++]=o>>18|240,e[t++]=o>>12&63|128,e[t++]=o>>6&63|128,e[t++]=o&63|128):(e[t++]=o>>12|224,e[t++]=o>>6&63|128,e[t++]=o&63|128)}return e},tv=function(n){const e=[];let t=0,r=0;for(;t<n.length;){const o=n[t++];if(o<128)e[r++]=String.fromCharCode(o);else if(o>191&&o<224){const i=n[t++];e[r++]=String.fromCharCode((o&31)<<6|i&63)}else if(o>239&&o<365){const i=n[t++],s=n[t++],c=n[t++],d=((o&7)<<18|(i&63)<<12|(s&63)<<6|c&63)-65536;e[r++]=String.fromCharCode(55296+(d>>10)),e[r++]=String.fromCharCode(56320+(d&1023))}else{const i=n[t++],s=n[t++];e[r++]=String.fromCharCode((o&15)<<12|(i&63)<<6|s&63)}}return e.join("")},hp={byteToCharMap_:null,charToByteMap_:null,byteToCharMapWebSafe_:null,charToByteMapWebSafe_:null,ENCODED_VALS_BASE:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",get ENCODED_VALS(){return this.ENCODED_VALS_BASE+"+/="},get ENCODED_VALS_WEBSAFE(){return this.ENCODED_VALS_BASE+"-_."},HAS_NATIVE_SUPPORT:typeof atob=="function",encodeByteArray(n,e){if(!Array.isArray(n))throw Error("encodeByteArray takes an array as a parameter");this.init_();const t=e?this.byteToCharMapWebSafe_:this.byteToCharMap_,r=[];for(let o=0;o<n.length;o+=3){const i=n[o],s=o+1<n.length,c=s?n[o+1]:0,d=o+2<n.length,u=d?n[o+2]:0,f=i>>2,g=(i&3)<<4|c>>4;let m=(c&15)<<2|u>>6,v=u&63;d||(v=64,s||(m=64)),r.push(t[f],t[g],t[m],t[v])}return r.join("")},encodeString(n,e){return this.HAS_NATIVE_SUPPORT&&!e?btoa(n):this.encodeByteArray(dp(n),e)},decodeString(n,e){return this.HAS_NATIVE_SUPPORT&&!e?atob(n):tv(this.decodeStringToByteArray(n,e))},decodeStringToByteArray(n,e){this.init_();const t=e?this.charToByteMapWebSafe_:this.charToByteMap_,r=[];for(let o=0;o<n.length;){const i=t[n.charAt(o++)],c=o<n.length?t[n.charAt(o)]:0;++o;const u=o<n.length?t[n.charAt(o)]:64;++o;const g=o<n.length?t[n.charAt(o)]:64;if(++o,i==null||c==null||u==null||g==null)throw new nv;const m=i<<2|c>>4;if(r.push(m),u!==64){const v=c<<4&240|u>>2;if(r.push(v),g!==64){const L=u<<6&192|g;r.push(L)}}}return r},init_(){if(!this.byteToCharMap_){this.byteToCharMap_={},this.charToByteMap_={},this.byteToCharMapWebSafe_={},this.charToByteMapWebSafe_={};for(let n=0;n<this.ENCODED_VALS.length;n++)this.byteToCharMap_[n]=this.ENCODED_VALS.charAt(n),this.charToByteMap_[this.byteToCharMap_[n]]=n,this.byteToCharMapWebSafe_[n]=this.ENCODED_VALS_WEBSAFE.charAt(n),this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[n]]=n,n>=this.ENCODED_VALS_BASE.length&&(this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(n)]=n,this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(n)]=n)}}};class nv extends Error{constructor(){super(...arguments),this.name="DecodeBase64StringError"}}const rv=function(n){const e=dp(n);return hp.encodeByteArray(e,!0)},_a=function(n){return rv(n).replace(/\./g,"")},fp=function(n){try{return hp.decodeString(n,!0)}catch(e){console.error("base64Decode failed: ",e)}return null};/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ov(){if(typeof self<"u")return self;if(typeof window<"u")return window;if(typeof global<"u")return global;throw new Error("Unable to locate global object.")}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const iv=()=>ov().__FIREBASE_DEFAULTS__,sv=()=>{if(typeof process>"u"||typeof ah>"u")return;const n=ah.__FIREBASE_DEFAULTS__;if(n)return JSON.parse(n)},av=()=>{if(typeof document>"u")return;let n;try{n=document.cookie.match(/__FIREBASE_DEFAULTS__=([^;]+)/)}catch{return}const e=n&&fp(n[1]);return e&&JSON.parse(e)},Xa=()=>{try{return ev()||iv()||sv()||av()}catch(n){console.info(`Unable to get __FIREBASE_DEFAULTS__ due to: ${n}`);return}},pp=n=>{var e,t;return(t=(e=Xa())==null?void 0:e.emulatorHosts)==null?void 0:t[n]},lv=n=>{const e=pp(n);if(!e)return;const t=e.lastIndexOf(":");if(t<=0||t+1===e.length)throw new Error(`Invalid host ${e} with no separate hostname and port!`);const r=parseInt(e.substring(t+1),10);return e[0]==="["?[e.substring(1,t-1),r]:[e.substring(0,t),r]},gp=()=>{var n;return(n=Xa())==null?void 0:n.config},mp=n=>{var e;return(e=Xa())==null?void 0:e[`_${n}`]};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class cv{constructor(){this.reject=()=>{},this.resolve=()=>{},this.promise=new Promise((e,t)=>{this.resolve=e,this.reject=t})}wrapCallback(e){return(t,r)=>{t?this.reject(t):this.resolve(r),typeof e=="function"&&(this.promise.catch(()=>{}),e.length===1?e(t):e(t,r))}}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function uv(n,e){if(n.uid)throw new Error('The "uid" field is no longer supported by mockUserToken. Please use "sub" instead for Firebase Auth User ID.');const t={alg:"none",type:"JWT"},r=e||"demo-project",o=n.iat||0,i=n.sub||n.user_id;if(!i)throw new Error("mockUserToken must contain 'sub' or 'user_id' field!");const s={iss:`https://securetoken.google.com/${r}`,aud:r,iat:o,exp:o+3600,auth_time:o,sub:i,user_id:i,firebase:{sign_in_provider:"custom",identities:{}},...n};return[_a(JSON.stringify(t)),_a(JSON.stringify(s)),""].join(".")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ht(){return typeof navigator<"u"&&typeof navigator.userAgent=="string"?navigator.userAgent:""}function dv(){return typeof window<"u"&&!!(window.cordova||window.phonegap||window.PhoneGap)&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i.test(ht())}function hv(){var e;const n=(e=Xa())==null?void 0:e.forceEnvironment;if(n==="node")return!0;if(n==="browser")return!1;try{return Object.prototype.toString.call(global.process)==="[object process]"}catch{return!1}}function fv(){return typeof navigator<"u"&&navigator.userAgent==="Cloudflare-Workers"}function pv(){const n=typeof chrome=="object"?chrome.runtime:typeof browser=="object"?browser.runtime:void 0;return typeof n=="object"&&n.id!==void 0}function gv(){return typeof navigator=="object"&&navigator.product==="ReactNative"}function mv(){const n=ht();return n.indexOf("MSIE ")>=0||n.indexOf("Trident/")>=0}function yv(){return!hv()&&!!navigator.userAgent&&navigator.userAgent.includes("Safari")&&!navigator.userAgent.includes("Chrome")}function vv(){try{return typeof indexedDB=="object"}catch{return!1}}function _v(){return new Promise((n,e)=>{try{let t=!0;const r="validate-browser-context-for-indexeddb-analytics-module",o=self.indexedDB.open(r);o.onsuccess=()=>{o.result.close(),t||self.indexedDB.deleteDatabase(r),n(!0)},o.onupgradeneeded=()=>{t=!1},o.onerror=()=>{var i;e(((i=o.error)==null?void 0:i.message)||"")}}catch(t){e(t)}})}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const bv="FirebaseError";class Nn extends Error{constructor(e,t,r){super(t),this.code=e,this.customData=r,this.name=bv,Object.setPrototypeOf(this,Nn.prototype),Error.captureStackTrace&&Error.captureStackTrace(this,us.prototype.create)}}class us{constructor(e,t,r){this.service=e,this.serviceName=t,this.errors=r}create(e,...t){const r=t[0]||{},o=`${this.service}/${e}`,i=this.errors[e],s=i?wv(i,r):"Error",c=`${this.serviceName}: ${s} (${o}).`;return new Nn(o,c,r)}}function wv(n,e){return n.replace(Tv,(t,r)=>{const o=e[r];return o!=null?String(o):`<${r}?>`})}const Tv=/\{\$([^}]+)}/g;function Ev(n){for(const e in n)if(Object.prototype.hasOwnProperty.call(n,e))return!1;return!0}function Mr(n,e){if(n===e)return!0;const t=Object.keys(n),r=Object.keys(e);for(const o of t){if(!r.includes(o))return!1;const i=n[o],s=e[o];if(lh(i)&&lh(s)){if(!Mr(i,s))return!1}else if(i!==s)return!1}for(const o of r)if(!t.includes(o))return!1;return!0}function lh(n){return n!==null&&typeof n=="object"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ds(n){const e=[];for(const[t,r]of Object.entries(n))Array.isArray(r)?r.forEach(o=>{e.push(encodeURIComponent(t)+"="+encodeURIComponent(o))}):e.push(encodeURIComponent(t)+"="+encodeURIComponent(r));return e.length?"&"+e.join("&"):""}function Iv(n,e){const t=new Sv(n,e);return t.subscribe.bind(t)}class Sv{constructor(e,t){this.observers=[],this.unsubscribes=[],this.observerCount=0,this.task=Promise.resolve(),this.finalized=!1,this.onNoObservers=t,this.task.then(()=>{e(this)}).catch(r=>{this.error(r)})}next(e){this.forEachObserver(t=>{t.next(e)})}error(e){this.forEachObserver(t=>{t.error(e)}),this.close(e)}complete(){this.forEachObserver(e=>{e.complete()}),this.close()}subscribe(e,t,r){let o;if(e===void 0&&t===void 0&&r===void 0)throw new Error("Missing Observer.");xv(e,["next","error","complete"])?o=e:o={next:e,error:t,complete:r},o.next===void 0&&(o.next=Vl),o.error===void 0&&(o.error=Vl),o.complete===void 0&&(o.complete=Vl);const i=this.unsubscribeOne.bind(this,this.observers.length);return this.finalized&&this.task.then(()=>{try{this.finalError?o.error(this.finalError):o.complete()}catch{}}),this.observers.push(o),i}unsubscribeOne(e){this.observers===void 0||this.observers[e]===void 0||(delete this.observers[e],this.observerCount-=1,this.observerCount===0&&this.onNoObservers!==void 0&&this.onNoObservers(this))}forEachObserver(e){if(!this.finalized)for(let t=0;t<this.observers.length;t++)this.sendOne(t,e)}sendOne(e,t){this.task.then(()=>{if(this.observers!==void 0&&this.observers[e]!==void 0)try{t(this.observers[e])}catch(r){typeof console<"u"&&console.error&&console.error(r)}})}close(e){this.finalized||(this.finalized=!0,e!==void 0&&(this.finalError=e),this.task.then(()=>{this.observers=void 0,this.onNoObservers=void 0}))}}function xv(n,e){if(typeof n!="object"||n===null)return!1;for(const t of e)if(t in n&&typeof n[t]=="function")return!0;return!1}function Vl(){}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function rt(n){return n&&n._delegate?n._delegate:n}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function hs(n){try{return(n.startsWith("http://")||n.startsWith("https://")?new URL(n).hostname:n).endsWith(".cloudworkstations.dev")}catch{return!1}}async function yp(n){return(await fetch(n,{credentials:"include"})).ok}class Dr{constructor(e,t,r){this.name=e,this.instanceFactory=t,this.type=r,this.multipleInstances=!1,this.serviceProps={},this.instantiationMode="LAZY",this.onInstanceCreated=null}setInstantiationMode(e){return this.instantiationMode=e,this}setMultipleInstances(e){return this.multipleInstances=e,this}setServiceProps(e){return this.serviceProps=e,this}setInstanceCreatedCallback(e){return this.onInstanceCreated=e,this}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const wr="[DEFAULT]";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Av{constructor(e,t){this.name=e,this.container=t,this.component=null,this.instances=new Map,this.instancesDeferred=new Map,this.instancesOptions=new Map,this.onInitCallbacks=new Map}get(e){const t=this.normalizeInstanceIdentifier(e);if(!this.instancesDeferred.has(t)){const r=new cv;if(this.instancesDeferred.set(t,r),this.isInitialized(t)||this.shouldAutoInitialize())try{const o=this.getOrInitializeService({instanceIdentifier:t});o&&r.resolve(o)}catch{}}return this.instancesDeferred.get(t).promise}getImmediate(e){const t=this.normalizeInstanceIdentifier(e==null?void 0:e.identifier),r=(e==null?void 0:e.optional)??!1;if(this.isInitialized(t)||this.shouldAutoInitialize())try{return this.getOrInitializeService({instanceIdentifier:t})}catch(o){if(r)return null;throw o}else{if(r)return null;throw Error(`Service ${this.name} is not available`)}}getComponent(){return this.component}setComponent(e){if(e.name!==this.name)throw Error(`Mismatching Component ${e.name} for Provider ${this.name}.`);if(this.component)throw Error(`Component for ${this.name} has already been provided`);if(this.component=e,!!this.shouldAutoInitialize()){if(Pv(e))try{this.getOrInitializeService({instanceIdentifier:wr})}catch{}for(const[t,r]of this.instancesDeferred.entries()){const o=this.normalizeInstanceIdentifier(t);try{const i=this.getOrInitializeService({instanceIdentifier:o});r.resolve(i)}catch{}}}}clearInstance(e=wr){this.instancesDeferred.delete(e),this.instancesOptions.delete(e),this.instances.delete(e)}async delete(){const e=Array.from(this.instances.values());await Promise.all([...e.filter(t=>"INTERNAL"in t).map(t=>t.INTERNAL.delete()),...e.filter(t=>"_delete"in t).map(t=>t._delete())])}isComponentSet(){return this.component!=null}isInitialized(e=wr){return this.instances.has(e)}getOptions(e=wr){return this.instancesOptions.get(e)||{}}initialize(e={}){const{options:t={}}=e,r=this.normalizeInstanceIdentifier(e.instanceIdentifier);if(this.isInitialized(r))throw Error(`${this.name}(${r}) has already been initialized`);if(!this.isComponentSet())throw Error(`Component ${this.name} has not been registered yet`);const o=this.getOrInitializeService({instanceIdentifier:r,options:t});for(const[i,s]of this.instancesDeferred.entries()){const c=this.normalizeInstanceIdentifier(i);r===c&&s.resolve(o)}return o}onInit(e,t){const r=this.normalizeInstanceIdentifier(t),o=this.onInitCallbacks.get(r)??new Set;o.add(e),this.onInitCallbacks.set(r,o);const i=this.instances.get(r);return i&&e(i,r),()=>{o.delete(e)}}invokeOnInitCallbacks(e,t){const r=this.onInitCallbacks.get(t);if(r)for(const o of r)try{o(e,t)}catch{}}getOrInitializeService({instanceIdentifier:e,options:t={}}){let r=this.instances.get(e);if(!r&&this.component&&(r=this.component.instanceFactory(this.container,{instanceIdentifier:kv(e),options:t}),this.instances.set(e,r),this.instancesOptions.set(e,t),this.invokeOnInitCallbacks(r,e),this.component.onInstanceCreated))try{this.component.onInstanceCreated(this.container,e,r)}catch{}return r||null}normalizeInstanceIdentifier(e=wr){return this.component?this.component.multipleInstances?e:wr:e}shouldAutoInitialize(){return!!this.component&&this.component.instantiationMode!=="EXPLICIT"}}function kv(n){return n===wr?void 0:n}function Pv(n){return n.instantiationMode==="EAGER"}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Cv{constructor(e){this.name=e,this.providers=new Map}addComponent(e){const t=this.getProvider(e.name);if(t.isComponentSet())throw new Error(`Component ${e.name} has already been registered with ${this.name}`);t.setComponent(e)}addOrOverwriteComponent(e){this.getProvider(e.name).isComponentSet()&&this.providers.delete(e.name),this.addComponent(e)}getProvider(e){if(this.providers.has(e))return this.providers.get(e);const t=new Av(e,this);return this.providers.set(e,t),t}getProviders(){return Array.from(this.providers.values())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var le;(function(n){n[n.DEBUG=0]="DEBUG",n[n.VERBOSE=1]="VERBOSE",n[n.INFO=2]="INFO",n[n.WARN=3]="WARN",n[n.ERROR=4]="ERROR",n[n.SILENT=5]="SILENT"})(le||(le={}));const Rv={debug:le.DEBUG,verbose:le.VERBOSE,info:le.INFO,warn:le.WARN,error:le.ERROR,silent:le.SILENT},Ov=le.INFO,Nv={[le.DEBUG]:"log",[le.VERBOSE]:"log",[le.INFO]:"info",[le.WARN]:"warn",[le.ERROR]:"error"},Lv=(n,e,...t)=>{if(e<n.logLevel)return;const r=new Date().toISOString(),o=Nv[e];if(o)console[o](`[${r}]  ${n.name}:`,...t);else throw new Error(`Attempted to log a message with an invalid logType (value: ${e})`)};class Kc{constructor(e){this.name=e,this._logLevel=Ov,this._logHandler=Lv,this._userLogHandler=null}get logLevel(){return this._logLevel}set logLevel(e){if(!(e in le))throw new TypeError(`Invalid value "${e}" assigned to \`logLevel\``);this._logLevel=e}setLogLevel(e){this._logLevel=typeof e=="string"?Rv[e]:e}get logHandler(){return this._logHandler}set logHandler(e){if(typeof e!="function")throw new TypeError("Value assigned to `logHandler` must be a function");this._logHandler=e}get userLogHandler(){return this._userLogHandler}set userLogHandler(e){this._userLogHandler=e}debug(...e){this._userLogHandler&&this._userLogHandler(this,le.DEBUG,...e),this._logHandler(this,le.DEBUG,...e)}log(...e){this._userLogHandler&&this._userLogHandler(this,le.VERBOSE,...e),this._logHandler(this,le.VERBOSE,...e)}info(...e){this._userLogHandler&&this._userLogHandler(this,le.INFO,...e),this._logHandler(this,le.INFO,...e)}warn(...e){this._userLogHandler&&this._userLogHandler(this,le.WARN,...e),this._logHandler(this,le.WARN,...e)}error(...e){this._userLogHandler&&this._userLogHandler(this,le.ERROR,...e),this._logHandler(this,le.ERROR,...e)}}const Mv=(n,e)=>e.some(t=>n instanceof t);let ch,uh;function Dv(){return ch||(ch=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction])}function Vv(){return uh||(uh=[IDBCursor.prototype.advance,IDBCursor.prototype.continue,IDBCursor.prototype.continuePrimaryKey])}const vp=new WeakMap,ic=new WeakMap,_p=new WeakMap,Fl=new WeakMap,Xc=new WeakMap;function Fv(n){const e=new Promise((t,r)=>{const o=()=>{n.removeEventListener("success",i),n.removeEventListener("error",s)},i=()=>{t(Xn(n.result)),o()},s=()=>{r(n.error),o()};n.addEventListener("success",i),n.addEventListener("error",s)});return e.then(t=>{t instanceof IDBCursor&&vp.set(t,n)}).catch(()=>{}),Xc.set(e,n),e}function Uv(n){if(ic.has(n))return;const e=new Promise((t,r)=>{const o=()=>{n.removeEventListener("complete",i),n.removeEventListener("error",s),n.removeEventListener("abort",s)},i=()=>{t(),o()},s=()=>{r(n.error||new DOMException("AbortError","AbortError")),o()};n.addEventListener("complete",i),n.addEventListener("error",s),n.addEventListener("abort",s)});ic.set(n,e)}let sc={get(n,e,t){if(n instanceof IDBTransaction){if(e==="done")return ic.get(n);if(e==="objectStoreNames")return n.objectStoreNames||_p.get(n);if(e==="store")return t.objectStoreNames[1]?void 0:t.objectStore(t.objectStoreNames[0])}return Xn(n[e])},set(n,e,t){return n[e]=t,!0},has(n,e){return n instanceof IDBTransaction&&(e==="done"||e==="store")?!0:e in n}};function qv(n){sc=n(sc)}function Bv(n){return n===IDBDatabase.prototype.transaction&&!("objectStoreNames"in IDBTransaction.prototype)?function(e,...t){const r=n.call(Ul(this),e,...t);return _p.set(r,e.sort?e.sort():[e]),Xn(r)}:Vv().includes(n)?function(...e){return n.apply(Ul(this),e),Xn(vp.get(this))}:function(...e){return Xn(n.apply(Ul(this),e))}}function $v(n){return typeof n=="function"?Bv(n):(n instanceof IDBTransaction&&Uv(n),Mv(n,Dv())?new Proxy(n,sc):n)}function Xn(n){if(n instanceof IDBRequest)return Fv(n);if(Fl.has(n))return Fl.get(n);const e=$v(n);return e!==n&&(Fl.set(n,e),Xc.set(e,n)),e}const Ul=n=>Xc.get(n);function jv(n,e,{blocked:t,upgrade:r,blocking:o,terminated:i}={}){const s=indexedDB.open(n,e),c=Xn(s);return r&&s.addEventListener("upgradeneeded",d=>{r(Xn(s.result),d.oldVersion,d.newVersion,Xn(s.transaction),d)}),t&&s.addEventListener("blocked",d=>t(d.oldVersion,d.newVersion,d)),c.then(d=>{i&&d.addEventListener("close",()=>i()),o&&d.addEventListener("versionchange",u=>o(u.oldVersion,u.newVersion,u))}).catch(()=>{}),c}const zv=["get","getKey","getAll","getAllKeys","count"],Wv=["put","add","delete","clear"],ql=new Map;function dh(n,e){if(!(n instanceof IDBDatabase&&!(e in n)&&typeof e=="string"))return;if(ql.get(e))return ql.get(e);const t=e.replace(/FromIndex$/,""),r=e!==t,o=Wv.includes(t);if(!(t in(r?IDBIndex:IDBObjectStore).prototype)||!(o||zv.includes(t)))return;const i=async function(s,...c){const d=this.transaction(s,o?"readwrite":"readonly");let u=d.store;return r&&(u=u.index(c.shift())),(await Promise.all([u[t](...c),o&&d.done]))[0]};return ql.set(e,i),i}qv(n=>({...n,get:(e,t,r)=>dh(e,t)||n.get(e,t,r),has:(e,t)=>!!dh(e,t)||n.has(e,t)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Hv{constructor(e){this.container=e}getPlatformInfoString(){return this.container.getProviders().map(t=>{if(Gv(t)){const r=t.getImmediate();return`${r.library}/${r.version}`}else return null}).filter(t=>t).join(" ")}}function Gv(n){const e=n.getComponent();return(e==null?void 0:e.type)==="VERSION"}const ac="@firebase/app",hh="0.14.11";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const An=new Kc("@firebase/app"),Yv="@firebase/app-compat",Kv="@firebase/analytics-compat",Xv="@firebase/analytics",Qv="@firebase/app-check-compat",Jv="@firebase/app-check",Zv="@firebase/auth",e_="@firebase/auth-compat",t_="@firebase/database",n_="@firebase/data-connect",r_="@firebase/database-compat",o_="@firebase/functions",i_="@firebase/functions-compat",s_="@firebase/installations",a_="@firebase/installations-compat",l_="@firebase/messaging",c_="@firebase/messaging-compat",u_="@firebase/performance",d_="@firebase/performance-compat",h_="@firebase/remote-config",f_="@firebase/remote-config-compat",p_="@firebase/storage",g_="@firebase/storage-compat",m_="@firebase/firestore",y_="@firebase/ai",v_="@firebase/firestore-compat",__="firebase",b_="12.12.0";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const lc="[DEFAULT]",w_={[ac]:"fire-core",[Yv]:"fire-core-compat",[Xv]:"fire-analytics",[Kv]:"fire-analytics-compat",[Jv]:"fire-app-check",[Qv]:"fire-app-check-compat",[Zv]:"fire-auth",[e_]:"fire-auth-compat",[t_]:"fire-rtdb",[n_]:"fire-data-connect",[r_]:"fire-rtdb-compat",[o_]:"fire-fn",[i_]:"fire-fn-compat",[s_]:"fire-iid",[a_]:"fire-iid-compat",[l_]:"fire-fcm",[c_]:"fire-fcm-compat",[u_]:"fire-perf",[d_]:"fire-perf-compat",[h_]:"fire-rc",[f_]:"fire-rc-compat",[p_]:"fire-gcs",[g_]:"fire-gcs-compat",[m_]:"fire-fst",[v_]:"fire-fst-compat",[y_]:"fire-vertex","fire-js":"fire-js",[__]:"fire-js-all"};/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ji=new Map,T_=new Map,cc=new Map;function fh(n,e){try{n.container.addComponent(e)}catch(t){An.debug(`Component ${e.name} failed to register with FirebaseApp ${n.name}`,t)}}function xo(n){const e=n.name;if(cc.has(e))return An.debug(`There were multiple attempts to register component ${e}.`),!1;cc.set(e,n);for(const t of ji.values())fh(t,n);for(const t of T_.values())fh(t,n);return!0}function Qc(n,e){const t=n.container.getProvider("heartbeat").getImmediate({optional:!0});return t&&t.triggerHeartbeat(),n.container.getProvider(e)}function Xt(n){return n==null?!1:n.settings!==void 0}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const E_={"no-app":"No Firebase App '{$appName}' has been created - call initializeApp() first","bad-app-name":"Illegal App name: '{$appName}'","duplicate-app":"Firebase App named '{$appName}' already exists with different options or config","app-deleted":"Firebase App named '{$appName}' already deleted","server-app-deleted":"Firebase Server App has been deleted","no-options":"Need to provide options, when not being deployed to hosting via source.","invalid-app-argument":"firebase.{$appName}() takes either no argument or a Firebase App instance.","invalid-log-argument":"First argument to `onLog` must be null or a function.","idb-open":"Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.","idb-get":"Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.","idb-set":"Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.","idb-delete":"Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}.","finalization-registry-not-supported":"FirebaseServerApp deleteOnDeref field defined but the JS runtime does not support FinalizationRegistry.","invalid-server-app-environment":"FirebaseServerApp is not for use in browser environments."},Qn=new us("app","Firebase",E_);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class I_{constructor(e,t,r){this._isDeleted=!1,this._options={...e},this._config={...t},this._name=t.name,this._automaticDataCollectionEnabled=t.automaticDataCollectionEnabled,this._container=r,this.container.addComponent(new Dr("app",()=>this,"PUBLIC"))}get automaticDataCollectionEnabled(){return this.checkDestroyed(),this._automaticDataCollectionEnabled}set automaticDataCollectionEnabled(e){this.checkDestroyed(),this._automaticDataCollectionEnabled=e}get name(){return this.checkDestroyed(),this._name}get options(){return this.checkDestroyed(),this._options}get config(){return this.checkDestroyed(),this._config}get container(){return this._container}get isDeleted(){return this._isDeleted}set isDeleted(e){this._isDeleted=e}checkDestroyed(){if(this.isDeleted)throw Qn.create("app-deleted",{appName:this._name})}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Fo=b_;function Jc(n,e={}){let t=n;typeof e!="object"&&(e={name:e});const r={name:lc,automaticDataCollectionEnabled:!0,...e},o=r.name;if(typeof o!="string"||!o)throw Qn.create("bad-app-name",{appName:String(o)});if(t||(t=gp()),!t)throw Qn.create("no-options");const i=ji.get(o);if(i){if(Mr(t,i.options)&&Mr(r,i.config))return i;throw Qn.create("duplicate-app",{appName:o})}const s=new Cv(o);for(const d of cc.values())s.addComponent(d);const c=new I_(t,r,s);return ji.set(o,c),c}function bp(n=lc){const e=ji.get(n);if(!e&&n===lc&&gp())return Jc();if(!e)throw Qn.create("no-app",{appName:n});return e}function ba(){return Array.from(ji.values())}function Jn(n,e,t){let r=w_[n]??n;t&&(r+=`-${t}`);const o=r.match(/\s|\//),i=e.match(/\s|\//);if(o||i){const s=[`Unable to register library "${r}" with version "${e}":`];o&&s.push(`library name "${r}" contains illegal characters (whitespace or "/")`),o&&i&&s.push("and"),i&&s.push(`version name "${e}" contains illegal characters (whitespace or "/")`),An.warn(s.join(" "));return}xo(new Dr(`${r}-version`,()=>({library:r,version:e}),"VERSION"))}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const S_="firebase-heartbeat-database",x_=1,zi="firebase-heartbeat-store";let Bl=null;function wp(){return Bl||(Bl=jv(S_,x_,{upgrade:(n,e)=>{switch(e){case 0:try{n.createObjectStore(zi)}catch(t){console.warn(t)}}}}).catch(n=>{throw Qn.create("idb-open",{originalErrorMessage:n.message})})),Bl}async function A_(n){try{const t=(await wp()).transaction(zi),r=await t.objectStore(zi).get(Tp(n));return await t.done,r}catch(e){if(e instanceof Nn)An.warn(e.message);else{const t=Qn.create("idb-get",{originalErrorMessage:e==null?void 0:e.message});An.warn(t.message)}}}async function ph(n,e){try{const r=(await wp()).transaction(zi,"readwrite");await r.objectStore(zi).put(e,Tp(n)),await r.done}catch(t){if(t instanceof Nn)An.warn(t.message);else{const r=Qn.create("idb-set",{originalErrorMessage:t==null?void 0:t.message});An.warn(r.message)}}}function Tp(n){return`${n.name}!${n.options.appId}`}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const k_=1024,P_=30;class C_{constructor(e){this.container=e,this._heartbeatsCache=null;const t=this.container.getProvider("app").getImmediate();this._storage=new O_(t),this._heartbeatsCachePromise=this._storage.read().then(r=>(this._heartbeatsCache=r,r))}async triggerHeartbeat(){var e,t;try{const o=this.container.getProvider("platform-logger").getImmediate().getPlatformInfoString(),i=gh();if(((e=this._heartbeatsCache)==null?void 0:e.heartbeats)==null&&(this._heartbeatsCache=await this._heartbeatsCachePromise,((t=this._heartbeatsCache)==null?void 0:t.heartbeats)==null)||this._heartbeatsCache.lastSentHeartbeatDate===i||this._heartbeatsCache.heartbeats.some(s=>s.date===i))return;if(this._heartbeatsCache.heartbeats.push({date:i,agent:o}),this._heartbeatsCache.heartbeats.length>P_){const s=N_(this._heartbeatsCache.heartbeats);this._heartbeatsCache.heartbeats.splice(s,1)}return this._storage.overwrite(this._heartbeatsCache)}catch(r){An.warn(r)}}async getHeartbeatsHeader(){var e;try{if(this._heartbeatsCache===null&&await this._heartbeatsCachePromise,((e=this._heartbeatsCache)==null?void 0:e.heartbeats)==null||this._heartbeatsCache.heartbeats.length===0)return"";const t=gh(),{heartbeatsToSend:r,unsentEntries:o}=R_(this._heartbeatsCache.heartbeats),i=_a(JSON.stringify({version:2,heartbeats:r}));return this._heartbeatsCache.lastSentHeartbeatDate=t,o.length>0?(this._heartbeatsCache.heartbeats=o,await this._storage.overwrite(this._heartbeatsCache)):(this._heartbeatsCache.heartbeats=[],this._storage.overwrite(this._heartbeatsCache)),i}catch(t){return An.warn(t),""}}}function gh(){return new Date().toISOString().substring(0,10)}function R_(n,e=k_){const t=[];let r=n.slice();for(const o of n){const i=t.find(s=>s.agent===o.agent);if(i){if(i.dates.push(o.date),mh(t)>e){i.dates.pop();break}}else if(t.push({agent:o.agent,dates:[o.date]}),mh(t)>e){t.pop();break}r=r.slice(1)}return{heartbeatsToSend:t,unsentEntries:r}}class O_{constructor(e){this.app=e,this._canUseIndexedDBPromise=this.runIndexedDBEnvironmentCheck()}async runIndexedDBEnvironmentCheck(){return vv()?_v().then(()=>!0).catch(()=>!1):!1}async read(){if(await this._canUseIndexedDBPromise){const t=await A_(this.app);return t!=null&&t.heartbeats?t:{heartbeats:[]}}else return{heartbeats:[]}}async overwrite(e){if(await this._canUseIndexedDBPromise){const r=await this.read();return ph(this.app,{lastSentHeartbeatDate:e.lastSentHeartbeatDate??r.lastSentHeartbeatDate,heartbeats:e.heartbeats})}else return}async add(e){if(await this._canUseIndexedDBPromise){const r=await this.read();return ph(this.app,{lastSentHeartbeatDate:e.lastSentHeartbeatDate??r.lastSentHeartbeatDate,heartbeats:[...r.heartbeats,...e.heartbeats]})}else return}}function mh(n){return _a(JSON.stringify({version:2,heartbeats:n})).length}function N_(n){if(n.length===0)return-1;let e=0,t=n[0].date;for(let r=1;r<n.length;r++)n[r].date<t&&(t=n[r].date,e=r);return e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function L_(n){xo(new Dr("platform-logger",e=>new Hv(e),"PRIVATE")),xo(new Dr("heartbeat",e=>new C_(e),"PRIVATE")),Jn(ac,hh,n),Jn(ac,hh,"esm2020"),Jn("fire-js","")}L_("");var M_="firebase",D_="12.12.1";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */Jn(M_,D_,"app");function Ep(){return{"dependent-sdk-initialized-before-auth":"Another Firebase SDK was initialized and is trying to use Auth before Auth is initialized. Please be sure to call `initializeAuth` or `getAuth` before starting any other Firebase SDK."}}const V_=Ep,Ip=new us("auth","Firebase",Ep());/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const wa=new Kc("@firebase/auth");function F_(n,...e){wa.logLevel<=le.WARN&&wa.warn(`Auth (${Fo}): ${n}`,...e)}function oa(n,...e){wa.logLevel<=le.ERROR&&wa.error(`Auth (${Fo}): ${n}`,...e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function kn(n,...e){throw Zc(n,...e)}function rn(n,...e){return Zc(n,...e)}function Sp(n,e,t){const r={...V_(),[e]:t};return new us("auth","Firebase",r).create(e,{appName:n.name})}function Cr(n){return Sp(n,"operation-not-supported-in-this-environment","Operations that alter the current user are not supported in conjunction with FirebaseServerApp")}function Zc(n,...e){if(typeof n!="string"){const t=e[0],r=[...e.slice(1)];return r[0]&&(r[0].appName=n.name),n._errorFactory.create(t,...r)}return Ip.create(n,...e)}function te(n,e,...t){if(!n)throw Zc(e,...t)}function bn(n){const e="INTERNAL ASSERTION FAILED: "+n;throw oa(e),new Error(e)}function Pn(n,e){n||bn(e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function uc(){var n;return typeof self<"u"&&((n=self.location)==null?void 0:n.href)||""}function U_(){return yh()==="http:"||yh()==="https:"}function yh(){var n;return typeof self<"u"&&((n=self.location)==null?void 0:n.protocol)||null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function q_(){return typeof navigator<"u"&&navigator&&"onLine"in navigator&&typeof navigator.onLine=="boolean"&&(U_()||pv()||"connection"in navigator)?navigator.onLine:!0}function B_(){if(typeof navigator>"u")return null;const n=navigator;return n.languages&&n.languages[0]||n.language||null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fs{constructor(e,t){this.shortDelay=e,this.longDelay=t,Pn(t>e,"Short delay should be less than long delay!"),this.isMobile=dv()||gv()}get(){return q_()?this.isMobile?this.longDelay:this.shortDelay:Math.min(5e3,this.shortDelay)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function eu(n,e){Pn(n.emulator,"Emulator should always be set here");const{url:t}=n.emulator;return e?`${t}${e.startsWith("/")?e.slice(1):e}`:t}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xp{static initialize(e,t,r){this.fetchImpl=e,t&&(this.headersImpl=t),r&&(this.responseImpl=r)}static fetch(){if(this.fetchImpl)return this.fetchImpl;if(typeof self<"u"&&"fetch"in self)return self.fetch;if(typeof globalThis<"u"&&globalThis.fetch)return globalThis.fetch;if(typeof fetch<"u")return fetch;bn("Could not find fetch implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static headers(){if(this.headersImpl)return this.headersImpl;if(typeof self<"u"&&"Headers"in self)return self.Headers;if(typeof globalThis<"u"&&globalThis.Headers)return globalThis.Headers;if(typeof Headers<"u")return Headers;bn("Could not find Headers implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static response(){if(this.responseImpl)return this.responseImpl;if(typeof self<"u"&&"Response"in self)return self.Response;if(typeof globalThis<"u"&&globalThis.Response)return globalThis.Response;if(typeof Response<"u")return Response;bn("Could not find Response implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const $_={CREDENTIAL_MISMATCH:"custom-token-mismatch",MISSING_CUSTOM_TOKEN:"internal-error",INVALID_IDENTIFIER:"invalid-email",MISSING_CONTINUE_URI:"internal-error",INVALID_PASSWORD:"wrong-password",MISSING_PASSWORD:"missing-password",INVALID_LOGIN_CREDENTIALS:"invalid-credential",EMAIL_EXISTS:"email-already-in-use",PASSWORD_LOGIN_DISABLED:"operation-not-allowed",INVALID_IDP_RESPONSE:"invalid-credential",INVALID_PENDING_TOKEN:"invalid-credential",FEDERATED_USER_ID_ALREADY_LINKED:"credential-already-in-use",MISSING_REQ_TYPE:"internal-error",EMAIL_NOT_FOUND:"user-not-found",RESET_PASSWORD_EXCEED_LIMIT:"too-many-requests",EXPIRED_OOB_CODE:"expired-action-code",INVALID_OOB_CODE:"invalid-action-code",MISSING_OOB_CODE:"internal-error",CREDENTIAL_TOO_OLD_LOGIN_AGAIN:"requires-recent-login",INVALID_ID_TOKEN:"invalid-user-token",TOKEN_EXPIRED:"user-token-expired",USER_NOT_FOUND:"user-token-expired",TOO_MANY_ATTEMPTS_TRY_LATER:"too-many-requests",PASSWORD_DOES_NOT_MEET_REQUIREMENTS:"password-does-not-meet-requirements",INVALID_CODE:"invalid-verification-code",INVALID_SESSION_INFO:"invalid-verification-id",INVALID_TEMPORARY_PROOF:"invalid-credential",MISSING_SESSION_INFO:"missing-verification-id",SESSION_EXPIRED:"code-expired",MISSING_ANDROID_PACKAGE_NAME:"missing-android-pkg-name",UNAUTHORIZED_DOMAIN:"unauthorized-continue-uri",INVALID_OAUTH_CLIENT_ID:"invalid-oauth-client-id",ADMIN_ONLY_OPERATION:"admin-restricted-operation",INVALID_MFA_PENDING_CREDENTIAL:"invalid-multi-factor-session",MFA_ENROLLMENT_NOT_FOUND:"multi-factor-info-not-found",MISSING_MFA_ENROLLMENT_ID:"missing-multi-factor-info",MISSING_MFA_PENDING_CREDENTIAL:"missing-multi-factor-session",SECOND_FACTOR_EXISTS:"second-factor-already-in-use",SECOND_FACTOR_LIMIT_EXCEEDED:"maximum-second-factor-count-exceeded",BLOCKING_FUNCTION_ERROR_RESPONSE:"internal-error",RECAPTCHA_NOT_ENABLED:"recaptcha-not-enabled",MISSING_RECAPTCHA_TOKEN:"missing-recaptcha-token",INVALID_RECAPTCHA_TOKEN:"invalid-recaptcha-token",INVALID_RECAPTCHA_ACTION:"invalid-recaptcha-action",MISSING_CLIENT_TYPE:"missing-client-type",MISSING_RECAPTCHA_VERSION:"missing-recaptcha-version",INVALID_RECAPTCHA_VERSION:"invalid-recaptcha-version",INVALID_REQ_TYPE:"invalid-req-type"};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const j_=["/v1/accounts:signInWithCustomToken","/v1/accounts:signInWithEmailLink","/v1/accounts:signInWithIdp","/v1/accounts:signInWithPassword","/v1/accounts:signInWithPhoneNumber","/v1/token"],z_=new fs(3e4,6e4);function tu(n,e){return n.tenantId&&!e.tenantId?{...e,tenantId:n.tenantId}:e}async function Uo(n,e,t,r,o={}){return Ap(n,o,async()=>{let i={},s={};r&&(e==="GET"?s=r:i={body:JSON.stringify(r)});const c=ds({key:n.config.apiKey,...s}).slice(1),d=await n._getAdditionalHeaders();d["Content-Type"]="application/json",n.languageCode&&(d["X-Firebase-Locale"]=n.languageCode);const u={method:e,headers:d,...i};return fv()||(u.referrerPolicy="no-referrer"),n.emulatorConfig&&hs(n.emulatorConfig.host)&&(u.credentials="include"),xp.fetch()(await kp(n,n.config.apiHost,t,c),u)})}async function Ap(n,e,t){n._canInitEmulator=!1;const r={...$_,...e};try{const o=new H_(n),i=await Promise.race([t(),o.promise]);o.clearNetworkTimeout();const s=await i.json();if("needConfirmation"in s)throw qs(n,"account-exists-with-different-credential",s);if(i.ok&&!("errorMessage"in s))return s;{const c=i.ok?s.errorMessage:s.error.message,[d,u]=c.split(" : ");if(d==="FEDERATED_USER_ID_ALREADY_LINKED")throw qs(n,"credential-already-in-use",s);if(d==="EMAIL_EXISTS")throw qs(n,"email-already-in-use",s);if(d==="USER_DISABLED")throw qs(n,"user-disabled",s);const f=r[d]||d.toLowerCase().replace(/[_\s]+/g,"-");if(u)throw Sp(n,f,u);kn(n,f)}}catch(o){if(o instanceof Nn)throw o;kn(n,"network-request-failed",{message:String(o)})}}async function W_(n,e,t,r,o={}){const i=await Uo(n,e,t,r,o);return"mfaPendingCredential"in i&&kn(n,"multi-factor-auth-required",{_serverResponse:i}),i}async function kp(n,e,t,r){const o=`${e}${t}?${r}`,i=n,s=i.config.emulator?eu(n.config,o):`${n.config.apiScheme}://${o}`;return j_.includes(t)&&(await i._persistenceManagerAvailable,i._getPersistenceType()==="COOKIE")?i._getPersistence()._getFinalTarget(s).toString():s}class H_{clearNetworkTimeout(){clearTimeout(this.timer)}constructor(e){this.auth=e,this.timer=null,this.promise=new Promise((t,r)=>{this.timer=setTimeout(()=>r(rn(this.auth,"network-request-failed")),z_.get())})}}function qs(n,e,t){const r={appName:n.name};t.email&&(r.email=t.email),t.phoneNumber&&(r.phoneNumber=t.phoneNumber);const o=rn(n,e,r);return o.customData._tokenResponse=t,o}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function G_(n,e){return Uo(n,"POST","/v1/accounts:delete",e)}async function Ta(n,e){return Uo(n,"POST","/v1/accounts:lookup",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ni(n){if(n)try{const e=new Date(Number(n));if(!isNaN(e.getTime()))return e.toUTCString()}catch{}}async function Y_(n,e=!1){const t=rt(n),r=await t.getIdToken(e),o=nu(r);te(o&&o.exp&&o.auth_time&&o.iat,t.auth,"internal-error");const i=typeof o.firebase=="object"?o.firebase:void 0,s=i==null?void 0:i.sign_in_provider;return{claims:o,token:r,authTime:Ni($l(o.auth_time)),issuedAtTime:Ni($l(o.iat)),expirationTime:Ni($l(o.exp)),signInProvider:s||null,signInSecondFactor:(i==null?void 0:i.sign_in_second_factor)||null}}function $l(n){return Number(n)*1e3}function nu(n){const[e,t,r]=n.split(".");if(e===void 0||t===void 0||r===void 0)return oa("JWT malformed, contained fewer than 3 sections"),null;try{const o=fp(t);return o?JSON.parse(o):(oa("Failed to decode base64 JWT payload"),null)}catch(o){return oa("Caught error parsing JWT payload as JSON",o==null?void 0:o.toString()),null}}function vh(n){const e=nu(n);return te(e,"internal-error"),te(typeof e.exp<"u","internal-error"),te(typeof e.iat<"u","internal-error"),Number(e.exp)-Number(e.iat)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Wi(n,e,t=!1){if(t)return e;try{return await e}catch(r){throw r instanceof Nn&&K_(r)&&n.auth.currentUser===n&&await n.auth.signOut(),r}}function K_({code:n}){return n==="auth/user-disabled"||n==="auth/user-token-expired"}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class X_{constructor(e){this.user=e,this.isRunning=!1,this.timerId=null,this.errorBackoff=3e4}_start(){this.isRunning||(this.isRunning=!0,this.schedule())}_stop(){this.isRunning&&(this.isRunning=!1,this.timerId!==null&&clearTimeout(this.timerId))}getInterval(e){if(e){const t=this.errorBackoff;return this.errorBackoff=Math.min(this.errorBackoff*2,96e4),t}else{this.errorBackoff=3e4;const r=(this.user.stsTokenManager.expirationTime??0)-Date.now()-3e5;return Math.max(0,r)}}schedule(e=!1){if(!this.isRunning)return;const t=this.getInterval(e);this.timerId=setTimeout(async()=>{await this.iteration()},t)}async iteration(){try{await this.user.getIdToken(!0)}catch(e){(e==null?void 0:e.code)==="auth/network-request-failed"&&this.schedule(!0);return}this.schedule()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class dc{constructor(e,t){this.createdAt=e,this.lastLoginAt=t,this._initializeTime()}_initializeTime(){this.lastSignInTime=Ni(this.lastLoginAt),this.creationTime=Ni(this.createdAt)}_copy(e){this.createdAt=e.createdAt,this.lastLoginAt=e.lastLoginAt,this._initializeTime()}toJSON(){return{createdAt:this.createdAt,lastLoginAt:this.lastLoginAt}}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Ea(n){var g;const e=n.auth,t=await n.getIdToken(),r=await Wi(n,Ta(e,{idToken:t}));te(r==null?void 0:r.users.length,e,"internal-error");const o=r.users[0];n._notifyReloadListener(o);const i=(g=o.providerUserInfo)!=null&&g.length?Pp(o.providerUserInfo):[],s=J_(n.providerData,i),c=n.isAnonymous,d=!(n.email&&o.passwordHash)&&!(s!=null&&s.length),u=c?d:!1,f={uid:o.localId,displayName:o.displayName||null,photoURL:o.photoUrl||null,email:o.email||null,emailVerified:o.emailVerified||!1,phoneNumber:o.phoneNumber||null,tenantId:o.tenantId||null,providerData:s,metadata:new dc(o.createdAt,o.lastLoginAt),isAnonymous:u};Object.assign(n,f)}async function Q_(n){const e=rt(n);await Ea(e),await e.auth._persistUserIfCurrent(e),e.auth._notifyListenersIfCurrent(e)}function J_(n,e){return[...n.filter(r=>!e.some(o=>o.providerId===r.providerId)),...e]}function Pp(n){return n.map(({providerId:e,...t})=>({providerId:e,uid:t.rawId||"",displayName:t.displayName||null,email:t.email||null,phoneNumber:t.phoneNumber||null,photoURL:t.photoUrl||null}))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Z_(n,e){const t=await Ap(n,{},async()=>{const r=ds({grant_type:"refresh_token",refresh_token:e}).slice(1),{tokenApiHost:o,apiKey:i}=n.config,s=await kp(n,o,"/v1/token",`key=${i}`),c=await n._getAdditionalHeaders();c["Content-Type"]="application/x-www-form-urlencoded";const d={method:"POST",headers:c,body:r};return n.emulatorConfig&&hs(n.emulatorConfig.host)&&(d.credentials="include"),xp.fetch()(s,d)});return{accessToken:t.access_token,expiresIn:t.expires_in,refreshToken:t.refresh_token}}async function eb(n,e){return Uo(n,"POST","/v2/accounts:revokeToken",tu(n,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class uo{constructor(){this.refreshToken=null,this.accessToken=null,this.expirationTime=null}get isExpired(){return!this.expirationTime||Date.now()>this.expirationTime-3e4}updateFromServerResponse(e){te(e.idToken,"internal-error"),te(typeof e.idToken<"u","internal-error"),te(typeof e.refreshToken<"u","internal-error");const t="expiresIn"in e&&typeof e.expiresIn<"u"?Number(e.expiresIn):vh(e.idToken);this.updateTokensAndExpiration(e.idToken,e.refreshToken,t)}updateFromIdToken(e){te(e.length!==0,"internal-error");const t=vh(e);this.updateTokensAndExpiration(e,null,t)}async getToken(e,t=!1){return!t&&this.accessToken&&!this.isExpired?this.accessToken:(te(this.refreshToken,e,"user-token-expired"),this.refreshToken?(await this.refresh(e,this.refreshToken),this.accessToken):null)}clearRefreshToken(){this.refreshToken=null}async refresh(e,t){const{accessToken:r,refreshToken:o,expiresIn:i}=await Z_(e,t);this.updateTokensAndExpiration(r,o,Number(i))}updateTokensAndExpiration(e,t,r){this.refreshToken=t||null,this.accessToken=e||null,this.expirationTime=Date.now()+r*1e3}static fromJSON(e,t){const{refreshToken:r,accessToken:o,expirationTime:i}=t,s=new uo;return r&&(te(typeof r=="string","internal-error",{appName:e}),s.refreshToken=r),o&&(te(typeof o=="string","internal-error",{appName:e}),s.accessToken=o),i&&(te(typeof i=="number","internal-error",{appName:e}),s.expirationTime=i),s}toJSON(){return{refreshToken:this.refreshToken,accessToken:this.accessToken,expirationTime:this.expirationTime}}_assign(e){this.accessToken=e.accessToken,this.refreshToken=e.refreshToken,this.expirationTime=e.expirationTime}_clone(){return Object.assign(new uo,this.toJSON())}_performRefresh(){return bn("not implemented")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Bn(n,e){te(typeof n=="string"||typeof n>"u","internal-error",{appName:e})}class Ut{constructor({uid:e,auth:t,stsTokenManager:r,...o}){this.providerId="firebase",this.proactiveRefresh=new X_(this),this.reloadUserInfo=null,this.reloadListener=null,this.uid=e,this.auth=t,this.stsTokenManager=r,this.accessToken=r.accessToken,this.displayName=o.displayName||null,this.email=o.email||null,this.emailVerified=o.emailVerified||!1,this.phoneNumber=o.phoneNumber||null,this.photoURL=o.photoURL||null,this.isAnonymous=o.isAnonymous||!1,this.tenantId=o.tenantId||null,this.providerData=o.providerData?[...o.providerData]:[],this.metadata=new dc(o.createdAt||void 0,o.lastLoginAt||void 0)}async getIdToken(e){const t=await Wi(this,this.stsTokenManager.getToken(this.auth,e));return te(t,this.auth,"internal-error"),this.accessToken!==t&&(this.accessToken=t,await this.auth._persistUserIfCurrent(this),this.auth._notifyListenersIfCurrent(this)),t}getIdTokenResult(e){return Y_(this,e)}reload(){return Q_(this)}_assign(e){this!==e&&(te(this.uid===e.uid,this.auth,"internal-error"),this.displayName=e.displayName,this.photoURL=e.photoURL,this.email=e.email,this.emailVerified=e.emailVerified,this.phoneNumber=e.phoneNumber,this.isAnonymous=e.isAnonymous,this.tenantId=e.tenantId,this.providerData=e.providerData.map(t=>({...t})),this.metadata._copy(e.metadata),this.stsTokenManager._assign(e.stsTokenManager))}_clone(e){const t=new Ut({...this,auth:e,stsTokenManager:this.stsTokenManager._clone()});return t.metadata._copy(this.metadata),t}_onReload(e){te(!this.reloadListener,this.auth,"internal-error"),this.reloadListener=e,this.reloadUserInfo&&(this._notifyReloadListener(this.reloadUserInfo),this.reloadUserInfo=null)}_notifyReloadListener(e){this.reloadListener?this.reloadListener(e):this.reloadUserInfo=e}_startProactiveRefresh(){this.proactiveRefresh._start()}_stopProactiveRefresh(){this.proactiveRefresh._stop()}async _updateTokensIfNecessary(e,t=!1){let r=!1;e.idToken&&e.idToken!==this.stsTokenManager.accessToken&&(this.stsTokenManager.updateFromServerResponse(e),r=!0),t&&await Ea(this),await this.auth._persistUserIfCurrent(this),r&&this.auth._notifyListenersIfCurrent(this)}async delete(){if(Xt(this.auth.app))return Promise.reject(Cr(this.auth));const e=await this.getIdToken();return await Wi(this,G_(this.auth,{idToken:e})),this.stsTokenManager.clearRefreshToken(),this.auth.signOut()}toJSON(){return{uid:this.uid,email:this.email||void 0,emailVerified:this.emailVerified,displayName:this.displayName||void 0,isAnonymous:this.isAnonymous,photoURL:this.photoURL||void 0,phoneNumber:this.phoneNumber||void 0,tenantId:this.tenantId||void 0,providerData:this.providerData.map(e=>({...e})),stsTokenManager:this.stsTokenManager.toJSON(),_redirectEventId:this._redirectEventId,...this.metadata.toJSON(),apiKey:this.auth.config.apiKey,appName:this.auth.name}}get refreshToken(){return this.stsTokenManager.refreshToken||""}static _fromJSON(e,t){const r=t.displayName??void 0,o=t.email??void 0,i=t.phoneNumber??void 0,s=t.photoURL??void 0,c=t.tenantId??void 0,d=t._redirectEventId??void 0,u=t.createdAt??void 0,f=t.lastLoginAt??void 0,{uid:g,emailVerified:m,isAnonymous:v,providerData:L,stsTokenManager:P}=t;te(g&&P,e,"internal-error");const M=uo.fromJSON(this.name,P);te(typeof g=="string",e,"internal-error"),Bn(r,e.name),Bn(o,e.name),te(typeof m=="boolean",e,"internal-error"),te(typeof v=="boolean",e,"internal-error"),Bn(i,e.name),Bn(s,e.name),Bn(c,e.name),Bn(d,e.name),Bn(u,e.name),Bn(f,e.name);const G=new Ut({uid:g,auth:e,email:o,emailVerified:m,displayName:r,isAnonymous:v,photoURL:s,phoneNumber:i,tenantId:c,stsTokenManager:M,createdAt:u,lastLoginAt:f});return L&&Array.isArray(L)&&(G.providerData=L.map($=>({...$}))),d&&(G._redirectEventId=d),G}static async _fromIdTokenResponse(e,t,r=!1){const o=new uo;o.updateFromServerResponse(t);const i=new Ut({uid:t.localId,auth:e,stsTokenManager:o,isAnonymous:r});return await Ea(i),i}static async _fromGetAccountInfoResponse(e,t,r){const o=t.users[0];te(o.localId!==void 0,"internal-error");const i=o.providerUserInfo!==void 0?Pp(o.providerUserInfo):[],s=!(o.email&&o.passwordHash)&&!(i!=null&&i.length),c=new uo;c.updateFromIdToken(r);const d=new Ut({uid:o.localId,auth:e,stsTokenManager:c,isAnonymous:s}),u={uid:o.localId,displayName:o.displayName||null,photoURL:o.photoUrl||null,email:o.email||null,emailVerified:o.emailVerified||!1,phoneNumber:o.phoneNumber||null,tenantId:o.tenantId||null,providerData:i,metadata:new dc(o.createdAt,o.lastLoginAt),isAnonymous:!(o.email&&o.passwordHash)&&!(i!=null&&i.length)};return Object.assign(d,u),d}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const _h=new Map;function wn(n){Pn(n instanceof Function,"Expected a class definition");let e=_h.get(n);return e?(Pn(e instanceof n,"Instance stored in cache mismatched with class"),e):(e=new n,_h.set(n,e),e)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Cp{constructor(){this.type="NONE",this.storage={}}async _isAvailable(){return!0}async _set(e,t){this.storage[e]=t}async _get(e){const t=this.storage[e];return t===void 0?null:t}async _remove(e){delete this.storage[e]}_addListener(e,t){}_removeListener(e,t){}}Cp.type="NONE";const bh=Cp;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ia(n,e,t){return`firebase:${n}:${e}:${t}`}class ho{constructor(e,t,r){this.persistence=e,this.auth=t,this.userKey=r;const{config:o,name:i}=this.auth;this.fullUserKey=ia(this.userKey,o.apiKey,i),this.fullPersistenceKey=ia("persistence",o.apiKey,i),this.boundEventHandler=t._onStorageEvent.bind(t),this.persistence._addListener(this.fullUserKey,this.boundEventHandler)}setCurrentUser(e){return this.persistence._set(this.fullUserKey,e.toJSON())}async getCurrentUser(){const e=await this.persistence._get(this.fullUserKey);if(!e)return null;if(typeof e=="string"){const t=await Ta(this.auth,{idToken:e}).catch(()=>{});return t?Ut._fromGetAccountInfoResponse(this.auth,t,e):null}return Ut._fromJSON(this.auth,e)}removeCurrentUser(){return this.persistence._remove(this.fullUserKey)}savePersistenceForRedirect(){return this.persistence._set(this.fullPersistenceKey,this.persistence.type)}async setPersistence(e){if(this.persistence===e)return;const t=await this.getCurrentUser();if(await this.removeCurrentUser(),this.persistence=e,t)return this.setCurrentUser(t)}delete(){this.persistence._removeListener(this.fullUserKey,this.boundEventHandler)}static async create(e,t,r="authUser"){if(!t.length)return new ho(wn(bh),e,r);const o=(await Promise.all(t.map(async u=>{if(await u._isAvailable())return u}))).filter(u=>u);let i=o[0]||wn(bh);const s=ia(r,e.config.apiKey,e.name);let c=null;for(const u of t)try{const f=await u._get(s);if(f){let g;if(typeof f=="string"){const m=await Ta(e,{idToken:f}).catch(()=>{});if(!m)break;g=await Ut._fromGetAccountInfoResponse(e,m,f)}else g=Ut._fromJSON(e,f);u!==i&&(c=g),i=u;break}}catch{}const d=o.filter(u=>u._shouldAllowMigration);return!i._shouldAllowMigration||!d.length?new ho(i,e,r):(i=d[0],c&&await i._set(s,c.toJSON()),await Promise.all(t.map(async u=>{if(u!==i)try{await u._remove(s)}catch{}})),new ho(i,e,r))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function wh(n){const e=n.toLowerCase();if(e.includes("opera/")||e.includes("opr/")||e.includes("opios/"))return"Opera";if(Lp(e))return"IEMobile";if(e.includes("msie")||e.includes("trident/"))return"IE";if(e.includes("edge/"))return"Edge";if(Rp(e))return"Firefox";if(e.includes("silk/"))return"Silk";if(Dp(e))return"Blackberry";if(Vp(e))return"Webos";if(Op(e))return"Safari";if((e.includes("chrome/")||Np(e))&&!e.includes("edge/"))return"Chrome";if(Mp(e))return"Android";{const t=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,r=n.match(t);if((r==null?void 0:r.length)===2)return r[1]}return"Other"}function Rp(n=ht()){return/firefox\//i.test(n)}function Op(n=ht()){const e=n.toLowerCase();return e.includes("safari/")&&!e.includes("chrome/")&&!e.includes("crios/")&&!e.includes("android")}function Np(n=ht()){return/crios\//i.test(n)}function Lp(n=ht()){return/iemobile/i.test(n)}function Mp(n=ht()){return/android/i.test(n)}function Dp(n=ht()){return/blackberry/i.test(n)}function Vp(n=ht()){return/webos/i.test(n)}function ru(n=ht()){return/iphone|ipad|ipod/i.test(n)||/macintosh/i.test(n)&&/mobile/i.test(n)}function tb(n=ht()){var e;return ru(n)&&!!((e=window.navigator)!=null&&e.standalone)}function nb(){return mv()&&document.documentMode===10}function Fp(n=ht()){return ru(n)||Mp(n)||Vp(n)||Dp(n)||/windows phone/i.test(n)||Lp(n)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Up(n,e=[]){let t;switch(n){case"Browser":t=wh(ht());break;case"Worker":t=`${wh(ht())}-${n}`;break;default:t=n}const r=e.length?e.join(","):"FirebaseCore-web";return`${t}/JsCore/${Fo}/${r}`}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class rb{constructor(e){this.auth=e,this.queue=[]}pushCallback(e,t){const r=i=>new Promise((s,c)=>{try{const d=e(i);s(d)}catch(d){c(d)}});r.onAbort=t,this.queue.push(r);const o=this.queue.length-1;return()=>{this.queue[o]=()=>Promise.resolve()}}async runMiddleware(e){if(this.auth.currentUser===e)return;const t=[];try{for(const r of this.queue)await r(e),r.onAbort&&t.push(r.onAbort)}catch(r){t.reverse();for(const o of t)try{o()}catch{}throw this.auth._errorFactory.create("login-blocked",{originalMessage:r==null?void 0:r.message})}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function ob(n,e={}){return Uo(n,"GET","/v2/passwordPolicy",tu(n,e))}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ib=6;class sb{constructor(e){var r;const t=e.customStrengthOptions;this.customStrengthOptions={},this.customStrengthOptions.minPasswordLength=t.minPasswordLength??ib,t.maxPasswordLength&&(this.customStrengthOptions.maxPasswordLength=t.maxPasswordLength),t.containsLowercaseCharacter!==void 0&&(this.customStrengthOptions.containsLowercaseLetter=t.containsLowercaseCharacter),t.containsUppercaseCharacter!==void 0&&(this.customStrengthOptions.containsUppercaseLetter=t.containsUppercaseCharacter),t.containsNumericCharacter!==void 0&&(this.customStrengthOptions.containsNumericCharacter=t.containsNumericCharacter),t.containsNonAlphanumericCharacter!==void 0&&(this.customStrengthOptions.containsNonAlphanumericCharacter=t.containsNonAlphanumericCharacter),this.enforcementState=e.enforcementState,this.enforcementState==="ENFORCEMENT_STATE_UNSPECIFIED"&&(this.enforcementState="OFF"),this.allowedNonAlphanumericCharacters=((r=e.allowedNonAlphanumericCharacters)==null?void 0:r.join(""))??"",this.forceUpgradeOnSignin=e.forceUpgradeOnSignin??!1,this.schemaVersion=e.schemaVersion}validatePassword(e){const t={isValid:!0,passwordPolicy:this};return this.validatePasswordLengthOptions(e,t),this.validatePasswordCharacterOptions(e,t),t.isValid&&(t.isValid=t.meetsMinPasswordLength??!0),t.isValid&&(t.isValid=t.meetsMaxPasswordLength??!0),t.isValid&&(t.isValid=t.containsLowercaseLetter??!0),t.isValid&&(t.isValid=t.containsUppercaseLetter??!0),t.isValid&&(t.isValid=t.containsNumericCharacter??!0),t.isValid&&(t.isValid=t.containsNonAlphanumericCharacter??!0),t}validatePasswordLengthOptions(e,t){const r=this.customStrengthOptions.minPasswordLength,o=this.customStrengthOptions.maxPasswordLength;r&&(t.meetsMinPasswordLength=e.length>=r),o&&(t.meetsMaxPasswordLength=e.length<=o)}validatePasswordCharacterOptions(e,t){this.updatePasswordCharacterOptionsStatuses(t,!1,!1,!1,!1);let r;for(let o=0;o<e.length;o++)r=e.charAt(o),this.updatePasswordCharacterOptionsStatuses(t,r>="a"&&r<="z",r>="A"&&r<="Z",r>="0"&&r<="9",this.allowedNonAlphanumericCharacters.includes(r))}updatePasswordCharacterOptionsStatuses(e,t,r,o,i){this.customStrengthOptions.containsLowercaseLetter&&(e.containsLowercaseLetter||(e.containsLowercaseLetter=t)),this.customStrengthOptions.containsUppercaseLetter&&(e.containsUppercaseLetter||(e.containsUppercaseLetter=r)),this.customStrengthOptions.containsNumericCharacter&&(e.containsNumericCharacter||(e.containsNumericCharacter=o)),this.customStrengthOptions.containsNonAlphanumericCharacter&&(e.containsNonAlphanumericCharacter||(e.containsNonAlphanumericCharacter=i))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ab{constructor(e,t,r,o){this.app=e,this.heartbeatServiceProvider=t,this.appCheckServiceProvider=r,this.config=o,this.currentUser=null,this.emulatorConfig=null,this.operations=Promise.resolve(),this.authStateSubscription=new Th(this),this.idTokenSubscription=new Th(this),this.beforeStateQueue=new rb(this),this.redirectUser=null,this.isProactiveRefreshEnabled=!1,this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION=1,this._canInitEmulator=!0,this._isInitialized=!1,this._deleted=!1,this._initializationPromise=null,this._popupRedirectResolver=null,this._errorFactory=Ip,this._agentRecaptchaConfig=null,this._tenantRecaptchaConfigs={},this._projectPasswordPolicy=null,this._tenantPasswordPolicies={},this._resolvePersistenceManagerAvailable=void 0,this.lastNotifiedUid=void 0,this.languageCode=null,this.tenantId=null,this.settings={appVerificationDisabledForTesting:!1},this.frameworks=[],this.name=e.name,this.clientVersion=o.sdkClientVersion,this._persistenceManagerAvailable=new Promise(i=>this._resolvePersistenceManagerAvailable=i)}_initializeWithPersistence(e,t){return t&&(this._popupRedirectResolver=wn(t)),this._initializationPromise=this.queue(async()=>{var r,o,i;if(!this._deleted&&(this.persistenceManager=await ho.create(this,e),(r=this._resolvePersistenceManagerAvailable)==null||r.call(this),!this._deleted)){if((o=this._popupRedirectResolver)!=null&&o._shouldInitProactively)try{await this._popupRedirectResolver._initialize(this)}catch{}await this.initializeCurrentUser(t),this.lastNotifiedUid=((i=this.currentUser)==null?void 0:i.uid)||null,!this._deleted&&(this._isInitialized=!0)}}),this._initializationPromise}async _onStorageEvent(){if(this._deleted)return;const e=await this.assertedPersistence.getCurrentUser();if(!(!this.currentUser&&!e)){if(this.currentUser&&e&&this.currentUser.uid===e.uid){this._currentUser._assign(e),await this.currentUser.getIdToken();return}await this._updateCurrentUser(e,!0)}}async initializeCurrentUserFromIdToken(e){try{const t=await Ta(this,{idToken:e}),r=await Ut._fromGetAccountInfoResponse(this,t,e);await this.directlySetCurrentUser(r)}catch(t){console.warn("FirebaseServerApp could not login user with provided authIdToken: ",t),await this.directlySetCurrentUser(null)}}async initializeCurrentUser(e){var i;if(Xt(this.app)){const s=this.app.settings.authIdToken;return s?new Promise(c=>{setTimeout(()=>this.initializeCurrentUserFromIdToken(s).then(c,c))}):this.directlySetCurrentUser(null)}const t=await this.assertedPersistence.getCurrentUser();let r=t,o=!1;if(e&&this.config.authDomain){await this.getOrInitRedirectPersistenceManager();const s=(i=this.redirectUser)==null?void 0:i._redirectEventId,c=r==null?void 0:r._redirectEventId,d=await this.tryRedirectSignIn(e);(!s||s===c)&&(d!=null&&d.user)&&(r=d.user,o=!0)}if(!r)return this.directlySetCurrentUser(null);if(!r._redirectEventId){if(o)try{await this.beforeStateQueue.runMiddleware(r)}catch(s){r=t,this._popupRedirectResolver._overrideRedirectResult(this,()=>Promise.reject(s))}return r?this.reloadAndSetCurrentUserOrClear(r):this.directlySetCurrentUser(null)}return te(this._popupRedirectResolver,this,"argument-error"),await this.getOrInitRedirectPersistenceManager(),this.redirectUser&&this.redirectUser._redirectEventId===r._redirectEventId?this.directlySetCurrentUser(r):this.reloadAndSetCurrentUserOrClear(r)}async tryRedirectSignIn(e){let t=null;try{t=await this._popupRedirectResolver._completeRedirectFn(this,e,!0)}catch{await this._setRedirectUser(null)}return t}async reloadAndSetCurrentUserOrClear(e){try{await Ea(e)}catch(t){if((t==null?void 0:t.code)!=="auth/network-request-failed")return this.directlySetCurrentUser(null)}return this.directlySetCurrentUser(e)}useDeviceLanguage(){this.languageCode=B_()}async _delete(){this._deleted=!0}async updateCurrentUser(e){if(Xt(this.app))return Promise.reject(Cr(this));const t=e?rt(e):null;return t&&te(t.auth.config.apiKey===this.config.apiKey,this,"invalid-user-token"),this._updateCurrentUser(t&&t._clone(this))}async _updateCurrentUser(e,t=!1){if(!this._deleted)return e&&te(this.tenantId===e.tenantId,this,"tenant-id-mismatch"),t||await this.beforeStateQueue.runMiddleware(e),this.queue(async()=>{await this.directlySetCurrentUser(e),this.notifyAuthListeners()})}async signOut(){return Xt(this.app)?Promise.reject(Cr(this)):(await this.beforeStateQueue.runMiddleware(null),(this.redirectPersistenceManager||this._popupRedirectResolver)&&await this._setRedirectUser(null),this._updateCurrentUser(null,!0))}setPersistence(e){return Xt(this.app)?Promise.reject(Cr(this)):this.queue(async()=>{await this.assertedPersistence.setPersistence(wn(e))})}_getRecaptchaConfig(){return this.tenantId==null?this._agentRecaptchaConfig:this._tenantRecaptchaConfigs[this.tenantId]}async validatePassword(e){this._getPasswordPolicyInternal()||await this._updatePasswordPolicy();const t=this._getPasswordPolicyInternal();return t.schemaVersion!==this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION?Promise.reject(this._errorFactory.create("unsupported-password-policy-schema-version",{})):t.validatePassword(e)}_getPasswordPolicyInternal(){return this.tenantId===null?this._projectPasswordPolicy:this._tenantPasswordPolicies[this.tenantId]}async _updatePasswordPolicy(){const e=await ob(this),t=new sb(e);this.tenantId===null?this._projectPasswordPolicy=t:this._tenantPasswordPolicies[this.tenantId]=t}_getPersistenceType(){return this.assertedPersistence.persistence.type}_getPersistence(){return this.assertedPersistence.persistence}_updateErrorMap(e){this._errorFactory=new us("auth","Firebase",e())}onAuthStateChanged(e,t,r){return this.registerStateListener(this.authStateSubscription,e,t,r)}beforeAuthStateChanged(e,t){return this.beforeStateQueue.pushCallback(e,t)}onIdTokenChanged(e,t,r){return this.registerStateListener(this.idTokenSubscription,e,t,r)}authStateReady(){return new Promise((e,t)=>{if(this.currentUser)e();else{const r=this.onAuthStateChanged(()=>{r(),e()},t)}})}async revokeAccessToken(e){if(this.currentUser){const t=await this.currentUser.getIdToken(),r={providerId:"apple.com",tokenType:"ACCESS_TOKEN",token:e,idToken:t};this.tenantId!=null&&(r.tenantId=this.tenantId),await eb(this,r)}}toJSON(){var e;return{apiKey:this.config.apiKey,authDomain:this.config.authDomain,appName:this.name,currentUser:(e=this._currentUser)==null?void 0:e.toJSON()}}async _setRedirectUser(e,t){const r=await this.getOrInitRedirectPersistenceManager(t);return e===null?r.removeCurrentUser():r.setCurrentUser(e)}async getOrInitRedirectPersistenceManager(e){if(!this.redirectPersistenceManager){const t=e&&wn(e)||this._popupRedirectResolver;te(t,this,"argument-error"),this.redirectPersistenceManager=await ho.create(this,[wn(t._redirectPersistence)],"redirectUser"),this.redirectUser=await this.redirectPersistenceManager.getCurrentUser()}return this.redirectPersistenceManager}async _redirectUserForId(e){var t,r;return this._isInitialized&&await this.queue(async()=>{}),((t=this._currentUser)==null?void 0:t._redirectEventId)===e?this._currentUser:((r=this.redirectUser)==null?void 0:r._redirectEventId)===e?this.redirectUser:null}async _persistUserIfCurrent(e){if(e===this.currentUser)return this.queue(async()=>this.directlySetCurrentUser(e))}_notifyListenersIfCurrent(e){e===this.currentUser&&this.notifyAuthListeners()}_key(){return`${this.config.authDomain}:${this.config.apiKey}:${this.name}`}_startProactiveRefresh(){this.isProactiveRefreshEnabled=!0,this.currentUser&&this._currentUser._startProactiveRefresh()}_stopProactiveRefresh(){this.isProactiveRefreshEnabled=!1,this.currentUser&&this._currentUser._stopProactiveRefresh()}get _currentUser(){return this.currentUser}notifyAuthListeners(){var t;if(!this._isInitialized)return;this.idTokenSubscription.next(this.currentUser);const e=((t=this.currentUser)==null?void 0:t.uid)??null;this.lastNotifiedUid!==e&&(this.lastNotifiedUid=e,this.authStateSubscription.next(this.currentUser))}registerStateListener(e,t,r,o){if(this._deleted)return()=>{};const i=typeof t=="function"?t:t.next.bind(t);let s=!1;const c=this._isInitialized?Promise.resolve():this._initializationPromise;if(te(c,this,"internal-error"),c.then(()=>{s||i(this.currentUser)}),typeof t=="function"){const d=e.addObserver(t,r,o);return()=>{s=!0,d()}}else{const d=e.addObserver(t);return()=>{s=!0,d()}}}async directlySetCurrentUser(e){this.currentUser&&this.currentUser!==e&&this._currentUser._stopProactiveRefresh(),e&&this.isProactiveRefreshEnabled&&e._startProactiveRefresh(),this.currentUser=e,e?await this.assertedPersistence.setCurrentUser(e):await this.assertedPersistence.removeCurrentUser()}queue(e){return this.operations=this.operations.then(e,e),this.operations}get assertedPersistence(){return te(this.persistenceManager,this,"internal-error"),this.persistenceManager}_logFramework(e){!e||this.frameworks.includes(e)||(this.frameworks.push(e),this.frameworks.sort(),this.clientVersion=Up(this.config.clientPlatform,this._getFrameworks()))}_getFrameworks(){return this.frameworks}async _getAdditionalHeaders(){var o;const e={"X-Client-Version":this.clientVersion};this.app.options.appId&&(e["X-Firebase-gmpid"]=this.app.options.appId);const t=await((o=this.heartbeatServiceProvider.getImmediate({optional:!0}))==null?void 0:o.getHeartbeatsHeader());t&&(e["X-Firebase-Client"]=t);const r=await this._getAppCheckToken();return r&&(e["X-Firebase-AppCheck"]=r),e}async _getAppCheckToken(){var t;if(Xt(this.app)&&this.app.settings.appCheckToken)return this.app.settings.appCheckToken;const e=await((t=this.appCheckServiceProvider.getImmediate({optional:!0}))==null?void 0:t.getToken());return e!=null&&e.error&&F_(`Error while retrieving App Check token: ${e.error}`),e==null?void 0:e.token}}function Qa(n){return rt(n)}class Th{constructor(e){this.auth=e,this.observer=null,this.addObserver=Iv(t=>this.observer=t)}get next(){return te(this.observer,this.auth,"internal-error"),this.observer.next.bind(this.observer)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let ou={async loadJS(){throw new Error("Unable to load external scripts")},recaptchaV2Script:"",recaptchaEnterpriseScript:"",gapiScript:""};function lb(n){ou=n}function cb(n){return ou.loadJS(n)}function ub(){return ou.gapiScript}function db(n){return`__${n}${Math.floor(Math.random()*1e6)}`}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function hb(n,e){const t=Qc(n,"auth");if(t.isInitialized()){const o=t.getImmediate(),i=t.getOptions();if(Mr(i,e??{}))return o;kn(o,"already-initialized")}return t.initialize({options:e})}function fb(n,e){const t=(e==null?void 0:e.persistence)||[],r=(Array.isArray(t)?t:[t]).map(wn);e!=null&&e.errorMap&&n._updateErrorMap(e.errorMap),n._initializeWithPersistence(r,e==null?void 0:e.popupRedirectResolver)}function pb(n,e,t){const r=Qa(n);te(/^https?:\/\//.test(e),r,"invalid-emulator-scheme");const o=!1,i=qp(e),{host:s,port:c}=gb(e),d=c===null?"":`:${c}`,u={url:`${i}//${s}${d}/`},f=Object.freeze({host:s,port:c,protocol:i.replace(":",""),options:Object.freeze({disableWarnings:o})});if(!r._canInitEmulator){te(r.config.emulator&&r.emulatorConfig,r,"emulator-config-failed"),te(Mr(u,r.config.emulator)&&Mr(f,r.emulatorConfig),r,"emulator-config-failed");return}r.config.emulator=u,r.emulatorConfig=f,r.settings.appVerificationDisabledForTesting=!0,hs(s)?yp(`${i}//${s}${d}`):mb()}function qp(n){const e=n.indexOf(":");return e<0?"":n.substr(0,e+1)}function gb(n){const e=qp(n),t=/(\/\/)?([^?#/]+)/.exec(n.substr(e.length));if(!t)return{host:"",port:null};const r=t[2].split("@").pop()||"",o=/^(\[[^\]]+\])(:|$)/.exec(r);if(o){const i=o[1];return{host:i,port:Eh(r.substr(i.length+1))}}else{const[i,s]=r.split(":");return{host:i,port:Eh(s)}}}function Eh(n){if(!n)return null;const e=Number(n);return isNaN(e)?null:e}function mb(){function n(){const e=document.createElement("p"),t=e.style;e.innerText="Running in emulator mode. Do not use with production credentials.",t.position="fixed",t.width="100%",t.backgroundColor="#ffffff",t.border=".1em solid #000000",t.color="#b50000",t.bottom="0px",t.left="0px",t.margin="0px",t.zIndex="10000",t.textAlign="center",e.classList.add("firebase-emulator-warning"),document.body.appendChild(e)}typeof console<"u"&&typeof console.info=="function"&&console.info("WARNING: You are using the Auth Emulator, which is intended for local testing only.  Do not use with production credentials."),typeof window<"u"&&typeof document<"u"&&(document.readyState==="loading"?window.addEventListener("DOMContentLoaded",n):n())}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Bp{constructor(e,t){this.providerId=e,this.signInMethod=t}toJSON(){return bn("not implemented")}_getIdTokenResponse(e){return bn("not implemented")}_linkToIdToken(e,t){return bn("not implemented")}_getReauthenticationResolver(e){return bn("not implemented")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function fo(n,e){return W_(n,"POST","/v1/accounts:signInWithIdp",tu(n,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const yb="http://localhost";class Vr extends Bp{constructor(){super(...arguments),this.pendingToken=null}static _fromParams(e){const t=new Vr(e.providerId,e.signInMethod);return e.idToken||e.accessToken?(e.idToken&&(t.idToken=e.idToken),e.accessToken&&(t.accessToken=e.accessToken),e.nonce&&!e.pendingToken&&(t.nonce=e.nonce),e.pendingToken&&(t.pendingToken=e.pendingToken)):e.oauthToken&&e.oauthTokenSecret?(t.accessToken=e.oauthToken,t.secret=e.oauthTokenSecret):kn("argument-error"),t}toJSON(){return{idToken:this.idToken,accessToken:this.accessToken,secret:this.secret,nonce:this.nonce,pendingToken:this.pendingToken,providerId:this.providerId,signInMethod:this.signInMethod}}static fromJSON(e){const t=typeof e=="string"?JSON.parse(e):e,{providerId:r,signInMethod:o,...i}=t;if(!r||!o)return null;const s=new Vr(r,o);return s.idToken=i.idToken||void 0,s.accessToken=i.accessToken||void 0,s.secret=i.secret,s.nonce=i.nonce,s.pendingToken=i.pendingToken||null,s}_getIdTokenResponse(e){const t=this.buildRequest();return fo(e,t)}_linkToIdToken(e,t){const r=this.buildRequest();return r.idToken=t,fo(e,r)}_getReauthenticationResolver(e){const t=this.buildRequest();return t.autoCreate=!1,fo(e,t)}buildRequest(){const e={requestUri:yb,returnSecureToken:!0};if(this.pendingToken)e.pendingToken=this.pendingToken;else{const t={};this.idToken&&(t.id_token=this.idToken),this.accessToken&&(t.access_token=this.accessToken),this.secret&&(t.oauth_token_secret=this.secret),t.providerId=this.providerId,this.nonce&&!this.pendingToken&&(t.nonce=this.nonce),e.postBody=ds(t)}return e}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class $p{constructor(e){this.providerId=e,this.defaultLanguageCode=null,this.customParameters={}}setDefaultLanguage(e){this.defaultLanguageCode=e}setCustomParameters(e){return this.customParameters=e,this}getCustomParameters(){return this.customParameters}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ps extends $p{constructor(){super(...arguments),this.scopes=[]}addScope(e){return this.scopes.includes(e)||this.scopes.push(e),this}getScopes(){return[...this.scopes]}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class jn extends ps{constructor(){super("facebook.com")}static credential(e){return Vr._fromParams({providerId:jn.PROVIDER_ID,signInMethod:jn.FACEBOOK_SIGN_IN_METHOD,accessToken:e})}static credentialFromResult(e){return jn.credentialFromTaggedObject(e)}static credentialFromError(e){return jn.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e||!("oauthAccessToken"in e)||!e.oauthAccessToken)return null;try{return jn.credential(e.oauthAccessToken)}catch{return null}}}jn.FACEBOOK_SIGN_IN_METHOD="facebook.com";jn.PROVIDER_ID="facebook.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _n extends ps{constructor(){super("google.com"),this.addScope("profile")}static credential(e,t){return Vr._fromParams({providerId:_n.PROVIDER_ID,signInMethod:_n.GOOGLE_SIGN_IN_METHOD,idToken:e,accessToken:t})}static credentialFromResult(e){return _n.credentialFromTaggedObject(e)}static credentialFromError(e){return _n.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e)return null;const{oauthIdToken:t,oauthAccessToken:r}=e;if(!t&&!r)return null;try{return _n.credential(t,r)}catch{return null}}}_n.GOOGLE_SIGN_IN_METHOD="google.com";_n.PROVIDER_ID="google.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class zn extends ps{constructor(){super("github.com")}static credential(e){return Vr._fromParams({providerId:zn.PROVIDER_ID,signInMethod:zn.GITHUB_SIGN_IN_METHOD,accessToken:e})}static credentialFromResult(e){return zn.credentialFromTaggedObject(e)}static credentialFromError(e){return zn.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e||!("oauthAccessToken"in e)||!e.oauthAccessToken)return null;try{return zn.credential(e.oauthAccessToken)}catch{return null}}}zn.GITHUB_SIGN_IN_METHOD="github.com";zn.PROVIDER_ID="github.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Wn extends ps{constructor(){super("twitter.com")}static credential(e,t){return Vr._fromParams({providerId:Wn.PROVIDER_ID,signInMethod:Wn.TWITTER_SIGN_IN_METHOD,oauthToken:e,oauthTokenSecret:t})}static credentialFromResult(e){return Wn.credentialFromTaggedObject(e)}static credentialFromError(e){return Wn.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e)return null;const{oauthAccessToken:t,oauthTokenSecret:r}=e;if(!t||!r)return null;try{return Wn.credential(t,r)}catch{return null}}}Wn.TWITTER_SIGN_IN_METHOD="twitter.com";Wn.PROVIDER_ID="twitter.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ao{constructor(e){this.user=e.user,this.providerId=e.providerId,this._tokenResponse=e._tokenResponse,this.operationType=e.operationType}static async _fromIdTokenResponse(e,t,r,o=!1){const i=await Ut._fromIdTokenResponse(e,r,o),s=Ih(r);return new Ao({user:i,providerId:s,_tokenResponse:r,operationType:t})}static async _forOperation(e,t,r){await e._updateTokensIfNecessary(r,!0);const o=Ih(r);return new Ao({user:e,providerId:o,_tokenResponse:r,operationType:t})}}function Ih(n){return n.providerId?n.providerId:"phoneNumber"in n?"phone":null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ia extends Nn{constructor(e,t,r,o){super(t.code,t.message),this.operationType=r,this.user=o,Object.setPrototypeOf(this,Ia.prototype),this.customData={appName:e.name,tenantId:e.tenantId??void 0,_serverResponse:t.customData._serverResponse,operationType:r}}static _fromErrorAndOperation(e,t,r,o){return new Ia(e,t,r,o)}}function jp(n,e,t,r){return(e==="reauthenticate"?t._getReauthenticationResolver(n):t._getIdTokenResponse(n)).catch(i=>{throw i.code==="auth/multi-factor-auth-required"?Ia._fromErrorAndOperation(n,i,e,r):i})}async function vb(n,e,t=!1){const r=await Wi(n,e._linkToIdToken(n.auth,await n.getIdToken()),t);return Ao._forOperation(n,"link",r)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function _b(n,e,t=!1){const{auth:r}=n;if(Xt(r.app))return Promise.reject(Cr(r));const o="reauthenticate";try{const i=await Wi(n,jp(r,o,e,n),t);te(i.idToken,r,"internal-error");const s=nu(i.idToken);te(s,r,"internal-error");const{sub:c}=s;return te(n.uid===c,r,"user-mismatch"),Ao._forOperation(n,o,i)}catch(i){throw(i==null?void 0:i.code)==="auth/user-not-found"&&kn(r,"user-mismatch"),i}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function zp(n,e,t=!1){if(Xt(n.app))return Promise.reject(Cr(n));const r="signIn",o=await jp(n,r,e),i=await Ao._fromIdTokenResponse(n,r,o);return t||await n._updateCurrentUser(i.user),i}async function bb(n,e){return zp(Qa(n),e)}function wb(n,e,t,r){return rt(n).onIdTokenChanged(e,t,r)}function Tb(n,e,t){return rt(n).beforeAuthStateChanged(e,t)}function Eb(n,e,t,r){return rt(n).onAuthStateChanged(e,t,r)}function Ib(n){return rt(n).signOut()}const Sa="__sak";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Wp{constructor(e,t){this.storageRetriever=e,this.type=t}_isAvailable(){try{return this.storage?(this.storage.setItem(Sa,"1"),this.storage.removeItem(Sa),Promise.resolve(!0)):Promise.resolve(!1)}catch{return Promise.resolve(!1)}}_set(e,t){return this.storage.setItem(e,JSON.stringify(t)),Promise.resolve()}_get(e){const t=this.storage.getItem(e);return Promise.resolve(t?JSON.parse(t):null)}_remove(e){return this.storage.removeItem(e),Promise.resolve()}get storage(){return this.storageRetriever()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Sb=1e3,xb=10;class Hp extends Wp{constructor(){super(()=>window.localStorage,"LOCAL"),this.boundEventHandler=(e,t)=>this.onStorageEvent(e,t),this.listeners={},this.localCache={},this.pollTimer=null,this.fallbackToPolling=Fp(),this._shouldAllowMigration=!0}forAllChangedKeys(e){for(const t of Object.keys(this.listeners)){const r=this.storage.getItem(t),o=this.localCache[t];r!==o&&e(t,o,r)}}onStorageEvent(e,t=!1){if(!e.key){this.forAllChangedKeys((s,c,d)=>{this.notifyListeners(s,d)});return}const r=e.key;t?this.detachListener():this.stopPolling();const o=()=>{const s=this.storage.getItem(r);!t&&this.localCache[r]===s||this.notifyListeners(r,s)},i=this.storage.getItem(r);nb()&&i!==e.newValue&&e.newValue!==e.oldValue?setTimeout(o,xb):o()}notifyListeners(e,t){this.localCache[e]=t;const r=this.listeners[e];if(r)for(const o of Array.from(r))o(t&&JSON.parse(t))}startPolling(){this.stopPolling(),this.pollTimer=setInterval(()=>{this.forAllChangedKeys((e,t,r)=>{this.onStorageEvent(new StorageEvent("storage",{key:e,oldValue:t,newValue:r}),!0)})},Sb)}stopPolling(){this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}attachListener(){window.addEventListener("storage",this.boundEventHandler)}detachListener(){window.removeEventListener("storage",this.boundEventHandler)}_addListener(e,t){Object.keys(this.listeners).length===0&&(this.fallbackToPolling?this.startPolling():this.attachListener()),this.listeners[e]||(this.listeners[e]=new Set,this.localCache[e]=this.storage.getItem(e)),this.listeners[e].add(t)}_removeListener(e,t){this.listeners[e]&&(this.listeners[e].delete(t),this.listeners[e].size===0&&delete this.listeners[e]),Object.keys(this.listeners).length===0&&(this.detachListener(),this.stopPolling())}async _set(e,t){await super._set(e,t),this.localCache[e]=JSON.stringify(t)}async _get(e){const t=await super._get(e);return this.localCache[e]=JSON.stringify(t),t}async _remove(e){await super._remove(e),delete this.localCache[e]}}Hp.type="LOCAL";const Ab=Hp;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Gp extends Wp{constructor(){super(()=>window.sessionStorage,"SESSION")}_addListener(e,t){}_removeListener(e,t){}}Gp.type="SESSION";const Yp=Gp;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function kb(n){return Promise.all(n.map(async e=>{try{return{fulfilled:!0,value:await e}}catch(t){return{fulfilled:!1,reason:t}}}))}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ja{constructor(e){this.eventTarget=e,this.handlersMap={},this.boundEventHandler=this.handleEvent.bind(this)}static _getInstance(e){const t=this.receivers.find(o=>o.isListeningto(e));if(t)return t;const r=new Ja(e);return this.receivers.push(r),r}isListeningto(e){return this.eventTarget===e}async handleEvent(e){const t=e,{eventId:r,eventType:o,data:i}=t.data,s=this.handlersMap[o];if(!(s!=null&&s.size))return;t.ports[0].postMessage({status:"ack",eventId:r,eventType:o});const c=Array.from(s).map(async u=>u(t.origin,i)),d=await kb(c);t.ports[0].postMessage({status:"done",eventId:r,eventType:o,response:d})}_subscribe(e,t){Object.keys(this.handlersMap).length===0&&this.eventTarget.addEventListener("message",this.boundEventHandler),this.handlersMap[e]||(this.handlersMap[e]=new Set),this.handlersMap[e].add(t)}_unsubscribe(e,t){this.handlersMap[e]&&t&&this.handlersMap[e].delete(t),(!t||this.handlersMap[e].size===0)&&delete this.handlersMap[e],Object.keys(this.handlersMap).length===0&&this.eventTarget.removeEventListener("message",this.boundEventHandler)}}Ja.receivers=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function iu(n="",e=10){let t="";for(let r=0;r<e;r++)t+=Math.floor(Math.random()*10);return n+t}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Pb{constructor(e){this.target=e,this.handlers=new Set}removeMessageHandler(e){e.messageChannel&&(e.messageChannel.port1.removeEventListener("message",e.onMessage),e.messageChannel.port1.close()),this.handlers.delete(e)}async _send(e,t,r=50){const o=typeof MessageChannel<"u"?new MessageChannel:null;if(!o)throw new Error("connection_unavailable");let i,s;return new Promise((c,d)=>{const u=iu("",20);o.port1.start();const f=setTimeout(()=>{d(new Error("unsupported_event"))},r);s={messageChannel:o,onMessage(g){const m=g;if(m.data.eventId===u)switch(m.data.status){case"ack":clearTimeout(f),i=setTimeout(()=>{d(new Error("timeout"))},3e3);break;case"done":clearTimeout(i),c(m.data.response);break;default:clearTimeout(f),clearTimeout(i),d(new Error("invalid_response"));break}}},this.handlers.add(s),o.port1.addEventListener("message",s.onMessage),this.target.postMessage({eventType:e,eventId:u,data:t},[o.port2])}).finally(()=>{s&&this.removeMessageHandler(s)})}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function on(){return window}function Cb(n){on().location.href=n}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Kp(){return typeof on().WorkerGlobalScope<"u"&&typeof on().importScripts=="function"}async function Rb(){if(!(navigator!=null&&navigator.serviceWorker))return null;try{return(await navigator.serviceWorker.ready).active}catch{return null}}function Ob(){var n;return((n=navigator==null?void 0:navigator.serviceWorker)==null?void 0:n.controller)||null}function Nb(){return Kp()?self:null}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Xp="firebaseLocalStorageDb",Lb=1,xa="firebaseLocalStorage",Qp="fbase_key";class gs{constructor(e){this.request=e}toPromise(){return new Promise((e,t)=>{this.request.addEventListener("success",()=>{e(this.request.result)}),this.request.addEventListener("error",()=>{t(this.request.error)})})}}function Za(n,e){return n.transaction([xa],e?"readwrite":"readonly").objectStore(xa)}function Mb(){const n=indexedDB.deleteDatabase(Xp);return new gs(n).toPromise()}function hc(){const n=indexedDB.open(Xp,Lb);return new Promise((e,t)=>{n.addEventListener("error",()=>{t(n.error)}),n.addEventListener("upgradeneeded",()=>{const r=n.result;try{r.createObjectStore(xa,{keyPath:Qp})}catch(o){t(o)}}),n.addEventListener("success",async()=>{const r=n.result;r.objectStoreNames.contains(xa)?e(r):(r.close(),await Mb(),e(await hc()))})})}async function Sh(n,e,t){const r=Za(n,!0).put({[Qp]:e,value:t});return new gs(r).toPromise()}async function Db(n,e){const t=Za(n,!1).get(e),r=await new gs(t).toPromise();return r===void 0?null:r.value}function xh(n,e){const t=Za(n,!0).delete(e);return new gs(t).toPromise()}const Vb=800,Fb=3;class Jp{constructor(){this.type="LOCAL",this._shouldAllowMigration=!0,this.listeners={},this.localCache={},this.pollTimer=null,this.pendingWrites=0,this.receiver=null,this.sender=null,this.serviceWorkerReceiverAvailable=!1,this.activeServiceWorker=null,this._workerInitializationPromise=this.initializeServiceWorkerMessaging().then(()=>{},()=>{})}async _openDb(){return this.db?this.db:(this.db=await hc(),this.db)}async _withRetries(e){let t=0;for(;;)try{const r=await this._openDb();return await e(r)}catch(r){if(t++>Fb)throw r;this.db&&(this.db.close(),this.db=void 0)}}async initializeServiceWorkerMessaging(){return Kp()?this.initializeReceiver():this.initializeSender()}async initializeReceiver(){this.receiver=Ja._getInstance(Nb()),this.receiver._subscribe("keyChanged",async(e,t)=>({keyProcessed:(await this._poll()).includes(t.key)})),this.receiver._subscribe("ping",async(e,t)=>["keyChanged"])}async initializeSender(){var t,r;if(this.activeServiceWorker=await Rb(),!this.activeServiceWorker)return;this.sender=new Pb(this.activeServiceWorker);const e=await this.sender._send("ping",{},800);e&&(t=e[0])!=null&&t.fulfilled&&(r=e[0])!=null&&r.value.includes("keyChanged")&&(this.serviceWorkerReceiverAvailable=!0)}async notifyServiceWorker(e){if(!(!this.sender||!this.activeServiceWorker||Ob()!==this.activeServiceWorker))try{await this.sender._send("keyChanged",{key:e},this.serviceWorkerReceiverAvailable?800:50)}catch{}}async _isAvailable(){try{if(!indexedDB)return!1;const e=await hc();return await Sh(e,Sa,"1"),await xh(e,Sa),!0}catch{}return!1}async _withPendingWrite(e){this.pendingWrites++;try{await e()}finally{this.pendingWrites--}}async _set(e,t){return this._withPendingWrite(async()=>(await this._withRetries(r=>Sh(r,e,t)),this.localCache[e]=t,this.notifyServiceWorker(e)))}async _get(e){const t=await this._withRetries(r=>Db(r,e));return this.localCache[e]=t,t}async _remove(e){return this._withPendingWrite(async()=>(await this._withRetries(t=>xh(t,e)),delete this.localCache[e],this.notifyServiceWorker(e)))}async _poll(){const e=await this._withRetries(o=>{const i=Za(o,!1).getAll();return new gs(i).toPromise()});if(!e)return[];if(this.pendingWrites!==0)return[];const t=[],r=new Set;if(e.length!==0)for(const{fbase_key:o,value:i}of e)r.add(o),JSON.stringify(this.localCache[o])!==JSON.stringify(i)&&(this.notifyListeners(o,i),t.push(o));for(const o of Object.keys(this.localCache))this.localCache[o]&&!r.has(o)&&(this.notifyListeners(o,null),t.push(o));return t}notifyListeners(e,t){this.localCache[e]=t;const r=this.listeners[e];if(r)for(const o of Array.from(r))o(t)}startPolling(){this.stopPolling(),this.pollTimer=setInterval(async()=>this._poll(),Vb)}stopPolling(){this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}_addListener(e,t){Object.keys(this.listeners).length===0&&this.startPolling(),this.listeners[e]||(this.listeners[e]=new Set,this._get(e)),this.listeners[e].add(t)}_removeListener(e,t){this.listeners[e]&&(this.listeners[e].delete(t),this.listeners[e].size===0&&delete this.listeners[e]),Object.keys(this.listeners).length===0&&this.stopPolling()}}Jp.type="LOCAL";const Ub=Jp;new fs(3e4,6e4);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function qb(n,e){return e?wn(e):(te(n._popupRedirectResolver,n,"argument-error"),n._popupRedirectResolver)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class su extends Bp{constructor(e){super("custom","custom"),this.params=e}_getIdTokenResponse(e){return fo(e,this._buildIdpRequest())}_linkToIdToken(e,t){return fo(e,this._buildIdpRequest(t))}_getReauthenticationResolver(e){return fo(e,this._buildIdpRequest())}_buildIdpRequest(e){const t={requestUri:this.params.requestUri,sessionId:this.params.sessionId,postBody:this.params.postBody,tenantId:this.params.tenantId,pendingToken:this.params.pendingToken,returnSecureToken:!0,returnIdpCredential:!0};return e&&(t.idToken=e),t}}function Bb(n){return zp(n.auth,new su(n),n.bypassAuthState)}function $b(n){const{auth:e,user:t}=n;return te(t,e,"internal-error"),_b(t,new su(n),n.bypassAuthState)}async function jb(n){const{auth:e,user:t}=n;return te(t,e,"internal-error"),vb(t,new su(n),n.bypassAuthState)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Zp{constructor(e,t,r,o,i=!1){this.auth=e,this.resolver=r,this.user=o,this.bypassAuthState=i,this.pendingPromise=null,this.eventManager=null,this.filter=Array.isArray(t)?t:[t]}execute(){return new Promise(async(e,t)=>{this.pendingPromise={resolve:e,reject:t};try{this.eventManager=await this.resolver._initialize(this.auth),await this.onExecution(),this.eventManager.registerConsumer(this)}catch(r){this.reject(r)}})}async onAuthEvent(e){const{urlResponse:t,sessionId:r,postBody:o,tenantId:i,error:s,type:c}=e;if(s){this.reject(s);return}const d={auth:this.auth,requestUri:t,sessionId:r,tenantId:i||void 0,postBody:o||void 0,user:this.user,bypassAuthState:this.bypassAuthState};try{this.resolve(await this.getIdpTask(c)(d))}catch(u){this.reject(u)}}onError(e){this.reject(e)}getIdpTask(e){switch(e){case"signInViaPopup":case"signInViaRedirect":return Bb;case"linkViaPopup":case"linkViaRedirect":return jb;case"reauthViaPopup":case"reauthViaRedirect":return $b;default:kn(this.auth,"internal-error")}}resolve(e){Pn(this.pendingPromise,"Pending promise was never set"),this.pendingPromise.resolve(e),this.unregisterAndCleanUp()}reject(e){Pn(this.pendingPromise,"Pending promise was never set"),this.pendingPromise.reject(e),this.unregisterAndCleanUp()}unregisterAndCleanUp(){this.eventManager&&this.eventManager.unregisterConsumer(this),this.pendingPromise=null,this.cleanUp()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const zb=new fs(2e3,1e4);class lo extends Zp{constructor(e,t,r,o,i){super(e,t,o,i),this.provider=r,this.authWindow=null,this.pollId=null,lo.currentPopupAction&&lo.currentPopupAction.cancel(),lo.currentPopupAction=this}async executeNotNull(){const e=await this.execute();return te(e,this.auth,"internal-error"),e}async onExecution(){Pn(this.filter.length===1,"Popup operations only handle one event");const e=iu();this.authWindow=await this.resolver._openPopup(this.auth,this.provider,this.filter[0],e),this.authWindow.associatedEvent=e,this.resolver._originValidation(this.auth).catch(t=>{this.reject(t)}),this.resolver._isIframeWebStorageSupported(this.auth,t=>{t||this.reject(rn(this.auth,"web-storage-unsupported"))}),this.pollUserCancellation()}get eventId(){var e;return((e=this.authWindow)==null?void 0:e.associatedEvent)||null}cancel(){this.reject(rn(this.auth,"cancelled-popup-request"))}cleanUp(){this.authWindow&&this.authWindow.close(),this.pollId&&window.clearTimeout(this.pollId),this.authWindow=null,this.pollId=null,lo.currentPopupAction=null}pollUserCancellation(){const e=()=>{var t,r;if((r=(t=this.authWindow)==null?void 0:t.window)!=null&&r.closed){this.pollId=window.setTimeout(()=>{this.pollId=null,this.reject(rn(this.auth,"popup-closed-by-user"))},8e3);return}this.pollId=window.setTimeout(e,zb.get())};e()}}lo.currentPopupAction=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Wb="pendingRedirect",sa=new Map;class Hb extends Zp{constructor(e,t,r=!1){super(e,["signInViaRedirect","linkViaRedirect","reauthViaRedirect","unknown"],t,void 0,r),this.eventId=null}async execute(){let e=sa.get(this.auth._key());if(!e){try{const r=await Gb(this.resolver,this.auth)?await super.execute():null;e=()=>Promise.resolve(r)}catch(t){e=()=>Promise.reject(t)}sa.set(this.auth._key(),e)}return this.bypassAuthState||sa.set(this.auth._key(),()=>Promise.resolve(null)),e()}async onAuthEvent(e){if(e.type==="signInViaRedirect")return super.onAuthEvent(e);if(e.type==="unknown"){this.resolve(null);return}if(e.eventId){const t=await this.auth._redirectUserForId(e.eventId);if(t)return this.user=t,super.onAuthEvent(e);this.resolve(null)}}async onExecution(){}cleanUp(){}}async function Gb(n,e){const t=Xb(e),r=Kb(n);if(!await r._isAvailable())return!1;const o=await r._get(t)==="true";return await r._remove(t),o}function Yb(n,e){sa.set(n._key(),e)}function Kb(n){return wn(n._redirectPersistence)}function Xb(n){return ia(Wb,n.config.apiKey,n.name)}async function Qb(n,e,t=!1){if(Xt(n.app))return Promise.reject(Cr(n));const r=Qa(n),o=qb(r,e),s=await new Hb(r,o,t).execute();return s&&!t&&(delete s.user._redirectEventId,await r._persistUserIfCurrent(s.user),await r._setRedirectUser(null,e)),s}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Jb=10*60*1e3;class Zb{constructor(e){this.auth=e,this.cachedEventUids=new Set,this.consumers=new Set,this.queuedRedirectEvent=null,this.hasHandledPotentialRedirect=!1,this.lastProcessedEventTime=Date.now()}registerConsumer(e){this.consumers.add(e),this.queuedRedirectEvent&&this.isEventForConsumer(this.queuedRedirectEvent,e)&&(this.sendToConsumer(this.queuedRedirectEvent,e),this.saveEventToCache(this.queuedRedirectEvent),this.queuedRedirectEvent=null)}unregisterConsumer(e){this.consumers.delete(e)}onEvent(e){if(this.hasEventBeenHandled(e))return!1;let t=!1;return this.consumers.forEach(r=>{this.isEventForConsumer(e,r)&&(t=!0,this.sendToConsumer(e,r),this.saveEventToCache(e))}),this.hasHandledPotentialRedirect||!ew(e)||(this.hasHandledPotentialRedirect=!0,t||(this.queuedRedirectEvent=e,t=!0)),t}sendToConsumer(e,t){var r;if(e.error&&!eg(e)){const o=((r=e.error.code)==null?void 0:r.split("auth/")[1])||"internal-error";t.onError(rn(this.auth,o))}else t.onAuthEvent(e)}isEventForConsumer(e,t){const r=t.eventId===null||!!e.eventId&&e.eventId===t.eventId;return t.filter.includes(e.type)&&r}hasEventBeenHandled(e){return Date.now()-this.lastProcessedEventTime>=Jb&&this.cachedEventUids.clear(),this.cachedEventUids.has(Ah(e))}saveEventToCache(e){this.cachedEventUids.add(Ah(e)),this.lastProcessedEventTime=Date.now()}}function Ah(n){return[n.type,n.eventId,n.sessionId,n.tenantId].filter(e=>e).join("-")}function eg({type:n,error:e}){return n==="unknown"&&(e==null?void 0:e.code)==="auth/no-auth-event"}function ew(n){switch(n.type){case"signInViaRedirect":case"linkViaRedirect":case"reauthViaRedirect":return!0;case"unknown":return eg(n);default:return!1}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function tw(n,e={}){return Uo(n,"GET","/v1/projects",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const nw=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,rw=/^https?/;async function ow(n){if(n.config.emulator)return;const{authorizedDomains:e}=await tw(n);for(const t of e)try{if(iw(t))return}catch{}kn(n,"unauthorized-domain")}function iw(n){const e=uc(),{protocol:t,hostname:r}=new URL(e);if(n.startsWith("chrome-extension://")){const s=new URL(n);return s.hostname===""&&r===""?t==="chrome-extension:"&&n.replace("chrome-extension://","")===e.replace("chrome-extension://",""):t==="chrome-extension:"&&s.hostname===r}if(!rw.test(t))return!1;if(nw.test(n))return r===n;const o=n.replace(/\./g,"\\.");return new RegExp("^(.+\\."+o+"|"+o+")$","i").test(r)}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const sw=new fs(3e4,6e4);function kh(){const n=on().___jsl;if(n!=null&&n.H){for(const e of Object.keys(n.H))if(n.H[e].r=n.H[e].r||[],n.H[e].L=n.H[e].L||[],n.H[e].r=[...n.H[e].L],n.CP)for(let t=0;t<n.CP.length;t++)n.CP[t]=null}}function aw(n){return new Promise((e,t)=>{var o,i,s;function r(){kh(),gapi.load("gapi.iframes",{callback:()=>{e(gapi.iframes.getContext())},ontimeout:()=>{kh(),t(rn(n,"network-request-failed"))},timeout:sw.get()})}if((i=(o=on().gapi)==null?void 0:o.iframes)!=null&&i.Iframe)e(gapi.iframes.getContext());else if((s=on().gapi)!=null&&s.load)r();else{const c=db("iframefcb");return on()[c]=()=>{gapi.load?r():t(rn(n,"network-request-failed"))},cb(`${ub()}?onload=${c}`).catch(d=>t(d))}}).catch(e=>{throw aa=null,e})}let aa=null;function lw(n){return aa=aa||aw(n),aa}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const cw=new fs(5e3,15e3),uw="__/auth/iframe",dw="emulator/auth/iframe",hw={style:{position:"absolute",top:"-100px",width:"1px",height:"1px"},"aria-hidden":"true",tabindex:"-1"},fw=new Map([["identitytoolkit.googleapis.com","p"],["staging-identitytoolkit.sandbox.googleapis.com","s"],["test-identitytoolkit.sandbox.googleapis.com","t"]]);function pw(n){const e=n.config;te(e.authDomain,n,"auth-domain-config-required");const t=e.emulator?eu(e,dw):`https://${n.config.authDomain}/${uw}`,r={apiKey:e.apiKey,appName:n.name,v:Fo},o=fw.get(n.config.apiHost);o&&(r.eid=o);const i=n._getFrameworks();return i.length&&(r.fw=i.join(",")),`${t}?${ds(r).slice(1)}`}async function gw(n){const e=await lw(n),t=on().gapi;return te(t,n,"internal-error"),e.open({where:document.body,url:pw(n),messageHandlersFilter:t.iframes.CROSS_ORIGIN_IFRAMES_FILTER,attributes:hw,dontclear:!0},r=>new Promise(async(o,i)=>{await r.restyle({setHideOnLeave:!1});const s=rn(n,"network-request-failed"),c=on().setTimeout(()=>{i(s)},cw.get());function d(){on().clearTimeout(c),o(r)}r.ping(d).then(d,()=>{i(s)})}))}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const mw={location:"yes",resizable:"yes",statusbar:"yes",toolbar:"no"},yw=500,vw=600,_w="_blank",bw="http://localhost";class Ph{constructor(e){this.window=e,this.associatedEvent=null}close(){if(this.window)try{this.window.close()}catch{}}}function ww(n,e,t,r=yw,o=vw){const i=Math.max((window.screen.availHeight-o)/2,0).toString(),s=Math.max((window.screen.availWidth-r)/2,0).toString();let c="";const d={...mw,width:r.toString(),height:o.toString(),top:i,left:s},u=ht().toLowerCase();t&&(c=Np(u)?_w:t),Rp(u)&&(e=e||bw,d.scrollbars="yes");const f=Object.entries(d).reduce((m,[v,L])=>`${m}${v}=${L},`,"");if(tb(u)&&c!=="_self")return Tw(e||"",c),new Ph(null);const g=window.open(e||"",c,f);te(g,n,"popup-blocked");try{g.focus()}catch{}return new Ph(g)}function Tw(n,e){const t=document.createElement("a");t.href=n,t.target=e;const r=document.createEvent("MouseEvent");r.initMouseEvent("click",!0,!0,window,1,0,0,0,0,!1,!1,!1,!1,1,null),t.dispatchEvent(r)}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ew="__/auth/handler",Iw="emulator/auth/handler",Sw=encodeURIComponent("fac");async function Ch(n,e,t,r,o,i){te(n.config.authDomain,n,"auth-domain-config-required"),te(n.config.apiKey,n,"invalid-api-key");const s={apiKey:n.config.apiKey,appName:n.name,authType:t,redirectUrl:r,v:Fo,eventId:o};if(e instanceof $p){e.setDefaultLanguage(n.languageCode),s.providerId=e.providerId||"",Ev(e.getCustomParameters())||(s.customParameters=JSON.stringify(e.getCustomParameters()));for(const[f,g]of Object.entries({}))s[f]=g}if(e instanceof ps){const f=e.getScopes().filter(g=>g!=="");f.length>0&&(s.scopes=f.join(","))}n.tenantId&&(s.tid=n.tenantId);const c=s;for(const f of Object.keys(c))c[f]===void 0&&delete c[f];const d=await n._getAppCheckToken(),u=d?`#${Sw}=${encodeURIComponent(d)}`:"";return`${xw(n)}?${ds(c).slice(1)}${u}`}function xw({config:n}){return n.emulator?eu(n,Iw):`https://${n.authDomain}/${Ew}`}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const jl="webStorageSupport";class Aw{constructor(){this.eventManagers={},this.iframes={},this.originValidationPromises={},this._redirectPersistence=Yp,this._completeRedirectFn=Qb,this._overrideRedirectResult=Yb}async _openPopup(e,t,r,o){var s;Pn((s=this.eventManagers[e._key()])==null?void 0:s.manager,"_initialize() not called before _openPopup()");const i=await Ch(e,t,r,uc(),o);return ww(e,i,iu())}async _openRedirect(e,t,r,o){await this._originValidation(e);const i=await Ch(e,t,r,uc(),o);return Cb(i),new Promise(()=>{})}_initialize(e){const t=e._key();if(this.eventManagers[t]){const{manager:o,promise:i}=this.eventManagers[t];return o?Promise.resolve(o):(Pn(i,"If manager is not set, promise should be"),i)}const r=this.initAndGetManager(e);return this.eventManagers[t]={promise:r},r.catch(()=>{delete this.eventManagers[t]}),r}async initAndGetManager(e){const t=await gw(e),r=new Zb(e);return t.register("authEvent",o=>(te(o==null?void 0:o.authEvent,e,"invalid-auth-event"),{status:r.onEvent(o.authEvent)?"ACK":"ERROR"}),gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER),this.eventManagers[e._key()]={manager:r},this.iframes[e._key()]=t,r}_isIframeWebStorageSupported(e,t){this.iframes[e._key()].send(jl,{type:jl},o=>{var s;const i=(s=o==null?void 0:o[0])==null?void 0:s[jl];i!==void 0&&t(!!i),kn(e,"internal-error")},gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER)}_originValidation(e){const t=e._key();return this.originValidationPromises[t]||(this.originValidationPromises[t]=ow(e)),this.originValidationPromises[t]}get _shouldInitProactively(){return Fp()||Op()||ru()}}const kw=Aw;var Rh="@firebase/auth",Oh="1.13.0";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Pw{constructor(e){this.auth=e,this.internalListeners=new Map}getUid(){var e;return this.assertAuthConfigured(),((e=this.auth.currentUser)==null?void 0:e.uid)||null}async getToken(e){return this.assertAuthConfigured(),await this.auth._initializationPromise,this.auth.currentUser?{accessToken:await this.auth.currentUser.getIdToken(e)}:null}addAuthTokenListener(e){if(this.assertAuthConfigured(),this.internalListeners.has(e))return;const t=this.auth.onIdTokenChanged(r=>{e((r==null?void 0:r.stsTokenManager.accessToken)||null)});this.internalListeners.set(e,t),this.updateProactiveRefresh()}removeAuthTokenListener(e){this.assertAuthConfigured();const t=this.internalListeners.get(e);t&&(this.internalListeners.delete(e),t(),this.updateProactiveRefresh())}assertAuthConfigured(){te(this.auth._initializationPromise,"dependent-sdk-initialized-before-auth")}updateProactiveRefresh(){this.internalListeners.size>0?this.auth._startProactiveRefresh():this.auth._stopProactiveRefresh()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Cw(n){switch(n){case"Node":return"node";case"ReactNative":return"rn";case"Worker":return"webworker";case"Cordova":return"cordova";case"WebExtension":return"web-extension";default:return}}function Rw(n){xo(new Dr("auth",(e,{options:t})=>{const r=e.getProvider("app").getImmediate(),o=e.getProvider("heartbeat"),i=e.getProvider("app-check-internal"),{apiKey:s,authDomain:c}=r.options;te(s&&!s.includes(":"),"invalid-api-key",{appName:r.name});const d={apiKey:s,authDomain:c,clientPlatform:n,apiHost:"identitytoolkit.googleapis.com",tokenApiHost:"securetoken.googleapis.com",apiScheme:"https",sdkClientVersion:Up(n)},u=new ab(r,o,i,d);return fb(u,t),u},"PUBLIC").setInstantiationMode("EXPLICIT").setInstanceCreatedCallback((e,t,r)=>{e.getProvider("auth-internal").initialize()})),xo(new Dr("auth-internal",e=>{const t=Qa(e.getProvider("auth").getImmediate());return(r=>new Pw(r))(t)},"PRIVATE").setInstantiationMode("EXPLICIT")),Jn(Rh,Oh,Cw(n)),Jn(Rh,Oh,"esm2020")}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ow=5*60,Nw=mp("authIdTokenMaxAge")||Ow;let Nh=null;const Lw=n=>async e=>{const t=e&&await e.getIdTokenResult(),r=t&&(new Date().getTime()-Date.parse(t.issuedAtTime))/1e3;if(r&&r>Nw)return;const o=t==null?void 0:t.token;Nh!==o&&(Nh=o,await fetch(n,{method:o?"POST":"DELETE",headers:o?{Authorization:`Bearer ${o}`}:{}}))};function Mw(n=bp()){const e=Qc(n,"auth");if(e.isInitialized())return e.getImmediate();const t=hb(n,{popupRedirectResolver:kw,persistence:[Ub,Ab,Yp]}),r=mp("authTokenSyncURL");if(r&&typeof isSecureContext=="boolean"&&isSecureContext){const i=new URL(r,location.origin);if(location.origin===i.origin){const s=Lw(i.toString());Tb(t,s,()=>s(t.currentUser)),wb(t,c=>s(c))}}const o=pp("auth");return o&&pb(t,`http://${o}`),t}function Dw(){var n;return((n=document.getElementsByTagName("head"))==null?void 0:n[0])??document}lb({loadJS(n){return new Promise((e,t)=>{const r=document.createElement("script");r.setAttribute("src",n),r.onload=e,r.onerror=o=>{const i=rn("internal-error");i.customData=o,t(i)},r.type="text/javascript",r.charset="UTF-8",Dw().appendChild(r)})},gapiScript:"https://apis.google.com/js/api.js",recaptchaV2Script:"https://www.google.com/recaptcha/api.js",recaptchaEnterpriseScript:"https://www.google.com/recaptcha/enterprise.js?render="});Rw("Browser");const tg={apiKey:"AIzaSyDgeMII4vDFmjXVKnrBYV8ane76eSzyUN8",authDomain:"overlay-runner.firebaseapp.com",databaseURL:"https://overlay-runner-default-rtdb.firebaseio.com",projectId:"overlay-runner",storageBucket:"overlay-runner.firebasestorage.app",messagingSenderId:"951272023115",appId:"1:951272023115:web:0f75edb7fb291a118119ce"};var Lh=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/var Zn,ng;(function(){var n;/** @license

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/function e(I,b){function _(){}_.prototype=b.prototype,I.F=b.prototype,I.prototype=new _,I.prototype.constructor=I,I.D=function(E,T,S){for(var w=Array(arguments.length-2),Z=2;Z<arguments.length;Z++)w[Z-2]=arguments[Z];return b.prototype[T].apply(E,w)}}function t(){this.blockSize=-1}function r(){this.blockSize=-1,this.blockSize=64,this.g=Array(4),this.C=Array(this.blockSize),this.o=this.h=0,this.u()}e(r,t),r.prototype.u=function(){this.g[0]=1732584193,this.g[1]=4023233417,this.g[2]=2562383102,this.g[3]=271733878,this.o=this.h=0};function o(I,b,_){_||(_=0);const E=Array(16);if(typeof b=="string")for(var T=0;T<16;++T)E[T]=b.charCodeAt(_++)|b.charCodeAt(_++)<<8|b.charCodeAt(_++)<<16|b.charCodeAt(_++)<<24;else for(T=0;T<16;++T)E[T]=b[_++]|b[_++]<<8|b[_++]<<16|b[_++]<<24;b=I.g[0],_=I.g[1],T=I.g[2];let S=I.g[3],w;w=b+(S^_&(T^S))+E[0]+3614090360&4294967295,b=_+(w<<7&4294967295|w>>>25),w=S+(T^b&(_^T))+E[1]+3905402710&4294967295,S=b+(w<<12&4294967295|w>>>20),w=T+(_^S&(b^_))+E[2]+606105819&4294967295,T=S+(w<<17&4294967295|w>>>15),w=_+(b^T&(S^b))+E[3]+3250441966&4294967295,_=T+(w<<22&4294967295|w>>>10),w=b+(S^_&(T^S))+E[4]+4118548399&4294967295,b=_+(w<<7&4294967295|w>>>25),w=S+(T^b&(_^T))+E[5]+1200080426&4294967295,S=b+(w<<12&4294967295|w>>>20),w=T+(_^S&(b^_))+E[6]+2821735955&4294967295,T=S+(w<<17&4294967295|w>>>15),w=_+(b^T&(S^b))+E[7]+4249261313&4294967295,_=T+(w<<22&4294967295|w>>>10),w=b+(S^_&(T^S))+E[8]+1770035416&4294967295,b=_+(w<<7&4294967295|w>>>25),w=S+(T^b&(_^T))+E[9]+2336552879&4294967295,S=b+(w<<12&4294967295|w>>>20),w=T+(_^S&(b^_))+E[10]+4294925233&4294967295,T=S+(w<<17&4294967295|w>>>15),w=_+(b^T&(S^b))+E[11]+2304563134&4294967295,_=T+(w<<22&4294967295|w>>>10),w=b+(S^_&(T^S))+E[12]+1804603682&4294967295,b=_+(w<<7&4294967295|w>>>25),w=S+(T^b&(_^T))+E[13]+4254626195&4294967295,S=b+(w<<12&4294967295|w>>>20),w=T+(_^S&(b^_))+E[14]+2792965006&4294967295,T=S+(w<<17&4294967295|w>>>15),w=_+(b^T&(S^b))+E[15]+1236535329&4294967295,_=T+(w<<22&4294967295|w>>>10),w=b+(T^S&(_^T))+E[1]+4129170786&4294967295,b=_+(w<<5&4294967295|w>>>27),w=S+(_^T&(b^_))+E[6]+3225465664&4294967295,S=b+(w<<9&4294967295|w>>>23),w=T+(b^_&(S^b))+E[11]+643717713&4294967295,T=S+(w<<14&4294967295|w>>>18),w=_+(S^b&(T^S))+E[0]+3921069994&4294967295,_=T+(w<<20&4294967295|w>>>12),w=b+(T^S&(_^T))+E[5]+3593408605&4294967295,b=_+(w<<5&4294967295|w>>>27),w=S+(_^T&(b^_))+E[10]+38016083&4294967295,S=b+(w<<9&4294967295|w>>>23),w=T+(b^_&(S^b))+E[15]+3634488961&4294967295,T=S+(w<<14&4294967295|w>>>18),w=_+(S^b&(T^S))+E[4]+3889429448&4294967295,_=T+(w<<20&4294967295|w>>>12),w=b+(T^S&(_^T))+E[9]+568446438&4294967295,b=_+(w<<5&4294967295|w>>>27),w=S+(_^T&(b^_))+E[14]+3275163606&4294967295,S=b+(w<<9&4294967295|w>>>23),w=T+(b^_&(S^b))+E[3]+4107603335&4294967295,T=S+(w<<14&4294967295|w>>>18),w=_+(S^b&(T^S))+E[8]+1163531501&4294967295,_=T+(w<<20&4294967295|w>>>12),w=b+(T^S&(_^T))+E[13]+2850285829&4294967295,b=_+(w<<5&4294967295|w>>>27),w=S+(_^T&(b^_))+E[2]+4243563512&4294967295,S=b+(w<<9&4294967295|w>>>23),w=T+(b^_&(S^b))+E[7]+1735328473&4294967295,T=S+(w<<14&4294967295|w>>>18),w=_+(S^b&(T^S))+E[12]+2368359562&4294967295,_=T+(w<<20&4294967295|w>>>12),w=b+(_^T^S)+E[5]+4294588738&4294967295,b=_+(w<<4&4294967295|w>>>28),w=S+(b^_^T)+E[8]+2272392833&4294967295,S=b+(w<<11&4294967295|w>>>21),w=T+(S^b^_)+E[11]+1839030562&4294967295,T=S+(w<<16&4294967295|w>>>16),w=_+(T^S^b)+E[14]+4259657740&4294967295,_=T+(w<<23&4294967295|w>>>9),w=b+(_^T^S)+E[1]+2763975236&4294967295,b=_+(w<<4&4294967295|w>>>28),w=S+(b^_^T)+E[4]+1272893353&4294967295,S=b+(w<<11&4294967295|w>>>21),w=T+(S^b^_)+E[7]+4139469664&4294967295,T=S+(w<<16&4294967295|w>>>16),w=_+(T^S^b)+E[10]+3200236656&4294967295,_=T+(w<<23&4294967295|w>>>9),w=b+(_^T^S)+E[13]+681279174&4294967295,b=_+(w<<4&4294967295|w>>>28),w=S+(b^_^T)+E[0]+3936430074&4294967295,S=b+(w<<11&4294967295|w>>>21),w=T+(S^b^_)+E[3]+3572445317&4294967295,T=S+(w<<16&4294967295|w>>>16),w=_+(T^S^b)+E[6]+76029189&4294967295,_=T+(w<<23&4294967295|w>>>9),w=b+(_^T^S)+E[9]+3654602809&4294967295,b=_+(w<<4&4294967295|w>>>28),w=S+(b^_^T)+E[12]+3873151461&4294967295,S=b+(w<<11&4294967295|w>>>21),w=T+(S^b^_)+E[15]+530742520&4294967295,T=S+(w<<16&4294967295|w>>>16),w=_+(T^S^b)+E[2]+3299628645&4294967295,_=T+(w<<23&4294967295|w>>>9),w=b+(T^(_|~S))+E[0]+4096336452&4294967295,b=_+(w<<6&4294967295|w>>>26),w=S+(_^(b|~T))+E[7]+1126891415&4294967295,S=b+(w<<10&4294967295|w>>>22),w=T+(b^(S|~_))+E[14]+2878612391&4294967295,T=S+(w<<15&4294967295|w>>>17),w=_+(S^(T|~b))+E[5]+4237533241&4294967295,_=T+(w<<21&4294967295|w>>>11),w=b+(T^(_|~S))+E[12]+1700485571&4294967295,b=_+(w<<6&4294967295|w>>>26),w=S+(_^(b|~T))+E[3]+2399980690&4294967295,S=b+(w<<10&4294967295|w>>>22),w=T+(b^(S|~_))+E[10]+4293915773&4294967295,T=S+(w<<15&4294967295|w>>>17),w=_+(S^(T|~b))+E[1]+2240044497&4294967295,_=T+(w<<21&4294967295|w>>>11),w=b+(T^(_|~S))+E[8]+1873313359&4294967295,b=_+(w<<6&4294967295|w>>>26),w=S+(_^(b|~T))+E[15]+4264355552&4294967295,S=b+(w<<10&4294967295|w>>>22),w=T+(b^(S|~_))+E[6]+2734768916&4294967295,T=S+(w<<15&4294967295|w>>>17),w=_+(S^(T|~b))+E[13]+1309151649&4294967295,_=T+(w<<21&4294967295|w>>>11),w=b+(T^(_|~S))+E[4]+4149444226&4294967295,b=_+(w<<6&4294967295|w>>>26),w=S+(_^(b|~T))+E[11]+3174756917&4294967295,S=b+(w<<10&4294967295|w>>>22),w=T+(b^(S|~_))+E[2]+718787259&4294967295,T=S+(w<<15&4294967295|w>>>17),w=_+(S^(T|~b))+E[9]+3951481745&4294967295,I.g[0]=I.g[0]+b&4294967295,I.g[1]=I.g[1]+(T+(w<<21&4294967295|w>>>11))&4294967295,I.g[2]=I.g[2]+T&4294967295,I.g[3]=I.g[3]+S&4294967295}r.prototype.v=function(I,b){b===void 0&&(b=I.length);const _=b-this.blockSize,E=this.C;let T=this.h,S=0;for(;S<b;){if(T==0)for(;S<=_;)o(this,I,S),S+=this.blockSize;if(typeof I=="string"){for(;S<b;)if(E[T++]=I.charCodeAt(S++),T==this.blockSize){o(this,E),T=0;break}}else for(;S<b;)if(E[T++]=I[S++],T==this.blockSize){o(this,E),T=0;break}}this.h=T,this.o+=b},r.prototype.A=function(){var I=Array((this.h<56?this.blockSize:this.blockSize*2)-this.h);I[0]=128;for(var b=1;b<I.length-8;++b)I[b]=0;b=this.o*8;for(var _=I.length-8;_<I.length;++_)I[_]=b&255,b/=256;for(this.v(I),I=Array(16),b=0,_=0;_<4;++_)for(let E=0;E<32;E+=8)I[b++]=this.g[_]>>>E&255;return I};function i(I,b){var _=c;return Object.prototype.hasOwnProperty.call(_,I)?_[I]:_[I]=b(I)}function s(I,b){this.h=b;const _=[];let E=!0;for(let T=I.length-1;T>=0;T--){const S=I[T]|0;E&&S==b||(_[T]=S,E=!1)}this.g=_}var c={};function d(I){return-128<=I&&I<128?i(I,function(b){return new s([b|0],b<0?-1:0)}):new s([I|0],I<0?-1:0)}function u(I){if(isNaN(I)||!isFinite(I))return g;if(I<0)return M(u(-I));const b=[];let _=1;for(let E=0;I>=_;E++)b[E]=I/_|0,_*=4294967296;return new s(b,0)}function f(I,b){if(I.length==0)throw Error("number format error: empty string");if(b=b||10,b<2||36<b)throw Error("radix out of range: "+b);if(I.charAt(0)=="-")return M(f(I.substring(1),b));if(I.indexOf("-")>=0)throw Error('number format error: interior "-" character');const _=u(Math.pow(b,8));let E=g;for(let S=0;S<I.length;S+=8){var T=Math.min(8,I.length-S);const w=parseInt(I.substring(S,S+T),b);T<8?(T=u(Math.pow(b,T)),E=E.j(T).add(u(w))):(E=E.j(_),E=E.add(u(w)))}return E}var g=d(0),m=d(1),v=d(16777216);n=s.prototype,n.m=function(){if(P(this))return-M(this).m();let I=0,b=1;for(let _=0;_<this.g.length;_++){const E=this.i(_);I+=(E>=0?E:4294967296+E)*b,b*=4294967296}return I},n.toString=function(I){if(I=I||10,I<2||36<I)throw Error("radix out of range: "+I);if(L(this))return"0";if(P(this))return"-"+M(this).toString(I);const b=u(Math.pow(I,6));var _=this;let E="";for(;;){const T=j(_,b).g;_=G(_,T.j(b));let S=((_.g.length>0?_.g[0]:_.h)>>>0).toString(I);if(_=T,L(_))return S+E;for(;S.length<6;)S="0"+S;E=S+E}},n.i=function(I){return I<0?0:I<this.g.length?this.g[I]:this.h};function L(I){if(I.h!=0)return!1;for(let b=0;b<I.g.length;b++)if(I.g[b]!=0)return!1;return!0}function P(I){return I.h==-1}n.l=function(I){return I=G(this,I),P(I)?-1:L(I)?0:1};function M(I){const b=I.g.length,_=[];for(let E=0;E<b;E++)_[E]=~I.g[E];return new s(_,~I.h).add(m)}n.abs=function(){return P(this)?M(this):this},n.add=function(I){const b=Math.max(this.g.length,I.g.length),_=[];let E=0;for(let T=0;T<=b;T++){let S=E+(this.i(T)&65535)+(I.i(T)&65535),w=(S>>>16)+(this.i(T)>>>16)+(I.i(T)>>>16);E=w>>>16,S&=65535,w&=65535,_[T]=w<<16|S}return new s(_,_[_.length-1]&-2147483648?-1:0)};function G(I,b){return I.add(M(b))}n.j=function(I){if(L(this)||L(I))return g;if(P(this))return P(I)?M(this).j(M(I)):M(M(this).j(I));if(P(I))return M(this.j(M(I)));if(this.l(v)<0&&I.l(v)<0)return u(this.m()*I.m());const b=this.g.length+I.g.length,_=[];for(var E=0;E<2*b;E++)_[E]=0;for(E=0;E<this.g.length;E++)for(let T=0;T<I.g.length;T++){const S=this.i(E)>>>16,w=this.i(E)&65535,Z=I.i(T)>>>16,de=I.i(T)&65535;_[2*E+2*T]+=w*de,$(_,2*E+2*T),_[2*E+2*T+1]+=S*de,$(_,2*E+2*T+1),_[2*E+2*T+1]+=w*Z,$(_,2*E+2*T+1),_[2*E+2*T+2]+=S*Z,$(_,2*E+2*T+2)}for(I=0;I<b;I++)_[I]=_[2*I+1]<<16|_[2*I];for(I=b;I<2*b;I++)_[I]=0;return new s(_,0)};function $(I,b){for(;(I[b]&65535)!=I[b];)I[b+1]+=I[b]>>>16,I[b]&=65535,b++}function D(I,b){this.g=I,this.h=b}function j(I,b){if(L(b))throw Error("division by zero");if(L(I))return new D(g,g);if(P(I))return b=j(M(I),b),new D(M(b.g),M(b.h));if(P(b))return b=j(I,M(b)),new D(M(b.g),b.h);if(I.g.length>30){if(P(I)||P(b))throw Error("slowDivide_ only works with positive integers.");for(var _=m,E=b;E.l(I)<=0;)_=V(_),E=V(E);var T=B(_,1),S=B(E,1);for(E=B(E,2),_=B(_,2);!L(E);){var w=S.add(E);w.l(I)<=0&&(T=T.add(_),S=w),E=B(E,1),_=B(_,1)}return b=G(I,T.j(b)),new D(T,b)}for(T=g;I.l(b)>=0;){for(_=Math.max(1,Math.floor(I.m()/b.m())),E=Math.ceil(Math.log(_)/Math.LN2),E=E<=48?1:Math.pow(2,E-48),S=u(_),w=S.j(b);P(w)||w.l(I)>0;)_-=E,S=u(_),w=S.j(b);L(S)&&(S=m),T=T.add(S),I=G(I,w)}return new D(T,I)}n.B=function(I){return j(this,I).h},n.and=function(I){const b=Math.max(this.g.length,I.g.length),_=[];for(let E=0;E<b;E++)_[E]=this.i(E)&I.i(E);return new s(_,this.h&I.h)},n.or=function(I){const b=Math.max(this.g.length,I.g.length),_=[];for(let E=0;E<b;E++)_[E]=this.i(E)|I.i(E);return new s(_,this.h|I.h)},n.xor=function(I){const b=Math.max(this.g.length,I.g.length),_=[];for(let E=0;E<b;E++)_[E]=this.i(E)^I.i(E);return new s(_,this.h^I.h)};function V(I){const b=I.g.length+1,_=[];for(let E=0;E<b;E++)_[E]=I.i(E)<<1|I.i(E-1)>>>31;return new s(_,I.h)}function B(I,b){const _=b>>5;b%=32;const E=I.g.length-_,T=[];for(let S=0;S<E;S++)T[S]=b>0?I.i(S+_)>>>b|I.i(S+_+1)<<32-b:I.i(S+_);return new s(T,I.h)}r.prototype.digest=r.prototype.A,r.prototype.reset=r.prototype.u,r.prototype.update=r.prototype.v,ng=r,s.prototype.add=s.prototype.add,s.prototype.multiply=s.prototype.j,s.prototype.modulo=s.prototype.B,s.prototype.compare=s.prototype.l,s.prototype.toNumber=s.prototype.m,s.prototype.toString=s.prototype.toString,s.prototype.getBits=s.prototype.i,s.fromNumber=u,s.fromString=f,Zn=s}).apply(typeof Lh<"u"?Lh:typeof self<"u"?self:typeof window<"u"?window:{});var Bs=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/var rg,Ti,og,la,fc,ig,sg,ag;(function(){var n,e=Object.defineProperty;function t(a){a=[typeof globalThis=="object"&&globalThis,a,typeof window=="object"&&window,typeof self=="object"&&self,typeof Bs=="object"&&Bs];for(var h=0;h<a.length;++h){var p=a[h];if(p&&p.Math==Math)return p}throw Error("Cannot find global object")}var r=t(this);function o(a,h){if(h)e:{var p=r;a=a.split(".");for(var y=0;y<a.length-1;y++){var k=a[y];if(!(k in p))break e;p=p[k]}a=a[a.length-1],y=p[a],h=h(y),h!=y&&h!=null&&e(p,a,{configurable:!0,writable:!0,value:h})}}o("Symbol.dispose",function(a){return a||Symbol("Symbol.dispose")}),o("Array.prototype.values",function(a){return a||function(){return this[Symbol.iterator]()}}),o("Object.entries",function(a){return a||function(h){var p=[],y;for(y in h)Object.prototype.hasOwnProperty.call(h,y)&&p.push([y,h[y]]);return p}});/** @license

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/var i=i||{},s=this||self;function c(a){var h=typeof a;return h=="object"&&a!=null||h=="function"}function d(a,h,p){return a.call.apply(a.bind,arguments)}function u(a,h,p){return u=d,u.apply(null,arguments)}function f(a,h){var p=Array.prototype.slice.call(arguments,1);return function(){var y=p.slice();return y.push.apply(y,arguments),a.apply(this,y)}}function g(a,h){function p(){}p.prototype=h.prototype,a.Z=h.prototype,a.prototype=new p,a.prototype.constructor=a,a.Ob=function(y,k,N){for(var W=Array(arguments.length-2),ie=2;ie<arguments.length;ie++)W[ie-2]=arguments[ie];return h.prototype[k].apply(y,W)}}var m=typeof AsyncContext<"u"&&typeof AsyncContext.Snapshot=="function"?a=>a&&AsyncContext.Snapshot.wrap(a):a=>a;function v(a){const h=a.length;if(h>0){const p=Array(h);for(let y=0;y<h;y++)p[y]=a[y];return p}return[]}function L(a,h){for(let y=1;y<arguments.length;y++){const k=arguments[y];var p=typeof k;if(p=p!="object"?p:k?Array.isArray(k)?"array":p:"null",p=="array"||p=="object"&&typeof k.length=="number"){p=a.length||0;const N=k.length||0;a.length=p+N;for(let W=0;W<N;W++)a[p+W]=k[W]}else a.push(k)}}class P{constructor(h,p){this.i=h,this.j=p,this.h=0,this.g=null}get(){let h;return this.h>0?(this.h--,h=this.g,this.g=h.next,h.next=null):h=this.i(),h}}function M(a){s.setTimeout(()=>{throw a},0)}function G(){var a=I;let h=null;return a.g&&(h=a.g,a.g=a.g.next,a.g||(a.h=null),h.next=null),h}class ${constructor(){this.h=this.g=null}add(h,p){const y=D.get();y.set(h,p),this.h?this.h.next=y:this.g=y,this.h=y}}var D=new P(()=>new j,a=>a.reset());class j{constructor(){this.next=this.g=this.h=null}set(h,p){this.h=h,this.g=p,this.next=null}reset(){this.next=this.g=this.h=null}}let V,B=!1,I=new $,b=()=>{const a=Promise.resolve(void 0);V=()=>{a.then(_)}};function _(){for(var a;a=G();){try{a.h.call(a.g)}catch(p){M(p)}var h=D;h.j(a),h.h<100&&(h.h++,a.next=h.g,h.g=a)}B=!1}function E(){this.u=this.u,this.C=this.C}E.prototype.u=!1,E.prototype.dispose=function(){this.u||(this.u=!0,this.N())},E.prototype[Symbol.dispose]=function(){this.dispose()},E.prototype.N=function(){if(this.C)for(;this.C.length;)this.C.shift()()};function T(a,h){this.type=a,this.g=this.target=h,this.defaultPrevented=!1}T.prototype.h=function(){this.defaultPrevented=!0};var S=function(){if(!s.addEventListener||!Object.defineProperty)return!1;var a=!1,h=Object.defineProperty({},"passive",{get:function(){a=!0}});try{const p=()=>{};s.addEventListener("test",p,h),s.removeEventListener("test",p,h)}catch{}return a}();function w(a){return/^[\s\xa0]*$/.test(a)}function Z(a,h){T.call(this,a?a.type:""),this.relatedTarget=this.g=this.target=null,this.button=this.screenY=this.screenX=this.clientY=this.clientX=0,this.key="",this.metaKey=this.shiftKey=this.altKey=this.ctrlKey=!1,this.state=null,this.pointerId=0,this.pointerType="",this.i=null,a&&this.init(a,h)}g(Z,T),Z.prototype.init=function(a,h){const p=this.type=a.type,y=a.changedTouches&&a.changedTouches.length?a.changedTouches[0]:null;this.target=a.target||a.srcElement,this.g=h,h=a.relatedTarget,h||(p=="mouseover"?h=a.fromElement:p=="mouseout"&&(h=a.toElement)),this.relatedTarget=h,y?(this.clientX=y.clientX!==void 0?y.clientX:y.pageX,this.clientY=y.clientY!==void 0?y.clientY:y.pageY,this.screenX=y.screenX||0,this.screenY=y.screenY||0):(this.clientX=a.clientX!==void 0?a.clientX:a.pageX,this.clientY=a.clientY!==void 0?a.clientY:a.pageY,this.screenX=a.screenX||0,this.screenY=a.screenY||0),this.button=a.button,this.key=a.key||"",this.ctrlKey=a.ctrlKey,this.altKey=a.altKey,this.shiftKey=a.shiftKey,this.metaKey=a.metaKey,this.pointerId=a.pointerId||0,this.pointerType=a.pointerType,this.state=a.state,this.i=a,a.defaultPrevented&&Z.Z.h.call(this)},Z.prototype.h=function(){Z.Z.h.call(this);const a=this.i;a.preventDefault?a.preventDefault():a.returnValue=!1};var de="closure_listenable_"+(Math.random()*1e6|0),fe=0;function me(a,h,p,y,k){this.listener=a,this.proxy=null,this.src=h,this.type=p,this.capture=!!y,this.ha=k,this.key=++fe,this.da=this.fa=!1}function xe(a){a.da=!0,a.listener=null,a.proxy=null,a.src=null,a.ha=null}function Te(a,h,p){for(const y in a)h.call(p,a[y],y,a)}function Ie(a,h){for(const p in a)h.call(void 0,a[p],p,a)}function ae(a){const h={};for(const p in a)h[p]=a[p];return h}const ye="constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");function ve(a,h){let p,y;for(let k=1;k<arguments.length;k++){y=arguments[k];for(p in y)a[p]=y[p];for(let N=0;N<ye.length;N++)p=ye[N],Object.prototype.hasOwnProperty.call(y,p)&&(a[p]=y[p])}}function Ae(a){this.src=a,this.g={},this.h=0}Ae.prototype.add=function(a,h,p,y,k){const N=a.toString();a=this.g[N],a||(a=this.g[N]=[],this.h++);const W=Go(a,h,y,k);return W>-1?(h=a[W],p||(h.fa=!1)):(h=new me(h,this.src,N,!!y,k),h.fa=p,a.push(h)),h};function fn(a,h){const p=h.type;if(p in a.g){var y=a.g[p],k=Array.prototype.indexOf.call(y,h,void 0),N;(N=k>=0)&&Array.prototype.splice.call(y,k,1),N&&(xe(h),a.g[p].length==0&&(delete a.g[p],a.h--))}}function Go(a,h,p,y){for(let k=0;k<a.length;++k){const N=a[k];if(!N.da&&N.listener==h&&N.capture==!!p&&N.ha==y)return k}return-1}var Xr="closure_lm_"+(Math.random()*1e6|0),It={};function Yo(a,h,p,y,k){if(Array.isArray(h)){for(let N=0;N<h.length;N++)Yo(a,h[N],p,y,k);return null}return p=Qo(p),a&&a[de]?a.J(h,p,c(y)?!!y.capture:!1,k):Is(a,h,p,!1,y,k)}function Is(a,h,p,y,k,N){if(!h)throw Error("Invalid event type");const W=c(k)?!!k.capture:!!k;let ie=Jr(a);if(ie||(a[Xr]=ie=new Ae(a)),p=ie.add(h,p,y,W,N),p.proxy)return p;if(y=Ss(),p.proxy=y,y.src=a,y.listener=p,a.addEventListener)S||(k=W),k===void 0&&(k=!1),a.addEventListener(h.toString(),y,k);else if(a.attachEvent)a.attachEvent(Xo(h.toString()),y);else if(a.addListener&&a.removeListener)a.addListener(y);else throw Error("addEventListener and attachEvent are unavailable.");return p}function Ss(){function a(p){return h.call(a.src,a.listener,p)}const h=xs;return a}function Ko(a,h,p,y,k){if(Array.isArray(h))for(var N=0;N<h.length;N++)Ko(a,h[N],p,y,k);else y=c(y)?!!y.capture:!!y,p=Qo(p),a&&a[de]?(a=a.i,N=String(h).toString(),N in a.g&&(h=a.g[N],p=Go(h,p,y,k),p>-1&&(xe(h[p]),Array.prototype.splice.call(h,p,1),h.length==0&&(delete a.g[N],a.h--)))):a&&(a=Jr(a))&&(h=a.g[h.toString()],a=-1,h&&(a=Go(h,p,y,k)),(p=a>-1?h[a]:null)&&Qr(p))}function Qr(a){if(typeof a!="number"&&a&&!a.da){var h=a.src;if(h&&h[de])fn(h.i,a);else{var p=a.type,y=a.proxy;h.removeEventListener?h.removeEventListener(p,y,a.capture):h.detachEvent?h.detachEvent(Xo(p),y):h.addListener&&h.removeListener&&h.removeListener(y),(p=Jr(h))?(fn(p,a),p.h==0&&(p.src=null,h[Xr]=null)):xe(a)}}}function Xo(a){return a in It?It[a]:It[a]="on"+a}function xs(a,h){if(a.da)a=!0;else{h=new Z(h,this);const p=a.listener,y=a.ha||a.src;a.fa&&Qr(a),a=p.call(y,h)}return a}function Jr(a){return a=a[Xr],a instanceof Ae?a:null}var Zr="__closure_events_fn_"+(Math.random()*1e9>>>0);function Qo(a){return typeof a=="function"?a:(a[Zr]||(a[Zr]=function(h){return a.handleEvent(h)}),a[Zr])}function Ge(){E.call(this),this.i=new Ae(this),this.M=this,this.G=null}g(Ge,E),Ge.prototype[de]=!0,Ge.prototype.removeEventListener=function(a,h,p,y){Ko(this,a,h,p,y)};function Je(a,h){var p,y=a.G;if(y)for(p=[];y;y=y.G)p.push(y);if(a=a.M,y=h.type||h,typeof h=="string")h=new T(h,a);else if(h instanceof T)h.target=h.target||a;else{var k=h;h=new T(y,a),ve(h,k)}k=!0;let N,W;if(p)for(W=p.length-1;W>=0;W--)N=h.g=p[W],k=gr(N,y,!0,h)&&k;if(N=h.g=a,k=gr(N,y,!0,h)&&k,k=gr(N,y,!1,h)&&k,p)for(W=0;W<p.length;W++)N=h.g=p[W],k=gr(N,y,!1,h)&&k}Ge.prototype.N=function(){if(Ge.Z.N.call(this),this.i){var a=this.i;for(const h in a.g){const p=a.g[h];for(let y=0;y<p.length;y++)xe(p[y]);delete a.g[h],a.h--}}this.G=null},Ge.prototype.J=function(a,h,p,y){return this.i.add(String(a),h,!1,p,y)},Ge.prototype.K=function(a,h,p,y){return this.i.add(String(a),h,!0,p,y)};function gr(a,h,p,y){if(h=a.i.g[String(h)],!h)return!0;h=h.concat();let k=!0;for(let N=0;N<h.length;++N){const W=h[N];if(W&&!W.da&&W.capture==p){const ie=W.listener,Ye=W.ha||W.src;W.fa&&fn(a.i,W),k=ie.call(Ye,y)!==!1&&k}}return k&&!y.defaultPrevented}function R(a,h){if(typeof a!="function")if(a&&typeof a.handleEvent=="function")a=u(a.handleEvent,a);else throw Error("Invalid listener argument");return Number(h)>2147483647?-1:s.setTimeout(a,h||0)}function z(a){a.g=R(()=>{a.g=null,a.i&&(a.i=!1,z(a))},a.l);const h=a.h;a.h=null,a.m.apply(null,h)}class X extends E{constructor(h,p){super(),this.m=h,this.l=p,this.h=null,this.i=!1,this.g=null}j(h){this.h=arguments,this.g?this.i=!0:z(this)}N(){super.N(),this.g&&(s.clearTimeout(this.g),this.g=null,this.i=!1,this.h=null)}}function oe(a){E.call(this),this.h=a,this.g={}}g(oe,E);var gt=[];function Ze(a){Te(a.g,function(h,p){this.g.hasOwnProperty(p)&&Qr(h)},a),a.g={}}oe.prototype.N=function(){oe.Z.N.call(this),Ze(this)},oe.prototype.handleEvent=function(){throw Error("EventHandler.handleEvent not implemented")};var Ue=s.JSON.stringify,As=s.JSON.parse,ks=class{stringify(a){return s.JSON.stringify(a,void 0)}parse(a){return s.JSON.parse(a,void 0)}};function md(){}function yd(){}var Jo={OPEN:"a",hb:"b",ERROR:"c",tb:"d"};function wl(){T.call(this,"d")}g(wl,T);function Tl(){T.call(this,"c")}g(Tl,T);var mr={},vd=null;function Ps(){return vd=vd||new Ge}mr.Ia="serverreachability";function _d(a){T.call(this,mr.Ia,a)}g(_d,T);function Zo(a){const h=Ps();Je(h,new _d(h))}mr.STAT_EVENT="statevent";function bd(a,h){T.call(this,mr.STAT_EVENT,a),this.stat=h}g(bd,T);function ft(a){const h=Ps();Je(h,new bd(h,a))}mr.Ja="timingevent";function wd(a,h){T.call(this,mr.Ja,a),this.size=h}g(wd,T);function ei(a,h){if(typeof a!="function")throw Error("Fn must not be null and must be a function");return s.setTimeout(function(){a()},h)}function ti(){this.g=!0}ti.prototype.ua=function(){this.g=!1};function Oy(a,h,p,y,k,N){a.info(function(){if(a.g)if(N){var W="",ie=N.split("&");for(let Ee=0;Ee<ie.length;Ee++){var Ye=ie[Ee].split("=");if(Ye.length>1){const et=Ye[0];Ye=Ye[1];const Gt=et.split("_");W=Gt.length>=2&&Gt[1]=="type"?W+(et+"="+Ye+"&"):W+(et+"=redacted&")}}}else W=null;else W=N;return"XMLHTTP REQ ("+y+") [attempt "+k+"]: "+h+`
`+p+`
`+W})}function Ny(a,h,p,y,k,N,W){a.info(function(){return"XMLHTTP RESP ("+y+") [ attempt "+k+"]: "+h+`
`+p+`
`+N+" "+W})}function eo(a,h,p,y){a.info(function(){return"XMLHTTP TEXT ("+h+"): "+My(a,p)+(y?" "+y:"")})}function Ly(a,h){a.info(function(){return"TIMEOUT: "+h})}ti.prototype.info=function(){};function My(a,h){if(!a.g)return h;if(!h)return null;try{const N=JSON.parse(h);if(N){for(a=0;a<N.length;a++)if(Array.isArray(N[a])){var p=N[a];if(!(p.length<2)){var y=p[1];if(Array.isArray(y)&&!(y.length<1)){var k=y[0];if(k!="noop"&&k!="stop"&&k!="close")for(let W=1;W<y.length;W++)y[W]=""}}}}return Ue(N)}catch{return h}}var Cs={NO_ERROR:0,cb:1,qb:2,pb:3,kb:4,ob:5,rb:6,Ga:7,TIMEOUT:8,ub:9},Td={ib:"complete",Fb:"success",ERROR:"error",Ga:"abort",xb:"ready",yb:"readystatechange",TIMEOUT:"timeout",sb:"incrementaldata",wb:"progress",lb:"downloadprogress",Nb:"uploadprogress"},Ed;function El(){}g(El,md),El.prototype.g=function(){return new XMLHttpRequest},Ed=new El;function ni(a){return encodeURIComponent(String(a))}function Dy(a){var h=1;a=a.split(":");const p=[];for(;h>0&&a.length;)p.push(a.shift()),h--;return a.length&&p.push(a.join(":")),p}function Mn(a,h,p,y){this.j=a,this.i=h,this.l=p,this.S=y||1,this.V=new oe(this),this.H=45e3,this.J=null,this.o=!1,this.u=this.B=this.A=this.M=this.F=this.T=this.D=null,this.G=[],this.g=null,this.C=0,this.m=this.v=null,this.X=-1,this.K=!1,this.P=0,this.O=null,this.W=this.L=this.U=this.R=!1,this.h=new Id}function Id(){this.i=null,this.g="",this.h=!1}var Sd={},Il={};function Sl(a,h,p){a.M=1,a.A=Os(Ht(h)),a.u=p,a.R=!0,xd(a,null)}function xd(a,h){a.F=Date.now(),Rs(a),a.B=Ht(a.A);var p=a.B,y=a.S;Array.isArray(y)||(y=[String(y)]),Ud(p.i,"t",y),a.C=0,p=a.j.L,a.h=new Id,a.g=rh(a.j,p?h:null,!a.u),a.P>0&&(a.O=new X(u(a.Y,a,a.g),a.P)),h=a.V,p=a.g,y=a.ba;var k="readystatechange";Array.isArray(k)||(k&&(gt[0]=k.toString()),k=gt);for(let N=0;N<k.length;N++){const W=Yo(p,k[N],y||h.handleEvent,!1,h.h||h);if(!W)break;h.g[W.key]=W}h=a.J?ae(a.J):{},a.u?(a.v||(a.v="POST"),h["Content-Type"]="application/x-www-form-urlencoded",a.g.ea(a.B,a.v,a.u,h)):(a.v="GET",a.g.ea(a.B,a.v,null,h)),Zo(),Oy(a.i,a.v,a.B,a.l,a.S,a.u)}Mn.prototype.ba=function(a){a=a.target;const h=this.O;h&&Fn(a)==3?h.j():this.Y(a)},Mn.prototype.Y=function(a){try{if(a==this.g)e:{const ie=Fn(this.g),Ye=this.g.ya(),Ee=this.g.ca();if(!(ie<3)&&(ie!=3||this.g&&(this.h.h||this.g.la()||Hd(this.g)))){this.K||ie!=4||Ye==7||(Ye==8||Ee<=0?Zo(3):Zo(2)),xl(this);var h=this.g.ca();this.X=h;var p=Vy(this);if(this.o=h==200,Ny(this.i,this.v,this.B,this.l,this.S,ie,h),this.o){if(this.U&&!this.L){t:{if(this.g){var y,k=this.g;if((y=k.g?k.g.getResponseHeader("X-HTTP-Initial-Response"):null)&&!w(y)){var N=y;break t}}N=null}if(a=N)eo(this.i,this.l,a,"Initial handshake response via X-HTTP-Initial-Response"),this.L=!0,Al(this,a);else{this.o=!1,this.m=3,ft(12),yr(this),ri(this);break e}}if(this.R){a=!0;let et;for(;!this.K&&this.C<p.length;)if(et=Fy(this,p),et==Il){ie==4&&(this.m=4,ft(14),a=!1),eo(this.i,this.l,null,"[Incomplete Response]");break}else if(et==Sd){this.m=4,ft(15),eo(this.i,this.l,p,"[Invalid Chunk]"),a=!1;break}else eo(this.i,this.l,et,null),Al(this,et);if(Ad(this)&&this.C!=0&&(this.h.g=this.h.g.slice(this.C),this.C=0),ie!=4||p.length!=0||this.h.h||(this.m=1,ft(16),a=!1),this.o=this.o&&a,!a)eo(this.i,this.l,p,"[Invalid Chunked Response]"),yr(this),ri(this);else if(p.length>0&&!this.W){this.W=!0;var W=this.j;W.g==this&&W.aa&&!W.P&&(W.j.info("Great, no buffering proxy detected. Bytes received: "+p.length),Ml(W),W.P=!0,ft(11))}}else eo(this.i,this.l,p,null),Al(this,p);ie==4&&yr(this),this.o&&!this.K&&(ie==4?Zd(this.j,this):(this.o=!1,Rs(this)))}else Jy(this.g),h==400&&p.indexOf("Unknown SID")>0?(this.m=3,ft(12)):(this.m=0,ft(13)),yr(this),ri(this)}}}catch{}finally{}};function Vy(a){if(!Ad(a))return a.g.la();const h=Hd(a.g);if(h==="")return"";let p="";const y=h.length,k=Fn(a.g)==4;if(!a.h.i){if(typeof TextDecoder>"u")return yr(a),ri(a),"";a.h.i=new s.TextDecoder}for(let N=0;N<y;N++)a.h.h=!0,p+=a.h.i.decode(h[N],{stream:!(k&&N==y-1)});return h.length=0,a.h.g+=p,a.C=0,a.h.g}function Ad(a){return a.g?a.v=="GET"&&a.M!=2&&a.j.Aa:!1}function Fy(a,h){var p=a.C,y=h.indexOf(`
`,p);return y==-1?Il:(p=Number(h.substring(p,y)),isNaN(p)?Sd:(y+=1,y+p>h.length?Il:(h=h.slice(y,y+p),a.C=y+p,h)))}Mn.prototype.cancel=function(){this.K=!0,yr(this)};function Rs(a){a.T=Date.now()+a.H,kd(a,a.H)}function kd(a,h){if(a.D!=null)throw Error("WatchDog timer not null");a.D=ei(u(a.aa,a),h)}function xl(a){a.D&&(s.clearTimeout(a.D),a.D=null)}Mn.prototype.aa=function(){this.D=null;const a=Date.now();a-this.T>=0?(Ly(this.i,this.B),this.M!=2&&(Zo(),ft(17)),yr(this),this.m=2,ri(this)):kd(this,this.T-a)};function ri(a){a.j.I==0||a.K||Zd(a.j,a)}function yr(a){xl(a);var h=a.O;h&&typeof h.dispose=="function"&&h.dispose(),a.O=null,Ze(a.V),a.g&&(h=a.g,a.g=null,h.abort(),h.dispose())}function Al(a,h){try{var p=a.j;if(p.I!=0&&(p.g==a||kl(p.h,a))){if(!a.L&&kl(p.h,a)&&p.I==3){try{var y=p.Ba.g.parse(h)}catch{y=null}if(Array.isArray(y)&&y.length==3){var k=y;if(k[0]==0){e:if(!p.v){if(p.g)if(p.g.F+3e3<a.F)Vs(p),Ms(p);else break e;Ll(p),ft(18)}}else p.xa=k[1],0<p.xa-p.K&&k[2]<37500&&p.F&&p.A==0&&!p.C&&(p.C=ei(u(p.Va,p),6e3));Rd(p.h)<=1&&p.ta&&(p.ta=void 0)}else _r(p,11)}else if((a.L||p.g==a)&&Vs(p),!w(h))for(k=p.Ba.g.parse(h),h=0;h<k.length;h++){let Ee=k[h];const et=Ee[0];if(!(et<=p.K))if(p.K=et,Ee=Ee[1],p.I==2)if(Ee[0]=="c"){p.M=Ee[1],p.ba=Ee[2];const Gt=Ee[3];Gt!=null&&(p.ka=Gt,p.j.info("VER="+p.ka));const br=Ee[4];br!=null&&(p.za=br,p.j.info("SVER="+p.za));const Un=Ee[5];Un!=null&&typeof Un=="number"&&Un>0&&(y=1.5*Un,p.O=y,p.j.info("backChannelRequestTimeoutMs_="+y)),y=p;const qn=a.g;if(qn){const Us=qn.g?qn.g.getResponseHeader("X-Client-Wire-Protocol"):null;if(Us){var N=y.h;N.g||Us.indexOf("spdy")==-1&&Us.indexOf("quic")==-1&&Us.indexOf("h2")==-1||(N.j=N.l,N.g=new Set,N.h&&(Pl(N,N.h),N.h=null))}if(y.G){const Dl=qn.g?qn.g.getResponseHeader("X-HTTP-Session-Id"):null;Dl&&(y.wa=Dl,ke(y.J,y.G,Dl))}}p.I=3,p.l&&p.l.ra(),p.aa&&(p.T=Date.now()-a.F,p.j.info("Handshake RTT: "+p.T+"ms")),y=p;var W=a;if(y.na=nh(y,y.L?y.ba:null,y.W),W.L){Od(y.h,W);var ie=W,Ye=y.O;Ye&&(ie.H=Ye),ie.D&&(xl(ie),Rs(ie)),y.g=W}else Qd(y);p.i.length>0&&Ds(p)}else Ee[0]!="stop"&&Ee[0]!="close"||_r(p,7);else p.I==3&&(Ee[0]=="stop"||Ee[0]=="close"?Ee[0]=="stop"?_r(p,7):Nl(p):Ee[0]!="noop"&&p.l&&p.l.qa(Ee),p.A=0)}}Zo(4)}catch{}}var Uy=class{constructor(a,h){this.g=a,this.map=h}};function Pd(a){this.l=a||10,s.PerformanceNavigationTiming?(a=s.performance.getEntriesByType("navigation"),a=a.length>0&&(a[0].nextHopProtocol=="hq"||a[0].nextHopProtocol=="h2")):a=!!(s.chrome&&s.chrome.loadTimes&&s.chrome.loadTimes()&&s.chrome.loadTimes().wasFetchedViaSpdy),this.j=a?this.l:1,this.g=null,this.j>1&&(this.g=new Set),this.h=null,this.i=[]}function Cd(a){return a.h?!0:a.g?a.g.size>=a.j:!1}function Rd(a){return a.h?1:a.g?a.g.size:0}function kl(a,h){return a.h?a.h==h:a.g?a.g.has(h):!1}function Pl(a,h){a.g?a.g.add(h):a.h=h}function Od(a,h){a.h&&a.h==h?a.h=null:a.g&&a.g.has(h)&&a.g.delete(h)}Pd.prototype.cancel=function(){if(this.i=Nd(this),this.h)this.h.cancel(),this.h=null;else if(this.g&&this.g.size!==0){for(const a of this.g.values())a.cancel();this.g.clear()}};function Nd(a){if(a.h!=null)return a.i.concat(a.h.G);if(a.g!=null&&a.g.size!==0){let h=a.i;for(const p of a.g.values())h=h.concat(p.G);return h}return v(a.i)}var Ld=RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");function qy(a,h){if(a){a=a.split("&");for(let p=0;p<a.length;p++){const y=a[p].indexOf("=");let k,N=null;y>=0?(k=a[p].substring(0,y),N=a[p].substring(y+1)):k=a[p],h(k,N?decodeURIComponent(N.replace(/\+/g," ")):"")}}}function Dn(a){this.g=this.o=this.j="",this.u=null,this.m=this.h="",this.l=!1;let h;a instanceof Dn?(this.l=a.l,oi(this,a.j),this.o=a.o,this.g=a.g,ii(this,a.u),this.h=a.h,Cl(this,qd(a.i)),this.m=a.m):a&&(h=String(a).match(Ld))?(this.l=!1,oi(this,h[1]||"",!0),this.o=si(h[2]||""),this.g=si(h[3]||"",!0),ii(this,h[4]),this.h=si(h[5]||"",!0),Cl(this,h[6]||"",!0),this.m=si(h[7]||"")):(this.l=!1,this.i=new li(null,this.l))}Dn.prototype.toString=function(){const a=[];var h=this.j;h&&a.push(ai(h,Md,!0),":");var p=this.g;return(p||h=="file")&&(a.push("//"),(h=this.o)&&a.push(ai(h,Md,!0),"@"),a.push(ni(p).replace(/%25([0-9a-fA-F]{2})/g,"%$1")),p=this.u,p!=null&&a.push(":",String(p))),(p=this.h)&&(this.g&&p.charAt(0)!="/"&&a.push("/"),a.push(ai(p,p.charAt(0)=="/"?jy:$y,!0))),(p=this.i.toString())&&a.push("?",p),(p=this.m)&&a.push("#",ai(p,Wy)),a.join("")},Dn.prototype.resolve=function(a){const h=Ht(this);let p=!!a.j;p?oi(h,a.j):p=!!a.o,p?h.o=a.o:p=!!a.g,p?h.g=a.g:p=a.u!=null;var y=a.h;if(p)ii(h,a.u);else if(p=!!a.h){if(y.charAt(0)!="/")if(this.g&&!this.h)y="/"+y;else{var k=h.h.lastIndexOf("/");k!=-1&&(y=h.h.slice(0,k+1)+y)}if(k=y,k==".."||k==".")y="";else if(k.indexOf("./")!=-1||k.indexOf("/.")!=-1){y=k.lastIndexOf("/",0)==0,k=k.split("/");const N=[];for(let W=0;W<k.length;){const ie=k[W++];ie=="."?y&&W==k.length&&N.push(""):ie==".."?((N.length>1||N.length==1&&N[0]!="")&&N.pop(),y&&W==k.length&&N.push("")):(N.push(ie),y=!0)}y=N.join("/")}else y=k}return p?h.h=y:p=a.i.toString()!=="",p?Cl(h,qd(a.i)):p=!!a.m,p&&(h.m=a.m),h};function Ht(a){return new Dn(a)}function oi(a,h,p){a.j=p?si(h,!0):h,a.j&&(a.j=a.j.replace(/:$/,""))}function ii(a,h){if(h){if(h=Number(h),isNaN(h)||h<0)throw Error("Bad port number "+h);a.u=h}else a.u=null}function Cl(a,h,p){h instanceof li?(a.i=h,Hy(a.i,a.l)):(p||(h=ai(h,zy)),a.i=new li(h,a.l))}function ke(a,h,p){a.i.set(h,p)}function Os(a){return ke(a,"zx",Math.floor(Math.random()*2147483648).toString(36)+Math.abs(Math.floor(Math.random()*2147483648)^Date.now()).toString(36)),a}function si(a,h){return a?h?decodeURI(a.replace(/%25/g,"%2525")):decodeURIComponent(a):""}function ai(a,h,p){return typeof a=="string"?(a=encodeURI(a).replace(h,By),p&&(a=a.replace(/%25([0-9a-fA-F]{2})/g,"%$1")),a):null}function By(a){return a=a.charCodeAt(0),"%"+(a>>4&15).toString(16)+(a&15).toString(16)}var Md=/[#\/\?@]/g,$y=/[#\?:]/g,jy=/[#\?]/g,zy=/[#\?@]/g,Wy=/#/g;function li(a,h){this.h=this.g=null,this.i=a||null,this.j=!!h}function vr(a){a.g||(a.g=new Map,a.h=0,a.i&&qy(a.i,function(h,p){a.add(decodeURIComponent(h.replace(/\+/g," ")),p)}))}n=li.prototype,n.add=function(a,h){vr(this),this.i=null,a=to(this,a);let p=this.g.get(a);return p||this.g.set(a,p=[]),p.push(h),this.h+=1,this};function Dd(a,h){vr(a),h=to(a,h),a.g.has(h)&&(a.i=null,a.h-=a.g.get(h).length,a.g.delete(h))}function Vd(a,h){return vr(a),h=to(a,h),a.g.has(h)}n.forEach=function(a,h){vr(this),this.g.forEach(function(p,y){p.forEach(function(k){a.call(h,k,y,this)},this)},this)};function Fd(a,h){vr(a);let p=[];if(typeof h=="string")Vd(a,h)&&(p=p.concat(a.g.get(to(a,h))));else for(a=Array.from(a.g.values()),h=0;h<a.length;h++)p=p.concat(a[h]);return p}n.set=function(a,h){return vr(this),this.i=null,a=to(this,a),Vd(this,a)&&(this.h-=this.g.get(a).length),this.g.set(a,[h]),this.h+=1,this},n.get=function(a,h){return a?(a=Fd(this,a),a.length>0?String(a[0]):h):h};function Ud(a,h,p){Dd(a,h),p.length>0&&(a.i=null,a.g.set(to(a,h),v(p)),a.h+=p.length)}n.toString=function(){if(this.i)return this.i;if(!this.g)return"";const a=[],h=Array.from(this.g.keys());for(let y=0;y<h.length;y++){var p=h[y];const k=ni(p);p=Fd(this,p);for(let N=0;N<p.length;N++){let W=k;p[N]!==""&&(W+="="+ni(p[N])),a.push(W)}}return this.i=a.join("&")};function qd(a){const h=new li;return h.i=a.i,a.g&&(h.g=new Map(a.g),h.h=a.h),h}function to(a,h){return h=String(h),a.j&&(h=h.toLowerCase()),h}function Hy(a,h){h&&!a.j&&(vr(a),a.i=null,a.g.forEach(function(p,y){const k=y.toLowerCase();y!=k&&(Dd(this,y),Ud(this,k,p))},a)),a.j=h}function Gy(a,h){const p=new ti;if(s.Image){const y=new Image;y.onload=f(Vn,p,"TestLoadImage: loaded",!0,h,y),y.onerror=f(Vn,p,"TestLoadImage: error",!1,h,y),y.onabort=f(Vn,p,"TestLoadImage: abort",!1,h,y),y.ontimeout=f(Vn,p,"TestLoadImage: timeout",!1,h,y),s.setTimeout(function(){y.ontimeout&&y.ontimeout()},1e4),y.src=a}else h(!1)}function Yy(a,h){const p=new ti,y=new AbortController,k=setTimeout(()=>{y.abort(),Vn(p,"TestPingServer: timeout",!1,h)},1e4);fetch(a,{signal:y.signal}).then(N=>{clearTimeout(k),N.ok?Vn(p,"TestPingServer: ok",!0,h):Vn(p,"TestPingServer: server error",!1,h)}).catch(()=>{clearTimeout(k),Vn(p,"TestPingServer: error",!1,h)})}function Vn(a,h,p,y,k){try{k&&(k.onload=null,k.onerror=null,k.onabort=null,k.ontimeout=null),y(p)}catch{}}function Ky(){this.g=new ks}function Rl(a){this.i=a.Sb||null,this.h=a.ab||!1}g(Rl,md),Rl.prototype.g=function(){return new Ns(this.i,this.h)};function Ns(a,h){Ge.call(this),this.H=a,this.o=h,this.m=void 0,this.status=this.readyState=0,this.responseType=this.responseText=this.response=this.statusText="",this.onreadystatechange=null,this.A=new Headers,this.h=null,this.F="GET",this.D="",this.g=!1,this.B=this.j=this.l=null,this.v=new AbortController}g(Ns,Ge),n=Ns.prototype,n.open=function(a,h){if(this.readyState!=0)throw this.abort(),Error("Error reopening a connection");this.F=a,this.D=h,this.readyState=1,ui(this)},n.send=function(a){if(this.readyState!=1)throw this.abort(),Error("need to call open() first. ");if(this.v.signal.aborted)throw this.abort(),Error("Request was aborted.");this.g=!0;const h={headers:this.A,method:this.F,credentials:this.m,cache:void 0,signal:this.v.signal};a&&(h.body=a),(this.H||s).fetch(new Request(this.D,h)).then(this.Pa.bind(this),this.ga.bind(this))},n.abort=function(){this.response=this.responseText="",this.A=new Headers,this.status=0,this.v.abort(),this.j&&this.j.cancel("Request was aborted.").catch(()=>{}),this.readyState>=1&&this.g&&this.readyState!=4&&(this.g=!1,ci(this)),this.readyState=0},n.Pa=function(a){if(this.g&&(this.l=a,this.h||(this.status=this.l.status,this.statusText=this.l.statusText,this.h=a.headers,this.readyState=2,ui(this)),this.g&&(this.readyState=3,ui(this),this.g)))if(this.responseType==="arraybuffer")a.arrayBuffer().then(this.Na.bind(this),this.ga.bind(this));else if(typeof s.ReadableStream<"u"&&"body"in a){if(this.j=a.body.getReader(),this.o){if(this.responseType)throw Error('responseType must be empty for "streamBinaryChunks" mode responses.');this.response=[]}else this.response=this.responseText="",this.B=new TextDecoder;Bd(this)}else a.text().then(this.Oa.bind(this),this.ga.bind(this))};function Bd(a){a.j.read().then(a.Ma.bind(a)).catch(a.ga.bind(a))}n.Ma=function(a){if(this.g){if(this.o&&a.value)this.response.push(a.value);else if(!this.o){var h=a.value?a.value:new Uint8Array(0);(h=this.B.decode(h,{stream:!a.done}))&&(this.response=this.responseText+=h)}a.done?ci(this):ui(this),this.readyState==3&&Bd(this)}},n.Oa=function(a){this.g&&(this.response=this.responseText=a,ci(this))},n.Na=function(a){this.g&&(this.response=a,ci(this))},n.ga=function(){this.g&&ci(this)};function ci(a){a.readyState=4,a.l=null,a.j=null,a.B=null,ui(a)}n.setRequestHeader=function(a,h){this.A.append(a,h)},n.getResponseHeader=function(a){return this.h&&this.h.get(a.toLowerCase())||""},n.getAllResponseHeaders=function(){if(!this.h)return"";const a=[],h=this.h.entries();for(var p=h.next();!p.done;)p=p.value,a.push(p[0]+": "+p[1]),p=h.next();return a.join(`\r
`)};function ui(a){a.onreadystatechange&&a.onreadystatechange.call(a)}Object.defineProperty(Ns.prototype,"withCredentials",{get:function(){return this.m==="include"},set:function(a){this.m=a?"include":"same-origin"}});function $d(a){let h="";return Te(a,function(p,y){h+=y,h+=":",h+=p,h+=`\r
`}),h}function Ol(a,h,p){e:{for(y in p){var y=!1;break e}y=!0}y||(p=$d(p),typeof a=="string"?p!=null&&ni(p):ke(a,h,p))}function Le(a){Ge.call(this),this.headers=new Map,this.L=a||null,this.h=!1,this.g=null,this.D="",this.o=0,this.l="",this.j=this.B=this.v=this.A=!1,this.m=null,this.F="",this.H=!1}g(Le,Ge);var Xy=/^https?$/i,Qy=["POST","PUT"];n=Le.prototype,n.Fa=function(a){this.H=a},n.ea=function(a,h,p,y){if(this.g)throw Error("[goog.net.XhrIo] Object is active with another request="+this.D+"; newUri="+a);h=h?h.toUpperCase():"GET",this.D=a,this.l="",this.o=0,this.A=!1,this.h=!0,this.g=this.L?this.L.g():Ed.g(),this.g.onreadystatechange=m(u(this.Ca,this));try{this.B=!0,this.g.open(h,String(a),!0),this.B=!1}catch(N){jd(this,N);return}if(a=p||"",p=new Map(this.headers),y)if(Object.getPrototypeOf(y)===Object.prototype)for(var k in y)p.set(k,y[k]);else if(typeof y.keys=="function"&&typeof y.get=="function")for(const N of y.keys())p.set(N,y.get(N));else throw Error("Unknown input type for opt_headers: "+String(y));y=Array.from(p.keys()).find(N=>N.toLowerCase()=="content-type"),k=s.FormData&&a instanceof s.FormData,!(Array.prototype.indexOf.call(Qy,h,void 0)>=0)||y||k||p.set("Content-Type","application/x-www-form-urlencoded;charset=utf-8");for(const[N,W]of p)this.g.setRequestHeader(N,W);this.F&&(this.g.responseType=this.F),"withCredentials"in this.g&&this.g.withCredentials!==this.H&&(this.g.withCredentials=this.H);try{this.m&&(clearTimeout(this.m),this.m=null),this.v=!0,this.g.send(a),this.v=!1}catch(N){jd(this,N)}};function jd(a,h){a.h=!1,a.g&&(a.j=!0,a.g.abort(),a.j=!1),a.l=h,a.o=5,zd(a),Ls(a)}function zd(a){a.A||(a.A=!0,Je(a,"complete"),Je(a,"error"))}n.abort=function(a){this.g&&this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1,this.o=a||7,Je(this,"complete"),Je(this,"abort"),Ls(this))},n.N=function(){this.g&&(this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1),Ls(this,!0)),Le.Z.N.call(this)},n.Ca=function(){this.u||(this.B||this.v||this.j?Wd(this):this.Xa())},n.Xa=function(){Wd(this)};function Wd(a){if(a.h&&typeof i<"u"){if(a.v&&Fn(a)==4)setTimeout(a.Ca.bind(a),0);else if(Je(a,"readystatechange"),Fn(a)==4){a.h=!1;try{const N=a.ca();e:switch(N){case 200:case 201:case 202:case 204:case 206:case 304:case 1223:var h=!0;break e;default:h=!1}var p;if(!(p=h)){var y;if(y=N===0){let W=String(a.D).match(Ld)[1]||null;!W&&s.self&&s.self.location&&(W=s.self.location.protocol.slice(0,-1)),y=!Xy.test(W?W.toLowerCase():"")}p=y}if(p)Je(a,"complete"),Je(a,"success");else{a.o=6;try{var k=Fn(a)>2?a.g.statusText:""}catch{k=""}a.l=k+" ["+a.ca()+"]",zd(a)}}finally{Ls(a)}}}}function Ls(a,h){if(a.g){a.m&&(clearTimeout(a.m),a.m=null);const p=a.g;a.g=null,h||Je(a,"ready");try{p.onreadystatechange=null}catch{}}}n.isActive=function(){return!!this.g};function Fn(a){return a.g?a.g.readyState:0}n.ca=function(){try{return Fn(this)>2?this.g.status:-1}catch{return-1}},n.la=function(){try{return this.g?this.g.responseText:""}catch{return""}},n.La=function(a){if(this.g){var h=this.g.responseText;return a&&h.indexOf(a)==0&&(h=h.substring(a.length)),As(h)}};function Hd(a){try{if(!a.g)return null;if("response"in a.g)return a.g.response;switch(a.F){case"":case"text":return a.g.responseText;case"arraybuffer":if("mozResponseArrayBuffer"in a.g)return a.g.mozResponseArrayBuffer}return null}catch{return null}}function Jy(a){const h={};a=(a.g&&Fn(a)>=2&&a.g.getAllResponseHeaders()||"").split(`\r
`);for(let y=0;y<a.length;y++){if(w(a[y]))continue;var p=Dy(a[y]);const k=p[0];if(p=p[1],typeof p!="string")continue;p=p.trim();const N=h[k]||[];h[k]=N,N.push(p)}Ie(h,function(y){return y.join(", ")})}n.ya=function(){return this.o},n.Ha=function(){return typeof this.l=="string"?this.l:String(this.l)};function di(a,h,p){return p&&p.internalChannelParams&&p.internalChannelParams[a]||h}function Gd(a){this.za=0,this.i=[],this.j=new ti,this.ba=this.na=this.J=this.W=this.g=this.wa=this.G=this.H=this.u=this.U=this.o=null,this.Ya=this.V=0,this.Sa=di("failFast",!1,a),this.F=this.C=this.v=this.m=this.l=null,this.X=!0,this.xa=this.K=-1,this.Y=this.A=this.D=0,this.Qa=di("baseRetryDelayMs",5e3,a),this.Za=di("retryDelaySeedMs",1e4,a),this.Ta=di("forwardChannelMaxRetries",2,a),this.va=di("forwardChannelRequestTimeoutMs",2e4,a),this.ma=a&&a.xmlHttpFactory||void 0,this.Ua=a&&a.Rb||void 0,this.Aa=a&&a.useFetchStreams||!1,this.O=void 0,this.L=a&&a.supportsCrossDomainXhr||!1,this.M="",this.h=new Pd(a&&a.concurrentRequestLimit),this.Ba=new Ky,this.S=a&&a.fastHandshake||!1,this.R=a&&a.encodeInitMessageHeaders||!1,this.S&&this.R&&(this.R=!1),this.Ra=a&&a.Pb||!1,a&&a.ua&&this.j.ua(),a&&a.forceLongPolling&&(this.X=!1),this.aa=!this.S&&this.X&&a&&a.detectBufferingProxy||!1,this.ia=void 0,a&&a.longPollingTimeout&&a.longPollingTimeout>0&&(this.ia=a.longPollingTimeout),this.ta=void 0,this.T=0,this.P=!1,this.ja=this.B=null}n=Gd.prototype,n.ka=8,n.I=1,n.connect=function(a,h,p,y){ft(0),this.W=a,this.H=h||{},p&&y!==void 0&&(this.H.OSID=p,this.H.OAID=y),this.F=this.X,this.J=nh(this,null,this.W),Ds(this)};function Nl(a){if(Yd(a),a.I==3){var h=a.V++,p=Ht(a.J);if(ke(p,"SID",a.M),ke(p,"RID",h),ke(p,"TYPE","terminate"),hi(a,p),h=new Mn(a,a.j,h),h.M=2,h.A=Os(Ht(p)),p=!1,s.navigator&&s.navigator.sendBeacon)try{p=s.navigator.sendBeacon(h.A.toString(),"")}catch{}!p&&s.Image&&(new Image().src=h.A,p=!0),p||(h.g=rh(h.j,null),h.g.ea(h.A)),h.F=Date.now(),Rs(h)}th(a)}function Ms(a){a.g&&(Ml(a),a.g.cancel(),a.g=null)}function Yd(a){Ms(a),a.v&&(s.clearTimeout(a.v),a.v=null),Vs(a),a.h.cancel(),a.m&&(typeof a.m=="number"&&s.clearTimeout(a.m),a.m=null)}function Ds(a){if(!Cd(a.h)&&!a.m){a.m=!0;var h=a.Ea;V||b(),B||(V(),B=!0),I.add(h,a),a.D=0}}function Zy(a,h){return Rd(a.h)>=a.h.j-(a.m?1:0)?!1:a.m?(a.i=h.G.concat(a.i),!0):a.I==1||a.I==2||a.D>=(a.Sa?0:a.Ta)?!1:(a.m=ei(u(a.Ea,a,h),eh(a,a.D)),a.D++,!0)}n.Ea=function(a){if(this.m)if(this.m=null,this.I==1){if(!a){this.V=Math.floor(Math.random()*1e5),a=this.V++;const k=new Mn(this,this.j,a);let N=this.o;if(this.U&&(N?(N=ae(N),ve(N,this.U)):N=this.U),this.u!==null||this.R||(k.J=N,N=null),this.S)e:{for(var h=0,p=0;p<this.i.length;p++){t:{var y=this.i[p];if("__data__"in y.map&&(y=y.map.__data__,typeof y=="string")){y=y.length;break t}y=void 0}if(y===void 0)break;if(h+=y,h>4096){h=p;break e}if(h===4096||p===this.i.length-1){h=p+1;break e}}h=1e3}else h=1e3;h=Xd(this,k,h),p=Ht(this.J),ke(p,"RID",a),ke(p,"CVER",22),this.G&&ke(p,"X-HTTP-Session-Id",this.G),hi(this,p),N&&(this.R?h="headers="+ni($d(N))+"&"+h:this.u&&Ol(p,this.u,N)),Pl(this.h,k),this.Ra&&ke(p,"TYPE","init"),this.S?(ke(p,"$req",h),ke(p,"SID","null"),k.U=!0,Sl(k,p,null)):Sl(k,p,h),this.I=2}}else this.I==3&&(a?Kd(this,a):this.i.length==0||Cd(this.h)||Kd(this))};function Kd(a,h){var p;h?p=h.l:p=a.V++;const y=Ht(a.J);ke(y,"SID",a.M),ke(y,"RID",p),ke(y,"AID",a.K),hi(a,y),a.u&&a.o&&Ol(y,a.u,a.o),p=new Mn(a,a.j,p,a.D+1),a.u===null&&(p.J=a.o),h&&(a.i=h.G.concat(a.i)),h=Xd(a,p,1e3),p.H=Math.round(a.va*.5)+Math.round(a.va*.5*Math.random()),Pl(a.h,p),Sl(p,y,h)}function hi(a,h){a.H&&Te(a.H,function(p,y){ke(h,y,p)}),a.l&&Te({},function(p,y){ke(h,y,p)})}function Xd(a,h,p){p=Math.min(a.i.length,p);const y=a.l?u(a.l.Ka,a.l,a):null;e:{var k=a.i;let ie=-1;for(;;){const Ye=["count="+p];ie==-1?p>0?(ie=k[0].g,Ye.push("ofs="+ie)):ie=0:Ye.push("ofs="+ie);let Ee=!0;for(let et=0;et<p;et++){var N=k[et].g;const Gt=k[et].map;if(N-=ie,N<0)ie=Math.max(0,k[et].g-100),Ee=!1;else try{N="req"+N+"_"||"";try{var W=Gt instanceof Map?Gt:Object.entries(Gt);for(const[br,Un]of W){let qn=Un;c(Un)&&(qn=Ue(Un)),Ye.push(N+br+"="+encodeURIComponent(qn))}}catch(br){throw Ye.push(N+"type="+encodeURIComponent("_badmap")),br}}catch{y&&y(Gt)}}if(Ee){W=Ye.join("&");break e}}W=void 0}return a=a.i.splice(0,p),h.G=a,W}function Qd(a){if(!a.g&&!a.v){a.Y=1;var h=a.Da;V||b(),B||(V(),B=!0),I.add(h,a),a.A=0}}function Ll(a){return a.g||a.v||a.A>=3?!1:(a.Y++,a.v=ei(u(a.Da,a),eh(a,a.A)),a.A++,!0)}n.Da=function(){if(this.v=null,Jd(this),this.aa&&!(this.P||this.g==null||this.T<=0)){var a=4*this.T;this.j.info("BP detection timer enabled: "+a),this.B=ei(u(this.Wa,this),a)}},n.Wa=function(){this.B&&(this.B=null,this.j.info("BP detection timeout reached."),this.j.info("Buffering proxy detected and switch to long-polling!"),this.F=!1,this.P=!0,ft(10),Ms(this),Jd(this))};function Ml(a){a.B!=null&&(s.clearTimeout(a.B),a.B=null)}function Jd(a){a.g=new Mn(a,a.j,"rpc",a.Y),a.u===null&&(a.g.J=a.o),a.g.P=0;var h=Ht(a.na);ke(h,"RID","rpc"),ke(h,"SID",a.M),ke(h,"AID",a.K),ke(h,"CI",a.F?"0":"1"),!a.F&&a.ia&&ke(h,"TO",a.ia),ke(h,"TYPE","xmlhttp"),hi(a,h),a.u&&a.o&&Ol(h,a.u,a.o),a.O&&(a.g.H=a.O);var p=a.g;a=a.ba,p.M=1,p.A=Os(Ht(h)),p.u=null,p.R=!0,xd(p,a)}n.Va=function(){this.C!=null&&(this.C=null,Ms(this),Ll(this),ft(19))};function Vs(a){a.C!=null&&(s.clearTimeout(a.C),a.C=null)}function Zd(a,h){var p=null;if(a.g==h){Vs(a),Ml(a),a.g=null;var y=2}else if(kl(a.h,h))p=h.G,Od(a.h,h),y=1;else return;if(a.I!=0){if(h.o)if(y==1){p=h.u?h.u.length:0,h=Date.now()-h.F;var k=a.D;y=Ps(),Je(y,new wd(y,p)),Ds(a)}else Qd(a);else if(k=h.m,k==3||k==0&&h.X>0||!(y==1&&Zy(a,h)||y==2&&Ll(a)))switch(p&&p.length>0&&(h=a.h,h.i=h.i.concat(p)),k){case 1:_r(a,5);break;case 4:_r(a,10);break;case 3:_r(a,6);break;default:_r(a,2)}}}function eh(a,h){let p=a.Qa+Math.floor(Math.random()*a.Za);return a.isActive()||(p*=2),p*h}function _r(a,h){if(a.j.info("Error code "+h),h==2){var p=u(a.bb,a),y=a.Ua;const k=!y;y=new Dn(y||"//www.google.com/images/cleardot.gif"),s.location&&s.location.protocol=="http"||oi(y,"https"),Os(y),k?Gy(y.toString(),p):Yy(y.toString(),p)}else ft(2);a.I=0,a.l&&a.l.pa(h),th(a),Yd(a)}n.bb=function(a){a?(this.j.info("Successfully pinged google.com"),ft(2)):(this.j.info("Failed to ping google.com"),ft(1))};function th(a){if(a.I=0,a.ja=[],a.l){const h=Nd(a.h);(h.length!=0||a.i.length!=0)&&(L(a.ja,h),L(a.ja,a.i),a.h.i.length=0,v(a.i),a.i.length=0),a.l.oa()}}function nh(a,h,p){var y=p instanceof Dn?Ht(p):new Dn(p);if(y.g!="")h&&(y.g=h+"."+y.g),ii(y,y.u);else{var k=s.location;y=k.protocol,h=h?h+"."+k.hostname:k.hostname,k=+k.port;const N=new Dn(null);y&&oi(N,y),h&&(N.g=h),k&&ii(N,k),p&&(N.h=p),y=N}return p=a.G,h=a.wa,p&&h&&ke(y,p,h),ke(y,"VER",a.ka),hi(a,y),y}function rh(a,h,p){if(h&&!a.L)throw Error("Can't create secondary domain capable XhrIo object.");return h=a.Aa&&!a.ma?new Le(new Rl({ab:p})):new Le(a.ma),h.Fa(a.L),h}n.isActive=function(){return!!this.l&&this.l.isActive(this)};function oh(){}n=oh.prototype,n.ra=function(){},n.qa=function(){},n.pa=function(){},n.oa=function(){},n.isActive=function(){return!0},n.Ka=function(){};function Fs(){}Fs.prototype.g=function(a,h){return new St(a,h)};function St(a,h){Ge.call(this),this.g=new Gd(h),this.l=a,this.h=h&&h.messageUrlParams||null,a=h&&h.messageHeaders||null,h&&h.clientProtocolHeaderRequired&&(a?a["X-Client-Protocol"]="webchannel":a={"X-Client-Protocol":"webchannel"}),this.g.o=a,a=h&&h.initMessageHeaders||null,h&&h.messageContentType&&(a?a["X-WebChannel-Content-Type"]=h.messageContentType:a={"X-WebChannel-Content-Type":h.messageContentType}),h&&h.sa&&(a?a["X-WebChannel-Client-Profile"]=h.sa:a={"X-WebChannel-Client-Profile":h.sa}),this.g.U=a,(a=h&&h.Qb)&&!w(a)&&(this.g.u=a),this.A=h&&h.supportsCrossDomainXhr||!1,this.v=h&&h.sendRawJson||!1,(h=h&&h.httpSessionIdParam)&&!w(h)&&(this.g.G=h,a=this.h,a!==null&&h in a&&(a=this.h,h in a&&delete a[h])),this.j=new no(this)}g(St,Ge),St.prototype.m=function(){this.g.l=this.j,this.A&&(this.g.L=!0),this.g.connect(this.l,this.h||void 0)},St.prototype.close=function(){Nl(this.g)},St.prototype.o=function(a){var h=this.g;if(typeof a=="string"){var p={};p.__data__=a,a=p}else this.v&&(p={},p.__data__=Ue(a),a=p);h.i.push(new Uy(h.Ya++,a)),h.I==3&&Ds(h)},St.prototype.N=function(){this.g.l=null,delete this.j,Nl(this.g),delete this.g,St.Z.N.call(this)};function ih(a){wl.call(this),a.__headers__&&(this.headers=a.__headers__,this.statusCode=a.__status__,delete a.__headers__,delete a.__status__);var h=a.__sm__;if(h){e:{for(const p in h){a=p;break e}a=void 0}(this.i=a)&&(a=this.i,h=h!==null&&a in h?h[a]:void 0),this.data=h}else this.data=a}g(ih,wl);function sh(){Tl.call(this),this.status=1}g(sh,Tl);function no(a){this.g=a}g(no,oh),no.prototype.ra=function(){Je(this.g,"a")},no.prototype.qa=function(a){Je(this.g,new ih(a))},no.prototype.pa=function(a){Je(this.g,new sh)},no.prototype.oa=function(){Je(this.g,"b")},Fs.prototype.createWebChannel=Fs.prototype.g,St.prototype.send=St.prototype.o,St.prototype.open=St.prototype.m,St.prototype.close=St.prototype.close,ag=function(){return new Fs},sg=function(){return Ps()},ig=mr,fc={jb:0,mb:1,nb:2,Hb:3,Mb:4,Jb:5,Kb:6,Ib:7,Gb:8,Lb:9,PROXY:10,NOPROXY:11,Eb:12,Ab:13,Bb:14,zb:15,Cb:16,Db:17,fb:18,eb:19,gb:20},Cs.NO_ERROR=0,Cs.TIMEOUT=8,Cs.HTTP_ERROR=6,la=Cs,Td.COMPLETE="complete",og=Td,yd.EventType=Jo,Jo.OPEN="a",Jo.CLOSE="b",Jo.ERROR="c",Jo.MESSAGE="d",Ge.prototype.listen=Ge.prototype.J,Ti=yd,Le.prototype.listenOnce=Le.prototype.K,Le.prototype.getLastError=Le.prototype.Ha,Le.prototype.getLastErrorCode=Le.prototype.ya,Le.prototype.getStatus=Le.prototype.ca,Le.prototype.getResponseJson=Le.prototype.La,Le.prototype.getResponseText=Le.prototype.la,Le.prototype.send=Le.prototype.ea,Le.prototype.setWithCredentials=Le.prototype.Fa,rg=Le}).apply(typeof Bs<"u"?Bs:typeof self<"u"?self:typeof window<"u"?window:{});/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ct{constructor(e){this.uid=e}isAuthenticated(){return this.uid!=null}toKey(){return this.isAuthenticated()?"uid:"+this.uid:"anonymous-user"}isEqual(e){return e.uid===this.uid}}ct.UNAUTHENTICATED=new ct(null),ct.GOOGLE_CREDENTIALS=new ct("google-credentials-uid"),ct.FIRST_PARTY=new ct("first-party-uid"),ct.MOCK_USER=new ct("mock-user");/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let qo="12.12.0";function Vw(n){qo=n}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Fr=new Kc("@firebase/firestore");function ro(){return Fr.logLevel}function Y(n,...e){if(Fr.logLevel<=le.DEBUG){const t=e.map(au);Fr.debug(`Firestore (${qo}): ${n}`,...t)}}function Cn(n,...e){if(Fr.logLevel<=le.ERROR){const t=e.map(au);Fr.error(`Firestore (${qo}): ${n}`,...t)}}function Ur(n,...e){if(Fr.logLevel<=le.WARN){const t=e.map(au);Fr.warn(`Firestore (${qo}): ${n}`,...t)}}function au(n){if(typeof n=="string")return n;try{return function(t){return JSON.stringify(t)}(n)}catch{return n}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ee(n,e,t){let r="Unexpected state";typeof e=="string"?r=e:t=e,lg(n,r,t)}function lg(n,e,t){let r=`FIRESTORE (${qo}) INTERNAL ASSERTION FAILED: ${e} (ID: ${n.toString(16)})`;if(t!==void 0)try{r+=" CONTEXT: "+JSON.stringify(t)}catch{r+=" CONTEXT: "+t}throw Cn(r),new Error(r)}function we(n,e,t,r){let o="Unexpected state";typeof t=="string"?o=t:r=t,n||lg(e,o,r)}function re(n,e){return n}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const F={OK:"ok",CANCELLED:"cancelled",UNKNOWN:"unknown",INVALID_ARGUMENT:"invalid-argument",DEADLINE_EXCEEDED:"deadline-exceeded",NOT_FOUND:"not-found",ALREADY_EXISTS:"already-exists",PERMISSION_DENIED:"permission-denied",UNAUTHENTICATED:"unauthenticated",RESOURCE_EXHAUSTED:"resource-exhausted",FAILED_PRECONDITION:"failed-precondition",ABORTED:"aborted",OUT_OF_RANGE:"out-of-range",UNIMPLEMENTED:"unimplemented",INTERNAL:"internal",UNAVAILABLE:"unavailable",DATA_LOSS:"data-loss"};class H extends Nn{constructor(e,t){super(e,t),this.code=e,this.message=t,this.toString=()=>`${this.name}: [code=${this.code}]: ${this.message}`}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class In{constructor(){this.promise=new Promise((e,t)=>{this.resolve=e,this.reject=t})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class cg{constructor(e,t){this.user=t,this.type="OAuth",this.headers=new Map,this.headers.set("Authorization",`Bearer ${e}`)}}class Fw{getToken(){return Promise.resolve(null)}invalidateToken(){}start(e,t){e.enqueueRetryable(()=>t(ct.UNAUTHENTICATED))}shutdown(){}}class Uw{constructor(e){this.token=e,this.changeListener=null}getToken(){return Promise.resolve(this.token)}invalidateToken(){}start(e,t){this.changeListener=t,e.enqueueRetryable(()=>t(this.token.user))}shutdown(){this.changeListener=null}}class qw{constructor(e){this.t=e,this.currentUser=ct.UNAUTHENTICATED,this.i=0,this.forceRefresh=!1,this.auth=null}start(e,t){we(this.o===void 0,42304);let r=this.i;const o=d=>this.i!==r?(r=this.i,t(d)):Promise.resolve();let i=new In;this.o=()=>{this.i++,this.currentUser=this.u(),i.resolve(),i=new In,e.enqueueRetryable(()=>o(this.currentUser))};const s=()=>{const d=i;e.enqueueRetryable(async()=>{await d.promise,await o(this.currentUser)})},c=d=>{Y("FirebaseAuthCredentialsProvider","Auth detected"),this.auth=d,this.o&&(this.auth.addAuthTokenListener(this.o),s())};this.t.onInit(d=>c(d)),setTimeout(()=>{if(!this.auth){const d=this.t.getImmediate({optional:!0});d?c(d):(Y("FirebaseAuthCredentialsProvider","Auth not yet detected"),i.resolve(),i=new In)}},0),s()}getToken(){const e=this.i,t=this.forceRefresh;return this.forceRefresh=!1,this.auth?this.auth.getToken(t).then(r=>this.i!==e?(Y("FirebaseAuthCredentialsProvider","getToken aborted due to token change."),this.getToken()):r?(we(typeof r.accessToken=="string",31837,{l:r}),new cg(r.accessToken,this.currentUser)):null):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.auth&&this.o&&this.auth.removeAuthTokenListener(this.o),this.o=void 0}u(){const e=this.auth&&this.auth.getUid();return we(e===null||typeof e=="string",2055,{h:e}),new ct(e)}}class Bw{constructor(e,t,r){this.P=e,this.T=t,this.I=r,this.type="FirstParty",this.user=ct.FIRST_PARTY,this.R=new Map}A(){return this.I?this.I():null}get headers(){this.R.set("X-Goog-AuthUser",this.P);const e=this.A();return e&&this.R.set("Authorization",e),this.T&&this.R.set("X-Goog-Iam-Authorization-Token",this.T),this.R}}class $w{constructor(e,t,r){this.P=e,this.T=t,this.I=r}getToken(){return Promise.resolve(new Bw(this.P,this.T,this.I))}start(e,t){e.enqueueRetryable(()=>t(ct.FIRST_PARTY))}shutdown(){}invalidateToken(){}}class Mh{constructor(e){this.value=e,this.type="AppCheck",this.headers=new Map,e&&e.length>0&&this.headers.set("x-firebase-appcheck",this.value)}}class jw{constructor(e,t){this.V=t,this.forceRefresh=!1,this.appCheck=null,this.m=null,this.p=null,Xt(e)&&e.settings.appCheckToken&&(this.p=e.settings.appCheckToken)}start(e,t){we(this.o===void 0,3512);const r=i=>{i.error!=null&&Y("FirebaseAppCheckTokenProvider",`Error getting App Check token; using placeholder token instead. Error: ${i.error.message}`);const s=i.token!==this.m;return this.m=i.token,Y("FirebaseAppCheckTokenProvider",`Received ${s?"new":"existing"} token.`),s?t(i.token):Promise.resolve()};this.o=i=>{e.enqueueRetryable(()=>r(i))};const o=i=>{Y("FirebaseAppCheckTokenProvider","AppCheck detected"),this.appCheck=i,this.o&&this.appCheck.addTokenListener(this.o)};this.V.onInit(i=>o(i)),setTimeout(()=>{if(!this.appCheck){const i=this.V.getImmediate({optional:!0});i?o(i):Y("FirebaseAppCheckTokenProvider","AppCheck not yet detected")}},0)}getToken(){if(this.p)return Promise.resolve(new Mh(this.p));const e=this.forceRefresh;return this.forceRefresh=!1,this.appCheck?this.appCheck.getToken(e).then(t=>t?(we(typeof t.token=="string",44558,{tokenResult:t}),this.m=t.token,new Mh(t.token)):null):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.appCheck&&this.o&&this.appCheck.removeTokenListener(this.o),this.o=void 0}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function zw(n){const e=typeof self<"u"&&(self.crypto||self.msCrypto),t=new Uint8Array(n);if(e&&typeof e.getRandomValues=="function")e.getRandomValues(t);else for(let r=0;r<n;r++)t[r]=Math.floor(256*Math.random());return t}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class lu{static newId(){const e="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",t=62*Math.floor(4.129032258064516);let r="";for(;r.length<20;){const o=zw(40);for(let i=0;i<o.length;++i)r.length<20&&o[i]<t&&(r+=e.charAt(o[i]%62))}return r}}function ce(n,e){return n<e?-1:n>e?1:0}function pc(n,e){const t=Math.min(n.length,e.length);for(let r=0;r<t;r++){const o=n.charAt(r),i=e.charAt(r);if(o!==i)return zl(o)===zl(i)?ce(o,i):zl(o)?1:-1}return ce(n.length,e.length)}const Ww=55296,Hw=57343;function zl(n){const e=n.charCodeAt(0);return e>=Ww&&e<=Hw}function ko(n,e,t){return n.length===e.length&&n.every((r,o)=>t(r,e[o]))}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Dh="__name__";class Kt{constructor(e,t,r){t===void 0?t=0:t>e.length&&ee(637,{offset:t,range:e.length}),r===void 0?r=e.length-t:r>e.length-t&&ee(1746,{length:r,range:e.length-t}),this.segments=e,this.offset=t,this.len=r}get length(){return this.len}isEqual(e){return Kt.comparator(this,e)===0}child(e){const t=this.segments.slice(this.offset,this.limit());return e instanceof Kt?e.forEach(r=>{t.push(r)}):t.push(e),this.construct(t)}limit(){return this.offset+this.length}popFirst(e){return e=e===void 0?1:e,this.construct(this.segments,this.offset+e,this.length-e)}popLast(){return this.construct(this.segments,this.offset,this.length-1)}firstSegment(){return this.segments[this.offset]}lastSegment(){return this.get(this.length-1)}get(e){return this.segments[this.offset+e]}isEmpty(){return this.length===0}isPrefixOf(e){if(e.length<this.length)return!1;for(let t=0;t<this.length;t++)if(this.get(t)!==e.get(t))return!1;return!0}isImmediateParentOf(e){if(this.length+1!==e.length)return!1;for(let t=0;t<this.length;t++)if(this.get(t)!==e.get(t))return!1;return!0}forEach(e){for(let t=this.offset,r=this.limit();t<r;t++)e(this.segments[t])}toArray(){return this.segments.slice(this.offset,this.limit())}static comparator(e,t){const r=Math.min(e.length,t.length);for(let o=0;o<r;o++){const i=Kt.compareSegments(e.get(o),t.get(o));if(i!==0)return i}return ce(e.length,t.length)}static compareSegments(e,t){const r=Kt.isNumericId(e),o=Kt.isNumericId(t);return r&&!o?-1:!r&&o?1:r&&o?Kt.extractNumericId(e).compare(Kt.extractNumericId(t)):pc(e,t)}static isNumericId(e){return e.startsWith("__id")&&e.endsWith("__")}static extractNumericId(e){return Zn.fromString(e.substring(4,e.length-2))}}class Se extends Kt{construct(e,t,r){return new Se(e,t,r)}canonicalString(){return this.toArray().join("/")}toString(){return this.canonicalString()}toUriEncodedString(){return this.toArray().map(encodeURIComponent).join("/")}static fromString(...e){const t=[];for(const r of e){if(r.indexOf("//")>=0)throw new H(F.INVALID_ARGUMENT,`Invalid segment (${r}). Paths must not contain // in them.`);t.push(...r.split("/").filter(o=>o.length>0))}return new Se(t)}static emptyPath(){return new Se([])}}const Gw=/^[_a-zA-Z][_a-zA-Z0-9]*$/;class it extends Kt{construct(e,t,r){return new it(e,t,r)}static isValidIdentifier(e){return Gw.test(e)}canonicalString(){return this.toArray().map(e=>(e=e.replace(/\\/g,"\\\\").replace(/`/g,"\\`"),it.isValidIdentifier(e)||(e="`"+e+"`"),e)).join(".")}toString(){return this.canonicalString()}isKeyField(){return this.length===1&&this.get(0)===Dh}static keyField(){return new it([Dh])}static fromServerFormat(e){const t=[];let r="",o=0;const i=()=>{if(r.length===0)throw new H(F.INVALID_ARGUMENT,`Invalid field path (${e}). Paths must not be empty, begin with '.', end with '.', or contain '..'`);t.push(r),r=""};let s=!1;for(;o<e.length;){const c=e[o];if(c==="\\"){if(o+1===e.length)throw new H(F.INVALID_ARGUMENT,"Path has trailing escape character: "+e);const d=e[o+1];if(d!=="\\"&&d!=="."&&d!=="`")throw new H(F.INVALID_ARGUMENT,"Path has invalid escape sequence: "+e);r+=d,o+=2}else c==="`"?(s=!s,o++):c!=="."||s?(r+=c,o++):(i(),o++)}if(i(),s)throw new H(F.INVALID_ARGUMENT,"Unterminated ` in path: "+e);return new it(t)}static emptyPath(){return new it([])}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Q{constructor(e){this.path=e}static fromPath(e){return new Q(Se.fromString(e))}static fromName(e){return new Q(Se.fromString(e).popFirst(5))}static empty(){return new Q(Se.emptyPath())}get collectionGroup(){return this.path.popLast().lastSegment()}hasCollectionId(e){return this.path.length>=2&&this.path.get(this.path.length-2)===e}getCollectionGroup(){return this.path.get(this.path.length-2)}getCollectionPath(){return this.path.popLast()}isEqual(e){return e!==null&&Se.comparator(this.path,e.path)===0}toString(){return this.path.toString()}static comparator(e,t){return Se.comparator(e.path,t.path)}static isDocumentKey(e){return e.length%2==0}static fromSegments(e){return new Q(new Se(e.slice()))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ug(n,e,t){if(!t)throw new H(F.INVALID_ARGUMENT,`Function ${n}() cannot be called with an empty ${e}.`)}function Yw(n,e,t,r){if(e===!0&&r===!0)throw new H(F.INVALID_ARGUMENT,`${n} and ${t} cannot be used together.`)}function Vh(n){if(!Q.isDocumentKey(n))throw new H(F.INVALID_ARGUMENT,`Invalid document reference. Document references must have an even number of segments, but ${n} has ${n.length}.`)}function Fh(n){if(Q.isDocumentKey(n))throw new H(F.INVALID_ARGUMENT,`Invalid collection reference. Collection references must have an odd number of segments, but ${n} has ${n.length}.`)}function dg(n){return typeof n=="object"&&n!==null&&(Object.getPrototypeOf(n)===Object.prototype||Object.getPrototypeOf(n)===null)}function el(n){if(n===void 0)return"undefined";if(n===null)return"null";if(typeof n=="string")return n.length>20&&(n=`${n.substring(0,20)}...`),JSON.stringify(n);if(typeof n=="number"||typeof n=="boolean")return""+n;if(typeof n=="object"){if(n instanceof Array)return"an array";{const e=function(r){return r.constructor?r.constructor.name:null}(n);return e?`a custom ${e} object`:"an object"}}return typeof n=="function"?"a function":ee(12329,{type:typeof n})}function Ot(n,e){if("_delegate"in n&&(n=n._delegate),!(n instanceof e)){if(e.name===n.constructor.name)throw new H(F.INVALID_ARGUMENT,"Type does not match the expected instance. Did you pass a reference from a different Firestore SDK?");{const t=el(n);throw new H(F.INVALID_ARGUMENT,`Expected type '${e.name}', but it was: ${t}`)}}return n}function Kw(n,e){if(e<=0)throw new H(F.INVALID_ARGUMENT,`Function ${n}() requires a positive number, but it was: ${e}.`)}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function We(n,e){const t={typeString:n};return e&&(t.value=e),t}function ms(n,e){if(!dg(n))throw new H(F.INVALID_ARGUMENT,"JSON must be an object");let t;for(const r in e)if(e[r]){const o=e[r].typeString,i="value"in e[r]?{value:e[r].value}:void 0;if(!(r in n)){t=`JSON missing required field: '${r}'`;break}const s=n[r];if(o&&typeof s!==o){t=`JSON field '${r}' must be a ${o}.`;break}if(i!==void 0&&s!==i.value){t=`Expected '${r}' field to equal '${i.value}'`;break}}if(t)throw new H(F.INVALID_ARGUMENT,t);return!0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Uh=-62135596800,qh=1e6;class Pe{static now(){return Pe.fromMillis(Date.now())}static fromDate(e){return Pe.fromMillis(e.getTime())}static fromMillis(e){const t=Math.floor(e/1e3),r=Math.floor((e-1e3*t)*qh);return new Pe(t,r)}constructor(e,t){if(this.seconds=e,this.nanoseconds=t,t<0)throw new H(F.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+t);if(t>=1e9)throw new H(F.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+t);if(e<Uh)throw new H(F.INVALID_ARGUMENT,"Timestamp seconds out of range: "+e);if(e>=253402300800)throw new H(F.INVALID_ARGUMENT,"Timestamp seconds out of range: "+e)}toDate(){return new Date(this.toMillis())}toMillis(){return 1e3*this.seconds+this.nanoseconds/qh}_compareTo(e){return this.seconds===e.seconds?ce(this.nanoseconds,e.nanoseconds):ce(this.seconds,e.seconds)}isEqual(e){return e.seconds===this.seconds&&e.nanoseconds===this.nanoseconds}toString(){return"Timestamp(seconds="+this.seconds+", nanoseconds="+this.nanoseconds+")"}toJSON(){return{type:Pe._jsonSchemaVersion,seconds:this.seconds,nanoseconds:this.nanoseconds}}static fromJSON(e){if(ms(e,Pe._jsonSchema))return new Pe(e.seconds,e.nanoseconds)}valueOf(){const e=this.seconds-Uh;return String(e).padStart(12,"0")+"."+String(this.nanoseconds).padStart(9,"0")}}Pe._jsonSchemaVersion="firestore/timestamp/1.0",Pe._jsonSchema={type:We("string",Pe._jsonSchemaVersion),seconds:We("number"),nanoseconds:We("number")};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ne{static fromTimestamp(e){return new ne(e)}static min(){return new ne(new Pe(0,0))}static max(){return new ne(new Pe(253402300799,999999999))}constructor(e){this.timestamp=e}compareTo(e){return this.timestamp._compareTo(e.timestamp)}isEqual(e){return this.timestamp.isEqual(e.timestamp)}toMicroseconds(){return 1e6*this.timestamp.seconds+this.timestamp.nanoseconds/1e3}toString(){return"SnapshotVersion("+this.timestamp.toString()+")"}toTimestamp(){return this.timestamp}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Hi=-1;function Xw(n,e){const t=n.toTimestamp().seconds,r=n.toTimestamp().nanoseconds+1,o=ne.fromTimestamp(r===1e9?new Pe(t+1,0):new Pe(t,r));return new or(o,Q.empty(),e)}function Qw(n){return new or(n.readTime,n.key,Hi)}class or{constructor(e,t,r){this.readTime=e,this.documentKey=t,this.largestBatchId=r}static min(){return new or(ne.min(),Q.empty(),Hi)}static max(){return new or(ne.max(),Q.empty(),Hi)}}function Jw(n,e){let t=n.readTime.compareTo(e.readTime);return t!==0?t:(t=Q.comparator(n.documentKey,e.documentKey),t!==0?t:ce(n.largestBatchId,e.largestBatchId))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Zw="The current tab is not in the required state to perform this operation. It might be necessary to refresh the browser tab.";class eT{constructor(){this.onCommittedListeners=[]}addOnCommittedListener(e){this.onCommittedListeners.push(e)}raiseOnCommittedEvent(){this.onCommittedListeners.forEach(e=>e())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Bo(n){if(n.code!==F.FAILED_PRECONDITION||n.message!==Zw)throw n;Y("LocalStore","Unexpectedly lost primary lease")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class U{constructor(e){this.nextCallback=null,this.catchCallback=null,this.result=void 0,this.error=void 0,this.isDone=!1,this.callbackAttached=!1,e(t=>{this.isDone=!0,this.result=t,this.nextCallback&&this.nextCallback(t)},t=>{this.isDone=!0,this.error=t,this.catchCallback&&this.catchCallback(t)})}catch(e){return this.next(void 0,e)}next(e,t){return this.callbackAttached&&ee(59440),this.callbackAttached=!0,this.isDone?this.error?this.wrapFailure(t,this.error):this.wrapSuccess(e,this.result):new U((r,o)=>{this.nextCallback=i=>{this.wrapSuccess(e,i).next(r,o)},this.catchCallback=i=>{this.wrapFailure(t,i).next(r,o)}})}toPromise(){return new Promise((e,t)=>{this.next(e,t)})}wrapUserFunction(e){try{const t=e();return t instanceof U?t:U.resolve(t)}catch(t){return U.reject(t)}}wrapSuccess(e,t){return e?this.wrapUserFunction(()=>e(t)):U.resolve(t)}wrapFailure(e,t){return e?this.wrapUserFunction(()=>e(t)):U.reject(t)}static resolve(e){return new U((t,r)=>{t(e)})}static reject(e){return new U((t,r)=>{r(e)})}static waitFor(e){return new U((t,r)=>{let o=0,i=0,s=!1;e.forEach(c=>{++o,c.next(()=>{++i,s&&i===o&&t()},d=>r(d))}),s=!0,i===o&&t()})}static or(e){let t=U.resolve(!1);for(const r of e)t=t.next(o=>o?U.resolve(o):r());return t}static forEach(e,t){const r=[];return e.forEach((o,i)=>{r.push(t.call(this,o,i))}),this.waitFor(r)}static mapArray(e,t){return new U((r,o)=>{const i=e.length,s=new Array(i);let c=0;for(let d=0;d<i;d++){const u=d;t(e[u]).next(f=>{s[u]=f,++c,c===i&&r(s)},f=>o(f))}})}static doWhile(e,t){return new U((r,o)=>{const i=()=>{e()===!0?t().next(()=>{i()},o):r()};i()})}}function tT(n){const e=n.match(/Android ([\d.]+)/i),t=e?e[1].split(".").slice(0,2).join("."):"-1";return Number(t)}function $o(n){return n.name==="IndexedDbTransactionError"}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class tl{constructor(e,t){this.previousValue=e,t&&(t.sequenceNumberHandler=r=>this.ae(r),this.ue=r=>t.writeSequenceNumber(r))}ae(e){return this.previousValue=Math.max(e,this.previousValue),this.previousValue}next(){const e=++this.previousValue;return this.ue&&this.ue(e),e}}tl.ce=-1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const cu=-1;function nl(n){return n==null}function Aa(n){return n===0&&1/n==-1/0}function nT(n){return typeof n=="number"&&Number.isInteger(n)&&!Aa(n)&&n<=Number.MAX_SAFE_INTEGER&&n>=Number.MIN_SAFE_INTEGER}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const hg="";function rT(n){let e="";for(let t=0;t<n.length;t++)e.length>0&&(e=Bh(e)),e=oT(n.get(t),e);return Bh(e)}function oT(n,e){let t=e;const r=n.length;for(let o=0;o<r;o++){const i=n.charAt(o);switch(i){case"\0":t+="";break;case hg:t+="";break;default:t+=i}}return t}function Bh(n){return n+hg+""}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function $h(n){let e=0;for(const t in n)Object.prototype.hasOwnProperty.call(n,t)&&e++;return e}function hr(n,e){for(const t in n)Object.prototype.hasOwnProperty.call(n,t)&&e(t,n[t])}function fg(n){for(const e in n)if(Object.prototype.hasOwnProperty.call(n,e))return!1;return!0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ne{constructor(e,t){this.comparator=e,this.root=t||ot.EMPTY}insert(e,t){return new Ne(this.comparator,this.root.insert(e,t,this.comparator).copy(null,null,ot.BLACK,null,null))}remove(e){return new Ne(this.comparator,this.root.remove(e,this.comparator).copy(null,null,ot.BLACK,null,null))}get(e){let t=this.root;for(;!t.isEmpty();){const r=this.comparator(e,t.key);if(r===0)return t.value;r<0?t=t.left:r>0&&(t=t.right)}return null}indexOf(e){let t=0,r=this.root;for(;!r.isEmpty();){const o=this.comparator(e,r.key);if(o===0)return t+r.left.size;o<0?r=r.left:(t+=r.left.size+1,r=r.right)}return-1}isEmpty(){return this.root.isEmpty()}get size(){return this.root.size}minKey(){return this.root.minKey()}maxKey(){return this.root.maxKey()}inorderTraversal(e){return this.root.inorderTraversal(e)}forEach(e){this.inorderTraversal((t,r)=>(e(t,r),!1))}toString(){const e=[];return this.inorderTraversal((t,r)=>(e.push(`${t}:${r}`),!1)),`{${e.join(", ")}}`}reverseTraversal(e){return this.root.reverseTraversal(e)}getIterator(){return new $s(this.root,null,this.comparator,!1)}getIteratorFrom(e){return new $s(this.root,e,this.comparator,!1)}getReverseIterator(){return new $s(this.root,null,this.comparator,!0)}getReverseIteratorFrom(e){return new $s(this.root,e,this.comparator,!0)}}class $s{constructor(e,t,r,o){this.isReverse=o,this.nodeStack=[];let i=1;for(;!e.isEmpty();)if(i=t?r(e.key,t):1,t&&o&&(i*=-1),i<0)e=this.isReverse?e.left:e.right;else{if(i===0){this.nodeStack.push(e);break}this.nodeStack.push(e),e=this.isReverse?e.right:e.left}}getNext(){let e=this.nodeStack.pop();const t={key:e.key,value:e.value};if(this.isReverse)for(e=e.left;!e.isEmpty();)this.nodeStack.push(e),e=e.right;else for(e=e.right;!e.isEmpty();)this.nodeStack.push(e),e=e.left;return t}hasNext(){return this.nodeStack.length>0}peek(){if(this.nodeStack.length===0)return null;const e=this.nodeStack[this.nodeStack.length-1];return{key:e.key,value:e.value}}}class ot{constructor(e,t,r,o,i){this.key=e,this.value=t,this.color=r??ot.RED,this.left=o??ot.EMPTY,this.right=i??ot.EMPTY,this.size=this.left.size+1+this.right.size}copy(e,t,r,o,i){return new ot(e??this.key,t??this.value,r??this.color,o??this.left,i??this.right)}isEmpty(){return!1}inorderTraversal(e){return this.left.inorderTraversal(e)||e(this.key,this.value)||this.right.inorderTraversal(e)}reverseTraversal(e){return this.right.reverseTraversal(e)||e(this.key,this.value)||this.left.reverseTraversal(e)}min(){return this.left.isEmpty()?this:this.left.min()}minKey(){return this.min().key}maxKey(){return this.right.isEmpty()?this.key:this.right.maxKey()}insert(e,t,r){let o=this;const i=r(e,o.key);return o=i<0?o.copy(null,null,null,o.left.insert(e,t,r),null):i===0?o.copy(null,t,null,null,null):o.copy(null,null,null,null,o.right.insert(e,t,r)),o.fixUp()}removeMin(){if(this.left.isEmpty())return ot.EMPTY;let e=this;return e.left.isRed()||e.left.left.isRed()||(e=e.moveRedLeft()),e=e.copy(null,null,null,e.left.removeMin(),null),e.fixUp()}remove(e,t){let r,o=this;if(t(e,o.key)<0)o.left.isEmpty()||o.left.isRed()||o.left.left.isRed()||(o=o.moveRedLeft()),o=o.copy(null,null,null,o.left.remove(e,t),null);else{if(o.left.isRed()&&(o=o.rotateRight()),o.right.isEmpty()||o.right.isRed()||o.right.left.isRed()||(o=o.moveRedRight()),t(e,o.key)===0){if(o.right.isEmpty())return ot.EMPTY;r=o.right.min(),o=o.copy(r.key,r.value,null,null,o.right.removeMin())}o=o.copy(null,null,null,null,o.right.remove(e,t))}return o.fixUp()}isRed(){return this.color}fixUp(){let e=this;return e.right.isRed()&&!e.left.isRed()&&(e=e.rotateLeft()),e.left.isRed()&&e.left.left.isRed()&&(e=e.rotateRight()),e.left.isRed()&&e.right.isRed()&&(e=e.colorFlip()),e}moveRedLeft(){let e=this.colorFlip();return e.right.left.isRed()&&(e=e.copy(null,null,null,null,e.right.rotateRight()),e=e.rotateLeft(),e=e.colorFlip()),e}moveRedRight(){let e=this.colorFlip();return e.left.left.isRed()&&(e=e.rotateRight(),e=e.colorFlip()),e}rotateLeft(){const e=this.copy(null,null,ot.RED,null,this.right.left);return this.right.copy(null,null,this.color,e,null)}rotateRight(){const e=this.copy(null,null,ot.RED,this.left.right,null);return this.left.copy(null,null,this.color,null,e)}colorFlip(){const e=this.left.copy(null,null,!this.left.color,null,null),t=this.right.copy(null,null,!this.right.color,null,null);return this.copy(null,null,!this.color,e,t)}checkMaxDepth(){const e=this.check();return Math.pow(2,e)<=this.size+1}check(){if(this.isRed()&&this.left.isRed())throw ee(43730,{key:this.key,value:this.value});if(this.right.isRed())throw ee(14113,{key:this.key,value:this.value});const e=this.left.check();if(e!==this.right.check())throw ee(27949);return e+(this.isRed()?0:1)}}ot.EMPTY=null,ot.RED=!0,ot.BLACK=!1;ot.EMPTY=new class{constructor(){this.size=0}get key(){throw ee(57766)}get value(){throw ee(16141)}get color(){throw ee(16727)}get left(){throw ee(29726)}get right(){throw ee(36894)}copy(e,t,r,o,i){return this}insert(e,t,r){return new ot(e,t)}remove(e,t){return this}isEmpty(){return!0}inorderTraversal(e){return!1}reverseTraversal(e){return!1}minKey(){return null}maxKey(){return null}isRed(){return!1}checkMaxDepth(){return!0}check(){return 0}};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Qe{constructor(e){this.comparator=e,this.data=new Ne(this.comparator)}has(e){return this.data.get(e)!==null}first(){return this.data.minKey()}last(){return this.data.maxKey()}get size(){return this.data.size}indexOf(e){return this.data.indexOf(e)}forEach(e){this.data.inorderTraversal((t,r)=>(e(t),!1))}forEachInRange(e,t){const r=this.data.getIteratorFrom(e[0]);for(;r.hasNext();){const o=r.getNext();if(this.comparator(o.key,e[1])>=0)return;t(o.key)}}forEachWhile(e,t){let r;for(r=t!==void 0?this.data.getIteratorFrom(t):this.data.getIterator();r.hasNext();)if(!e(r.getNext().key))return}firstAfterOrEqual(e){const t=this.data.getIteratorFrom(e);return t.hasNext()?t.getNext().key:null}getIterator(){return new jh(this.data.getIterator())}getIteratorFrom(e){return new jh(this.data.getIteratorFrom(e))}add(e){return this.copy(this.data.remove(e).insert(e,!0))}delete(e){return this.has(e)?this.copy(this.data.remove(e)):this}isEmpty(){return this.data.isEmpty()}unionWith(e){let t=this;return t.size<e.size&&(t=e,e=this),e.forEach(r=>{t=t.add(r)}),t}isEqual(e){if(!(e instanceof Qe)||this.size!==e.size)return!1;const t=this.data.getIterator(),r=e.data.getIterator();for(;t.hasNext();){const o=t.getNext().key,i=r.getNext().key;if(this.comparator(o,i)!==0)return!1}return!0}toArray(){const e=[];return this.forEach(t=>{e.push(t)}),e}toString(){const e=[];return this.forEach(t=>e.push(t)),"SortedSet("+e.toString()+")"}copy(e){const t=new Qe(this.comparator);return t.data=e,t}}class jh{constructor(e){this.iter=e}getNext(){return this.iter.getNext().key}hasNext(){return this.iter.hasNext()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Rt{constructor(e){this.fields=e,e.sort(it.comparator)}static empty(){return new Rt([])}unionWith(e){let t=new Qe(it.comparator);for(const r of this.fields)t=t.add(r);for(const r of e)t=t.add(r);return new Rt(t.toArray())}covers(e){for(const t of this.fields)if(t.isPrefixOf(e))return!0;return!1}isEqual(e){return ko(this.fields,e.fields,(t,r)=>t.isEqual(r))}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class pg extends Error{constructor(){super(...arguments),this.name="Base64DecodeError"}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class at{constructor(e){this.binaryString=e}static fromBase64String(e){const t=function(o){try{return atob(o)}catch(i){throw typeof DOMException<"u"&&i instanceof DOMException?new pg("Invalid base64 string: "+i):i}}(e);return new at(t)}static fromUint8Array(e){const t=function(o){let i="";for(let s=0;s<o.length;++s)i+=String.fromCharCode(o[s]);return i}(e);return new at(t)}[Symbol.iterator](){let e=0;return{next:()=>e<this.binaryString.length?{value:this.binaryString.charCodeAt(e++),done:!1}:{value:void 0,done:!0}}}toBase64(){return function(t){return btoa(t)}(this.binaryString)}toUint8Array(){return function(t){const r=new Uint8Array(t.length);for(let o=0;o<t.length;o++)r[o]=t.charCodeAt(o);return r}(this.binaryString)}approximateByteSize(){return 2*this.binaryString.length}compareTo(e){return ce(this.binaryString,e.binaryString)}isEqual(e){return this.binaryString===e.binaryString}}at.EMPTY_BYTE_STRING=new at("");const iT=new RegExp(/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.(\d+))?Z$/);function ir(n){if(we(!!n,39018),typeof n=="string"){let e=0;const t=iT.exec(n);if(we(!!t,46558,{timestamp:n}),t[1]){let o=t[1];o=(o+"000000000").substr(0,9),e=Number(o)}const r=new Date(n);return{seconds:Math.floor(r.getTime()/1e3),nanos:e}}return{seconds:Ve(n.seconds),nanos:Ve(n.nanos)}}function Ve(n){return typeof n=="number"?n:typeof n=="string"?Number(n):0}function sr(n){return typeof n=="string"?at.fromBase64String(n):at.fromUint8Array(n)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const gg="server_timestamp",mg="__type__",yg="__previous_value__",vg="__local_write_time__";function uu(n){var t,r;return((r=(((t=n==null?void 0:n.mapValue)==null?void 0:t.fields)||{})[mg])==null?void 0:r.stringValue)===gg}function rl(n){const e=n.mapValue.fields[yg];return uu(e)?rl(e):e}function Gi(n){const e=ir(n.mapValue.fields[vg].timestampValue);return new Pe(e.seconds,e.nanos)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class sT{constructor(e,t,r,o,i,s,c,d,u,f,g){this.databaseId=e,this.appId=t,this.persistenceKey=r,this.host=o,this.ssl=i,this.forceLongPolling=s,this.autoDetectLongPolling=c,this.longPollingOptions=d,this.useFetchStreams=u,this.isUsingEmulator=f,this.apiKey=g}}const ka="(default)";class Yi{constructor(e,t){this.projectId=e,this.database=t||ka}static empty(){return new Yi("","")}get isDefaultDatabase(){return this.database===ka}isEqual(e){return e instanceof Yi&&e.projectId===this.projectId&&e.database===this.database}}function aT(n,e){if(!Object.prototype.hasOwnProperty.apply(n.options,["projectId"]))throw new H(F.INVALID_ARGUMENT,'"projectId" not provided in firebase.initializeApp.');return new Yi(n.options.projectId,e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const _g="__type__",lT="__max__",js={mapValue:{}},bg="__vector__",Pa="value";function ar(n){return"nullValue"in n?0:"booleanValue"in n?1:"integerValue"in n||"doubleValue"in n?2:"timestampValue"in n?3:"stringValue"in n?5:"bytesValue"in n?6:"referenceValue"in n?7:"geoPointValue"in n?8:"arrayValue"in n?9:"mapValue"in n?uu(n)?4:uT(n)?9007199254740991:cT(n)?10:11:ee(28295,{value:n})}function un(n,e){if(n===e)return!0;const t=ar(n);if(t!==ar(e))return!1;switch(t){case 0:case 9007199254740991:return!0;case 1:return n.booleanValue===e.booleanValue;case 4:return Gi(n).isEqual(Gi(e));case 3:return function(o,i){if(typeof o.timestampValue=="string"&&typeof i.timestampValue=="string"&&o.timestampValue.length===i.timestampValue.length)return o.timestampValue===i.timestampValue;const s=ir(o.timestampValue),c=ir(i.timestampValue);return s.seconds===c.seconds&&s.nanos===c.nanos}(n,e);case 5:return n.stringValue===e.stringValue;case 6:return function(o,i){return sr(o.bytesValue).isEqual(sr(i.bytesValue))}(n,e);case 7:return n.referenceValue===e.referenceValue;case 8:return function(o,i){return Ve(o.geoPointValue.latitude)===Ve(i.geoPointValue.latitude)&&Ve(o.geoPointValue.longitude)===Ve(i.geoPointValue.longitude)}(n,e);case 2:return function(o,i){if("integerValue"in o&&"integerValue"in i)return Ve(o.integerValue)===Ve(i.integerValue);if("doubleValue"in o&&"doubleValue"in i){const s=Ve(o.doubleValue),c=Ve(i.doubleValue);return s===c?Aa(s)===Aa(c):isNaN(s)&&isNaN(c)}return!1}(n,e);case 9:return ko(n.arrayValue.values||[],e.arrayValue.values||[],un);case 10:case 11:return function(o,i){const s=o.mapValue.fields||{},c=i.mapValue.fields||{};if($h(s)!==$h(c))return!1;for(const d in s)if(s.hasOwnProperty(d)&&(c[d]===void 0||!un(s[d],c[d])))return!1;return!0}(n,e);default:return ee(52216,{left:n})}}function Ki(n,e){return(n.values||[]).find(t=>un(t,e))!==void 0}function Po(n,e){if(n===e)return 0;const t=ar(n),r=ar(e);if(t!==r)return ce(t,r);switch(t){case 0:case 9007199254740991:return 0;case 1:return ce(n.booleanValue,e.booleanValue);case 2:return function(i,s){const c=Ve(i.integerValue||i.doubleValue),d=Ve(s.integerValue||s.doubleValue);return c<d?-1:c>d?1:c===d?0:isNaN(c)?isNaN(d)?0:-1:1}(n,e);case 3:return zh(n.timestampValue,e.timestampValue);case 4:return zh(Gi(n),Gi(e));case 5:return pc(n.stringValue,e.stringValue);case 6:return function(i,s){const c=sr(i),d=sr(s);return c.compareTo(d)}(n.bytesValue,e.bytesValue);case 7:return function(i,s){const c=i.split("/"),d=s.split("/");for(let u=0;u<c.length&&u<d.length;u++){const f=ce(c[u],d[u]);if(f!==0)return f}return ce(c.length,d.length)}(n.referenceValue,e.referenceValue);case 8:return function(i,s){const c=ce(Ve(i.latitude),Ve(s.latitude));return c!==0?c:ce(Ve(i.longitude),Ve(s.longitude))}(n.geoPointValue,e.geoPointValue);case 9:return Wh(n.arrayValue,e.arrayValue);case 10:return function(i,s){var m,v,L,P;const c=i.fields||{},d=s.fields||{},u=(m=c[Pa])==null?void 0:m.arrayValue,f=(v=d[Pa])==null?void 0:v.arrayValue,g=ce(((L=u==null?void 0:u.values)==null?void 0:L.length)||0,((P=f==null?void 0:f.values)==null?void 0:P.length)||0);return g!==0?g:Wh(u,f)}(n.mapValue,e.mapValue);case 11:return function(i,s){if(i===js.mapValue&&s===js.mapValue)return 0;if(i===js.mapValue)return 1;if(s===js.mapValue)return-1;const c=i.fields||{},d=Object.keys(c),u=s.fields||{},f=Object.keys(u);d.sort(),f.sort();for(let g=0;g<d.length&&g<f.length;++g){const m=pc(d[g],f[g]);if(m!==0)return m;const v=Po(c[d[g]],u[f[g]]);if(v!==0)return v}return ce(d.length,f.length)}(n.mapValue,e.mapValue);default:throw ee(23264,{he:t})}}function zh(n,e){if(typeof n=="string"&&typeof e=="string"&&n.length===e.length)return ce(n,e);const t=ir(n),r=ir(e),o=ce(t.seconds,r.seconds);return o!==0?o:ce(t.nanos,r.nanos)}function Wh(n,e){const t=n.values||[],r=e.values||[];for(let o=0;o<t.length&&o<r.length;++o){const i=Po(t[o],r[o]);if(i)return i}return ce(t.length,r.length)}function Co(n){return gc(n)}function gc(n){return"nullValue"in n?"null":"booleanValue"in n?""+n.booleanValue:"integerValue"in n?""+n.integerValue:"doubleValue"in n?""+n.doubleValue:"timestampValue"in n?function(t){const r=ir(t);return`time(${r.seconds},${r.nanos})`}(n.timestampValue):"stringValue"in n?n.stringValue:"bytesValue"in n?function(t){return sr(t).toBase64()}(n.bytesValue):"referenceValue"in n?function(t){return Q.fromName(t).toString()}(n.referenceValue):"geoPointValue"in n?function(t){return`geo(${t.latitude},${t.longitude})`}(n.geoPointValue):"arrayValue"in n?function(t){let r="[",o=!0;for(const i of t.values||[])o?o=!1:r+=",",r+=gc(i);return r+"]"}(n.arrayValue):"mapValue"in n?function(t){const r=Object.keys(t.fields||{}).sort();let o="{",i=!0;for(const s of r)i?i=!1:o+=",",o+=`${s}:${gc(t.fields[s])}`;return o+"}"}(n.mapValue):ee(61005,{value:n})}function ca(n){switch(ar(n)){case 0:case 1:return 4;case 2:return 8;case 3:case 8:return 16;case 4:const e=rl(n);return e?16+ca(e):16;case 5:return 2*n.stringValue.length;case 6:return sr(n.bytesValue).approximateByteSize();case 7:return n.referenceValue.length;case 9:return function(r){return(r.values||[]).reduce((o,i)=>o+ca(i),0)}(n.arrayValue);case 10:case 11:return function(r){let o=0;return hr(r.fields,(i,s)=>{o+=i.length+ca(s)}),o}(n.mapValue);default:throw ee(13486,{value:n})}}function Hh(n,e){return{referenceValue:`projects/${n.projectId}/databases/${n.database}/documents/${e.path.canonicalString()}`}}function mc(n){return!!n&&"integerValue"in n}function du(n){return!!n&&"arrayValue"in n}function Gh(n){return!!n&&"nullValue"in n}function Yh(n){return!!n&&"doubleValue"in n&&isNaN(Number(n.doubleValue))}function ua(n){return!!n&&"mapValue"in n}function cT(n){var t,r;return((r=(((t=n==null?void 0:n.mapValue)==null?void 0:t.fields)||{})[_g])==null?void 0:r.stringValue)===bg}function Li(n){if(n.geoPointValue)return{geoPointValue:{...n.geoPointValue}};if(n.timestampValue&&typeof n.timestampValue=="object")return{timestampValue:{...n.timestampValue}};if(n.mapValue){const e={mapValue:{fields:{}}};return hr(n.mapValue.fields,(t,r)=>e.mapValue.fields[t]=Li(r)),e}if(n.arrayValue){const e={arrayValue:{values:[]}};for(let t=0;t<(n.arrayValue.values||[]).length;++t)e.arrayValue.values[t]=Li(n.arrayValue.values[t]);return e}return{...n}}function uT(n){return(((n.mapValue||{}).fields||{}).__type__||{}).stringValue===lT}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class bt{constructor(e){this.value=e}static empty(){return new bt({mapValue:{}})}field(e){if(e.isEmpty())return this.value;{let t=this.value;for(let r=0;r<e.length-1;++r)if(t=(t.mapValue.fields||{})[e.get(r)],!ua(t))return null;return t=(t.mapValue.fields||{})[e.lastSegment()],t||null}}set(e,t){this.getFieldsMap(e.popLast())[e.lastSegment()]=Li(t)}setAll(e){let t=it.emptyPath(),r={},o=[];e.forEach((s,c)=>{if(!t.isImmediateParentOf(c)){const d=this.getFieldsMap(t);this.applyChanges(d,r,o),r={},o=[],t=c.popLast()}s?r[c.lastSegment()]=Li(s):o.push(c.lastSegment())});const i=this.getFieldsMap(t);this.applyChanges(i,r,o)}delete(e){const t=this.field(e.popLast());ua(t)&&t.mapValue.fields&&delete t.mapValue.fields[e.lastSegment()]}isEqual(e){return un(this.value,e.value)}getFieldsMap(e){let t=this.value;t.mapValue.fields||(t.mapValue={fields:{}});for(let r=0;r<e.length;++r){let o=t.mapValue.fields[e.get(r)];ua(o)&&o.mapValue.fields||(o={mapValue:{fields:{}}},t.mapValue.fields[e.get(r)]=o),t=o}return t.mapValue.fields}applyChanges(e,t,r){hr(t,(o,i)=>e[o]=i);for(const o of r)delete e[o]}clone(){return new bt(Li(this.value))}}function wg(n){const e=[];return hr(n.fields,(t,r)=>{const o=new it([t]);if(ua(r)){const i=wg(r.mapValue).fields;if(i.length===0)e.push(o);else for(const s of i)e.push(o.child(s))}else e.push(o)}),new Rt(e)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class dt{constructor(e,t,r,o,i,s,c){this.key=e,this.documentType=t,this.version=r,this.readTime=o,this.createTime=i,this.data=s,this.documentState=c}static newInvalidDocument(e){return new dt(e,0,ne.min(),ne.min(),ne.min(),bt.empty(),0)}static newFoundDocument(e,t,r,o){return new dt(e,1,t,ne.min(),r,o,0)}static newNoDocument(e,t){return new dt(e,2,t,ne.min(),ne.min(),bt.empty(),0)}static newUnknownDocument(e,t){return new dt(e,3,t,ne.min(),ne.min(),bt.empty(),2)}convertToFoundDocument(e,t){return!this.createTime.isEqual(ne.min())||this.documentType!==2&&this.documentType!==0||(this.createTime=e),this.version=e,this.documentType=1,this.data=t,this.documentState=0,this}convertToNoDocument(e){return this.version=e,this.documentType=2,this.data=bt.empty(),this.documentState=0,this}convertToUnknownDocument(e){return this.version=e,this.documentType=3,this.data=bt.empty(),this.documentState=2,this}setHasCommittedMutations(){return this.documentState=2,this}setHasLocalMutations(){return this.documentState=1,this.version=ne.min(),this}setReadTime(e){return this.readTime=e,this}get hasLocalMutations(){return this.documentState===1}get hasCommittedMutations(){return this.documentState===2}get hasPendingWrites(){return this.hasLocalMutations||this.hasCommittedMutations}isValidDocument(){return this.documentType!==0}isFoundDocument(){return this.documentType===1}isNoDocument(){return this.documentType===2}isUnknownDocument(){return this.documentType===3}isEqual(e){return e instanceof dt&&this.key.isEqual(e.key)&&this.version.isEqual(e.version)&&this.documentType===e.documentType&&this.documentState===e.documentState&&this.data.isEqual(e.data)}mutableCopy(){return new dt(this.key,this.documentType,this.version,this.readTime,this.createTime,this.data.clone(),this.documentState)}toString(){return`Document(${this.key}, ${this.version}, ${JSON.stringify(this.data.value)}, {createTime: ${this.createTime}}), {documentType: ${this.documentType}}), {documentState: ${this.documentState}})`}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ca{constructor(e,t){this.position=e,this.inclusive=t}}function Kh(n,e,t){let r=0;for(let o=0;o<n.position.length;o++){const i=e[o],s=n.position[o];if(i.field.isKeyField()?r=Q.comparator(Q.fromName(s.referenceValue),t.key):r=Po(s,t.data.field(i.field)),i.dir==="desc"&&(r*=-1),r!==0)break}return r}function Xh(n,e){if(n===null)return e===null;if(e===null||n.inclusive!==e.inclusive||n.position.length!==e.position.length)return!1;for(let t=0;t<n.position.length;t++)if(!un(n.position[t],e.position[t]))return!1;return!0}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Xi{constructor(e,t="asc"){this.field=e,this.dir=t}}function dT(n,e){return n.dir===e.dir&&n.field.isEqual(e.field)}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Tg{}class ze extends Tg{constructor(e,t,r){super(),this.field=e,this.op=t,this.value=r}static create(e,t,r){return e.isKeyField()?t==="in"||t==="not-in"?this.createKeyFieldInFilter(e,t,r):new fT(e,t,r):t==="array-contains"?new mT(e,r):t==="in"?new yT(e,r):t==="not-in"?new vT(e,r):t==="array-contains-any"?new _T(e,r):new ze(e,t,r)}static createKeyFieldInFilter(e,t,r){return t==="in"?new pT(e,r):new gT(e,r)}matches(e){const t=e.data.field(this.field);return this.op==="!="?t!==null&&t.nullValue===void 0&&this.matchesComparison(Po(t,this.value)):t!==null&&ar(this.value)===ar(t)&&this.matchesComparison(Po(t,this.value))}matchesComparison(e){switch(this.op){case"<":return e<0;case"<=":return e<=0;case"==":return e===0;case"!=":return e!==0;case">":return e>0;case">=":return e>=0;default:return ee(47266,{operator:this.op})}}isInequality(){return["<","<=",">",">=","!=","not-in"].indexOf(this.op)>=0}getFlattenedFilters(){return[this]}getFilters(){return[this]}}class Wt extends Tg{constructor(e,t){super(),this.filters=e,this.op=t,this.Pe=null}static create(e,t){return new Wt(e,t)}matches(e){return Eg(this)?this.filters.find(t=>!t.matches(e))===void 0:this.filters.find(t=>t.matches(e))!==void 0}getFlattenedFilters(){return this.Pe!==null||(this.Pe=this.filters.reduce((e,t)=>e.concat(t.getFlattenedFilters()),[])),this.Pe}getFilters(){return Object.assign([],this.filters)}}function Eg(n){return n.op==="and"}function Ig(n){return hT(n)&&Eg(n)}function hT(n){for(const e of n.filters)if(e instanceof Wt)return!1;return!0}function yc(n){if(n instanceof ze)return n.field.canonicalString()+n.op.toString()+Co(n.value);if(Ig(n))return n.filters.map(e=>yc(e)).join(",");{const e=n.filters.map(t=>yc(t)).join(",");return`${n.op}(${e})`}}function Sg(n,e){return n instanceof ze?function(r,o){return o instanceof ze&&r.op===o.op&&r.field.isEqual(o.field)&&un(r.value,o.value)}(n,e):n instanceof Wt?function(r,o){return o instanceof Wt&&r.op===o.op&&r.filters.length===o.filters.length?r.filters.reduce((i,s,c)=>i&&Sg(s,o.filters[c]),!0):!1}(n,e):void ee(19439)}function xg(n){return n instanceof ze?function(t){return`${t.field.canonicalString()} ${t.op} ${Co(t.value)}`}(n):n instanceof Wt?function(t){return t.op.toString()+" {"+t.getFilters().map(xg).join(" ,")+"}"}(n):"Filter"}class fT extends ze{constructor(e,t,r){super(e,t,r),this.key=Q.fromName(r.referenceValue)}matches(e){const t=Q.comparator(e.key,this.key);return this.matchesComparison(t)}}class pT extends ze{constructor(e,t){super(e,"in",t),this.keys=Ag("in",t)}matches(e){return this.keys.some(t=>t.isEqual(e.key))}}class gT extends ze{constructor(e,t){super(e,"not-in",t),this.keys=Ag("not-in",t)}matches(e){return!this.keys.some(t=>t.isEqual(e.key))}}function Ag(n,e){var t;return(((t=e.arrayValue)==null?void 0:t.values)||[]).map(r=>Q.fromName(r.referenceValue))}class mT extends ze{constructor(e,t){super(e,"array-contains",t)}matches(e){const t=e.data.field(this.field);return du(t)&&Ki(t.arrayValue,this.value)}}class yT extends ze{constructor(e,t){super(e,"in",t)}matches(e){const t=e.data.field(this.field);return t!==null&&Ki(this.value.arrayValue,t)}}class vT extends ze{constructor(e,t){super(e,"not-in",t)}matches(e){if(Ki(this.value.arrayValue,{nullValue:"NULL_VALUE"}))return!1;const t=e.data.field(this.field);return t!==null&&t.nullValue===void 0&&!Ki(this.value.arrayValue,t)}}class _T extends ze{constructor(e,t){super(e,"array-contains-any",t)}matches(e){const t=e.data.field(this.field);return!(!du(t)||!t.arrayValue.values)&&t.arrayValue.values.some(r=>Ki(this.value.arrayValue,r))}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class bT{constructor(e,t=null,r=[],o=[],i=null,s=null,c=null){this.path=e,this.collectionGroup=t,this.orderBy=r,this.filters=o,this.limit=i,this.startAt=s,this.endAt=c,this.Te=null}}function Qh(n,e=null,t=[],r=[],o=null,i=null,s=null){return new bT(n,e,t,r,o,i,s)}function hu(n){const e=re(n);if(e.Te===null){let t=e.path.canonicalString();e.collectionGroup!==null&&(t+="|cg:"+e.collectionGroup),t+="|f:",t+=e.filters.map(r=>yc(r)).join(","),t+="|ob:",t+=e.orderBy.map(r=>function(i){return i.field.canonicalString()+i.dir}(r)).join(","),nl(e.limit)||(t+="|l:",t+=e.limit),e.startAt&&(t+="|lb:",t+=e.startAt.inclusive?"b:":"a:",t+=e.startAt.position.map(r=>Co(r)).join(",")),e.endAt&&(t+="|ub:",t+=e.endAt.inclusive?"a:":"b:",t+=e.endAt.position.map(r=>Co(r)).join(",")),e.Te=t}return e.Te}function fu(n,e){if(n.limit!==e.limit||n.orderBy.length!==e.orderBy.length)return!1;for(let t=0;t<n.orderBy.length;t++)if(!dT(n.orderBy[t],e.orderBy[t]))return!1;if(n.filters.length!==e.filters.length)return!1;for(let t=0;t<n.filters.length;t++)if(!Sg(n.filters[t],e.filters[t]))return!1;return n.collectionGroup===e.collectionGroup&&!!n.path.isEqual(e.path)&&!!Xh(n.startAt,e.startAt)&&Xh(n.endAt,e.endAt)}function vc(n){return Q.isDocumentKey(n.path)&&n.collectionGroup===null&&n.filters.length===0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class jo{constructor(e,t=null,r=[],o=[],i=null,s="F",c=null,d=null){this.path=e,this.collectionGroup=t,this.explicitOrderBy=r,this.filters=o,this.limit=i,this.limitType=s,this.startAt=c,this.endAt=d,this.Ee=null,this.Ie=null,this.Re=null,this.startAt,this.endAt}}function wT(n,e,t,r,o,i,s,c){return new jo(n,e,t,r,o,i,s,c)}function ol(n){return new jo(n)}function Jh(n){return n.filters.length===0&&n.limit===null&&n.startAt==null&&n.endAt==null&&(n.explicitOrderBy.length===0||n.explicitOrderBy.length===1&&n.explicitOrderBy[0].field.isKeyField())}function TT(n){return Q.isDocumentKey(n.path)&&n.collectionGroup===null&&n.filters.length===0}function kg(n){return n.collectionGroup!==null}function Mi(n){const e=re(n);if(e.Ee===null){e.Ee=[];const t=new Set;for(const i of e.explicitOrderBy)e.Ee.push(i),t.add(i.field.canonicalString());const r=e.explicitOrderBy.length>0?e.explicitOrderBy[e.explicitOrderBy.length-1].dir:"asc";(function(s){let c=new Qe(it.comparator);return s.filters.forEach(d=>{d.getFlattenedFilters().forEach(u=>{u.isInequality()&&(c=c.add(u.field))})}),c})(e).forEach(i=>{t.has(i.canonicalString())||i.isKeyField()||e.Ee.push(new Xi(i,r))}),t.has(it.keyField().canonicalString())||e.Ee.push(new Xi(it.keyField(),r))}return e.Ee}function sn(n){const e=re(n);return e.Ie||(e.Ie=ET(e,Mi(n))),e.Ie}function ET(n,e){if(n.limitType==="F")return Qh(n.path,n.collectionGroup,e,n.filters,n.limit,n.startAt,n.endAt);{e=e.map(o=>{const i=o.dir==="desc"?"asc":"desc";return new Xi(o.field,i)});const t=n.endAt?new Ca(n.endAt.position,n.endAt.inclusive):null,r=n.startAt?new Ca(n.startAt.position,n.startAt.inclusive):null;return Qh(n.path,n.collectionGroup,e,n.filters,n.limit,t,r)}}function _c(n,e){const t=n.filters.concat([e]);return new jo(n.path,n.collectionGroup,n.explicitOrderBy.slice(),t,n.limit,n.limitType,n.startAt,n.endAt)}function IT(n,e){const t=n.explicitOrderBy.concat([e]);return new jo(n.path,n.collectionGroup,t,n.filters.slice(),n.limit,n.limitType,n.startAt,n.endAt)}function Ra(n,e,t){return new jo(n.path,n.collectionGroup,n.explicitOrderBy.slice(),n.filters.slice(),e,t,n.startAt,n.endAt)}function il(n,e){return fu(sn(n),sn(e))&&n.limitType===e.limitType}function Pg(n){return`${hu(sn(n))}|lt:${n.limitType}`}function oo(n){return`Query(target=${function(t){let r=t.path.canonicalString();return t.collectionGroup!==null&&(r+=" collectionGroup="+t.collectionGroup),t.filters.length>0&&(r+=`, filters: [${t.filters.map(o=>xg(o)).join(", ")}]`),nl(t.limit)||(r+=", limit: "+t.limit),t.orderBy.length>0&&(r+=`, orderBy: [${t.orderBy.map(o=>function(s){return`${s.field.canonicalString()} (${s.dir})`}(o)).join(", ")}]`),t.startAt&&(r+=", startAt: ",r+=t.startAt.inclusive?"b:":"a:",r+=t.startAt.position.map(o=>Co(o)).join(",")),t.endAt&&(r+=", endAt: ",r+=t.endAt.inclusive?"a:":"b:",r+=t.endAt.position.map(o=>Co(o)).join(",")),`Target(${r})`}(sn(n))}; limitType=${n.limitType})`}function sl(n,e){return e.isFoundDocument()&&function(r,o){const i=o.key.path;return r.collectionGroup!==null?o.key.hasCollectionId(r.collectionGroup)&&r.path.isPrefixOf(i):Q.isDocumentKey(r.path)?r.path.isEqual(i):r.path.isImmediateParentOf(i)}(n,e)&&function(r,o){for(const i of Mi(r))if(!i.field.isKeyField()&&o.data.field(i.field)===null)return!1;return!0}(n,e)&&function(r,o){for(const i of r.filters)if(!i.matches(o))return!1;return!0}(n,e)&&function(r,o){return!(r.startAt&&!function(s,c,d){const u=Kh(s,c,d);return s.inclusive?u<=0:u<0}(r.startAt,Mi(r),o)||r.endAt&&!function(s,c,d){const u=Kh(s,c,d);return s.inclusive?u>=0:u>0}(r.endAt,Mi(r),o))}(n,e)}function ST(n){return n.collectionGroup||(n.path.length%2==1?n.path.lastSegment():n.path.get(n.path.length-2))}function Cg(n){return(e,t)=>{let r=!1;for(const o of Mi(n)){const i=xT(o,e,t);if(i!==0)return i;r=r||o.field.isKeyField()}return 0}}function xT(n,e,t){const r=n.field.isKeyField()?Q.comparator(e.key,t.key):function(i,s,c){const d=s.data.field(i),u=c.data.field(i);return d!==null&&u!==null?Po(d,u):ee(42886)}(n.field,e,t);switch(n.dir){case"asc":return r;case"desc":return-1*r;default:return ee(19790,{direction:n.dir})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Hr{constructor(e,t){this.mapKeyFn=e,this.equalsFn=t,this.inner={},this.innerSize=0}get(e){const t=this.mapKeyFn(e),r=this.inner[t];if(r!==void 0){for(const[o,i]of r)if(this.equalsFn(o,e))return i}}has(e){return this.get(e)!==void 0}set(e,t){const r=this.mapKeyFn(e),o=this.inner[r];if(o===void 0)return this.inner[r]=[[e,t]],void this.innerSize++;for(let i=0;i<o.length;i++)if(this.equalsFn(o[i][0],e))return void(o[i]=[e,t]);o.push([e,t]),this.innerSize++}delete(e){const t=this.mapKeyFn(e),r=this.inner[t];if(r===void 0)return!1;for(let o=0;o<r.length;o++)if(this.equalsFn(r[o][0],e))return r.length===1?delete this.inner[t]:r.splice(o,1),this.innerSize--,!0;return!1}forEach(e){hr(this.inner,(t,r)=>{for(const[o,i]of r)e(o,i)})}isEmpty(){return fg(this.inner)}size(){return this.innerSize}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const AT=new Ne(Q.comparator);function Rn(){return AT}const Rg=new Ne(Q.comparator);function Ei(...n){let e=Rg;for(const t of n)e=e.insert(t.key,t);return e}function Og(n){let e=Rg;return n.forEach((t,r)=>e=e.insert(t,r.overlayedDocument)),e}function Sr(){return Di()}function Ng(){return Di()}function Di(){return new Hr(n=>n.toString(),(n,e)=>n.isEqual(e))}const kT=new Ne(Q.comparator),PT=new Qe(Q.comparator);function ue(...n){let e=PT;for(const t of n)e=e.add(t);return e}const CT=new Qe(ce);function RT(){return CT}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function pu(n,e){if(n.useProto3Json){if(isNaN(e))return{doubleValue:"NaN"};if(e===1/0)return{doubleValue:"Infinity"};if(e===-1/0)return{doubleValue:"-Infinity"}}return{doubleValue:Aa(e)?"-0":e}}function Lg(n){return{integerValue:""+n}}function Mg(n,e){return nT(e)?Lg(e):pu(n,e)}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class al{constructor(){this._=void 0}}function OT(n,e,t){return n instanceof Qi?function(o,i){const s={fields:{[mg]:{stringValue:gg},[vg]:{timestampValue:{seconds:o.seconds,nanos:o.nanoseconds}}}};return i&&uu(i)&&(i=rl(i)),i&&(s.fields[yg]=i),{mapValue:s}}(t,e):n instanceof Ji?Vg(n,e):n instanceof Zi?Fg(n,e):function(o,i){const s=Dg(o,i),c=Zh(s)+Zh(o.Ae);return mc(s)&&mc(o.Ae)?Lg(c):pu(o.serializer,c)}(n,e)}function NT(n,e,t){return n instanceof Ji?Vg(n,e):n instanceof Zi?Fg(n,e):t}function Dg(n,e){return n instanceof es?function(r){return mc(r)||function(i){return!!i&&"doubleValue"in i}(r)}(e)?e:{integerValue:0}:null}class Qi extends al{}class Ji extends al{constructor(e){super(),this.elements=e}}function Vg(n,e){const t=Ug(e);for(const r of n.elements)t.some(o=>un(o,r))||t.push(r);return{arrayValue:{values:t}}}class Zi extends al{constructor(e){super(),this.elements=e}}function Fg(n,e){let t=Ug(e);for(const r of n.elements)t=t.filter(o=>!un(o,r));return{arrayValue:{values:t}}}class es extends al{constructor(e,t){super(),this.serializer=e,this.Ae=t}}function Zh(n){return Ve(n.integerValue||n.doubleValue)}function Ug(n){return du(n)&&n.arrayValue.values?n.arrayValue.values.slice():[]}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class qg{constructor(e,t){this.field=e,this.transform=t}}function LT(n,e){return n.field.isEqual(e.field)&&function(r,o){return r instanceof Ji&&o instanceof Ji||r instanceof Zi&&o instanceof Zi?ko(r.elements,o.elements,un):r instanceof es&&o instanceof es?un(r.Ae,o.Ae):r instanceof Qi&&o instanceof Qi}(n.transform,e.transform)}class MT{constructor(e,t){this.version=e,this.transformResults=t}}class Bt{constructor(e,t){this.updateTime=e,this.exists=t}static none(){return new Bt}static exists(e){return new Bt(void 0,e)}static updateTime(e){return new Bt(e)}get isNone(){return this.updateTime===void 0&&this.exists===void 0}isEqual(e){return this.exists===e.exists&&(this.updateTime?!!e.updateTime&&this.updateTime.isEqual(e.updateTime):!e.updateTime)}}function da(n,e){return n.updateTime!==void 0?e.isFoundDocument()&&e.version.isEqual(n.updateTime):n.exists===void 0||n.exists===e.isFoundDocument()}class ll{}function Bg(n,e){if(!n.hasLocalMutations||e&&e.fields.length===0)return null;if(e===null)return n.isNoDocument()?new gu(n.key,Bt.none()):new ys(n.key,n.data,Bt.none());{const t=n.data,r=bt.empty();let o=new Qe(it.comparator);for(let i of e.fields)if(!o.has(i)){let s=t.field(i);s===null&&i.length>1&&(i=i.popLast(),s=t.field(i)),s===null?r.delete(i):r.set(i,s),o=o.add(i)}return new fr(n.key,r,new Rt(o.toArray()),Bt.none())}}function DT(n,e,t){n instanceof ys?function(o,i,s){const c=o.value.clone(),d=tf(o.fieldTransforms,i,s.transformResults);c.setAll(d),i.convertToFoundDocument(s.version,c).setHasCommittedMutations()}(n,e,t):n instanceof fr?function(o,i,s){if(!da(o.precondition,i))return void i.convertToUnknownDocument(s.version);const c=tf(o.fieldTransforms,i,s.transformResults),d=i.data;d.setAll($g(o)),d.setAll(c),i.convertToFoundDocument(s.version,d).setHasCommittedMutations()}(n,e,t):function(o,i,s){i.convertToNoDocument(s.version).setHasCommittedMutations()}(0,e,t)}function Vi(n,e,t,r){return n instanceof ys?function(i,s,c,d){if(!da(i.precondition,s))return c;const u=i.value.clone(),f=nf(i.fieldTransforms,d,s);return u.setAll(f),s.convertToFoundDocument(s.version,u).setHasLocalMutations(),null}(n,e,t,r):n instanceof fr?function(i,s,c,d){if(!da(i.precondition,s))return c;const u=nf(i.fieldTransforms,d,s),f=s.data;return f.setAll($g(i)),f.setAll(u),s.convertToFoundDocument(s.version,f).setHasLocalMutations(),c===null?null:c.unionWith(i.fieldMask.fields).unionWith(i.fieldTransforms.map(g=>g.field))}(n,e,t,r):function(i,s,c){return da(i.precondition,s)?(s.convertToNoDocument(s.version).setHasLocalMutations(),null):c}(n,e,t)}function VT(n,e){let t=null;for(const r of n.fieldTransforms){const o=e.data.field(r.field),i=Dg(r.transform,o||null);i!=null&&(t===null&&(t=bt.empty()),t.set(r.field,i))}return t||null}function ef(n,e){return n.type===e.type&&!!n.key.isEqual(e.key)&&!!n.precondition.isEqual(e.precondition)&&!!function(r,o){return r===void 0&&o===void 0||!(!r||!o)&&ko(r,o,(i,s)=>LT(i,s))}(n.fieldTransforms,e.fieldTransforms)&&(n.type===0?n.value.isEqual(e.value):n.type!==1||n.data.isEqual(e.data)&&n.fieldMask.isEqual(e.fieldMask))}class ys extends ll{constructor(e,t,r,o=[]){super(),this.key=e,this.value=t,this.precondition=r,this.fieldTransforms=o,this.type=0}getFieldMask(){return null}}class fr extends ll{constructor(e,t,r,o,i=[]){super(),this.key=e,this.data=t,this.fieldMask=r,this.precondition=o,this.fieldTransforms=i,this.type=1}getFieldMask(){return this.fieldMask}}function $g(n){const e=new Map;return n.fieldMask.fields.forEach(t=>{if(!t.isEmpty()){const r=n.data.field(t);e.set(t,r)}}),e}function tf(n,e,t){const r=new Map;we(n.length===t.length,32656,{Ve:t.length,de:n.length});for(let o=0;o<t.length;o++){const i=n[o],s=i.transform,c=e.data.field(i.field);r.set(i.field,NT(s,c,t[o]))}return r}function nf(n,e,t){const r=new Map;for(const o of n){const i=o.transform,s=t.data.field(o.field);r.set(o.field,OT(i,s,e))}return r}class gu extends ll{constructor(e,t){super(),this.key=e,this.precondition=t,this.type=2,this.fieldTransforms=[]}getFieldMask(){return null}}class FT extends ll{constructor(e,t){super(),this.key=e,this.precondition=t,this.type=3,this.fieldTransforms=[]}getFieldMask(){return null}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class UT{constructor(e,t,r,o){this.batchId=e,this.localWriteTime=t,this.baseMutations=r,this.mutations=o}applyToRemoteDocument(e,t){const r=t.mutationResults;for(let o=0;o<this.mutations.length;o++){const i=this.mutations[o];i.key.isEqual(e.key)&&DT(i,e,r[o])}}applyToLocalView(e,t){for(const r of this.baseMutations)r.key.isEqual(e.key)&&(t=Vi(r,e,t,this.localWriteTime));for(const r of this.mutations)r.key.isEqual(e.key)&&(t=Vi(r,e,t,this.localWriteTime));return t}applyToLocalDocumentSet(e,t){const r=Ng();return this.mutations.forEach(o=>{const i=e.get(o.key),s=i.overlayedDocument;let c=this.applyToLocalView(s,i.mutatedFields);c=t.has(o.key)?null:c;const d=Bg(s,c);d!==null&&r.set(o.key,d),s.isValidDocument()||s.convertToNoDocument(ne.min())}),r}keys(){return this.mutations.reduce((e,t)=>e.add(t.key),ue())}isEqual(e){return this.batchId===e.batchId&&ko(this.mutations,e.mutations,(t,r)=>ef(t,r))&&ko(this.baseMutations,e.baseMutations,(t,r)=>ef(t,r))}}class mu{constructor(e,t,r,o){this.batch=e,this.commitVersion=t,this.mutationResults=r,this.docVersions=o}static from(e,t,r){we(e.mutations.length===r.length,58842,{me:e.mutations.length,fe:r.length});let o=function(){return kT}();const i=e.mutations;for(let s=0;s<i.length;s++)o=o.insert(i[s].key,r[s].version);return new mu(e,t,r,o)}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class qT{constructor(e,t){this.largestBatchId=e,this.mutation=t}getKey(){return this.mutation.key}isEqual(e){return e!==null&&this.mutation===e.mutation}toString(){return`Overlay{
      largestBatchId: ${this.largestBatchId},
      mutation: ${this.mutation.toString()}
    }`}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class BT{constructor(e,t){this.count=e,this.unchangedNames=t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var qe,he;function $T(n){switch(n){case F.OK:return ee(64938);case F.CANCELLED:case F.UNKNOWN:case F.DEADLINE_EXCEEDED:case F.RESOURCE_EXHAUSTED:case F.INTERNAL:case F.UNAVAILABLE:case F.UNAUTHENTICATED:return!1;case F.INVALID_ARGUMENT:case F.NOT_FOUND:case F.ALREADY_EXISTS:case F.PERMISSION_DENIED:case F.FAILED_PRECONDITION:case F.ABORTED:case F.OUT_OF_RANGE:case F.UNIMPLEMENTED:case F.DATA_LOSS:return!0;default:return ee(15467,{code:n})}}function jg(n){if(n===void 0)return Cn("GRPC error has no .code"),F.UNKNOWN;switch(n){case qe.OK:return F.OK;case qe.CANCELLED:return F.CANCELLED;case qe.UNKNOWN:return F.UNKNOWN;case qe.DEADLINE_EXCEEDED:return F.DEADLINE_EXCEEDED;case qe.RESOURCE_EXHAUSTED:return F.RESOURCE_EXHAUSTED;case qe.INTERNAL:return F.INTERNAL;case qe.UNAVAILABLE:return F.UNAVAILABLE;case qe.UNAUTHENTICATED:return F.UNAUTHENTICATED;case qe.INVALID_ARGUMENT:return F.INVALID_ARGUMENT;case qe.NOT_FOUND:return F.NOT_FOUND;case qe.ALREADY_EXISTS:return F.ALREADY_EXISTS;case qe.PERMISSION_DENIED:return F.PERMISSION_DENIED;case qe.FAILED_PRECONDITION:return F.FAILED_PRECONDITION;case qe.ABORTED:return F.ABORTED;case qe.OUT_OF_RANGE:return F.OUT_OF_RANGE;case qe.UNIMPLEMENTED:return F.UNIMPLEMENTED;case qe.DATA_LOSS:return F.DATA_LOSS;default:return ee(39323,{code:n})}}(he=qe||(qe={}))[he.OK=0]="OK",he[he.CANCELLED=1]="CANCELLED",he[he.UNKNOWN=2]="UNKNOWN",he[he.INVALID_ARGUMENT=3]="INVALID_ARGUMENT",he[he.DEADLINE_EXCEEDED=4]="DEADLINE_EXCEEDED",he[he.NOT_FOUND=5]="NOT_FOUND",he[he.ALREADY_EXISTS=6]="ALREADY_EXISTS",he[he.PERMISSION_DENIED=7]="PERMISSION_DENIED",he[he.UNAUTHENTICATED=16]="UNAUTHENTICATED",he[he.RESOURCE_EXHAUSTED=8]="RESOURCE_EXHAUSTED",he[he.FAILED_PRECONDITION=9]="FAILED_PRECONDITION",he[he.ABORTED=10]="ABORTED",he[he.OUT_OF_RANGE=11]="OUT_OF_RANGE",he[he.UNIMPLEMENTED=12]="UNIMPLEMENTED",he[he.INTERNAL=13]="INTERNAL",he[he.UNAVAILABLE=14]="UNAVAILABLE",he[he.DATA_LOSS=15]="DATA_LOSS";/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function jT(){return new TextEncoder}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const zT=new Zn([4294967295,4294967295],0);function rf(n){const e=jT().encode(n),t=new ng;return t.update(e),new Uint8Array(t.digest())}function of(n){const e=new DataView(n.buffer),t=e.getUint32(0,!0),r=e.getUint32(4,!0),o=e.getUint32(8,!0),i=e.getUint32(12,!0);return[new Zn([t,r],0),new Zn([o,i],0)]}class yu{constructor(e,t,r){if(this.bitmap=e,this.padding=t,this.hashCount=r,t<0||t>=8)throw new Ii(`Invalid padding: ${t}`);if(r<0)throw new Ii(`Invalid hash count: ${r}`);if(e.length>0&&this.hashCount===0)throw new Ii(`Invalid hash count: ${r}`);if(e.length===0&&t!==0)throw new Ii(`Invalid padding when bitmap length is 0: ${t}`);this.ge=8*e.length-t,this.pe=Zn.fromNumber(this.ge)}ye(e,t,r){let o=e.add(t.multiply(Zn.fromNumber(r)));return o.compare(zT)===1&&(o=new Zn([o.getBits(0),o.getBits(1)],0)),o.modulo(this.pe).toNumber()}we(e){return!!(this.bitmap[Math.floor(e/8)]&1<<e%8)}mightContain(e){if(this.ge===0)return!1;const t=rf(e),[r,o]=of(t);for(let i=0;i<this.hashCount;i++){const s=this.ye(r,o,i);if(!this.we(s))return!1}return!0}static create(e,t,r){const o=e%8==0?0:8-e%8,i=new Uint8Array(Math.ceil(e/8)),s=new yu(i,o,t);return r.forEach(c=>s.insert(c)),s}insert(e){if(this.ge===0)return;const t=rf(e),[r,o]=of(t);for(let i=0;i<this.hashCount;i++){const s=this.ye(r,o,i);this.Se(s)}}Se(e){const t=Math.floor(e/8),r=e%8;this.bitmap[t]|=1<<r}}class Ii extends Error{constructor(){super(...arguments),this.name="BloomFilterError"}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class cl{constructor(e,t,r,o,i){this.snapshotVersion=e,this.targetChanges=t,this.targetMismatches=r,this.documentUpdates=o,this.resolvedLimboDocuments=i}static createSynthesizedRemoteEventForCurrentChange(e,t,r){const o=new Map;return o.set(e,vs.createSynthesizedTargetChangeForCurrentChange(e,t,r)),new cl(ne.min(),o,new Ne(ce),Rn(),ue())}}class vs{constructor(e,t,r,o,i){this.resumeToken=e,this.current=t,this.addedDocuments=r,this.modifiedDocuments=o,this.removedDocuments=i}static createSynthesizedTargetChangeForCurrentChange(e,t,r){return new vs(r,t,ue(),ue(),ue())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ha{constructor(e,t,r,o){this.be=e,this.removedTargetIds=t,this.key=r,this.De=o}}class zg{constructor(e,t){this.targetId=e,this.Ce=t}}class Wg{constructor(e,t,r=at.EMPTY_BYTE_STRING,o=null){this.state=e,this.targetIds=t,this.resumeToken=r,this.cause=o}}class sf{constructor(){this.ve=0,this.Fe=af(),this.Me=at.EMPTY_BYTE_STRING,this.xe=!1,this.Oe=!0}get current(){return this.xe}get resumeToken(){return this.Me}get Ne(){return this.ve!==0}get Be(){return this.Oe}Le(e){e.approximateByteSize()>0&&(this.Oe=!0,this.Me=e)}ke(){let e=ue(),t=ue(),r=ue();return this.Fe.forEach((o,i)=>{switch(i){case 0:e=e.add(o);break;case 2:t=t.add(o);break;case 1:r=r.add(o);break;default:ee(38017,{changeType:i})}}),new vs(this.Me,this.xe,e,t,r)}qe(){this.Oe=!1,this.Fe=af()}Ke(e,t){this.Oe=!0,this.Fe=this.Fe.insert(e,t)}Ue(e){this.Oe=!0,this.Fe=this.Fe.remove(e)}$e(){this.ve+=1}We(){this.ve-=1,we(this.ve>=0,3241,{ve:this.ve})}Qe(){this.Oe=!0,this.xe=!0}}class WT{constructor(e){this.Ge=e,this.ze=new Map,this.je=Rn(),this.Je=zs(),this.He=zs(),this.Ze=new Ne(ce)}Xe(e){for(const t of e.be)e.De&&e.De.isFoundDocument()?this.Ye(t,e.De):this.et(t,e.key,e.De);for(const t of e.removedTargetIds)this.et(t,e.key,e.De)}tt(e){this.forEachTarget(e,t=>{const r=this.nt(t);switch(e.state){case 0:this.rt(t)&&r.Le(e.resumeToken);break;case 1:r.We(),r.Ne||r.qe(),r.Le(e.resumeToken);break;case 2:r.We(),r.Ne||this.removeTarget(t);break;case 3:this.rt(t)&&(r.Qe(),r.Le(e.resumeToken));break;case 4:this.rt(t)&&(this.it(t),r.Le(e.resumeToken));break;default:ee(56790,{state:e.state})}})}forEachTarget(e,t){e.targetIds.length>0?e.targetIds.forEach(t):this.ze.forEach((r,o)=>{this.rt(o)&&t(o)})}st(e){const t=e.targetId,r=e.Ce.count,o=this.ot(t);if(o){const i=o.target;if(vc(i))if(r===0){const s=new Q(i.path);this.et(t,s,dt.newNoDocument(s,ne.min()))}else we(r===1,20013,{expectedCount:r});else{const s=this._t(t);if(s!==r){const c=this.ut(e),d=c?this.ct(c,e,s):1;if(d!==0){this.it(t);const u=d===2?"TargetPurposeExistenceFilterMismatchBloom":"TargetPurposeExistenceFilterMismatch";this.Ze=this.Ze.insert(t,u)}}}}}ut(e){const t=e.Ce.unchangedNames;if(!t||!t.bits)return null;const{bits:{bitmap:r="",padding:o=0},hashCount:i=0}=t;let s,c;try{s=sr(r).toUint8Array()}catch(d){if(d instanceof pg)return Ur("Decoding the base64 bloom filter in existence filter failed ("+d.message+"); ignoring the bloom filter and falling back to full re-query."),null;throw d}try{c=new yu(s,o,i)}catch(d){return Ur(d instanceof Ii?"BloomFilter error: ":"Applying bloom filter failed: ",d),null}return c.ge===0?null:c}ct(e,t,r){return t.Ce.count===r-this.Pt(e,t.targetId)?0:2}Pt(e,t){const r=this.Ge.getRemoteKeysForTarget(t);let o=0;return r.forEach(i=>{const s=this.Ge.ht(),c=`projects/${s.projectId}/databases/${s.database}/documents/${i.path.canonicalString()}`;e.mightContain(c)||(this.et(t,i,null),o++)}),o}Tt(e){const t=new Map;this.ze.forEach((i,s)=>{const c=this.ot(s);if(c){if(i.current&&vc(c.target)){const d=new Q(c.target.path);this.Et(d).has(s)||this.It(s,d)||this.et(s,d,dt.newNoDocument(d,e))}i.Be&&(t.set(s,i.ke()),i.qe())}});let r=ue();this.He.forEach((i,s)=>{let c=!0;s.forEachWhile(d=>{const u=this.ot(d);return!u||u.purpose==="TargetPurposeLimboResolution"||(c=!1,!1)}),c&&(r=r.add(i))}),this.je.forEach((i,s)=>s.setReadTime(e));const o=new cl(e,t,this.Ze,this.je,r);return this.je=Rn(),this.Je=zs(),this.He=zs(),this.Ze=new Ne(ce),o}Ye(e,t){if(!this.rt(e))return;const r=this.It(e,t.key)?2:0;this.nt(e).Ke(t.key,r),this.je=this.je.insert(t.key,t),this.Je=this.Je.insert(t.key,this.Et(t.key).add(e)),this.He=this.He.insert(t.key,this.Rt(t.key).add(e))}et(e,t,r){if(!this.rt(e))return;const o=this.nt(e);this.It(e,t)?o.Ke(t,1):o.Ue(t),this.He=this.He.insert(t,this.Rt(t).delete(e)),this.He=this.He.insert(t,this.Rt(t).add(e)),r&&(this.je=this.je.insert(t,r))}removeTarget(e){this.ze.delete(e)}_t(e){const t=this.nt(e).ke();return this.Ge.getRemoteKeysForTarget(e).size+t.addedDocuments.size-t.removedDocuments.size}$e(e){this.nt(e).$e()}nt(e){let t=this.ze.get(e);return t||(t=new sf,this.ze.set(e,t)),t}Rt(e){let t=this.He.get(e);return t||(t=new Qe(ce),this.He=this.He.insert(e,t)),t}Et(e){let t=this.Je.get(e);return t||(t=new Qe(ce),this.Je=this.Je.insert(e,t)),t}rt(e){const t=this.ot(e)!==null;return t||Y("WatchChangeAggregator","Detected inactive target",e),t}ot(e){const t=this.ze.get(e);return t&&t.Ne?null:this.Ge.At(e)}it(e){this.ze.set(e,new sf),this.Ge.getRemoteKeysForTarget(e).forEach(t=>{this.et(e,t,null)})}It(e,t){return this.Ge.getRemoteKeysForTarget(e).has(t)}}function zs(){return new Ne(Q.comparator)}function af(){return new Ne(Q.comparator)}const HT={asc:"ASCENDING",desc:"DESCENDING"},GT={"<":"LESS_THAN","<=":"LESS_THAN_OR_EQUAL",">":"GREATER_THAN",">=":"GREATER_THAN_OR_EQUAL","==":"EQUAL","!=":"NOT_EQUAL","array-contains":"ARRAY_CONTAINS",in:"IN","not-in":"NOT_IN","array-contains-any":"ARRAY_CONTAINS_ANY"},YT={and:"AND",or:"OR"};class KT{constructor(e,t){this.databaseId=e,this.useProto3Json=t}}function bc(n,e){return n.useProto3Json||nl(e)?e:{value:e}}function Oa(n,e){return n.useProto3Json?`${new Date(1e3*e.seconds).toISOString().replace(/\.\d*/,"").replace("Z","")}.${("000000000"+e.nanoseconds).slice(-9)}Z`:{seconds:""+e.seconds,nanos:e.nanoseconds}}function Hg(n,e){return n.useProto3Json?e.toBase64():e.toUint8Array()}function XT(n,e){return Oa(n,e.toTimestamp())}function an(n){return we(!!n,49232),ne.fromTimestamp(function(t){const r=ir(t);return new Pe(r.seconds,r.nanos)}(n))}function vu(n,e){return wc(n,e).canonicalString()}function wc(n,e){const t=function(o){return new Se(["projects",o.projectId,"databases",o.database])}(n).child("documents");return e===void 0?t:t.child(e)}function Gg(n){const e=Se.fromString(n);return we(Jg(e),10190,{key:e.toString()}),e}function Tc(n,e){return vu(n.databaseId,e.path)}function Wl(n,e){const t=Gg(e);if(t.get(1)!==n.databaseId.projectId)throw new H(F.INVALID_ARGUMENT,"Tried to deserialize key from different project: "+t.get(1)+" vs "+n.databaseId.projectId);if(t.get(3)!==n.databaseId.database)throw new H(F.INVALID_ARGUMENT,"Tried to deserialize key from different database: "+t.get(3)+" vs "+n.databaseId.database);return new Q(Kg(t))}function Yg(n,e){return vu(n.databaseId,e)}function QT(n){const e=Gg(n);return e.length===4?Se.emptyPath():Kg(e)}function Ec(n){return new Se(["projects",n.databaseId.projectId,"databases",n.databaseId.database]).canonicalString()}function Kg(n){return we(n.length>4&&n.get(4)==="documents",29091,{key:n.toString()}),n.popFirst(5)}function lf(n,e,t){return{name:Tc(n,e),fields:t.value.mapValue.fields}}function JT(n,e){let t;if("targetChange"in e){e.targetChange;const r=function(u){return u==="NO_CHANGE"?0:u==="ADD"?1:u==="REMOVE"?2:u==="CURRENT"?3:u==="RESET"?4:ee(39313,{state:u})}(e.targetChange.targetChangeType||"NO_CHANGE"),o=e.targetChange.targetIds||[],i=function(u,f){return u.useProto3Json?(we(f===void 0||typeof f=="string",58123),at.fromBase64String(f||"")):(we(f===void 0||f instanceof Buffer||f instanceof Uint8Array,16193),at.fromUint8Array(f||new Uint8Array))}(n,e.targetChange.resumeToken),s=e.targetChange.cause,c=s&&function(u){const f=u.code===void 0?F.UNKNOWN:jg(u.code);return new H(f,u.message||"")}(s);t=new Wg(r,o,i,c||null)}else if("documentChange"in e){e.documentChange;const r=e.documentChange;r.document,r.document.name,r.document.updateTime;const o=Wl(n,r.document.name),i=an(r.document.updateTime),s=r.document.createTime?an(r.document.createTime):ne.min(),c=new bt({mapValue:{fields:r.document.fields}}),d=dt.newFoundDocument(o,i,s,c),u=r.targetIds||[],f=r.removedTargetIds||[];t=new ha(u,f,d.key,d)}else if("documentDelete"in e){e.documentDelete;const r=e.documentDelete;r.document;const o=Wl(n,r.document),i=r.readTime?an(r.readTime):ne.min(),s=dt.newNoDocument(o,i),c=r.removedTargetIds||[];t=new ha([],c,s.key,s)}else if("documentRemove"in e){e.documentRemove;const r=e.documentRemove;r.document;const o=Wl(n,r.document),i=r.removedTargetIds||[];t=new ha([],i,o,null)}else{if(!("filter"in e))return ee(11601,{Vt:e});{e.filter;const r=e.filter;r.targetId;const{count:o=0,unchangedNames:i}=r,s=new BT(o,i),c=r.targetId;t=new zg(c,s)}}return t}function ZT(n,e){let t;if(e instanceof ys)t={update:lf(n,e.key,e.value)};else if(e instanceof gu)t={delete:Tc(n,e.key)};else if(e instanceof fr)t={update:lf(n,e.key,e.data),updateMask:l0(e.fieldMask)};else{if(!(e instanceof FT))return ee(16599,{dt:e.type});t={verify:Tc(n,e.key)}}return e.fieldTransforms.length>0&&(t.updateTransforms=e.fieldTransforms.map(r=>function(i,s){const c=s.transform;if(c instanceof Qi)return{fieldPath:s.field.canonicalString(),setToServerValue:"REQUEST_TIME"};if(c instanceof Ji)return{fieldPath:s.field.canonicalString(),appendMissingElements:{values:c.elements}};if(c instanceof Zi)return{fieldPath:s.field.canonicalString(),removeAllFromArray:{values:c.elements}};if(c instanceof es)return{fieldPath:s.field.canonicalString(),increment:c.Ae};throw ee(20930,{transform:s.transform})}(0,r))),e.precondition.isNone||(t.currentDocument=function(o,i){return i.updateTime!==void 0?{updateTime:XT(o,i.updateTime)}:i.exists!==void 0?{exists:i.exists}:ee(27497)}(n,e.precondition)),t}function e0(n,e){return n&&n.length>0?(we(e!==void 0,14353),n.map(t=>function(o,i){let s=o.updateTime?an(o.updateTime):an(i);return s.isEqual(ne.min())&&(s=an(i)),new MT(s,o.transformResults||[])}(t,e))):[]}function t0(n,e){return{documents:[Yg(n,e.path)]}}function n0(n,e){const t={structuredQuery:{}},r=e.path;let o;e.collectionGroup!==null?(o=r,t.structuredQuery.from=[{collectionId:e.collectionGroup,allDescendants:!0}]):(o=r.popLast(),t.structuredQuery.from=[{collectionId:r.lastSegment()}]),t.parent=Yg(n,o);const i=function(u){if(u.length!==0)return Qg(Wt.create(u,"and"))}(e.filters);i&&(t.structuredQuery.where=i);const s=function(u){if(u.length!==0)return u.map(f=>function(m){return{field:io(m.field),direction:i0(m.dir)}}(f))}(e.orderBy);s&&(t.structuredQuery.orderBy=s);const c=bc(n,e.limit);return c!==null&&(t.structuredQuery.limit=c),e.startAt&&(t.structuredQuery.startAt=function(u){return{before:u.inclusive,values:u.position}}(e.startAt)),e.endAt&&(t.structuredQuery.endAt=function(u){return{before:!u.inclusive,values:u.position}}(e.endAt)),{ft:t,parent:o}}function r0(n){let e=QT(n.parent);const t=n.structuredQuery,r=t.from?t.from.length:0;let o=null;if(r>0){we(r===1,65062);const f=t.from[0];f.allDescendants?o=f.collectionId:e=e.child(f.collectionId)}let i=[];t.where&&(i=function(g){const m=Xg(g);return m instanceof Wt&&Ig(m)?m.getFilters():[m]}(t.where));let s=[];t.orderBy&&(s=function(g){return g.map(m=>function(L){return new Xi(so(L.field),function(M){switch(M){case"ASCENDING":return"asc";case"DESCENDING":return"desc";default:return}}(L.direction))}(m))}(t.orderBy));let c=null;t.limit&&(c=function(g){let m;return m=typeof g=="object"?g.value:g,nl(m)?null:m}(t.limit));let d=null;t.startAt&&(d=function(g){const m=!!g.before,v=g.values||[];return new Ca(v,m)}(t.startAt));let u=null;return t.endAt&&(u=function(g){const m=!g.before,v=g.values||[];return new Ca(v,m)}(t.endAt)),wT(e,o,s,i,c,"F",d,u)}function o0(n,e){const t=function(o){switch(o){case"TargetPurposeListen":return null;case"TargetPurposeExistenceFilterMismatch":return"existence-filter-mismatch";case"TargetPurposeExistenceFilterMismatchBloom":return"existence-filter-mismatch-bloom";case"TargetPurposeLimboResolution":return"limbo-document";default:return ee(28987,{purpose:o})}}(e.purpose);return t==null?null:{"goog-listen-tags":t}}function Xg(n){return n.unaryFilter!==void 0?function(t){switch(t.unaryFilter.op){case"IS_NAN":const r=so(t.unaryFilter.field);return ze.create(r,"==",{doubleValue:NaN});case"IS_NULL":const o=so(t.unaryFilter.field);return ze.create(o,"==",{nullValue:"NULL_VALUE"});case"IS_NOT_NAN":const i=so(t.unaryFilter.field);return ze.create(i,"!=",{doubleValue:NaN});case"IS_NOT_NULL":const s=so(t.unaryFilter.field);return ze.create(s,"!=",{nullValue:"NULL_VALUE"});case"OPERATOR_UNSPECIFIED":return ee(61313);default:return ee(60726)}}(n):n.fieldFilter!==void 0?function(t){return ze.create(so(t.fieldFilter.field),function(o){switch(o){case"EQUAL":return"==";case"NOT_EQUAL":return"!=";case"GREATER_THAN":return">";case"GREATER_THAN_OR_EQUAL":return">=";case"LESS_THAN":return"<";case"LESS_THAN_OR_EQUAL":return"<=";case"ARRAY_CONTAINS":return"array-contains";case"IN":return"in";case"NOT_IN":return"not-in";case"ARRAY_CONTAINS_ANY":return"array-contains-any";case"OPERATOR_UNSPECIFIED":return ee(58110);default:return ee(50506)}}(t.fieldFilter.op),t.fieldFilter.value)}(n):n.compositeFilter!==void 0?function(t){return Wt.create(t.compositeFilter.filters.map(r=>Xg(r)),function(o){switch(o){case"AND":return"and";case"OR":return"or";default:return ee(1026)}}(t.compositeFilter.op))}(n):ee(30097,{filter:n})}function i0(n){return HT[n]}function s0(n){return GT[n]}function a0(n){return YT[n]}function io(n){return{fieldPath:n.canonicalString()}}function so(n){return it.fromServerFormat(n.fieldPath)}function Qg(n){return n instanceof ze?function(t){if(t.op==="=="){if(Yh(t.value))return{unaryFilter:{field:io(t.field),op:"IS_NAN"}};if(Gh(t.value))return{unaryFilter:{field:io(t.field),op:"IS_NULL"}}}else if(t.op==="!="){if(Yh(t.value))return{unaryFilter:{field:io(t.field),op:"IS_NOT_NAN"}};if(Gh(t.value))return{unaryFilter:{field:io(t.field),op:"IS_NOT_NULL"}}}return{fieldFilter:{field:io(t.field),op:s0(t.op),value:t.value}}}(n):n instanceof Wt?function(t){const r=t.getFilters().map(o=>Qg(o));return r.length===1?r[0]:{compositeFilter:{op:a0(t.op),filters:r}}}(n):ee(54877,{filter:n})}function l0(n){const e=[];return n.fields.forEach(t=>e.push(t.canonicalString())),{fieldPaths:e}}function Jg(n){return n.length>=4&&n.get(0)==="projects"&&n.get(2)==="databases"}function Zg(n){return!!n&&typeof n._toProto=="function"&&n._protoValueType==="ProtoValue"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Yn{constructor(e,t,r,o,i=ne.min(),s=ne.min(),c=at.EMPTY_BYTE_STRING,d=null){this.target=e,this.targetId=t,this.purpose=r,this.sequenceNumber=o,this.snapshotVersion=i,this.lastLimboFreeSnapshotVersion=s,this.resumeToken=c,this.expectedCount=d}withSequenceNumber(e){return new Yn(this.target,this.targetId,this.purpose,e,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,this.expectedCount)}withResumeToken(e,t){return new Yn(this.target,this.targetId,this.purpose,this.sequenceNumber,t,this.lastLimboFreeSnapshotVersion,e,null)}withExpectedCount(e){return new Yn(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,e)}withLastLimboFreeSnapshotVersion(e){return new Yn(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,e,this.resumeToken,this.expectedCount)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class c0{constructor(e){this.yt=e}}function u0(n){const e=r0({parent:n.parent,structuredQuery:n.structuredQuery});return n.limitType==="LAST"?Ra(e,e.limit,"L"):e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class d0{constructor(){this.bn=new h0}addToCollectionParentIndex(e,t){return this.bn.add(t),U.resolve()}getCollectionParents(e,t){return U.resolve(this.bn.getEntries(t))}addFieldIndex(e,t){return U.resolve()}deleteFieldIndex(e,t){return U.resolve()}deleteAllFieldIndexes(e){return U.resolve()}createTargetIndexes(e,t){return U.resolve()}getDocumentsMatchingTarget(e,t){return U.resolve(null)}getIndexType(e,t){return U.resolve(0)}getFieldIndexes(e,t){return U.resolve([])}getNextCollectionGroupToUpdate(e){return U.resolve(null)}getMinOffset(e,t){return U.resolve(or.min())}getMinOffsetFromCollectionGroup(e,t){return U.resolve(or.min())}updateCollectionGroup(e,t,r){return U.resolve()}updateIndexEntries(e,t){return U.resolve()}}class h0{constructor(){this.index={}}add(e){const t=e.lastSegment(),r=e.popLast(),o=this.index[t]||new Qe(Se.comparator),i=!o.has(r);return this.index[t]=o.add(r),i}has(e){const t=e.lastSegment(),r=e.popLast(),o=this.index[t];return o&&o.has(r)}getEntries(e){return(this.index[e]||new Qe(Se.comparator)).toArray()}}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const cf={didRun:!1,sequenceNumbersCollected:0,targetsRemoved:0,documentsRemoved:0},em=41943040;class vt{static withCacheSize(e){return new vt(e,vt.DEFAULT_COLLECTION_PERCENTILE,vt.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT)}constructor(e,t,r){this.cacheSizeCollectionThreshold=e,this.percentileToCollect=t,this.maximumSequenceNumbersToCollect=r}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */vt.DEFAULT_COLLECTION_PERCENTILE=10,vt.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT=1e3,vt.DEFAULT=new vt(em,vt.DEFAULT_COLLECTION_PERCENTILE,vt.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT),vt.DISABLED=new vt(-1,0,0);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ro{constructor(e){this.sr=e}next(){return this.sr+=2,this.sr}static _r(){return new Ro(0)}static ar(){return new Ro(-1)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const uf="LruGarbageCollector",f0=1048576;function df([n,e],[t,r]){const o=ce(n,t);return o===0?ce(e,r):o}class p0{constructor(e){this.Pr=e,this.buffer=new Qe(df),this.Tr=0}Er(){return++this.Tr}Ir(e){const t=[e,this.Er()];if(this.buffer.size<this.Pr)this.buffer=this.buffer.add(t);else{const r=this.buffer.last();df(t,r)<0&&(this.buffer=this.buffer.delete(r).add(t))}}get maxValue(){return this.buffer.last()[0]}}class g0{constructor(e,t,r){this.garbageCollector=e,this.asyncQueue=t,this.localStore=r,this.Rr=null}start(){this.garbageCollector.params.cacheSizeCollectionThreshold!==-1&&this.Ar(6e4)}stop(){this.Rr&&(this.Rr.cancel(),this.Rr=null)}get started(){return this.Rr!==null}Ar(e){Y(uf,`Garbage collection scheduled in ${e}ms`),this.Rr=this.asyncQueue.enqueueAfterDelay("lru_garbage_collection",e,async()=>{this.Rr=null;try{await this.localStore.collectGarbage(this.garbageCollector)}catch(t){$o(t)?Y(uf,"Ignoring IndexedDB error during garbage collection: ",t):await Bo(t)}await this.Ar(3e5)})}}class m0{constructor(e,t){this.Vr=e,this.params=t}calculateTargetCount(e,t){return this.Vr.dr(e).next(r=>Math.floor(t/100*r))}nthSequenceNumber(e,t){if(t===0)return U.resolve(tl.ce);const r=new p0(t);return this.Vr.forEachTarget(e,o=>r.Ir(o.sequenceNumber)).next(()=>this.Vr.mr(e,o=>r.Ir(o))).next(()=>r.maxValue)}removeTargets(e,t,r){return this.Vr.removeTargets(e,t,r)}removeOrphanedDocuments(e,t){return this.Vr.removeOrphanedDocuments(e,t)}collect(e,t){return this.params.cacheSizeCollectionThreshold===-1?(Y("LruGarbageCollector","Garbage collection skipped; disabled"),U.resolve(cf)):this.getCacheSize(e).next(r=>r<this.params.cacheSizeCollectionThreshold?(Y("LruGarbageCollector",`Garbage collection skipped; Cache size ${r} is lower than threshold ${this.params.cacheSizeCollectionThreshold}`),cf):this.gr(e,t))}getCacheSize(e){return this.Vr.getCacheSize(e)}gr(e,t){let r,o,i,s,c,d,u;const f=Date.now();return this.calculateTargetCount(e,this.params.percentileToCollect).next(g=>(g>this.params.maximumSequenceNumbersToCollect?(Y("LruGarbageCollector",`Capping sequence numbers to collect down to the maximum of ${this.params.maximumSequenceNumbersToCollect} from ${g}`),o=this.params.maximumSequenceNumbersToCollect):o=g,s=Date.now(),this.nthSequenceNumber(e,o))).next(g=>(r=g,c=Date.now(),this.removeTargets(e,r,t))).next(g=>(i=g,d=Date.now(),this.removeOrphanedDocuments(e,r))).next(g=>(u=Date.now(),ro()<=le.DEBUG&&Y("LruGarbageCollector",`LRU Garbage Collection
	Counted targets in ${s-f}ms
	Determined least recently used ${o} in `+(c-s)+`ms
	Removed ${i} targets in `+(d-c)+`ms
	Removed ${g} documents in `+(u-d)+`ms
Total Duration: ${u-f}ms`),U.resolve({didRun:!0,sequenceNumbersCollected:o,targetsRemoved:i,documentsRemoved:g})))}}function y0(n,e){return new m0(n,e)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class v0{constructor(){this.changes=new Hr(e=>e.toString(),(e,t)=>e.isEqual(t)),this.changesApplied=!1}addEntry(e){this.assertNotApplied(),this.changes.set(e.key,e)}removeEntry(e,t){this.assertNotApplied(),this.changes.set(e,dt.newInvalidDocument(e).setReadTime(t))}getEntry(e,t){this.assertNotApplied();const r=this.changes.get(t);return r!==void 0?U.resolve(r):this.getFromCache(e,t)}getEntries(e,t){return this.getAllFromCache(e,t)}apply(e){return this.assertNotApplied(),this.changesApplied=!0,this.applyChanges(e)}assertNotApplied(){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _0{constructor(e,t){this.overlayedDocument=e,this.mutatedFields=t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class b0{constructor(e,t,r,o){this.remoteDocumentCache=e,this.mutationQueue=t,this.documentOverlayCache=r,this.indexManager=o}getDocument(e,t){let r=null;return this.documentOverlayCache.getOverlay(e,t).next(o=>(r=o,this.remoteDocumentCache.getEntry(e,t))).next(o=>(r!==null&&Vi(r.mutation,o,Rt.empty(),Pe.now()),o))}getDocuments(e,t){return this.remoteDocumentCache.getEntries(e,t).next(r=>this.getLocalViewOfDocuments(e,r,ue()).next(()=>r))}getLocalViewOfDocuments(e,t,r=ue()){const o=Sr();return this.populateOverlays(e,o,t).next(()=>this.computeViews(e,t,o,r).next(i=>{let s=Ei();return i.forEach((c,d)=>{s=s.insert(c,d.overlayedDocument)}),s}))}getOverlayedDocuments(e,t){const r=Sr();return this.populateOverlays(e,r,t).next(()=>this.computeViews(e,t,r,ue()))}populateOverlays(e,t,r){const o=[];return r.forEach(i=>{t.has(i)||o.push(i)}),this.documentOverlayCache.getOverlays(e,o).next(i=>{i.forEach((s,c)=>{t.set(s,c)})})}computeViews(e,t,r,o){let i=Rn();const s=Di(),c=function(){return Di()}();return t.forEach((d,u)=>{const f=r.get(u.key);o.has(u.key)&&(f===void 0||f.mutation instanceof fr)?i=i.insert(u.key,u):f!==void 0?(s.set(u.key,f.mutation.getFieldMask()),Vi(f.mutation,u,f.mutation.getFieldMask(),Pe.now())):s.set(u.key,Rt.empty())}),this.recalculateAndSaveOverlays(e,i).next(d=>(d.forEach((u,f)=>s.set(u,f)),t.forEach((u,f)=>c.set(u,new _0(f,s.get(u)??null))),c))}recalculateAndSaveOverlays(e,t){const r=Di();let o=new Ne((s,c)=>s-c),i=ue();return this.mutationQueue.getAllMutationBatchesAffectingDocumentKeys(e,t).next(s=>{for(const c of s)c.keys().forEach(d=>{const u=t.get(d);if(u===null)return;let f=r.get(d)||Rt.empty();f=c.applyToLocalView(u,f),r.set(d,f);const g=(o.get(c.batchId)||ue()).add(d);o=o.insert(c.batchId,g)})}).next(()=>{const s=[],c=o.getReverseIterator();for(;c.hasNext();){const d=c.getNext(),u=d.key,f=d.value,g=Ng();f.forEach(m=>{if(!i.has(m)){const v=Bg(t.get(m),r.get(m));v!==null&&g.set(m,v),i=i.add(m)}}),s.push(this.documentOverlayCache.saveOverlays(e,u,g))}return U.waitFor(s)}).next(()=>r)}recalculateAndSaveOverlaysForDocumentKeys(e,t){return this.remoteDocumentCache.getEntries(e,t).next(r=>this.recalculateAndSaveOverlays(e,r))}getDocumentsMatchingQuery(e,t,r,o){return TT(t)?this.getDocumentsMatchingDocumentQuery(e,t.path):kg(t)?this.getDocumentsMatchingCollectionGroupQuery(e,t,r,o):this.getDocumentsMatchingCollectionQuery(e,t,r,o)}getNextDocuments(e,t,r,o){return this.remoteDocumentCache.getAllFromCollectionGroup(e,t,r,o).next(i=>{const s=o-i.size>0?this.documentOverlayCache.getOverlaysForCollectionGroup(e,t,r.largestBatchId,o-i.size):U.resolve(Sr());let c=Hi,d=i;return s.next(u=>U.forEach(u,(f,g)=>(c<g.largestBatchId&&(c=g.largestBatchId),i.get(f)?U.resolve():this.remoteDocumentCache.getEntry(e,f).next(m=>{d=d.insert(f,m)}))).next(()=>this.populateOverlays(e,u,i)).next(()=>this.computeViews(e,d,u,ue())).next(f=>({batchId:c,changes:Og(f)})))})}getDocumentsMatchingDocumentQuery(e,t){return this.getDocument(e,new Q(t)).next(r=>{let o=Ei();return r.isFoundDocument()&&(o=o.insert(r.key,r)),o})}getDocumentsMatchingCollectionGroupQuery(e,t,r,o){const i=t.collectionGroup;let s=Ei();return this.indexManager.getCollectionParents(e,i).next(c=>U.forEach(c,d=>{const u=function(g,m){return new jo(m,null,g.explicitOrderBy.slice(),g.filters.slice(),g.limit,g.limitType,g.startAt,g.endAt)}(t,d.child(i));return this.getDocumentsMatchingCollectionQuery(e,u,r,o).next(f=>{f.forEach((g,m)=>{s=s.insert(g,m)})})}).next(()=>s))}getDocumentsMatchingCollectionQuery(e,t,r,o){let i;return this.documentOverlayCache.getOverlaysForCollection(e,t.path,r.largestBatchId).next(s=>(i=s,this.remoteDocumentCache.getDocumentsMatchingQuery(e,t,r,i,o))).next(s=>{i.forEach((d,u)=>{const f=u.getKey();s.get(f)===null&&(s=s.insert(f,dt.newInvalidDocument(f)))});let c=Ei();return s.forEach((d,u)=>{const f=i.get(d);f!==void 0&&Vi(f.mutation,u,Rt.empty(),Pe.now()),sl(t,u)&&(c=c.insert(d,u))}),c})}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class w0{constructor(e){this.serializer=e,this.Nr=new Map,this.Br=new Map}getBundleMetadata(e,t){return U.resolve(this.Nr.get(t))}saveBundleMetadata(e,t){return this.Nr.set(t.id,function(o){return{id:o.id,version:o.version,createTime:an(o.createTime)}}(t)),U.resolve()}getNamedQuery(e,t){return U.resolve(this.Br.get(t))}saveNamedQuery(e,t){return this.Br.set(t.name,function(o){return{name:o.name,query:u0(o.bundledQuery),readTime:an(o.readTime)}}(t)),U.resolve()}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class T0{constructor(){this.overlays=new Ne(Q.comparator),this.Lr=new Map}getOverlay(e,t){return U.resolve(this.overlays.get(t))}getOverlays(e,t){const r=Sr();return U.forEach(t,o=>this.getOverlay(e,o).next(i=>{i!==null&&r.set(o,i)})).next(()=>r)}saveOverlays(e,t,r){return r.forEach((o,i)=>{this.St(e,t,i)}),U.resolve()}removeOverlaysForBatchId(e,t,r){const o=this.Lr.get(r);return o!==void 0&&(o.forEach(i=>this.overlays=this.overlays.remove(i)),this.Lr.delete(r)),U.resolve()}getOverlaysForCollection(e,t,r){const o=Sr(),i=t.length+1,s=new Q(t.child("")),c=this.overlays.getIteratorFrom(s);for(;c.hasNext();){const d=c.getNext().value,u=d.getKey();if(!t.isPrefixOf(u.path))break;u.path.length===i&&d.largestBatchId>r&&o.set(d.getKey(),d)}return U.resolve(o)}getOverlaysForCollectionGroup(e,t,r,o){let i=new Ne((u,f)=>u-f);const s=this.overlays.getIterator();for(;s.hasNext();){const u=s.getNext().value;if(u.getKey().getCollectionGroup()===t&&u.largestBatchId>r){let f=i.get(u.largestBatchId);f===null&&(f=Sr(),i=i.insert(u.largestBatchId,f)),f.set(u.getKey(),u)}}const c=Sr(),d=i.getIterator();for(;d.hasNext()&&(d.getNext().value.forEach((u,f)=>c.set(u,f)),!(c.size()>=o)););return U.resolve(c)}St(e,t,r){const o=this.overlays.get(r.key);if(o!==null){const s=this.Lr.get(o.largestBatchId).delete(r.key);this.Lr.set(o.largestBatchId,s)}this.overlays=this.overlays.insert(r.key,new qT(t,r));let i=this.Lr.get(t);i===void 0&&(i=ue(),this.Lr.set(t,i)),this.Lr.set(t,i.add(r.key))}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class E0{constructor(){this.sessionToken=at.EMPTY_BYTE_STRING}getSessionToken(e){return U.resolve(this.sessionToken)}setSessionToken(e,t){return this.sessionToken=t,U.resolve()}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _u{constructor(){this.kr=new Qe(nt.qr),this.Kr=new Qe(nt.Ur)}isEmpty(){return this.kr.isEmpty()}addReference(e,t){const r=new nt(e,t);this.kr=this.kr.add(r),this.Kr=this.Kr.add(r)}$r(e,t){e.forEach(r=>this.addReference(r,t))}removeReference(e,t){this.Wr(new nt(e,t))}Qr(e,t){e.forEach(r=>this.removeReference(r,t))}Gr(e){const t=new Q(new Se([])),r=new nt(t,e),o=new nt(t,e+1),i=[];return this.Kr.forEachInRange([r,o],s=>{this.Wr(s),i.push(s.key)}),i}zr(){this.kr.forEach(e=>this.Wr(e))}Wr(e){this.kr=this.kr.delete(e),this.Kr=this.Kr.delete(e)}jr(e){const t=new Q(new Se([])),r=new nt(t,e),o=new nt(t,e+1);let i=ue();return this.Kr.forEachInRange([r,o],s=>{i=i.add(s.key)}),i}containsKey(e){const t=new nt(e,0),r=this.kr.firstAfterOrEqual(t);return r!==null&&e.isEqual(r.key)}}class nt{constructor(e,t){this.key=e,this.Jr=t}static qr(e,t){return Q.comparator(e.key,t.key)||ce(e.Jr,t.Jr)}static Ur(e,t){return ce(e.Jr,t.Jr)||Q.comparator(e.key,t.key)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class I0{constructor(e,t){this.indexManager=e,this.referenceDelegate=t,this.mutationQueue=[],this.Yn=1,this.Hr=new Qe(nt.qr)}checkEmpty(e){return U.resolve(this.mutationQueue.length===0)}addMutationBatch(e,t,r,o){const i=this.Yn;this.Yn++,this.mutationQueue.length>0&&this.mutationQueue[this.mutationQueue.length-1];const s=new UT(i,t,r,o);this.mutationQueue.push(s);for(const c of o)this.Hr=this.Hr.add(new nt(c.key,i)),this.indexManager.addToCollectionParentIndex(e,c.key.path.popLast());return U.resolve(s)}lookupMutationBatch(e,t){return U.resolve(this.Zr(t))}getNextMutationBatchAfterBatchId(e,t){const r=t+1,o=this.Xr(r),i=o<0?0:o;return U.resolve(this.mutationQueue.length>i?this.mutationQueue[i]:null)}getHighestUnacknowledgedBatchId(){return U.resolve(this.mutationQueue.length===0?cu:this.Yn-1)}getAllMutationBatches(e){return U.resolve(this.mutationQueue.slice())}getAllMutationBatchesAffectingDocumentKey(e,t){const r=new nt(t,0),o=new nt(t,Number.POSITIVE_INFINITY),i=[];return this.Hr.forEachInRange([r,o],s=>{const c=this.Zr(s.Jr);i.push(c)}),U.resolve(i)}getAllMutationBatchesAffectingDocumentKeys(e,t){let r=new Qe(ce);return t.forEach(o=>{const i=new nt(o,0),s=new nt(o,Number.POSITIVE_INFINITY);this.Hr.forEachInRange([i,s],c=>{r=r.add(c.Jr)})}),U.resolve(this.Yr(r))}getAllMutationBatchesAffectingQuery(e,t){const r=t.path,o=r.length+1;let i=r;Q.isDocumentKey(i)||(i=i.child(""));const s=new nt(new Q(i),0);let c=new Qe(ce);return this.Hr.forEachWhile(d=>{const u=d.key.path;return!!r.isPrefixOf(u)&&(u.length===o&&(c=c.add(d.Jr)),!0)},s),U.resolve(this.Yr(c))}Yr(e){const t=[];return e.forEach(r=>{const o=this.Zr(r);o!==null&&t.push(o)}),t}removeMutationBatch(e,t){we(this.ei(t.batchId,"removed")===0,55003),this.mutationQueue.shift();let r=this.Hr;return U.forEach(t.mutations,o=>{const i=new nt(o.key,t.batchId);return r=r.delete(i),this.referenceDelegate.markPotentiallyOrphaned(e,o.key)}).next(()=>{this.Hr=r})}nr(e){}containsKey(e,t){const r=new nt(t,0),o=this.Hr.firstAfterOrEqual(r);return U.resolve(t.isEqual(o&&o.key))}performConsistencyCheck(e){return this.mutationQueue.length,U.resolve()}ei(e,t){return this.Xr(e)}Xr(e){return this.mutationQueue.length===0?0:e-this.mutationQueue[0].batchId}Zr(e){const t=this.Xr(e);return t<0||t>=this.mutationQueue.length?null:this.mutationQueue[t]}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class S0{constructor(e){this.ti=e,this.docs=function(){return new Ne(Q.comparator)}(),this.size=0}setIndexManager(e){this.indexManager=e}addEntry(e,t){const r=t.key,o=this.docs.get(r),i=o?o.size:0,s=this.ti(t);return this.docs=this.docs.insert(r,{document:t.mutableCopy(),size:s}),this.size+=s-i,this.indexManager.addToCollectionParentIndex(e,r.path.popLast())}removeEntry(e){const t=this.docs.get(e);t&&(this.docs=this.docs.remove(e),this.size-=t.size)}getEntry(e,t){const r=this.docs.get(t);return U.resolve(r?r.document.mutableCopy():dt.newInvalidDocument(t))}getEntries(e,t){let r=Rn();return t.forEach(o=>{const i=this.docs.get(o);r=r.insert(o,i?i.document.mutableCopy():dt.newInvalidDocument(o))}),U.resolve(r)}getDocumentsMatchingQuery(e,t,r,o){let i=Rn();const s=t.path,c=new Q(s.child("__id-9223372036854775808__")),d=this.docs.getIteratorFrom(c);for(;d.hasNext();){const{key:u,value:{document:f}}=d.getNext();if(!s.isPrefixOf(u.path))break;u.path.length>s.length+1||Jw(Qw(f),r)<=0||(o.has(f.key)||sl(t,f))&&(i=i.insert(f.key,f.mutableCopy()))}return U.resolve(i)}getAllFromCollectionGroup(e,t,r,o){ee(9500)}ni(e,t){return U.forEach(this.docs,r=>t(r))}newChangeBuffer(e){return new x0(this)}getSize(e){return U.resolve(this.size)}}class x0 extends v0{constructor(e){super(),this.Mr=e}applyChanges(e){const t=[];return this.changes.forEach((r,o)=>{o.isValidDocument()?t.push(this.Mr.addEntry(e,o)):this.Mr.removeEntry(r)}),U.waitFor(t)}getFromCache(e,t){return this.Mr.getEntry(e,t)}getAllFromCache(e,t){return this.Mr.getEntries(e,t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class A0{constructor(e){this.persistence=e,this.ri=new Hr(t=>hu(t),fu),this.lastRemoteSnapshotVersion=ne.min(),this.highestTargetId=0,this.ii=0,this.si=new _u,this.targetCount=0,this.oi=Ro._r()}forEachTarget(e,t){return this.ri.forEach((r,o)=>t(o)),U.resolve()}getLastRemoteSnapshotVersion(e){return U.resolve(this.lastRemoteSnapshotVersion)}getHighestSequenceNumber(e){return U.resolve(this.ii)}allocateTargetId(e){return this.highestTargetId=this.oi.next(),U.resolve(this.highestTargetId)}setTargetsMetadata(e,t,r){return r&&(this.lastRemoteSnapshotVersion=r),t>this.ii&&(this.ii=t),U.resolve()}lr(e){this.ri.set(e.target,e);const t=e.targetId;t>this.highestTargetId&&(this.oi=new Ro(t),this.highestTargetId=t),e.sequenceNumber>this.ii&&(this.ii=e.sequenceNumber)}addTargetData(e,t){return this.lr(t),this.targetCount+=1,U.resolve()}updateTargetData(e,t){return this.lr(t),U.resolve()}removeTargetData(e,t){return this.ri.delete(t.target),this.si.Gr(t.targetId),this.targetCount-=1,U.resolve()}removeTargets(e,t,r){let o=0;const i=[];return this.ri.forEach((s,c)=>{c.sequenceNumber<=t&&r.get(c.targetId)===null&&(this.ri.delete(s),i.push(this.removeMatchingKeysForTargetId(e,c.targetId)),o++)}),U.waitFor(i).next(()=>o)}getTargetCount(e){return U.resolve(this.targetCount)}getTargetData(e,t){const r=this.ri.get(t)||null;return U.resolve(r)}addMatchingKeys(e,t,r){return this.si.$r(t,r),U.resolve()}removeMatchingKeys(e,t,r){this.si.Qr(t,r);const o=this.persistence.referenceDelegate,i=[];return o&&t.forEach(s=>{i.push(o.markPotentiallyOrphaned(e,s))}),U.waitFor(i)}removeMatchingKeysForTargetId(e,t){return this.si.Gr(t),U.resolve()}getMatchingKeysForTargetId(e,t){const r=this.si.jr(t);return U.resolve(r)}containsKey(e,t){return U.resolve(this.si.containsKey(t))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class tm{constructor(e,t){this._i={},this.overlays={},this.ai=new tl(0),this.ui=!1,this.ui=!0,this.ci=new E0,this.referenceDelegate=e(this),this.li=new A0(this),this.indexManager=new d0,this.remoteDocumentCache=function(o){return new S0(o)}(r=>this.referenceDelegate.hi(r)),this.serializer=new c0(t),this.Pi=new w0(this.serializer)}start(){return Promise.resolve()}shutdown(){return this.ui=!1,Promise.resolve()}get started(){return this.ui}setDatabaseDeletedListener(){}setNetworkEnabled(){}getIndexManager(e){return this.indexManager}getDocumentOverlayCache(e){let t=this.overlays[e.toKey()];return t||(t=new T0,this.overlays[e.toKey()]=t),t}getMutationQueue(e,t){let r=this._i[e.toKey()];return r||(r=new I0(t,this.referenceDelegate),this._i[e.toKey()]=r),r}getGlobalsCache(){return this.ci}getTargetCache(){return this.li}getRemoteDocumentCache(){return this.remoteDocumentCache}getBundleCache(){return this.Pi}runTransaction(e,t,r){Y("MemoryPersistence","Starting transaction:",e);const o=new k0(this.ai.next());return this.referenceDelegate.Ti(),r(o).next(i=>this.referenceDelegate.Ei(o).next(()=>i)).toPromise().then(i=>(o.raiseOnCommittedEvent(),i))}Ii(e,t){return U.or(Object.values(this._i).map(r=>()=>r.containsKey(e,t)))}}class k0 extends eT{constructor(e){super(),this.currentSequenceNumber=e}}class bu{constructor(e){this.persistence=e,this.Ri=new _u,this.Ai=null}static Vi(e){return new bu(e)}get di(){if(this.Ai)return this.Ai;throw ee(60996)}addReference(e,t,r){return this.Ri.addReference(r,t),this.di.delete(r.toString()),U.resolve()}removeReference(e,t,r){return this.Ri.removeReference(r,t),this.di.add(r.toString()),U.resolve()}markPotentiallyOrphaned(e,t){return this.di.add(t.toString()),U.resolve()}removeTarget(e,t){this.Ri.Gr(t.targetId).forEach(o=>this.di.add(o.toString()));const r=this.persistence.getTargetCache();return r.getMatchingKeysForTargetId(e,t.targetId).next(o=>{o.forEach(i=>this.di.add(i.toString()))}).next(()=>r.removeTargetData(e,t))}Ti(){this.Ai=new Set}Ei(e){const t=this.persistence.getRemoteDocumentCache().newChangeBuffer();return U.forEach(this.di,r=>{const o=Q.fromPath(r);return this.mi(e,o).next(i=>{i||t.removeEntry(o,ne.min())})}).next(()=>(this.Ai=null,t.apply(e)))}updateLimboDocument(e,t){return this.mi(e,t).next(r=>{r?this.di.delete(t.toString()):this.di.add(t.toString())})}hi(e){return 0}mi(e,t){return U.or([()=>U.resolve(this.Ri.containsKey(t)),()=>this.persistence.getTargetCache().containsKey(e,t),()=>this.persistence.Ii(e,t)])}}class Na{constructor(e,t){this.persistence=e,this.fi=new Hr(r=>rT(r.path),(r,o)=>r.isEqual(o)),this.garbageCollector=y0(this,t)}static Vi(e,t){return new Na(e,t)}Ti(){}Ei(e){return U.resolve()}forEachTarget(e,t){return this.persistence.getTargetCache().forEachTarget(e,t)}dr(e){const t=this.pr(e);return this.persistence.getTargetCache().getTargetCount(e).next(r=>t.next(o=>r+o))}pr(e){let t=0;return this.mr(e,r=>{t++}).next(()=>t)}mr(e,t){return U.forEach(this.fi,(r,o)=>this.wr(e,r,o).next(i=>i?U.resolve():t(o)))}removeTargets(e,t,r){return this.persistence.getTargetCache().removeTargets(e,t,r)}removeOrphanedDocuments(e,t){let r=0;const o=this.persistence.getRemoteDocumentCache(),i=o.newChangeBuffer();return o.ni(e,s=>this.wr(e,s,t).next(c=>{c||(r++,i.removeEntry(s,ne.min()))})).next(()=>i.apply(e)).next(()=>r)}markPotentiallyOrphaned(e,t){return this.fi.set(t,e.currentSequenceNumber),U.resolve()}removeTarget(e,t){const r=t.withSequenceNumber(e.currentSequenceNumber);return this.persistence.getTargetCache().updateTargetData(e,r)}addReference(e,t,r){return this.fi.set(r,e.currentSequenceNumber),U.resolve()}removeReference(e,t,r){return this.fi.set(r,e.currentSequenceNumber),U.resolve()}updateLimboDocument(e,t){return this.fi.set(t,e.currentSequenceNumber),U.resolve()}hi(e){let t=e.key.toString().length;return e.isFoundDocument()&&(t+=ca(e.data.value)),t}wr(e,t,r){return U.or([()=>this.persistence.Ii(e,t),()=>this.persistence.getTargetCache().containsKey(e,t),()=>{const o=this.fi.get(t);return U.resolve(o!==void 0&&o>r)}])}getCacheSize(e){return this.persistence.getRemoteDocumentCache().getSize(e)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wu{constructor(e,t,r,o){this.targetId=e,this.fromCache=t,this.Ts=r,this.Es=o}static Is(e,t){let r=ue(),o=ue();for(const i of t.docChanges)switch(i.type){case 0:r=r.add(i.doc.key);break;case 1:o=o.add(i.doc.key)}return new wu(e,t.fromCache,r,o)}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class P0{constructor(){this._documentReadCount=0}get documentReadCount(){return this._documentReadCount}incrementDocumentReadCount(e){this._documentReadCount+=e}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class C0{constructor(){this.Rs=!1,this.As=!1,this.Vs=100,this.ds=function(){return yv()?8:tT(ht())>0?6:4}()}initialize(e,t){this.fs=e,this.indexManager=t,this.Rs=!0}getDocumentsMatchingQuery(e,t,r,o){const i={result:null};return this.gs(e,t).next(s=>{i.result=s}).next(()=>{if(!i.result)return this.ps(e,t,o,r).next(s=>{i.result=s})}).next(()=>{if(i.result)return;const s=new P0;return this.ys(e,t,s).next(c=>{if(i.result=c,this.As)return this.ws(e,t,s,c.size)})}).next(()=>i.result)}ws(e,t,r,o){return r.documentReadCount<this.Vs?(ro()<=le.DEBUG&&Y("QueryEngine","SDK will not create cache indexes for query:",oo(t),"since it only creates cache indexes for collection contains","more than or equal to",this.Vs,"documents"),U.resolve()):(ro()<=le.DEBUG&&Y("QueryEngine","Query:",oo(t),"scans",r.documentReadCount,"local documents and returns",o,"documents as results."),r.documentReadCount>this.ds*o?(ro()<=le.DEBUG&&Y("QueryEngine","The SDK decides to create cache indexes for query:",oo(t),"as using cache indexes may help improve performance."),this.indexManager.createTargetIndexes(e,sn(t))):U.resolve())}gs(e,t){if(Jh(t))return U.resolve(null);let r=sn(t);return this.indexManager.getIndexType(e,r).next(o=>o===0?null:(t.limit!==null&&o===1&&(t=Ra(t,null,"F"),r=sn(t)),this.indexManager.getDocumentsMatchingTarget(e,r).next(i=>{const s=ue(...i);return this.fs.getDocuments(e,s).next(c=>this.indexManager.getMinOffset(e,r).next(d=>{const u=this.Ss(t,c);return this.bs(t,u,s,d.readTime)?this.gs(e,Ra(t,null,"F")):this.Ds(e,u,t,d)}))})))}ps(e,t,r,o){return Jh(t)||o.isEqual(ne.min())?U.resolve(null):this.fs.getDocuments(e,r).next(i=>{const s=this.Ss(t,i);return this.bs(t,s,r,o)?U.resolve(null):(ro()<=le.DEBUG&&Y("QueryEngine","Re-using previous result from %s to execute query: %s",o.toString(),oo(t)),this.Ds(e,s,t,Xw(o,Hi)).next(c=>c))})}Ss(e,t){let r=new Qe(Cg(e));return t.forEach((o,i)=>{sl(e,i)&&(r=r.add(i))}),r}bs(e,t,r,o){if(e.limit===null)return!1;if(r.size!==t.size)return!0;const i=e.limitType==="F"?t.last():t.first();return!!i&&(i.hasPendingWrites||i.version.compareTo(o)>0)}ys(e,t,r){return ro()<=le.DEBUG&&Y("QueryEngine","Using full collection scan to execute query:",oo(t)),this.fs.getDocumentsMatchingQuery(e,t,or.min(),r)}Ds(e,t,r,o){return this.fs.getDocumentsMatchingQuery(e,r,o).next(i=>(t.forEach(s=>{i=i.insert(s.key,s)}),i))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Tu="LocalStore",R0=3e8;class O0{constructor(e,t,r,o){this.persistence=e,this.Cs=t,this.serializer=o,this.vs=new Ne(ce),this.Fs=new Hr(i=>hu(i),fu),this.Ms=new Map,this.xs=e.getRemoteDocumentCache(),this.li=e.getTargetCache(),this.Pi=e.getBundleCache(),this.Os(r)}Os(e){this.documentOverlayCache=this.persistence.getDocumentOverlayCache(e),this.indexManager=this.persistence.getIndexManager(e),this.mutationQueue=this.persistence.getMutationQueue(e,this.indexManager),this.localDocuments=new b0(this.xs,this.mutationQueue,this.documentOverlayCache,this.indexManager),this.xs.setIndexManager(this.indexManager),this.Cs.initialize(this.localDocuments,this.indexManager)}collectGarbage(e){return this.persistence.runTransaction("Collect garbage","readwrite-primary",t=>e.collect(t,this.vs))}}function N0(n,e,t,r){return new O0(n,e,t,r)}async function nm(n,e){const t=re(n);return await t.persistence.runTransaction("Handle user change","readonly",r=>{let o;return t.mutationQueue.getAllMutationBatches(r).next(i=>(o=i,t.Os(e),t.mutationQueue.getAllMutationBatches(r))).next(i=>{const s=[],c=[];let d=ue();for(const u of o){s.push(u.batchId);for(const f of u.mutations)d=d.add(f.key)}for(const u of i){c.push(u.batchId);for(const f of u.mutations)d=d.add(f.key)}return t.localDocuments.getDocuments(r,d).next(u=>({Ns:u,removedBatchIds:s,addedBatchIds:c}))})})}function L0(n,e){const t=re(n);return t.persistence.runTransaction("Acknowledge batch","readwrite-primary",r=>{const o=e.batch.keys(),i=t.xs.newChangeBuffer({trackRemovals:!0});return function(c,d,u,f){const g=u.batch,m=g.keys();let v=U.resolve();return m.forEach(L=>{v=v.next(()=>f.getEntry(d,L)).next(P=>{const M=u.docVersions.get(L);we(M!==null,48541),P.version.compareTo(M)<0&&(g.applyToRemoteDocument(P,u),P.isValidDocument()&&(P.setReadTime(u.commitVersion),f.addEntry(P)))})}),v.next(()=>c.mutationQueue.removeMutationBatch(d,g))}(t,r,e,i).next(()=>i.apply(r)).next(()=>t.mutationQueue.performConsistencyCheck(r)).next(()=>t.documentOverlayCache.removeOverlaysForBatchId(r,o,e.batch.batchId)).next(()=>t.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(r,function(c){let d=ue();for(let u=0;u<c.mutationResults.length;++u)c.mutationResults[u].transformResults.length>0&&(d=d.add(c.batch.mutations[u].key));return d}(e))).next(()=>t.localDocuments.getDocuments(r,o))})}function rm(n){const e=re(n);return e.persistence.runTransaction("Get last remote snapshot version","readonly",t=>e.li.getLastRemoteSnapshotVersion(t))}function M0(n,e){const t=re(n),r=e.snapshotVersion;let o=t.vs;return t.persistence.runTransaction("Apply remote event","readwrite-primary",i=>{const s=t.xs.newChangeBuffer({trackRemovals:!0});o=t.vs;const c=[];e.targetChanges.forEach((f,g)=>{const m=o.get(g);if(!m)return;c.push(t.li.removeMatchingKeys(i,f.removedDocuments,g).next(()=>t.li.addMatchingKeys(i,f.addedDocuments,g)));let v=m.withSequenceNumber(i.currentSequenceNumber);e.targetMismatches.get(g)!==null?v=v.withResumeToken(at.EMPTY_BYTE_STRING,ne.min()).withLastLimboFreeSnapshotVersion(ne.min()):f.resumeToken.approximateByteSize()>0&&(v=v.withResumeToken(f.resumeToken,r)),o=o.insert(g,v),function(P,M,G){return P.resumeToken.approximateByteSize()===0||M.snapshotVersion.toMicroseconds()-P.snapshotVersion.toMicroseconds()>=R0?!0:G.addedDocuments.size+G.modifiedDocuments.size+G.removedDocuments.size>0}(m,v,f)&&c.push(t.li.updateTargetData(i,v))});let d=Rn(),u=ue();if(e.documentUpdates.forEach(f=>{e.resolvedLimboDocuments.has(f)&&c.push(t.persistence.referenceDelegate.updateLimboDocument(i,f))}),c.push(D0(i,s,e.documentUpdates).next(f=>{d=f.Bs,u=f.Ls})),!r.isEqual(ne.min())){const f=t.li.getLastRemoteSnapshotVersion(i).next(g=>t.li.setTargetsMetadata(i,i.currentSequenceNumber,r));c.push(f)}return U.waitFor(c).next(()=>s.apply(i)).next(()=>t.localDocuments.getLocalViewOfDocuments(i,d,u)).next(()=>d)}).then(i=>(t.vs=o,i))}function D0(n,e,t){let r=ue(),o=ue();return t.forEach(i=>r=r.add(i)),e.getEntries(n,r).next(i=>{let s=Rn();return t.forEach((c,d)=>{const u=i.get(c);d.isFoundDocument()!==u.isFoundDocument()&&(o=o.add(c)),d.isNoDocument()&&d.version.isEqual(ne.min())?(e.removeEntry(c,d.readTime),s=s.insert(c,d)):!u.isValidDocument()||d.version.compareTo(u.version)>0||d.version.compareTo(u.version)===0&&u.hasPendingWrites?(e.addEntry(d),s=s.insert(c,d)):Y(Tu,"Ignoring outdated watch update for ",c,". Current version:",u.version," Watch version:",d.version)}),{Bs:s,Ls:o}})}function V0(n,e){const t=re(n);return t.persistence.runTransaction("Get next mutation batch","readonly",r=>(e===void 0&&(e=cu),t.mutationQueue.getNextMutationBatchAfterBatchId(r,e)))}function F0(n,e){const t=re(n);return t.persistence.runTransaction("Allocate target","readwrite",r=>{let o;return t.li.getTargetData(r,e).next(i=>i?(o=i,U.resolve(o)):t.li.allocateTargetId(r).next(s=>(o=new Yn(e,s,"TargetPurposeListen",r.currentSequenceNumber),t.li.addTargetData(r,o).next(()=>o))))}).then(r=>{const o=t.vs.get(r.targetId);return(o===null||r.snapshotVersion.compareTo(o.snapshotVersion)>0)&&(t.vs=t.vs.insert(r.targetId,r),t.Fs.set(e,r.targetId)),r})}async function Ic(n,e,t){const r=re(n),o=r.vs.get(e),i=t?"readwrite":"readwrite-primary";try{t||await r.persistence.runTransaction("Release target",i,s=>r.persistence.referenceDelegate.removeTarget(s,o))}catch(s){if(!$o(s))throw s;Y(Tu,`Failed to update sequence numbers for target ${e}: ${s}`)}r.vs=r.vs.remove(e),r.Fs.delete(o.target)}function hf(n,e,t){const r=re(n);let o=ne.min(),i=ue();return r.persistence.runTransaction("Execute query","readwrite",s=>function(d,u,f){const g=re(d),m=g.Fs.get(f);return m!==void 0?U.resolve(g.vs.get(m)):g.li.getTargetData(u,f)}(r,s,sn(e)).next(c=>{if(c)return o=c.lastLimboFreeSnapshotVersion,r.li.getMatchingKeysForTargetId(s,c.targetId).next(d=>{i=d})}).next(()=>r.Cs.getDocumentsMatchingQuery(s,e,t?o:ne.min(),t?i:ue())).next(c=>(U0(r,ST(e),c),{documents:c,ks:i})))}function U0(n,e,t){let r=n.Ms.get(e)||ne.min();t.forEach((o,i)=>{i.readTime.compareTo(r)>0&&(r=i.readTime)}),n.Ms.set(e,r)}class ff{constructor(){this.activeTargetIds=RT()}Qs(e){this.activeTargetIds=this.activeTargetIds.add(e)}Gs(e){this.activeTargetIds=this.activeTargetIds.delete(e)}Ws(){const e={activeTargetIds:this.activeTargetIds.toArray(),updateTimeMs:Date.now()};return JSON.stringify(e)}}class q0{constructor(){this.vo=new ff,this.Fo={},this.onlineStateHandler=null,this.sequenceNumberHandler=null}addPendingMutation(e){}updateMutationState(e,t,r){}addLocalQueryTarget(e,t=!0){return t&&this.vo.Qs(e),this.Fo[e]||"not-current"}updateQueryState(e,t,r){this.Fo[e]=t}removeLocalQueryTarget(e){this.vo.Gs(e)}isLocalQueryTarget(e){return this.vo.activeTargetIds.has(e)}clearQueryState(e){delete this.Fo[e]}getAllActiveQueryTargets(){return this.vo.activeTargetIds}isActiveQueryTarget(e){return this.vo.activeTargetIds.has(e)}start(){return this.vo=new ff,Promise.resolve()}handleUserChange(e,t,r){}setOnlineState(e){}shutdown(){}writeSequenceNumber(e){}notifyBundleLoaded(e){}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class B0{Mo(e){}shutdown(){}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const pf="ConnectivityMonitor";class gf{constructor(){this.xo=()=>this.Oo(),this.No=()=>this.Bo(),this.Lo=[],this.ko()}Mo(e){this.Lo.push(e)}shutdown(){window.removeEventListener("online",this.xo),window.removeEventListener("offline",this.No)}ko(){window.addEventListener("online",this.xo),window.addEventListener("offline",this.No)}Oo(){Y(pf,"Network connectivity changed: AVAILABLE");for(const e of this.Lo)e(0)}Bo(){Y(pf,"Network connectivity changed: UNAVAILABLE");for(const e of this.Lo)e(1)}static v(){return typeof window<"u"&&window.addEventListener!==void 0&&window.removeEventListener!==void 0}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Ws=null;function Sc(){return Ws===null?Ws=function(){return 268435456+Math.round(2147483648*Math.random())}():Ws++,"0x"+Ws.toString(16)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Hl="RestConnection",$0={BatchGetDocuments:"batchGet",Commit:"commit",RunQuery:"runQuery",RunAggregationQuery:"runAggregationQuery",ExecutePipeline:"executePipeline"};class j0{get qo(){return!1}constructor(e){this.databaseInfo=e,this.databaseId=e.databaseId;const t=e.ssl?"https":"http",r=encodeURIComponent(this.databaseId.projectId),o=encodeURIComponent(this.databaseId.database);this.Ko=t+"://"+e.host,this.Uo=`projects/${r}/databases/${o}`,this.$o=this.databaseId.database===ka?`project_id=${r}`:`project_id=${r}&database_id=${o}`}Wo(e,t,r,o,i){const s=Sc(),c=this.Qo(e,t.toUriEncodedString());Y(Hl,`Sending RPC '${e}' ${s}:`,c,r);const d={"google-cloud-resource-prefix":this.Uo,"x-goog-request-params":this.$o};this.Go(d,o,i);const{host:u}=new URL(c),f=hs(u);return this.zo(e,c,d,r,f).then(g=>(Y(Hl,`Received RPC '${e}' ${s}: `,g),g),g=>{throw Ur(Hl,`RPC '${e}' ${s} failed with error: `,g,"url: ",c,"request:",r),g})}jo(e,t,r,o,i,s){return this.Wo(e,t,r,o,i)}Go(e,t,r){e["X-Goog-Api-Client"]=function(){return"gl-js/ fire/"+qo}(),e["Content-Type"]="text/plain",this.databaseInfo.appId&&(e["X-Firebase-GMPID"]=this.databaseInfo.appId),t&&t.headers.forEach((o,i)=>e[i]=o),r&&r.headers.forEach((o,i)=>e[i]=o)}Qo(e,t){const r=$0[e];let o=`${this.Ko}/v1/${t}:${r}`;return this.databaseInfo.apiKey&&(o=`${o}?key=${encodeURIComponent(this.databaseInfo.apiKey)}`),o}terminate(){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class z0{constructor(e){this.Jo=e.Jo,this.Ho=e.Ho}Zo(e){this.Xo=e}Yo(e){this.e_=e}t_(e){this.n_=e}onMessage(e){this.r_=e}close(){this.Ho()}send(e){this.Jo(e)}i_(){this.Xo()}s_(){this.e_()}o_(e){this.n_(e)}__(e){this.r_(e)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const lt="WebChannelConnection",fi=(n,e,t)=>{n.listen(e,r=>{try{t(r)}catch(o){setTimeout(()=>{throw o},0)}})};class po extends j0{constructor(e){super(e),this.a_=[],this.forceLongPolling=e.forceLongPolling,this.autoDetectLongPolling=e.autoDetectLongPolling,this.useFetchStreams=e.useFetchStreams,this.longPollingOptions=e.longPollingOptions}static u_(){if(!po.c_){const e=sg();fi(e,ig.STAT_EVENT,t=>{t.stat===fc.PROXY?Y(lt,"STAT_EVENT: detected buffering proxy"):t.stat===fc.NOPROXY&&Y(lt,"STAT_EVENT: detected no buffering proxy")}),po.c_=!0}}zo(e,t,r,o,i){const s=Sc();return new Promise((c,d)=>{const u=new rg;u.setWithCredentials(!0),u.listenOnce(og.COMPLETE,()=>{try{switch(u.getLastErrorCode()){case la.NO_ERROR:const g=u.getResponseJson();Y(lt,`XHR for RPC '${e}' ${s} received:`,JSON.stringify(g)),c(g);break;case la.TIMEOUT:Y(lt,`RPC '${e}' ${s} timed out`),d(new H(F.DEADLINE_EXCEEDED,"Request time out"));break;case la.HTTP_ERROR:const m=u.getStatus();if(Y(lt,`RPC '${e}' ${s} failed with status:`,m,"response text:",u.getResponseText()),m>0){let v=u.getResponseJson();Array.isArray(v)&&(v=v[0]);const L=v==null?void 0:v.error;if(L&&L.status&&L.message){const P=function(G){const $=G.toLowerCase().replace(/_/g,"-");return Object.values(F).indexOf($)>=0?$:F.UNKNOWN}(L.status);d(new H(P,L.message))}else d(new H(F.UNKNOWN,"Server responded with status "+u.getStatus()))}else d(new H(F.UNAVAILABLE,"Connection failed."));break;default:ee(9055,{l_:e,streamId:s,h_:u.getLastErrorCode(),P_:u.getLastError()})}}finally{Y(lt,`RPC '${e}' ${s} completed.`)}});const f=JSON.stringify(o);Y(lt,`RPC '${e}' ${s} sending request:`,o),u.send(t,"POST",f,r,15)})}T_(e,t,r){const o=Sc(),i=[this.Ko,"/","google.firestore.v1.Firestore","/",e,"/channel"],s=this.createWebChannelTransport(),c={httpSessionIdParam:"gsessionid",initMessageHeaders:{},messageUrlParams:{database:`projects/${this.databaseId.projectId}/databases/${this.databaseId.database}`},sendRawJson:!0,supportsCrossDomainXhr:!0,internalChannelParams:{forwardChannelRequestTimeoutMs:6e5},forceLongPolling:this.forceLongPolling,detectBufferingProxy:this.autoDetectLongPolling},d=this.longPollingOptions.timeoutSeconds;d!==void 0&&(c.longPollingTimeout=Math.round(1e3*d)),this.useFetchStreams&&(c.useFetchStreams=!0),this.Go(c.initMessageHeaders,t,r),c.encodeInitMessageHeaders=!0;const u=i.join("");Y(lt,`Creating RPC '${e}' stream ${o}: ${u}`,c);const f=s.createWebChannel(u,c);this.E_(f);let g=!1,m=!1;const v=new z0({Jo:L=>{m?Y(lt,`Not sending because RPC '${e}' stream ${o} is closed:`,L):(g||(Y(lt,`Opening RPC '${e}' stream ${o} transport.`),f.open(),g=!0),Y(lt,`RPC '${e}' stream ${o} sending:`,L),f.send(L))},Ho:()=>f.close()});return fi(f,Ti.EventType.OPEN,()=>{m||(Y(lt,`RPC '${e}' stream ${o} transport opened.`),v.i_())}),fi(f,Ti.EventType.CLOSE,()=>{m||(m=!0,Y(lt,`RPC '${e}' stream ${o} transport closed`),v.o_(),this.I_(f))}),fi(f,Ti.EventType.ERROR,L=>{m||(m=!0,Ur(lt,`RPC '${e}' stream ${o} transport errored. Name:`,L.name,"Message:",L.message),v.o_(new H(F.UNAVAILABLE,"The operation could not be completed")))}),fi(f,Ti.EventType.MESSAGE,L=>{var P;if(!m){const M=L.data[0];we(!!M,16349);const G=M,$=(G==null?void 0:G.error)||((P=G[0])==null?void 0:P.error);if($){Y(lt,`RPC '${e}' stream ${o} received error:`,$);const D=$.status;let j=function(I){const b=qe[I];if(b!==void 0)return jg(b)}(D),V=$.message;D==="NOT_FOUND"&&V.includes("database")&&V.includes("does not exist")&&V.includes(this.databaseId.database)&&Ur(`Database '${this.databaseId.database}' not found. Please check your project configuration.`),j===void 0&&(j=F.INTERNAL,V="Unknown error status: "+D+" with message "+$.message),m=!0,v.o_(new H(j,V)),f.close()}else Y(lt,`RPC '${e}' stream ${o} received:`,M),v.__(M)}}),po.u_(),setTimeout(()=>{v.s_()},0),v}terminate(){this.a_.forEach(e=>e.close()),this.a_=[]}E_(e){this.a_.push(e)}I_(e){this.a_=this.a_.filter(t=>t===e)}Go(e,t,r){super.Go(e,t,r),this.databaseInfo.apiKey&&(e["x-goog-api-key"]=this.databaseInfo.apiKey)}createWebChannelTransport(){return ag()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function W0(n){return new po(n)}function Gl(){return typeof document<"u"?document:null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ul(n){return new KT(n,!0)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */po.c_=!1;class om{constructor(e,t,r=1e3,o=1.5,i=6e4){this.Ci=e,this.timerId=t,this.R_=r,this.A_=o,this.V_=i,this.d_=0,this.m_=null,this.f_=Date.now(),this.reset()}reset(){this.d_=0}g_(){this.d_=this.V_}p_(e){this.cancel();const t=Math.floor(this.d_+this.y_()),r=Math.max(0,Date.now()-this.f_),o=Math.max(0,t-r);o>0&&Y("ExponentialBackoff",`Backing off for ${o} ms (base delay: ${this.d_} ms, delay with jitter: ${t} ms, last attempt: ${r} ms ago)`),this.m_=this.Ci.enqueueAfterDelay(this.timerId,o,()=>(this.f_=Date.now(),e())),this.d_*=this.A_,this.d_<this.R_&&(this.d_=this.R_),this.d_>this.V_&&(this.d_=this.V_)}w_(){this.m_!==null&&(this.m_.skipDelay(),this.m_=null)}cancel(){this.m_!==null&&(this.m_.cancel(),this.m_=null)}y_(){return(Math.random()-.5)*this.d_}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const mf="PersistentStream";class im{constructor(e,t,r,o,i,s,c,d){this.Ci=e,this.S_=r,this.b_=o,this.connection=i,this.authCredentialsProvider=s,this.appCheckCredentialsProvider=c,this.listener=d,this.state=0,this.D_=0,this.C_=null,this.v_=null,this.stream=null,this.F_=0,this.M_=new om(e,t)}x_(){return this.state===1||this.state===5||this.O_()}O_(){return this.state===2||this.state===3}start(){this.F_=0,this.state!==4?this.auth():this.N_()}async stop(){this.x_()&&await this.close(0)}B_(){this.state=0,this.M_.reset()}L_(){this.O_()&&this.C_===null&&(this.C_=this.Ci.enqueueAfterDelay(this.S_,6e4,()=>this.k_()))}q_(e){this.K_(),this.stream.send(e)}async k_(){if(this.O_())return this.close(0)}K_(){this.C_&&(this.C_.cancel(),this.C_=null)}U_(){this.v_&&(this.v_.cancel(),this.v_=null)}async close(e,t){this.K_(),this.U_(),this.M_.cancel(),this.D_++,e!==4?this.M_.reset():t&&t.code===F.RESOURCE_EXHAUSTED?(Cn(t.toString()),Cn("Using maximum backoff delay to prevent overloading the backend."),this.M_.g_()):t&&t.code===F.UNAUTHENTICATED&&this.state!==3&&(this.authCredentialsProvider.invalidateToken(),this.appCheckCredentialsProvider.invalidateToken()),this.stream!==null&&(this.W_(),this.stream.close(),this.stream=null),this.state=e,await this.listener.t_(t)}W_(){}auth(){this.state=1;const e=this.Q_(this.D_),t=this.D_;Promise.all([this.authCredentialsProvider.getToken(),this.appCheckCredentialsProvider.getToken()]).then(([r,o])=>{this.D_===t&&this.G_(r,o)},r=>{e(()=>{const o=new H(F.UNKNOWN,"Fetching auth token failed: "+r.message);return this.z_(o)})})}G_(e,t){const r=this.Q_(this.D_);this.stream=this.j_(e,t),this.stream.Zo(()=>{r(()=>this.listener.Zo())}),this.stream.Yo(()=>{r(()=>(this.state=2,this.v_=this.Ci.enqueueAfterDelay(this.b_,1e4,()=>(this.O_()&&(this.state=3),Promise.resolve())),this.listener.Yo()))}),this.stream.t_(o=>{r(()=>this.z_(o))}),this.stream.onMessage(o=>{r(()=>++this.F_==1?this.J_(o):this.onNext(o))})}N_(){this.state=5,this.M_.p_(async()=>{this.state=0,this.start()})}z_(e){return Y(mf,`close with error: ${e}`),this.stream=null,this.close(4,e)}Q_(e){return t=>{this.Ci.enqueueAndForget(()=>this.D_===e?t():(Y(mf,"stream callback skipped by getCloseGuardedDispatcher."),Promise.resolve()))}}}class H0 extends im{constructor(e,t,r,o,i,s){super(e,"listen_stream_connection_backoff","listen_stream_idle","health_check_timeout",t,r,o,s),this.serializer=i}j_(e,t){return this.connection.T_("Listen",e,t)}J_(e){return this.onNext(e)}onNext(e){this.M_.reset();const t=JT(this.serializer,e),r=function(i){if(!("targetChange"in i))return ne.min();const s=i.targetChange;return s.targetIds&&s.targetIds.length?ne.min():s.readTime?an(s.readTime):ne.min()}(e);return this.listener.H_(t,r)}Z_(e){const t={};t.database=Ec(this.serializer),t.addTarget=function(i,s){let c;const d=s.target;if(c=vc(d)?{documents:t0(i,d)}:{query:n0(i,d).ft},c.targetId=s.targetId,s.resumeToken.approximateByteSize()>0){c.resumeToken=Hg(i,s.resumeToken);const u=bc(i,s.expectedCount);u!==null&&(c.expectedCount=u)}else if(s.snapshotVersion.compareTo(ne.min())>0){c.readTime=Oa(i,s.snapshotVersion.toTimestamp());const u=bc(i,s.expectedCount);u!==null&&(c.expectedCount=u)}return c}(this.serializer,e);const r=o0(this.serializer,e);r&&(t.labels=r),this.q_(t)}X_(e){const t={};t.database=Ec(this.serializer),t.removeTarget=e,this.q_(t)}}class G0 extends im{constructor(e,t,r,o,i,s){super(e,"write_stream_connection_backoff","write_stream_idle","health_check_timeout",t,r,o,s),this.serializer=i}get Y_(){return this.F_>0}start(){this.lastStreamToken=void 0,super.start()}W_(){this.Y_&&this.ea([])}j_(e,t){return this.connection.T_("Write",e,t)}J_(e){return we(!!e.streamToken,31322),this.lastStreamToken=e.streamToken,we(!e.writeResults||e.writeResults.length===0,55816),this.listener.ta()}onNext(e){we(!!e.streamToken,12678),this.lastStreamToken=e.streamToken,this.M_.reset();const t=e0(e.writeResults,e.commitTime),r=an(e.commitTime);return this.listener.na(r,t)}ra(){const e={};e.database=Ec(this.serializer),this.q_(e)}ea(e){const t={streamToken:this.lastStreamToken,writes:e.map(r=>ZT(this.serializer,r))};this.q_(t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Y0{}class K0 extends Y0{constructor(e,t,r,o){super(),this.authCredentials=e,this.appCheckCredentials=t,this.connection=r,this.serializer=o,this.ia=!1}sa(){if(this.ia)throw new H(F.FAILED_PRECONDITION,"The client has already been terminated.")}Wo(e,t,r,o){return this.sa(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then(([i,s])=>this.connection.Wo(e,wc(t,r),o,i,s)).catch(i=>{throw i.name==="FirebaseError"?(i.code===F.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),i):new H(F.UNKNOWN,i.toString())})}jo(e,t,r,o,i){return this.sa(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then(([s,c])=>this.connection.jo(e,wc(t,r),o,s,c,i)).catch(s=>{throw s.name==="FirebaseError"?(s.code===F.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),s):new H(F.UNKNOWN,s.toString())})}terminate(){this.ia=!0,this.connection.terminate()}}function X0(n,e,t,r){return new K0(n,e,t,r)}class Q0{constructor(e,t){this.asyncQueue=e,this.onlineStateHandler=t,this.state="Unknown",this.oa=0,this._a=null,this.aa=!0}ua(){this.oa===0&&(this.ca("Unknown"),this._a=this.asyncQueue.enqueueAfterDelay("online_state_timeout",1e4,()=>(this._a=null,this.la("Backend didn't respond within 10 seconds."),this.ca("Offline"),Promise.resolve())))}ha(e){this.state==="Online"?this.ca("Unknown"):(this.oa++,this.oa>=1&&(this.Pa(),this.la(`Connection failed 1 times. Most recent error: ${e.toString()}`),this.ca("Offline")))}set(e){this.Pa(),this.oa=0,e==="Online"&&(this.aa=!1),this.ca(e)}ca(e){e!==this.state&&(this.state=e,this.onlineStateHandler(e))}la(e){const t=`Could not reach Cloud Firestore backend. ${e}
This typically indicates that your device does not have a healthy Internet connection at the moment. The client will operate in offline mode until it is able to successfully connect to the backend.`;this.aa?(Cn(t),this.aa=!1):Y("OnlineStateTracker",t)}Pa(){this._a!==null&&(this._a.cancel(),this._a=null)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const qr="RemoteStore";class J0{constructor(e,t,r,o,i){this.localStore=e,this.datastore=t,this.asyncQueue=r,this.remoteSyncer={},this.Ta=[],this.Ea=new Map,this.Ia=new Set,this.Ra=[],this.Aa=i,this.Aa.Mo(s=>{r.enqueueAndForget(async()=>{Gr(this)&&(Y(qr,"Restarting streams for network reachability change."),await async function(d){const u=re(d);u.Ia.add(4),await _s(u),u.Va.set("Unknown"),u.Ia.delete(4),await dl(u)}(this))})}),this.Va=new Q0(r,o)}}async function dl(n){if(Gr(n))for(const e of n.Ra)await e(!0)}async function _s(n){for(const e of n.Ra)await e(!1)}function sm(n,e){const t=re(n);t.Ea.has(e.targetId)||(t.Ea.set(e.targetId,e),xu(t)?Su(t):zo(t).O_()&&Iu(t,e))}function Eu(n,e){const t=re(n),r=zo(t);t.Ea.delete(e),r.O_()&&am(t,e),t.Ea.size===0&&(r.O_()?r.L_():Gr(t)&&t.Va.set("Unknown"))}function Iu(n,e){if(n.da.$e(e.targetId),e.resumeToken.approximateByteSize()>0||e.snapshotVersion.compareTo(ne.min())>0){const t=n.remoteSyncer.getRemoteKeysForTarget(e.targetId).size;e=e.withExpectedCount(t)}zo(n).Z_(e)}function am(n,e){n.da.$e(e),zo(n).X_(e)}function Su(n){n.da=new WT({getRemoteKeysForTarget:e=>n.remoteSyncer.getRemoteKeysForTarget(e),At:e=>n.Ea.get(e)||null,ht:()=>n.datastore.serializer.databaseId}),zo(n).start(),n.Va.ua()}function xu(n){return Gr(n)&&!zo(n).x_()&&n.Ea.size>0}function Gr(n){return re(n).Ia.size===0}function lm(n){n.da=void 0}async function Z0(n){n.Va.set("Online")}async function eE(n){n.Ea.forEach((e,t)=>{Iu(n,e)})}async function tE(n,e){lm(n),xu(n)?(n.Va.ha(e),Su(n)):n.Va.set("Unknown")}async function nE(n,e,t){if(n.Va.set("Online"),e instanceof Wg&&e.state===2&&e.cause)try{await async function(o,i){const s=i.cause;for(const c of i.targetIds)o.Ea.has(c)&&(await o.remoteSyncer.rejectListen(c,s),o.Ea.delete(c),o.da.removeTarget(c))}(n,e)}catch(r){Y(qr,"Failed to remove targets %s: %s ",e.targetIds.join(","),r),await La(n,r)}else if(e instanceof ha?n.da.Xe(e):e instanceof zg?n.da.st(e):n.da.tt(e),!t.isEqual(ne.min()))try{const r=await rm(n.localStore);t.compareTo(r)>=0&&await function(i,s){const c=i.da.Tt(s);return c.targetChanges.forEach((d,u)=>{if(d.resumeToken.approximateByteSize()>0){const f=i.Ea.get(u);f&&i.Ea.set(u,f.withResumeToken(d.resumeToken,s))}}),c.targetMismatches.forEach((d,u)=>{const f=i.Ea.get(d);if(!f)return;i.Ea.set(d,f.withResumeToken(at.EMPTY_BYTE_STRING,f.snapshotVersion)),am(i,d);const g=new Yn(f.target,d,u,f.sequenceNumber);Iu(i,g)}),i.remoteSyncer.applyRemoteEvent(c)}(n,t)}catch(r){Y(qr,"Failed to raise snapshot:",r),await La(n,r)}}async function La(n,e,t){if(!$o(e))throw e;n.Ia.add(1),await _s(n),n.Va.set("Offline"),t||(t=()=>rm(n.localStore)),n.asyncQueue.enqueueRetryable(async()=>{Y(qr,"Retrying IndexedDB access"),await t(),n.Ia.delete(1),await dl(n)})}function cm(n,e){return e().catch(t=>La(n,t,e))}async function hl(n){const e=re(n),t=lr(e);let r=e.Ta.length>0?e.Ta[e.Ta.length-1].batchId:cu;for(;rE(e);)try{const o=await V0(e.localStore,r);if(o===null){e.Ta.length===0&&t.L_();break}r=o.batchId,oE(e,o)}catch(o){await La(e,o)}um(e)&&dm(e)}function rE(n){return Gr(n)&&n.Ta.length<10}function oE(n,e){n.Ta.push(e);const t=lr(n);t.O_()&&t.Y_&&t.ea(e.mutations)}function um(n){return Gr(n)&&!lr(n).x_()&&n.Ta.length>0}function dm(n){lr(n).start()}async function iE(n){lr(n).ra()}async function sE(n){const e=lr(n);for(const t of n.Ta)e.ea(t.mutations)}async function aE(n,e,t){const r=n.Ta.shift(),o=mu.from(r,e,t);await cm(n,()=>n.remoteSyncer.applySuccessfulWrite(o)),await hl(n)}async function lE(n,e){e&&lr(n).Y_&&await async function(r,o){if(function(s){return $T(s)&&s!==F.ABORTED}(o.code)){const i=r.Ta.shift();lr(r).B_(),await cm(r,()=>r.remoteSyncer.rejectFailedWrite(i.batchId,o)),await hl(r)}}(n,e),um(n)&&dm(n)}async function yf(n,e){const t=re(n);t.asyncQueue.verifyOperationInProgress(),Y(qr,"RemoteStore received new credentials");const r=Gr(t);t.Ia.add(3),await _s(t),r&&t.Va.set("Unknown"),await t.remoteSyncer.handleCredentialChange(e),t.Ia.delete(3),await dl(t)}async function cE(n,e){const t=re(n);e?(t.Ia.delete(2),await dl(t)):e||(t.Ia.add(2),await _s(t),t.Va.set("Unknown"))}function zo(n){return n.ma||(n.ma=function(t,r,o){const i=re(t);return i.sa(),new H0(r,i.connection,i.authCredentials,i.appCheckCredentials,i.serializer,o)}(n.datastore,n.asyncQueue,{Zo:Z0.bind(null,n),Yo:eE.bind(null,n),t_:tE.bind(null,n),H_:nE.bind(null,n)}),n.Ra.push(async e=>{e?(n.ma.B_(),xu(n)?Su(n):n.Va.set("Unknown")):(await n.ma.stop(),lm(n))})),n.ma}function lr(n){return n.fa||(n.fa=function(t,r,o){const i=re(t);return i.sa(),new G0(r,i.connection,i.authCredentials,i.appCheckCredentials,i.serializer,o)}(n.datastore,n.asyncQueue,{Zo:()=>Promise.resolve(),Yo:iE.bind(null,n),t_:lE.bind(null,n),ta:sE.bind(null,n),na:aE.bind(null,n)}),n.Ra.push(async e=>{e?(n.fa.B_(),await hl(n)):(await n.fa.stop(),n.Ta.length>0&&(Y(qr,`Stopping write stream with ${n.Ta.length} pending writes`),n.Ta=[]))})),n.fa}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Au{constructor(e,t,r,o,i){this.asyncQueue=e,this.timerId=t,this.targetTimeMs=r,this.op=o,this.removalCallback=i,this.deferred=new In,this.then=this.deferred.promise.then.bind(this.deferred.promise),this.deferred.promise.catch(s=>{})}get promise(){return this.deferred.promise}static createAndSchedule(e,t,r,o,i){const s=Date.now()+r,c=new Au(e,t,s,o,i);return c.start(r),c}start(e){this.timerHandle=setTimeout(()=>this.handleDelayElapsed(),e)}skipDelay(){return this.handleDelayElapsed()}cancel(e){this.timerHandle!==null&&(this.clearTimeout(),this.deferred.reject(new H(F.CANCELLED,"Operation cancelled"+(e?": "+e:""))))}handleDelayElapsed(){this.asyncQueue.enqueueAndForget(()=>this.timerHandle!==null?(this.clearTimeout(),this.op().then(e=>this.deferred.resolve(e))):Promise.resolve())}clearTimeout(){this.timerHandle!==null&&(this.removalCallback(this),clearTimeout(this.timerHandle),this.timerHandle=null)}}function ku(n,e){if(Cn("AsyncQueue",`${e}: ${n}`),$o(n))return new H(F.UNAVAILABLE,`${e}: ${n}`);throw n}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class go{static emptySet(e){return new go(e.comparator)}constructor(e){this.comparator=e?(t,r)=>e(t,r)||Q.comparator(t.key,r.key):(t,r)=>Q.comparator(t.key,r.key),this.keyedMap=Ei(),this.sortedSet=new Ne(this.comparator)}has(e){return this.keyedMap.get(e)!=null}get(e){return this.keyedMap.get(e)}first(){return this.sortedSet.minKey()}last(){return this.sortedSet.maxKey()}isEmpty(){return this.sortedSet.isEmpty()}indexOf(e){const t=this.keyedMap.get(e);return t?this.sortedSet.indexOf(t):-1}get size(){return this.sortedSet.size}forEach(e){this.sortedSet.inorderTraversal((t,r)=>(e(t),!1))}add(e){const t=this.delete(e.key);return t.copy(t.keyedMap.insert(e.key,e),t.sortedSet.insert(e,null))}delete(e){const t=this.get(e);return t?this.copy(this.keyedMap.remove(e),this.sortedSet.remove(t)):this}isEqual(e){if(!(e instanceof go)||this.size!==e.size)return!1;const t=this.sortedSet.getIterator(),r=e.sortedSet.getIterator();for(;t.hasNext();){const o=t.getNext().key,i=r.getNext().key;if(!o.isEqual(i))return!1}return!0}toString(){const e=[];return this.forEach(t=>{e.push(t.toString())}),e.length===0?"DocumentSet ()":`DocumentSet (
  `+e.join(`  
`)+`
)`}copy(e,t){const r=new go;return r.comparator=this.comparator,r.keyedMap=e,r.sortedSet=t,r}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class vf{constructor(){this.ga=new Ne(Q.comparator)}track(e){const t=e.doc.key,r=this.ga.get(t);r?e.type!==0&&r.type===3?this.ga=this.ga.insert(t,e):e.type===3&&r.type!==1?this.ga=this.ga.insert(t,{type:r.type,doc:e.doc}):e.type===2&&r.type===2?this.ga=this.ga.insert(t,{type:2,doc:e.doc}):e.type===2&&r.type===0?this.ga=this.ga.insert(t,{type:0,doc:e.doc}):e.type===1&&r.type===0?this.ga=this.ga.remove(t):e.type===1&&r.type===2?this.ga=this.ga.insert(t,{type:1,doc:r.doc}):e.type===0&&r.type===1?this.ga=this.ga.insert(t,{type:2,doc:e.doc}):ee(63341,{Vt:e,pa:r}):this.ga=this.ga.insert(t,e)}ya(){const e=[];return this.ga.inorderTraversal((t,r)=>{e.push(r)}),e}}class Oo{constructor(e,t,r,o,i,s,c,d,u){this.query=e,this.docs=t,this.oldDocs=r,this.docChanges=o,this.mutatedKeys=i,this.fromCache=s,this.syncStateChanged=c,this.excludesMetadataChanges=d,this.hasCachedResults=u}static fromInitialDocuments(e,t,r,o,i){const s=[];return t.forEach(c=>{s.push({type:0,doc:c})}),new Oo(e,t,go.emptySet(t),s,r,o,!0,!1,i)}get hasPendingWrites(){return!this.mutatedKeys.isEmpty()}isEqual(e){if(!(this.fromCache===e.fromCache&&this.hasCachedResults===e.hasCachedResults&&this.syncStateChanged===e.syncStateChanged&&this.mutatedKeys.isEqual(e.mutatedKeys)&&il(this.query,e.query)&&this.docs.isEqual(e.docs)&&this.oldDocs.isEqual(e.oldDocs)))return!1;const t=this.docChanges,r=e.docChanges;if(t.length!==r.length)return!1;for(let o=0;o<t.length;o++)if(t[o].type!==r[o].type||!t[o].doc.isEqual(r[o].doc))return!1;return!0}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class uE{constructor(){this.wa=void 0,this.Sa=[]}ba(){return this.Sa.some(e=>e.Da())}}class dE{constructor(){this.queries=_f(),this.onlineState="Unknown",this.Ca=new Set}terminate(){(function(t,r){const o=re(t),i=o.queries;o.queries=_f(),i.forEach((s,c)=>{for(const d of c.Sa)d.onError(r)})})(this,new H(F.ABORTED,"Firestore shutting down"))}}function _f(){return new Hr(n=>Pg(n),il)}async function Pu(n,e){const t=re(n);let r=3;const o=e.query;let i=t.queries.get(o);i?!i.ba()&&e.Da()&&(r=2):(i=new uE,r=e.Da()?0:1);try{switch(r){case 0:i.wa=await t.onListen(o,!0);break;case 1:i.wa=await t.onListen(o,!1);break;case 2:await t.onFirstRemoteStoreListen(o)}}catch(s){const c=ku(s,`Initialization of query '${oo(e.query)}' failed`);return void e.onError(c)}t.queries.set(o,i),i.Sa.push(e),e.va(t.onlineState),i.wa&&e.Fa(i.wa)&&Ru(t)}async function Cu(n,e){const t=re(n),r=e.query;let o=3;const i=t.queries.get(r);if(i){const s=i.Sa.indexOf(e);s>=0&&(i.Sa.splice(s,1),i.Sa.length===0?o=e.Da()?0:1:!i.ba()&&e.Da()&&(o=2))}switch(o){case 0:return t.queries.delete(r),t.onUnlisten(r,!0);case 1:return t.queries.delete(r),t.onUnlisten(r,!1);case 2:return t.onLastRemoteStoreUnlisten(r);default:return}}function hE(n,e){const t=re(n);let r=!1;for(const o of e){const i=o.query,s=t.queries.get(i);if(s){for(const c of s.Sa)c.Fa(o)&&(r=!0);s.wa=o}}r&&Ru(t)}function fE(n,e,t){const r=re(n),o=r.queries.get(e);if(o)for(const i of o.Sa)i.onError(t);r.queries.delete(e)}function Ru(n){n.Ca.forEach(e=>{e.next()})}var xc,bf;(bf=xc||(xc={})).Ma="default",bf.Cache="cache";class Ou{constructor(e,t,r){this.query=e,this.xa=t,this.Oa=!1,this.Na=null,this.onlineState="Unknown",this.options=r||{}}Fa(e){if(!this.options.includeMetadataChanges){const r=[];for(const o of e.docChanges)o.type!==3&&r.push(o);e=new Oo(e.query,e.docs,e.oldDocs,r,e.mutatedKeys,e.fromCache,e.syncStateChanged,!0,e.hasCachedResults)}let t=!1;return this.Oa?this.Ba(e)&&(this.xa.next(e),t=!0):this.La(e,this.onlineState)&&(this.ka(e),t=!0),this.Na=e,t}onError(e){this.xa.error(e)}va(e){this.onlineState=e;let t=!1;return this.Na&&!this.Oa&&this.La(this.Na,e)&&(this.ka(this.Na),t=!0),t}La(e,t){if(!e.fromCache||!this.Da())return!0;const r=t!=="Offline";return(!this.options.qa||!r)&&(!e.docs.isEmpty()||e.hasCachedResults||t==="Offline")}Ba(e){if(e.docChanges.length>0)return!0;const t=this.Na&&this.Na.hasPendingWrites!==e.hasPendingWrites;return!(!e.syncStateChanged&&!t)&&this.options.includeMetadataChanges===!0}ka(e){e=Oo.fromInitialDocuments(e.query,e.docs,e.mutatedKeys,e.fromCache,e.hasCachedResults),this.Oa=!0,this.xa.next(e)}Da(){return this.options.source!==xc.Cache}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class hm{constructor(e){this.key=e}}class fm{constructor(e){this.key=e}}class pE{constructor(e,t){this.query=e,this.Za=t,this.Xa=null,this.hasCachedResults=!1,this.current=!1,this.Ya=ue(),this.mutatedKeys=ue(),this.eu=Cg(e),this.tu=new go(this.eu)}get nu(){return this.Za}ru(e,t){const r=t?t.iu:new vf,o=t?t.tu:this.tu;let i=t?t.mutatedKeys:this.mutatedKeys,s=o,c=!1;const d=this.query.limitType==="F"&&o.size===this.query.limit?o.last():null,u=this.query.limitType==="L"&&o.size===this.query.limit?o.first():null;if(e.inorderTraversal((f,g)=>{const m=o.get(f),v=sl(this.query,g)?g:null,L=!!m&&this.mutatedKeys.has(m.key),P=!!v&&(v.hasLocalMutations||this.mutatedKeys.has(v.key)&&v.hasCommittedMutations);let M=!1;m&&v?m.data.isEqual(v.data)?L!==P&&(r.track({type:3,doc:v}),M=!0):this.su(m,v)||(r.track({type:2,doc:v}),M=!0,(d&&this.eu(v,d)>0||u&&this.eu(v,u)<0)&&(c=!0)):!m&&v?(r.track({type:0,doc:v}),M=!0):m&&!v&&(r.track({type:1,doc:m}),M=!0,(d||u)&&(c=!0)),M&&(v?(s=s.add(v),i=P?i.add(f):i.delete(f)):(s=s.delete(f),i=i.delete(f)))}),this.query.limit!==null)for(;s.size>this.query.limit;){const f=this.query.limitType==="F"?s.last():s.first();s=s.delete(f.key),i=i.delete(f.key),r.track({type:1,doc:f})}return{tu:s,iu:r,bs:c,mutatedKeys:i}}su(e,t){return e.hasLocalMutations&&t.hasCommittedMutations&&!t.hasLocalMutations}applyChanges(e,t,r,o){const i=this.tu;this.tu=e.tu,this.mutatedKeys=e.mutatedKeys;const s=e.iu.ya();s.sort((f,g)=>function(v,L){const P=M=>{switch(M){case 0:return 1;case 2:case 3:return 2;case 1:return 0;default:return ee(20277,{Vt:M})}};return P(v)-P(L)}(f.type,g.type)||this.eu(f.doc,g.doc)),this.ou(r),o=o??!1;const c=t&&!o?this._u():[],d=this.Ya.size===0&&this.current&&!o?1:0,u=d!==this.Xa;return this.Xa=d,s.length!==0||u?{snapshot:new Oo(this.query,e.tu,i,s,e.mutatedKeys,d===0,u,!1,!!r&&r.resumeToken.approximateByteSize()>0),au:c}:{au:c}}va(e){return this.current&&e==="Offline"?(this.current=!1,this.applyChanges({tu:this.tu,iu:new vf,mutatedKeys:this.mutatedKeys,bs:!1},!1)):{au:[]}}uu(e){return!this.Za.has(e)&&!!this.tu.has(e)&&!this.tu.get(e).hasLocalMutations}ou(e){e&&(e.addedDocuments.forEach(t=>this.Za=this.Za.add(t)),e.modifiedDocuments.forEach(t=>{}),e.removedDocuments.forEach(t=>this.Za=this.Za.delete(t)),this.current=e.current)}_u(){if(!this.current)return[];const e=this.Ya;this.Ya=ue(),this.tu.forEach(r=>{this.uu(r.key)&&(this.Ya=this.Ya.add(r.key))});const t=[];return e.forEach(r=>{this.Ya.has(r)||t.push(new fm(r))}),this.Ya.forEach(r=>{e.has(r)||t.push(new hm(r))}),t}cu(e){this.Za=e.ks,this.Ya=ue();const t=this.ru(e.documents);return this.applyChanges(t,!0)}lu(){return Oo.fromInitialDocuments(this.query,this.tu,this.mutatedKeys,this.Xa===0,this.hasCachedResults)}}const Nu="SyncEngine";class gE{constructor(e,t,r){this.query=e,this.targetId=t,this.view=r}}class mE{constructor(e){this.key=e,this.hu=!1}}class yE{constructor(e,t,r,o,i,s){this.localStore=e,this.remoteStore=t,this.eventManager=r,this.sharedClientState=o,this.currentUser=i,this.maxConcurrentLimboResolutions=s,this.Pu={},this.Tu=new Hr(c=>Pg(c),il),this.Eu=new Map,this.Iu=new Set,this.Ru=new Ne(Q.comparator),this.Au=new Map,this.Vu=new _u,this.du={},this.mu=new Map,this.fu=Ro.ar(),this.onlineState="Unknown",this.gu=void 0}get isPrimaryClient(){return this.gu===!0}}async function vE(n,e,t=!0){const r=_m(n);let o;const i=r.Tu.get(e);return i?(r.sharedClientState.addLocalQueryTarget(i.targetId),o=i.view.lu()):o=await pm(r,e,t,!0),o}async function _E(n,e){const t=_m(n);await pm(t,e,!0,!1)}async function pm(n,e,t,r){const o=await F0(n.localStore,sn(e)),i=o.targetId,s=n.sharedClientState.addLocalQueryTarget(i,t);let c;return r&&(c=await bE(n,e,i,s==="current",o.resumeToken)),n.isPrimaryClient&&t&&sm(n.remoteStore,o),c}async function bE(n,e,t,r,o){n.pu=(g,m,v)=>async function(P,M,G,$){let D=M.view.ru(G);D.bs&&(D=await hf(P.localStore,M.query,!1).then(({documents:I})=>M.view.ru(I,D)));const j=$&&$.targetChanges.get(M.targetId),V=$&&$.targetMismatches.get(M.targetId)!=null,B=M.view.applyChanges(D,P.isPrimaryClient,j,V);return Tf(P,M.targetId,B.au),B.snapshot}(n,g,m,v);const i=await hf(n.localStore,e,!0),s=new pE(e,i.ks),c=s.ru(i.documents),d=vs.createSynthesizedTargetChangeForCurrentChange(t,r&&n.onlineState!=="Offline",o),u=s.applyChanges(c,n.isPrimaryClient,d);Tf(n,t,u.au);const f=new gE(e,t,s);return n.Tu.set(e,f),n.Eu.has(t)?n.Eu.get(t).push(e):n.Eu.set(t,[e]),u.snapshot}async function wE(n,e,t){const r=re(n),o=r.Tu.get(e),i=r.Eu.get(o.targetId);if(i.length>1)return r.Eu.set(o.targetId,i.filter(s=>!il(s,e))),void r.Tu.delete(e);r.isPrimaryClient?(r.sharedClientState.removeLocalQueryTarget(o.targetId),r.sharedClientState.isActiveQueryTarget(o.targetId)||await Ic(r.localStore,o.targetId,!1).then(()=>{r.sharedClientState.clearQueryState(o.targetId),t&&Eu(r.remoteStore,o.targetId),Ac(r,o.targetId)}).catch(Bo)):(Ac(r,o.targetId),await Ic(r.localStore,o.targetId,!0))}async function TE(n,e){const t=re(n),r=t.Tu.get(e),o=t.Eu.get(r.targetId);t.isPrimaryClient&&o.length===1&&(t.sharedClientState.removeLocalQueryTarget(r.targetId),Eu(t.remoteStore,r.targetId))}async function EE(n,e,t){const r=CE(n);try{const o=await function(s,c){const d=re(s),u=Pe.now(),f=c.reduce((v,L)=>v.add(L.key),ue());let g,m;return d.persistence.runTransaction("Locally write mutations","readwrite",v=>{let L=Rn(),P=ue();return d.xs.getEntries(v,f).next(M=>{L=M,L.forEach((G,$)=>{$.isValidDocument()||(P=P.add(G))})}).next(()=>d.localDocuments.getOverlayedDocuments(v,L)).next(M=>{g=M;const G=[];for(const $ of c){const D=VT($,g.get($.key).overlayedDocument);D!=null&&G.push(new fr($.key,D,wg(D.value.mapValue),Bt.exists(!0)))}return d.mutationQueue.addMutationBatch(v,u,G,c)}).next(M=>{m=M;const G=M.applyToLocalDocumentSet(g,P);return d.documentOverlayCache.saveOverlays(v,M.batchId,G)})}).then(()=>({batchId:m.batchId,changes:Og(g)}))}(r.localStore,e);r.sharedClientState.addPendingMutation(o.batchId),function(s,c,d){let u=s.du[s.currentUser.toKey()];u||(u=new Ne(ce)),u=u.insert(c,d),s.du[s.currentUser.toKey()]=u}(r,o.batchId,t),await bs(r,o.changes),await hl(r.remoteStore)}catch(o){const i=ku(o,"Failed to persist write");t.reject(i)}}async function gm(n,e){const t=re(n);try{const r=await M0(t.localStore,e);e.targetChanges.forEach((o,i)=>{const s=t.Au.get(i);s&&(we(o.addedDocuments.size+o.modifiedDocuments.size+o.removedDocuments.size<=1,22616),o.addedDocuments.size>0?s.hu=!0:o.modifiedDocuments.size>0?we(s.hu,14607):o.removedDocuments.size>0&&(we(s.hu,42227),s.hu=!1))}),await bs(t,r,e)}catch(r){await Bo(r)}}function wf(n,e,t){const r=re(n);if(r.isPrimaryClient&&t===0||!r.isPrimaryClient&&t===1){const o=[];r.Tu.forEach((i,s)=>{const c=s.view.va(e);c.snapshot&&o.push(c.snapshot)}),function(s,c){const d=re(s);d.onlineState=c;let u=!1;d.queries.forEach((f,g)=>{for(const m of g.Sa)m.va(c)&&(u=!0)}),u&&Ru(d)}(r.eventManager,e),o.length&&r.Pu.H_(o),r.onlineState=e,r.isPrimaryClient&&r.sharedClientState.setOnlineState(e)}}async function IE(n,e,t){const r=re(n);r.sharedClientState.updateQueryState(e,"rejected",t);const o=r.Au.get(e),i=o&&o.key;if(i){let s=new Ne(Q.comparator);s=s.insert(i,dt.newNoDocument(i,ne.min()));const c=ue().add(i),d=new cl(ne.min(),new Map,new Ne(ce),s,c);await gm(r,d),r.Ru=r.Ru.remove(i),r.Au.delete(e),Lu(r)}else await Ic(r.localStore,e,!1).then(()=>Ac(r,e,t)).catch(Bo)}async function SE(n,e){const t=re(n),r=e.batch.batchId;try{const o=await L0(t.localStore,e);ym(t,r,null),mm(t,r),t.sharedClientState.updateMutationState(r,"acknowledged"),await bs(t,o)}catch(o){await Bo(o)}}async function xE(n,e,t){const r=re(n);try{const o=await function(s,c){const d=re(s);return d.persistence.runTransaction("Reject batch","readwrite-primary",u=>{let f;return d.mutationQueue.lookupMutationBatch(u,c).next(g=>(we(g!==null,37113),f=g.keys(),d.mutationQueue.removeMutationBatch(u,g))).next(()=>d.mutationQueue.performConsistencyCheck(u)).next(()=>d.documentOverlayCache.removeOverlaysForBatchId(u,f,c)).next(()=>d.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(u,f)).next(()=>d.localDocuments.getDocuments(u,f))})}(r.localStore,e);ym(r,e,t),mm(r,e),r.sharedClientState.updateMutationState(e,"rejected",t),await bs(r,o)}catch(o){await Bo(o)}}function mm(n,e){(n.mu.get(e)||[]).forEach(t=>{t.resolve()}),n.mu.delete(e)}function ym(n,e,t){const r=re(n);let o=r.du[r.currentUser.toKey()];if(o){const i=o.get(e);i&&(t?i.reject(t):i.resolve(),o=o.remove(e)),r.du[r.currentUser.toKey()]=o}}function Ac(n,e,t=null){n.sharedClientState.removeLocalQueryTarget(e);for(const r of n.Eu.get(e))n.Tu.delete(r),t&&n.Pu.yu(r,t);n.Eu.delete(e),n.isPrimaryClient&&n.Vu.Gr(e).forEach(r=>{n.Vu.containsKey(r)||vm(n,r)})}function vm(n,e){n.Iu.delete(e.path.canonicalString());const t=n.Ru.get(e);t!==null&&(Eu(n.remoteStore,t),n.Ru=n.Ru.remove(e),n.Au.delete(t),Lu(n))}function Tf(n,e,t){for(const r of t)r instanceof hm?(n.Vu.addReference(r.key,e),AE(n,r)):r instanceof fm?(Y(Nu,"Document no longer in limbo: "+r.key),n.Vu.removeReference(r.key,e),n.Vu.containsKey(r.key)||vm(n,r.key)):ee(19791,{wu:r})}function AE(n,e){const t=e.key,r=t.path.canonicalString();n.Ru.get(t)||n.Iu.has(r)||(Y(Nu,"New document in limbo: "+t),n.Iu.add(r),Lu(n))}function Lu(n){for(;n.Iu.size>0&&n.Ru.size<n.maxConcurrentLimboResolutions;){const e=n.Iu.values().next().value;n.Iu.delete(e);const t=new Q(Se.fromString(e)),r=n.fu.next();n.Au.set(r,new mE(t)),n.Ru=n.Ru.insert(t,r),sm(n.remoteStore,new Yn(sn(ol(t.path)),r,"TargetPurposeLimboResolution",tl.ce))}}async function bs(n,e,t){const r=re(n),o=[],i=[],s=[];r.Tu.isEmpty()||(r.Tu.forEach((c,d)=>{s.push(r.pu(d,e,t).then(u=>{var f;if((u||t)&&r.isPrimaryClient){const g=u?!u.fromCache:(f=t==null?void 0:t.targetChanges.get(d.targetId))==null?void 0:f.current;r.sharedClientState.updateQueryState(d.targetId,g?"current":"not-current")}if(u){o.push(u);const g=wu.Is(d.targetId,u);i.push(g)}}))}),await Promise.all(s),r.Pu.H_(o),await async function(d,u){const f=re(d);try{await f.persistence.runTransaction("notifyLocalViewChanges","readwrite",g=>U.forEach(u,m=>U.forEach(m.Ts,v=>f.persistence.referenceDelegate.addReference(g,m.targetId,v)).next(()=>U.forEach(m.Es,v=>f.persistence.referenceDelegate.removeReference(g,m.targetId,v)))))}catch(g){if(!$o(g))throw g;Y(Tu,"Failed to update sequence numbers: "+g)}for(const g of u){const m=g.targetId;if(!g.fromCache){const v=f.vs.get(m),L=v.snapshotVersion,P=v.withLastLimboFreeSnapshotVersion(L);f.vs=f.vs.insert(m,P)}}}(r.localStore,i))}async function kE(n,e){const t=re(n);if(!t.currentUser.isEqual(e)){Y(Nu,"User change. New user:",e.toKey());const r=await nm(t.localStore,e);t.currentUser=e,function(i,s){i.mu.forEach(c=>{c.forEach(d=>{d.reject(new H(F.CANCELLED,s))})}),i.mu.clear()}(t,"'waitForPendingWrites' promise is rejected due to a user change."),t.sharedClientState.handleUserChange(e,r.removedBatchIds,r.addedBatchIds),await bs(t,r.Ns)}}function PE(n,e){const t=re(n),r=t.Au.get(e);if(r&&r.hu)return ue().add(r.key);{let o=ue();const i=t.Eu.get(e);if(!i)return o;for(const s of i){const c=t.Tu.get(s);o=o.unionWith(c.view.nu)}return o}}function _m(n){const e=re(n);return e.remoteStore.remoteSyncer.applyRemoteEvent=gm.bind(null,e),e.remoteStore.remoteSyncer.getRemoteKeysForTarget=PE.bind(null,e),e.remoteStore.remoteSyncer.rejectListen=IE.bind(null,e),e.Pu.H_=hE.bind(null,e.eventManager),e.Pu.yu=fE.bind(null,e.eventManager),e}function CE(n){const e=re(n);return e.remoteStore.remoteSyncer.applySuccessfulWrite=SE.bind(null,e),e.remoteStore.remoteSyncer.rejectFailedWrite=xE.bind(null,e),e}class Ma{constructor(){this.kind="memory",this.synchronizeTabs=!1}async initialize(e){this.serializer=ul(e.databaseInfo.databaseId),this.sharedClientState=this.Du(e),this.persistence=this.Cu(e),await this.persistence.start(),this.localStore=this.vu(e),this.gcScheduler=this.Fu(e,this.localStore),this.indexBackfillerScheduler=this.Mu(e,this.localStore)}Fu(e,t){return null}Mu(e,t){return null}vu(e){return N0(this.persistence,new C0,e.initialUser,this.serializer)}Cu(e){return new tm(bu.Vi,this.serializer)}Du(e){return new q0}async terminate(){var e,t;(e=this.gcScheduler)==null||e.stop(),(t=this.indexBackfillerScheduler)==null||t.stop(),this.sharedClientState.shutdown(),await this.persistence.shutdown()}}Ma.provider={build:()=>new Ma};class RE extends Ma{constructor(e){super(),this.cacheSizeBytes=e}Fu(e,t){we(this.persistence.referenceDelegate instanceof Na,46915);const r=this.persistence.referenceDelegate.garbageCollector;return new g0(r,e.asyncQueue,t)}Cu(e){const t=this.cacheSizeBytes!==void 0?vt.withCacheSize(this.cacheSizeBytes):vt.DEFAULT;return new tm(r=>Na.Vi(r,t),this.serializer)}}class kc{async initialize(e,t){this.localStore||(this.localStore=e.localStore,this.sharedClientState=e.sharedClientState,this.datastore=this.createDatastore(t),this.remoteStore=this.createRemoteStore(t),this.eventManager=this.createEventManager(t),this.syncEngine=this.createSyncEngine(t,!e.synchronizeTabs),this.sharedClientState.onlineStateHandler=r=>wf(this.syncEngine,r,1),this.remoteStore.remoteSyncer.handleCredentialChange=kE.bind(null,this.syncEngine),await cE(this.remoteStore,this.syncEngine.isPrimaryClient))}createEventManager(e){return function(){return new dE}()}createDatastore(e){const t=ul(e.databaseInfo.databaseId),r=W0(e.databaseInfo);return X0(e.authCredentials,e.appCheckCredentials,r,t)}createRemoteStore(e){return function(r,o,i,s,c){return new J0(r,o,i,s,c)}(this.localStore,this.datastore,e.asyncQueue,t=>wf(this.syncEngine,t,0),function(){return gf.v()?new gf:new B0}())}createSyncEngine(e,t){return function(o,i,s,c,d,u,f){const g=new yE(o,i,s,c,d,u);return f&&(g.gu=!0),g}(this.localStore,this.remoteStore,this.eventManager,this.sharedClientState,e.initialUser,e.maxConcurrentLimboResolutions,t)}async terminate(){var e,t;await async function(o){const i=re(o);Y(qr,"RemoteStore shutting down."),i.Ia.add(5),await _s(i),i.Aa.shutdown(),i.Va.set("Unknown")}(this.remoteStore),(e=this.datastore)==null||e.terminate(),(t=this.eventManager)==null||t.terminate()}}kc.provider={build:()=>new kc};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Mu{constructor(e){this.observer=e,this.muted=!1}next(e){this.muted||this.observer.next&&this.Ou(this.observer.next,e)}error(e){this.muted||(this.observer.error?this.Ou(this.observer.error,e):Cn("Uncaught Error in snapshot listener:",e.toString()))}Nu(){this.muted=!0}Ou(e,t){setTimeout(()=>{this.muted||e(t)},0)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const cr="FirestoreClient";class OE{constructor(e,t,r,o,i){this.authCredentials=e,this.appCheckCredentials=t,this.asyncQueue=r,this._databaseInfo=o,this.user=ct.UNAUTHENTICATED,this.clientId=lu.newId(),this.authCredentialListener=()=>Promise.resolve(),this.appCheckCredentialListener=()=>Promise.resolve(),this._uninitializedComponentsProvider=i,this.authCredentials.start(r,async s=>{Y(cr,"Received user=",s.uid),await this.authCredentialListener(s),this.user=s}),this.appCheckCredentials.start(r,s=>(Y(cr,"Received new app check token=",s),this.appCheckCredentialListener(s,this.user)))}get configuration(){return{asyncQueue:this.asyncQueue,databaseInfo:this._databaseInfo,clientId:this.clientId,authCredentials:this.authCredentials,appCheckCredentials:this.appCheckCredentials,initialUser:this.user,maxConcurrentLimboResolutions:100}}setCredentialChangeListener(e){this.authCredentialListener=e}setAppCheckTokenChangeListener(e){this.appCheckCredentialListener=e}terminate(){this.asyncQueue.enterRestrictedMode();const e=new In;return this.asyncQueue.enqueueAndForgetEvenWhileRestricted(async()=>{try{this._onlineComponents&&await this._onlineComponents.terminate(),this._offlineComponents&&await this._offlineComponents.terminate(),this.authCredentials.shutdown(),this.appCheckCredentials.shutdown(),e.resolve()}catch(t){const r=ku(t,"Failed to shutdown persistence");e.reject(r)}}),e.promise}}async function Yl(n,e){n.asyncQueue.verifyOperationInProgress(),Y(cr,"Initializing OfflineComponentProvider");const t=n.configuration;await e.initialize(t);let r=t.initialUser;n.setCredentialChangeListener(async o=>{r.isEqual(o)||(await nm(e.localStore,o),r=o)}),e.persistence.setDatabaseDeletedListener(()=>n.terminate()),n._offlineComponents=e}async function Ef(n,e){n.asyncQueue.verifyOperationInProgress();const t=await NE(n);Y(cr,"Initializing OnlineComponentProvider"),await e.initialize(t,n.configuration),n.setCredentialChangeListener(r=>yf(e.remoteStore,r)),n.setAppCheckTokenChangeListener((r,o)=>yf(e.remoteStore,o)),n._onlineComponents=e}async function NE(n){if(!n._offlineComponents)if(n._uninitializedComponentsProvider){Y(cr,"Using user provided OfflineComponentProvider");try{await Yl(n,n._uninitializedComponentsProvider._offline)}catch(e){const t=e;if(!function(o){return o.name==="FirebaseError"?o.code===F.FAILED_PRECONDITION||o.code===F.UNIMPLEMENTED:!(typeof DOMException<"u"&&o instanceof DOMException)||o.code===22||o.code===20||o.code===11}(t))throw t;Ur("Error using user provided cache. Falling back to memory cache: "+t),await Yl(n,new Ma)}}else Y(cr,"Using default OfflineComponentProvider"),await Yl(n,new RE(void 0));return n._offlineComponents}async function bm(n){return n._onlineComponents||(n._uninitializedComponentsProvider?(Y(cr,"Using user provided OnlineComponentProvider"),await Ef(n,n._uninitializedComponentsProvider._online)):(Y(cr,"Using default OnlineComponentProvider"),await Ef(n,new kc))),n._onlineComponents}function LE(n){return bm(n).then(e=>e.syncEngine)}async function Da(n){const e=await bm(n),t=e.eventManager;return t.onListen=vE.bind(null,e.syncEngine),t.onUnlisten=wE.bind(null,e.syncEngine),t.onFirstRemoteStoreListen=_E.bind(null,e.syncEngine),t.onLastRemoteStoreUnlisten=TE.bind(null,e.syncEngine),t}function ME(n,e,t,r){const o=new Mu(r),i=new Ou(e,o,t);return n.asyncQueue.enqueueAndForget(async()=>Pu(await Da(n),i)),()=>{o.Nu(),n.asyncQueue.enqueueAndForget(async()=>Cu(await Da(n),i))}}function DE(n,e,t={}){const r=new In;return n.asyncQueue.enqueueAndForget(async()=>function(i,s,c,d,u){const f=new Mu({next:m=>{f.Nu(),s.enqueueAndForget(()=>Cu(i,g));const v=m.docs.has(c);!v&&m.fromCache?u.reject(new H(F.UNAVAILABLE,"Failed to get document because the client is offline.")):v&&m.fromCache&&d&&d.source==="server"?u.reject(new H(F.UNAVAILABLE,'Failed to get document from server. (However, this document does exist in the local cache. Run again without setting source to "server" to retrieve the cached document.)')):u.resolve(m)},error:m=>u.reject(m)}),g=new Ou(ol(c.path),f,{includeMetadataChanges:!0,qa:!0});return Pu(i,g)}(await Da(n),n.asyncQueue,e,t,r)),r.promise}function VE(n,e,t={}){const r=new In;return n.asyncQueue.enqueueAndForget(async()=>function(i,s,c,d,u){const f=new Mu({next:m=>{f.Nu(),s.enqueueAndForget(()=>Cu(i,g)),m.fromCache&&d.source==="server"?u.reject(new H(F.UNAVAILABLE,'Failed to get documents from server. (However, these documents may exist in the local cache. Run again without setting source to "server" to retrieve the cached documents.)')):u.resolve(m)},error:m=>u.reject(m)}),g=new Ou(c,f,{includeMetadataChanges:!0,qa:!0});return Pu(i,g)}(await Da(n),n.asyncQueue,e,t,r)),r.promise}function FE(n,e){const t=new In;return n.asyncQueue.enqueueAndForget(async()=>EE(await LE(n),e,t)),t.promise}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function wm(n){const e={};return n.timeoutSeconds!==void 0&&(e.timeoutSeconds=n.timeoutSeconds),e}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const UE="ComponentProvider",If=new Map;function qE(n,e,t,r,o){return new sT(n,e,t,o.host,o.ssl,o.experimentalForceLongPolling,o.experimentalAutoDetectLongPolling,wm(o.experimentalLongPollingOptions),o.useFetchStreams,o.isUsingEmulator,r)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Tm="firestore.googleapis.com",Sf=!0;class xf{constructor(e){if(e.host===void 0){if(e.ssl!==void 0)throw new H(F.INVALID_ARGUMENT,"Can't provide ssl option if host option is not set");this.host=Tm,this.ssl=Sf}else this.host=e.host,this.ssl=e.ssl??Sf;if(this.isUsingEmulator=e.emulatorOptions!==void 0,this.credentials=e.credentials,this.ignoreUndefinedProperties=!!e.ignoreUndefinedProperties,this.localCache=e.localCache,e.cacheSizeBytes===void 0)this.cacheSizeBytes=em;else{if(e.cacheSizeBytes!==-1&&e.cacheSizeBytes<f0)throw new H(F.INVALID_ARGUMENT,"cacheSizeBytes must be at least 1048576");this.cacheSizeBytes=e.cacheSizeBytes}Yw("experimentalForceLongPolling",e.experimentalForceLongPolling,"experimentalAutoDetectLongPolling",e.experimentalAutoDetectLongPolling),this.experimentalForceLongPolling=!!e.experimentalForceLongPolling,this.experimentalForceLongPolling?this.experimentalAutoDetectLongPolling=!1:e.experimentalAutoDetectLongPolling===void 0?this.experimentalAutoDetectLongPolling=!0:this.experimentalAutoDetectLongPolling=!!e.experimentalAutoDetectLongPolling,this.experimentalLongPollingOptions=wm(e.experimentalLongPollingOptions??{}),function(r){if(r.timeoutSeconds!==void 0){if(isNaN(r.timeoutSeconds))throw new H(F.INVALID_ARGUMENT,`invalid long polling timeout: ${r.timeoutSeconds} (must not be NaN)`);if(r.timeoutSeconds<5)throw new H(F.INVALID_ARGUMENT,`invalid long polling timeout: ${r.timeoutSeconds} (minimum allowed value is 5)`);if(r.timeoutSeconds>30)throw new H(F.INVALID_ARGUMENT,`invalid long polling timeout: ${r.timeoutSeconds} (maximum allowed value is 30)`)}}(this.experimentalLongPollingOptions),this.useFetchStreams=!!e.useFetchStreams}isEqual(e){return this.host===e.host&&this.ssl===e.ssl&&this.credentials===e.credentials&&this.cacheSizeBytes===e.cacheSizeBytes&&this.experimentalForceLongPolling===e.experimentalForceLongPolling&&this.experimentalAutoDetectLongPolling===e.experimentalAutoDetectLongPolling&&function(r,o){return r.timeoutSeconds===o.timeoutSeconds}(this.experimentalLongPollingOptions,e.experimentalLongPollingOptions)&&this.ignoreUndefinedProperties===e.ignoreUndefinedProperties&&this.useFetchStreams===e.useFetchStreams}}class fl{constructor(e,t,r,o){this._authCredentials=e,this._appCheckCredentials=t,this._databaseId=r,this._app=o,this.type="firestore-lite",this._persistenceKey="(lite)",this._settings=new xf({}),this._settingsFrozen=!1,this._emulatorOptions={},this._terminateTask="notTerminated"}get app(){if(!this._app)throw new H(F.FAILED_PRECONDITION,"Firestore was not initialized using the Firebase SDK. 'app' is not available");return this._app}get _initialized(){return this._settingsFrozen}get _terminated(){return this._terminateTask!=="notTerminated"}_setSettings(e){if(this._settingsFrozen)throw new H(F.FAILED_PRECONDITION,"Firestore has already been started and its settings can no longer be changed. You can only modify settings before calling any other methods on a Firestore object.");this._settings=new xf(e),this._emulatorOptions=e.emulatorOptions||{},e.credentials!==void 0&&(this._authCredentials=function(r){if(!r)return new Fw;switch(r.type){case"firstParty":return new $w(r.sessionIndex||"0",r.iamToken||null,r.authTokenFactory||null);case"provider":return r.client;default:throw new H(F.INVALID_ARGUMENT,"makeAuthCredentialsProvider failed due to invalid credential type")}}(e.credentials))}_getSettings(){return this._settings}_getEmulatorOptions(){return this._emulatorOptions}_freezeSettings(){return this._settingsFrozen=!0,this._settings}_delete(){return this._terminateTask==="notTerminated"&&(this._terminateTask=this._terminate()),this._terminateTask}async _restart(){this._terminateTask==="notTerminated"?await this._terminate():this._terminateTask="notTerminated"}toJSON(){return{app:this._app,databaseId:this._databaseId,settings:this._settings}}_terminate(){return function(t){const r=If.get(t);r&&(Y(UE,"Removing Datastore"),If.delete(t),r.terminate())}(this),Promise.resolve()}}function BE(n,e,t,r={}){var u;n=Ot(n,fl);const o=hs(e),i=n._getSettings(),s={...i,emulatorOptions:n._getEmulatorOptions()},c=`${e}:${t}`;o&&yp(`https://${c}`),i.host!==Tm&&i.host!==c&&Ur("Host has been set in both settings() and connectFirestoreEmulator(), emulator host will be used.");const d={...i,host:c,ssl:o,emulatorOptions:r};if(!Mr(d,s)&&(n._setSettings(d),r.mockUserToken)){let f,g;if(typeof r.mockUserToken=="string")f=r.mockUserToken,g=ct.MOCK_USER;else{f=uv(r.mockUserToken,(u=n._app)==null?void 0:u.options.projectId);const m=r.mockUserToken.sub||r.mockUserToken.user_id;if(!m)throw new H(F.INVALID_ARGUMENT,"mockUserToken must contain 'sub' or 'user_id' field!");g=new ct(m)}n._authCredentials=new Uw(new cg(f,g))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ln{constructor(e,t,r){this.converter=t,this._query=r,this.type="query",this.firestore=e}withConverter(e){return new Ln(this.firestore,e,this._query)}}class De{constructor(e,t,r){this.converter=t,this._key=r,this.type="document",this.firestore=e}get _path(){return this._key.path}get id(){return this._key.path.lastSegment()}get path(){return this._key.path.canonicalString()}get parent(){return new er(this.firestore,this.converter,this._key.path.popLast())}withConverter(e){return new De(this.firestore,e,this._key)}toJSON(){return{type:De._jsonSchemaVersion,referencePath:this._key.toString()}}static fromJSON(e,t,r){if(ms(t,De._jsonSchema))return new De(e,r||null,new Q(Se.fromString(t.referencePath)))}}De._jsonSchemaVersion="firestore/documentReference/1.0",De._jsonSchema={type:We("string",De._jsonSchemaVersion),referencePath:We("string")};class er extends Ln{constructor(e,t,r){super(e,t,ol(r)),this._path=r,this.type="collection"}get id(){return this._query.path.lastSegment()}get path(){return this._query.path.canonicalString()}get parent(){const e=this._path.popLast();return e.isEmpty()?null:new De(this.firestore,null,new Q(e))}withConverter(e){return new er(this.firestore,e,this._path)}}function hn(n,e,...t){if(n=rt(n),ug("collection","path",e),n instanceof fl){const r=Se.fromString(e,...t);return Fh(r),new er(n,null,r)}{if(!(n instanceof De||n instanceof er))throw new H(F.INVALID_ARGUMENT,"Expected first argument to collection() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const r=n._path.child(Se.fromString(e,...t));return Fh(r),new er(n.firestore,null,r)}}function Ce(n,e,...t){if(n=rt(n),arguments.length===1&&(e=lu.newId()),ug("doc","path",e),n instanceof fl){const r=Se.fromString(e,...t);return Vh(r),new De(n,null,new Q(r))}{if(!(n instanceof De||n instanceof er))throw new H(F.INVALID_ARGUMENT,"Expected first argument to doc() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const r=n._path.child(Se.fromString(e,...t));return Vh(r),new De(n.firestore,n instanceof er?n.converter:null,new Q(r))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Af="AsyncQueue";class kf{constructor(e=Promise.resolve()){this.Yu=[],this.ec=!1,this.tc=[],this.nc=null,this.rc=!1,this.sc=!1,this.oc=[],this.M_=new om(this,"async_queue_retry"),this._c=()=>{const r=Gl();r&&Y(Af,"Visibility state changed to "+r.visibilityState),this.M_.w_()},this.ac=e;const t=Gl();t&&typeof t.addEventListener=="function"&&t.addEventListener("visibilitychange",this._c)}get isShuttingDown(){return this.ec}enqueueAndForget(e){this.enqueue(e)}enqueueAndForgetEvenWhileRestricted(e){this.uc(),this.cc(e)}enterRestrictedMode(e){if(!this.ec){this.ec=!0,this.sc=e||!1;const t=Gl();t&&typeof t.removeEventListener=="function"&&t.removeEventListener("visibilitychange",this._c)}}enqueue(e){if(this.uc(),this.ec)return new Promise(()=>{});const t=new In;return this.cc(()=>this.ec&&this.sc?Promise.resolve():(e().then(t.resolve,t.reject),t.promise)).then(()=>t.promise)}enqueueRetryable(e){this.enqueueAndForget(()=>(this.Yu.push(e),this.lc()))}async lc(){if(this.Yu.length!==0){try{await this.Yu[0](),this.Yu.shift(),this.M_.reset()}catch(e){if(!$o(e))throw e;Y(Af,"Operation failed with retryable error: "+e)}this.Yu.length>0&&this.M_.p_(()=>this.lc())}}cc(e){const t=this.ac.then(()=>(this.rc=!0,e().catch(r=>{throw this.nc=r,this.rc=!1,Cn("INTERNAL UNHANDLED ERROR: ",Pf(r)),r}).then(r=>(this.rc=!1,r))));return this.ac=t,t}enqueueAfterDelay(e,t,r){this.uc(),this.oc.indexOf(e)>-1&&(t=0);const o=Au.createAndSchedule(this,e,t,r,i=>this.hc(i));return this.tc.push(o),o}uc(){this.nc&&ee(47125,{Pc:Pf(this.nc)})}verifyOperationInProgress(){}async Tc(){let e;do e=this.ac,await e;while(e!==this.ac)}Ec(e){for(const t of this.tc)if(t.timerId===e)return!0;return!1}Ic(e){return this.Tc().then(()=>{this.tc.sort((t,r)=>t.targetTimeMs-r.targetTimeMs);for(const t of this.tc)if(t.skipDelay(),e!=="all"&&t.timerId===e)break;return this.Tc()})}Rc(e){this.oc.push(e)}hc(e){const t=this.tc.indexOf(e);this.tc.splice(t,1)}}function Pf(n){let e=n.message||"";return n.stack&&(e=n.stack.includes(n.message)?n.stack:n.message+`
`+n.stack),e}class ur extends fl{constructor(e,t,r,o){super(e,t,r,o),this.type="firestore",this._queue=new kf,this._persistenceKey=(o==null?void 0:o.name)||"[DEFAULT]"}async _terminate(){if(this._firestoreClient){const e=this._firestoreClient.terminate();this._queue=new kf(e),this._firestoreClient=void 0,await e}}}function $E(n,e){const t=typeof n=="object"?n:bp(),r=typeof n=="string"?n:ka,o=Qc(t,"firestore").getImmediate({identifier:r});if(!o._initialized){const i=lv("firestore");i&&BE(o,...i)}return o}function pl(n){if(n._terminated)throw new H(F.FAILED_PRECONDITION,"The client has already been terminated.");return n._firestoreClient||jE(n),n._firestoreClient}function jE(n){var r,o,i,s;const e=n._freezeSettings(),t=qE(n._databaseId,((r=n._app)==null?void 0:r.options.appId)||"",n._persistenceKey,(o=n._app)==null?void 0:o.options.apiKey,e);n._componentsProvider||(i=e.localCache)!=null&&i._offlineComponentProvider&&((s=e.localCache)!=null&&s._onlineComponentProvider)&&(n._componentsProvider={_offline:e.localCache._offlineComponentProvider,_online:e.localCache._onlineComponentProvider}),n._firestoreClient=new OE(n._authCredentials,n._appCheckCredentials,n._queue,t,n._componentsProvider&&function(d){const u=d==null?void 0:d._online.build();return{_offline:d==null?void 0:d._offline.build(u),_online:u}}(n._componentsProvider))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Nt{constructor(e){this._byteString=e}static fromBase64String(e){try{return new Nt(at.fromBase64String(e))}catch(t){throw new H(F.INVALID_ARGUMENT,"Failed to construct data from Base64 string: "+t)}}static fromUint8Array(e){return new Nt(at.fromUint8Array(e))}toBase64(){return this._byteString.toBase64()}toUint8Array(){return this._byteString.toUint8Array()}toString(){return"Bytes(base64: "+this.toBase64()+")"}isEqual(e){return this._byteString.isEqual(e._byteString)}toJSON(){return{type:Nt._jsonSchemaVersion,bytes:this.toBase64()}}static fromJSON(e){if(ms(e,Nt._jsonSchema))return Nt.fromBase64String(e.bytes)}}Nt._jsonSchemaVersion="firestore/bytes/1.0",Nt._jsonSchema={type:We("string",Nt._jsonSchemaVersion),bytes:We("string")};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Du{constructor(...e){for(let t=0;t<e.length;++t)if(e[t].length===0)throw new H(F.INVALID_ARGUMENT,"Invalid field name at argument $(i + 1). Field names must not be empty.");this._internalPath=new it(e)}isEqual(e){return this._internalPath.isEqual(e._internalPath)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ws{constructor(e){this._methodName=e}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ln{constructor(e,t){if(!isFinite(e)||e<-90||e>90)throw new H(F.INVALID_ARGUMENT,"Latitude must be a number between -90 and 90, but was: "+e);if(!isFinite(t)||t<-180||t>180)throw new H(F.INVALID_ARGUMENT,"Longitude must be a number between -180 and 180, but was: "+t);this._lat=e,this._long=t}get latitude(){return this._lat}get longitude(){return this._long}isEqual(e){return this._lat===e._lat&&this._long===e._long}_compareTo(e){return ce(this._lat,e._lat)||ce(this._long,e._long)}toJSON(){return{latitude:this._lat,longitude:this._long,type:ln._jsonSchemaVersion}}static fromJSON(e){if(ms(e,ln._jsonSchema))return new ln(e.latitude,e.longitude)}}ln._jsonSchemaVersion="firestore/geoPoint/1.0",ln._jsonSchema={type:We("string",ln._jsonSchemaVersion),latitude:We("number"),longitude:We("number")};/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class $t{constructor(e){this._values=(e||[]).map(t=>t)}toArray(){return this._values.map(e=>e)}isEqual(e){return function(r,o){if(r.length!==o.length)return!1;for(let i=0;i<r.length;++i)if(r[i]!==o[i])return!1;return!0}(this._values,e._values)}toJSON(){return{type:$t._jsonSchemaVersion,vectorValues:this._values}}static fromJSON(e){if(ms(e,$t._jsonSchema)){if(Array.isArray(e.vectorValues)&&e.vectorValues.every(t=>typeof t=="number"))return new $t(e.vectorValues);throw new H(F.INVALID_ARGUMENT,"Expected 'vectorValues' field to be a number array")}}}$t._jsonSchemaVersion="firestore/vectorValue/1.0",$t._jsonSchema={type:We("string",$t._jsonSchemaVersion),vectorValues:We("object")};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const zE=/^__.*__$/;class WE{constructor(e,t,r){this.data=e,this.fieldMask=t,this.fieldTransforms=r}toMutation(e,t){return this.fieldMask!==null?new fr(e,this.data,this.fieldMask,t,this.fieldTransforms):new ys(e,this.data,t,this.fieldTransforms)}}class Em{constructor(e,t,r){this.data=e,this.fieldMask=t,this.fieldTransforms=r}toMutation(e,t){return new fr(e,this.data,this.fieldMask,t,this.fieldTransforms)}}function Im(n){switch(n){case 0:case 2:case 1:return!0;case 3:case 4:return!1;default:throw ee(40011,{dataSource:n})}}class Vu{constructor(e,t,r,o,i,s){this.settings=e,this.databaseId=t,this.serializer=r,this.ignoreUndefinedProperties=o,i===void 0&&this.Ac(),this.fieldTransforms=i||[],this.fieldMask=s||[]}get path(){return this.settings.path}get dataSource(){return this.settings.dataSource}i(e){return new Vu({...this.settings,...e},this.databaseId,this.serializer,this.ignoreUndefinedProperties,this.fieldTransforms,this.fieldMask)}dc(e){var o;const t=(o=this.path)==null?void 0:o.child(e),r=this.i({path:t,arrayElement:!1});return r.mc(e),r}fc(e){var o;const t=(o=this.path)==null?void 0:o.child(e),r=this.i({path:t,arrayElement:!1});return r.Ac(),r}gc(e){return this.i({path:void 0,arrayElement:!0})}yc(e){return Va(e,this.settings.methodName,this.settings.hasConverter||!1,this.path,this.settings.targetDoc)}contains(e){return this.fieldMask.find(t=>e.isPrefixOf(t))!==void 0||this.fieldTransforms.find(t=>e.isPrefixOf(t.field))!==void 0}Ac(){if(this.path)for(let e=0;e<this.path.length;e++)this.mc(this.path.get(e))}mc(e){if(e.length===0)throw this.yc("Document fields must not be empty");if(Im(this.dataSource)&&zE.test(e))throw this.yc('Document fields cannot begin and end with "__"')}}class HE{constructor(e,t,r){this.databaseId=e,this.ignoreUndefinedProperties=t,this.serializer=r||ul(e)}I(e,t,r,o=!1){return new Vu({dataSource:e,methodName:t,targetDoc:r,path:it.emptyPath(),arrayElement:!1,hasConverter:o},this.databaseId,this.serializer,this.ignoreUndefinedProperties)}}function Fu(n){const e=n._freezeSettings(),t=ul(n._databaseId);return new HE(n._databaseId,!!e.ignoreUndefinedProperties,t)}function GE(n,e,t,r,o,i={}){const s=n.I(i.merge||i.mergeFields?2:0,e,t,o);Bu("Data must be an object, but it was:",s,r);const c=Sm(r,s);let d,u;if(i.merge)d=new Rt(s.fieldMask),u=s.fieldTransforms;else if(i.mergeFields){const f=[];for(const g of i.mergeFields){const m=No(e,g,t);if(!s.contains(m))throw new H(F.INVALID_ARGUMENT,`Field '${m}' is specified in your field mask but missing from your input data.`);km(f,m)||f.push(m)}d=new Rt(f),u=s.fieldTransforms.filter(g=>d.covers(g.field))}else d=null,u=s.fieldTransforms;return new WE(new bt(c),d,u)}class gl extends ws{_toFieldTransform(e){if(e.dataSource!==2)throw e.dataSource===1?e.yc(`${this._methodName}() can only appear at the top level of your update data`):e.yc(`${this._methodName}() cannot be used with set() unless you pass {merge:true}`);return e.fieldMask.push(e.path),null}isEqual(e){return e instanceof gl}}class Uu extends ws{_toFieldTransform(e){return new qg(e.path,new Qi)}isEqual(e){return e instanceof Uu}}class qu extends ws{constructor(e,t){super(e),this.bc=t}_toFieldTransform(e){const t=new es(e.serializer,Mg(e.serializer,this.bc));return new qg(e.path,t)}isEqual(e){return e instanceof qu&&this.bc===e.bc}}function YE(n,e,t,r){const o=n.I(1,e,t);Bu("Data must be an object, but it was:",o,r);const i=[],s=bt.empty();hr(r,(d,u)=>{const f=Am(e,d,t);u=rt(u);const g=o.fc(f);if(u instanceof gl)i.push(f);else{const m=Ts(u,g);m!=null&&(i.push(f),s.set(f,m))}});const c=new Rt(i);return new Em(s,c,o.fieldTransforms)}function KE(n,e,t,r,o,i){const s=n.I(1,e,t),c=[No(e,r,t)],d=[o];if(i.length%2!=0)throw new H(F.INVALID_ARGUMENT,`Function ${e}() needs to be called with an even number of arguments that alternate between field names and values.`);for(let m=0;m<i.length;m+=2)c.push(No(e,i[m])),d.push(i[m+1]);const u=[],f=bt.empty();for(let m=c.length-1;m>=0;--m)if(!km(u,c[m])){const v=c[m];let L=d[m];L=rt(L);const P=s.fc(v);if(L instanceof gl)u.push(v);else{const M=Ts(L,P);M!=null&&(u.push(v),f.set(v,M))}}const g=new Rt(u);return new Em(f,g,s.fieldTransforms)}function XE(n,e,t,r=!1){return Ts(t,n.I(r?4:3,e))}function Ts(n,e){if(xm(n=rt(n)))return Bu("Unsupported field value:",e,n),Sm(n,e);if(n instanceof ws)return function(r,o){if(!Im(o.dataSource))throw o.yc(`${r._methodName}() can only be used with update() and set()`);if(!o.path)throw o.yc(`${r._methodName}() is not currently supported inside arrays`);const i=r._toFieldTransform(o);i&&o.fieldTransforms.push(i)}(n,e),null;if(n===void 0&&e.ignoreUndefinedProperties)return null;if(e.path&&e.fieldMask.push(e.path),n instanceof Array){if(e.settings.arrayElement&&e.dataSource!==4)throw e.yc("Nested arrays are not supported");return function(r,o){const i=[];let s=0;for(const c of r){let d=Ts(c,o.gc(s));d==null&&(d={nullValue:"NULL_VALUE"}),i.push(d),s++}return{arrayValue:{values:i}}}(n,e)}return function(r,o){if((r=rt(r))===null)return{nullValue:"NULL_VALUE"};if(typeof r=="number")return Mg(o.serializer,r);if(typeof r=="boolean")return{booleanValue:r};if(typeof r=="string")return{stringValue:r};if(r instanceof Date){const i=Pe.fromDate(r);return{timestampValue:Oa(o.serializer,i)}}if(r instanceof Pe){const i=new Pe(r.seconds,1e3*Math.floor(r.nanoseconds/1e3));return{timestampValue:Oa(o.serializer,i)}}if(r instanceof ln)return{geoPointValue:{latitude:r.latitude,longitude:r.longitude}};if(r instanceof Nt)return{bytesValue:Hg(o.serializer,r._byteString)};if(r instanceof De){const i=o.databaseId,s=r.firestore._databaseId;if(!s.isEqual(i))throw o.yc(`Document reference is for database ${s.projectId}/${s.database} but should be for database ${i.projectId}/${i.database}`);return{referenceValue:vu(r.firestore._databaseId||o.databaseId,r._key.path)}}if(r instanceof $t)return function(s,c){const d=s instanceof $t?s.toArray():s;return{mapValue:{fields:{[_g]:{stringValue:bg},[Pa]:{arrayValue:{values:d.map(f=>{if(typeof f!="number")throw c.yc("VectorValues must only contain numeric values.");return pu(c.serializer,f)})}}}}}}(r,o);if(Zg(r))return r._toProto(o.serializer);throw o.yc(`Unsupported field value: ${el(r)}`)}(n,e)}function Sm(n,e){const t={};return fg(n)?e.path&&e.path.length>0&&e.fieldMask.push(e.path):hr(n,(r,o)=>{const i=Ts(o,e.dc(r));i!=null&&(t[r]=i)}),{mapValue:{fields:t}}}function xm(n){return!(typeof n!="object"||n===null||n instanceof Array||n instanceof Date||n instanceof Pe||n instanceof ln||n instanceof Nt||n instanceof De||n instanceof ws||n instanceof $t||Zg(n))}function Bu(n,e,t){if(!xm(t)||!dg(t)){const r=el(t);throw r==="an object"?e.yc(n+" a custom object"):e.yc(n+" "+r)}}function No(n,e,t){if((e=rt(e))instanceof Du)return e._internalPath;if(typeof e=="string")return Am(n,e);throw Va("Field path arguments must be of type string or ",n,!1,void 0,t)}const QE=new RegExp("[~\\*/\\[\\]]");function Am(n,e,t){if(e.search(QE)>=0)throw Va(`Invalid field path (${e}). Paths must not contain '~', '*', '/', '[', or ']'`,n,!1,void 0,t);try{return new Du(...e.split("."))._internalPath}catch{throw Va(`Invalid field path (${e}). Paths must not be empty, begin with '.', end with '.', or contain '..'`,n,!1,void 0,t)}}function Va(n,e,t,r,o){const i=r&&!r.isEmpty(),s=o!==void 0;let c=`Function ${e}() called with invalid data`;t&&(c+=" (via `toFirestore()`)"),c+=". ";let d="";return(i||s)&&(d+=" (found",i&&(d+=` in field ${r}`),s&&(d+=` in document ${o}`),d+=")"),new H(F.INVALID_ARGUMENT,c+n+d)}function km(n,e){return n.some(t=>t.isEqual(e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class JE{convertValue(e,t="none"){switch(ar(e)){case 0:return null;case 1:return e.booleanValue;case 2:return Ve(e.integerValue||e.doubleValue);case 3:return this.convertTimestamp(e.timestampValue);case 4:return this.convertServerTimestamp(e,t);case 5:return e.stringValue;case 6:return this.convertBytes(sr(e.bytesValue));case 7:return this.convertReference(e.referenceValue);case 8:return this.convertGeoPoint(e.geoPointValue);case 9:return this.convertArray(e.arrayValue,t);case 11:return this.convertObject(e.mapValue,t);case 10:return this.convertVectorValue(e.mapValue);default:throw ee(62114,{value:e})}}convertObject(e,t){return this.convertObjectMap(e.fields,t)}convertObjectMap(e,t="none"){const r={};return hr(e,(o,i)=>{r[o]=this.convertValue(i,t)}),r}convertVectorValue(e){var r,o,i;const t=(i=(o=(r=e.fields)==null?void 0:r[Pa].arrayValue)==null?void 0:o.values)==null?void 0:i.map(s=>Ve(s.doubleValue));return new $t(t)}convertGeoPoint(e){return new ln(Ve(e.latitude),Ve(e.longitude))}convertArray(e,t){return(e.values||[]).map(r=>this.convertValue(r,t))}convertServerTimestamp(e,t){switch(t){case"previous":const r=rl(e);return r==null?null:this.convertValue(r,t);case"estimate":return this.convertTimestamp(Gi(e));default:return null}}convertTimestamp(e){const t=ir(e);return new Pe(t.seconds,t.nanos)}convertDocumentKey(e,t){const r=Se.fromString(e);we(Jg(r),9688,{name:e});const o=new Yi(r.get(1),r.get(3)),i=new Q(r.popFirst(5));return o.isEqual(t)||Cn(`Document ${i} contains a document reference within a different database (${o.projectId}/${o.database}) which is not supported. It will be treated as a reference in the current database (${t.projectId}/${t.database}) instead.`),i}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class $u extends JE{constructor(e){super(),this.firestore=e}convertBytes(e){return new Nt(e)}convertReference(e){const t=this.convertDocumentKey(e,this.firestore._databaseId);return new De(this.firestore,null,t)}}function Br(){return new Uu("serverTimestamp")}function Fa(n){return new qu("increment",n)}const Cf="@firebase/firestore",Rf="4.14.0";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Of(n){return function(t,r){if(typeof t!="object"||t===null)return!1;const o=t;for(const i of r)if(i in o&&typeof o[i]=="function")return!0;return!1}(n,["next","error","complete"])}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Pm{constructor(e,t,r,o,i){this._firestore=e,this._userDataWriter=t,this._key=r,this._document=o,this._converter=i}get id(){return this._key.path.lastSegment()}get ref(){return new De(this._firestore,this._converter,this._key)}exists(){return this._document!==null}data(){if(this._document){if(this._converter){const e=new ZE(this._firestore,this._userDataWriter,this._key,this._document,null);return this._converter.fromFirestore(e)}return this._userDataWriter.convertValue(this._document.data.value)}}_fieldsProto(){var e;return((e=this._document)==null?void 0:e.data.clone().value.mapValue.fields)??void 0}get(e){if(this._document){const t=this._document.data.field(No("DocumentSnapshot.get",e));if(t!==null)return this._userDataWriter.convertValue(t)}}}class ZE extends Pm{data(){return super.data()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Cm(n){if(n.limitType==="L"&&n.explicitOrderBy.length===0)throw new H(F.UNIMPLEMENTED,"limitToLast() queries require specifying at least one orderBy() clause")}class ju{}class zu extends ju{}function Wu(n,e,...t){let r=[];e instanceof ju&&r.push(e),r=r.concat(t),function(i){const s=i.filter(d=>d instanceof Gu).length,c=i.filter(d=>d instanceof Hu).length;if(s>1||s>0&&c>0)throw new H(F.INVALID_ARGUMENT,"InvalidQuery. When using composite filters, you cannot use more than one filter at the top level. Consider nesting the multiple filters within an `and(...)` statement. For example: change `query(query, where(...), or(...))` to `query(query, and(where(...), or(...)))`.")}(r);for(const o of r)n=o._apply(n);return n}class Hu extends zu{constructor(e,t,r){super(),this._field=e,this._op=t,this._value=r,this.type="where"}static _create(e,t,r){return new Hu(e,t,r)}_apply(e){const t=this._parse(e);return Rm(e._query,t),new Ln(e.firestore,e.converter,_c(e._query,t))}_parse(e){const t=Fu(e.firestore);return function(i,s,c,d,u,f,g){let m;if(u.isKeyField()){if(f==="array-contains"||f==="array-contains-any")throw new H(F.INVALID_ARGUMENT,`Invalid Query. You can't perform '${f}' queries on documentId().`);if(f==="in"||f==="not-in"){Lf(g,f);const L=[];for(const P of g)L.push(Nf(d,i,P));m={arrayValue:{values:L}}}else m=Nf(d,i,g)}else f!=="in"&&f!=="not-in"&&f!=="array-contains-any"||Lf(g,f),m=XE(c,s,g,f==="in"||f==="not-in");return ze.create(u,f,m)}(e._query,"where",t,e.firestore._databaseId,this._field,this._op,this._value)}}class Gu extends ju{constructor(e,t){super(),this.type=e,this._queryConstraints=t}static _create(e,t){return new Gu(e,t)}_parse(e){const t=this._queryConstraints.map(r=>r._parse(e)).filter(r=>r.getFilters().length>0);return t.length===1?t[0]:Wt.create(t,this._getOperator())}_apply(e){const t=this._parse(e);return t.getFilters().length===0?e:(function(o,i){let s=o;const c=i.getFlattenedFilters();for(const d of c)Rm(s,d),s=_c(s,d)}(e._query,t),new Ln(e.firestore,e.converter,_c(e._query,t)))}_getQueryConstraints(){return this._queryConstraints}_getOperator(){return this.type==="and"?"and":"or"}}class Yu extends zu{constructor(e,t){super(),this._field=e,this._direction=t,this.type="orderBy"}static _create(e,t){return new Yu(e,t)}_apply(e){const t=function(o,i,s){if(o.startAt!==null)throw new H(F.INVALID_ARGUMENT,"Invalid query. You must not call startAt() or startAfter() before calling orderBy().");if(o.endAt!==null)throw new H(F.INVALID_ARGUMENT,"Invalid query. You must not call endAt() or endBefore() before calling orderBy().");return new Xi(i,s)}(e._query,this._field,this._direction);return new Ln(e.firestore,e.converter,IT(e._query,t))}}function Ku(n,e="asc"){const t=e,r=No("orderBy",n);return Yu._create(r,t)}class Xu extends zu{constructor(e,t,r){super(),this.type=e,this._limit=t,this._limitType=r}static _create(e,t,r){return new Xu(e,t,r)}_apply(e){return new Ln(e.firestore,e.converter,Ra(e._query,this._limit,this._limitType))}}function Qu(n){return Kw("limit",n),Xu._create("limit",n,"F")}function Nf(n,e,t){if(typeof(t=rt(t))=="string"){if(t==="")throw new H(F.INVALID_ARGUMENT,"Invalid query. When querying with documentId(), you must provide a valid document ID, but it was an empty string.");if(!kg(e)&&t.indexOf("/")!==-1)throw new H(F.INVALID_ARGUMENT,`Invalid query. When querying a collection by documentId(), you must provide a plain document ID, but '${t}' contains a '/' character.`);const r=e.path.child(Se.fromString(t));if(!Q.isDocumentKey(r))throw new H(F.INVALID_ARGUMENT,`Invalid query. When querying a collection group by documentId(), the value provided must result in a valid document path, but '${r}' is not because it has an odd number of segments (${r.length}).`);return Hh(n,new Q(r))}if(t instanceof De)return Hh(n,t._key);throw new H(F.INVALID_ARGUMENT,`Invalid query. When querying with documentId(), you must provide a valid string or a DocumentReference, but it was: ${el(t)}.`)}function Lf(n,e){if(!Array.isArray(n)||n.length===0)throw new H(F.INVALID_ARGUMENT,`Invalid Query. A non-empty array is required for '${e.toString()}' filters.`)}function Rm(n,e){const t=function(o,i){for(const s of o)for(const c of s.getFlattenedFilters())if(i.indexOf(c.op)>=0)return c.op;return null}(n.filters,function(o){switch(o){case"!=":return["!=","not-in"];case"array-contains-any":case"in":return["not-in"];case"not-in":return["array-contains-any","in","not-in","!="];default:return[]}}(e.op));if(t!==null)throw t===e.op?new H(F.INVALID_ARGUMENT,`Invalid query. You cannot use more than one '${e.op.toString()}' filter.`):new H(F.INVALID_ARGUMENT,`Invalid query. You cannot use '${e.op.toString()}' filters with '${t.toString()}' filters.`)}function eI(n,e,t){let r;return r=n?t&&(t.merge||t.mergeFields)?n.toFirestore(e,t):n.toFirestore(e):e,r}class Si{constructor(e,t){this.hasPendingWrites=e,this.fromCache=t}isEqual(e){return this.hasPendingWrites===e.hasPendingWrites&&this.fromCache===e.fromCache}}class Rr extends Pm{constructor(e,t,r,o,i,s){super(e,t,r,o,s),this._firestore=e,this._firestoreImpl=e,this.metadata=i}exists(){return super.exists()}data(e={}){if(this._document){if(this._converter){const t=new fa(this._firestore,this._userDataWriter,this._key,this._document,this.metadata,null);return this._converter.fromFirestore(t,e)}return this._userDataWriter.convertValue(this._document.data.value,e.serverTimestamps)}}get(e,t={}){if(this._document){const r=this._document.data.field(No("DocumentSnapshot.get",e));if(r!==null)return this._userDataWriter.convertValue(r,t.serverTimestamps)}}toJSON(){if(this.metadata.hasPendingWrites)throw new H(F.FAILED_PRECONDITION,"DocumentSnapshot.toJSON() attempted to serialize a document with pending writes. Await waitForPendingWrites() before invoking toJSON().");const e=this._document,t={};return t.type=Rr._jsonSchemaVersion,t.bundle="",t.bundleSource="DocumentSnapshot",t.bundleName=this._key.toString(),!e||!e.isValidDocument()||!e.isFoundDocument()?t:(this._userDataWriter.convertObjectMap(e.data.value.mapValue.fields,"previous"),t.bundle=(this._firestore,this.ref.path,"NOT SUPPORTED"),t)}}Rr._jsonSchemaVersion="firestore/documentSnapshot/1.0",Rr._jsonSchema={type:We("string",Rr._jsonSchemaVersion),bundleSource:We("string","DocumentSnapshot"),bundleName:We("string"),bundle:We("string")};class fa extends Rr{data(e={}){return super.data(e)}}class Or{constructor(e,t,r,o){this._firestore=e,this._userDataWriter=t,this._snapshot=o,this.metadata=new Si(o.hasPendingWrites,o.fromCache),this.query=r}get docs(){const e=[];return this.forEach(t=>e.push(t)),e}get size(){return this._snapshot.docs.size}get empty(){return this.size===0}forEach(e,t){this._snapshot.docs.forEach(r=>{e.call(t,new fa(this._firestore,this._userDataWriter,r.key,r,new Si(this._snapshot.mutatedKeys.has(r.key),this._snapshot.fromCache),this.query.converter))})}docChanges(e={}){const t=!!e.includeMetadataChanges;if(t&&this._snapshot.excludesMetadataChanges)throw new H(F.INVALID_ARGUMENT,"To include metadata changes with your document changes, you must also pass { includeMetadataChanges:true } to onSnapshot().");return this._cachedChanges&&this._cachedChangesIncludeMetadataChanges===t||(this._cachedChanges=function(o,i){if(o._snapshot.oldDocs.isEmpty()){let s=0;return o._snapshot.docChanges.map(c=>{const d=new fa(o._firestore,o._userDataWriter,c.doc.key,c.doc,new Si(o._snapshot.mutatedKeys.has(c.doc.key),o._snapshot.fromCache),o.query.converter);return c.doc,{type:"added",doc:d,oldIndex:-1,newIndex:s++}})}{let s=o._snapshot.oldDocs;return o._snapshot.docChanges.filter(c=>i||c.type!==3).map(c=>{const d=new fa(o._firestore,o._userDataWriter,c.doc.key,c.doc,new Si(o._snapshot.mutatedKeys.has(c.doc.key),o._snapshot.fromCache),o.query.converter);let u=-1,f=-1;return c.type!==0&&(u=s.indexOf(c.doc.key),s=s.delete(c.doc.key)),c.type!==1&&(s=s.add(c.doc),f=s.indexOf(c.doc.key)),{type:tI(c.type),doc:d,oldIndex:u,newIndex:f}})}}(this,t),this._cachedChangesIncludeMetadataChanges=t),this._cachedChanges}toJSON(){if(this.metadata.hasPendingWrites)throw new H(F.FAILED_PRECONDITION,"QuerySnapshot.toJSON() attempted to serialize a document with pending writes. Await waitForPendingWrites() before invoking toJSON().");const e={};e.type=Or._jsonSchemaVersion,e.bundleSource="QuerySnapshot",e.bundleName=lu.newId(),this._firestore._databaseId.database,this._firestore._databaseId.projectId;const t=[],r=[],o=[];return this.docs.forEach(i=>{i._document!==null&&(t.push(i._document),r.push(this._userDataWriter.convertObjectMap(i._document.data.value.mapValue.fields,"previous")),o.push(i.ref.path))}),e.bundle=(this._firestore,this.query._query,e.bundleName,"NOT SUPPORTED"),e}}function tI(n){switch(n){case 0:return"added";case 2:case 3:return"modified";case 1:return"removed";default:return ee(61501,{type:n})}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */Or._jsonSchemaVersion="firestore/querySnapshot/1.0",Or._jsonSchema={type:We("string",Or._jsonSchemaVersion),bundleSource:We("string","QuerySnapshot"),bundleName:We("string"),bundle:We("string")};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Yr(n){n=Ot(n,De);const e=Ot(n.firestore,ur),t=pl(e);return DE(t,n._key).then(r=>Om(e,n,r))}function ml(n){n=Ot(n,Ln);const e=Ot(n.firestore,ur),t=pl(e),r=new $u(e);return Cm(n._query),VE(t,n._query).then(o=>new Or(e,r,n,o))}function dn(n,e,t){n=Ot(n,De);const r=Ot(n.firestore,ur),o=eI(n.converter,e,t),i=Fu(r);return Ju(r,[GE(i,"setDoc",n._key,o,n.converter!==null,t).toMutation(n._key,Bt.none())])}function dr(n,e,t,...r){n=Ot(n,De);const o=Ot(n.firestore,ur),i=Fu(o);let s;return s=typeof(e=rt(e))=="string"||e instanceof Du?KE(i,"updateDoc",n._key,e,t,r):YE(i,"updateDoc",n._key,e),Ju(o,[s.toMutation(n._key,Bt.exists(!0))])}function ts(n){return Ju(Ot(n.firestore,ur),[new gu(n._key,Bt.none())])}function Wo(n,...e){var u,f,g;n=rt(n);let t={includeMetadataChanges:!1,source:"default"},r=0;typeof e[r]!="object"||Of(e[r])||(t=e[r++]);const o={includeMetadataChanges:t.includeMetadataChanges,source:t.source};if(Of(e[r])){const m=e[r];e[r]=(u=m.next)==null?void 0:u.bind(m),e[r+1]=(f=m.error)==null?void 0:f.bind(m),e[r+2]=(g=m.complete)==null?void 0:g.bind(m)}let i,s,c;if(n instanceof De)s=Ot(n.firestore,ur),c=ol(n._key.path),i={next:m=>{e[r]&&e[r](Om(s,n,m))},error:e[r+1],complete:e[r+2]};else{const m=Ot(n,Ln);s=Ot(m.firestore,ur),c=m._query;const v=new $u(s);i={next:L=>{e[r]&&e[r](new Or(s,v,m,L))},error:e[r+1],complete:e[r+2]},Cm(n._query)}const d=pl(s);return ME(d,c,o,i)}function Ju(n,e){const t=pl(n);return FE(t,e)}function Om(n,e,t){const r=t.docs.get(e._key),o=new $u(n);return new Rr(n,o,e._key,r,new Si(t.hasPendingWrites,t.fromCache),e.converter)}(function(e,t=!0){Vw(Fo),xo(new Dr("firestore",(r,{instanceIdentifier:o,options:i})=>{const s=r.getProvider("app").getImmediate(),c=new ur(new qw(r.getProvider("auth-internal")),new jw(s,r.getProvider("app-check-internal")),aT(s,o),s);return i={useFetchStreams:t,...i},c._setSettings(i),c},"PUBLIC").setMultipleInstances(!0)),Jn(Cf,Rf,e),Jn(Cf,Rf,"esm2020")})();let K=null;function nI(){let n;ba().length===0?n=Jc(tg):n=ba()[0],K=$E(n),console.log("[OpenOverlay] Firestore initialized")}async function rI(n){if(!K){console.error("[OpenOverlay] Firestore not initialized");return}const e=Ce(K,"users",n.uid);(await Yr(e)).exists()?(await dr(e,{displayName:n.displayName||"Anonymous",photoURL:n.photoURL||"",email:n.email||""}),console.log("[OpenOverlay] User profile updated")):(await dn(e,{uid:n.uid,displayName:n.displayName||"Anonymous",email:n.email||"",photoURL:n.photoURL||"",bio:"",createdAt:Br(),followersCount:0,followingCount:0}),console.log("[OpenOverlay] User profile created"))}async function yl(n){if(!K)return null;const e=Ce(K,"users",n),t=await Yr(e);return t.exists()?t.data():null}async function oI(n){const e=ge();if(!K||!e)return;const t=Ce(K,"users",e.uid);await dr(t,{bio:n})}async function iI(n){const e=ge();if(!K||!e||e.uid===n)return;const t=Ce(K,"users",e.uid,"following",n);await dn(t,{followedAt:Br()});const r=Ce(K,"users",n,"followers",e.uid);await dn(r,{followedAt:Br()});const o=Ce(K,"users",e.uid),i=Ce(K,"users",n);await dr(o,{followingCount:Fa(1)}),await dr(i,{followersCount:Fa(1)}),console.log("[OpenOverlay] Followed user:",n)}async function sI(n){const e=ge();if(!K||!e||e.uid===n)return;const t=Ce(K,"users",e.uid,"following",n);await ts(t);const r=Ce(K,"users",n,"followers",e.uid);await ts(r);const o=Ce(K,"users",e.uid),i=Ce(K,"users",n);await dr(o,{followingCount:Fa(-1)}),await dr(i,{followersCount:Fa(-1)}),console.log("[OpenOverlay] Unfollowed user:",n)}async function aI(n){const e=ge();if(!K||!e)return!1;const t=Ce(K,"users",e.uid,"following",n);return(await Yr(t)).exists()}async function lI(n,e=50){if(!K)return[];const t=hn(K,"users",n,"followers"),r=Wu(t,Ku("followedAt","desc"),Qu(e)),o=await ml(r),i=[];for(const s of o.docs){const c=await yl(s.id);c&&i.push(c)}return i}async function cI(n,e=50){if(!K)return[];const t=hn(K,"users",n,"following"),r=Wu(t,Ku("followedAt","desc"),Qu(e)),o=await ml(r),i=[];for(const s of o.docs){const c=await yl(s.id);c&&i.push(c)}return i}function uI(n,e){if(!K)return null;const t=hn(K,"users",n,"followers"),r=Wu(t,Ku("followedAt","desc"),Qu(10));let o=!0;return Wo(r,async i=>{var s;if(o){o=!1;return}for(const c of i.docChanges())if(c.type==="added"){const d=c.doc.id,f=((s=c.doc.data().followedAt)==null?void 0:s.toDate())||new Date,g=await yl(d);g&&e({uid:d,displayName:g.displayName,photoURL:g.photoURL,followedAt:f})}})}async function Nm(n,e,t){const r=ge();if(!K||!r)return console.log("[OpenOverlay] Not logged in, skipping cloud save"),!1;try{const o=Ce(K,"pageDrawings",n,"contributors",r.uid);return await dn(o,{userId:r.uid,userDisplayName:r.displayName||"Anonymous",userPhotoURL:r.photoURL||"",pageUrl:e,items:JSON.stringify(t),updatedAt:Br()}),console.log("[OpenOverlay] Drawing saved to cloud (public)"),!0}catch(o){return console.error("[OpenOverlay] Failed to save drawing to cloud:",o),!1}}async function dI(n){if(!K)return null;const e=ge();try{const t=hn(K,"pageDrawings",n,"contributors"),r=await ml(t),o=[],i=[],s=[];return r.docs.forEach(c=>{const d=c.data(),u=JSON.parse(d.items||"[]");s.push({userId:d.userId,displayName:d.userDisplayName,photoURL:d.userPhotoURL}),e&&d.userId===e.uid?o.push(...u):u.forEach(f=>{i.push({...f,_ownerId:d.userId,_ownerName:d.userDisplayName,_readOnly:!0})})}),console.log("[OpenOverlay] Loaded drawings:",o.length,"mine,",i.length,"from others"),{myItems:o,otherItems:i,contributors:s}}catch(t){return console.error("[OpenOverlay] Failed to load drawings from cloud:",t),null}}async function hI(n){const e=ge();if(!K||!e)return!1;try{const t=Ce(K,"pageDrawings",n,"contributors",e.uid);return await ts(t),console.log("[OpenOverlay] Drawing deleted from cloud"),!0}catch(t){return console.error("[OpenOverlay] Failed to delete drawing from cloud:",t),!1}}let Hs=null;function fI(n,e){if(!K)return console.log("[OpenOverlay] Cannot subscribe to drawings: Firestore not initialized"),null;Hs&&Hs();const t=ge(),r=hn(K,"pageDrawings",n,"contributors");return Hs=Wo(r,o=>{const i=[],s=[],c=[];o.docs.forEach(d=>{const u=d.data(),f=JSON.parse(u.items||"[]");c.push({userId:u.userId,displayName:u.userDisplayName,photoURL:u.userPhotoURL}),t&&u.userId===t.uid?i.push(...f):f.forEach(g=>{s.push({...g,_ownerId:u.userId,_ownerName:u.userDisplayName,_readOnly:!0})})}),console.log("[OpenOverlay] Real-time drawing update:",i.length,"mine,",s.length,"from others"),e({myItems:i,otherItems:s,contributors:c})},o=>{console.error("[OpenOverlay] Drawing subscription error:",o)}),console.log("[OpenOverlay] Subscribed to drawings on page:",n),Hs}function Kr(){return K!==null}function Ua(){return ge()!==null}let Gs=null;async function pI(n,e){if(!K)return console.log("[OpenOverlay] Cannot save annotation: Firestore not initialized"),!1;try{const t=Ce(K,"pageAnnotations",n,"annotations",e.id),r={...e,reactions:e.reactions||[],replies:e.replies||[],updatedAt:Br()};return console.log("[OpenOverlay] Saving to Firestore:",t.path),await dn(t,r,{merge:!0}),console.log("[OpenOverlay] Annotation saved to cloud successfully"),!0}catch(t){return console.error("[OpenOverlay] Failed to save annotation:",(t==null?void 0:t.message)||t),(t==null?void 0:t.code)==="permission-denied"&&console.error("[OpenOverlay] Firestore security rules may need to be updated"),!1}}async function gI(n,e){if(!K)return!1;try{const t=Ce(K,"pageAnnotations",n,"annotations",e);return await ts(t),console.log("[OpenOverlay] Annotation deleted from cloud"),!0}catch(t){return console.error("[OpenOverlay] Failed to delete annotation:",t),!1}}async function Lm(n){if(!K)return[];try{const e=hn(K,"pageAnnotations",n,"annotations"),t=await ml(e),r=[];return t.forEach(o=>{r.push({id:o.id,...o.data()})}),r.sort((o,i)=>(i.createdAt||0)-(o.createdAt||0)),console.log("[OpenOverlay] Fetched",r.length,"annotations from cloud"),r}catch(e){return console.error("[OpenOverlay] Failed to fetch annotations:",e),[]}}function mI(n,e){if(!K)return console.log("[OpenOverlay] Cannot subscribe to annotations: Firestore not initialized"),null;Gs&&Gs();const t=hn(K,"pageAnnotations",n,"annotations");return Gs=Wo(t,r=>{const o=[];r.forEach(i=>{o.push({id:i.id,...i.data()})}),o.sort((i,s)=>(s.createdAt||0)-(i.createdAt||0)),console.log("[OpenOverlay] Real-time update:",o.length,"annotations"),e(o)},r=>{console.error("[OpenOverlay] Annotation subscription error:",r),Lm(n).then(e)}),Gs}async function yI(n,e,t){if(!K)return!1;try{const r=Ce(K,"pageAnnotations",n,"annotations",e),o=await Yr(r);if(!o.exists())return!1;const s=o.data().replies||[];return s.push(t),await dr(r,{replies:s}),console.log("[OpenOverlay] Reply added"),!0}catch(r){return console.error("[OpenOverlay] Failed to add reply:",r),!1}}async function vI(n,e,t,r){if(!K)return!1;try{const o=Ce(K,"pageAnnotations",n,"annotations",e),i=await Yr(o);if(!i.exists())return!1;let c=i.data().reactions||[];const d=c.find(u=>u.emoji===t);return d?d.users.includes(r)?(d.users=d.users.filter(u=>u!==r),d.count=d.users.length,d.count===0&&(c=c.filter(u=>u.emoji!==t))):(d.users.push(r),d.count=d.users.length):c.push({emoji:t,count:1,users:[r]}),await dr(o,{reactions:c}),!0}catch(o){return console.error("[OpenOverlay] Failed to toggle reaction:",o),!1}}let xr=null,Mf=0;async function _I(n,e){const t=ge();if(!K||!t){console.log("[OpenOverlay] Cannot sync position: db=",!!K,"user=",!!t);return}try{const r=Ce(K,"pageGames",n,"players",t.uid);await dn(r,{...e,odlPlayerId:t.uid,displayName:e.displayName||t.displayName||"Player",updatedAt:Date.now()},{merge:!0})}catch(r){const o=Date.now();o-Mf>1e4&&(Mf=o,console.error("[OpenOverlay] Position sync error:",(r==null?void 0:r.message)||r))}}function bI(n,e){if(!K)return console.log("[OpenOverlay] Cannot subscribe to players: Firestore not initialized"),null;const t=ge();console.log("[OpenOverlay] Subscribing to players for page:",n,"currentUser:",t==null?void 0:t.uid),xr&&xr();const r=hn(K,"pageGames",n,"players");return xr=Wo(r,o=>{const i=new Map,s=Date.now(),c=3e4;o.forEach(d=>{const u=d.data(),f=s-u.updatedAt;t&&d.id===t.uid||f>c||i.set(d.id,u)}),i.size>0&&console.log("[OpenOverlay] Got",i.size,"other players from snapshot"),e(i)},o=>{console.error("[OpenOverlay] Player subscription error:",o)}),console.log("[OpenOverlay] Subscribed to players on page:",n),xr}async function Mm(n){const e=ge();if(!(!K||!e))try{const t=Ce(K,"pageGames",n,"players",e.uid);await ts(t),console.log("[OpenOverlay] Player removed from page")}catch(t){console.error("[OpenOverlay] Failed to remove player:",t)}}function Dm(){xr&&(xr(),xr=null)}let Ar=null;function wI(n,e){if(!K)return console.log("[OpenOverlay] Cannot subscribe to tag game: Firestore not initialized"),null;Ar&&Ar();const t=Ce(K,"pageGames",n,"gameState","tag");return Ar=Wo(t,r=>{r.exists()?e(r.data()):e(null)},r=>{console.error("[OpenOverlay] Tag game subscription error:",r),e(null)}),console.log("[OpenOverlay] Subscribed to tag game"),Ar}function TI(){Ar&&(Ar(),Ar=null)}async function EI(n){const e=ge();if(!K||!e)return!1;try{const t=Ce(K,"pageGames",n,"gameState","tag"),r=await Yr(t);if(r.exists()){const o=r.data();return console.log("[OpenOverlay] Joined existing tag game, IT is:",o.itPlayerId),o.itPlayerId===e.uid}return await dn(t,{itPlayerId:e.uid,lastTagTime:Date.now(),gameActive:!0}),console.log("[OpenOverlay] Started new tag game - you are IT!"),!0}catch(t){return console.error("[OpenOverlay] Failed to start tag game:",t),!1}}async function II(n,e){const t=ge();if(!K||!t)return!1;try{const r=Ce(K,"pageGames",n,"gameState","tag"),o=await Yr(r);return o.exists()?o.data().itPlayerId!==t.uid?(console.log("[OpenOverlay] Cannot tag - you are not IT"),!1):(await dn(r,{itPlayerId:e,lastTagTime:Date.now(),gameActive:!0}),console.log("[OpenOverlay] Tagged player:",e),!0):!1}catch(r){return console.error("[OpenOverlay] Failed to tag player:",r),!1}}async function SI(n,e){if(!K)return console.error("[OpenOverlay] Cannot submit feedback: Firestore not initialized"),!1;const t=ge();try{const r=hn(K,"feedback"),o=Ce(r);return await dn(o,{type:n,message:e,userId:(t==null?void 0:t.uid)||null,userEmail:(t==null?void 0:t.email)||null,userName:(t==null?void 0:t.displayName)||null,pageUrl:window.location.href,userAgent:navigator.userAgent,timestamp:Br()}),console.log("[OpenOverlay] Feedback submitted successfully"),!0}catch(r){return console.error("[OpenOverlay] Failed to submit feedback:",r),!1}}let Ys=null;async function xI(n,e){const t=ge();if(!K||!t)return console.log("[OpenOverlay] Not logged in, skipping course cloud save"),!1;try{const r=Ce(K,"pageCourses",n,"courses",t.uid);return await dn(r,{...e,authorId:t.uid,authorName:t.displayName||"Anonymous",updatedAt:Br()}),console.log("[OpenOverlay] Course saved to cloud"),!0}catch(r){return console.error("[OpenOverlay] Failed to save course to cloud:",r),!1}}function AI(n,e){if(!K)return console.log("[OpenOverlay] Cannot subscribe to courses: Firestore not initialized"),null;Ys&&Ys();const t=ge(),r=hn(K,"pageCourses",n,"courses");return Ys=Wo(r,o=>{let i=null;const s=[];o.forEach(c=>{const d=c.data();t&&c.id===t.uid?i=d:s.push(d)}),console.log("[OpenOverlay] Course update: mine=",!!i,"others=",s.length),e({myCourse:i,otherCourses:s})},o=>{console.error("[OpenOverlay] Course subscription error:",o)}),console.log("[OpenOverlay] Subscribed to courses on page:",n),Ys}let Kl=null,Lo=null,Zu=null;const pa=[];function kI(){ba().length===0?Kl=Jc(tg):Kl=ba()[0],Lo=Mw(Kl),Eb(Lo,async n=>{Zu=n,console.log("[OpenOverlay] Auth state changed:",(n==null?void 0:n.displayName)||"signed out"),n&&await rI(n),pa.forEach(e=>e(n))}),console.log("[OpenOverlay] Auth initialized")}async function PI(){if(!Lo)return console.error("[OpenOverlay] Auth not initialized"),null;const n=await new Promise(e=>{chrome.runtime.sendMessage({type:"GOOGLE_SIGN_IN"},e)});if(!n.success||!n.token)throw new Error(n.error||"Failed to get auth token");try{const e=_n.credential(null,n.token),t=await bb(Lo,e);return console.log("[OpenOverlay] Signed in as:",t.user.displayName),t.user}catch(e){throw console.error("[OpenOverlay] Sign in error:",e),(e==null?void 0:e.code)==="auth/invalid-credential"&&await new Promise(t=>{chrome.runtime.sendMessage({type:"GOOGLE_SIGN_OUT"},()=>t())}),e}}async function CI(){Lo&&(await new Promise(n=>{chrome.runtime.sendMessage({type:"GOOGLE_SIGN_OUT"},()=>n())}),await Ib(Lo),console.log("[OpenOverlay] Signed out"))}function ge(){return Zu}function Vm(n){return pa.push(n),n(Zu),()=>{const e=pa.indexOf(n);e>-1&&pa.splice(e,1)}}let st=[],xi=null,pi=null,Et=null,kr=null,tr=new Set;const Xl=["#ffeb3b","#ff9800","#4caf50","#2196f3","#e91e63"],ed=["👍","❤️","😂","😮","😢","😡","🔥","👀","💯","🎉"],RI=`
  .oo-annotate-btn {
    position: absolute;
    background: #22c55e;
    color: white;
    border: none;
    padding: 6px 12px;
    border-radius: 6px;
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
    box-shadow: 0 2px 8px rgba(0,0,0,0.2);
    z-index: 2147483646;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    transition: transform 0.1s;
  }

  .oo-annotate-btn:hover {
    transform: scale(1.05);
  }

  .oo-annotation-form {
    position: absolute;
    background: #1a1a1a;
    border-radius: 12px;
    padding: 16px;
    box-shadow: 0 8px 32px rgba(0,0,0,0.3);
    z-index: 2147483646;
    width: 300px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  }

  .oo-annotation-form textarea {
    width: 100%;
    height: 80px;
    background: #2a2a2a;
    border: 1px solid #333;
    border-radius: 8px;
    color: #fff;
    padding: 10px;
    font-size: 14px;
    resize: none;
    font-family: inherit;
  }

  .oo-annotation-form textarea:focus {
    outline: none;
    border-color: #22c55e;
  }

  .oo-annotation-form .colors {
    display: flex;
    gap: 6px;
    margin: 12px 0;
  }

  .oo-annotation-form .color-btn {
    width: 24px;
    height: 24px;
    border-radius: 50%;
    border: 2px solid transparent;
    cursor: pointer;
    transition: transform 0.1s;
  }

  .oo-annotation-form .color-btn:hover {
    transform: scale(1.2);
  }

  .oo-annotation-form .color-btn.active {
    border-color: #fff;
  }

  .oo-annotation-form .actions {
    display: flex;
    justify-content: flex-end;
    gap: 8px;
    margin-top: 12px;
  }

  .oo-annotation-form button {
    padding: 8px 16px;
    border: none;
    border-radius: 6px;
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
    font-family: inherit;
  }

  .oo-annotation-form .cancel-btn {
    background: #333;
    color: #fff;
  }

  .oo-annotation-form .save-btn {
    background: #22c55e;
    color: #fff;
  }

  .oo-popup {
    position: absolute;
    background: #1a1a1a;
    border-radius: 12px;
    box-shadow: 0 8px 32px rgba(0,0,0,0.4);
    z-index: 2147483646;
    max-width: 320px;
    min-width: 200px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    pointer-events: auto;
    padding: 14px;
  }

  .oo-popup .popup-quote {
    font-size: 18px;
    font-weight: 700;
    color: #fff;
    line-height: 1.3;
    margin-bottom: 8px;
  }

  .oo-popup .popup-author {
    text-align: right;
    color: #888;
    font-size: 12px;
    margin-bottom: 10px;
  }

  .oo-popup .popup-footer {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
  }

  .oo-popup .popup-reactions {
    display: flex;
    gap: 4px;
    flex-wrap: wrap;
    flex: 1;
  }

  .oo-popup .reaction {
    background: #222;
    border: 1px solid #333;
    border-radius: 12px;
    padding: 2px 6px;
    font-size: 12px;
    cursor: pointer;
    transition: background 0.1s;
    display: flex;
    align-items: center;
    gap: 2px;
  }

  .oo-popup .reaction:hover {
    background: #333;
  }

  .oo-popup .reaction .count {
    color: #888;
    font-size: 11px;
  }

  .oo-popup .reaction.active {
    background: #22c55e33;
    border-color: #22c55e;
  }

  .oo-popup .popup-actions {
    display: flex;
    gap: 6px;
    align-items: center;
  }

  .oo-popup .comment-btn {
    background: #222;
    border: 1px solid #333;
    border-radius: 12px;
    padding: 2px 8px;
    font-size: 12px;
    cursor: pointer;
    color: #888;
    display: flex;
    align-items: center;
    gap: 4px;
  }

  .oo-popup .comment-btn:hover {
    background: #333;
    color: #fff;
  }

  .oo-popup .add-reaction {
    background: #222;
    border: 1px solid #333;
    border-radius: 12px;
    padding: 2px 6px;
    font-size: 14px;
    cursor: pointer;
    color: #888;
  }

  .oo-popup .add-reaction:hover {
    background: #333;
    border-color: #22c55e;
    color: #22c55e;
  }

  .oo-popup .maximize-btn {
    background: none;
    border: none;
    color: #666;
    font-size: 14px;
    cursor: pointer;
    padding: 2px 4px;
  }

  .oo-popup .maximize-btn:hover {
    color: #fff;
  }

  .oo-popup .bookmark-btn {
    background: transparent;
    border: none;
    padding: 2px 4px;
    cursor: pointer;
    font-size: 14px;
    color: #888;
    transition: color 0.15s;
  }

  .oo-popup .bookmark-btn:hover {
    color: #fff;
  }

  .oo-popup .bookmark-btn.active {
    color: #f59e0b;
  }

  .oo-popup .delete-btn {
    background: transparent;
    border: none;
    padding: 2px 4px;
    cursor: pointer;
    font-size: 14px;
    color: #666;
    transition: color 0.15s;
  }

  .oo-popup .delete-btn:hover {
    color: #ef4444;
  }

  .oo-comment-panel .delete-btn {
    background: #ef4444;
    color: white;
    border: none;
    padding: 8px 16px;
    border-radius: 6px;
    cursor: pointer;
    font-size: 13px;
    margin-top: 12px;
  }

  .oo-comment-panel .delete-btn:hover {
    background: #dc2626;
  }

  .oo-popup .popup-reply-section {
    margin-top: 10px;
    padding-top: 10px;
    border-top: 1px solid #333;
    display: none;
  }

  .oo-popup .popup-reply-section.open {
    display: block;
  }

  .oo-popup .popup-reply-input {
    display: flex;
    gap: 6px;
  }

  .oo-popup .popup-reply-input input {
    flex: 1;
    background: #222;
    border: 1px solid #333;
    border-radius: 14px;
    padding: 6px 10px;
    color: #fff;
    font-size: 12px;
  }

  .oo-popup .popup-reply-input input:focus {
    outline: none;
    border-color: #22c55e;
  }

  .oo-popup .popup-reply-input button {
    background: #22c55e;
    border: none;
    border-radius: 50%;
    width: 26px;
    height: 26px;
    color: white;
    font-size: 12px;
    cursor: pointer;
  }

  .oo-popup .quick-emojis {
    display: flex;
    gap: 2px;
    margin-top: 8px;
  }

  .oo-popup .quick-emoji {
    background: none;
    border: none;
    font-size: 16px;
    cursor: pointer;
    padding: 2px;
    border-radius: 4px;
    opacity: 0.6;
    transition: opacity 0.1s, transform 0.1s;
  }

  .oo-popup .quick-emoji:hover {
    opacity: 1;
    transform: scale(1.2);
  }

  .oo-popup-emoji-picker {
    position: absolute;
    background: #222;
    border-radius: 10px;
    padding: 6px;
    box-shadow: 0 4px 16px rgba(0,0,0,0.4);
    display: flex;
    flex-wrap: wrap;
    gap: 2px;
    width: 180px;
    bottom: 100%;
    left: 0;
    margin-bottom: 4px;
  }

  .oo-popup-emoji-picker .emoji-btn {
    width: 28px;
    height: 28px;
    border: none;
    background: transparent;
    border-radius: 4px;
    font-size: 16px;
    cursor: pointer;
  }

  .oo-popup-emoji-picker .emoji-btn:hover {
    background: #333;
  }

  .oo-comment-panel {
    position: fixed;
    right: 0;
    top: 0;
    width: 360px;
    height: 100vh;
    background: #111;
    box-shadow: -4px 0 24px rgba(0,0,0,0.3);
    z-index: 2147483646;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    display: flex;
    flex-direction: column;
    transform: translateX(100%);
    transition: transform 0.2s ease-out;
  }

  .oo-comment-panel.open {
    transform: translateX(0);
  }

  .oo-comment-panel .header {
    padding: 16px;
    border-bottom: 1px solid #222;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .oo-comment-panel .header h3 {
    margin: 0;
    color: #fff;
    font-size: 16px;
  }

  .oo-comment-panel .close-btn {
    background: none;
    border: none;
    color: #888;
    font-size: 24px;
    cursor: pointer;
    padding: 0;
    line-height: 1;
  }

  .oo-comment-panel .highlighted-text {
    padding: 16px;
    background: #1a1a1a;
    border-bottom: 1px solid #222;
  }

  .oo-comment-panel .highlighted-text blockquote {
    margin: 0;
    padding-left: 12px;
    border-left: 3px solid #22c55e;
    color: #aaa;
    font-style: italic;
  }

  .oo-comment-panel .main-comment {
    padding: 16px;
    border-bottom: 1px solid #222;
  }

  .oo-comment-panel .author-info {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 8px;
  }

  .oo-comment-panel .avatar {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    background: #333;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #888;
    font-size: 14px;
  }

  .oo-comment-panel .author-name {
    color: #fff;
    font-weight: 600;
    font-size: 14px;
  }

  .oo-comment-panel .timestamp {
    color: #666;
    font-size: 12px;
  }

  .oo-comment-panel .comment-text {
    color: #ddd;
    font-size: 14px;
    line-height: 1.5;
  }

  .oo-comment-panel .reactions {
    display: flex;
    gap: 8px;
    margin-top: 12px;
    flex-wrap: wrap;
  }

  .oo-comment-panel .reaction {
    background: #222;
    border: 1px solid #333;
    border-radius: 16px;
    padding: 4px 10px;
    font-size: 13px;
    cursor: pointer;
    transition: background 0.1s;
  }

  .oo-comment-panel .reaction:hover {
    background: #333;
  }

  .oo-comment-panel .reaction .emoji {
    margin-right: 4px;
  }

  .oo-comment-panel .reaction .count {
    color: #888;
  }

  .oo-comment-panel .add-reaction {
    background: #1a1a1a;
    border: 1px dashed #444;
    color: #888;
    font-size: 16px;
    min-width: 36px;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .oo-comment-panel .add-reaction:hover {
    border-color: #22c55e;
    color: #22c55e;
  }

  .oo-comment-panel .reaction.active {
    background: #22c55e33;
    border-color: #22c55e;
  }

  .oo-emoji-picker {
    position: absolute;
    background: #222;
    border-radius: 12px;
    padding: 8px;
    box-shadow: 0 4px 16px rgba(0,0,0,0.4);
    display: flex;
    flex-wrap: wrap;
    gap: 4px;
    width: 200px;
    z-index: 10;
  }

  .oo-emoji-picker .emoji-btn {
    width: 32px;
    height: 32px;
    border: none;
    background: transparent;
    border-radius: 6px;
    font-size: 18px;
    cursor: pointer;
    transition: background 0.1s, transform 0.1s;
  }

  .oo-emoji-picker .emoji-btn:hover {
    background: #333;
    transform: scale(1.2);
  }

  .oo-comment-panel .replies-section {
    flex: 1;
    overflow-y: auto;
    padding: 16px;
  }

  .oo-comment-panel .reply {
    margin-bottom: 16px;
    padding-bottom: 16px;
    border-bottom: 1px solid #222;
  }

  .oo-comment-panel .reply:last-child {
    border-bottom: none;
  }

  .oo-comment-panel .reply-input {
    padding: 16px;
    border-top: 1px solid #222;
    display: flex;
    gap: 8px;
  }

  .oo-comment-panel .reply-input input {
    flex: 1;
    background: #222;
    border: 1px solid #333;
    border-radius: 20px;
    padding: 10px 16px;
    color: #fff;
    font-size: 14px;
  }

  .oo-comment-panel .reply-input input:focus {
    outline: none;
    border-color: #22c55e;
  }

  .oo-comment-panel .reply-input button {
    background: #22c55e;
    border: none;
    border-radius: 50%;
    width: 40px;
    height: 40px;
    color: white;
    font-size: 18px;
    cursor: pointer;
  }
`;function OI(){console.log("[OpenOverlay] initAnnotations starting..."),pi=document.createElement("div"),pi.id="openoverlay-annotations",pi.style.cssText=`
    position: fixed;
    top: 0;
    left: 0;
    width: 0;
    height: 0;
    z-index: 2147483646;
    pointer-events: none;
  `,Et=pi.attachShadow({mode:"open"});const n=document.createElement("style");n.textContent=RI,Et.appendChild(n),document.body.appendChild(pi),document.addEventListener("mouseup",LI),document.addEventListener("selectionchange",NI),zI(),XI(),vl(),console.log("[OpenOverlay] Annotations initialized")}let Ql=null;function NI(){Ql&&clearTimeout(Ql),Ql=window.setTimeout(()=>{Fm()},100)}function LI(n){var e,t;(e=n.target)!=null&&e.closest("#openoverlay-annotations")||(t=n.target)!=null&&t.closest("#openoverlay-ui")||setTimeout(Fm,10)}function Fm(){const n=window.getSelection();if(!n||n.isCollapsed||!n.toString().trim()){qa();return}if(n.toString().trim().length<3){qa();return}const r=n.getRangeAt(0).getBoundingClientRect();MI(r,n)}function MI(n,e){if(qa(),!Et)return;const t=document.createElement("button");t.className="oo-annotate-btn",t.textContent="+ Annotate",t.style.pointerEvents="auto";const r=Math.max(10,Math.min(n.left+n.width/2-50,window.innerWidth-110)),o=n.bottom+2,i=o+32>window.innerHeight?n.top-34:o;t.style.left=`${r}px`,t.style.top=`${i}px`,t.onclick=s=>{s.preventDefault(),s.stopPropagation(),DI(n,e)},Et.appendChild(t),xi=t}function qa(){xi&&(Et!=null&&Et.contains(xi))&&xi.remove(),xi=null}function DI(n,e){var v,L;if(qa(),!Et)return;const t=e.toString().trim(),r=e.getRangeAt(0),o=e.anchorNode,i=e.focusNode,s=document.createElement("div");s.className="oo-annotation-form",s.style.pointerEvents="auto";const c=Math.max(10,Math.min(n.left,window.innerWidth-320)),d=n.bottom+4,u=180,f=d+u>window.innerHeight?Math.max(10,n.top-u-4):d;s.style.left=`${c}px`,s.style.top=`${f}px`;let g=Xl[0];s.innerHTML=`
    <textarea placeholder="Add your annotation..." autofocus></textarea>
    <div class="colors">
      ${Xl.map((P,M)=>`
        <div class="color-btn ${M===0?"active":""}"
             data-color="${P}"
             style="background: ${P}"></div>
      `).join("")}
    </div>
    <div class="actions">
      <button class="cancel-btn">Cancel</button>
      <button class="save-btn">Save</button>
    </div>
  `,s.querySelectorAll(".color-btn").forEach(P=>{P.addEventListener("click",()=>{s.querySelectorAll(".color-btn").forEach(M=>M.classList.remove("active")),P.classList.add("active"),g=P.dataset.color||Xl[0]})}),(v=s.querySelector(".cancel-btn"))==null||v.addEventListener("click",()=>{var P;s.remove(),(P=window.getSelection())==null||P.removeAllRanges()}),(L=s.querySelector(".save-btn"))==null||L.addEventListener("click",()=>{var j;const P=s.querySelector("textarea"),M=P.value.trim();if(!M){P.focus();return}const{contextBefore:G,contextAfter:$}=FI(r,t),D={id:VI(),text:t,contextBefore:G,contextAfter:$,anchorSelector:Df(o),anchorOffset:e.anchorOffset,focusSelector:Df(i),focusOffset:e.focusOffset,comment:M,color:g,authorId:"local-user",authorName:"You",createdAt:Date.now(),reactions:[],replies:[]};st.push(D),jt(),vl(),jI(D),s.remove(),(j=window.getSelection())==null||j.removeAllRanges(),console.log("[OpenOverlay] Annotation created:",D.id)}),Et.appendChild(s),setTimeout(()=>{var P;(P=s.querySelector("textarea"))==null||P.focus()},10);const m=s.querySelector("textarea");m==null||m.addEventListener("keydown",P=>{if(P.stopPropagation(),P.key==="Enter"&&!P.shiftKey){P.preventDefault();const M=s.querySelector(".save-btn");M==null||M.click()}})}function Df(n){if(!n)return"body";const e=n.nodeType===Node.TEXT_NODE?n.parentElement:n;if(!e)return"body";const t=[];let r=e;for(;r&&r!==document.body&&r!==document.documentElement;){let o=r.tagName.toLowerCase();if(r.id){t.unshift(`#${CSS.escape(r.id)}`);break}const i=r.parentElement;if(i){const c=Array.from(i.children).indexOf(r)+1;o+=`:nth-child(${c})`}t.unshift(o),r=r.parentElement}return t.join(" > ")||"body"}function VI(){return Math.random().toString(36).substr(2,9)}function FI(n,e){var r;try{const o=n.commonAncestorContainer,i=o.nodeType===Node.TEXT_NODE?o.parentElement:o;if(!i)return{contextBefore:"",contextAfter:""};const s=i.textContent||"",c=((r=n.startContainer.textContent)==null?void 0:r.substring(0,n.startOffset))||"";let d="";const u=document.createTreeWalker(i,NodeFilter.SHOW_TEXT,null);let f;for(;f=u.nextNode();){if(f===n.startContainer){d+=c;break}d+=f.textContent||""}const g=d.slice(-30),m=d.length+e.length,v=s.substring(m,m+30);return{contextBefore:g,contextAfter:v}}catch(o){return console.warn("[OpenOverlay] Failed to get selection context:",o),{contextBefore:"",contextAfter:""}}}function td(){document.querySelectorAll(".oo-highlight").forEach(n=>{const e=n.parentNode;e&&(e.replaceChild(document.createTextNode(n.textContent||""),n),e.normalize())})}function vl(){td();for(const n of st)try{UI(n)}catch(e){console.warn("[OpenOverlay] Failed to highlight annotation:",n.id,e)}}function UI(n){(n.contextBefore||"")+n.text+(n.contextAfter||"");const e=n.text,t=[],r=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,null);let o="",i;for(;i=r.nextNode();){const u=i.textContent||"";t.push({node:i,start:o.length,end:o.length+u.length}),o+=u}let s=-1;if(n.contextBefore||n.contextAfter){const u=n.contextBefore||"",f=n.contextAfter||"";let g=0;for(;g<o.length;){const m=o.indexOf(e,g);if(m===-1)break;const v=u===""||o.substring(Math.max(0,m-u.length),m).endsWith(u),L=f===""||o.substring(m+e.length,m+e.length+f.length).startsWith(f);if(v&&L){s=m;break}g=m+1}}if(s===-1&&(s=o.indexOf(e)),s===-1)return;let c=null,d=0;for(const u of t)if(s>=u.start&&s<u.end){c=u.node,d=s-u.start;break}if(c)try{const u=document.createRange();u.setStart(c,d),u.setEnd(c,d+e.length);const f=document.createElement("span");f.className="oo-highlight",f.dataset.annotationId=n.id,f.style.cssText=`
      background: ${n.color}40;
      border-bottom: 2px solid ${n.color};
      cursor: pointer;
      transition: background 0.15s;
    `,f.addEventListener("mouseenter",g=>{f.style.background=`${n.color}60`,Pc(n,g,f)}),f.addEventListener("mouseleave",g=>{f.style.background=`${n.color}40`,Um()}),u.surroundContents(f)}catch(u){console.warn("[OpenOverlay] Failed to highlight annotation:",n.id,u)}}let Nr=null,Qt=null,mo=null,yo=!1;function Um(){yo||(mo&&clearTimeout(mo),mo=window.setTimeout(()=>{Hn()},150))}function Ai(){mo&&(clearTimeout(mo),mo=null)}function Pc(n,e,t){var P,M,G,$;if(cn)return;if(Nr&&(Qt==null?void 0:Qt.id)===n.id){Ai();return}if(Ai(),Hn(),yo=!1,!Et)return;Qt=n;const r=document.createElement("div");r.className="oo-popup";let o,i;if(t){const D=t.getBoundingClientRect();o=D.left,i=D.bottom+4}else o=e.clientX-100,i=e.clientY+10;o<10&&(o=10),o+320>window.innerWidth&&(o=window.innerWidth-330),i+200>window.innerHeight&&(i=t?t.getBoundingClientRect().top-200:e.clientY-200),r.style.left=`${o}px`,r.style.top=`${i}px`;const s=n.reactions.filter(D=>D.count>0),c=n.replies.length,d=ge(),u=d?n.authorId===d.uid:n.authorId==="local-user";r.innerHTML=`
    <div class="popup-quote">"${Dt(n.comment)}"</div>
    <div class="popup-author">— ${Dt(n.authorName)}</div>
    <div class="popup-footer">
      <div class="popup-reactions" id="popup-reactions">
        ${s.map(D=>`
          <div class="reaction ${D.userReacted?"active":""}" data-emoji="${D.emoji}">
            <span class="emoji">${D.emoji}</span>
            <span class="count">${D.count}</span>
          </div>
        `).join("")}
      </div>
      <div class="popup-actions">
        <button class="comment-btn" id="popup-comment-btn" title="Comments">
          💬 ${c>0?c:""}
        </button>
        <button class="add-reaction" id="popup-add-reaction" title="React">+</button>
        <button class="bookmark-btn ${tr.has(n.id)?"active":""}" id="popup-bookmark-btn" title="Bookmark">🔖</button>
        <button class="maximize-btn" title="Open in sidebar">⛶</button>
        ${u?'<button class="delete-btn" id="popup-delete-btn" title="Delete annotation">🗑️</button>':""}
      </div>
    </div>
    <div class="popup-reply-section" id="popup-reply-section">
      <div class="popup-reply-input">
        <input type="text" placeholder="Add a comment..." />
        <button>➤</button>
      </div>
      <div class="quick-emojis">
        ${ed.slice(0,6).map(D=>`
          <button class="quick-emoji" data-emoji="${D}">${D}</button>
        `).join("")}
      </div>
    </div>
  `,r.addEventListener("mouseenter",()=>{Ai()}),r.addEventListener("mouseleave",()=>{Um()}),r.addEventListener("click",D=>{D.stopPropagation(),yo=!0,Ai()}),(P=r.querySelector(".maximize-btn"))==null||P.addEventListener("click",D=>{D.stopPropagation(),yo=!1,Hn(),$I(n)}),(M=r.querySelector("#popup-bookmark-btn"))==null||M.addEventListener("click",D=>{D.stopPropagation(),YI(n.id);const j=r.querySelector("#popup-bookmark-btn");j==null||j.classList.toggle("active",tr.has(n.id))}),(G=r.querySelector("#popup-delete-btn"))==null||G.addEventListener("click",D=>{D.stopPropagation(),confirm("Delete this annotation and all its comments?")&&(Ym(n.id),Hn())});const f=r.querySelector("#popup-comment-btn"),g=r.querySelector("#popup-reply-section");f==null||f.addEventListener("click",D=>{if(D.stopPropagation(),g==null||g.classList.toggle("open"),g!=null&&g.classList.contains("open")){const j=r.querySelector(".popup-reply-input input");j==null||j.focus()}}),r.querySelectorAll(".reaction").forEach(D=>{D.addEventListener("click",j=>{j.stopPropagation();const V=D.dataset.emoji;if(!V)return;const B=n.reactions.find(I=>I.emoji===V);B&&(B.userReacted?(B.count--,B.userReacted=!1,B.count<=0&&(n.reactions=n.reactions.filter(I=>I.emoji!==V))):(B.count++,B.userReacted=!0),jt(),$r(n,V),Hn(),Pc(n,j))})}),($=r.querySelector("#popup-add-reaction"))==null||$.addEventListener("click",D=>{D.stopPropagation();const j=r.querySelector("#popup-reactions");Bm(r,n,j)}),r.querySelectorAll(".quick-emoji").forEach(D=>{D.addEventListener("click",j=>{j.stopPropagation();const V=D.dataset.emoji;if(!V)return;let B=n.reactions.find(I=>I.emoji===V);B?B.userReacted||(B.count++,B.userReacted=!0):n.reactions.push({emoji:V,count:1,userReacted:!0}),jt(),$r(n,V),Hn(),Pc(n,j)})});const m=r.querySelector(".popup-reply-input input"),v=r.querySelector(".popup-reply-input button"),L=()=>{const D=m.value.trim();if(!D)return;const j=ge(),V={authorName:(j==null?void 0:j.displayName)||"You",text:D,createdAt:Date.now()};n.replies.push(V),jt(),Gm(n,V),m.value="";const B=r.querySelector("#popup-comment-btn");B&&(B.innerHTML=`💬 ${n.replies.length}`)};v==null||v.addEventListener("click",D=>{D.stopPropagation(),L()}),m==null||m.addEventListener("keypress",D=>{D.key==="Enter"&&(D.stopPropagation(),L())}),Et.appendChild(r),Nr=r,setTimeout(()=>{document.addEventListener("click",jm)},10)}function qI(n){return`
    ${n.reactions.map(e=>`
      <div class="reaction ${e.userReacted?"active":""}" data-emoji="${e.emoji}">
        <span class="emoji">${e.emoji}</span>
        <span class="count">${e.count}</span>
      </div>
    `).join("")}
    <div class="reaction add-reaction" id="popup-add-reaction">😀+</div>
  `}function BI(n,e){var r;const t=n.querySelector("#popup-reactions");t&&(t.querySelectorAll(".reaction:not(.add-reaction)").forEach(o=>{o.addEventListener("click",i=>{i.stopPropagation();const s=o.dataset.emoji;if(!s)return;const c=e.reactions.find(d=>d.emoji===s);c&&(c.userReacted?(c.count--,c.userReacted=!1,c.count<=0&&(e.reactions=e.reactions.filter(d=>d.emoji!==s))):(c.count++,c.userReacted=!0),jt(),$r(e,s),qm(n,e))})}),(r=t.querySelector("#popup-add-reaction"))==null||r.addEventListener("click",o=>{o.stopPropagation(),Bm(n,e,t)}))}function qm(n,e){const t=n.querySelector("#popup-reactions");t&&(t.innerHTML=qI(e),BI(n,e))}let vo=null;function Bm(n,e,t){Ba();const r=document.createElement("div");r.className="oo-popup-emoji-picker",r.innerHTML=ed.map(o=>`
    <button class="emoji-btn" data-emoji="${o}">${o}</button>
  `).join(""),r.querySelectorAll(".emoji-btn").forEach(o=>{o.addEventListener("click",i=>{i.stopPropagation();const s=o.dataset.emoji;if(!s)return;let c=e.reactions.find(d=>d.emoji===s);c?c.userReacted||(c.count++,c.userReacted=!0):e.reactions.push({emoji:s,count:1,userReacted:!0}),jt(),$r(e,s),qm(n,e),Ba()})}),t.appendChild(r),vo=r,setTimeout(()=>{document.addEventListener("click",$m)},10)}function $m(n){vo&&!vo.contains(n.target)&&Ba()}function Ba(){document.removeEventListener("click",$m),vo&&(vo.remove(),vo=null)}function jm(n){yo&&Nr&&!Nr.contains(n.target)&&Hn()}function Hn(){Ai(),document.removeEventListener("click",jm),Ba(),Nr&&(Nr.remove(),Nr=null),Qt=null,yo=!1}let cn=null;function $I(n){var u,f,g;if(Hn(),ga(),!Et)return;const e=document.createElement("div");e.className="oo-comment-panel open",e.style.pointerEvents="auto";const t=Rc(n.createdAt),r=ge(),o=r?n.authorId===r.uid:n.authorId==="local-user";e.innerHTML=`
    <div class="header">
      <h3>Annotation</h3>
      <button class="close-btn">&times;</button>
    </div>
    <div class="highlighted-text">
      <blockquote>"${Dt(n.text)}"</blockquote>
    </div>
    <div class="main-comment">
      <div class="author-info">
        <div class="avatar">${n.authorName.charAt(0).toUpperCase()}</div>
        <div>
          <div class="author-name">${Dt(n.authorName)}</div>
          <div class="timestamp">${t}</div>
        </div>
      </div>
      <div class="comment-text">${Dt(n.comment)}</div>
      <div class="reactions" id="reactions-container">
        ${n.reactions.map(m=>`
          <div class="reaction ${m.userReacted?"active":""}" data-emoji="${m.emoji}">
            <span class="emoji">${m.emoji}</span>
            <span class="count">${m.count}</span>
          </div>
        `).join("")}
        <div class="reaction add-reaction" id="add-reaction-btn">😀+</div>
      </div>
      ${o?'<button class="delete-btn" id="panel-delete-btn">🗑️ Delete Annotation</button>':""}
    </div>
    <div class="replies-section">
      ${n.replies.map(m=>`
        <div class="reply">
          <div class="author-info">
            <div class="avatar">${m.authorName.charAt(0).toUpperCase()}</div>
            <div>
              <div class="author-name">${Dt(m.authorName)}</div>
              <div class="timestamp">${Rc(m.createdAt)}</div>
            </div>
          </div>
          <div class="comment-text">${Dt(m.text)}</div>
        </div>
      `).join("")}
    </div>
    <div class="reply-input">
      <input type="text" placeholder="Add a reply..." />
      <button>➤</button>
    </div>
  `,e.addEventListener("click",m=>{m.stopPropagation()}),(u=e.querySelector(".close-btn"))==null||u.addEventListener("click",m=>{m.stopPropagation(),ga()}),(f=e.querySelector("#panel-delete-btn"))==null||f.addEventListener("click",m=>{m.stopPropagation(),confirm("Delete this annotation and all its comments?")&&(Ym(n.id),ga())});const i=e.querySelector(".reply-input input"),s=e.querySelector(".reply-input button"),c=()=>{const m=i.value.trim();if(!m)return;const v=ge(),L=(v==null?void 0:v.displayName)||"You",P={authorName:L,text:m,createdAt:Date.now()};n.replies.push(P),jt(),Gm(n,P);const M=e.querySelector(".replies-section");if(M){const G=`
        <div class="reply">
          <div class="author-info">
            <div class="avatar">${L.charAt(0).toUpperCase()}</div>
            <div>
              <div class="author-name">${Dt(L)}</div>
              <div class="timestamp">just now</div>
            </div>
          </div>
          <div class="comment-text">${Dt(m)}</div>
        </div>
      `;M.insertAdjacentHTML("beforeend",G)}i.value="",i.focus()};s==null||s.addEventListener("click",m=>{m.stopPropagation(),c()}),i==null||i.addEventListener("keypress",m=>{m.key==="Enter"&&(m.stopPropagation(),c())});const d=e.querySelector("#reactions-container");e.querySelectorAll(".reaction:not(.add-reaction)").forEach(m=>{m.addEventListener("click",v=>{v.stopPropagation();const L=m.dataset.emoji;if(!L)return;const P=n.reactions.find(M=>M.emoji===L);P&&(P.userReacted?(P.count--,P.userReacted=!1,P.count<=0&&(n.reactions=n.reactions.filter(M=>M.emoji!==L))):(P.count++,P.userReacted=!0),jt(),$r(n,L),nd(n,d))})}),(g=e.querySelector("#add-reaction-btn"))==null||g.addEventListener("click",m=>{m.stopPropagation(),zm(n,m.target,d)}),Et.appendChild(e),cn=e,kr=n,setTimeout(()=>i==null?void 0:i.focus(),100),setTimeout(()=>{document.addEventListener("click",Hm)},50)}let _o=null;function zm(n,e,t){Cc();const r=document.createElement("div");r.className="oo-emoji-picker",e.getBoundingClientRect(),r.style.bottom="40px",r.style.left="0",r.innerHTML=ed.map(o=>`
    <button class="emoji-btn" data-emoji="${o}">${o}</button>
  `).join(""),r.querySelectorAll(".emoji-btn").forEach(o=>{o.addEventListener("click",i=>{i.stopPropagation();const s=o.dataset.emoji;if(!s)return;let c=n.reactions.find(d=>d.emoji===s);c?c.userReacted||(c.count++,c.userReacted=!0):n.reactions.push({emoji:s,count:1,userReacted:!0}),jt(),$r(n,s),nd(n,t),Cc()})}),t.style.position="relative",t.appendChild(r),_o=r,setTimeout(()=>{document.addEventListener("click",Wm)},10)}function Wm(n){_o&&!_o.contains(n.target)&&Cc()}function Cc(){document.removeEventListener("click",Wm),_o&&(_o.remove(),_o=null)}function nd(n,e){var t;e&&(e.innerHTML=`
    ${n.reactions.map(r=>`
      <div class="reaction ${r.userReacted?"active":""}" data-emoji="${r.emoji}">
        <span class="emoji">${r.emoji}</span>
        <span class="count">${r.count}</span>
      </div>
    `).join("")}
    <div class="reaction add-reaction" id="add-reaction-btn">😀+</div>
  `,e.querySelectorAll(".reaction:not(.add-reaction)").forEach(r=>{r.addEventListener("click",o=>{o.stopPropagation();const i=r.dataset.emoji;if(!i)return;const s=n.reactions.find(c=>c.emoji===i);s&&(s.userReacted?(s.count--,s.userReacted=!1,s.count<=0&&(n.reactions=n.reactions.filter(c=>c.emoji!==i))):(s.count++,s.userReacted=!0),jt(),$r(n,i),nd(n,e))})}),(t=e.querySelector("#add-reaction-btn"))==null||t.addEventListener("click",r=>{r.stopPropagation(),zm(n,r.target,e)}))}function Hm(n){cn&&!cn.contains(n.target)&&ga()}function ga(){document.removeEventListener("click",Hm),cn&&(cn.remove(),cn=null),kr=null}function Dt(n){const e=document.createElement("div");return e.textContent=n,e.innerHTML}function Rc(n){const e=Math.floor((Date.now()-n)/1e3);return e<60?"just now":e<3600?`${Math.floor(e/60)}m ago`:e<86400?`${Math.floor(e/3600)}h ago`:e<604800?`${Math.floor(e/86400)}d ago`:new Date(n).toLocaleDateString()}function jt(){const n=pr();localStorage.setItem(`oo_annotations_${n}`,JSON.stringify(st)),console.log("[OpenOverlay] Saved",st.length,"annotations locally")}async function jI(n){if(!Kr()){console.log("[OpenOverlay] Firestore not available, skipping cloud save");return}const e=ge(),t=pr();console.log("[OpenOverlay] Saving annotation to cloud:",n.id,"pageKey:",t);const r={id:n.id,pageKey:t,text:n.text,contextBefore:n.contextBefore||"",contextAfter:n.contextAfter||"",anchorSelector:n.anchorSelector,anchorOffset:n.anchorOffset,focusSelector:n.focusSelector,focusOffset:n.focusOffset,comment:n.comment,color:n.color,authorId:(e==null?void 0:e.uid)||n.authorId,authorName:(e==null?void 0:e.displayName)||n.authorName,createdAt:n.createdAt,reactions:n.reactions.map(o=>({emoji:o.emoji,count:o.count,users:o.userReacted&&e?[e.uid]:[]})),replies:n.replies.map(o=>({authorId:"",authorName:o.authorName,text:o.text,createdAt:o.createdAt}))};await pI(t,r)}async function $r(n,e){if(!Kr())return;const t=ge();if(!t)return;const r=pr();await vI(r,n.id,e,t.uid)}async function Gm(n,e){if(!Kr())return;const t=ge(),r=pr();await yI(r,n.id,{authorId:(t==null?void 0:t.uid)||"",authorName:(t==null?void 0:t.displayName)||e.authorName,text:e.text,createdAt:e.createdAt})}function zI(){const n=pr(),e=localStorage.getItem(`oo_annotations_${n}`);if(e)try{st=JSON.parse(e),console.log("[OpenOverlay] Loaded",st.length,"annotations from localStorage")}catch{console.warn("[OpenOverlay] Failed to load annotations"),st=[]}WI()}async function WI(){if(!Kr()){console.log("[OpenOverlay] Firestore not available, skipping real-time sync");return}const n=pr();if(console.log("[OpenOverlay] Setting up real-time sync for page:",n),!mI(n,t=>{Vf(t)})){console.log("[OpenOverlay] Real-time subscription failed, trying one-time fetch");const t=await Lm(n);Vf(t)}}function Vf(n){const e=ge();if(console.log("[OpenOverlay] Processing",n.length,"cloud annotations"),n.length===0){console.log("[OpenOverlay] No cloud annotations found");return}const t=new Map;for(const o of st)t.set(o.id,o);for(const o of n){const i=t.get(o.id),s={id:o.id,text:o.text,contextBefore:o.contextBefore||"",contextAfter:o.contextAfter||"",anchorSelector:o.anchorSelector,anchorOffset:o.anchorOffset,focusSelector:o.focusSelector,focusOffset:o.focusOffset,comment:o.comment,color:o.color,authorId:o.authorId,authorName:o.authorName,createdAt:o.createdAt,reactions:(o.reactions||[]).map(c=>({emoji:c.emoji,count:c.count,userReacted:e?c.users.includes(e.uid):!1})),replies:(o.replies||[]).map(c=>({authorName:c.authorName,text:c.text,createdAt:c.createdAt}))};(!i||o.createdAt>=i.createdAt)&&t.set(o.id,s)}st=Array.from(t.values()),console.log("[OpenOverlay] Merged to",st.length,"total annotations");const r=pr();localStorage.setItem(`oo_annotations_${r}`,JSON.stringify(st)),td(),vl(),HI()}function HI(){if(Qt){const n=st.find(e=>e.id===(Qt==null?void 0:Qt.id));n&&(Qt=n)}if(cn&&kr){const n=st.find(e=>e.id===(kr==null?void 0:kr.id));n&&GI(n)}}function GI(n){if(!cn||!Et)return;const e=cn.querySelector(".replies-section");e&&(e.innerHTML=n.replies.map(t=>`
    <div class="reply">
      <div class="author-info">
        <div class="avatar">${t.authorName.charAt(0).toUpperCase()}</div>
        <div>
          <div class="author-name">${Dt(t.authorName)}</div>
          <div class="timestamp">${Rc(t.createdAt)}</div>
        </div>
      </div>
      <div class="comment-text">${Dt(t.text)}</div>
    </div>
  `).join(""),kr=n,console.log("[OpenOverlay] Comment panel refreshed with",n.replies.length,"replies"))}async function Ym(n){const e=st.find(o=>o.id===n);if(!e)return;const t=ge();if(!(t?e.authorId===t.uid:e.authorId==="local-user")){console.warn("[OpenOverlay] Cannot delete: not the author");return}if(st=st.filter(o=>o.id!==n),jt(),Kr()){const o=pr();await gI(o,n)}tr.has(n)&&(tr.delete(n),Km(n)),td(),vl(),console.log("[OpenOverlay] Annotation deleted:",n)}function YI(n){if(tr.has(n))tr.delete(n),Km(n),console.log("[OpenOverlay] Removed bookmark");else{tr.add(n);const e=st.find(t=>t.id===n);e&&(KI(e),console.log("[OpenOverlay] Added bookmark"))}}function KI(n){const e=_l();e.some(t=>t.id===n.id)||(e.push({id:n.id,pageUrl:window.location.href,pageTitle:document.title,text:n.text,comment:n.comment,authorName:n.authorName,bookmarkedAt:Date.now()}),localStorage.setItem("oo_bookmarks",JSON.stringify(e)))}function Km(n){const e=_l().filter(t=>t.id!==n);localStorage.setItem("oo_bookmarks",JSON.stringify(e))}function _l(){try{return JSON.parse(localStorage.getItem("oo_bookmarks")||"[]")}catch{return[]}}function XI(){const n=_l();tr=new Set(n.map(e=>e.id))}function pr(){return btoa(window.location.href).slice(0,32)}let gi=null,x=null,Tr=!1,Ft="none",Xm="solid",Qm="normal",Jm="none",ki=!1,bo=!1,Ke="normal",ns="",Er="play",Ff="spawn",Oc=!1,Nc=null,en=!1,wo=null,nr=0,Pi=!1;const QI=["#ff3366","#ff6b35","#f59e0b","#22c55e","#06b6d4","#3b82f6","#8b5cf6","#ec4899","#ef4444","#000000","#ffffff","#6b7280"],JI=[{id:"solid",label:"━",title:"Solid"},{id:"spray",label:"░",title:"Spray"},{id:"dots",label:"•••",title:"Dots"},{id:"square",label:"▬",title:"Square"},{id:"rainbow",label:"🌈",title:"Rainbow"},{id:"glow",label:"✦",title:"Glow"}],ZI=[{id:"normal",label:"A",title:"Normal"},{id:"rainbow",label:"🌈",title:"Rainbow"},{id:"aged",label:"🏚️",title:"Aged"}],eS=[{id:"none",label:"✏️",title:"Freehand"},{id:"line",label:"╱",title:"Line"},{id:"rectangle",label:"▢",title:"Rectangle"},{id:"circle",label:"○",title:"Circle"},{id:"triangle",label:"△",title:"Triangle"},{id:"star",label:"☆",title:"Star"}],tS=["😀","😂","🤣","😍","🥰","😎","🤩","😜","😭","😤","🤯","🥺","😱","🤮","💀","👻","👍","👎","👏","🙌","🤝","✌️","🤟","👋","💪","🫶","🙏","👀","🧠","💅","🦾","🫡","❤️","🧡","💛","💚","💙","💜","🖤","💔","⭐","✨","🔥","💯","💥","💫","🎯","🏆","🐶","🐱","🐻","🦊","🐸","🐵","🦄","🐝","🍕","🍔","🌮","🍩","☕","🎂","🍿","🥤","⚽","🏀","🎮","🎸","🎤","🎬","📸","💻","🚀","💎","🎁","🎈","🎉","🪄","⚡","🌈"],nS=`
  * {
    box-sizing: border-box;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  }

  .fab-container {
    all: initial;
    position: fixed !important;
    right: 18px !important;
    bottom: 18px !important;
    z-index: 2147483647 !important;
    display: flex !important;
    flex-direction: column-reverse !important;
    align-items: center !important;
    gap: 8px !important;
    pointer-events: auto !important;
    touch-action: none !important;
    visibility: visible !important;
    opacity: 1 !important;
    transform: none !important;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif !important;
  }

  .fab-container.dragging {
    opacity: 0.8;
  }

  .fab-container.dragging .fab {
    cursor: grabbing;
  }

  .fab {
    all: initial;
    width: 56px !important;
    height: 56px !important;
    min-width: 56px !important;
    min-height: 56px !important;
    border-radius: 50% !important;
    border: none !important;
    background: rgba(255, 255, 255, 0.95) !important;
    color: #222 !important;
    font-size: 20px !important;
    cursor: pointer !important;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15) !important;
    transition: transform 0.15s, background 0.15s !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    visibility: visible !important;
    opacity: 1 !important;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif !important;
  }

  .fab:hover {
    transform: scale(1.05);
  }

  .fab.open {
    background: #22c55e;
    color: white;
  }

  .quick-explore {
    position: absolute;
    bottom: -8px;
    left: -8px;
    width: 24px;
    height: 24px;
    border-radius: 50%;
    border: 2px solid white;
    background: #ff69b4;
    color: white;
    font-size: 12px;
    cursor: pointer;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.25);
    transition: transform 0.15s, opacity 0.15s;
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 1;
  }

  .quick-explore:hover {
    transform: scale(1.15);
  }

  .fab-container.open .quick-explore {
    display: none;
  }

  .quick-visibility {
    position: absolute;
    bottom: -8px;
    right: -8px;
    width: 24px;
    height: 24px;
    border-radius: 50%;
    border: 2px solid white;
    background: #3b82f6;
    color: white;
    font-size: 11px;
    cursor: pointer;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.25);
    transition: transform 0.15s, opacity 0.15s;
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 1;
  }

  .quick-visibility:hover {
    transform: scale(1.15);
  }

  .quick-visibility.hidden {
    background: #64748b;
    opacity: 0.7;
  }

  .quick-visibility.hidden::after {
    content: '';
    position: absolute;
    width: 18px;
    height: 2px;
    background: #ef4444;
    transform: rotate(-45deg);
    border-radius: 1px;
  }

  .fab-container.open .quick-visibility {
    display: none;
  }

  .dismiss-smudgy {
    position: absolute;
    top: -8px;
    left: -8px;
    width: 20px;
    height: 20px;
    border-radius: 50%;
    border: 2px solid white;
    background: #ef4444;
    color: white;
    font-size: 10px;
    cursor: pointer;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.25);
    transition: transform 0.15s, opacity 0.15s;
    display: none;
    align-items: center;
    justify-content: center;
    font-weight: bold;
  }

  .dismiss-smudgy:hover {
    transform: scale(1.15);
  }

  .dismiss-smudgy.show {
    display: flex;
  }

  .mini {
    width: 44px;
    height: 44px;
    border-radius: 50%;
    border: none;
    background: #fff;
    color: #222;
    font-size: 18px;
    cursor: pointer;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.12);
    transition: transform 0.15s, opacity 0.15s;
    opacity: 0;
    transform: scale(0.5);
    pointer-events: none;
  }

  .mini.show {
    opacity: 1;
    transform: scale(1);
    pointer-events: auto;
  }

  .mini:hover {
    transform: scale(1.1);
  }

  .mini.active {
    background: #22c55e;
    color: white;
  }

  .toolbar {
    position: fixed;
    right: 90px;
    bottom: 18px;
    background: #111;
    color: #fff;
    padding: 10px;
    border-radius: 10px;
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.3);
    display: none;
    flex-direction: column;
    gap: 8px;
    align-items: stretch;
    pointer-events: auto;
    z-index: 2147483647;
    max-width: 320px;
  }

  .toolbar.game-mode {
    flex-direction: column;
    align-items: stretch;
  }

  .toolbar-drag-handle {
    cursor: grab;
    padding: 2px 8px;
    color: #666;
    font-size: 12px;
    user-select: none;
    text-align: center;
  }

  .toolbar-drag-handle:hover {
    color: #999;
  }

  .toolbar-drag-handle:active {
    cursor: grabbing;
  }

  .toolbar.game-mode .toolbar-drag-handle {
    align-self: center;
    margin-bottom: -4px;
  }

  .toolbar.show {
    display: flex;
  }

  .toolbar-row {
    display: flex;
    align-items: center;
    gap: 6px;
    flex-wrap: wrap;
  }

  .toolbar-section {
    display: flex;
    align-items: center;
    gap: 4px;
  }

  .toolbar-divider {
    display: none;
  }

  .toolbar label {
    font-size: 11px;
    color: #888;
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }

  .toolbar input[type="color"] {
    width: 24px;
    height: 24px;
    border: 2px solid #333;
    border-radius: 50%;
    cursor: pointer;
    padding: 0;
    background: none;
    flex-shrink: 0;
  }

  .toolbar input[type="color"]::-webkit-color-swatch-wrapper {
    padding: 0;
  }

  .toolbar input[type="color"]::-webkit-color-swatch {
    border: none;
    border-radius: 50%;
  }

  .toolbar input[type="range"] {
    height: 6px;
    -webkit-appearance: none;
    background: #333;
    border-radius: 3px;
  }

  .toolbar input[type="range"]::-webkit-slider-thumb {
    -webkit-appearance: none;
    width: 18px;
    height: 18px;
    background: #fff;
    border-radius: 50%;
    cursor: pointer;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
  }

  .quick-colors {
    display: grid;
    grid-template-columns: repeat(4, 14px);
    gap: 2px;
  }

  .quick-color {
    width: 14px;
    height: 14px;
    border-radius: 50%;
    border: 2px solid transparent;
    cursor: pointer;
    transition: transform 0.1s;
  }

  .quick-color:hover {
    transform: scale(1.15);
  }

  .quick-color.active {
    border-color: #fff;
    box-shadow: 0 0 0 1px #000;
  }

  .quick-color[data-color="#ffffff"] {
    border-color: #ccc;
  }

  .quick-color[data-color="#000000"] {
    border-color: #333;
  }

  .toolbar.game-mode .quick-colors {
    grid-template-columns: repeat(4, 14px);
  }

  .brush-styles {
    display: flex;
    gap: 2px;
  }

  .brush-btn {
    width: 28px;
    height: 28px;
    border: none;
    background: #222;
    color: #aaa;
    border-radius: 6px;
    cursor: pointer;
    font-size: 14px;
    transition: background 0.1s;
  }

  .brush-btn:hover {
    background: #333;
  }

  .brush-btn.active {
    background: #22c55e;
    color: white;
  }

  .tool-btn {
    width: 32px;
    height: 32px;
    border: none;
    background: #222;
    color: #aaa;
    border-radius: 8px;
    cursor: pointer;
    font-size: 16px;
    transition: background 0.1s;
  }

  .tool-btn:hover {
    background: #333;
  }

  .tool-btn.active {
    background: #ef4444;
    color: white;
  }

  .eraser-btn {
    width: 36px;
    height: 32px;
    background: #222;
    border: 1px solid #333;
    border-radius: 6px;
    font-size: 16px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .eraser-btn:hover {
    background: #333;
  }

  .eraser-btn.active {
    background: #ef4444;
    color: white;
  }

  .shape-tools {
    display: flex;
    gap: 2px;
  }

  .shape-btn {
    width: 28px;
    height: 28px;
    border: none;
    background: #222;
    color: #aaa;
    border-radius: 6px;
    cursor: pointer;
    font-size: 14px;
    transition: background 0.1s;
  }

  .shape-btn:hover {
    background: #333;
  }

  .shape-btn.active {
    background: #8b5cf6;
    color: white;
  }

  .fill-btn {
    width: 28px;
    height: 28px;
    border: none;
    background: #222;
    color: #aaa;
    border-radius: 6px;
    cursor: pointer;
    font-size: 16px;
    margin-left: 4px;
  }

  .fill-btn:hover {
    background: #333;
  }

  .fill-btn.active {
    background: #f59e0b;
    color: white;
  }

  .toolbar button.action-btn {
    padding: 5px 10px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 11px;
    font-weight: 600;
    transition: background 0.1s;
  }

  .btn-undo {
    background: #333;
    color: #fff;
  }

  .btn-undo:hover {
    background: #444;
  }

  .btn-clear {
    background: #333;
    color: #fff;
  }

  .btn-clear:hover {
    background: #444;
  }

  .btn-save {
    background: #22c55e;
    color: white;
  }

  .btn-save:hover {
    background: #16a34a;
  }

  .btn-cancel {
    background: #333;
    color: white;
  }

  .btn-cancel:hover {
    background: #444;
  }

  .size-display {
    font-size: 11px;
    color: #888;
    min-width: 20px;
    text-align: center;
  }

  .opacity-display {
    font-size: 11px;
    color: #888;
    min-width: 28px;
    text-align: center;
  }

  .draw-controls, .text-controls {
    display: none;
    flex-direction: column;
    gap: 6px;
  }

  .draw-controls.active, .text-controls.active {
    display: flex;
  }

  .text-input {
    background: #222;
    border: 1px solid #333;
    border-radius: 6px;
    color: #fff;
    padding: 6px 10px;
    font-size: 13px;
    flex: 1;
    min-width: 100px;
    font-family: inherit;
  }

  .text-input:focus {
    outline: none;
    border-color: #22c55e;
  }

  .text-input::placeholder {
    color: #666;
  }

  .emoji-btn {
    width: 36px;
    height: 32px;
    background: #222;
    border: 1px solid #333;
    border-radius: 6px;
    font-size: 18px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .emoji-btn:hover {
    background: #333;
  }

  .emoji-picker {
    display: none;
    position: absolute;
    bottom: 100%;
    left: 0;
    right: 0;
    margin-bottom: 8px;
    background: #1a1a1a;
    border: 1px solid #333;
    border-radius: 8px;
    padding: 8px;
    max-height: 200px;
    overflow-y: auto;
    z-index: 100;
  }

  .emoji-picker.show {
    display: block;
  }

  .emoji-picker-header {
    font-size: 10px;
    color: #888;
    text-transform: uppercase;
    margin-bottom: 6px;
    padding-bottom: 4px;
    border-bottom: 1px solid #333;
  }

  .emoji-grid {
    display: grid;
    grid-template-columns: repeat(8, 1fr);
    gap: 2px;
  }

  .emoji-item {
    width: 32px;
    height: 32px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 20px;
    cursor: pointer;
    border-radius: 4px;
    background: transparent;
    border: none;
  }

  .emoji-item:hover {
    background: #333;
  }

  .text-styles {
    display: flex;
    gap: 2px;
  }

  .text-style-btn {
    width: 32px;
    height: 32px;
    border: none;
    background: #222;
    color: #aaa;
    border-radius: 6px;
    cursor: pointer;
    font-size: 14px;
    transition: background 0.1s;
  }

  .text-style-btn:hover {
    background: #333;
  }

  .text-style-btn.active {
    background: #22c55e;
    color: white;
  }

  .place-hint {
    font-size: 11px;
    color: #666;
    font-style: italic;
  }

  .game-controls {
    display: none;
    flex-direction: column;
    gap: 8px;
  }

  .game-controls.active {
    display: flex;
  }

  .game-row {
    display: flex;
    align-items: center;
    gap: 6px;
    justify-content: center;
  }

  .game-actions {
    display: flex;
    gap: 4px;
    margin-left: auto;
  }

  .game-colors {
    display: flex;
    gap: 3px;
  }

  .toolbar.game-mode .drawing-only {
    display: none !important;
  }

  .toolbar.game-mode > .toolbar-row,
  .toolbar.game-mode > .toolbar-section,
  .toolbar.game-mode > .toolbar-divider {
    display: none !important;
  }

  .toolbar.game-mode > .toolbar-drag-handle,
  .toolbar.game-mode > .game-controls {
    display: flex !important;
  }

  .char-style-toggle {
    display: flex;
    background: #222;
    border-radius: 4px;
    padding: 2px;
  }

  .char-style-btn {
    padding: 3px 6px;
    border: none;
    background: transparent;
    border-radius: 3px;
    cursor: pointer;
    font-size: 14px;
    transition: background 0.1s;
  }

  .char-style-btn:hover {
    background: #333;
  }

  .char-style-btn.active {
    background: #22c55e;
  }

  .char-customize-select {
    background: #222;
    color: #fff;
    border: 1px solid #333;
    border-radius: 4px;
    padding: 3px 4px;
    font-size: 14px;
    cursor: pointer;
    min-width: 36px;
    text-align: center;
  }

  .char-customize-select:hover {
    border-color: #555;
  }

  .char-customize-select:focus {
    outline: none;
    border-color: #22c55e;
  }

  .screen-name-section {
    margin: 16px 0;
    padding: 12px;
    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
    border-radius: 10px;
    border: 2px solid #0f3460;
  }

  .screen-name-label {
    display: block;
    font-size: 13px;
    color: #e94560;
    margin-bottom: 8px;
    text-transform: uppercase;
    letter-spacing: 1px;
    font-weight: bold;
    text-align: center;
  }

  .screen-name-input {
    width: 100%;
    background: #0a0a15;
    color: #fff;
    border: 2px solid #e94560;
    border-radius: 8px;
    padding: 10px 14px;
    font-size: 18px;
    font-family: "Comic Sans MS", "Chalkboard SE", cursive;
    text-align: center;
    box-sizing: border-box;
  }

  .screen-name-input::placeholder {
    color: #666;
    font-style: italic;
  }

  .screen-name-input:focus {
    outline: none;
    border-color: #22c55e;
    background: #111;
    box-shadow: 0 0 10px rgba(233, 69, 96, 0.3);
  }

  .game-mode-toggle {
    display: flex;
    background: #222;
    border-radius: 6px;
    padding: 2px;
  }

  .game-mode-btn {
    padding: 4px 8px;
    border: none;
    background: transparent;
    color: #888;
    border-radius: 4px;
    cursor: pointer;
    font-size: 14px;
    transition: background 0.1s, color 0.1s;
  }

  .game-mode-btn:hover {
    color: #fff;
  }

  .game-mode-btn.active {
    background: #22c55e;
    color: white;
  }

  .build-tools-section {
    display: flex;
    align-items: center;
  }

  .game-tools {
    display: flex;
    gap: 2px;
  }

  .game-tool-btn {
    width: 28px;
    height: 28px;
    padding: 0;
    border: none;
    background: #222;
    color: #aaa;
    border-radius: 4px;
    cursor: pointer;
    font-size: 13px;
    transition: background 0.1s;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .game-tool-btn:hover {
    background: #333;
  }

  .game-tool-btn.active {
    background: #3b82f6;
    color: white;
  }

  .multiplayer-btn {
    padding: 4px 8px;
    border: none;
    background: #7c3aed;
    color: #fff;
    border-radius: 4px;
    cursor: pointer;
    font-size: 11px;
    font-weight: 600;
    transition: background 0.1s;
  }

  .multiplayer-btn:hover {
    background: #6d28d9;
  }

  .multiplayer-btn.active {
    background: #22c55e;
  }

  .mini.game-btn {
    background: #8b5cf6;
    color: white;
  }

  .mini.game-btn.active {
    background: #22c55e;
  }

  /* Profile button */
  .mini.profile-btn {
    padding: 0;
    overflow: hidden;
  }

  .mini.profile-btn img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    border-radius: 50%;
  }

  /* Profile modal */
  .profile-modal {
    position: fixed;
    bottom: 80px;
    right: 20px;
    width: 320px;
    max-height: calc(100vh - 100px);
    background: #111;
    border-radius: 16px;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
    display: none;
    flex-direction: column;
    overflow-y: auto;
    z-index: 2147483647;
    pointer-events: auto;
  }

  .profile-modal.show {
    display: flex;
  }

  .profile-close {
    position: absolute;
    top: 10px;
    right: 10px;
    width: 28px;
    height: 28px;
    border: none;
    background: #333;
    color: #fff;
    border-radius: 50%;
    font-size: 18px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 10;
  }

  .profile-close:hover {
    background: #444;
  }

  .profile-header {
    padding: 20px;
    display: flex;
    align-items: center;
    gap: 16px;
    border-bottom: 1px solid #333;
  }

  .profile-avatar {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    object-fit: cover;
    border: 2px solid #3b82f6;
  }

  .profile-info {
    flex: 1;
  }

  .profile-name {
    font-size: 18px;
    font-weight: bold;
    color: #fff;
    margin: 0 0 4px 0;
  }

  .profile-email {
    font-size: 12px;
    color: #888;
    margin: 0;
  }

  .profile-stats {
    display: flex;
    gap: 20px;
    padding: 16px 20px;
    border-bottom: 1px solid #333;
  }

  .profile-stat {
    text-align: center;
    cursor: pointer;
  }

  .profile-stat:hover {
    opacity: 0.8;
  }

  .profile-stat-value {
    font-size: 20px;
    font-weight: bold;
    color: #fff;
  }

  .profile-stat-label {
    font-size: 11px;
    color: #888;
    text-transform: uppercase;
  }

  .profile-stat {
    position: relative;
  }

  .notification-badge {
    position: absolute;
    top: -5px;
    right: -5px;
    background: #ef4444;
    color: white;
    font-size: 10px;
    font-weight: bold;
    min-width: 16px;
    height: 16px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 0 4px;
    animation: pulse 2s infinite;
  }

  @keyframes pulse {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.1); }
  }

  .followers-panel {
    display: none;
    padding: 12px 20px;
    border-bottom: 1px solid #333;
    background: rgba(34, 197, 94, 0.1);
  }

  .followers-panel.show {
    display: block;
  }

  .followers-panel-header {
    font-size: 12px;
    font-weight: bold;
    color: #22c55e;
    margin-bottom: 8px;
    text-transform: uppercase;
  }

  .follower-item {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 8px 0;
    border-bottom: 1px solid #333;
  }

  .follower-item:last-child {
    border-bottom: none;
  }

  .follower-avatar {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    object-fit: cover;
    background: #333;
  }

  .follower-info {
    flex: 1;
  }

  .follower-name {
    font-size: 14px;
    color: #fff;
    font-weight: 500;
  }

  .follower-time {
    font-size: 11px;
    color: #888;
  }

  .no-followers {
    color: #666;
    font-size: 13px;
    font-style: italic;
    padding: 8px 0;
  }

  .profile-bio {
    padding: 16px 20px;
    border-bottom: 1px solid #333;
  }

  .profile-bio-label {
    font-size: 11px;
    color: #888;
    text-transform: uppercase;
    margin-bottom: 6px;
  }

  .profile-bio-content {
    color: #ccc;
    font-size: 14px;
    cursor: pointer;
    padding: 8px;
    border-radius: 6px;
    transition: background 0.2s;
  }

  .profile-bio-content:hover {
    background: rgba(255,255,255,0.05);
  }

  .profile-bio-empty {
    color: #666;
    font-style: italic;
  }

  .profile-bio-input {
    width: 100%;
    background: #1a1a1a;
    border: 1px solid #444;
    border-radius: 6px;
    padding: 8px;
    color: #fff;
    font-size: 14px;
    resize: none;
    font-family: inherit;
  }

  .profile-bio-input:focus {
    outline: none;
    border-color: #3b82f6;
  }

  .profile-bio-actions {
    display: flex;
    gap: 8px;
    margin-top: 8px;
  }

  .profile-bio-save {
    background: #22c55e;
    color: white;
    border: none;
    padding: 6px 12px;
    border-radius: 4px;
    font-size: 12px;
    cursor: pointer;
  }

  .profile-bio-cancel {
    background: #666;
    color: white;
    border: none;
    padding: 6px 12px;
    border-radius: 4px;
    font-size: 12px;
    cursor: pointer;
  }

  .profile-actions {
    padding: 16px 20px;
    display: flex;
    gap: 10px;
  }

  .feedback-section {
    padding: 12px 20px;
    border-bottom: 1px solid #333;
    background: linear-gradient(135deg, rgba(34, 197, 94, 0.1) 0%, rgba(59, 130, 246, 0.1) 100%);
  }

  .feedback-header {
    color: #fff;
    font-size: 13px;
    font-weight: 600;
    margin-bottom: 10px;
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .beta-badge {
    background: linear-gradient(135deg, #22c55e, #3b82f6);
    color: white;
    font-size: 9px;
    font-weight: 700;
    padding: 2px 6px;
    border-radius: 4px;
    letter-spacing: 0.5px;
  }

  .feedback-form {
    display: flex;
    flex-direction: column;
    gap: 8px;
  }

  .feedback-select {
    background: #222;
    border: 1px solid #333;
    border-radius: 6px;
    color: #fff;
    padding: 8px 10px;
    font-size: 13px;
    cursor: pointer;
  }

  .feedback-select:focus {
    outline: none;
    border-color: #22c55e;
  }

  .feedback-textarea {
    background: #222;
    border: 1px solid #333;
    border-radius: 6px;
    color: #fff;
    padding: 8px 10px;
    font-size: 13px;
    resize: none;
    font-family: inherit;
  }

  .feedback-textarea:focus {
    outline: none;
    border-color: #22c55e;
  }

  .feedback-textarea::placeholder {
    color: #666;
  }

  .feedback-submit {
    background: #22c55e;
    color: white;
    border: none;
    border-radius: 6px;
    padding: 8px 16px;
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
    transition: background 0.2s;
  }

  .feedback-submit:hover {
    background: #16a34a;
  }

  .feedback-submit:disabled {
    background: #333;
    color: #666;
    cursor: not-allowed;
  }

  .feedback-success {
    color: #22c55e;
    font-size: 13px;
    text-align: center;
    padding: 10px;
  }

  .profile-settings {
    padding: 12px 20px;
    border-bottom: 1px solid #333;
  }

  .profile-settings-header {
    color: #888;
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 8px;
  }

  .profile-setting-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 8px 0;
  }

  .profile-setting-label {
    color: #ccc;
    font-size: 14px;
  }

  .profile-contributors {
    margin-top: 16px;
    padding-top: 12px;
    border-top: 1px solid #333;
  }

  .profile-contributors-header {
    color: #888;
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 8px;
  }

  .contributors-list {
    max-height: 150px;
    overflow-y: auto;
  }

  .no-contributors {
    color: #666;
    font-size: 13px;
    font-style: italic;
    padding: 8px 0;
  }

  .contributor-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 6px 0;
    gap: 10px;
  }

  .contributor-info {
    display: flex;
    align-items: center;
    gap: 8px;
    flex: 1;
    min-width: 0;
  }

  .contributor-avatar {
    width: 24px;
    height: 24px;
    border-radius: 50%;
    background: #333;
    object-fit: cover;
    flex-shrink: 0;
  }

  .contributor-name {
    color: #ddd;
    font-size: 13px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .contributor-toggle {
    flex-shrink: 0;
  }

  .contributor-actions {
    display: flex;
    align-items: center;
    gap: 8px;
    flex-shrink: 0;
  }

  .follow-btn {
    padding: 4px 10px;
    border-radius: 12px;
    border: none;
    font-size: 11px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s;
  }

  .follow-btn.follow {
    background: #3b82f6;
    color: white;
  }

  .follow-btn.follow:hover {
    background: #2563eb;
  }

  .follow-btn.following {
    background: #333;
    color: #aaa;
  }

  .follow-btn.following:hover {
    background: #ef4444;
    color: white;
  }

  .toggle-switch {
    position: relative;
    width: 44px;
    height: 24px;
    background: #333;
    border-radius: 12px;
    cursor: pointer;
    transition: background 0.2s;
  }

  .toggle-switch.active {
    background: #22c55e;
  }

  .toggle-switch::after {
    content: '';
    position: absolute;
    top: 2px;
    left: 2px;
    width: 20px;
    height: 20px;
    background: #fff;
    border-radius: 50%;
    transition: transform 0.2s;
  }

  .toggle-switch.active::after {
    transform: translateX(20px);
  }

  .toggle-switch.small {
    width: 32px;
    height: 18px;
    border-radius: 9px;
  }

  .toggle-switch.small::after {
    width: 14px;
    height: 14px;
  }

  .toggle-switch.small.active::after {
    transform: translateX(14px);
  }

  .char-toggle-profile {
    display: flex;
    gap: 4px;
  }

  .char-btn-profile {
    width: 32px;
    height: 32px;
    border-radius: 6px;
    border: 2px solid #333;
    background: #222;
    font-size: 16px;
    cursor: pointer;
    transition: all 0.15s;
  }

  .char-btn-profile:hover {
    border-color: #555;
  }

  .char-btn-profile.active {
    border-color: #22c55e;
    background: #22c55e22;
  }

  .body-part-toggles {
    display: flex;
    gap: 4px;
  }

  .part-toggle {
    width: 28px;
    height: 28px;
    border-radius: 50%;
    border: 2px solid #444;
    background: #222;
    font-size: 12px;
    cursor: pointer;
    transition: all 0.15s;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .part-toggle:hover {
    border-color: #666;
    transform: scale(1.05);
  }

  .part-toggle.active {
    border-color: #22c55e;
    background: #22c55e22;
  }

  .profile-color-picker {
    display: flex;
    align-items: center;
  }

  .profile-color-swatches {
    display: flex;
    gap: 4px;
    flex-wrap: wrap;
  }

  .profile-color-swatch {
    width: 24px;
    height: 24px;
    border-radius: 50%;
    border: 2px solid #333;
    cursor: pointer;
    transition: all 0.15s;
  }

  .profile-color-swatch:hover {
    transform: scale(1.1);
    border-color: #555;
  }

  .profile-color-swatch.active {
    border-color: #fff;
    box-shadow: 0 0 0 2px #22c55e;
  }

  .profile-select {
    background: #222;
    color: #fff;
    border: 1px solid #333;
    border-radius: 6px;
    padding: 6px 10px;
    font-size: 13px;
    cursor: pointer;
  }

  .profile-select:focus {
    outline: none;
    border-color: #22c55e;
  }

  .profile-bookmarks {
    padding: 12px 20px;
    border-bottom: 1px solid #333;
    max-height: 200px;
    overflow-y: auto;
  }

  .profile-bookmarks-header {
    color: #888;
    font-size: 12px;
    text-transform: uppercase;
    margin-bottom: 10px;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .profile-bookmarks-count {
    background: #333;
    padding: 2px 8px;
    border-radius: 10px;
    font-size: 11px;
  }

  .bookmark-item {
    background: #222;
    border-radius: 8px;
    padding: 10px;
    margin-bottom: 8px;
    cursor: pointer;
    transition: background 0.15s;
  }

  .bookmark-item:hover {
    background: #333;
  }

  .bookmark-quote {
    color: #fff;
    font-size: 13px;
    margin-bottom: 4px;
    font-style: italic;
  }

  .bookmark-meta {
    color: #888;
    font-size: 11px;
  }

  .no-bookmarks {
    color: #666;
    font-size: 13px;
    font-style: italic;
    text-align: center;
    padding: 20px;
  }

  .profile-btn {
    flex: 1;
    padding: 10px 16px;
    border: none;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    transition: background 0.15s;
  }

  .profile-btn.primary {
    background: #3b82f6;
    color: white;
  }

  .profile-btn.primary:hover {
    background: #2563eb;
  }

  .profile-btn.secondary {
    background: #333;
    color: #fff;
  }

  .profile-btn.secondary:hover {
    background: #444;
  }

  .profile-btn.danger {
    background: #ef4444;
    color: white;
  }

  .profile-btn.danger:hover {
    background: #dc2626;
  }

  .login-prompt {
    padding: 40px 20px;
    text-align: center;
  }

  .login-prompt p {
    color: #888;
    margin: 0 0 20px 0;
  }

  .login-btn {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    padding: 12px 24px;
    background: #fff;
    color: #333;
    border: none;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
  }

  .login-btn:hover {
    background: #f0f0f0;
  }

  .login-btn img {
    width: 20px;
    height: 20px;
  }
`;function rS(){if(console.log("[OpenOverlay] initUI starting..."),!document.body){console.error("[OpenOverlay] No document.body!");return}gi=document.createElement("div"),gi.id="openoverlay-ui",gi.style.cssText=`
    all: initial;
    position: fixed !important;
    top: 0 !important;
    left: 0 !important;
    right: 0 !important;
    bottom: 0 !important;
    width: 100vw !important;
    height: 100vh !important;
    z-index: 2147483647 !important;
    pointer-events: none !important;
    overflow: visible !important;
    display: block !important;
    visibility: visible !important;
    opacity: 1 !important;
    transform: none !important;
    margin: 0 !important;
    padding: 0 !important;
    border: none !important;
    box-sizing: border-box !important;
  `,x=gi.attachShadow({mode:"open"});const n=document.createElement("style");n.textContent=nS,x.appendChild(n);const e=document.createElement("div");e.className="fab-container";const t=document.createElement("button");t.className="fab",t.textContent="•••",t.title="OpenOverlay",t.onclick=()=>{var V;en&&(en=!1,(V=x==null?void 0:x.querySelector("#oo-profile-modal"))==null||V.classList.remove("show")),Zm()},e.appendChild(t);const r=document.createElement("button");r.className="quick-explore",r.textContent="🏃",r.title="Quick drop Smudgy";let o=!1;r.onclick=V=>{V.stopPropagation(),o?(o=!1,Ft="none",r.style.background="#ff69b4",document.dispatchEvent(new CustomEvent("oo:gamemode",{detail:{mode:"none"}}))):(o=!0,Ft="game",r.style.background="#22c55e",document.dispatchEvent(new CustomEvent("oo:gamemode",{detail:{mode:"play",playmode:"explore"}})))},document.addEventListener("oo:gamemode",V=>{V.detail.mode==="none"?(o=!1,r.style.background="#ff69b4"):V.detail.mode==="play"&&V.detail.playmode==="explore"&&(o=!0,r.style.background="#22c55e")}),e.appendChild(r);const i=document.createElement("button");i.className="quick-visibility",i.innerHTML="👁",i.title="Hide drawings";let s=!0;const c=()=>{i.classList.toggle("hidden",!s),i.title=s?"Hide drawings":"Show drawings"};i.onclick=V=>{var B;V.stopPropagation(),s=!s,c(),Be.showAll=s,(B=x==null?void 0:x.querySelector("#toggle-all-drawings"))==null||B.classList.toggle("active",s),document.dispatchEvent(new CustomEvent("oo:visibility:all",{detail:{show:s}}))},document.addEventListener("oo:visibility:all",V=>{s=V.detail.show,c()}),e.appendChild(i);const d=document.createElement("button");d.className="dismiss-smudgy",d.textContent="✕",d.title="Dismiss Smudgy",d.onclick=V=>{V.stopPropagation(),document.dispatchEvent(new CustomEvent("oo:dismisssmudgy")),d.classList.remove("show")},e.appendChild(d),document.addEventListener("oo:ambientstart",()=>{d.classList.add("show")}),document.addEventListener("oo:ambientend",()=>{d.classList.remove("show")});const u=document.createElement("button");u.className="mini",u.textContent="✏️",u.title="Draw",u.onclick=()=>Jl("draw"),e.appendChild(u);const f=document.createElement("button");f.className="mini",f.textContent="T",f.title="Text",f.onclick=()=>Jl("text"),e.appendChild(f);const g=document.createElement("button");g.className="mini game-btn",g.textContent="🎮",g.title="Game",g.onclick=()=>Jl("game"),e.appendChild(g);const m=document.createElement("button");m.className="mini profile-btn",m.id="oo-profile-btn",m.textContent="⚙️",m.title="Settings & Profile",m.onclick=cS,e.appendChild(m),x.appendChild(e);let v=!1,L=0,P=0,M=18,G=18;const $=localStorage.getItem("oo_fab_position");if($)try{const V=JSON.parse($);e.style.right=V.right+"px",e.style.bottom=V.bottom+"px",M=V.right,G=V.bottom}catch{}t.addEventListener("pointerdown",V=>{if(V.shiftKey){V.preventDefault(),v=!0,L=V.clientX,P=V.clientY;const B=getComputedStyle(e);M=parseInt(B.right)||18,G=parseInt(B.bottom)||18,e.classList.add("dragging"),t.setPointerCapture(V.pointerId)}}),t.addEventListener("pointermove",V=>{if(!v)return;V.preventDefault();const B=L-V.clientX,I=P-V.clientY,b=Math.max(10,Math.min(window.innerWidth-70,M+B)),_=Math.max(10,Math.min(window.innerHeight-70,G+I));e.style.right=b+"px",e.style.bottom=_+"px"}),t.addEventListener("pointerup",V=>{if(v){v=!1,e.classList.remove("dragging"),t.releasePointerCapture(V.pointerId);const B=getComputedStyle(e);localStorage.setItem("oo_fab_position",JSON.stringify({right:parseInt(B.right)||18,bottom:parseInt(B.bottom)||18}))}});const D=document.createElement("div");D.className="profile-modal",D.id="oo-profile-modal",D.innerHTML=`
    <button class="profile-close" id="profile-close-btn">&times;</button>
    <div class="login-prompt" id="login-prompt">
      <p>Sign in to save your drawings and follow other users +many more features</p>
      <button class="login-btn" id="google-login-btn">
        <svg width="20" height="20" viewBox="0 0 24 24">
          <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
          <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
          <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
          <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
        </svg>
        Sign in with Google
      </button>
    </div>
    <div class="profile-content" id="profile-content" style="display: none;">
      <div class="profile-header">
        <img class="profile-avatar" id="profile-avatar" src="" alt="Profile">
        <div class="profile-info">
          <h3 class="profile-name" id="profile-name">User Name</h3>
          <p class="profile-email" id="profile-email">email@example.com</p>
        </div>
      </div>
      <div class="screen-name-section">
        <label class="screen-name-label">Your Game Name</label>
        <input type="text" class="screen-name-input" id="oo-screen-name" placeholder="Pick a nickname!" maxlength="12">
      </div>
      <div class="profile-stats">
        <div class="profile-stat" id="followers-stat" title="Click to view followers">
          <div class="profile-stat-value" id="followers-count">0</div>
          <div class="profile-stat-label">Followers</div>
        </div>
        <div class="profile-stat" id="following-stat" title="Click to view following">
          <div class="profile-stat-value" id="following-count">0</div>
          <div class="profile-stat-label">Following</div>
        </div>
      </div>
      <div class="followers-panel" id="followers-panel">
        <div class="followers-panel-header">Your Followers</div>
        <div id="followers-list">
          <div class="no-followers">Loading followers...</div>
        </div>
      </div>
      <div class="profile-bio" id="profile-bio">
        <div class="profile-bio-label">Bio (click to edit)</div>
        <div class="profile-bio-content" id="profile-bio-content">
          <span class="profile-bio-empty">Click to add a bio...</span>
        </div>
        <div class="profile-bio-edit" id="profile-bio-edit" style="display:none;">
          <textarea class="profile-bio-input" id="profile-bio-input" placeholder="Tell others about yourself..." maxlength="150" rows="3"></textarea>
          <div class="profile-bio-actions">
            <button class="profile-bio-save" id="profile-bio-save">Save</button>
            <button class="profile-bio-cancel" id="profile-bio-cancel">Cancel</button>
          </div>
        </div>
      </div>
      <div class="profile-settings" id="character-settings">
        <div class="profile-settings-header">Character Settings</div>
        <div class="profile-setting-row">
          <span class="profile-setting-label">Character</span>
          <div class="char-toggle-profile">
            <button class="char-btn-profile active" id="profile-char-boy" title="Boy">👦</button>
            <button class="char-btn-profile" id="profile-char-girl" title="Girl">👧</button>
          </div>
        </div>
        <div class="profile-setting-row">
          <span class="profile-setting-label">Part</span>
          <div class="body-part-toggles" id="body-part-toggles">
            <button class="part-toggle active" data-part="body" title="Body">🦴</button>
            <button class="part-toggle" data-part="head" title="Head">⚪</button>
            <button class="part-toggle" data-part="face" title="Face">🩷</button>
            <button class="part-toggle" data-part="hair" title="Hair">💇</button>
            <button class="part-toggle" data-part="dress" title="Dress">👗</button>
          </div>
        </div>
        <div class="profile-setting-row">
          <span class="profile-setting-label">Color</span>
          <div class="profile-color-picker" id="profile-color-picker">
            <div class="profile-color-swatches" id="profile-color-swatches"></div>
          </div>
        </div>
        <div class="profile-setting-row">
          <span class="profile-setting-label">Hat</span>
          <select class="profile-select" id="profile-hat-select">
            <option value="none">None</option>
            <option value="cap">🧢 Cap</option>
            <option value="tophat">🎩 Top Hat</option>
            <option value="crown">👑 Crown</option>
            <option value="beanie">🧶 Beanie</option>
            <option value="party">🎉 Party</option>
          </select>
        </div>
        <div class="profile-setting-row">
          <span class="profile-setting-label">Respawn in explore</span>
          <div class="toggle-switch active" id="toggle-respawn" title="Respawn when falling off screen"></div>
        </div>
      </div>
      <div class="profile-settings">
        <div class="profile-settings-header">Drawing Visibility</div>
        <div class="profile-setting-row">
          <span class="profile-setting-label">Show all drawings</span>
          <div class="toggle-switch active" id="toggle-all-drawings" title="Master toggle - hide all drawings"></div>
        </div>
        <div class="profile-setting-row">
          <span class="profile-setting-label">My drawings</span>
          <div class="toggle-switch active" id="toggle-my-drawings" title="Show or hide your own drawings"></div>
        </div>
        <div class="profile-setting-row">
          <span class="profile-setting-label">Only people I follow</span>
          <div class="toggle-switch" id="toggle-following-only" title="Show only drawings from users you follow"></div>
        </div>
        <div class="profile-contributors" id="contributors-section">
          <div class="profile-contributors-header">Contributors on this page</div>
          <div id="contributors-list" class="contributors-list">
            <div class="no-contributors">No other contributors yet</div>
          </div>
        </div>
      </div>
      <div class="profile-settings" id="race-course-settings" style="display: none;">
        <div class="profile-settings-header">Race Course</div>
        <div class="profile-setting-row">
          <span class="profile-setting-label">Select course</span>
          <select class="profile-select" id="race-course-select">
            <option value="mine">My Course</option>
          </select>
        </div>
      </div>
      <div class="profile-bookmarks" id="profile-bookmarks">
        <div class="profile-bookmarks-header">
          Bookmarks <span class="profile-bookmarks-count" id="bookmarks-count">0</span>
        </div>
        <div id="bookmarks-list"></div>
      </div>
      <div class="feedback-section">
        <div class="feedback-header">
          <span class="beta-badge">BETA</span>
          Send Feedback
        </div>
        <div class="feedback-form" id="feedback-form">
          <select id="feedback-type" class="feedback-select">
            <option value="bug">🐛 Bug Report</option>
            <option value="feature">💡 Feature Request</option>
            <option value="other">💬 Other Feedback</option>
          </select>
          <textarea id="feedback-text" class="feedback-textarea" placeholder="Describe the issue or suggestion..." rows="3"></textarea>
          <button class="feedback-submit" id="feedback-submit">Send Feedback</button>
        </div>
        <div class="feedback-success" id="feedback-success" style="display:none;">
          ✓ Thanks for your feedback!
        </div>
      </div>
      <div class="profile-actions">
        <button class="profile-btn danger" id="signout-btn">Sign Out</button>
      </div>
    </div>
  `,x.appendChild(D);const j=document.createElement("div");j.className="toolbar",j.id="oo-toolbar",j.innerHTML=`
    <!-- DRAG HANDLE -->
    <div class="toolbar-drag-handle" id="oo-drag-handle" title="Drag to move">⠿</div>

    <!-- DRAW MODE CONTROLS -->
    <div class="draw-controls active" id="draw-controls">
      <!-- Row 1: Brushes + Tools -->
      <div class="toolbar-row">
        <div class="brush-styles" id="oo-brushes">
          ${JI.map(V=>`
            <button class="brush-btn ${V.id==="solid"?"active":""}"
                    data-brush="${V.id}" title="${V.title}">${V.label}</button>
          `).join("")}
        </div>
        <button class="eraser-btn" id="oo-eraser" title="Eraser">🧹</button>
        <button class="tool-btn" id="oo-layer-bg" title="Background">⬇️</button>
        <button class="tool-btn" id="oo-layer-fg" title="Foreground">⬆️</button>
      </div>
      <!-- Row 2: Shapes -->
      <div class="toolbar-row">
        <div class="shape-tools" id="oo-shapes">
          ${eS.map(V=>`
            <button class="shape-btn ${V.id==="none"?"active":""}"
                    data-shape="${V.id}" title="${V.title}">${V.label}</button>
          `).join("")}
        </div>
        <button class="fill-btn" id="oo-fill-toggle" title="Toggle fill">◧</button>
      </div>
    </div>

    <!-- TEXT MODE CONTROLS -->
    <div class="text-controls" id="text-controls" style="position: relative;">
      <div class="emoji-picker" id="oo-emoji-picker">
        <div class="emoji-picker-header">Emojis & Stickers</div>
        <div class="emoji-grid" id="oo-emoji-grid"></div>
      </div>
      <div class="toolbar-row">
        <button class="emoji-btn" id="oo-emoji-btn" title="Add emoji">😀</button>
        <input type="text" class="text-input" id="oo-text-input" placeholder="Type or pick emoji...">
        <div class="text-styles" id="oo-text-styles">
          ${ZI.map(V=>`
            <button class="text-style-btn ${V.id==="normal"?"active":""}"
                    data-style="${V.id}" title="${V.title}">${V.label}</button>
          `).join("")}
        </div>
        <button class="tool-btn" id="oo-text-layer-bg" title="Background (behind character)">⬇️</button>
        <button class="tool-btn" id="oo-text-layer-fg" title="Foreground (in front of character)">⬆️</button>
      </div>
      <span class="place-hint">Click page to place (default: regular layer)</span>
    </div>

    <!-- GAME MODE CONTROLS -->
    <div class="game-controls" id="game-controls">
      <!-- Row 1: Play Mode Buttons -->
      <div class="game-row">
        <div class="game-mode-toggle">
          <button class="game-mode-btn" id="oo-multiplayer-setup" data-mode="play" data-playmode="explore" title="Multiplayer Explore">👥 MP</button>
          <button class="game-mode-btn" id="oo-tag-game" data-mode="play" data-playmode="explore" title="Tag Game">🏷️ Tag</button>
          <button class="game-mode-btn" data-mode="play" data-playmode="race" title="Race">🏃 Race</button>
        </div>
      </div>

      <!-- Row 2: Build Tools (shown by default in build mode) -->
      <div class="game-row build-tools-section">
        <div class="game-tools" id="game-tools">
          <button class="game-tool-btn" data-tool="select" title="Select">✋</button>
          <button class="game-tool-btn active" data-tool="spawn" title="Spawn">👤</button>
          <button class="game-tool-btn" data-tool="start" title="Start">🏁</button>
          <button class="game-tool-btn" data-tool="finish" title="Finish">🏆</button>
          <button class="game-tool-btn" data-tool="checkpoint" title="Checkpoint">🚩</button>
          <button class="game-tool-btn" data-tool="trampoline" title="Bounce">🔶</button>
          <button class="game-tool-btn" data-tool="speedBoost" title="Speed">💨</button>
          <button class="game-tool-btn" data-tool="highJump" title="Jump">🦘</button>
          <button class="game-tool-btn" data-tool="spike" title="Spike">🔺</button>
        </div>
      </div>

      <!-- Row 3: Actions -->
      <div class="game-row">
        <div class="game-actions">
          <button class="action-btn btn-undo" id="oo-game-undo" title="Undo">↩</button>
          <button class="action-btn btn-clear" id="oo-game-clear" title="Clear">🗑</button>
          <button class="action-btn btn-cancel" id="oo-game-cancel">✕</button>
          <button class="action-btn btn-save" id="oo-game-save">✓</button>
        </div>
      </div>
    </div>

    <!-- SHARED CONTROLS -->
    <!-- Color Row -->
    <div class="toolbar-row">
      <input type="color" id="oo-color" value="#ff3366" title="Color">
      <div class="quick-colors" id="oo-quick-colors">
        ${QI.map((V,B)=>`
          <div class="quick-color ${B===0?"active":""}"
               data-color="${V}"
               style="background: ${V}"
               title="${V}"></div>
        `).join("")}
      </div>
    </div>

    <!-- Size/Opacity Row (hidden in game mode) -->
    <div class="toolbar-row drawing-only">
      <label>Size</label>
      <input type="range" id="oo-size" min="1" max="150" value="24" style="width: 80px;">
      <span class="size-display" id="oo-size-display">24</span>
      <label style="margin-left: 8px;">Op</label>
      <input type="range" id="oo-opacity" min="10" max="100" value="100" style="width: 60px;">
      <span class="opacity-display" id="oo-opacity-display">100%</span>
    </div>

    <!-- Actions Row -->
    <div class="toolbar-row">
      <button class="action-btn btn-undo" id="oo-undo" title="Undo">↩</button>
      <button class="action-btn btn-clear" id="oo-clear" title="Clear All">🗑</button>
      <div style="flex: 1;"></div>
      <button class="action-btn btn-cancel" id="oo-cancel">Cancel</button>
      <button class="action-btn btn-save" id="oo-save">Save</button>
    </div>
  `,x.appendChild(j),oS(j),document.body.appendChild(gi),document.addEventListener("oo:hidetoolbar",()=>{const V=x==null?void 0:x.querySelector(".toolbar");V==null||V.classList.remove("show"),Ft="none",Er="play";const B=x==null?void 0:x.querySelectorAll(".mini");B==null||B.forEach(I=>I.classList.remove("active"))}),console.log("[OpenOverlay] UI initialized")}function oS(n){var Yo,Is,Ss,Ko,Qr,Xo,xs,Jr,Zr,Qo,Ge,Je,gr;n.querySelectorAll(".brush-btn").forEach(R=>{R.addEventListener("click",()=>{Xm=R.dataset.brush||"solid",n.querySelectorAll(".brush-btn").forEach(X=>X.classList.remove("active")),R.classList.add("active"),mt()})}),n.querySelectorAll(".text-style-btn").forEach(R=>{R.addEventListener("click",()=>{Qm=R.dataset.style||"normal",n.querySelectorAll(".text-style-btn").forEach(X=>X.classList.remove("active")),R.classList.add("active"),mt()})}),n.querySelectorAll(".shape-btn").forEach(R=>{R.addEventListener("click",()=>{Jm=R.dataset.shape||"none",n.querySelectorAll(".shape-btn").forEach(X=>X.classList.remove("active")),R.classList.add("active"),mt()})});const e=n.querySelector("#oo-fill-toggle");e==null||e.addEventListener("click",()=>{ki=!ki,e.classList.toggle("active",ki),e.textContent=ki?"◼":"◧",mt()});const t=n.querySelector("#oo-emoji-btn"),r=n.querySelector("#oo-emoji-picker"),o=n.querySelector("#oo-emoji-grid");o&&(o.innerHTML=tS.map(R=>`<button class="emoji-item" data-emoji="${R}">${R}</button>`).join("")),t==null||t.addEventListener("click",R=>{R.stopPropagation(),r==null||r.classList.toggle("show")}),o==null||o.addEventListener("click",R=>{const X=R.target.dataset.emoji;if(X){const oe=n.querySelector("#oo-text-input");if(oe){const gt=oe.selectionStart||oe.value.length,Ze=oe.selectionEnd||oe.value.length,Ue=oe.value.substring(0,gt),As=oe.value.substring(Ze);oe.value=Ue+X+As,oe.focus(),oe.dispatchEvent(new Event("input",{bubbles:!0}))}r==null||r.classList.remove("show")}}),document.addEventListener("click",R=>{if(r!=null&&r.classList.contains("show")){const z=R.target;!r.contains(z)&&z!==t&&r.classList.remove("show")}});const i=n.querySelector("#oo-text-input");let s=null;i==null||i.addEventListener("input",()=>{const R=i.value;ns=R,console.log("[OpenOverlay] Text input:",R,"liveTextId:",s),R.trim()&&!s?(console.log("[OpenOverlay] Creating text in center"),document.dispatchEvent(new CustomEvent("oo:textcreate",{detail:{text:R}}))):R.trim()&&s?document.dispatchEvent(new CustomEvent("oo:textupdate",{detail:{text:R}})):!R.trim()&&s&&(document.dispatchEvent(new CustomEvent("oo:textdelete",{detail:{id:s}})),s=null),mt()}),document.addEventListener("oo:textcreated",R=>{console.log("[OpenOverlay] Text created with id:",R.detail.id),s=R.detail.id,i==null||i.blur()}),document.addEventListener("oo:textsaved",()=>{console.log("[OpenOverlay] Text saved, resetting"),s=null,i&&(i.value=""),ns=""}),n.querySelectorAll(".quick-color").forEach(R=>{R.addEventListener("click",()=>{const z=R.dataset.color||"#ff3366",X=n.querySelector("#oo-color");X&&(X.value=z),n.querySelectorAll(".quick-color").forEach(oe=>oe.classList.remove("active")),R.classList.add("active"),mt(),Ft==="game"&&document.dispatchEvent(new CustomEvent("oo:playercolor",{detail:{color:z}}))})}),(Yo=n.querySelector("#oo-color"))==null||Yo.addEventListener("input",()=>{const R=n.querySelector("#oo-color");n.querySelectorAll(".quick-color").forEach(z=>z.classList.remove("active")),mt(),Ft==="game"&&R&&document.dispatchEvent(new CustomEvent("oo:playercolor",{detail:{color:R.value}}))});const c=n.querySelector("#oo-size"),d=n.querySelector("#oo-size-display");c==null||c.addEventListener("input",()=>{d&&(d.textContent=c.value),mt()});const u=n.querySelector("#oo-opacity"),f=n.querySelector("#oo-opacity-display");u==null||u.addEventListener("input",()=>{f&&(f.textContent=u.value+"%"),mt()});const g=n.querySelector("#oo-eraser");g==null||g.addEventListener("click",()=>{bo=!bo,g.classList.toggle("active",bo),mt()}),(Is=n.querySelector("#oo-layer-bg"))==null||Is.addEventListener("click",()=>{var R,z;Ke==="background"?Ke="normal":Ke="background",(R=n.querySelector("#oo-layer-bg"))==null||R.classList.toggle("active",Ke==="background"),(z=n.querySelector("#oo-layer-fg"))==null||z.classList.remove("active"),mt()}),(Ss=n.querySelector("#oo-layer-fg"))==null||Ss.addEventListener("click",()=>{var R,z;Ke==="foreground"?Ke="normal":Ke="foreground",(R=n.querySelector("#oo-layer-fg"))==null||R.classList.toggle("active",Ke==="foreground"),(z=n.querySelector("#oo-layer-bg"))==null||z.classList.remove("active"),mt()}),(Ko=n.querySelector("#oo-text-layer-bg"))==null||Ko.addEventListener("click",()=>{var R,z;Ke==="background"?Ke="normal":Ke="background",(R=n.querySelector("#oo-text-layer-bg"))==null||R.classList.toggle("active",Ke==="background"),(z=n.querySelector("#oo-text-layer-fg"))==null||z.classList.remove("active"),mt()}),(Qr=n.querySelector("#oo-text-layer-fg"))==null||Qr.addEventListener("click",()=>{var R,z;Ke==="foreground"?Ke="normal":Ke="foreground",(R=n.querySelector("#oo-text-layer-fg"))==null||R.classList.toggle("active",Ke==="foreground"),(z=n.querySelector("#oo-text-layer-bg"))==null||z.classList.remove("active"),mt()}),(Xo=n.querySelector("#oo-undo"))==null||Xo.addEventListener("click",()=>{document.dispatchEvent(new CustomEvent("oo:undo"))}),(xs=n.querySelector("#oo-clear"))==null||xs.addEventListener("click",()=>{document.dispatchEvent(new CustomEvent("oo:clear"))}),(Jr=n.querySelector("#oo-cancel"))==null||Jr.addEventListener("click",()=>{rs("none"),document.dispatchEvent(new CustomEvent("oo:cancel"))}),(Zr=n.querySelector("#oo-save"))==null||Zr.addEventListener("click",()=>{rs("none"),document.dispatchEvent(new CustomEvent("oo:save"))}),n.querySelectorAll(".game-mode-btn").forEach(R=>{const z=R.id;z==="oo-multiplayer-setup"||z==="oo-tag-game"||R.addEventListener("click",()=>{const X=R.dataset.mode,oe=R.dataset.playmode;Er=X,n.querySelectorAll(".game-mode-btn").forEach(Ze=>Ze.classList.remove("active")),R.classList.add("active");const gt=n.querySelector(".build-tools-section");gt&&(gt.style.display="none"),document.dispatchEvent(new CustomEvent("oo:gamemode",{detail:{mode:X,tool:Ff,playmode:oe||"explore"}}))})}),n.querySelectorAll(".game-tool-btn[data-tool]").forEach(R=>{R.addEventListener("click",()=>{const z=R.dataset.tool||"platform";Ff=z,n.querySelectorAll(".game-tool-btn[data-tool]").forEach(X=>X.classList.remove("active")),R.classList.add("active"),document.dispatchEvent(new CustomEvent("oo:gamemode",{detail:{mode:Er,tool:z}}))})}),(Qo=n.querySelector("#oo-game-undo"))==null||Qo.addEventListener("click",()=>{document.dispatchEvent(new CustomEvent("oo:undo"))}),(Ge=n.querySelector("#oo-game-clear"))==null||Ge.addEventListener("click",()=>{document.dispatchEvent(new CustomEvent("oo:clear"))}),(Je=n.querySelector("#oo-game-cancel"))==null||Je.addEventListener("click",()=>{document.dispatchEvent(new CustomEvent("oo:save")),n.classList.remove("show"),Ft="none"}),(gr=n.querySelector("#oo-game-save"))==null||gr.addEventListener("click",()=>{document.dispatchEvent(new CustomEvent("oo:save")),document.dispatchEvent(new CustomEvent("oo:gamemode",{detail:{mode:"play",playmode:"explore"}})),n.classList.remove("show"),Ft="none"}),document.addEventListener("click",R=>{if(Oc){Oc=!1;return}if(Ft!=="game"||!n.classList.contains("show")||Er==="build")return;const z=R.composedPath(),X=x==null?void 0:x.host;X&&z.includes(X)||(document.dispatchEvent(new CustomEvent("oo:save")),document.dispatchEvent(new CustomEvent("oo:gamemode",{detail:{mode:"play",playmode:"explore"}})),n.classList.remove("show"),Ft="none")}),document.addEventListener("click",R=>{var oe;if(!en)return;const z=R.composedPath(),X=x==null?void 0:x.host;X&&z.includes(X)||(en=!1,(oe=x==null?void 0:x.querySelector("#oo-profile-modal"))==null||oe.classList.remove("show"))});const m=n.querySelector("#oo-multiplayer-setup");m==null||m.addEventListener("click",async()=>{const R=m;R.textContent="⏳",R.disabled=!0;try{const z=await chrome.runtime.sendMessage({type:"SETUP_MULTIPLAYER"});if(z!=null&&z.success){R.textContent="✓ Ready",n.querySelectorAll(".game-mode-btn").forEach(oe=>oe.classList.remove("active")),R.classList.add("active");const X=n.querySelector(".build-tools-section");X&&(X.style.display="none"),Er="play",document.dispatchEvent(new CustomEvent("oo:gamemode",{detail:{mode:"play",playmode:"explore"}})),setTimeout(()=>{R.textContent="👥 MP",R.disabled=!1},1500)}else R.textContent="❌ Error",setTimeout(()=>{R.textContent="👥 MP",R.disabled=!1,R.classList.remove("active")},2e3)}catch(z){console.error("[OpenOverlay] Multiplayer setup error:",z),R.textContent="👥 MP",R.disabled=!1}});const v=n.querySelector("#oo-tag-game");let L=!1;v==null||v.addEventListener("click",async()=>{if(L){document.dispatchEvent(new CustomEvent("oo:toggletag"));return}v.textContent="⏳",v.disabled=!0;try{const R=await chrome.runtime.sendMessage({type:"SETUP_MULTIPLAYER"});if(R!=null&&R.success){console.log("[OpenOverlay UI] Multiplayer setup complete, starting tag game"),n.querySelectorAll(".game-mode-btn").forEach(X=>X.classList.remove("active")),v.classList.add("active");const z=n.querySelector(".build-tools-section");z&&(z.style.display="none"),Er="play",document.dispatchEvent(new CustomEvent("oo:toggletag"))}else console.error("[OpenOverlay UI] Multiplayer setup failed:",R==null?void 0:R.error),v.textContent="❌",setTimeout(()=>{v.textContent="🏷️ Tag",v.disabled=!1},1500)}catch(R){console.error("[OpenOverlay UI] Error setting up multiplayer:",R),v.textContent="❌",setTimeout(()=>{v.textContent="🏷️ Tag",v.disabled=!1},1500)}}),document.addEventListener("oo:tagstatechange",R=>{const{isTagMode:z,isIt:X}=R.detail;L=z,v.disabled=!1,z?X?(v.textContent="🏷️ IT!",v.classList.add("active")):(v.textContent="🏷️ Run!",v.classList.add("active")):(v.textContent="🏷️ Tag",v.classList.remove("active"))});const P=n.querySelector("#oo-drag-handle");let M=!1,G=0,$=0,D=0,j=0;P==null||P.addEventListener("pointerdown",R=>{const z=R;M=!0,G=z.clientX,$=z.clientY;const X=n.getBoundingClientRect();D=X.left,j=X.top,n.style.right="auto",n.style.bottom="auto",n.style.left=`${X.left}px`,n.style.top=`${X.top}px`,P.style.cursor="grabbing",z.preventDefault()}),document.addEventListener("pointermove",R=>{if(!M)return;const z=R.clientX-G,X=R.clientY-$;n.style.left=`${D+z}px`,n.style.top=`${j+X}px`}),document.addEventListener("pointerup",()=>{M&&(M=!1,P&&(P.style.cursor="grab"))});const V=x.querySelector("#google-login-btn"),B=x.querySelector("#signout-btn"),I=x.querySelector("#profile-close-btn");I==null||I.addEventListener("click",()=>{en=!1;const R=x==null?void 0:x.querySelector("#oo-profile-modal");R==null||R.classList.remove("show")}),V==null||V.addEventListener("click",async()=>{try{await PI()}catch(R){console.error("[OpenOverlay] Login failed:",R)}}),B==null||B.addEventListener("click",async()=>{try{await CI(),en=!1;const R=x==null?void 0:x.querySelector("#oo-profile-modal");R==null||R.classList.remove("show")}catch(R){console.error("[OpenOverlay] Sign out failed:",R)}});const b=x.querySelector("#oo-screen-name");if(b){const R=localStorage.getItem("oo_screen_name");R&&(b.value=R),b.addEventListener("change",()=>{const z=b.value.trim();localStorage.setItem("oo_screen_name",z),document.dispatchEvent(new CustomEvent("oo:screenname",{detail:{name:z}}))}),b.addEventListener("keydown",z=>{z.stopPropagation(),z.key==="Enter"&&b.blur()})}const _=x.querySelector("#profile-bio-content"),E=x.querySelector("#profile-bio-edit"),T=x.querySelector("#profile-bio-input"),S=x.querySelector("#profile-bio-save"),w=x.querySelector("#profile-bio-cancel");_==null||_.addEventListener("click",()=>{const R=_.dataset.bio||"";T.value=R,_.style.display="none",E.style.display="block",T.focus()}),T==null||T.addEventListener("keydown",R=>{R.stopPropagation()}),S==null||S.addEventListener("click",async()=>{const R=T.value.trim();S.disabled=!0,S.textContent="Saving...";try{await oI(R),_.innerHTML=R?tn(R):'<span class="profile-bio-empty">Click to add a bio...</span>',_.dataset.bio=R,E.style.display="none",_.style.display="block"}catch(z){console.error("[OpenOverlay] Failed to save bio:",z)}finally{S.disabled=!1,S.textContent="Save"}}),w==null||w.addEventListener("click",()=>{E.style.display="none",_.style.display="block"});const Z=x.querySelector("#feedback-text");Z==null||Z.addEventListener("keydown",R=>{R.stopPropagation()});const de=x.querySelector("#feedback-submit");de==null||de.addEventListener("click",async()=>{var ks;const R=x==null?void 0:x.querySelector("#feedback-type"),z=x==null?void 0:x.querySelector("#feedback-text"),X=x==null?void 0:x.querySelector("#feedback-form"),oe=x==null?void 0:x.querySelector("#feedback-success"),gt=R==null?void 0:R.value,Ze=(ks=z==null?void 0:z.value)==null?void 0:ks.trim();if(!Ze){z==null||z.focus();return}const Ue=de;Ue.disabled=!0,Ue.textContent="Sending...",await SI(gt,Ze)?(X.style.display="none",oe.style.display="block",setTimeout(()=>{z.value="",R.selectedIndex=0,X.style.display="block",oe.style.display="none",Ue.disabled=!1,Ue.textContent="Send Feedback"},3e3)):(Ue.disabled=!1,Ue.textContent="Send Feedback",alert("Failed to send feedback. Please try again."))}),iS(x),document.addEventListener("oo:contributors",R=>{aS(x,R.detail.contributors)});const fe=x.querySelector("#profile-char-boy"),me=x.querySelector("#profile-char-girl"),xe=x.querySelector("#profile-hat-select"),Te=x.querySelector("#toggle-respawn");fe==null||fe.addEventListener("click",()=>{fe.classList.add("active"),me==null||me.classList.remove("active"),document.dispatchEvent(new CustomEvent("oo:playerstyle",{detail:{isGirl:!1}})),localStorage.setItem("oo_player_girl","false")}),me==null||me.addEventListener("click",()=>{me.classList.add("active"),fe==null||fe.classList.remove("active"),document.dispatchEvent(new CustomEvent("oo:playerstyle",{detail:{isGirl:!0}})),localStorage.setItem("oo_player_girl","true")}),localStorage.getItem("oo_player_girl")==="true"&&(fe==null||fe.classList.remove("active"),me==null||me.classList.add("active")),xe==null||xe.addEventListener("change",()=>{const R=xe.value;document.dispatchEvent(new CustomEvent("oo:playerhat",{detail:{hat:R}})),localStorage.setItem("oo_player_hat",R)});const Ie=localStorage.getItem("oo_player_hat");Ie&&xe&&(xe.value=Ie),localStorage.getItem("oo_explore_respawn")!=="false"||Te==null||Te.classList.remove("active"),Te==null||Te.addEventListener("click",()=>{Te.classList.toggle("active");const R=Te.classList.contains("active");localStorage.setItem("oo_explore_respawn",R?"true":"false"),document.dispatchEvent(new CustomEvent("oo:respawnsetting",{detail:{respawn:R}}))});const ye=x.querySelector("#profile-color-swatches"),ve=x.querySelector("#body-part-toggles");let Ae="body";const fn=R=>{if(R==="face")return localStorage.getItem("oo_color_face")||"#ff69b4";const z=localStorage.getItem(`oo_color_${R}`);return z||localStorage.getItem("oo_player_color")||"#ffffff"},Go=R=>{const z=fn(R);ye==null||ye.querySelectorAll(".profile-color-swatch").forEach(X=>{X.classList.toggle("active",X.dataset.color===z)})};if(ye){const R=["#ff3366","#22c55e","#3b82f6","#f59e0b","#8b5cf6","#ff69b4","#fff","#000"],z=fn(Ae);ye.innerHTML=R.map(X=>`
      <div class="profile-color-swatch ${X===z?"active":""}" data-color="${X}" style="background: ${X}" title="${X}"></div>
    `).join(""),ye.querySelectorAll(".profile-color-swatch").forEach(X=>{X.addEventListener("click",()=>{const oe=X.dataset.color||"#ff3366";ye.querySelectorAll(".profile-color-swatch").forEach(gt=>gt.classList.remove("active")),X.classList.add("active"),localStorage.setItem(`oo_color_${Ae}`,oe),document.dispatchEvent(new CustomEvent("oo:partcolor",{detail:{part:Ae,color:oe}})),Ae==="body"&&(localStorage.setItem("oo_player_color",oe),document.dispatchEvent(new CustomEvent("oo:playercolor",{detail:{color:oe}})))})})}ve&&ve.querySelectorAll(".part-toggle").forEach(R=>{R.addEventListener("click",()=>{ve.querySelectorAll(".part-toggle").forEach(z=>z.classList.remove("active")),R.classList.add("active"),Ae=R.dataset.part||"body",Go(Ae)})});const Xr=x.querySelector("#race-course-settings"),It=x.querySelector("#race-course-select");document.addEventListener("oo:coursesupdate",R=>{var gt;const{myCourse:z,otherCourses:X}=R.detail,oe=[{id:"mine",name:"My Course",hasElements:((gt=z==null?void 0:z.checkpoints)==null?void 0:gt.length)>0},...X.map(Ze=>{var Ue;return{id:Ze.userId,name:Ze.displayName||"Unknown",hasElements:((Ue=Ze.checkpoints)==null?void 0:Ue.length)>0}})].filter(Ze=>Ze.hasElements);if(Xr&&(Xr.style.display=oe.length>0?"block":"none"),It&&oe.length>0){const Ze=It.value;It.innerHTML=oe.map(Ue=>`<option value="${Ue.id}">${Ue.name}</option>`).join(""),oe.some(Ue=>Ue.id===Ze)?It.value=Ze:(It.value=oe[0].id,document.dispatchEvent(new CustomEvent("oo:selectcourse",{detail:{courseId:oe[0].id}})))}}),It==null||It.addEventListener("change",()=>{document.dispatchEvent(new CustomEvent("oo:selectcourse",{detail:{courseId:It.value}}))}),Vm(R=>{Nc=R,lS(R)})}let Be={showAll:!0,showMine:!0,showFollowing:!1,hiddenUsers:new Set};function iS(n){sS();const e=n.querySelector("#toggle-all-drawings"),t=n.querySelector("#toggle-my-drawings"),r=n.querySelector("#toggle-following-only");e==null||e.classList.toggle("active",Be.showAll),t==null||t.classList.toggle("active",Be.showMine),r==null||r.classList.toggle("active",Be.showFollowing),e==null||e.addEventListener("click",()=>{Be.showAll=!Be.showAll,e.classList.toggle("active",Be.showAll),document.dispatchEvent(new CustomEvent("oo:visibility:all",{detail:{show:Be.showAll}}))}),t==null||t.addEventListener("click",()=>{Be.showMine=!Be.showMine,t.classList.toggle("active",Be.showMine),document.dispatchEvent(new CustomEvent("oo:visibility:mine",{detail:{show:Be.showMine}}))}),r==null||r.addEventListener("click",()=>{Be.showFollowing=!Be.showFollowing,r.classList.toggle("active",Be.showFollowing),document.dispatchEvent(new CustomEvent("oo:visibility:following",{detail:{show:Be.showFollowing}}))})}function sS(){try{const n=localStorage.getItem("oo_visibility_prefs");if(n){const e=JSON.parse(n);Be={showAll:e.showAll??!0,showMine:e.showMine??!0,showFollowing:e.showFollowing??!1,hiddenUsers:new Set(e.hiddenUsers??[])}}}catch{}}async function aS(n,e){const t=n.querySelector("#contributors-list");if(!t)return;const r=ge(),o=e.filter(s=>s.userId!==(r==null?void 0:r.uid));if(o.length===0){t.innerHTML='<div class="no-contributors">No other contributors yet</div>';return}const i=new Map;r&&await Promise.all(o.map(async s=>{const c=await aI(r.uid,s.userId);i.set(s.userId,c)})),t.innerHTML=o.map(s=>{var g;const c=!Be.hiddenUsers.has(s.userId),d=s.photoURL||"",u=((g=s.displayName)==null?void 0:g.charAt(0).toUpperCase())||"?",f=i.get(s.userId)||!1;return`
      <div class="contributor-row" data-user-id="${s.userId}">
        <div class="contributor-info">
          ${d?`<img src="${d}" class="contributor-avatar" alt="${s.displayName}">`:`<div class="contributor-avatar" style="display:flex;align-items:center;justify-content:center;color:#888;font-size:12px;">${u}</div>`}
          <span class="contributor-name">${tn(s.displayName)}</span>
        </div>
        <div class="contributor-actions">
          ${r?`
            <button class="follow-btn ${f?"following":"follow"}"
                    data-follow-user="${s.userId}"
                    data-user-name="${tn(s.displayName)}"
                    data-user-photo="${d}">
              ${f?"Following":"Follow"}
            </button>
          `:""}
          <div class="toggle-switch small ${c?"active":""}" data-toggle-user="${s.userId}" title="Show/hide this user's drawings"></div>
        </div>
      </div>
    `}).join(""),t.querySelectorAll("[data-toggle-user]").forEach(s=>{s.addEventListener("click",()=>{const c=s.getAttribute("data-toggle-user");if(!c)return;const d=s.classList.toggle("active");d?Be.hiddenUsers.delete(c):Be.hiddenUsers.add(c),document.dispatchEvent(new CustomEvent("oo:visibility:user",{detail:{userId:c,show:d}}))})}),t.querySelectorAll("[data-follow-user]").forEach(s=>{s.addEventListener("click",async()=>{const c=s.getAttribute("data-follow-user");if(s.getAttribute("data-user-name"),s.getAttribute("data-user-photo"),!c||!r)return;const d=s,u=d.classList.contains("following");d.disabled=!0;try{u?(await sI(c),d.classList.remove("following"),d.classList.add("follow"),d.textContent="Follow",document.dispatchEvent(new CustomEvent("oo:following:changed",{detail:{userId:c,action:"unfollow"}}))):(await iI(c),d.classList.remove("follow"),d.classList.add("following"),d.textContent="Following",document.dispatchEvent(new CustomEvent("oo:following:changed",{detail:{userId:c,action:"follow"}})))}catch(f){console.error("[OpenOverlay] Follow action failed:",f),u?(d.classList.add("following"),d.classList.remove("follow"),d.textContent="Following"):(d.classList.add("follow"),d.classList.remove("following"),d.textContent="Follow")}finally{d.disabled=!1}})})}function lS(n){var o;const e=x==null?void 0:x.querySelector("#oo-profile-btn"),t=x==null?void 0:x.querySelector("#login-prompt"),r=x==null?void 0:x.querySelector("#profile-content");if(!(!e||!t||!r))if(n){n.photoURL?e.innerHTML=`<img src="${n.photoURL}" alt="Profile">`:e.textContent=((o=n.displayName)==null?void 0:o.charAt(0).toUpperCase())||"👤",t.style.display="none",r.style.display="block";const i=x==null?void 0:x.querySelector("#profile-avatar"),s=x==null?void 0:x.querySelector("#profile-name"),c=x==null?void 0:x.querySelector("#profile-email");i&&(i.src=n.photoURL||""),s&&(s.textContent=n.displayName||"Anonymous"),c&&(c.textContent=n.email||""),yl(n.uid).then(d=>{if(d){const u=x==null?void 0:x.querySelector("#followers-count"),f=x==null?void 0:x.querySelector("#following-count");x==null||x.querySelector("#profile-bio"),u&&(u.textContent=String(d.followersCount||0)),f&&(f.textContent=String(d.followingCount||0));const g=x==null?void 0:x.querySelector("#profile-bio-content");g&&(g.innerHTML=d.bio?tn(d.bio):'<span class="profile-bio-empty">Click to add a bio...</span>',g.dataset.bio=d.bio||"")}}),uS(n.uid),dS()}else wo&&(wo(),wo=null),nr=0,Pi=!1,e.textContent="👤",t.style.display="block",r.style.display="none"}function cS(){en=!en;const n=x==null?void 0:x.querySelector("#oo-profile-modal");n==null||n.classList.toggle("show",en),en&&(fS(),nr>0&&(nr=0,rd()))}function uS(n){wo&&wo();const e=uI(n,t=>{console.log("[OpenOverlay] New follower:",t.displayName),nr++,rd();const r=x==null?void 0:x.querySelector("#followers-count");if(r){const o=parseInt(r.textContent||"0");r.textContent=String(o+1)}});e&&(wo=e)}function rd(){const n=x==null?void 0:x.querySelector("#followers-stat");if(!n)return;const e=n.querySelector(".notification-badge");if(e&&e.remove(),nr>0){const t=document.createElement("div");t.className="notification-badge",t.textContent=nr>9?"9+":String(nr),n.appendChild(t)}}function dS(){var r;const n=x==null?void 0:x.querySelector("#followers-stat"),e=x==null?void 0:x.querySelector("#followers-panel");if(!n||!e)return;const t=n.cloneNode(!0);(r=n.parentNode)==null||r.replaceChild(t,n),t.addEventListener("click",async()=>{Pi=!Pi,e.classList.toggle("show",Pi),Pi&&(nr=0,rd(),await hS())})}async function hS(){const n=x==null?void 0:x.querySelector("#followers-list");if(!(!n||!Nc)){n.innerHTML='<div class="no-followers">Loading...</div>';try{const e=await lI(Nc.uid,20);if(e.length===0){n.innerHTML='<div class="no-followers">No followers yet. Share your drawings to get followers!</div>';return}n.innerHTML=e.map(t=>`
      <div class="follower-item">
        <img class="follower-avatar" src="${t.photoURL||""}" alt="${tn(t.displayName)}" onerror="this.style.display='none'">
        <div class="follower-info">
          <div class="follower-name">${tn(t.displayName)}</div>
        </div>
      </div>
    `).join("")}catch(e){console.error("[OpenOverlay] Failed to load followers:",e),n.innerHTML='<div class="no-followers">Failed to load followers</div>'}}}function fS(){const n=x==null?void 0:x.querySelector("#bookmarks-list"),e=x==null?void 0:x.querySelector("#bookmarks-count");if(!n)return;const t=_l();if(e&&(e.textContent=String(t.length)),t.length===0){n.innerHTML='<div class="no-bookmarks">No bookmarks yet</div>';return}n.innerHTML=t.slice(0,10).map(r=>`
    <div class="bookmark-item" data-url="${tn(r.pageUrl)}">
      <div class="bookmark-quote">"${tn(Uf(r.comment,50))}"</div>
      <div class="bookmark-meta">${tn(Uf(r.pageTitle,30))} • ${tn(r.authorName)}</div>
    </div>
  `).join(""),n.querySelectorAll(".bookmark-item").forEach(r=>{r.addEventListener("click",()=>{const o=r.dataset.url;o&&window.open(o,"_blank")})})}function tn(n){const e=document.createElement("div");return e.textContent=n,e.innerHTML}function Uf(n,e){return n.length<=e?n:n.slice(0,e)+"..."}function mt(){document.dispatchEvent(new CustomEvent("oo:settings",{detail:{color:jr(),size:zr(),opacity:Wr(),brush:od(),textStyle:id(),eraser:bo,layer:Ke}}))}function Zm(){const n=Tr;Tr=!Tr;const e=x==null?void 0:x.querySelector(".fab"),t=x==null?void 0:x.querySelectorAll(".mini");e==null||e.classList.toggle("open",Tr),t==null||t.forEach(r=>r.classList.toggle("show",Tr)),n&&!Tr&&window.dispatchEvent(new CustomEvent("oo:menuClosed"))}function Jl(n){rs(Ft===n?"none":n)}function rs(n){var d,u,f,g,m;Ft=n;const e=x==null?void 0:x.querySelectorAll(".mini");e==null||e.forEach((v,L)=>{L===0&&v.classList.toggle("active",n==="draw"),L===1&&v.classList.toggle("active",n==="text"),L===2&&v.classList.toggle("active",n==="game")});const t=x==null?void 0:x.querySelector(".toolbar");t==null||t.classList.toggle("show",n!=="none"),t==null||t.classList.toggle("game-mode",n==="game");const r=x==null?void 0:x.querySelector("#draw-controls"),o=x==null?void 0:x.querySelector("#text-controls"),i=x==null?void 0:x.querySelector("#game-controls");r==null||r.classList.toggle("active",n==="draw"),o==null||o.classList.toggle("active",n==="text"),i==null||i.classList.toggle("active",n==="game");const s=x==null?void 0:x.querySelector("#oo-size"),c=x==null?void 0:x.querySelector("#oo-size-display");if(s&&c&&(n==="text"?(s.value="32",s.max="200",c.textContent="32"):n==="draw"&&(s.value="4",s.max="150",c.textContent="4")),n!=="none"&&(bo=!1,(d=x==null?void 0:x.querySelector("#oo-eraser"))==null||d.classList.remove("active"),Ke="normal",(u=x==null?void 0:x.querySelector("#oo-layer-bg"))==null||u.classList.remove("active"),(f=x==null?void 0:x.querySelector("#oo-layer-fg"))==null||f.classList.remove("active"),(g=x==null?void 0:x.querySelector("#oo-text-layer-bg"))==null||g.classList.remove("active"),(m=x==null?void 0:x.querySelector("#oo-text-layer-fg"))==null||m.classList.remove("active")),n!=="text"){ns="";const v=x==null?void 0:x.querySelector("#oo-text-input");v&&(v.value="")}if(document.dispatchEvent(new CustomEvent("oo:mode",{detail:{mode:n}})),n==="game"){Oc=!0,Er="build";const v=x==null?void 0:x.querySelectorAll(".game-mode-btn");v==null||v.forEach(P=>P.classList.remove("active"));const L=x==null?void 0:x.querySelector(".build-tools-section");L&&(L.style.display="flex"),document.dispatchEvent(new CustomEvent("oo:gamemode",{detail:{mode:"build"}}))}console.log("[OpenOverlay] Mode:",n)}function jr(){const n=x==null?void 0:x.querySelector("#oo-color");return(n==null?void 0:n.value)||"#ff3366"}function zr(){const n=x==null?void 0:x.querySelector("#oo-size");return parseInt((n==null?void 0:n.value)||"4",10)}function Wr(){const n=x==null?void 0:x.querySelector("#oo-opacity");return parseInt((n==null?void 0:n.value)||"100",10)/100}function od(){return Xm}function $a(){return bo}function ja(){return Ke}function id(){return Qm}function pS(){return Jm}function ey(){return ki}function gS(){return ns}function qf(){ns="";const n=x==null?void 0:x.querySelector("#oo-text-input");n&&(n.value="")}function Es(){return x}function mS(){Tr||Zm()}function Bf(n){rs(n)}function yS(){if(!x)return null;const n=x.querySelector(".quick-explore");if(!n)return null;const e=n.getBoundingClientRect();return{x:e.left+e.width/2,y:e.top+e.height/2}}function vS(){if(!x)return null;const n=x.querySelector("#oo-profile-btn");if(!n)return null;const e=n.getBoundingClientRect();return{x:e.left+e.width/2,y:e.top+e.height/2}}function Lc(n){if(!x)return;const e=x.querySelector("#oo-profile-btn");e&&(n?(e.style.background="#22c55e",e.style.boxShadow="0 0 20px #22c55e, 0 0 40px #22c55e",e.style.transform="scale(1.1)"):(e.style.background="",e.style.boxShadow="",e.style.transform=""))}let pe=null,q=null,Xe=null,_t=null,Pt=null,Pr=null,Mo=!1,ut="none",sd=!1,se=[],ao=[],$e={showAll:!0,showMine:!0,showFollowing:!1,hiddenUsers:new Set},Lt=null,Ks=[],To=[],pn=null,Eo="none",Tn=null,En=null,ty=!1,Zl=0,je=null,Mc={x:0,y:0},Jt="none",ma={x:0,y:0,size:0};const Xs=10,ny=30;function ad(n){if(n===document.body||n===document.documentElement)return"body";if(n.id)return`#${CSS.escape(n.id)}`;const e=[];let t=n;for(;t&&t!==document.body&&t!==document.documentElement;){let r=t.tagName.toLowerCase();if(t.className&&typeof t.className=="string"){const i=t.className.trim().split(/\s+/).slice(0,2);i.length>0&&i[0]&&(r+="."+i.map(s=>CSS.escape(s)).join("."))}const o=t.parentElement;if(o){const i=Array.from(o.children).filter(s=>s.tagName===t.tagName);if(i.length>1){const s=i.indexOf(t)+1;r+=`:nth-of-type(${s})`}}if(e.unshift(r),e.length>=4)break;t=t.parentElement}return e.join(" > ")||"body"}function ld(n,e){pe&&(pe.style.pointerEvents="none");const t=document.elementsFromPoint(n,e);pe&&(pe.style.pointerEvents=ut==="draw"||ut==="text"?"auto":"none");for(const r of t){if(r.id==="oo-canvas"||r.id==="openoverlay-ui"||r===document.body||r===document.documentElement)continue;const o=r.getBoundingClientRect();if(!(o.width<20||o.height<20))return r}return document.body}function _S(){console.log("[OpenOverlay] initCanvas starting..."),pe=document.createElement("canvas"),pe.id="oo-canvas",pe.style.cssText=`
    position: absolute;
    top: 0;
    left: 0;
    z-index: 2147483640;
    pointer-events: none;
  `,document.body.appendChild(pe),q=pe.getContext("2d"),Xe=document.createElement("canvas"),_t=Xe.getContext("2d"),Pt=document.createElement("canvas"),Pt.id="oo-background-canvas",Pt.style.cssText=`
    position: absolute;
    top: 0;
    left: 0;
    z-index: 2147483635;
    pointer-events: none;
  `,document.body.appendChild(Pt),Pr=Pt.getContext("2d"),mi(),window.addEventListener("resize",mi);const n=/yahoo|facebook|twitter|instagram|tiktok|reddit/i.test(window.location.hostname),e=n?500:150;let t=null;window.addEventListener("scroll",()=>{t&&clearTimeout(t),t=window.setTimeout(()=>{Mo||_e()},e)},{passive:!0});let r=null;new ResizeObserver(()=>{n?(r&&clearTimeout(r),r=window.setTimeout(mi,500)):mi()}).observe(document.documentElement);const i=n?2e3:500;let s=null,c=!1;new MutationObserver(()=>{c||(c=!0,s&&clearTimeout(s),s=window.setTimeout(()=>{c=!1,Mo||(mi(),_e())},i))}).observe(document.body,{childList:!0,subtree:!1}),n&&console.log("[OpenOverlay] Heavy site detected, using longer debounce"),document.addEventListener("oo:mode",u=>{ut=u.detail.mode,pe&&(pe.style.pointerEvents=ut==="draw"||ut==="text"?"auto":"none",pe.style.cursor=ut==="draw"?"crosshair":ut==="text"?"text":"default")}),document.addEventListener("oo:save",VS),document.addEventListener("oo:cancel",FS),document.addEventListener("oo:undo",MS),document.addEventListener("oo:clear",DS),document.addEventListener("oo:visibility:all",u=>{$e.showAll=u.detail.show,yi(),_e(),console.log("[OpenOverlay] Visibility - show all:",u.detail.show)}),document.addEventListener("oo:visibility:mine",u=>{$e.showMine=u.detail.show,yi(),_e(),console.log("[OpenOverlay] Visibility - show mine:",u.detail.show)}),document.addEventListener("oo:visibility:following",u=>{$e.showFollowing=u.detail.show,yi(),_e(),console.log("[OpenOverlay] Visibility - following only:",u.detail.show)}),document.addEventListener("oo:visibility:user",u=>{const{userId:f,show:g}=u.detail;g?$e.hiddenUsers.delete(f):$e.hiddenUsers.add(f),yi(),_e(),console.log("[OpenOverlay] Visibility - user",f,":",g?"shown":"hidden")}),document.addEventListener("oo:toggleothers",u=>{$e.showAll=u.detail.show,yi(),_e()}),document.addEventListener("oo:following:changed",u=>{const{userId:f,action:g}=u.detail;Lt||(Lt=new Set),g==="follow"?(Lt.add(f),console.log("[OpenOverlay] Added to following cache:",f)):(Lt.delete(f),console.log("[OpenOverlay] Removed from following cache:",f)),$e.showFollowing&&_e()}),PS(),document.addEventListener("oo:gamemode",u=>{sd=u.detail.mode==="build"||u.detail.mode==="play",(u.detail.mode==="play"||u.detail.mode==="build")&&_e()}),document.addEventListener("oo:settings",u=>{if(je&&ut==="text"){const f=se.find(g=>g.type==="text"&&g.id===je);f&&(f.size=u.detail.size,f.color=u.detail.color,f.opacity=u.detail.opacity,f.style=u.detail.textStyle,_e())}}),document.addEventListener("oo:textcreate",u=>{if(console.log("[OpenOverlay] oo:textcreate received, currentMode:",ut),ut!=="text")return;const f=window.innerWidth/2,g=window.innerHeight/2,m=ld(f,g);if(!m){console.log("[OpenOverlay] No anchor found at center");return}const v=m.getBoundingClientRect(),L=window.scrollX,P=window.scrollY,M=v.left+L,G=v.top+P,$=(f+L-M)/v.width,D=(g+P-G)/v.height,j=sy(),V={type:"text",id:j,anchorSelector:ad(m),x:$,y:D,anchorBounds:{x:M,y:G,width:v.width,height:v.height},text:u.detail.text,color:jr(),size:zr(),opacity:Wr(),style:id(),rotation:0,layer:ja()};se.push(V),je=V.id,console.log("[OpenOverlay] Text created:",j),document.dispatchEvent(new CustomEvent("oo:textcreated",{detail:{id:j}})),_e()}),document.addEventListener("oo:textupdate",u=>{if(!je)return;const f=se.find(g=>g.type==="text"&&g.id===je);f&&(f.text=u.detail.text,_e())}),document.addEventListener("oo:textdelete",u=>{const f=u.detail.id,g=se.findIndex(m=>m.id===f);g!==-1&&(se.splice(g,1),je===f&&(je=null),_e())}),pe.addEventListener("pointerdown",bS),pe.addEventListener("pointermove",ES),pe.addEventListener("pointerup",zf),pe.addEventListener("pointerleave",zf),cd(),US(),console.log("[OpenOverlay] Canvas initialized")}let $f=0,jf=0;function mi(){if(!pe||!q)return;const n=Math.max(document.body.scrollWidth||0,document.body.offsetWidth||0,document.documentElement.scrollWidth||0,document.documentElement.offsetWidth||0,window.innerWidth||0),e=Math.max(document.body.scrollHeight||0,document.body.offsetHeight||0,document.documentElement.scrollHeight||0,document.documentElement.offsetHeight||0,window.innerHeight||0);if(n===$f&&e===jf)return;$f=n,jf=e;const t=window.devicePixelRatio||1;pe.style.width=`${n}px`,pe.style.height=`${e}px`,pe.width=n*t,pe.height=e*t,q.scale(t,t),Xe&&_t&&(Xe.width=n*t,Xe.height=e*t,_t.setTransform(1,0,0,1,0,0),_t.scale(t,t)),Pt&&Pr&&(Pt.style.width=`${n}px`,Pt.style.height=`${e}px`,Pt.width=n*t,Pt.height=e*t,Pr.scale(t,t)),_e()}function bS(n){if(ut==="text"){TS(n);return}if(ut!=="draw")return;Mo=!0;const e=ld(n.clientX,n.clientY);if(e){const r=e.getBoundingClientRect();pn={element:e,selector:ad(e),bounds:r}}const t=pS();t!=="none"?(Eo=t,Tn={x:n.pageX,y:n.pageY},En={x:n.pageX,y:n.pageY},ty=ey()):To=[{x:n.pageX,y:n.pageY}]}function za(n){if(!q)return null;const e=oy(n);if(!e)return null;q.font=`bold ${n.size||32}px Impact, Arial, sans-serif`;const r=q.measureText(n.text).width,o=n.size;return{x:e.x,y:e.y,width:r,height:o,centerX:e.x+r/2,centerY:e.y+o/2}}function ry(n,e,t){const r=za(t);if(!r)return"none";const o=8,i=t.rotation||0,s=[{x:r.x+r.width+o,y:r.y+r.height+o,mode:"resize"}],c=r.centerX,d=r.y-o-ny,u=Math.cos(i),f=Math.sin(i),g=c-r.centerX,m=d-r.centerY,v=r.centerX+g*u-m*f,L=r.centerY+g*f+m*u;if(Math.abs(n-v)<Xs&&Math.abs(e-L)<Xs)return"rotate";const P=s[0].x-r.centerX,M=s[0].y-r.centerY,G=r.centerX+P*u-M*f,$=r.centerY+P*f+M*u;return Math.abs(n-G)<Xs&&Math.abs(e-$)<Xs?"resize":"none"}function wS(n){if(!pe||ut!=="text")return;if(je){const t=se.find(r=>r.type==="text"&&r.id===je);if(t){const r=ry(n.pageX,n.pageY,t);if(r==="resize"){pe.style.cursor="nwse-resize";return}else if(r==="rotate"){pe.style.cursor="crosshair";return}}}iy(n.pageX,n.pageY)?pe.style.cursor="grab":pe.style.cursor="default"}function TS(n){if(je){const r=se.find(o=>o.type==="text"&&o.id===je);if(r){const o=ry(n.pageX,n.pageY,r);if(o!=="none"){Jt=o,za(r)&&(ma={x:n.pageX,y:n.pageY,size:r.size,rotation:r.rotation||0});return}}}const e=iy(n.pageX,n.pageY);if(e){je=e.id,Jt="move";const r=oy(e);r&&(Mc={x:n.pageX-r.x,y:n.pageY-r.y}),pe&&(pe.style.cursor="grabbing"),_e();return}if(je){je=null,Jt="none",qf(),document.dispatchEvent(new CustomEvent("oo:textsaved")),_e();return}const t=gS();if(t&&t.trim()){const r=ld(n.clientX,n.clientY);if(!r)return;const o=r.getBoundingClientRect(),i=window.scrollX,s=window.scrollY,c=o.left+i,d=o.top+s,u=(n.pageX-c)/o.width,f=(n.pageY-d)/o.height,g={type:"text",id:sy(),anchorSelector:ad(r),x:u,y:f,anchorBounds:{x:c,y:d,width:o.width,height:o.height},text:t,color:jr(),size:zr(),opacity:Wr(),style:id(),rotation:0,layer:ja()};se.push(g),je=g.id,qf(),document.dispatchEvent(new CustomEvent("oo:textsaved")),_e()}}function oy(n){let e=null;try{e=document.querySelector(n.anchorSelector)}catch{}if(!e)return null;const t=e.getBoundingClientRect(),r=window.scrollX,o=window.scrollY;return{x:t.left+r+n.x*t.width,y:t.top+o+n.y*t.height}}function ES(n){if(ut==="text"&&Jt==="none"&&wS(n),je&&ut==="text"&&Jt!=="none"){const e=se.find(t=>t.type==="text"&&t.id===je);if(!e)return;if(Jt==="move"){let t=null;try{t=document.querySelector(e.anchorSelector)}catch{}if(t){const r=t.getBoundingClientRect(),o=window.scrollX,i=window.scrollY,s=n.pageX-Mc.x,c=n.pageY-Mc.y;e.x=(s-r.left-o)/r.width,e.y=(c-r.top-i)/r.height,_e()}}else if(Jt==="resize"){if(za(e)){const r=n.pageX-ma.x,o=n.pageY-ma.y,i=(r+o)/2,s=Math.max(12,Math.min(200,ma.size+i));e.size=s,_e()}}else if(Jt==="rotate"){const t=za(e);if(t){const r=Math.atan2(n.pageY-t.centerY,n.pageX-t.centerX);e.rotation=r+Math.PI/2,_e()}}return}if(!(!Mo||!q)){if(Eo!=="none"&&Tn){En={x:n.pageX,y:n.pageY},_e(),SS();return}To.push({x:n.pageX,y:n.pageY}),_e(),IS(To,jr(),zr(),Wr(),od(),$a())}}function zf(){if(Jt!=="none"){Jt="none",pe&&(pe.style.cursor="grab");return}if(Mo){if(Mo=!1,Eo!=="none"&&Tn&&En&&pn){const n=pn.element.getBoundingClientRect(),e=window.scrollX,t=window.scrollY,r=n.left+e,o=n.top+t,i=(Tn.x-r)/n.width,s=(Tn.y-o)/n.height,c=(En.x-r)/n.width,d=(En.y-o)/n.height;se.push({type:"shape",id:"shape_"+Date.now(),anchorSelector:pn.selector,x1:i,y1:s,x2:c,y2:d,anchorBounds:{x:r,y:o,width:n.width,height:n.height},shape:Eo,color:jr(),width:zr(),opacity:Wr(),filled:ty,eraser:$a(),layer:ja()}),Tn=null,En=null,Eo="none",pn=null,_e();return}if(To.length>1&&pn){const n=pn.element.getBoundingClientRect(),e=window.scrollX,t=window.scrollY,r=n.left+e,o=n.top+t,i=To.map(s=>({x:(s.x-r)/n.width,y:(s.y-o)/n.height}));se.push({type:"stroke",anchorSelector:pn.selector,points:i,anchorBounds:{x:r,y:o,width:n.width,height:n.height},color:jr(),width:zr(),opacity:Wr(),brush:od(),eraser:$a(),layer:ja()})}To=[],pn=null,_e()}}function iy(n,e){const t=window.scrollX,r=window.scrollY;for(let o=se.length-1;o>=0;o--){const i=se[o];if(i.type!=="text")continue;let s=null;try{s=document.querySelector(i.anchorSelector)}catch{}if(!s)continue;const c=s.getBoundingClientRect(),d={x:c.left+t,y:c.top+r,width:c.width,height:c.height},u=d.x+i.x*d.width,f=d.y+i.y*d.height,g=i.text.length*i.size*.6,m=i.size,v=10;if(n>=u-v&&n<=u+g+v&&e>=f-v&&e<=f+m+v)return i}return null}function sy(){return Math.random().toString(36).substr(2,9)}function IS(n,e,t,r,o,i){if(!(!q||n.length<2)){switch(q.save(),q.globalAlpha=r,i&&(q.globalCompositeOperation="destination-out",q.globalAlpha=1),o){case"spray":cy(q,n,e,t);break;case"dots":uy(q,n,e,t);break;case"square":dy(q,n,e,t);break;case"rainbow":xS(q,n,t);break;case"glow":hy(q,n,e,t);break;default:ly(q,n,e,t)}q.restore()}}function Wf(n,e){if(!q||n.points.length<2)return;const t=n.points.map(r=>({x:e.x+r.x*e.width,y:e.y+r.y*e.height}));switch(q.save(),q.globalAlpha=n.opacity,n.eraser&&(q.globalCompositeOperation="destination-out",q.globalAlpha=1),n.brush){case"spray":cy(q,t,n.color,n.width);break;case"dots":uy(q,t,n.color,n.width);break;case"square":dy(q,t,n.color,n.width);break;case"rainbow":AS(q,t,n.width);break;case"glow":hy(q,t,n.color,n.width);break;default:ly(q,t,n.color,n.width)}q.restore()}function SS(){if(!q||!Tn||!En)return;const n=jr(),e=zr(),t=Wr(),r=ey(),o=$a();q.save(),q.globalAlpha=t,q.strokeStyle=n,q.fillStyle=n,q.lineWidth=e,q.lineCap="round",q.lineJoin="round",o&&(q.globalCompositeOperation="destination-out",q.globalAlpha=1);const i=Tn.x,s=Tn.y,c=En.x,d=En.y;ay(q,Eo,i,s,c,d,r),q.restore()}function Hf(n,e){if(!q)return;const t=e.x+n.x1*e.width,r=e.y+n.y1*e.height,o=e.x+n.x2*e.width,i=e.y+n.y2*e.height;q.save(),q.globalAlpha=n.opacity,q.strokeStyle=n.color,q.fillStyle=n.color,q.lineWidth=n.width,q.lineCap="round",q.lineJoin="round",n.eraser&&(q.globalCompositeOperation="destination-out",q.globalAlpha=1),ay(q,n.shape,t,r,o,i,n.filled),q.restore()}function ay(n,e,t,r,o,i,s){const c=Math.min(t,o),d=Math.min(r,i),u=Math.abs(o-t),f=Math.abs(i-r),g=(t+o)/2,m=(r+i)/2;switch(n.beginPath(),e){case"line":n.moveTo(t,r),n.lineTo(o,i),n.stroke();break;case"rectangle":s&&n.fillRect(c,d,u,f),n.strokeRect(c,d,u,f);break;case"circle":const v=Math.sqrt(u*u+f*f)/2;n.arc(g,m,v,0,Math.PI*2),s&&n.fill(),n.stroke();break;case"triangle":n.moveTo(g,d),n.lineTo(c,d+f),n.lineTo(c+u,d+f),n.closePath(),s&&n.fill(),n.stroke();break;case"star":const L=Math.min(u,f)/2,P=L*.4,M=5;for(let G=0;G<M*2;G++){const $=G%2===0?L:P,D=Math.PI/M*G-Math.PI/2,j=g+$*Math.cos(D),V=m+$*Math.sin(D);G===0?n.moveTo(j,V):n.lineTo(j,V)}n.closePath(),s&&n.fill(),n.stroke();break}}function ly(n,e,t,r){n.beginPath(),n.strokeStyle=t,n.lineWidth=r,n.lineCap="round",n.lineJoin="round",n.moveTo(e[0].x,e[0].y);for(let o=1;o<e.length;o++)n.lineTo(e[o].x,e[o].y);n.stroke()}function cy(n,e,t,r){n.fillStyle=t;const o=Math.max(10,r*2);for(const i of e)for(let s=0;s<o;s++){const c=Math.random()*Math.PI*2,d=Math.random()*r,u=i.x+Math.cos(c)*d,f=i.y+Math.sin(c)*d;n.beginPath(),n.arc(u,f,.5,0,Math.PI*2),n.fill()}}function uy(n,e,t,r){n.fillStyle=t;const o=Math.max(r*.8,4);let i=0;for(let s=0;s<e.length;s++){if(s===0){n.beginPath(),n.arc(e[0].x,e[0].y,r/2,0,Math.PI*2),n.fill();continue}const c=e[s].x-e[s-1].x,d=e[s].y-e[s-1].y,u=Math.sqrt(c*c+d*d);i+=u,i>=o&&(n.beginPath(),n.arc(e[s].x,e[s].y,r/2,0,Math.PI*2),n.fill(),i=0)}}function dy(n,e,t,r){n.beginPath(),n.strokeStyle=t,n.lineWidth=r,n.lineCap="square",n.lineJoin="bevel",n.moveTo(e[0].x,e[0].y);for(let o=1;o<e.length;o++)n.lineTo(e[o].x,e[o].y);n.stroke()}function xS(n,e,t){n.lineWidth=t,n.lineCap="round",n.lineJoin="round";for(let r=1;r<e.length;r++){const o=`hsl(${Zl}, 100%, 50%)`;n.beginPath(),n.strokeStyle=o,n.shadowColor=o,n.shadowBlur=t*.8,n.moveTo(e[r-1].x,e[r-1].y),n.lineTo(e[r].x,e[r].y),n.stroke(),Zl=(Zl+2)%360}n.shadowBlur=0}function AS(n,e,t){n.lineWidth=t,n.lineCap="round",n.lineJoin="round";let r=0;for(let o=1;o<e.length;o++){const i=`hsl(${r}, 100%, 50%)`;n.beginPath(),n.strokeStyle=i,n.shadowColor=i,n.shadowBlur=t*.8,n.moveTo(e[o-1].x,e[o-1].y),n.lineTo(e[o].x,e[o].y),n.stroke(),r=(r+2)%360}n.shadowBlur=0}function hy(n,e,t,r){const o=r*3;let i=1/0,s=1/0,c=-1/0,d=-1/0;for(const P of e)i=Math.min(i,P.x),s=Math.min(s,P.y),c=Math.max(c,P.x),d=Math.max(d,P.y);const u=Math.ceil(c-i+o*2),f=Math.ceil(d-s+o*2),g=document.createElement("canvas");g.width=u,g.height=f;const m=g.getContext("2d");if(!m)return;const v=i-o,L=s-o;m.strokeStyle=t,m.lineWidth=r,m.lineCap="round",m.lineJoin="round",m.shadowColor=t,m.shadowBlur=r*2.5,m.beginPath(),m.moveTo(e[0].x-v,e[0].y-L);for(let P=1;P<e.length;P++)m.lineTo(e[P].x-v,e[P].y-L);m.stroke(),m.shadowBlur=r,m.stroke(),n.drawImage(g,v,L)}function kS(){const{showAll:n,showMine:e,showFollowing:t,hiddenUsers:r}=$e;if(!n)return[];const o=[];e&&o.push(...se.map(i=>({item:i,isOtherUser:!1})));for(const i of ao){const s=i._ownerId;s&&(r.has(s)||t&&!((Lt==null?void 0:Lt.has(s))??!1)||o.push({item:i,isOtherUser:!0}))}return o}function yi(){const n={showAll:$e.showAll,showMine:$e.showMine,showFollowing:$e.showFollowing,hiddenUsers:Array.from($e.hiddenUsers)};localStorage.setItem("oo_visibility_prefs",JSON.stringify(n))}function PS(){try{const n=localStorage.getItem("oo_visibility_prefs");if(n){const e=JSON.parse(n);$e={showAll:e.showAll!==!1,showMine:e.showMine!==!1,showFollowing:e.showFollowing===!0,hiddenUsers:new Set(Array.isArray(e.hiddenUsers)?e.hiddenUsers:[])},console.log("[OpenOverlay] Loaded visibility prefs:",{showAll:$e.showAll,showMine:$e.showMine,showFollowing:$e.showFollowing,hiddenUsers:$e.hiddenUsers.size}),(!$e.showAll||!$e.showMine)&&(console.warn("[OpenOverlay] Visibility prefs seem corrupted, resetting to defaults"),$e={showAll:!0,showMine:!0,showFollowing:!1,hiddenUsers:new Set},localStorage.removeItem("oo_visibility_prefs"))}}catch(n){console.warn("[OpenOverlay] Failed to load visibility prefs, using defaults:",n),localStorage.removeItem("oo_visibility_prefs")}}async function CS(){const n=ge();if(!n){Lt=new Set;return}try{const e=await cI(n.uid);Lt=new Set(e.map(t=>t.uid)),console.log("[OpenOverlay] Loaded following cache:",Lt.size,"users")}catch(e){console.warn("[OpenOverlay] Failed to load following cache:",e),Lt=new Set}}function _e(){if(!q||!pe)return;q.clearRect(0,0,pe.width,pe.height),Xe&&_t&&_t.clearRect(0,0,Xe.width,Xe.height),Pt&&Pr&&Pr.clearRect(0,0,Pt.width,Pt.height);const n=window.scrollX,e=window.scrollY,t=(d,u,f=!1)=>{let g=null;try{g=document.querySelector(u.anchorSelector)}catch{}if(!g)return;const m=g.getBoundingClientRect();if(m.width===0||m.height===0)return;const v={x:m.left+n,y:m.top+e,width:m.width,height:m.height},L=q;q=d,u.type==="text"?(Gf(u,v),!f&&u.id===je&&(console.log("[OpenOverlay] Drawing selection for text:",u.id),RS(u,v))):u.type==="shape"?Hf(u,v):Wf(u,v),q=L},r=d=>{if(!_t)return;let u=null;try{u=document.querySelector(d.anchorSelector)}catch{return}if(!u)return;const f=u.getBoundingClientRect();if(f.width===0||f.height===0)return;const g={x:f.left+n,y:f.top+e,width:f.width,height:f.height},m=q;q=_t,d.type==="text"?Gf(d,g):d.type==="shape"?Hf(d,g):(d.type==="stroke"||!d.type)&&Wf(d,g),q=m},o=kS(),i=o.filter(({item:d})=>d.layer==="background"),s=o.filter(({item:d})=>{const u=d.layer;return!u||u==="normal"}),c=o.filter(({item:d})=>d.layer==="foreground");if(Pr)for(const{item:d,isOtherUser:u}of i)t(Pr,d,u);for(const{item:d,isOtherUser:u}of s)t(q,d,u),r(d);for(const{item:d,isOtherUser:u}of c)t(q,d,u)}function RS(n,e){if(!q)return;console.log("[OpenOverlay] Drawing text selection for:",n.id,"selectedTextId:",je);const t=e.x+n.x*e.width,r=e.y+n.y*e.height;q.font=`bold ${n.size||32}px Impact, Arial, sans-serif`;const i=q.measureText(n.text).width,s=n.size,c=8,d=t+i/2,u=r+s/2,f=n.rotation||0;q.save(),q.translate(d,u),q.rotate(f),q.translate(-d,-u),q.strokeStyle="#22c55e",q.lineWidth=2,q.setLineDash([5,3]),q.strokeRect(t-c,r-c,i+c*2,s+c*2),q.setLineDash([]),q.fillStyle="#22c55e";const g=8;q.fillRect(t+i+c-g/2,r+s+c-g/2,g,g);const m=r-c-ny;q.beginPath(),q.arc(d,m,6,0,Math.PI*2),q.fill(),q.beginPath(),q.strokeStyle="#22c55e",q.setLineDash([]),q.lineWidth=2,q.moveTo(d,r-c),q.lineTo(d,m+6),q.stroke(),q.restore()}function Gf(n,e){if(!q)return;const t=e.x+n.x*e.width,r=e.y+n.y*e.height;q.save(),q.globalAlpha=n.opacity||1,q.font=`bold ${n.size||32}px Impact, Arial, sans-serif`,q.textBaseline="top";const o=n.rotation||0;if(o!==0){const i=q.measureText(n.text),s=t+i.width/2,c=r+n.size/2;q.translate(s,c),q.rotate(o),q.translate(-s,-c)}switch(n.style){case"rainbow":NS(q,n.text,t,r,n.size);break;case"aged":LS(q,n.text,t,r,n.size,n.color);break;default:OS(q,n.text,t,r,n.color)}q.restore()}function OS(n,e,t,r,o){n.strokeStyle="#000",n.lineWidth=3,n.strokeText(e,t,r),n.fillStyle=o,n.fillText(e,t,r)}function NS(n,e,t,r,o){const i=n.measureText(e).width,s=n.createLinearGradient(t,r,t+i,r);s.addColorStop(0,"hsl(0, 100%, 50%)"),s.addColorStop(.17,"hsl(60, 100%, 50%)"),s.addColorStop(.33,"hsl(120, 100%, 50%)"),s.addColorStop(.5,"hsl(180, 100%, 50%)"),s.addColorStop(.67,"hsl(240, 100%, 50%)"),s.addColorStop(.83,"hsl(300, 100%, 50%)"),s.addColorStop(1,"hsl(360, 100%, 50%)");let c=0;for(let d=0;d<e.length;d++){const u=e[d],f=n.measureText(u).width,m=(c+f/2)/i*360;n.shadowColor=`hsl(${m}, 100%, 50%)`,n.shadowBlur=o*.2,n.shadowOffsetX=0,n.shadowOffsetY=0,n.fillStyle=s,n.fillText(u,t+c,r),c+=f}n.shadowBlur=0,n.strokeStyle="#000",n.lineWidth=3,n.strokeText(e,t,r),n.fillStyle=s,n.fillText(e,t,r)}function LS(n,e,t,r,o,i){n.shadowColor="rgba(0,0,0,0.5)",n.shadowBlur=4,n.shadowOffsetX=2,n.shadowOffsetY=2,n.strokeStyle="#222",n.lineWidth=4,n.strokeText(e,t,r),n.shadowBlur=0,n.shadowOffsetX=0,n.shadowOffsetY=0;const s=n.createLinearGradient(t,r,t,r+o);s.addColorStop(0,Yf(i,20)),s.addColorStop(.5,i),s.addColorStop(1,Yf(i,-30)),n.fillStyle=s,n.fillText(e,t,r),n.globalAlpha=.3,n.strokeStyle="#000",n.lineWidth=1;const c=n.measureText(e).width;for(let d=0;d<5;d++){const u=t+Math.random()*c,f=r+Math.random()*o;n.beginPath(),n.moveTo(u,f),n.lineTo(u+Math.random()*10-5,f+Math.random()*10),n.stroke()}}function Yf(n,e){const t=n.replace("#",""),r=Math.max(0,Math.min(255,parseInt(t.substr(0,2),16)+e)),o=Math.max(0,Math.min(255,parseInt(t.substr(2,2),16)+e)),i=Math.max(0,Math.min(255,parseInt(t.substr(4,2),16)+e));return`rgb(${r},${o},${i})`}function MS(){sd||se.length>0&&(se.pop(),_e(),console.log("[OpenOverlay] Undo - items remaining:",se.length))}async function DS(){if(sd)return;ut==="text"?(se=se.filter(e=>e.type!=="text"),console.log("[OpenOverlay] Cleared text stamps (drawings preserved)")):(se=se.filter(e=>e.type==="text"),console.log("[OpenOverlay] Cleared drawings (text stamps preserved)"));const n=ud();se.length>0?(localStorage.setItem(`oo_drawing_${n}`,JSON.stringify(se)),Ua()&&await Nm(n,window.location.href,se)):(localStorage.removeItem(`oo_drawing_${n}`),Ua()&&await hI(n)),_e()}async function VS(){console.log("[OpenOverlay] Saving",se.length,"items"),je=null,document.dispatchEvent(new CustomEvent("oo:textsaved"));const n=ud(),e=JSON.stringify(se);localStorage.setItem(`oo_drawing_${n}`,e),Ua()&&await Nm(n,window.location.href,se),_e(),console.log("[OpenOverlay] Drawing saved")}function FS(){console.log("[OpenOverlay] Canceling drawing"),cd()}async function cd(){const n=ud();if(Kr()){if(fI(n,o=>{se=o.myItems,ao=o.otherItems,Ks=o.contributors,localStorage.setItem(`oo_drawing_${n}`,JSON.stringify(se)),console.log("[OpenOverlay] Real-time update:",se.length,"mine,",ao.length,"from others"),o.contributors.length>0&&console.log("[OpenOverlay] Contributors:",o.contributors.map(i=>i.displayName).join(", ")),document.dispatchEvent(new CustomEvent("oo:contributors",{detail:{contributors:Ks}})),_e()})){console.log("[OpenOverlay] Subscribed to real-time drawing updates");return}console.log("[OpenOverlay] Real-time subscription failed, trying one-time fetch");const r=await dI(n);if(r!==null){se=r.myItems,ao=r.otherItems,Ks=r.contributors,localStorage.setItem(`oo_drawing_${n}`,JSON.stringify(se)),console.log("[OpenOverlay] Loaded from cloud:",se.length,"mine,",ao.length,"from others"),document.dispatchEvent(new CustomEvent("oo:contributors",{detail:{contributors:Ks}})),_e();return}}ao=[];const e=localStorage.getItem(`oo_drawing_${n}`);if(e)try{se=JSON.parse(e),console.log("[OpenOverlay] Loaded",se.length,"items from localStorage"),_e()}catch{console.warn("[OpenOverlay] Failed to load drawings"),se=[]}else se=[]}function ud(){return btoa(window.location.href).slice(0,32)}function US(){Vm(n=>{n?(console.log("[OpenOverlay] User logged in, reloading drawings from cloud"),CS()):(console.log("[OpenOverlay] User logged out, reloading public drawings"),Lt=null),cd()})}function vi(n,e,t,r,o){if(!Xe||!_t)return{floor:!1,floorY:0,ceiling:!1,ceilingY:0,leftWall:!1,leftWallX:0,rightWall:!1,rightWallX:0,slopeAngle:0,slopeAheadY:0};const i=window.devicePixelRatio||1;let s=!1,c=0,d=!1,u=0,f=!1,g=0,m=!1,v=0,L=0,P=0;const M=Math.max(1,Math.floor(t*.5*i)),G=Math.floor((n+t/2)*i),$=Math.max(0,G-Math.floor(M/2));try{const D=e+r,j=Math.floor((D-5)*i),V=Math.floor(20*i);if($>=0&&j>=0&&$+M<=Xe.width&&j+V<=Xe.height){const Ie=_t.getImageData($,j,M,V);for(let ae=0;ae<V;ae++){let ye=!1;for(let ve=0;ve<M;ve++){const Ae=(ae*M+ve)*4;if(Ie.data[Ae+3]>30){ye=!0;break}}if(ye){const ve=j/i+ae/i;ve>=D-8&&(s=!0,c=ve);break}}}const B=e,I=Math.max(0,Math.floor((B-15)*i)),b=Math.floor(15*i);if($>=0&&I>=0&&$+M<=Xe.width&&I+b<=Xe.height){const Ie=_t.getImageData($,I,M,b);for(let ae=b-1;ae>=0;ae--){let ye=!1;for(let ve=0;ve<M;ve++){const Ae=(ae*M+ve)*4;if(Ie.data[Ae+3]>30){ye=!0;break}}if(ye){const ve=I/i+(ae+1)/i;ve<=B+5&&(d=!0,u=ve);break}}}const _=Math.floor(e*i),E=Math.floor(r*.85*i),T=Math.floor(10*i),S=Math.max(0,Math.floor(n*i)-T);if(S>=0&&_>=0&&S+T<=Xe.width&&_+E<=Xe.height){const Ie=_t.getImageData(S,_,T,E);e:for(let ae=T-1;ae>=0;ae--)for(let ye=0;ye<E;ye++){const ve=(ye*T+ae)*4;if(Ie.data[ve+3]>30){f=!0,g=(S+ae+1)/i;break e}}}const w=Math.floor((n+t)*i);if(w>=0&&_>=0&&w+T<=Xe.width&&_+E<=Xe.height){const Ie=_t.getImageData(w,_,T,E);e:for(let ae=0;ae<T;ae++)for(let ye=0;ye<E;ye++){const ve=(ye*T+ae)*4;if(Ie.data[ve+3]>30){m=!0,v=(w+ae)/i;break e}}}const Z=e+r,de=20,fe=o!==!1?n+t+de:n-de,me=Math.floor(fe*i),xe=Math.floor((Z-30)*i),Te=Math.floor(50*i);if(me>=0&&me<Xe.width&&xe>=0&&xe+Te<=Xe.height){const Ie=_t.getImageData(me,xe,1,Te);for(let ae=0;ae<Te;ae++)if(Ie.data[ae*4+3]>30){P=xe/i+ae/i;const Ae=(s?c:Z)-P;L=Math.atan2(Ae,de)*(180/Math.PI);break}}}catch{}return{floor:s,floorY:c,ceiling:d,ceilingY:u,leftWall:f,leftWallX:g,rightWall:m,rightWallX:v,slopeAngle:L,slopeAheadY:P}}function qS(n,e,t){if(n.length<2)return;const o=document.body.getBoundingClientRect(),i=window.scrollX,s=window.scrollY,c=n.map(d=>({x:(d.x-i)/o.width,y:(d.y-s)/o.height}));se.push({type:"stroke",anchorSelector:"body",points:c,anchorBounds:{x:i,y:s,width:o.width,height:o.height},color:e,width:t,opacity:1,brush:"solid",eraser:!1,layer:"normal"}),_e()}let Re=null,l=null,Ct=null,J=null,Fe="none",os="spawn",A={x:100,y:100,vx:0,vy:0,width:23,height:41,onGround:!1,facingRight:!0,animFrame:0,jumpsRemaining:2,maxJumps:2},Qs=!1,_i=0,Js=0,$n=!1,ya=0,Kf=0;const BS=12e4,$S=2e3;let jS=!1,Dc=localStorage.getItem("oo_player_color")||"#ffffff",Vc=localStorage.getItem("oo_color_head")||localStorage.getItem("oo_player_color")||"#ffffff",Mt=localStorage.getItem("oo_color_body")||localStorage.getItem("oo_player_color")||"#ffffff",Fc=localStorage.getItem("oo_color_face")||"#ff69b4",Ci=localStorage.getItem("oo_color_hair")||localStorage.getItem("oo_player_color")||"#ffffff",fy=localStorage.getItem("oo_color_dress")||localStorage.getItem("oo_player_color")||"#ffffff",is=localStorage.getItem("oo_player_hat")||"none",ss=localStorage.getItem("oo_player_accessory")||"none",py=localStorage.getItem("oo_explore_respawn")!=="false",Uc=localStorage.getItem("oo_screen_name")||"";function zS(n,e){const t=n.replace(/^#?([a-f\d])([a-f\d])([a-f\d])$/i,(c,d,u,f)=>d+d+u+u+f+f),r=/^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(t);if(!r)return n;const o=Math.max(0,Math.round(parseInt(r[1],16)*(1-e))),i=Math.max(0,Math.round(parseInt(r[2],16)*(1-e))),s=Math.max(0,Math.round(parseInt(r[3],16)*(1-e)));return`#${o.toString(16).padStart(2,"0")}${i.toString(16).padStart(2,"0")}${s.toString(16).padStart(2,"0")}`}let Fi=localStorage.getItem("oo_player_girl")==="true",as=localStorage.getItem("oo_player_face")||"smudgy",mn=0;const WS=.02;let Ui=0;const Xf=15;let Qf=0,Zs=35,bi=!1,ec=0;const HS=60,Jf=400,GS=600,Zf=40,YS=80;let qi=[],qt=new Map,Gn=new Map,tc=0,ep=0,tp=0;const KS=80;let He=!1,pt=null,Sn=0,Oe=!1,yn=null,Kn=null,Lr=0;const Wa=3e3,gy=5e3,my=3e3;let qc=0;const XS=4e3;let yy=0;function Bc(){yy=performance.now()+XS}const QS=5e3;function ls(){const n=ge();return n?pt!=null&&pt.gameActive?pt.itPlayerId===n.uid:Oe:!1}let be={id:xy(),name:"New Course",checkpoints:[],authorId:"local-user",authorName:"You",createdAt:Date.now()},Do=[],Bi=null;function vy(){if(Bi&&Bi!=="mine"){const n=Do.find(e=>e.userId===Bi);if(n)return n}return be}function np(){document.dispatchEvent(new CustomEvent("oo:coursesupdate",{detail:{myCourse:be,otherCourses:Do.map(n=>({userId:n.userId,displayName:n.displayName,checkpoints:n.checkpoints}))}}))}const JS=.6,rp=-12,op=4,ZS=.7,ip=14,nc=6,Vt={};function ex(){for(const n in Vt)Vt[n]=!1}let co=null,$c=0,wt=!1,jc=0,Ho=0,Ir=0,rr=3,dd=3,nn=!1,zc=0;const sp=1500,tx=2e3;let hd=0,Ha=!1,Tt="explore",xn=!1,fd=0;const _y=2e3;let Me=null,gn=null,yt=null,Io=!1,Zt=0,$i=localStorage.getItem("oo_player_name")||"";function nx(){console.log("[OpenOverlay] initGame starting..."),Re=document.createElement("canvas"),Re.id="oo-game-canvas",Re.style.cssText=`
    position: absolute;
    top: 0;
    left: 0;
    z-index: 2147483638;
    pointer-events: none;
  `,document.body.appendChild(Re),l=Re.getContext("2d"),Ct=document.createElement("canvas"),Ct.id="oo-overlay-canvas",Ct.style.cssText=`
    position: absolute;
    top: 0;
    left: 0;
    z-index: 2147483646;
    pointer-events: none;
  `,document.body.appendChild(Ct),J=Ct.getContext("2d"),rc(),window.addEventListener("resize",rc),new ResizeObserver(rc).observe(document.body),document.addEventListener("keydown",Ix),document.addEventListener("keyup",Sx),document.addEventListener("oo:gamemode",t=>{ap(t.detail.mode,t.detail.tool,t.detail.playmode,t.detail.spawnPos,t.detail.fromOnboarding)}),document.addEventListener("oo:undo",()=>{Fe==="build"&&be.checkpoints.length>0&&(be.checkpoints.pop(),Vo(),tt())}),document.addEventListener("oo:clear",()=>{Fe==="build"&&(be.checkpoints=[],Vo(),tt())}),document.addEventListener("oo:selectcourse",t=>{Bi=t.detail.courseId==="mine"?null:t.detail.courseId,console.log("[OpenOverlay] Selected race course:",Bi||"mine"),tt()}),document.addEventListener("oo:playercolor",t=>{Dc=t.detail.color,localStorage.setItem("oo_player_color",Dc),tt()}),document.addEventListener("oo:partcolor",t=>{const{part:r,color:o}=t.detail;switch(r){case"head":Vc=o,localStorage.setItem("oo_color_head",o);break;case"body":Mt=o,localStorage.setItem("oo_color_body",o);break;case"face":Fc=o,localStorage.setItem("oo_color_face",o);break;case"hair":Ci=o,localStorage.setItem("oo_color_hair",o);break;case"dress":fy=o,localStorage.setItem("oo_color_dress",o);break}tt()}),document.addEventListener("oo:playerstyle",t=>{Fi=t.detail.isGirl,tt()}),document.addEventListener("oo:playerhat",t=>{is=t.detail.hat,localStorage.setItem("oo_player_hat",is),tt()}),document.addEventListener("oo:playeraccessory",t=>{ss=t.detail.accessory,localStorage.setItem("oo_player_accessory",ss),tt()}),document.addEventListener("oo:playerface",t=>{as=t.detail.face,localStorage.setItem("oo_player_face",as),tt()}),document.addEventListener("oo:screenname",t=>{Uc=t.detail.name,localStorage.setItem("oo_screen_name",Uc),cs()}),document.addEventListener("oo:respawnsetting",t=>{py=t.detail.respawn}),document.addEventListener("oo:toggletag",()=>{console.log("[OpenOverlay] Tag toggle requested, gameMode:",Fe),Fe!=="play"&&(console.log("[OpenOverlay] Auto-switching to play mode for tag"),ap("play","explore")),Nx()}),Re.addEventListener("pointerdown",Ax),Re.addEventListener("pointermove",kx),Re.addEventListener("pointerup",Px),Re.addEventListener("contextmenu",t=>{Fe==="build"&&t.preventDefault()}),Cx(),tt();const e=()=>{Fe==="play"&&(Dm(),Mm(On()))};window.addEventListener("beforeunload",e),window.addEventListener("pagehide",e),document.addEventListener("visibilitychange",()=>{document.hidden&&Fe==="play"&&cs()}),document.addEventListener("oo:save",()=>{performance.now()}),document.addEventListener("mousemove",t=>{t.pageX,t.pageY}),document.addEventListener("oo:dismisssmudgy",()=>{}),performance.now(),console.log("[OpenOverlay] Game initialized")}function rc(){if(!Re||!l)return;const n=Math.max(document.body.scrollWidth,document.body.offsetWidth,document.documentElement.scrollWidth,document.documentElement.offsetWidth),e=Math.max(document.body.scrollHeight,document.body.offsetHeight,document.documentElement.scrollHeight,document.documentElement.offsetHeight),t=window.devicePixelRatio||1;Re.style.width=`${n}px`,Re.style.height=`${e}px`,Re.width=n*t,Re.height=e*t,l.scale(t,t),Ct&&J&&(Ct.style.width=`${n}px`,Ct.style.height=`${e}px`,Ct.width=n*t,Ct.height=e*t,J.scale(t,t)),tt()}let Ri=null,Wc=!1;function ap(n,e,t,r,o){if(Fe=n,e&&(os=e),t&&(Tt=t),r&&(Ri=r),Wc=o||!1,n==="play"&&Bc(),Re&&(Re.style.pointerEvents=n==="build"?"auto":"none",Re.style.cursor=n==="build"?"crosshair":"default"),n==="play"){wt=!1,Ho=0,Ir=0,be.checkpoints.forEach(s=>s.reached=!1),rr=dd,nn=!1,xn=!1,Me=null,Io=!1;const i=On();console.log("[OpenOverlay] Subscribing to players on page:",i),bI(i,s=>{if(qt=s,s.size>0&&(console.log("[OpenOverlay] Received",s.size,"other players"),s.forEach((c,d)=>{console.log("[OpenOverlay] Player",d,"at",c.x,c.y)}),He)){const c=ge(),d=Date.now();let u=null;for(const[m,v]of s)v.taggedPlayerId===(c==null?void 0:c.uid)&&v.taggedAt&&d-v.taggedAt<gy&&!Oe&&d>Sn&&(console.log("[OpenOverlay] EXPLICITLY TAGGED by:",m,"via taggedPlayerId"),Oe=!0,yn=m,Sn=d+Wa,zt("You're IT!","Tag someone!",2e3),Hc(),document.dispatchEvent(new CustomEvent("oo:tagstatechange",{detail:{isTagMode:!0,isIt:!0,gameActive:!0}})));for(const[m,v]of s){if(console.log("[OpenOverlay] Checking player",m,"isIt:",v.isIt),v.isIt){u=m,console.log("[OpenOverlay] Found IT player in sync:",v.displayName,"id:",m);break}m===yn&&!v.isIt&&(console.log("[OpenOverlay] Clearing lastTaggedByPlayerId - sync caught up"),yn=null)}const f=d<Sn,g=u===yn;u&&Oe&&c&&!f&&!g?u<c.uid?(console.log("[OpenOverlay] Tiebreaker: other player wins (lower ID), giving up IT"),Oe=!1,yn=null,document.dispatchEvent(new CustomEvent("oo:tagstatechange",{detail:{isTagMode:!0,isIt:!1,gameActive:!0}}))):console.log("[OpenOverlay] Tiebreaker: we win (lower ID), keeping IT"):u&&Oe&&f?console.log("[OpenOverlay] Skipping tiebreaker - in tag cooldown"):u&&Oe&&g?console.log("[OpenOverlay] Skipping tiebreaker - was tagged by this player (stale sync)"):u&&!Oe&&console.log("[OpenOverlay] Other player is IT, we are not")}}),wI(i,s=>{const c=pt;pt=s,console.log("[OpenOverlay] Tag game state changed:",s);const d=ge(),u=(s==null?void 0:s.itPlayerId)===(d==null?void 0:d.uid);document.dispatchEvent(new CustomEvent("oo:tagstatechange",{detail:{isTagMode:He,isIt:u,gameActive:(s==null?void 0:s.gameActive)??!1}})),s!=null&&s.gameActive&&(console.log('[OpenOverlay] Tag game active, "it" is:',s.itPlayerId),(c==null?void 0:c.itPlayerId)!==s.itPlayerId&&(u?zt("You're IT!","Tag someone!",2e3):(c==null?void 0:c.itPlayerId)===(d==null?void 0:d.uid)&&zt("You're not IT!","Run away!",2e3)))}),Ty(),Tt==="race"&&document.dispatchEvent(new CustomEvent("oo:hidetoolbar")),rx()}else n==="build"?(Io=!1,xn=!1,Me=null,He=!1,Oe=!1,yn=null,Kn=null,Lr=0,pt=null):(Io=!1,xn=!1,Me=null,Dm(),TI(),Mm(On()),qt.clear(),Gn.clear(),He=!1,Oe=!1,yn=null,Kn=null,Lr=0,pt=null);tt()}function rx(){co&&(cancelAnimationFrame(co),co=null),$c=performance.now(),co=requestAnimationFrame(by)}function by(n){const e=Math.min((n-$c)/16.67,3);$c=n,ax(e),tt(),Fe==="play"||Fe==="build"||jS?co=requestAnimationFrame(by):co=null}function wy(){if(Ri){A.x=Ri.x-A.width/2,A.y=Ri.y-A.height,Ri=null,A.vx=0,A.vy=0,A.onGround=!0,A.jumpsRemaining=A.maxJumps;return}const n=Tt==="race"?vy():be,e=n.checkpoints.find(o=>o.type==="spawn"),t=n.checkpoints.find(o=>o.type==="start"),r=e||t;r?(A.x=r.x-A.width/2,A.y=r.y-A.height-10):(A.x=window.scrollX+window.innerWidth/2-A.width/2,A.y=window.scrollY+100),A.vx=0,A.vy=0,A.onGround=!1,A.jumpsRemaining=A.maxJumps}function Ty(){if(ex(),wy(),Tt==="explore"){xn=!1,wt=!1,zt("Explore!","No timer, unlimited respawns",2e3),setTimeout(()=>{},150);return}xn=!0,fd=performance.now(),zt("Get Ready!","2")}function zt(n,e,t=1e3){Me={text:n,subtext:e,endTime:performance.now()+t}}function ox(n,e=1e3){const t=performance.now();gn={text:n,startTime:t,endTime:t+e}}function Hc(){qc=performance.now()+my}function Ey(n){yt&&ea();const{top10:e}=Ox();yt=document.createElement("div"),yt.id="oo-game-popup",yt.style.cssText=`
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background: rgba(0,0,0,0.7);
    z-index: 2147483647;
    display: flex;
    align-items: center;
    justify-content: center;
    font-family: system-ui, -apple-system, sans-serif;
  `;const t=n==="finish",r=t?"🏆 RACE COMPLETE!":"💀 GAME OVER",o=t?"#22c55e":"#ef4444",i=(Ho/1e3).toFixed(2),s=t&&Zt===be.bestTime;let c="";e.length>0&&(c=`
      <div style="margin-top: 15px; max-height: 200px; overflow-y: auto;">
        <div style="color: #fbbf24; font-weight: bold; margin-bottom: 8px;">🏆 Today's Best</div>
        ${e.slice(0,5).map((m,v)=>`
          <div style="display: flex; justify-content: space-between; color: ${v<3?["#fbbf24","#c0c0c0","#cd7f32"][v]:"#888"}; font-size: 13px; padding: 2px 0;">
            <span>${v+1}. ${m.name.slice(0,10)}</span>
            <span>${(m.time/1e3).toFixed(2)}s</span>
          </div>
        `).join("")}
      </div>
    `);const d=document.createElement("div");d.style.cssText=`
    background: #111;
    border: 3px solid ${o};
    border-radius: 12px;
    padding: 25px 35px;
    text-align: center;
    min-width: 300px;
    max-width: 400px;
    box-shadow: 0 10px 40px rgba(0,0,0,0.8);
  `,d.innerHTML=`
    <div style="color: ${o}; font-size: 24px; font-weight: bold; margin-bottom: 15px;">${r}</div>
    <div style="color: #fff; font-size: 40px; font-weight: bold; font-family: monospace;">${i}s</div>
    ${s?'<div style="color: #fbbf24; font-size: 14px; margin-top: 5px;">⭐ NEW PERSONAL BEST!</div>':""}
    ${t?`
      <div style="margin-top: 15px;">
        <input type="text" id="oo-popup-name" placeholder="Enter name..." value="${$i}"
          style="padding: 8px 12px; border-radius: 6px; border: 2px solid #333; background: #222; color: #fff; font-size: 14px; width: 180px; text-align: center;">
      </div>
    `:""}
    ${c}
    <div style="display: flex; gap: 10px; justify-content: center; margin-top: 20px;">
      <button id="oo-popup-retry" style="padding: 10px 25px; background: ${o}; color: white; border: none; border-radius: 8px; font-size: 14px; font-weight: bold; cursor: pointer;">
        🔄 Retry
      </button>
      <button id="oo-popup-close" style="padding: 10px 25px; background: #333; color: white; border: none; border-radius: 8px; font-size: 14px; font-weight: bold; cursor: pointer;">
        ✕ Close
      </button>
    </div>
  `,yt.appendChild(d),document.body.appendChild(yt);const u=yt.querySelector("#oo-popup-retry"),f=yt.querySelector("#oo-popup-close"),g=yt.querySelector("#oo-popup-name");u==null||u.addEventListener("click",()=>{t&&g&&g.value.trim()&&ta(g.value.trim(),Zt),ea(),ix()}),f==null||f.addEventListener("click",()=>{t&&g&&g.value.trim()&&ta(g.value.trim(),Zt),ea(),lp()}),yt.addEventListener("click",m=>{m.target===yt&&(t&&g&&g.value.trim()&&ta(g.value.trim(),Zt),ea(),lp())}),g==null||g.focus(),g==null||g.addEventListener("keydown",m=>{m.stopPropagation(),m.key==="Enter"&&g.value.trim()&&(m.preventDefault(),ta(g.value.trim(),Zt),g.value="✓ Saved!",g.disabled=!0,g.style.background="#22c55e",u==null||u.focus())})}function ea(){yt&&(yt.remove(),yt=null)}function ix(){wt=!1,Ho=0,Ir=0,be.checkpoints.forEach(n=>n.reached=!1),rr=dd,nn=!1,Io=!1,qi=[],Ty()}function lp(){document.dispatchEvent(new CustomEvent("oo:gamemode",{detail:{mode:"build"}})),wt=!1,Io=!1}function Iy(){nn||(nn=!0,zc=performance.now(),Tt==="race"&&wt&&(rr--,console.log("[OpenOverlay] Died! Lives remaining:",rr)))}let cp=!1;function sx(){const n=performance.now();for(const[t,r]of qt){let o=Gn.get(t);if(!o){o={x:r.x,y:r.y,vx:r.vx,vy:r.vy,lastSyncTime:n,targetX:r.x,targetY:r.y},Gn.set(t,o);continue}const i=Math.abs(r.x-o.targetX)>.1||Math.abs(r.y-o.targetY)>.1,s=Math.abs(r.vx-o.vx)>.1||Math.abs(r.vy-o.vy)>.1;if(i||s){o.vx=r.vx,o.vy=r.vy,o.lastSyncTime=n;const g=5;o.targetX=r.x+r.vx*g,o.targetY=r.y+r.vy*g}o.x+=o.vx*.5,o.y+=o.vy*.5;const c=.12,d=o.targetX-o.x,u=o.targetY-o.y;(Math.abs(d)>1||Math.abs(u)>1)&&(o.x+=d*c,o.y+=u*c),Math.sqrt(d*d+u*u)>150&&(o.x=r.x,o.y=r.y)}for(const t of Gn.keys())qt.has(t)||Gn.delete(t);const e=Date.now();for(const[t,r]of qt)r.updatedAt&&e-r.updatedAt>QS&&(console.log("[OpenOverlay] Removing stale player:",t),qt.delete(t),Gn.delete(t))}function ax(n){if(Fe!=="play")return;if(sx(),xn){const D=performance.now()-fd,j=_y-D;j>1e3?Me={text:"Get Ready!",subtext:"2",endTime:performance.now()+100}:j>0?Me={text:"Get Ready!",subtext:"1",endTime:performance.now()+100}:(xn=!1,Me={text:"GO!",endTime:performance.now()+500},Tt==="race"&&(wt=!0,jc=performance.now()));return}if(nn){const D=sp-(performance.now()-zc);if(D>0&&(Me={text:"You fell!",subtext:`Respawning in ${Math.ceil(D/1e3)}...`,endTime:performance.now()+100}),performance.now()-zc>=sp){if(Tt==="race"&&rr<=0){wt=!1,nn=!1,Ey("gameover");return}if(Tt==="explore"&&!py){nn=!1,Me=null,document.dispatchEvent(new CustomEvent("oo:gamemode",{detail:{mode:"none"}}));return}nn=!1,wy(),Me=null,setTimeout(()=>{},100)}return}Me&&performance.now()>Me.endTime&&(Me=null);const t=performance.now()<hd?op*2:op;if(Vt.ArrowLeft||Vt.KeyA)A.vx=-t,A.facingRight=!1,Js=performance.now(),$n=!1;else if(Vt.ArrowRight||Vt.KeyD)A.vx=t,A.facingRight=!0,Js=performance.now(),$n=!1;else{const D=_i>0?.92:ZS;A.vx*=D,Math.abs(A.vx)<.1&&(A.vx=0)}if(_i>0&&_i--,Math.abs(A.vx)>.5){const D=(pt==null?void 0:pt.gameActive)&&!isPlayerIt(),j=Tt==="explore"||D,V=Math.abs(A.x-Qf);j&&V>Zs&&!bi&&(bi=!0,ec=0,Qf=A.x,D?Zs=Zf+Math.random()*(YS-Zf):Zs=Jf+Math.random()*(GS-Jf)),bi?(mn=-1,ec++,ec>=HS&&(bi=!1)):mn=1,Ui=0}else bi=!1,Zs=50,Ui===0&&Math.abs(mn)>.1&&(mn=A.facingRight?1:-1),Math.abs(mn)>.1?mn*=1-WS:mn=0,Ui++;A.onGround&&Math.abs(A.vx)<.1?(performance.now()-Js>BS&&!$n&&($n=!0,Kf=performance.now(),ya=0),$n&&(performance.now()-Kf<$S?ya+=.15:($n=!1,Js=performance.now()))):($n=!1,ya=0);const o=Vt.ArrowUp||Vt.KeyW||Vt.Space;if(o&&!cp&&A.jumpsRemaining>0){const D=Ha?rp*1.5:rp;A.vy=D,A.onGround=!1,A.jumpsRemaining--,Ha=!1}cp=o,A.vy+=JS*n,A.vy>ip&&(A.vy=ip);const i=50,s=A.vx>=0;A.onGround=!1;const c=A.vx*n,d=A.vy*n,u=Math.sqrt(c*c+d*d),f=Math.max(1,Math.ceil(u/nc)),g=c/f,m=d/f;for(let D=0;D<f;D++){const j=A.x+g,V=A.y+m,B=vi(j,A.y,A.width,A.height,s);let I=!0;A.vx<0&&B.leftWall&&(A.x=B.leftWallX,A.vx=0,I=!1),A.vx>0&&B.rightWall&&(A.x=B.rightWallX-A.width,A.vx=0,I=!1),I&&Math.abs(A.vx)>.5&&B.slopeAheadY>0&&B.slopeAngle>i&&(A.vx=0,I=!1);let b=!0;if(A.vy<0){const _=vi(A.x,V,A.width,A.height,s);_.ceiling&&(A.y=_.ceilingY,A.vy=1,b=!1)}if(I&&(A.x+=g),b&&(A.y+=m),A.vy>=0){const _=vi(A.x,A.y,A.width,A.height,s);if(_.floor){const E=_.floorY-A.height,T=A.y-E,w=A.vy>5?2:8;if(T<=w&&T>=-nc){!Qs&&Math.abs(A.vx)>.5&&(_i=8),!Qs&&Wc&&(Wc=!1,ox("Move with WASD/Arrows!",1500)),A.y=E,A.vy=0,A.onGround=!0,A.jumpsRemaining=A.maxJumps;break}}}}const v=vi(A.x,A.y,A.width,A.height,s);A.vy<0&&v.ceiling&&(A.y=v.ceilingY,A.vy=1);const L=v.leftWall&&A.x<v.leftWallX,P=v.rightWall&&A.x+A.width>v.rightWallX;if(L&&P){const D=v.leftWallX-A.x,j=A.x+A.width-v.rightWallX;D<j?A.x=v.leftWallX:A.x=v.rightWallX-A.width,A.vx=0}else L?(A.x=v.leftWallX,A.vx=0):P&&(A.x=v.rightWallX-A.width,A.vx=0);if(A.vy>0&&!A.onGround&&v.floor){const D=v.floorY-A.height,j=A.y-D;j<=8&&j>=-nc&&(!Qs&&Math.abs(A.vx)>.5&&(_i=8),A.y=D,A.vy=0,A.onGround=!0,A.jumpsRemaining=A.maxJumps)}if(A.onGround&&Math.abs(A.vx)>.5){const D=Math.abs(A.vx),j=Math.min(3,Math.ceil(D*.3));for(let V=1;V<=j;V++){const B=A.y-V,I=vi(A.x,B,A.width,A.height,s);if(I.floor&&!I.leftWall&&!I.rightWall){const b=I.floorY-A.height,_=A.y-b;if(_>0&&_<=j){A.y=b;break}}}}Qs=A.onGround;const M=Math.max(document.body.scrollHeight,window.innerHeight),G=Math.max(document.body.scrollWidth,window.innerWidth);(A.y>M+tx||A.x<-100||A.x>G+100)&&Iy(),Math.abs(A.vx)>.5?A.animFrame=(A.animFrame+.15*n)%4:A.animFrame=0,lx(),cx(),He&&ux(),wt&&Tt==="race"&&(Ho=performance.now()-jc);const $=performance.now();if(Fe==="play"&&$-tc>KS){const D=Math.abs(A.x-ep)>5||Math.abs(A.y-tp)>5,j=$-tc>5e3;(D||j)&&(tc=$,ep=A.x,tp=A.y,cs())}}function cs(){const n=On(),e=ge(),t=He&&ls();He&&console.log("[OpenOverlay] Syncing player with isIt:",t,"isTagMode:",He,"localIsIt:",Oe);const r=Date.now();Kn&&r-Lr>gy&&(Kn=null,Lr=0);const o={x:A.x,y:A.y+A.height,vx:A.vx,vy:A.vy,facingRight:A.facingRight,animFrame:A.animFrame,onGround:A.onGround,isDead:nn,playerColor:Dc,playerHat:is,playerAccessory:ss,isGirlMode:Fi,faceStyle:as,displayName:Uc||(e==null?void 0:e.displayName)||"",updatedAt:r,isIt:He&&ls(),tagCooldownUntil:Sn};Kn&&(o.taggedPlayerId=Kn,o.taggedAt=Lr),_I(n,o)}function lx(){if(Tt!=="race")return;const n=vy(),e=n.checkpoints,t=e.filter(r=>r.type==="checkpoint").length;for(const r of e){if(r.reached)continue;const o=A.x+A.width/2,i=A.y+A.height/2;if(Math.hypot(o-r.x,i-r.y)<50)if(r.type==="start"&&!wt)wt=!0,jc=performance.now(),r.reached=!0,console.log("[OpenOverlay] Race started!");else if(r.type==="checkpoint"&&wt){const c=Ir+1;r.order===c&&(r.reached=!0,Ir++,console.log("[OpenOverlay] Checkpoint",Ir,"of",t,"reached!"),zt(`Flag ${Ir}/${t}`,"",1500))}else r.type==="finish"&&wt&&Ir>=t&&(r.reached=!0,wt=!1,Zt=Ho,console.log("[OpenOverlay] Race finished! Time:",(Zt/1e3).toFixed(2)+"s"),(!n.bestTime||Zt<n.bestTime)&&(n.bestTime=Zt,n===be&&Vo()),Ey("finish"),document.dispatchEvent(new CustomEvent("oo:racefinish",{detail:{time:Zt,bestTime:n.bestTime}})))}}function cx(){const n=[...be.checkpoints,...Do.flatMap(e=>e.checkpoints)];for(const e of n){if(!["trampoline","speedBoost","highJump","spike"].includes(e.type))continue;const t=e.width||60,r=e.height||20,o=e.x-t/2,i=e.x+t/2,s=e.y-r,c=e.y,d=A.x,u=A.x+A.width,f=A.y,g=A.y+A.height;if(u>o&&d<i&&g>s&&f<c)switch(e.type){case"trampoline":A.vy>0&&(A.vy=-20,A.onGround=!1,A.jumpsRemaining=A.maxJumps);break;case"speedBoost":hd=performance.now()+3e3;break;case"highJump":Ha=!0;break;case"spike":nn||(qi.push({x:A.x+A.width/2,y:A.y+A.height,createdAt:performance.now()}),Iy());break}}}function ux(){if(!He||!ge())return;const e=Date.now(),t=On(),r=A.x+A.width/2,o=A.y+A.height,i=ls();for(const[s,c]of qt){const d=Gn.get(s),u=d?d.x:c.x,f=d?d.y:c.y,g=r-u,m=o-f;if(Math.sqrt(g*g+m*m)<40){const L=e>Sn,P=!c.tagCooldownUntil||e>c.tagCooldownUntil;i&&L&&P&&(console.log("[OpenOverlay] TAGGING player:",s),Oe=!1,Kn=s,Lr=e,II(t,s).catch(()=>{console.log("[OpenOverlay] Firebase tag update failed, using local state")}),Sn=e+Wa,zt("Tagged!",c.displayName||"Player",1500),Hc(),document.dispatchEvent(new CustomEvent("oo:tagstatechange",{detail:{isTagMode:!0,isIt:!1,gameActive:!0}})),cs());const M=!c.tagCooldownUntil||e>c.tagCooldownUntil;!i&&c.isIt&&L&&M&&(console.log("[OpenOverlay] GOT TAGGED by:",s),Oe=!0,Sn=e+Wa,yn=s,zt("You're IT!","Tag someone!",2e3),Hc(),document.dispatchEvent(new CustomEvent("oo:tagstatechange",{detail:{isTagMode:!0,isIt:!0,gameActive:!0}})))}}}function tt(){if(!(!l||!Re)){l.clearRect(0,0,Re.width,Re.height),J&&Ct&&J.clearRect(0,0,Ct.width,Ct.height),dx();for(const n of be.checkpoints)up(n);for(const n of Do)for(const e of n.checkpoints)up(e,n.authorName);(Fe==="play"||Fe==="build")&&(hx(),gx(),Fe==="play"&&_x()),Fe==="build"&&Ex()}}function dx(){if(!l)return;const n=performance.now(),e=5e3;qi=qi.filter(t=>n-t.createdAt<e);for(const t of qi){const r=n-t.createdAt,o=Math.max(0,1-r/e);l.save(),l.globalAlpha=o,l.fillStyle="#dc2626",l.beginPath(),l.arc(t.x,t.y,12,0,Math.PI*2),l.fill(),l.fillStyle="#b91c1c";for(let i=0;i<5;i++){const s=i/5*Math.PI*2+Math.random()*.5,c=15+Math.random()*10,d=Math.cos(s)*c,u=Math.sin(s)*c*.5;l.beginPath(),l.arc(t.x+d,t.y+u,4+Math.random()*3,0,Math.PI*2),l.fill()}l.restore()}}function up(n,e){if(!l)return;const t=n.x,r=n.y;if(l.save(),e&&(n.type==="start"||n.type==="finish")&&(l.font="10px Arial",l.fillStyle="rgba(255,255,255,0.7)",l.textAlign="center",l.fillText(`by ${e}`,t,r+15)),n.type==="start"){const o=n.reached?"#86efac":"#22c55e",i=80,s=70;l.strokeStyle="#444",l.lineWidth=6,l.beginPath(),l.moveTo(t-i/2,r),l.lineTo(t-i/2,r-s),l.stroke(),l.beginPath(),l.moveTo(t+i/2,r),l.lineTo(t+i/2,r-s),l.stroke(),l.fillStyle=o,l.fillRect(t-i/2-3,r-s-15,i+6,20),l.strokeStyle="#166534",l.lineWidth=2,l.strokeRect(t-i/2-3,r-s-15,i+6,20),l.fillStyle="#fff",l.font="bold 14px sans-serif",l.textAlign="center",l.fillText("START",t,r-s-1)}else if(n.type==="finish"){l.strokeStyle="#444",l.lineWidth=6,l.beginPath(),l.moveTo(t-80/2,r),l.lineTo(t-80/2,r-70),l.stroke(),l.beginPath(),l.moveTo(t+80/2,r),l.lineTo(t+80/2,r-70),l.stroke();const s=r-70-15,c=20,d=8;l.fillStyle=n.reached?"#fbbf24":"#111",l.fillRect(t-80/2-3,s,86,c);for(let u=0;u<Math.ceil(86/d);u++)for(let f=0;f<Math.ceil(c/d);f++)(u+f)%2===0&&(l.fillStyle="#fff",l.fillRect(t-80/2-3+u*d,s+f*d,d,Math.min(d,c-f*d)));l.strokeStyle="#444",l.lineWidth=2,l.strokeRect(t-80/2-3,s,86,c),l.fillStyle="#fff",l.font="bold 11px sans-serif",l.textAlign="center",l.fillText("FINISH",t,r+15)}else if(n.type==="spawn"){if(Fe!=="build"){l.restore();return}const o="#a855f7";l.fillStyle=o,l.beginPath(),l.moveTo(t,r-20),l.lineTo(t-10,r-35),l.lineTo(t+10,r-35),l.closePath(),l.fill(),l.strokeStyle=o,l.lineWidth=2,l.beginPath(),l.arc(t,r-55,8,0,Math.PI*2),l.stroke(),l.beginPath(),l.moveTo(t,r-47),l.lineTo(t,r-30),l.stroke(),l.beginPath(),l.moveTo(t-10,r-42),l.lineTo(t+10,r-42),l.stroke(),l.beginPath(),l.moveTo(t,r-30),l.lineTo(t-8,r-15),l.moveTo(t,r-30),l.lineTo(t+8,r-15),l.stroke(),l.fillStyle="#fff",l.font="bold 10px sans-serif",l.textAlign="center",l.fillText("SPAWN",t,r+5)}else if(n.type==="trampoline"){const o=n.width||60,i=n.height||20;l.fillStyle="#f97316",l.fillRect(t-o/2,r-i,o,i),l.strokeStyle="#c2410c",l.lineWidth=2,l.strokeRect(t-o/2,r-i,o,i),l.strokeStyle="#c2410c",l.lineWidth=2;const s=3,c=o/s;for(let d=0;d<s;d++){const u=t-o/2+c/2+d*c;l.beginPath(),l.moveTo(u,r),l.lineTo(u-4,r-i/3),l.lineTo(u+4,r-i*2/3),l.lineTo(u,r-i),l.stroke()}}else if(n.type==="speedBoost"){const o=n.width||60,i=n.height||20,s=performance.now()<hd;l.fillStyle=s?"#60a5fa":"#3b82f6",l.fillRect(t-o/2,r-i,o,i),l.strokeStyle="#1d4ed8",l.lineWidth=2,l.strokeRect(t-o/2,r-i,o,i),l.fillStyle="#fff",l.font="bold 14px sans-serif",l.textAlign="center",l.textBaseline="middle",l.fillText(">>",t,r-i/2)}else if(n.type==="highJump"){const o=n.width||60,i=n.height||20,s=Ha;l.fillStyle=s?"#86efac":"#22c55e",l.fillRect(t-o/2,r-i,o,i),l.strokeStyle="#15803d",l.lineWidth=2,l.strokeRect(t-o/2,r-i,o,i),l.fillStyle="#fff",l.font="bold 16px sans-serif",l.textAlign="center",l.textBaseline="middle",l.fillText("^",t,r-i/2)}else if(n.type==="spike"){const o=n.width||60,i=n.height||30,s=4,c=o/s;l.fillStyle="#ef4444";for(let d=0;d<s;d++){const u=t-o/2+d*c;l.beginPath(),l.moveTo(u,r),l.lineTo(u+c/2,r-i),l.lineTo(u+c,r),l.closePath(),l.fill()}l.strokeStyle="#991b1b",l.lineWidth=1;for(let d=0;d<s;d++){const u=t-o/2+d*c;l.beginPath(),l.moveTo(u,r),l.lineTo(u+c/2,r-i),l.lineTo(u+c,r),l.closePath(),l.stroke()}}else if(n.type==="checkpoint"){const o=n.reached?"#fbbf24":"#3b82f6";l.strokeStyle="#444",l.lineWidth=4,l.beginPath(),l.moveTo(t,r),l.lineTo(t,r-50),l.stroke(),l.fillStyle=o,l.beginPath(),l.moveTo(t,r-50),l.lineTo(t+35,r-40),l.lineTo(t,r-30),l.closePath(),l.fill(),l.fillStyle="#fff",l.font="bold 12px sans-serif",l.textAlign="center",l.textBaseline="middle",l.fillText(String(n.order),t+15,r-40)}l.restore()}function hx(){if(l)for(const[n,e]of qt){const t=`logged_${n}`;window[t]||(window[t]=!0,console.log("[OpenOverlay] Remote player data:",n,JSON.stringify({isGirlMode:e.isGirlMode,playerHat:e.playerHat,playerColor:e.playerColor,displayName:e.displayName,playerAccessory:e.playerAccessory,isIt:e.isIt}))),fx(n,e)}}function fx(n,e){if(!l||e.isDead)return;const t=Gn.get(n),r=t?t.x:e.x,o=t?t.y:e.y,i=30,s=50,c=r,d=o-s;l.save(),l.globalAlpha=.85,e.facingRight||(l.translate(c+i/2,0),l.scale(-1,1),l.translate(-(c+i/2),0));const u=7,f=13,g=11,m=c+i/2,v=d+u+3,L=v+u,P=L+f,M=e.playerColor||"#ffffff";l.strokeStyle=M,l.lineWidth=3,l.lineCap="round",l.lineJoin="round",l.shadowColor="rgba(0,0,0,0.3)",l.shadowBlur=4,l.shadowOffsetX=2,l.shadowOffsetY=2;const G=Math.abs(e.vx)>.5,$=e.animFrame||0;if(e.isGirlMode){if(l.fillStyle=M,l.beginPath(),l.moveTo(m-u-2,v+8),l.lineTo(m-u-1,v-2),l.quadraticCurveTo(m-u+2,v-u-4,m,v-u-3),l.quadraticCurveTo(m+u-2,v-u-4,m+u+1,v-2),l.lineTo(m+u+2,v+8),l.quadraticCurveTo(m+u,v+10,m+u-2,v+10),l.lineTo(m-u+2,v+10),l.quadraticCurveTo(m-u,v+10,m-u-2,v+8),l.closePath(),l.fill(),l.fillStyle="#fff",l.beginPath(),l.arc(m,v,u-1,0,Math.PI*2),l.fill(),l.fillStyle=M,l.beginPath(),l.moveTo(m-u+2,v-2),l.quadraticCurveTo(m-2,v-u-2,m,v-u+1),l.quadraticCurveTo(m+2,v-u-2,m+u-2,v-2),l.quadraticCurveTo(m,v-1,m-u+2,v-2),l.closePath(),l.fill(),(e.faceStyle||"smudgy")==="smudgy"){const I=e.vx>.5?1:e.vx<-.5?-1:0;Ga(l,m,v,u,I,e.vy,e.onGround!==!1)}else l.fillStyle=M,G?(l.beginPath(),l.arc(m+2,v,1.5,0,Math.PI*2),l.fill(),l.lineWidth=2,l.beginPath(),l.moveTo(m,v+4),l.lineTo(m+4,v+4),l.stroke(),l.lineWidth=3):(l.beginPath(),l.arc(m-3,v,1.5,0,Math.PI*2),l.fill(),l.beginPath(),l.arc(m+3,v,1.5,0,Math.PI*2),l.fill(),l.lineWidth=1.5,l.beginPath(),l.arc(m,v+3,2.5,.2*Math.PI,.8*Math.PI),l.stroke(),l.lineWidth=3);l.fillStyle=M,l.beginPath(),l.moveTo(m,L),l.lineTo(m-8,P+1),l.lineTo(m+8,P+1),l.closePath(),l.fill();const B=G?Math.sin($*Math.PI)*6:0;l.strokeStyle="#000",l.lineWidth=2.5,l.beginPath(),l.moveTo(m-3,P),l.lineTo(m-5+B,P+g),l.moveTo(m+3,P),l.lineTo(m+5-B,P+g),l.stroke(),l.strokeStyle="#fff",l.lineWidth=2,l.beginPath(),l.moveTo(m-3,P),l.lineTo(m-5+B,P+g),l.moveTo(m+3,P),l.lineTo(m+5-B,P+g),l.stroke(),l.lineWidth=3,l.strokeStyle=M}else{const V=e.faceStyle||"smudgy",B=v-u;if(V==="smudgy"){const Z=e.animFrame||0;l.strokeStyle=M,l.lineWidth=2.5,l.lineCap="round";const de=Math.sin(Z*Math.PI*2)*2;G?(l.beginPath(),l.moveTo(m+2,B+2),l.bezierCurveTo(m+2,B-6,m-6,B-4,m-12+de,B-2),l.stroke(),l.beginPath(),l.moveTo(m-1,B+2),l.bezierCurveTo(m-1,B-4,m-5,B-2,m-9+de*.7,B),l.stroke()):(l.beginPath(),l.moveTo(m+1,B+1),l.quadraticCurveTo(m+1,B-5,m,B-9),l.stroke(),l.beginPath(),l.moveTo(m-2,B+2),l.quadraticCurveTo(m-2,B-2,m-2,B-5),l.stroke()),l.strokeStyle=M,l.lineWidth=3,l.beginPath(),l.arc(m,v,u,0,Math.PI*2),l.stroke();const fe=e.vx>.5?1:e.vx<-.5?-1:0;Ga(l,m,v,u,fe,e.vy,e.onGround!==!1)}else l.beginPath(),l.arc(m,v,u,0,Math.PI*2),l.stroke(),l.fillStyle=M,l.beginPath(),l.moveTo(m-6,v-u+1),l.lineTo(m-3,v-u-4),l.lineTo(m+8,v-u+3),l.quadraticCurveTo(m,v-u-1,m-6,v-u+1),l.closePath(),l.fill(),l.stroke(),l.fillStyle=M,G?(l.beginPath(),l.arc(m+3,v-1,2,0,Math.PI*2),l.fill(),l.beginPath(),l.moveTo(m+1,v+4),l.lineTo(m+5,v+4),l.stroke()):(l.beginPath(),l.arc(m-3,v-1,1.5,0,Math.PI*2),l.fill(),l.beginPath(),l.arc(m+3,v-1,1.5,0,Math.PI*2),l.fill(),l.lineWidth=1.5,l.beginPath(),l.arc(m,v+3,3,.2*Math.PI,.8*Math.PI),l.stroke(),l.lineWidth=3);l.beginPath(),l.moveTo(m,L),l.lineTo(m,P),l.stroke();const I=(Z,de,fe,me,xe,Te)=>{const Ie=Z+Math.sin(fe)*me*(Te?-1:1),ae=de+Math.cos(fe)*me,ye=fe+(Te?-1.2:1.2),ve=Ie+Math.sin(ye)*xe*(Te?-1:1),Ae=ae+Math.cos(ye)*xe;l.beginPath(),l.moveTo(Z,de),l.lineTo(Ie,ae),l.lineTo(ve,Ae),l.stroke()},b=L+3,_=P,E=Math.sin($*Math.PI),T=6,S=6;if(G){const Z=E*.8;I(m,b,-Z*.6,T,S,!0),I(m,b,Z*.6,T,S,!1)}else I(m,b,.2,T,S,!0),I(m,b,.2,T,S,!1);const w=G?Math.sin($*Math.PI)*8:0;l.beginPath(),l.moveTo(m,_),l.lineTo(m-4+w,_+g),l.stroke(),l.beginPath(),l.moveTo(m,_),l.lineTo(m+4-w,_+g),l.stroke()}if(e.playerHat&&e.playerHat!=="none"&&px(m,v,u,e.playerHat,M),l.restore(),l.save(),l.globalAlpha=.9,e.displayName){l.shadowColor="transparent",l.fillStyle="rgba(0,0,0,0.7)",l.font='bold 11px "Comic Sans MS", "Chalkboard SE", cursive';const V=l.measureText(e.displayName).width;l.fillRect(m-V/2-5,v-u-22,V+10,16),l.fillStyle=e.playerColor||"#fff",l.textAlign="center",l.textBaseline="middle",l.fillText(e.displayName,m,v-u-14)}l.restore(),He&&e.isIt&&(l.save(),l.shadowColor="#ff0000",l.shadowBlur=15,l.fillStyle="#ff0000",l.font="bold 16px sans-serif",l.textAlign="center",l.textBaseline="middle",l.fillText("IT",m,v-u-25),l.restore());const j=Date.now();He&&e.tagCooldownUntil&&e.tagCooldownUntil>j&&Sy(m,d+s/2,e.tagCooldownUntil,j)}function px(n,e,t,r,o){if(!l)return;const i=e-t;switch(r){case"cap":l.fillStyle="#ef4444",l.beginPath(),l.ellipse(n,i-2,t+2,5,0,0,Math.PI*2),l.fill(),l.fillRect(n-2,i-4,t+8,4);break;case"tophat":l.fillStyle="#1a1a1a",l.fillRect(n-12,i-2,24,4),l.fillRect(n-8,i-18,16,16),l.fillStyle=o,l.fillRect(n-8,i-6,16,3);break;case"crown":l.fillStyle="#fbbf24",l.beginPath(),l.moveTo(n-10,i),l.lineTo(n-10,i-8),l.lineTo(n-6,i-4),l.lineTo(n-3,i-12),l.lineTo(n,i-6),l.lineTo(n+3,i-12),l.lineTo(n+6,i-4),l.lineTo(n+10,i-8),l.lineTo(n+10,i),l.closePath(),l.fill(),l.fillStyle="#dc2626",l.beginPath(),l.arc(n,i-5,2,0,Math.PI*2),l.fill();break;case"beanie":l.fillStyle="#3b82f6",l.beginPath(),l.arc(n,i,t+1,Math.PI,0),l.fill(),l.fillStyle="#fff",l.beginPath(),l.arc(n,i-t-3,4,0,Math.PI*2),l.fill();break;case"party":l.fillStyle="#ec4899",l.beginPath(),l.moveTo(n,i-20),l.lineTo(n-10,i),l.lineTo(n+10,i),l.closePath(),l.fill(),l.strokeStyle="#fbbf24",l.lineWidth=2,l.beginPath(),l.moveTo(n-8,i-4),l.lineTo(n+8,i-4),l.moveTo(n-5,i-10),l.lineTo(n+5,i-10),l.stroke(),l.lineWidth=3;break}}function Ga(n,e,t,r,o,i,s,c){n.save(),n.shadowColor="transparent",n.shadowBlur=0,n.shadowOffsetX=0,n.shadowOffsetY=0,n.fillStyle=Fc,n.beginPath(),n.arc(e,t,r-1,0,Math.PI*2),n.fill();const d=zS(Fc,.2);n.strokeStyle=d,n.lineWidth=1,n.beginPath(),n.arc(e,t,r-1,0,Math.PI*2),n.stroke();const u=r-3,f=o*u;let g=0,m=1;s?Math.abs(o)>.3&&(g=1):i<-2?(g=-4,m=.3):i>2&&(g=1);const v=r-4,L=f*m;n.globalCompositeOperation="destination-out",n.beginPath(),n.arc(e+L,t+g,v,0,Math.PI*2),n.fill(),n.restore()}function gx(){if(!l)return;const n=A.x,e=A.y,t=A.width,r=A.height;l.save();const o=Math.abs(A.vx)>.5;o&&!A.facingRight&&(l.translate(n+t/2,0),l.scale(-1,1),l.translate(-(n+t/2),0));const s=o?.17:0;if(s!==0){const _=n+t/2,E=e+r-5;l.translate(_,E),l.rotate(s),l.translate(-_,-E)}const c=7,d=13,u=11,f=n+t/2,g=e+c+3,m=g+c,v=m+d;if(l.strokeStyle=Mt,l.lineWidth=3,l.lineCap="round",l.lineJoin="round",l.shadowColor="rgba(0,0,0,0.3)",l.shadowBlur=4,l.shadowOffsetX=2,l.shadowOffsetY=2,Fi){const _=Math.sin(A.animFrame*Math.PI*2)*3;l.fillStyle=Ci,l.beginPath(),o?(l.moveTo(f,g-c-3),l.quadraticCurveTo(f-c+2,g-c-4,f-c-1,g-2),l.lineTo(f-c-2,g+4),l.quadraticCurveTo(f-c-4-_,g+8,f-c-3-_,g+12),l.quadraticCurveTo(f-c,g+11,f-c+3,g+10),l.lineTo(f-2,g+c),l.closePath(),l.fill()):(l.moveTo(f-c-2,g+8),l.lineTo(f-c-1,g-2),l.quadraticCurveTo(f-c+2,g-c-4,f,g-c-3),l.quadraticCurveTo(f+c-2,g-c-4,f+c+1,g-2),l.lineTo(f+c+2,g+8),l.quadraticCurveTo(f+c,g+10,f+c-2,g+10),l.lineTo(f-c+2,g+10),l.quadraticCurveTo(f-c,g+10,f-c-2,g+8),l.closePath(),l.fill()),l.strokeStyle="#000",l.lineWidth=.5,l.beginPath(),l.arc(f,g,c-.5,0,Math.PI*2),l.stroke(),l.fillStyle=Vc,l.beginPath(),l.arc(f,g,c-1,0,Math.PI*2),l.fill(),l.fillStyle=Ci,l.beginPath(),l.moveTo(f-c+2,g-2),l.quadraticCurveTo(f-2,g-c-2,f,g-c+1),l.quadraticCurveTo(f+2,g-c-2,f+c-2,g-2),l.quadraticCurveTo(f,g-1,f-c+2,g-2),l.closePath(),l.fill(),as==="smudgy"?Ga(l,f,g,c,mn,A.vy,A.onGround):(l.fillStyle=Mt,o?(l.beginPath(),l.arc(f+2,g,1.5,0,Math.PI*2),l.fill(),l.lineWidth=2,l.beginPath(),l.moveTo(f,g+4),l.lineTo(f+4,g+4),l.stroke(),l.lineWidth=3):(l.beginPath(),l.arc(f-3,g,1.5,0,Math.PI*2),l.fill(),l.beginPath(),l.arc(f+3,g,1.5,0,Math.PI*2),l.fill(),l.lineWidth=1.5,l.beginPath(),l.arc(f,g+3,2.5,.2*Math.PI,.8*Math.PI),l.stroke(),l.lineWidth=3))}else{const _=g-c;if(as==="smudgy"){l.lineCap="round";const E=Math.sin(A.animFrame*Math.PI*2)*2,T=S=>{l.strokeStyle="#fff",l.lineWidth=3.1,S(),l.stroke(),l.strokeStyle="#000",l.lineWidth=2.8,S(),l.stroke(),l.strokeStyle=Ci,l.lineWidth=2.5,S(),l.stroke()};o?(T(()=>{l.beginPath(),l.moveTo(f+2,_+1),l.bezierCurveTo(f+1,_-8,f-3,_-9,f-6+E*.5,_-7)}),T(()=>{l.beginPath(),l.moveTo(f-2,_+1),l.bezierCurveTo(f-2,_-5,f-4,_-6,f-7+E*.4,_-4)})):(T(()=>{l.beginPath(),l.moveTo(f+1,_+1),l.quadraticCurveTo(f+1,_-5,f,_-9)}),T(()=>{l.beginPath(),l.moveTo(f-2,_+2),l.quadraticCurveTo(f-2,_-2,f-2,_-5)})),Ga(l,f,g,c,mn,A.vy,A.onGround),l.strokeStyle=Vc,l.lineWidth=2,l.beginPath(),l.arc(f,g,c,0,Math.PI*2),l.stroke()}else l.beginPath(),l.arc(f,g,c,0,Math.PI*2),l.stroke(),l.fillStyle=Ci,l.beginPath(),l.moveTo(f-6,g-c+1),l.lineTo(f-3,g-c-4),l.lineTo(f+8,g-c+3),l.quadraticCurveTo(f,g-c-1,f-6,g-c+1),l.closePath(),l.fill(),l.stroke(),l.fillStyle=Mt,o?(l.beginPath(),l.arc(f+3,g-1,2,0,Math.PI*2),l.fill(),l.beginPath(),l.moveTo(f+1,g+4),l.lineTo(f+5,g+4),l.stroke()):(l.beginPath(),l.arc(f-3,g-1,1.5,0,Math.PI*2),l.fill(),l.beginPath(),l.arc(f+3,g-1,1.5,0,Math.PI*2),l.fill(),l.beginPath(),l.arc(f,g+3,3,.1*Math.PI,.9*Math.PI),l.stroke());l.strokeStyle="#fff",l.lineWidth=3.6,l.beginPath(),l.moveTo(f,m),l.lineTo(f,v),l.stroke(),l.strokeStyle="#000",l.lineWidth=3.3,l.beginPath(),l.moveTo(f,m),l.lineTo(f,v),l.stroke(),l.strokeStyle=Mt,l.lineWidth=3,l.beginPath(),l.moveTo(f,m),l.lineTo(f,v),l.stroke()}const L=Math.sin(A.animFrame*Math.PI),P=Math.abs(A.vx)>.5,M=P||Ui<Xf,G=(_,E,T,S,w,Z)=>{const de=T,fe=_+Math.sin(de)*S*(Z?-1:1),me=E+Math.cos(de)*S,xe=de+(Z?-1.2:1.2),Te=fe+Math.sin(xe)*w*(Z?-1:1),Ie=me+Math.cos(xe)*w;l.strokeStyle="#fff",l.lineWidth=3.6,l.beginPath(),l.moveTo(_,E),l.lineTo(fe,me),l.lineTo(Te,Ie),l.stroke(),l.strokeStyle="#000",l.lineWidth=3.3,l.beginPath(),l.moveTo(_,E),l.lineTo(fe,me),l.lineTo(Te,Ie),l.stroke(),l.strokeStyle=Mt,l.lineWidth=3,l.beginPath(),l.moveTo(_,E),l.lineTo(fe,me),l.lineTo(Te,Ie),l.stroke()},$=m+4,D=v,j=6,V=6;if($n){const _=Math.sin(ya*4)*.4;G(f,$,-1.5+_,j,V,!0),G(f,$,.3,j,V,!1)}else if(M){const _=P?L*1.2:L*1.2*(1-Ui/Xf);G(f,$,-_,j,V,!0),G(f,$,_,j,V,!1)}else if(Fi)l.strokeStyle="#fff",l.lineWidth=3.6,l.beginPath(),l.moveTo(f,$),l.lineTo(f-u,$+2),l.stroke(),l.strokeStyle="#000",l.lineWidth=3.3,l.beginPath(),l.moveTo(f,$),l.lineTo(f-u,$+2),l.stroke(),l.strokeStyle=Mt,l.lineWidth=3,l.beginPath(),l.moveTo(f,$),l.lineTo(f-u,$+2),l.stroke(),l.strokeStyle="#fff",l.lineWidth=3.6,l.beginPath(),l.moveTo(f,$),l.lineTo(f+u,$+2),l.stroke(),l.strokeStyle="#000",l.lineWidth=3.3,l.beginPath(),l.moveTo(f,$),l.lineTo(f+u,$+2),l.stroke(),l.strokeStyle=Mt,l.lineWidth=3,l.beginPath(),l.moveTo(f,$),l.lineTo(f+u,$+2),l.stroke();else{const _=v-2,E=7,T=$+5,S=4;l.strokeStyle="#fff",l.lineWidth=3.6,l.beginPath(),l.moveTo(f,$),l.lineTo(f-E,T),l.lineTo(f-S,_),l.stroke(),l.strokeStyle="#000",l.lineWidth=3.3,l.beginPath(),l.moveTo(f,$),l.lineTo(f-E,T),l.lineTo(f-S,_),l.stroke(),l.strokeStyle=Mt,l.lineWidth=3,l.beginPath(),l.moveTo(f,$),l.lineTo(f-E,T),l.lineTo(f-S,_),l.stroke(),l.strokeStyle="#fff",l.lineWidth=3.6,l.beginPath(),l.moveTo(f,$),l.lineTo(f+E,T),l.lineTo(f+S,_),l.stroke(),l.strokeStyle="#000",l.lineWidth=3.3,l.beginPath(),l.moveTo(f,$),l.lineTo(f+E,T),l.lineTo(f+S,_),l.stroke(),l.strokeStyle=Mt,l.lineWidth=3,l.beginPath(),l.moveTo(f,$),l.lineTo(f+E,T),l.lineTo(f+S,_),l.stroke()}const B=(_,E,T,S)=>{l.strokeStyle="#fff",l.lineWidth=3.6,l.beginPath(),l.moveTo(_,E),l.lineTo(T,S),l.stroke(),l.strokeStyle="#000",l.lineWidth=3.3,l.beginPath(),l.moveTo(_,E),l.lineTo(T,S),l.stroke(),l.strokeStyle=Mt,l.lineWidth=3,l.beginPath(),l.moveTo(_,E),l.lineTo(T,S),l.stroke()},I=P?Math.sin(A.animFrame*Math.PI)*8:0;!A.onGround&&A.vy<0?(B(f,D,f-3,D+u*.7),B(f,D,f+3,D+u*.7)):A.onGround?P?(B(f,D,f-4+I,D+u),B(f,D,f+4-I,D+u)):(B(f,D,f-4,D+u),B(f,D,f+4,D+u)):(B(f,D,f-7,D+u),B(f,D,f+7,D+u)),Fi&&(l.fillStyle=fy,l.beginPath(),l.moveTo(f,m),l.lineTo(f-10,v+5),l.lineTo(f+10,v+5),l.closePath(),l.fill()),mx(f,g,c),l.restore(),He&&ls()&&(l.save(),l.shadowColor="#ff0000",l.shadowBlur=15,l.fillStyle="#ff0000",l.font="bold 16px sans-serif",l.textAlign="center",l.textBaseline="middle",l.fillText("IT",f,g-c-20),l.restore());const b=Date.now();He&&Sn>b&&Sy(f,A.y+A.height/2,Sn,b)}function Sy(n,e,t,r){if(!l)return;const o=t-r;if(o<=0)return;const i=6,s=Wa/i,c=Math.ceil(o/s),d=35,u=Math.PI*2/i;l.save();for(let f=0;f<c;f++){const g=-Math.PI/2+f*u,m=g+u-.05;l.fillStyle="rgba(0, 200, 255, 0.3)",l.strokeStyle="rgba(0, 200, 255, 0.7)",l.lineWidth=2,l.beginPath(),l.moveTo(n,e),l.arc(n,e,d,g,m),l.closePath(),l.fill(),l.stroke()}l.strokeStyle="rgba(0, 200, 255, 0.5)",l.lineWidth=3,l.beginPath(),l.arc(n,e,d,0,Math.PI*2),l.stroke(),l.restore()}function mx(n,e,t){l&&(l.shadowBlur=0,is!=="none"&&yx(n,e,t),ss!=="none"&&vx(n,e,t))}function yx(n,e,t){if(!l)return;const r=e-t;switch(is){case"cap":l.fillStyle="#ef4444",l.beginPath(),l.ellipse(n,r-2,t+2,5,0,0,Math.PI*2),l.fill(),l.fillRect(n-2,r-4,t+8,4);break;case"tophat":l.fillStyle="#1a1a1a",l.fillRect(n-7,r-18,14,16),l.fillRect(n-12,r-2,24,4);break;case"crown":l.fillStyle="#fbbf24",l.beginPath(),l.moveTo(n-10,r),l.lineTo(n-10,r-8),l.lineTo(n-6,r-4),l.lineTo(n-3,r-12),l.lineTo(n,r-6),l.lineTo(n+3,r-12),l.lineTo(n+6,r-4),l.lineTo(n+10,r-8),l.lineTo(n+10,r),l.closePath(),l.fill(),l.fillStyle="#dc2626",l.beginPath(),l.arc(n,r-5,2,0,Math.PI*2),l.fill();break;case"beanie":l.fillStyle="#3b82f6",l.beginPath(),l.arc(n,r,t+1,Math.PI,0),l.fill(),l.fillStyle="#fff",l.beginPath(),l.arc(n,r-t-3,4,0,Math.PI*2),l.fill();break;case"party":l.fillStyle="#ec4899",l.beginPath(),l.moveTo(n,r-20),l.lineTo(n-10,r),l.lineTo(n+10,r),l.closePath(),l.fill(),l.strokeStyle="#fbbf24",l.lineWidth=2,l.beginPath(),l.moveTo(n-8,r-4),l.lineTo(n+8,r-4),l.moveTo(n-5,r-10),l.lineTo(n+5,r-10),l.stroke(),l.lineWidth=3;break}}function vx(n,e,t){if(l)switch(ss){case"glasses":l.strokeStyle="#333",l.lineWidth=1.5,l.beginPath(),l.arc(n-4,e-1,4,0,Math.PI*2),l.arc(n+4,e-1,4,0,Math.PI*2),l.stroke(),l.beginPath(),l.moveTo(n-1,e-1),l.lineTo(n+1,e-1),l.stroke(),l.lineWidth=3;break;case"sunglasses":l.fillStyle="#1a1a1a",l.fillRect(n-9,e-3,7,5),l.fillRect(n+2,e-3,7,5),l.fillRect(n-2,e-2,4,2);break;case"mustache":l.fillStyle="#4a3728",l.beginPath(),l.moveTo(n-8,e+3),l.quadraticCurveTo(n-4,e+6,n,e+4),l.quadraticCurveTo(n+4,e+6,n+8,e+3),l.quadraticCurveTo(n+4,e+4,n,e+3),l.quadraticCurveTo(n-4,e+4,n-8,e+3),l.fill();break;case"beard":l.fillStyle="#4a3728",l.beginPath(),l.moveTo(n-t+2,e+2),l.quadraticCurveTo(n-t,e+10,n,e+14),l.quadraticCurveTo(n+t,e+10,n+t-2,e+2),l.quadraticCurveTo(n,e+6,n-t+2,e+2),l.fill();break;case"mask":l.fillStyle="#1a1a1a",l.beginPath(),l.ellipse(n,e-1,t-1,4,0,0,Math.PI*2),l.fill(),l.fillStyle="#fff",l.beginPath(),l.ellipse(n-4,e-1,2.5,2,0,0,Math.PI*2),l.ellipse(n+4,e-1,2.5,2,0,0,Math.PI*2),l.fill();break}}function _x(){if(!l)return;const n=window.scrollX,e=window.scrollY,r=performance.now()<yy;if(l.save(),r){const o=Tt==="race"?260:180;l.fillStyle="rgba(0,0,0,0.8)",l.fillRect(n+10,e+10,o,70);let i="EXPLORE MODE",s="#22c55e";He?(i="TAG MODE",s="#f97316"):Tt==="race"&&(i="RACE MODE",s="#ef4444"),l.fillStyle=s,l.font="bold 11px sans-serif",l.fillText(i,n+20,e+25)}if(Tt==="race"){r||(l.fillStyle="rgba(0,0,0,0.7)",l.fillRect(n+10,e+10,250,50));const o=(Ho/1e3).toFixed(2);l.fillStyle="#fff",l.font="bold 20px monospace";const i=xn?"Ready...":wt?`${o}s`:rr<=0?"GAME OVER":`${o}s`;l.fillText(i,n+20,e+(r?48:38));const s=r?48:38;l.font="14px sans-serif",l.fillStyle="#888",l.fillText("Lives:",n+155,e+s);for(let c=0;c<dd;c++){const d=n+200+c*20,u=e+(r?40:30);c<rr?(l.strokeStyle="#22c55e",l.lineWidth=2,l.beginPath(),l.arc(d,u-6,4,0,Math.PI*2),l.stroke(),l.beginPath(),l.moveTo(d,u-2),l.lineTo(d,u+6),l.stroke(),l.beginPath(),l.moveTo(d-4,u+1),l.lineTo(d+4,u+1),l.stroke(),l.beginPath(),l.moveTo(d,u+6),l.lineTo(d-3,u+12),l.moveTo(d,u+6),l.lineTo(d+3,u+12),l.stroke()):(l.strokeStyle="#ef4444",l.lineWidth=2,l.beginPath(),l.moveTo(d-5,u-8),l.lineTo(d+5,u+8),l.moveTo(d+5,u-8),l.lineTo(d-5,u+8),l.stroke())}r&&be.bestTime&&(l.fillStyle="#fbbf24",l.font="12px monospace",l.fillText(`Best: ${(be.bestTime/1e3).toFixed(2)}s`,n+20,e+66)),rr<=0&&(l.fillStyle="#ef4444",l.font="bold 14px sans-serif",l.fillText("GAME OVER - Press Play to retry",n+20,e+(r?100:70)))}else if(He){r||(l.fillStyle="rgba(0,0,0,0.7)",l.fillRect(n+10,e+10,200,30));const o=ls(),i=r?48:32;if(o)l.fillStyle="#ff4444",l.font="bold 16px sans-serif",l.fillText("You're IT! Tag someone!",n+20,e+i);else{let s="",c=!1;if(pt!=null&&pt.itPlayerId){c=!0;for(const[d,u]of qt)if(d===pt.itPlayerId){s=u.displayName||"Another player";break}}if(!s){for(const[,d]of qt)if(d.isIt){s=d.displayName||"Another player",c=!0;break}}!c&&Oe&&(c=!0),s?(l.fillStyle="#22c55e",l.font="bold 16px sans-serif",l.fillText("Run! "+s+" is IT!",n+20,e+i)):c?(l.fillStyle="#22c55e",l.font="bold 16px sans-serif",l.fillText("Run! Someone is IT!",n+20,e+i)):(l.fillStyle="#fff",l.font="16px sans-serif",l.fillText("Waiting for IT player...",n+20,e+i))}r&&(l.fillStyle="#888",l.font="12px sans-serif",l.fillText("Touch another player to tag them",n+20,e+66))}else r&&(l.fillStyle="#fff",l.font="16px sans-serif",l.fillText("Explore freely!",n+20,e+48),l.fillStyle="#888",l.font="12px sans-serif",l.fillText("No timer, unlimited respawns",n+20,e+66));if(r&&(l.fillStyle="#666",l.font="11px sans-serif",l.fillText("WASD/Arrows, Space=jump, L=leaderboard",n+10,e+95)),bx(),wx(),Tx(),xn&&J){const o=performance.now()-fd,s=_y-o>1e3?"2":"1";J.fillStyle="rgba(0, 0, 0, 0.5)",J.fillRect(n,e,window.innerWidth,window.innerHeight),J.fillStyle="#fff",J.font="bold 120px sans-serif",J.textAlign="center",J.textBaseline="middle",J.fillText(s,n+window.innerWidth/2,e+window.innerHeight/2),J.textBaseline="alphabetic",J.textAlign="left"}l.restore()}function bx(){if(!J||!Me)return;const n=window.scrollX,e=window.scrollY,t=200,r=Me.subtext?60:40,o=n+20,i=e+window.innerHeight-r-20;J.fillStyle="rgba(0, 0, 0, 0.9)",J.fillRect(o,i,t,r),J.strokeStyle=Me.text==="GO!"?"#22c55e":Me.text==="GAME OVER"?"#ef4444":Me.text==="You fell!"?"#f59e0b":"#3b82f6",J.lineWidth=2,J.strokeRect(o,i,t,r),J.fillStyle="#fff",J.font="bold 16px sans-serif",J.textAlign="center";const s=Me.subtext?i+22:i+26;J.fillText(Me.text,o+t/2,s),Me.subtext&&(J.fillStyle="#888",J.font="13px sans-serif",J.fillText(Me.subtext,o+t/2,i+44)),J.textAlign="left"}function wx(){if(!J||!gn)return;const n=performance.now();if(n>gn.endTime){gn=null;return}const e=window.scrollX,t=window.scrollY,r=e+window.innerWidth/2,o=t+window.innerHeight/2,i=gn.endTime-gn.startTime,c=(n-gn.startTime)/i;let d=1;c<.1?d=c/.1:c>.8&&(d=(1-c)/.2),J.save(),J.globalAlpha=d,J.font="bold 36px sans-serif",J.textAlign="center",J.textBaseline="middle",J.fillStyle="rgba(0, 0, 0, 0.5)",J.fillText(gn.text,r+2,o+2),J.fillStyle="#ffffff",J.fillText(gn.text,r,o),J.restore()}function Tx(){if(!J||performance.now()>qc)return;const n=window.scrollX,e=window.scrollY,t=window.innerWidth,r=window.innerHeight,i=(qc-performance.now())/my,s=Math.min(.7,i*.9);J.save(),J.fillStyle=`rgba(220, 38, 38, ${s*.3})`,J.fillRect(n,e,t,r);const c=Math.min(1,i*1.5);J.font="bold 72px sans-serif",J.textAlign="center",J.textBaseline="middle",J.shadowColor="#ff0000",J.shadowBlur=30,J.fillStyle=`rgba(255, 255, 255, ${c})`,J.fillText("NO TAG BACKS",n+t/2,e+r/2),J.shadowBlur=15,J.fillText("NO TAG BACKS",n+t/2,e+r/2),J.restore()}function Ex(){if(!l)return;const n=window.scrollX,e=window.scrollY;l.save(),l.fillStyle="rgba(0,0,0,0.8)",l.fillRect(n+10,e+10,200,35),l.fillStyle="#22c55e",l.font="bold 14px sans-serif",l.fillText("BUILD MODE",n+20,e+32),l.fillStyle="#888",l.font="12px sans-serif";const t=os.charAt(0).toUpperCase()+os.slice(1);l.fillText(`Tool: ${t}`,n+115,e+32),l.restore()}function Ix(n){var r;if(Fe!=="play"||Io)return;let e=document.activeElement;for(;(r=e==null?void 0:e.shadowRoot)!=null&&r.activeElement;)e=e.shadowRoot.activeElement;if(!(e&&(e.tagName==="INPUT"||e.tagName==="TEXTAREA"||e.isContentEditable))){if(Vt[n.code]=!0,n.code==="Tab"||n.code==="KeyL"){n.preventDefault(),tt();return}["ArrowUp","ArrowDown","ArrowLeft","ArrowRight","Space"].includes(n.code)&&n.preventDefault()}}function Sx(n){Vt[n.code]=!1}let So=null;function xx(n,e){for(const t of be.checkpoints)if(t.width&&t.height){const r=t.x-t.width/2,o=t.x+t.width/2,i=t.y-t.height,s=t.y;if(n>=r&&n<=o&&e>=i&&e<=s)return t}else if(Math.hypot(n-t.x,e-t.y)<40)return t;return null}function Ax(n){if(Fe!=="build")return;const e=n.pageX,t=n.pageY,r=xx(e,t);if(r){if(n.button===2||n.shiftKey){be.checkpoints=be.checkpoints.filter(c=>c.id!==r.id),Vo(),tt();return}So=r,Re&&(Re.style.cursor="grabbing");return}if(os==="select")return;const o=os;(o==="start"||o==="finish"||o==="spawn")&&(be.checkpoints=be.checkpoints.filter(c=>c.type!==o));const i=o==="start"?0:o==="finish"?999:o==="spawn"?-1:o==="checkpoint"?be.checkpoints.filter(c=>c.type==="checkpoint").length+1:0,s={id:xy(),type:o,x:e,y:t,order:i,reached:!1};o==="trampoline"||o==="speedBoost"||o==="highJump"?(s.width=60,s.height=20):o==="spike"&&(s.width=60,s.height=30),be.checkpoints.push(s),Vo(),tt()}function kx(n){Fe==="build"&&So&&(So.x=n.pageX,So.y=n.pageY,tt())}function Px(n){So&&(Vo(),So=null,Re&&(Re.style.cursor="crosshair"))}function xy(){return Math.random().toString(36).substr(2,9)}async function Vo(){const n=On();localStorage.setItem(`oo_course_${n}`,JSON.stringify(be)),Ua()&&await xI(n,be),console.log("[OpenOverlay] Course saved")}function Cx(){const n=On();Kr()&&AI(n,t=>{t.myCourse&&(be=t.myCourse,be.checkpoints.forEach(r=>r.reached=!1),localStorage.setItem(`oo_course_${n}`,JSON.stringify(be))),Do=t.otherCourses.map(r=>({...r,checkpoints:(r.checkpoints||[]).map(o=>({...o,reached:!1}))})),console.log("[OpenOverlay] Course sync: mine=",be.checkpoints.length,"elements, others=",Do.length,"courses"),np(),Fe!=="none"&&tt()});const e=localStorage.getItem(`oo_course_${n}`);if(e)try{be=JSON.parse(e),be.checkpoints.forEach(t=>t.reached=!1),console.log("[OpenOverlay] Course loaded from localStorage:",be.checkpoints.length,"checkpoints"),np()}catch{console.warn("[OpenOverlay] Failed to load course")}}function On(){return btoa(window.location.href).slice(0,32)}function Ay(){return`oo_scores_${On()}`}function Rx(){const n=new Date;return new Date(n.getFullYear(),n.getMonth(),n.getDate()).getTime()}function ky(){const n=localStorage.getItem(Ay());if(!n)return[];try{const e=JSON.parse(n),t=Rx();return e.filter(r=>r.timestamp>=t)}catch{return[]}}function ta(n,e){const t=ky();t.push({name:n,time:e,timestamp:Date.now()}),t.sort((r,o)=>r.time-o.time),localStorage.setItem(Ay(),JSON.stringify(t)),localStorage.setItem("oo_player_name",n),$i=n}function Ox(){const n=ky(),e=n.slice(0,10);let t=null,r=-1;if($i){const o=n.filter(i=>i.name===$i);o.length>0&&(t=o[0],r=n.findIndex(i=>i.name===$i&&i.time===t.time)+1)}return{top10:e,playerBest:t,playerRank:r}}function Nx(){if(console.log("[OpenOverlay] toggleTagMode called, current isTagMode:",He),He)He=!1,Bc(),Oe=!1,yn=null,Kn=null,Lr=0,console.log("[OpenOverlay] Left tag mode"),document.dispatchEvent(new CustomEvent("oo:tagstatechange",{detail:{isTagMode:!1,isIt:!1,gameActive:!1}})),zt("Left tag game","",1500);else{He=!0,Bc();const n=On();console.log("[OpenOverlay] Starting/joining tag game on page:",n);let e=!1;for(const[,t]of qt)if(t.isIt){e=!0;break}Oe=!e,console.log("[OpenOverlay] localIsIt:",Oe,"someoneElseIsIt:",e),document.dispatchEvent(new CustomEvent("oo:tagstatechange",{detail:{isTagMode:!0,isIt:Oe,gameActive:!0}})),cs(),console.log("[OpenOverlay] Forced sync with isIt:",Oe),Oe?zt("You're IT!","Tag another player!",2e3):zt("Tag Mode!","Avoid being tagged!",2e3),EI(n).then(t=>{console.log("[OpenOverlay] startTagGame returned:",t),t&&!Oe&&(Oe=!0,document.dispatchEvent(new CustomEvent("oo:tagstatechange",{detail:{isTagMode:!0,isIt:!0,gameActive:!0}})))}).catch(t=>{console.log("[OpenOverlay] Firebase unavailable, using local tag state:",Oe)})}}function Gc(n){const e=Es();if(!e)return;const t=e.querySelector(".fab");t&&(n?(t.style.background="#22c55e",t.style.boxShadow="0 0 20px #22c55e, 0 0 40px #22c55e",t.style.transform="scale(1.1)"):(t.style.background="",t.style.boxShadow="",t.style.transform=""))}function Lx(n){const e=Es();if(!e)return;const t=e.querySelectorAll(".mini");t.forEach(r=>r.classList.remove("active")),t[n]&&t[n].classList.add("active")}function Py(){const n=Es();if(!n)return;n.querySelectorAll(".mini").forEach(t=>t.classList.remove("active")),Gc(!1),Lc(!1)}const pd="oo_onboarding_complete",Cy="oo_onboarding_skipped",Ya="oo_onboarding_shown_this_session",Mx=5,Dx=.6,na=-12,Vx=100,va=2500,bl="#ff69b4",Fx="#d45a9d",At="#ffffff",oc="#000000";let C={step:0,smudgyX:-50,smudgyY:0,smudgyVx:0,smudgyVy:0,onGround:!0,facingRight:!0,animFrame:0,speechBubble:null,speechTimer:0,isComplete:!1,isSkipped:!1,stepTimer:0,eyeLookDirection:1},kt=null,O=null,xt=null,Yc=0,Ka=0,wi=[];function Ux(){return!(localStorage.getItem(pd)==="true"||localStorage.getItem(Cy)==="true"||sessionStorage.getItem(Ya)==="true")}function qx(){console.log("[Smudgy] Starting onboarding..."),sessionStorage.setItem(Ya,"true"),Ka=window.innerHeight-Vx,C={step:0,smudgyX:window.innerWidth/2,smudgyY:-50,smudgyVx:0,smudgyVy:2,onGround:!1,facingRight:!0,animFrame:0,speechBubble:null,speechTimer:0,drawnLine:[],isComplete:!1,isSkipped:!1,stepTimer:0,eyeLookDirection:0},vn=[],Oi=0,Yt=[],Bx(),$x();const n=()=>{C.step>0&&!C.isComplete&&!C.isSkipped&&(console.log("[Smudgy] Menu closed - onboarding complete!"),localStorage.setItem(pd,"true"),gd(),window.removeEventListener("oo:menuClosed",n))};window.addEventListener("oo:menuClosed",n),Yc=performance.now(),requestAnimationFrame(Ry)}function Bx(){kt=document.createElement("canvas"),kt.id="smudgy-onboarding-canvas",kt.style.cssText=`
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    pointer-events: none;
    z-index: 2147483648;
  `,kt.width=window.innerWidth,kt.height=window.innerHeight,document.body.appendChild(kt),O=kt.getContext("2d")}function $x(){xt=document.createElement("div"),xt.id="smudgy-skip",xt.textContent="skip intro",xt.style.cssText=`
    position: fixed;
    top: 20px;
    right: 20px;
    padding: 8px 16px;
    background: rgba(0, 0, 0, 0.5);
    color: white;
    font-family: sans-serif;
    font-size: 12px;
    border-radius: 20px;
    cursor: pointer;
    z-index: 2147483649;
    opacity: 0.7;
    transition: opacity 0.2s;
  `,xt.addEventListener("mouseenter",()=>{xt.style.opacity="1"}),xt.addEventListener("mouseleave",()=>{xt.style.opacity="0.7"}),xt.addEventListener("click",()=>{C.isSkipped=!0,localStorage.setItem(Cy,"true"),gd()}),document.body.appendChild(xt)}function gd(){kt&&(kt.remove(),kt=null,O=null),xt&&(xt.remove(),xt=null),Py(),C.isComplete=!0}function Ry(n){if(C.isComplete||C.isSkipped)return;const e=Math.min((n-Yc)/16.67,3);Yc=n,jx(e),Hx(e),Gx(),!C.isComplete&&!C.isSkipped&&requestAnimationFrame(Ry)}function jx(n){C.onGround||(C.smudgyVy+=Dx*n),C.smudgyX+=C.smudgyVx*n,C.smudgyY+=C.smudgyVy*n,C.step<=2&&C.smudgyY>=Ka&&(C.smudgyY=Ka,C.smudgyVy=0,C.onGround=!0),C.smudgyVx>.5?C.facingRight=!0:C.smudgyVx<-.5&&(C.facingRight=!1),Math.abs(C.smudgyVx)>.5?C.eyeLookDirection=1:(Math.abs(C.eyeLookDirection)===1&&(C.eyeLookDirection=C.facingRight?1:-1),Math.abs(C.eyeLookDirection)>.1?C.eyeLookDirection*=.98:C.eyeLookDirection=0),Math.abs(C.smudgyVx)>.5?C.animFrame=(C.animFrame+.2*n)%4:C.animFrame=0,Math.abs(C.smudgyVx)>2?(wi.unshift({x:C.smudgyX,y:C.smudgyY-25}),wi.length>8&&wi.pop()):wi.length>0&&wi.pop(),C.speechTimer>0&&(C.speechTimer-=n*16.67,C.speechTimer<=0&&(C.speechBubble=null))}function ra(n){C.speechBubble=n,C.speechTimer=va}function zx(){const n=Es();if(!n)return{x:window.innerWidth-40,y:window.innerHeight-40};const e=n.querySelector(".fab");if(!e)return{x:window.innerWidth-40,y:window.innerHeight-40};const t=e.getBoundingClientRect();return{x:t.left+t.width/2,y:t.top+t.height/2}}function Wx(n){const e=Es();if(!e)return{x:window.innerWidth-40,y:window.innerHeight-100-n*50};const t=e.querySelectorAll(".mini");if(!t[n])return{x:window.innerWidth-40,y:window.innerHeight-100-n*50};const r=t[n].getBoundingClientRect();return{x:r.left+r.width/2,y:r.top+r.height/2}}let vn=[],Oi=0,Yt=[];function Hx(n){C.stepTimer+=n*16.67;const e=zx(),t=Wx(0);switch(C.step){case 0:C.onGround&&C.stepTimer>500&&(C.smudgyVx=0,C.step=1,C.stepTimer=0,ra("hi! i'm smudgy!"));break;case 1:C.stepTimer>va&&(C.step=2,C.stepTimer=0,C.smudgyVx=Mx);break;case 2:C.smudgyX>=e.x-80&&(C.smudgyVx=0,C.step=3,C.stepTimer=0,mS());break;case 3:C.stepTimer>500&&(C.smudgyVy=na*.6,C.smudgyVx=3,C.onGround=!1,C.step=4,C.stepTimer=0);break;case 4:C.smudgyX<e.x-5?C.smudgyVx=3:C.smudgyX>e.x+5?C.smudgyVx=-2:C.smudgyVx=0,Math.floor(C.stepTimer/500)!==Math.floor((C.stepTimer-n*16.67)/500)&&console.log(`[Smudgy] Step 4: smudgyY=${C.smudgyY.toFixed(0)}, fabPos.y=${e.y.toFixed(0)}, vy=${C.smudgyVy.toFixed(1)}`),C.smudgyVy>0&&C.smudgyY>=e.y-70&&(C.smudgyX=e.x,C.smudgyY=e.y-65,C.smudgyVx=0,C.smudgyVy=0,C.onGround=!0,C.step=5,C.stepTimer=0,Gc(!0),console.log("[Smudgy] Landed on FAB at Y="+C.smudgyY.toFixed(0)+", turning green!"));break;case 5:C.stepTimer>1500&&(Gc(!1),C.smudgyVy=na*.7,C.onGround=!1,C.step=6,C.stepTimer=0);break;case 6:const r=t.x-C.smudgyX;if(Math.abs(r)>5&&(C.smudgyVx=r*.1),C.smudgyVy>0&&C.stepTimer>200){C.smudgyX=t.x,C.smudgyY=t.y-25,C.smudgyVx=0,C.smudgyVy=0,C.onGround=!0,C.step=7,C.stepTimer=0,ra("draw here!"),Lx(0),Bf("draw"),Oi=0,vn=[],Yt=[];const v=80,L=e.x-60,P=50;for(let M=0;M<=P;M++)Yt.push({x:v+(L-v)*(M/P),y:Ka})}break;case 7:Oi+=n*.025;const o=Math.floor(Yt.length*Math.min(Oi,1));vn=Yt.slice(0,o+1),C.stepTimer>va&&Oi>=1&&(Yt.length>1&&qS(Yt,bl,4),Bf("none"),Py(),C.smudgyVy=na*.5,C.onGround=!1,C.step=8,C.stepTimer=0);break;case 8:const i=vS(),s=i?i.x:e.x,c=i?i.y:e.y,d=s-C.smudgyX;Math.abs(d)>5&&(C.smudgyVx=d*.08),C.smudgyVy>0&&C.smudgyY>=c-60&&(C.smudgyX=s,C.smudgyY=c-40,C.smudgyVx=0,C.smudgyVy=0,C.onGround=!0,C.step=9,C.stepTimer=0,Lc(!0),ra("sign in for TONS more!"),console.log("[Smudgy] Landed on profile button!"));break;case 9:C.stepTimer>2e3&&(Lc(!1),C.smudgyVy=na*.5,C.onGround=!1,C.step=10,C.stepTimer=0);break;case 10:const u=yS(),f=u?u.x:e.x,g=u?u.y:e.y-20,m=f-C.smudgyX;if(Math.abs(m)>5&&(C.smudgyVx=m*.08),C.smudgyVy>0&&C.smudgyY>=g-60){C.smudgyX=f,C.smudgyY=g-40,C.smudgyVx=0,C.smudgyVy=0,C.onGround=!0,C.step=11,C.stepTimer=0,ra("explore with me!"),console.log("[Smudgy] Landed on explore button!");const v=Yt.length>0?Yt[Math.floor(Yt.length/2)].x:window.innerWidth/2;document.dispatchEvent(new CustomEvent("oo:gamemode",{detail:{mode:"play",playmode:"explore",spawnPos:{x:v,y:-50},fromOnboarding:!0}}))}break;case 11:C.stepTimer>va+1e3&&(localStorage.setItem(pd,"true"),gd());break}}function Gx(){if(!(!O||!kt)){if(O.clearRect(0,0,kt.width,kt.height),vn.length>1){O.save(),O.strokeStyle=bl,O.lineWidth=4,O.lineCap="round",O.lineJoin="round",O.beginPath(),O.moveTo(vn[0].x,vn[0].y);for(let n=1;n<vn.length;n++)O.lineTo(vn[n].x,vn[n].y);O.stroke(),O.restore()}Yx(C.smudgyX,C.smudgyY,C.facingRight,C.animFrame,C.step===1),C.speechBubble&&Kx(C.smudgyX,C.smudgyY-60,C.speechBubble)}}function Yx(n,e,t,r,o){if(!O)return;O.save();const i=Math.abs(C.smudgyVx)>.5;i&&!t&&(O.translate(n,0),O.scale(-1,1),O.translate(-n,0));const s=7,c=13,d=11,u=n,f=e-38+s+3,g=f+s,m=g+c;O.strokeStyle=At,O.lineWidth=3,O.lineCap="round",O.lineJoin="round",O.shadowColor="rgba(0,0,0,0.3)",O.shadowBlur=4,O.shadowOffsetX=2,O.shadowOffsetY=2;const v=f-s,L=Math.sin(C.animFrame*Math.PI*2)*2,P=Z=>{O.strokeStyle=At,O.lineWidth=3.1,Z(),O.stroke(),O.strokeStyle=oc,O.lineWidth=2.8,Z(),O.stroke(),O.strokeStyle=At,O.lineWidth=2.5,Z(),O.stroke()};O.lineCap="round",i?(P(()=>{O.beginPath(),O.moveTo(u+2,v+1),O.bezierCurveTo(u+1,v-8,u-3,v-9,u-6+L*.5,v-7)}),P(()=>{O.beginPath(),O.moveTo(u-2,v+1),O.bezierCurveTo(u-2,v-5,u-4,v-6,u-7+L*.4,v-4)})):(P(()=>{O.beginPath(),O.moveTo(u+1,v+1),O.quadraticCurveTo(u+1,v-5,u,v-9)}),P(()=>{O.beginPath(),O.moveTo(u-2,v+2),O.quadraticCurveTo(u-2,v-2,u-2,v-5)})),O.strokeStyle=At,O.lineWidth=3,O.beginPath(),O.arc(u,f,s,0,Math.PI*2),O.stroke(),O.shadowColor="transparent",O.shadowBlur=0,O.shadowOffsetX=0,O.shadowOffsetY=0,O.fillStyle=bl,O.beginPath(),O.arc(u,f,s-1,0,Math.PI*2),O.fill(),O.strokeStyle=Fx,O.lineWidth=1,O.beginPath(),O.arc(u,f,s-1,0,Math.PI*2),O.stroke();const M=s-3;let G=C.eyeLookDirection*M,$=0,D=1;C.onGround?Math.abs(C.eyeLookDirection)>.3&&($=1):C.smudgyVy<-2?($=-4,D=.3):C.smudgyVy>2&&($=1);const j=s-4;O.save(),O.globalCompositeOperation="destination-out",O.beginPath(),O.arc(u+G*D,f+$,j,0,Math.PI*2),O.fill(),O.restore(),O.strokeStyle=At,O.lineWidth=2,O.beginPath(),O.arc(u,f,s,0,Math.PI*2),O.stroke();const V=(Z,de,fe,me)=>{O.strokeStyle=At,O.lineWidth=3.6,O.beginPath(),O.moveTo(Z,de),O.lineTo(fe,me),O.stroke(),O.strokeStyle=oc,O.lineWidth=3.3,O.beginPath(),O.moveTo(Z,de),O.lineTo(fe,me),O.stroke(),O.strokeStyle=At,O.lineWidth=3,O.beginPath(),O.moveTo(Z,de),O.lineTo(fe,me),O.stroke()};V(u,g,u,m);const B=Math.sin(r*Math.PI),I=i,b=(Z,de,fe,me,xe,Te)=>{const Ie=Z+Math.sin(fe)*me*(Te?-1:1),ae=de+Math.cos(fe)*me,ye=fe+(Te?-1.2:1.2),ve=Ie+Math.sin(ye)*xe*(Te?-1:1),Ae=ae+Math.cos(ye)*xe;O.strokeStyle=At,O.lineWidth=3.6,O.beginPath(),O.moveTo(Z,de),O.lineTo(Ie,ae),O.lineTo(ve,Ae),O.stroke(),O.strokeStyle=oc,O.lineWidth=3.3,O.beginPath(),O.moveTo(Z,de),O.lineTo(Ie,ae),O.lineTo(ve,Ae),O.stroke(),O.strokeStyle=At,O.lineWidth=3,O.beginPath(),O.moveTo(Z,de),O.lineTo(Ie,ae),O.lineTo(ve,Ae),O.stroke()},_=g+4,E=m,T=6,S=6;if(o){const Z=Math.sin(r*4)*.4;b(u,_,-1.5+Z,T,S,!0),b(u,_,.3,T,S,!1)}else if(I){const Z=B*.8;b(u,_,-Z*.6,T,S,!0),b(u,_,Z*.6,T,S,!1)}else b(u,_,.1,T,S,!0),b(u,_,.1,T,S,!1);const w=I?Math.sin(r*Math.PI)*8:0;!C.onGround&&C.smudgyVy<0?(V(u,E,u-3,E+d*.7),V(u,E,u+3,E+d*.7)):C.onGround?(V(u,E,u-4+w,E+d),V(u,E,u+4-w,E+d)):(V(u,E,u-7,E+d),V(u,E,u+7,E+d)),O.restore()}function Kx(n,e,t){if(!O)return;O.save();const r=12,o=14;O.font=`bold ${o}px -apple-system, BlinkMacSystemFont, sans-serif`;const s=O.measureText(t).width+r*2,c=28,d=n-s/2,u=e-c;O.fillStyle=At,O.strokeStyle="#333",O.lineWidth=2,O.beginPath(),O.roundRect(d,u,s,c,8),O.fill(),O.stroke(),O.fillStyle=At,O.beginPath(),O.moveTo(n-8,u+c-1),O.lineTo(n,u+c+10),O.lineTo(n+8,u+c-1),O.fill(),O.strokeStyle="#333",O.beginPath(),O.moveTo(n-8,u+c),O.lineTo(n,u+c+10),O.lineTo(n+8,u+c),O.stroke(),O.fillStyle=At,O.fillRect(n-9,u+c-2,18,4),O.fillStyle="#333",O.textAlign="center",O.textBaseline="middle",O.fillText(t,n,u+c/2),O.restore()}function Xx(){if(sessionStorage.getItem(Ya)==="true")return;sessionStorage.setItem(Ya,"true"),console.log("[Smudgy] Welcome back wave");const n=document.createElement("canvas");n.style.cssText=`
    position: fixed;
    bottom: 60px;
    right: 60px;
    width: 80px;
    height: 80px;
    pointer-events: none;
    z-index: 2147483645;
  `,n.width=80,n.height=80,document.body.appendChild(n);const e=n.getContext("2d");if(!e)return;let t=0;const r=()=>{t++,e.clearRect(0,0,80,80);const o=t<30?t/30:t>90?(120-t)/30:1;e.globalAlpha=o;const i=Math.sin(t*.15)*.5;e.strokeStyle=At,e.lineWidth=2.5,e.lineCap="round",e.lineJoin="round",e.shadowColor="rgba(0,0,0,0.3)",e.shadowBlur=3,e.shadowOffsetX=1,e.shadowOffsetY=1,e.beginPath(),e.arc(40,25,8,0,Math.PI*2),e.stroke(),e.fillStyle=bl,e.beginPath(),e.arc(40,25,7,0,Math.PI*2),e.fill(),e.save(),e.globalCompositeOperation="destination-out",e.beginPath(),e.arc(40,25,4,0,Math.PI*2),e.fill(),e.restore(),e.beginPath(),e.moveTo(40,33),e.lineTo(40,48),e.stroke();const s=40-10*Math.cos(-.8+i),c=37+10*Math.sin(-.8+i);e.beginPath(),e.moveTo(40,37),e.lineTo(s,c),e.stroke(),e.beginPath(),e.moveTo(40,37),e.lineTo(48,44),e.stroke(),e.beginPath(),e.moveTo(40,48),e.lineTo(36,60),e.stroke(),e.beginPath(),e.moveTo(40,48),e.lineTo(44,60),e.stroke(),t<120?requestAnimationFrame(r):n.remove()};requestAnimationFrame(r)}if(window.__OPENOVERLAY_V2__)console.log("[OpenOverlay] Already injected, skipping");else{let n=function(){console.log("[OpenOverlay] init() called"),console.log("[OpenOverlay] document.body exists:",!!document.body);try{nI(),kI()}catch(e){console.warn("[OpenOverlay] Firebase init failed (may be incognito):",e)}try{rS(),_S(),OI(),nx(),console.log("[OpenOverlay] Ready!"),setTimeout(()=>{Ux()?qx():Xx()},1500)}catch(e){console.error("[OpenOverlay] UI init error:",e)}};window.__OPENOVERLAY_V2__=!0,console.log("[OpenOverlay] v2.0.0 starting..."),document.body?n():document.readyState==="loading"?document.addEventListener("DOMContentLoaded",n):setTimeout(n,100)}
})()
